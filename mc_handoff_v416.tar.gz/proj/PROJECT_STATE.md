# PROJECT_STATE — 마블 챔피언스 디지털화

## v2026.07.12.172 — 빌런 승리(플레이어 패배) 테마 대사 시스템
**배경:** 사용자 요청 — 어떤 이유로든 플레이어가 패배할 때(히어로 체력 0 / 메인 스킴
달성) 빌런 테마에 맞는 승리 대사 출력. 패배 사유별 빌런당 각 5개, 총 10개. 메모리 #8 저장.
**무엇을:**
- ★ setGameOver(G, result, reason, cause) — cause 카테고리 신설:
  'heroDefeat'(히어로 체력 0/전원 탈락) / 'schemeComplete'(메인 스킴 달성)
  · loss + cause + 빌런 quoteKey + hasQuote 있으면 → G.over.villainQuote/villainName 세팅
  · 승리(win) 시엔 대사 안 붙음. cause 없는 구 호출도 조용히 스킵(하위호환)
- 패배 호출부 2곳에 cause 태깅:
  · mc_5_encounter.js: 메인 스킴 완성 → 'schemeComplete'
  · mc_6_keywords.js: 전원 탈락(히어로 체력 0) → 'heroDefeat'
- QUOTES(ui/mc_vfx.js): 라이노·클로에 heroDefeat/schemeComplete 각 5개 추가
  · 라이노(01094, quoteKey:rhino): 무식한 돌격·순박한 괴력 톤 — 짓밟기/임무완수
  · 클로(01113, quoteKey:klaw): 음파 물리학자·예술가적 광기 톤 — 침묵/교향곡 완성
- 결과창(results-overlay): 패배 + villainQuote 있으면 붉은 말풍선(rvq-name+rvq-text)으로
  빌런 이름과 조롱 대사 표시. 승리 시엔 미표시
**검증:** 브라우저 환경(빌드 HTML) vm 시뮬 — 라이노/클로 × heroDefeat/schemeComplete
4조합 모두 대사 정상 선택, 승리 시 미표시 확인 ✓ · 회귀 전체 통과 · 2092KB
**주의:** MC.hasQuote/randomQuote는 mc_vfx.js 정의라 node로 engine+cards만 로드 시 undefined.
검증은 반드시 빌드된 HTML(mc_vfx 포함)로 해야 함
**UI:** results-villainquote + rvq-name/rvq-text CSS (붉은 말풍선)
---

## v2026.07.12.146 — 조우 카드 공개 모달 시네마틱 개편 (타입 테마 + 플립)
**배경:** 사용자 피드백 — 조우카드 공개가 거의 로그로만 확인되고 기존 모달은 테마도
안 살고 허접. 부스트 오버레이(v145)와 톤을 통일해 전면 개편.
**무엇을:**
- revealModalHTML 전면 재작성 (rvm-* → rvx-*):
  · 타입별 테마 시스템(RVX_THEME + CSS --rvx 액센트 변수): 배반=보라⚡ / 하수인=적⚔ /
    사이드 스킴=청록🗺 / 부착=주황🔗 / 의무=갈색📜 / 환경=청색🌐.
    배경 방사광·박스 테두리·헤더 아이콘·카드 테두리가 모두 테마 컬러를 따름
  · 카드가 조우덱 뒷면(👁 보라 스트라이프)→앞면 3D 플립으로 등장 (0.24s 딜레이 + 0.5s 플립)
  · 헤더: 타입 아이콘 원형 배지(팝 등장) + "조우 카드 공개 — 배반" 식 타이틀
  · 하수인: ATK/SCH/HP 스탯 배지 미리보기 + 등장 대사를 꼬리 달린 만화 말풍선으로
  · 사이드 스킴: 시작 위협(플레이어 수 반영) 배지
  · 효과 텍스트는 테마색 좌측 보더 블록, 적용 로그는 "결과" 타이틀 달린 블록
  · 하단 진행 도트: 현재(● 발광)+남은(○ 최대 7 + 초과 +n) — 몇 장 남았는지 한눈에
  · 본문 우측 슬라이드 인, 헤더/도트 스태거 등장 (시네마틱 타이밍)
- 구 .rvm-* CSS 완전 제거 (잔여 참조 0 확인). vpanel 타입 칩(rv-t-*)은 유지
**검증:** 회귀 전체 통과 · 빌드 rvx 요소 10종 포함 + rvm 잔여 0 · JS 문법 OK · 2085KB
**UI:** reveal-modal 테마 변수 시스템(--rvx/--rvxglow) + rvx-flip/quote/stats/dots
---

## v2026.07.12.145 — 부스트 카드 공개 전용 시퀀스 오버레이 (플립 + 발동 옵션 명시)
**배경:** 사용자 피드백 — 부스트/추가 부스트 카드가 뭘 뽑았고 무슨 옵션(▲아이콘/부스트★)이
발동했는지 구분이 어렵고, 노출시간·연출이 부족.
**무엇을:**
- ★ 부스트 카드 공개를 범용 revealQueue 모달에서 분리 — 전용 시퀀스 오버레이 신설
  (boost-reveal-modal). 리펄서 fxReveal 패턴을 따름.
  · 엔진: resolveBoostStar가 발동 내역을 G._lastBoostStar에 기록
    ({kind:'minion'} 전장 배치 / {kind:'effect',effect} 효과 발동)
  · 엔진: resolveDefensePending(공격)·enemyActivation 스킴부가 boostEvents를 모아
    G.fxBoostReveal 힌트 세팅: {kind:'attack'|'scheme', attackerName, base, boostTotal,
    events:[{defCode,name,boost,extra,star}], seq}
  · UI: seq diff 감지 → 오버레이. 카드별 순차(620ms 스태거) 등장 → 뒷면(🂠)→앞면 3D 플립
    → 이름 → ▲아이콘 팝(개수만큼 + '+n') → ★발동 콜아웃 순으로 단계 공개
  · 배지: 기본 부스트="부스트 카드"(금색) / 클로 강제 난입 추가="⚡ 강제 난입 — 추가 부스트"
    (적색 점멸 + 카드 테두리 적색)
  · ★ 콜아웃: 전장 배치="★ 전장에 교전 상태로 등장!" / 효과=BOOST_STAR_LABELS 한국어 맵
    (toughEnemy/discardBooster/exhaustAllAllies/damageEachHeroBoost, 미등록은 id 폴백)
  · 하단 합산 공식: 공격="기본 피해 X + 부스트 ▲n = 총 피해 Y" / 스킴="기본 위협 X + ▲n = 위협 +Y"
  · 노출시간: 확인 버튼으로 사용자 제어 (자동 소멸 없음) + 플립 스태거로 카드별 순차 가독
  · 빌런 자동 진행(maybeStepVillain)·연출 지연(baseDelay)이 오버레이 표시 중 일시정지,
    확인 시 재개. revealQueue에서 boost 타입 제외(중복 방지, vpanel 목록에는 유지)
**검증:** 엔진 힌트 시뮬 — 클로 공격(기본+추가 2건, extra 플래그) / 빌런 스킴(1건) /
부스트★ star 정보(im-tough→effect:toughEnemy, weapons-runner→minion 배치) 모두 확인 ✓ ·
회귀 전체 통과 · 빌드 요소 8종 포함 확인 · 2082KB
**UI:** boost-reveal-modal + bxr-* CSS (3D 플립 backface, 배지 점멸, ▲팝, ★콜아웃)
---

## v2026.07.12.144 — 01113~01115 클로 빌런 3단계 (★ 시나리오 순서 복구 시작)
**배경:** 하수인만 골라 진행하다 클로 빌런 시나리오(01113~01128)를 통째로 건너뛴 것을
사용자가 지적. 결정: "01113 클로 빌런부터 mcode 순서대로 채우기". 이번은 빌런 본체 등록.
**무엇을:**
- 클로(Ulysses Klaw) 빌런 3단계 등록 — Core Set #113~115. 음파 물리학자→"살아있는 소리"의
  무기 밀매업자, 블랙 팬서/와칸다 숙적, 마스터즈 오브 이블.
  · I (01113): ATK0/SCH2/HP12×히어로, nextStage 01114
  · II(01114): ATK1/SCH2/HP18×히어로. 공개 시 "불멸의 클로" 사이드 스킴 공개+셔플
  · III(01115): ATK2/SCH3/HP22×히어로. Toughness(등장 시 tough)
  · 공통: 강제 난입 — 공격 시 부스트 카드 1장 추가 (villainAttackExtraBoost:1)
  · 공식 JSON 교차검증(HP 12/18/22, ATK 0/1/2, SCH 2/2/3 확정)
- ★ 엔진: 빌런 공격 시 추가 부스트 카드 처리 신설. enemyActivation이 villainAttackExtraBoost
  만큼 부스트 카드를 추가로 뽑아 pending.extraBoostCards에 뒷면 보관. resolveDefensePending
  이 추가 부스트도 공개·아이콘 합산·부스트★·버림 처리 (기존 단일 boostCard 구조 확장)
- 불멸의 클로(the-immortal-klaw, 01127) 사이드 스킴 등록: 지속 클로 HP +10, 해결 시 -10
  (hpBonusImmortalKlaw 추적). Stage II whenRevealed가 참조
- 클로 fx 파일 신설(mc_cards_zzklaw_fx.js): klawStage2/3Reveal, immortalKlawReveal/Defeated
- 테마: 율리시스 클로 — 음파에 도취된 존재, "에너지! 이토록 장엄한 불협화음!"
  · enter/stageChange/defeat 각 10개 (빌런 대사 규칙 — 음파·비브라늄·와칸다 숙적 톤)
  · vfx 4종: sonicEmerge(등장·음파 응축), sonicBlast(공격·음파 대포 빔+동심원 파동),
    sonicSurge(페이즈변화·음파 폭발 진화), sonicShatter(패배·음파 붕괴+색 소실+SILENCE)
  · sonicWaves 공통 헬퍼(동심원 음파 링)
**검증:** 클로 17종(3단계 스탯/unique+트레잇/nextStage/부스트+1 정의/공격 시 부스트 2장 소비/
방어 해소 2장 버림/불멸의클로 공개·HP±10/Toughness/vfx) ✓ · vfx_index 313건 · 대사 10/10×3 ✓ ·
회귀 전체 통과 · 2073KB
**연출 인덱스:** +sonicEmerge/sonicBlast/sonicSurge/sonicShatter (클로 음파 4종)
**엔진:** villainAttackExtraBoost (빌런 공격 추가 부스트 카드) + pending.extraBoostCards
**카드 작업:** 클로 시나리오 복구 시작. 빌런 본체 완료. 다음 mcode 순:
01116 underground-distribution(메인스킴1), 01117 secret-rendezvous(메인스킴2),
01118 sonic-converter/01119 solid-sound-body(부착), 01122 klaws-vengeance(배반),
01123 sonic-boom/01124 sound-manipulation(배반 todoFx), 01125 defense-network/
01126 illegal-arms-factory(사이드 todoFx), 01128 the-masters-of-evil(사이드).
그 후 클로 시나리오 SCENARIOS 조립.
---

## v2026.07.12.143 — 01132 멜터 (지속 강제 동료 방어 + 부스트★ 동료 소진 + 대사/이펙트)
**무엇을:**
- ★ 지속 효과 "강제 동료 방어"(forceAllyDefend) 시스템 신설: 멜터 공격 시 준비된 동료가 있으면
  pending.mustDefendWithAlly 마커 설정 → 신분·무방어 방어 거부(throw), 동료 방어만 허용.
  · 엔진: enemyActivation이 forceAllyDefend def 확인 후 hasReadyAlly면 마커 세팅.
    resolveDefensePending 검증부에서 마커+동료 있으면 identity/none 거부
  · UI: mustDefendWithAlly면 신분·무방어 버튼 disabled + "동료 방어 강제" 칩 표시
  · 봇: smoke/phase1 autoPlay가 mustDefendWithAlly면 준비된 동료로 자동 방어 (throw 회피)
- ★ EFFECTS.exhaustAllAllies 신설: 통제하는 모든 동료 소진 (멜터 부스트★)
- 01132 멜터(melter) 등록: forceAllyDefend:true + boostStarEffect:exhaustAllAllies + vfx.
  공식 JSON 교차검증(ATK3/SCH1/HP5/×1 unique/Elite+Masters of Evil/지속 동료방어+부스트★)
- 테마: 브루노 호건 — 아이언맨의 첫 숙적, 용해 광선 발명가(마스터즈 오브 이블 창립 멤버).
  스타크에 뺏긴 계약 복수 집착 + 과대망상(자기가 스타크보다 천재) + 늘 지는 이류 빌런:
  · enter 5개(스타크 복수+용해 광선 과대망상), attack 5개(용해 광선 발사), defeat 5개(또 패배한 최후)
  · vfx.attack = meltRay (광선 충전 → 주황~백열 용해 광선 발사 → 대상 녹아내림(흘러내리는 방울) +
    MELT!)
**검증:** 멜터 11종(스탯/unique+트레잇/mustDefendWithAlly 마커/신분·무방어 거부/동료 방어 성공/
동료 피해/부스트★ 전 동료 소진/vfx 참조/교차검증) ✓ · vfx_index 300건 · 랜덤 5/5×3 ✓ ·
회귀 전체 통과(봇 강제 동료 방어 갱신) · 2054KB
**연출 인덱스:** +meltRay (하수인 공격 이펙트 10호)
**엔진:** forceAllyDefend 지속 효과(mustDefendWithAlly) + exhaustAllAllies effect
**카드 작업:** 코어셋 하수인 mcode 순 진행 — Klaw/Masters of Evil 하수인 10종 완료
(01101/02/03/10/20/21/29/30/31/32). 다음 후보=01143 어드밴스드 울트론 드론 등 Ultron 하수인
---

## v2026.07.12.142 — 01131 타이거 샤크 (공격 후 자기 강인 + 부스트★ 빌런 강인 + 대사/이펙트)
**무엇을:**
- 01131 타이거 샤크(tiger-shark) 등록: 기존 시스템(forcedResponse 공격 후 발화 + boostStar) 재사용.
  · ★강제 반응 fr_tigerShark — 공격 후 자신에게 강인(status.tough+1) 부여 (점점 단단해지는 상어)
  · ★부스트 toughEnemy — 빌런에게 강인 부여 (boostStarEffect, 기본 대상 villain)
  · 공식 JSON 교차검증(ATK3/SCH1/HP6/×1 unique/Masters of Evil/강제반응+부스트★)
- 테마: 토드 아를리스 — 올림픽 수영선수가 나모르+타이거샤크 DNA 융합으로 반인반상어가 됨.
  거친 포식자 + 사냥 본능(한번 노린 먹이는 안 놓침) + 면도날 이빨 + 자부심. 물 밖에선 약해짐:
  · enter 5개(포식자 사냥 본능+자부심), attack 5개(물어뜯기), defeat 5개(물 밖에서 말라가는 최후)
  · vfx.attack = sharkBite (물살 궤적 돌진 → 상어 아가리 물어뜯기(위아래 이빨 맞물림) → 물보라 +
    CHOMP!)
**검증:** 타이거 샤크 7종(스탯/unique+트레잇/공격 후 자기 강인/공격 힌트/부스트★ 빌런 강인/vfx
참조/교차검증) ✓ · vfx_index 296건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과 · 2046KB
**연출 인덱스:** +sharkBite (하수인 공격 이펙트 9호)
**카드 작업:** 하수인 mcode 순 진행 — 다음 01132 멜터(melter, Masters of Evil)
**진행 현황:** Klaw/Masters of Evil 하수인 다수 완료. 코어셋 하수인 대사/이펙트 순차 진행 중
(완료: 01101 하이드라용병, 01102 샌드맨, 01103 쇼커, 01110 하이드라폭파범, 01120 무장경호원,
01121 무기밀매상, 01129 라디오액티브맨, 01130 회오리바람, 01131 타이거샤크)
---

## v2026.07.12.141 — 01130 회오리바람 (강제 난입 다중 히어로 공격 체인 + 대사/이펙트)
**무엇을:**
- ★ 강제 난입(forcedInterrupt) 다중 히어로 공격 체인 시스템 신설: 회오리바람 "공격 시 다른
  모든 히어로에게도 동일 공격". enemyActivation이 첫 방어 pending에 alsoAttack[남은 히어로 uid들]을
  담고, resolveDefensePending 완료 시 남은 대상이 있으면 그 다음 히어로의 방어 pending을 체인 생성.
  각 히어로가 개별 방어 선언 가능. 마지막 대상 해소 후 정상 종료. (단일 게임에선 무의미, 멀티 전용)
- 01130 회오리바람(whirlwind) 등록:
  · ★강제 난입 fi_attackEachHero (마커 — 엔진 pending.alsoAttack 체인이 실제 처리, no-op 핸들러)
  · ★부스트 damageEachHeroBoost (각 히어로 1피해)
  · 공식 JSON 교차검증(ATK2/SCH1/HP6/×1 unique/Masters of Evil/강제난입+부스트★)
- 테마: 데이비드 캐넌 — 몸을 초고속 회전(400rpm)시켜 회오리를 만드는 뮤턴트. 거친 성질 +
  회전 능력 자만 + 손목 톱날. 와스프 집착:
  · enter 5개(거친 성질+회전 자만), attack 5개(회전으로 전부 휩쓸기), defeat 5개(회전 멈춘 최후)
  · vfx.attack = tornadoSpin (회오리 소용돌이 이동 → 대상 위 회전 바람 링 3겹 + 톱날 궤적 →
    휩쓸림 임팩트 + SPIN!)
**검증:** 회오리바람 7종(스탯/unique+트레잇/첫 공격 alsoAttack/강제난입 체인/체인 종료/vfx 참조/
교차검증) ✓ · vfx_index 292건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과(4인 스모크 체인 무한루프 없음) · 2040KB
**연출 인덱스:** +tornadoSpin (하수인 공격 이펙트 8호)
**엔진:** 강제 난입 다중 히어로 공격 체인 (pending.alsoAttack) — 범용
**카드 작업:** 하수인 mcode 순 진행 — 다음 01131 타이거 샤크(tiger-shark, Masters of Evil)
---

## v2026.07.12.140 — 01129 라디오액티브 맨 (강제 반응 손패 버림 + 부스트★ + 대사/이펙트)
**무엇을:**
- ★ 하수인 공격 후 강제 반응(forcedResponse) 발화 시스템 신설: resolveDefensePending 끝
  (피해 적용 후, pending 해제 전)에서 attacker가 minion이고 forcedResponse가 있으면 HANDLERS 호출.
  공식 "After ... attacks you" — 피해 여부 무관. 향후 모든 하수인 공격 후 반응에 재사용.
- 01129 라디오액티브 맨(radioactive-man) 등록:
  · ★강제 반응 fr_radioactiveMan — 공격 후 대상 플레이어 손패 무작위 1장 버림
  · ★부스트 discardBooster(EFFECTS) — 부스트로 뽑히면 그 플레이어 손패 무작위 1장 버림
    (resolveBoostStar의 boostStarEffect 경로, target 미지정으로 player 대상 지원하도록 조정)
  · 공식 JSON 교차검증(ATK1/SCH1/HP7/×1 unique/Elite+Masters of Evil/강제반응+부스트★)
- 테마: 첸 루 — 방사능 실험으로 초인이 된 오만한 중국 핵물리학자(마스터즈 오브 이블 창립 멤버).
  힘 과시 + 방사능 오염(손패 버림=카드 오염) + 초록빛 발광:
  · enter 5개(방사능 과시+과학자 오만), attack 5개(방사능 블래스트), defeat 5개(냉각되어 반응 멈춤)
  · vfx.attack = radiationBlast (초록빛 충전 → 방사능 광선+입자 방출 → 대상 오염 맥동 + ☢ 기호 +
    RADIATION!)
**검증:** 라디오액티브 맨 7종(스탯/unique+트레잇/공격 후 손패 버림/공격 힌트/부스트★ 손패 버림/
vfx 참조/교차검증) ✓ · vfx_index 288건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과 · 2032KB
**연출 인덱스:** +radiationBlast (하수인 공격 이펙트 7호)
**엔진:** 하수인 공격 후 forcedResponse 발화 (resolveDefensePending) — 범용
**카드 작업:** 하수인 mcode 순 진행 — 다음 01130 회오리바람(whirlwind, Masters of Evil, 각 히어로 공격)
---

## v2026.07.12.139 — 01121 무기 밀매상 (Surge + 부스트★ 전장 배치 시스템 + 대사/이펙트)
**무엇을:**
- ★ 부스트★(boost_star) 효과 시스템 신설: 그동안 부스트 카드의 ★ 효과가 문서화만 되고
  실제 미발동이었음(부스트 카드는 그냥 버려짐). resolveBoostStar 헬퍼 신설:
  · boostStarPutIntoPlay(minion): 부스트로 뽑힌 하수인을 그 플레이어와 교전 상태로 전장 배치
    (버리지 않음) — 무기 밀매상. status.tough 초기화 + minionJustEntered + revealLog 기록
  · boostStarEffect(효과명): EFFECTS 파이프라인 실행 (im-tough=toughEnemy 등, 이제 실제 발동)
  · 두 부스트 공개 지점(방어 해소 resolveDefensePending / 스킴 암약)에서 공통 호출.
    전장 배치되면 encounterDiscard 버림 스킵
- 01121 무기 밀매상(weapons-runner) 등록: surge:true(공개 시 추가 조우 1장 — revealPending이
  처리) + boostStarPutIntoPlay + vfx.attack. 공식 JSON 교차검증(ATK1/SCH1/HP2/Surge/부스트★/
  Mercenary/×2, Klaw 조우셋)
- 테마: 클로 조직에 무기를 조달·밀매하는 용병 러너(장사꾼 기질 + 물량 자신감):
  · enter 5개(밀매 장사꾼+물량 자신감), attack 5개(밀수 무기 투척), defeat 5개(재고는 남았다는 최후)
  · vfx.attack = weaponSmuggle (밀수 상자 열림 → 무기 아이콘 회전 투척 → 명중 임팩트 + CRATE!)
- test_index KNOWN_META에 boostStarPutIntoPlay 추가
**검증:** 무기 밀매상 8종(스탯/Surge/트레잇/부스트★ 전장배치/engagedWith/공격 힌트/vfx 참조/
교차검증) ✓ · vfx_index 284건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과(im-tough boostStar 실발동 포함) · 2025KB
**연출 인덱스:** +weaponSmuggle (하수인 공격 이펙트 6호)
**엔진:** resolveBoostStar (부스트★ 효과 범용 시스템 — 전장 배치 + 효과 발동)
**카드 작업:** 하수인 mcode 순 진행 — 다음 01129 라디오액티브 맨(radioactive-man, Masters of Evil)
---

## v2026.07.12.138 — 01120 무장 경호원 (Guard+Toughness 기등록 + 대사/이펙트)
**무엇을:**
- 01120 무장 경호원(armored-guard) 대사·이펙트 등록: Guard+Toughness는 v132 일괄 감사에서
  이미 등록됨 — 이번엔 vfx.attack + 대사만. 공식 JSON 교차검증(ATK1/SCH0/HP3/Guard+Toughness/
  Mercenary/×3, Klaw 조우셋)
- 웹 검색으로 테마 파악 — 클로(Ulysses Klaw, 비브라늄 무기 밀매업자)의 범죄 조직을 지키는
  고용된 중장갑 용병 경호원(gang of hired thugs). Mercenary 트레잇 + Guard/Toughness(중장갑으로
  버티는 방어형):
  · enter 5개(돈 받고 보스 지키는 직업의식+방어 자신감), attack 5개(방패 밀치기),
    defeat 5개(장갑 뚫린 최후, 보수는 선불이라 다행)
  · vfx.attack = armorSlam (금속 방패 돌진 → 육중한 충돌 충격파 + 금속 광택 → 금속 파편·불꽃 +
    CLANG! + 화면 진동)
**검증:** 무장 경호원 6종(스탯/Guard+Tough 반영/트레잇/공격 힌트/vfx 참조/교차검증) ✓ ·
vfx_index 280건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과 · 2018KB
**연출 인덱스:** +armorSlam (하수인 공격 이펙트 5호)
**카드 작업:** 하수인 mcode 순 진행 — 다음 01121 무기 밀매상(weapons-runner, Surge 하수인)
---

## v2026.07.12.137 — 01110 하이드라 폭파범 + 조우 카드 공개 선택(revealChoice) 시스템
**무엇을:**
- ★ 조우 카드 공개 시 플레이어 선택 시스템 신설 (하이드라 폭파범 "피해 2 받기 OR 위협 +1"):
  · 엔진: whenRevealed 핸들러가 G.pending={kind:'revealChoice', options:[{key,label,effects}]}를
    세워 공개 루프 정지. minion 등장부에서 revealChoice 감지 시 vq에 reveal 되돌리고 return
    (quickstrike 패턴 재사용). 해소 액션 resolveRevealChoice(선택 옵션 effects 실행 + pending 해제)
  · UI: revealChoice pending을 pending-zone에 선택 버튼으로 렌더. UI.revealChoice(option)이
    act 디스패치 → 피해 선택 시 하수인 vfx.attack(폭탄)을 교전 플레이어 위에 재생.
    pending 해소 후 act 훅이 maybeStepVillain으로 빌런 페이즈 자동 재개
  · 봇: test_smoke/test_phase1 autoPlay가 revealChoice pending을 랜덤 선택지로 처리 (무한루프 방지)
- 01110 하이드라 폭파범(hydra-bomber) 등록: whenRevealed rev_hydraBomber (선택형).
  공식 JSON 교차검증(ATK1/SCH1/HP2/Hydra/×2/부스트1/선택 피해2 or 위협+1)
- 테마: 하이드라 광신(하일 하이드라, 머리 자르면 둘) + 자폭도 불사하는 폭탄병:
  · enter 5개(광신+폭탄 위협), attack 5개(폭탄 투척), defeat 5개(폭탄과 함께한 최후)
  · vfx.attack = hydraBomb (폭탄 투척 → 대폭발 화염구 + 충격 링 → 파편·불꽃 비산 + BOOM! + 강진동)
**검증:** 폭파범 9종(스탯/트레잇/revealChoice 생성/선택지 2개/피해 선택 2피해/pending 해제/
위협 선택 +1/vfx 참조/교차검증) ✓ · vfx_index 276건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과(봇 갱신 포함) · 2013KB
**연출 인덱스:** +hydraBomb (하수인 공격 이펙트 4호)
**엔진:** revealChoice pending + resolveRevealChoice 액션 (조우 카드 공개 선택 범용 시스템)
**카드 작업:** 하수인 mcode 순 진행 — 다음 01120 무장 경호원(armored-guard, Guard+Toughness
이미 등록됨 — 대사/이펙트만)
---

## v2026.07.12.136 — 하수인 등장 피해(whenRevealed 각 히어로 피해)에도 이펙트 배선
**무엇을:**
- ★ 문 요청: 하수인 등장 효과로 각 히어로에게 피해를 줄 때(쇼커 공개 시 등)도 이펙트 재생.
  기존엔 fxMinionAttack(공격)만 이펙트가 있고 whenRevealed 피해엔 연출이 없었음.
- ★ 엔진: EFFECTS.damageEachHero가 실행 시 G.fxDamageEachHero 힌트 남김
  (defCode/amount/targetUids[피격 히어로 uid들]/seq). 범용 — 이 effect를 쓰는 모든 카드에 적용.
- ★ UI: damageEachHeroSeq diff 감지 → 각 피격 히어로 위에 이펙트 재생.
  · 하수인이면 그 하수인의 vfx.attack(공격 이펙트, 예 쇼커=vibroShock)을 대상 중심에 재생
  · 하수인 아니거나 vfx 없으면 범용 impactHit 폴백
  · 공개 모달이 떠 있으면(revealShowing/revealQueue) 모달 닫힌 뒤 재생되도록 지연(900ms),
    없으면 200ms. 대상별 160ms 스태거로 순차 타격감
- ★ VFX 신설: impactHit — 범용 피격 연출(POW! 버스트 + 임팩트 링 + 대상 흔들림 + 붉은
  플래시 + 화면 진동). 캐릭터 전용 이펙트 없을 때 폴백으로 광범위 재사용
**검증:** 각 히어로 피해 힌트 6종(힌트 생성/defCode/피격 uid 2명/amount/seq/하수인 vfx 참조) ✓ ·
쇼커 기존 6종 유지 · vfx_index 272건 · 회귀 전체 통과 · 2005KB
**연출 인덱스:** +impactHit (범용 피격 폴백)
**시스템:** 하수인 등장 피해 이펙트 — damageEachHero effect를 쓰는 모든 카드에 자동 적용
**카드 작업:** 하수인 mcode 순 진행 — 다음 01110 하이드라 폭파범(hydra-bomber)
---

## v2026.07.12.135 — 01103 쇼커 (whenRevealed 각 히어로 피해 + 진동 공격 이펙트/대사)
**무엇을:**
- 01103 쇼커(shocker) 대사·이펙트 등록: 능력(whenRevealed rev_shocker=각 히어로 1피해)은
  기존 완비. unique 플래그 + vfx.attack 추가. 공식 JSON 교차검증(ATK2/SCH1/HP3/×1 unique/
  부스트2/Criminal/공개 시 각 히어로 1피해)
- 웹 검색으로 테마 파악 — 허먼 슐츠: 독학 엔지니어, 진동 충격 건틀릿(vibro-shock)으로
  벽·금고를 부수는 진동 펀치. 복수/광기 아닌 "돈이 목적"인 실용적 크룩 + 자기 능력 과대평가
  하는 자뻑. 카드 플레이버 "날 보고 충격받았나?"(I bet you're shocked to see me!):
  · enter 5개(능글맞은 자뻑+돈 목적), attack 5개(진동 펀치), defeat 5개(장비 탓하는 크룩)
  · vfx.attack = vibroShock (건틀릿 발사 섬광 → 동심원 진동 충격 링 4겹 대상으로 확산 →
    대상 고속 진동 흔들림 + BZZZT! + 화면 진동)
**검증:** 쇼커 6종(스탯/unique/whenRevealed 2인 각 1피해/공격 힌트/vfx 참조/교차검증) ✓ ·
vfx_index 272건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과 · 2002KB
**연출 인덱스:** +vibroShock (하수인 공격 이펙트 3호)
**카드 작업:** 하수인 mcode 순 진행 — 다음 01110 하이드라 폭파범(hydra-bomber), 이후 01120
무장 경호원(armored-guard, 이미 Guard+Toughness 등록됨 — 대사/이펙트만)
---

## v2026.07.12.134 — 01102 샌드맨 (Toughness 하수인 + 모래 공격 이펙트/대사)
**무엇을:**
- 01102 샌드맨(sandman) 등록: Toughness 키워드 (강인 상태 카드 갖고 등장 → makeInstance가
  status.tough 부여). Criminal+Elite 트레잇, unique, 순수 스탯 ATK3/SCH2/HP4. 특수 능력 없음.
  공식 JSON 교차검증(Toughness/×1 unique/부스트2/Criminal+Elite)
- 웹 검색으로 테마 파악 — 플린트 마르코: 거친 뒷골목 출신 직업 범죄자, 모래로 변신하는
  파워하우스 브롤러. 카드 플레이버 "난 그냥 돈만 받으면 돼!"(I just wanna get paid!)에 맞춰
  돈에 집착하는 브롤러 톤. 총알이 통과하는 불사신 몸(Toughness와 연결), 모래주먹·모래폭풍:
  · enter 5개(돈 집착+범죄자의 씁쓸함), attack 5개(모래주먹 브롤링), defeat 5개(흩어지는 모래)
  · vfx.attack = sandBlast (모래 입자 분출 → 거대 모래주먹이 대상으로 뻗음 → 모래폭풍 작렬 +
    WHUMP! + 화면 진동)
**검증:** 샌드맨 9종(스탯/강인 등장/unique/트레잇/강인 첫 흡수/소진 후 정상피해/공격 힌트/vfx
참조/교차검증) ✓ · vfx_index 268건 · 랜덤 5/5×3 ✓ · 회귀 전체 통과 · 1997KB
**연출 인덱스:** +sandBlast (하수인 공격 이펙트 2호)
**카드 작업:** 하수인 mcode 순 진행 — 다음 01103 쇼커(shocker), 이후 01110 하이드라 폭파범
---

## v2026.07.12.133 — 하수인 대사·공격 이펙트 범용 시스템 + 01101 하이드라 용병 첫 적용
**무엇을:**
- ★ 하수인(minion)도 빌런처럼 연출·대사 세트 구축 (문 요구 사양):
  각 하수인마다 등장(enter)/공격(attack)/패배(defeat) 대사 5개씩 + 공격 전용 이펙트.
  하수인은 defCode 자체를 대사 키로 사용 (빌런의 quoteKey 필드 방식과 구분).
- ★ 범용 배선 3트리거:
  · 등장: 공개 모달(revealModalHTML)에 minion이면 enter 대사 버블(.rvm-quote) 표시
  · 공격: 엔진 enemyActivation의 pending 생성 시 G.fxMinionAttack 힌트(defCode/attacker/
    target/seq) → UI act훅이 seq diff 감지 → vfx.attack 연출 + attack 대사. 빌런은 미생성
  · 패배: K.O. diff에서 minion이면 defeat 대사(speechBubbleAt — 사라진 대상 rect 기반)
- ★ VFX 헬퍼 신설: hasQuote(key,kind) — 대사 존재 확인 / speechBubbleAt(rect,text) —
    DOM 없는 좌표에 말풍선 (K.O.된 하수인용). 둘 다 MC.으로 export
- ★ test_vfx_index 확장: minion defCode를 키로 갖는 QUOTES는 enter/attack/defeat 각 5개
    강제 검증 (하수인 대사 관례 자동 감시)
- 01101 하이드라 용병 첫 적용 (웹 검색으로 테마 파악 — 하이드라=S.H.I.E.L.D.의 라이벌
  테러조직, "하일 하이드라!", "머리 하나 자르면 둘이 돋아난다" 광신 + 용병의 냉소):
  · enter 5개(광신도+돈 받은 냉소), attack 5개(연사), defeat 5개(죽어도 조직 충성)
  · vfx.attack = hydraGunfire (머즐 플래시 4연사 + 예광탄 궤적 + 탄착 스파크 + RATATAT!)
**검증:** 하수인 힌트 5종(fxMinionAttack 생성/attacker·target/seq/빌런 미생성/vfx 참조) ✓ ·
대사 세트 검증(vfx_index 264건, enter/attack/defeat 5개 규칙) ✓ · 랜덤 커버리지 5/5×3 ✓ ·
회귀 전체 통과(재생 결정성 엄격 일치) · 빌드 grep 7종 ✓ · 1992KB
**연출 인덱스:** +hydraGunfire (하수인 공격 이펙트 1호)
**시스템:** 하수인 대사(enter/attack/defeat) + 공격 이펙트 범용 트리거 — 이후 모든 하수인 재사용
**카드 작업:** 하수인 mcode 순 대사/이펙트 진행 — 다음 01102 샌드맨(sandman, Toughness),
이후 01103 쇼커, 01110 하이드라 폭파범 ...
---

## v2026.07.12.132 — 01101 하이드라 용병 + 가드 하수인 키워드 플래그 일괄 감사(27장)
**무엇을:**
- 01101 하이드라 용병(hydra-mercenary) 등록: Guard 키워드만 (특수 능력·연출 없는 순수
  하수인 ATK1/SCH0/HP3). 공식 JSON 교차검증(Guard/Hydra/×2/부스트1)
- ★ 이 카드가 시스템 결함 노출: hasGuardEngaged/hasPatrolEngaged 등 키워드 로직은
  완비돼 있으나, 등록된 가드 하수인 18장에 guard/patrol/retaliate/toughness/quickstrike
  플래그가 DB에 누락 → 실제로 가드가 무력화(플레이어가 하수인 무시하고 빌런 직접 공격
  가능, 룰 위반). 과거 S.H.I.E.L.D. 트레잇 25장 일괄 수정과 동일한 데이터 정합성 문제
- ★ 일괄 감사 — 각 카드 공식 textKo(공식 대조 번역) authoritative로 정확한 플래그 부여:
  · 1차 18장: guard 전부 + servant-bot/enraged-symbiote(patrol) +
    yotat/sir-raston(retaliate1) + the-sleeper(retaliate1+toughness) +
    armored-guard(toughness) + kree-lieutenant(stalwart) + lady-deathstrike(quickstrike만
    — Guard는 "심장 도려낼" 오탐이라 제외)
  · 2차 전수 재조사 9장: badoon-lieutenant/kree-commando(patrol) +
    badoon-sentry/omega-red/mister-knife/whiplash(retaliate1) +
    nebula-nemesis/modok(retaliate2) + proxima-midnight-minion(piercing)
  · 오탐 제외: ebony-maw(설명 예시), yellowjacket(폼 조건부 retaliate — 상시 아님),
    proxima의 retaliate(Corvus 설명 예시 — 자기 능력은 piercing)
- ★ 엔진: 미니언 공격 applyDamage에 piercing 전달 누락 수정. 공격 개시 시 enemy.piercing을
  pending에 기록 → resolveDefensePending 3경로(무방어/신분방어/동료방어) applyDamage에
  piercing:pierce 전달. 관통은 강인 무시(프록시마 미드나이트). 과잉살상+관통 동시 시 강인
  방어자여도 초과 피해 발생하도록 조건 보정
- ★ 봇 갱신: test_phase1 autoPlay가 Guard 교전 시 하수인부터 타격하도록 수정
  (실제 가드 작동으로 빌런 직접 공격이 차단되므로)
**검증:** 용병 6종 + 가드 감사 6종(11장 정합/오탐 2건 제외/인스턴스 반영/piercing 강인
무시/전수 재조사 잔여 0) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치) · 연출 260건 · 1984KB
**활성 키워드 하수인:** guard 20 / patrol 4 / retaliate 10 / toughness 9 / quickstrike 3
**엔진:** 미니언 공격 piercing 전달 / hasPatrolEngaged(v131)
**원칙 확립:** 하수인 등록 시 키워드 플래그(guard/patrol/retaliate/toughness/quickstrike/
stalwart/piercing)를 공식 textKo 기준으로 반드시 부여 — 로직만 있고 플래그 누락 시 무력화됨
**카드 작업:** 다음 라이노 조우 카드 — 01102 샌드맨(sandman, Toughness 하수인)
---

## v2026.07.12.131 — 저지 대상 지정 시스템 + 01100 강화된 상아 뿔 (문 지적 반영)
**무엇을:**
- ★ 문 지적: "저지가 왜 타겟을 못 해? 사이드스킴도 저지 가능해야 하고 위협바 필요"
  → 엔진은 a.scheme/targetScheme을 이미 받았으나 UI가 'main' 하드코딩 + playCard ctx에
  targetScheme 누락이 원인. 전면 수정:
  · UI 범용 스킴 선택 모드(sel.mode='schemePick', purpose=basicThwart/allyThwart/event):
    사이드스킴 존재 시 기본 저지/동료 저지/저지 이벤트가 대상 선택 진입 → 메인 스트립 또는
    사이드스킴 슬롯 탭으로 확정. 금색 펄스 하이라이트(.scheme-pickable) + 취소 배너.
    저지 버튼 재탭=취소. 사이드스킴 없으면 기존처럼 메인 즉시.
  · playCard ctx에 targetScheme 추가 → removeThreat 이벤트(정의를 위해! 등) 대상 지정 가능
- ★ 사이드스킴 위협바: 배지 숫자 → comicBar(mini)로 교체. 분모=peakThreat(엔진이
  placeThreat에서 역대 최대 위협 추적, 생성 시 초기화). barSnapshot에 threat:{uid} 키
  추가로 FLIP 부드러운 전환. "남은 저지량"이 바로 보임
- ★ 룰 정정 — 가드/순찰 분리: 가드(Guard)는 "빌런 공격 불가"만 제한하는데 기존 엔진이
  메인 스킴 저지까지 차단(오류). basicThwart/allyThwart의 검사를 hasPatrolEngaged(신설)로
  교체 — 순찰(Patrol) 하수인 교전 시에만 메인 저지 차단. test_phase1 구 단언도 공식 룰로 갱신
- 01100 강화된 상아 뿔(horn-attack) 등록: attachStats ATK+1 + activatedAbility
  (form:hero, payCost 💪×3, special:hornRemove → detach+조우버림+fxAttachSpent 힌트).
  공식 JSON 교차검증(attack 1/boost 2/Weapon/×1). textKo 구버전 시뮬 노트 정리
- ★ 엔진: useCardAbility가 빌런 부착물도 탐색 (조우 부착물의 히어로 행동 범용화)
- ★ UI: findAbilityCardUI 헬퍼(플레이영역+빌런 부착물) — useCardAbility/_fireCardAbility/
  payConfirm(abilityPay 부착물 조회 크래시 수정) 3곳 적용. attachChips에 조우 부착물
  히어로 행동 버튼(🔧 제거, 자원 힌트, 멀티플레이 시 플레이어별) 추가
- QUOTES 'horn-attack': attach 5개(티타늄뿔 자랑), spent 5개(뿔 뽑힌 분노)
- 연출: hornGrow(상아 뿔 2단 솟구침+광택 스윕+SHARPENED!), hornRip(저항 진동+뿔 뽑혀
  회전 낙하+파편+RIPPED OFF!)
**검증:** 저지 대상 테스트 7종(사이드 저지/peak 유지/가드 저지 허용/순찰 차단/순찰 중
사이드 허용/이벤트 targetScheme/peak 상승) ✓ · 상아 뿔 테스트 6종(ATK+1/알터에고 불가/
💪×3 제거/ATK 원복/fx 힌트/교차검증) ✓ · 랜덤 대사 5/5 ✓ · 회귀 전체 통과(재생 결정성
엄격 일치, test_phase1 룰 갱신 포함) · 연출 참조 260건 미등록 0 · 빌드 grep 7종 ✓ · 1980KB
**연출 인덱스:** +hornGrow +hornRip
**엔진:** targetScheme(playCard) / peakThreat / hasPatrolEngaged / 부착물 activatedAbility
**카드 작업:** 다음 라이노 조우 카드 — 01101 하이드라 용병(hydra-mercenary, Guard 하수인)
---

## v2026.07.12.130 — 01099 돌진 (빌런 공격 강화 부착 + 빌런측 과잉살상 신설)
**무엇을:**
- ★ 공식(core_encounter.json 01099): attachment/조우/부스트2/attack 3(star)/×2.
  "라이노 부착. 강제 개입: 라이노 공격 시 과잉살상. 공격 종료 후 버림." DB textKo 정확
- ★ 엔진 신설 3종 (정의 전용 필드 — test_index 화이트리스트 등록):
  · attachStats: 부착 시 대상 스탯 보정(ATK+3), attachTo 적용 → detachFrom 원복.
    적용량을 inst.appliedStats에 기록해 정의 변경과 무관하게 정확 원복.
    releaseAttachments는 대상 격파라 원복 생략 + appliedStats 정리(재공개 오염 방지)
  · grantOverkillOnAttack: enemyActivation에서 부착물 스캔 → pending.overkill 세팅
  · discardAfterAttack: pending.discardAfterAttack에 uid 예약 →
    resolveDefensePending 말미에 detach+조우버림+G.fxAttachSpent 힌트(seq 카운터)
- ★ 빌런측 과잉살상 신설: 동료 방어 시 초과 피해(total - 동료HP) → 그 동료의 컨트롤러.
  강인 동료는 피해 자체가 무효라 초과 없음 (공식 룰 준수, 테스트 검증)
- QUOTES 'charge': attach 5개(하하막아봐라(flavor 계승)/길을비켜라/돌진이다/내뿔앞에서/
  발굽이근질), spent 5개(후우맛보기다/기세가빠졌군/벌써끝났나/한번더/라이노는안끝났다)
- 연출: chargeAttach(발구르기 흙먼지 2회 스텀프 + 카드 움츠림→돌진 + 붉은 속도선 5줄 +
  CHARGE! + 기세 오라), chargeSpent(잔먼지 7개 소산 + 숨고르기 기울임 + 오라 페이드)
- ★ UI: G.fxAttachSpent 범용 소비 (defCode의 vfx.spent + quoteKey 'spent' 대사 —
  seq 비교로 중복 재생 방지. charge ×2장 연속 소모도 각각 재생됨)
**검증:** 돌진 테스트 9종(ATK+3 / 과잉살상 부여 / 버림 예약 / 동료 초과 3→컨트롤러 /
조우 버림 / ATK 원복 / fx 힌트 / 강인 초과 없음 / 데이터 교차검증) ✓ · 랜덤 대사
커버리지 attach·spent 각 5/5 ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 참조 257건 미등록 0 · 빌드 grep ✓ · 용량 1968KB
**연출 인덱스:** +chargeAttach +chargeSpent
**엔진:** attachStats / grantOverkillOnAttack / discardAfterAttack / 빌런측 과잉살상
**카드 작업:** 다음 라이노 조우 카드 — 01100 지진 강타(ground stomp 계열) 등 번호순
---

## v2026.07.10.129 — 01098 장갑 라이노 슈트 (부착 방어 갑옷 + 전용 대사/연출)
**무엇을:**
- ★ 공식(core_encounter.json 01098): attachment/Armor/조우. "라이노 부착. 강제 인터럽트:
  라이노 피해를 대신 여기 놓음. 5 이상 쌓이면 슈트 버림." DB textKo 정확(정정 불필요)
- 피해 흡수 로직은 이미 applyDamage(mc_6_keywords.js)에 완비 — rhino-suit 부착 시 피해
  누적, 5 이상이면 파괴+encounterDiscard, G.fxSuitBreak VFX 힌트, 본체 무피해. 이번엔 연출·대사 배선
- ★ 문 지시: 부착 시 전용 대사 5개 + 대사는 전부 랜덤 재생(Math.random 확인)
- QUOTES 'rhino-suit' 추가: attach(부착) 5개[이갑옷을뚫겠다고/티타늄장갑/아무리때려봐라/
  이슈트안에서무적/폭탄이든총알이든], suitBreak(파괴) 5개[내갑옷이부서졌다고/티타늄이갈라지다니/
  갑옷이벗겨졌어/무적의슈트를/갑옷없어도라이노는강하다]
- 연출: suitArmor(부착 — 회색 금속판 사방에서 체결+광택 스윕+볼트🔩+"ARMORED!"+부착 대사),
  suitBreak(파괴 — 금속 파편 튀김+"SUIT BROKEN!"+파괴 대사)
- ★ 엔진/UI: 부착물 신규 등장 감지(collectAttachments) → 전용 install 연출+attach 대사 트리거.
  G.fxSuitBreak 힌트 감지 → suitBreak 연출+대사 (suitBreakShown 1회 플래그)
- ★ rhino-suit fx는 db 카드라 mc_cards_fx.js에서 defineCardFx (seed 아님, 순서문제 없음).
  단 IIFE 안쪽 배치 주의(밖에 두면 MC undefined)
- ★ test_vfx_index 규칙 조정: 빌런 핵심 대사(등장/페이즈/패배)는 최소 10개, 부착 등
  보조 대사(attach/suitBreak)는 최소 5개
**검증:** rhino-suit 테스트(피해 3 흡수/5 누적 파괴/부착목록 제거/fxSuitBreak 힌트/fx등록) 통과 ·
랜덤 재생 확인(30회 중 5종 전부) · 회귀 전체 통과 · 연출 참조 254건 · 빌드 grep · 용량 1956KB
**연출 인덱스:** +suitArmor +suitBreak
**카드 작업:** 다음 라이노 조우 카드 — 01099 돌진(charge, attachment)
---

## v2026.07.10.128 — 라이노 전용 단계전환·패배 연출 (빌런 연출 템플릿 확립)
**무엇을:**
- ★ 문 지시: 모든 빌런은 대사 3종(등장/페이즈변화/패배 각 10개) + 전용 애니메이션
  4종(등장/페이즈전환/패배이미지/공격)을 갖춰야 함 (메모리 등록 완료)
- ★ 라이노 검증 결과: 대사 3종(등장10/stageUp10/defeat15) 완비, 등장(wallBreak)·
  공격(headbutt) 완비. 부족했던 단계전환·패배 전용 연출을 이번에 제작
- ★ 웹 리서치: 라이노 = 회색 코뿔소 갑옷 + 티타늄 뿔 + 돌진 + 감마 방사선 강화 + 막무가내 브루트
- rhinoRampage(단계 전환 전용): 감마 에너지로 갑옷 부풀기 + 초록 방사선 소용돌이 +
  거대한 뿔 솟구침 + 감마 폭발 링 + 강진동 + "RAMPAGE!" (코믹스풍 과장)
- rhinoCollapse(패배 전용): 흰 섬광 → 회색 갑옷 파편 18개 사방 폭발 → 부러진 뿔 회전
  낙하 → "DEFEATED" 대형 슬램 + 강진동
- ★ 엔진: 빌런 정의 vfx.stageChange/vfx.defeat 필드 신설. UI가 단계전환·최종패배 시
  빌런 전용 연출 우선 재생(없으면 공용 stageChange/villainDefeat). villainSnap에 defCode 추가
- ★ 라이노 3단계 vfx: entrance=wallBreak, enemyAttack=headbutt, stageChange=rhinoRampage,
  defeat=rhinoCollapse. 이 패턴이 이후 모든 빌런 연출 템플릿
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 카드 기능 테스트 전체 통과 ·
연출 참조 252건 미등록 0 · 빌드 grep ✓ · 용량 1950KB
**연출 인덱스:** +rhinoRampage +rhinoCollapse
**★ 라이노 빌런 연출·대사 완비:** 등장/페이즈전환/패배/공격 애니메이션 + 대사 3종 전부
**카드 작업:** 다음 라이노 조우 카드 — 01098 장갑 라이노 슈트(rhino-suit, attachment)
---

## v2026.07.10.127 — 라이노 세트 빌런 3단계 능력 (라이노 세트 진입)
**무엇을:**
- ★ 코어셋 어스팩트 전부 완료 후 라이노 세트 진입 (문 지시: 라이노부터 순차)
- ★ 교차검증(core_encounter.json 신규 확보 — GitHub raw): 라이노 HP 14/15/16(영웅당),
  ATK 2/3/4, SCH 1 확정. seed 데이터 완전 일치. 메인스킴 01097b: 위협0시작/영웅당7/가속1 일치
- 라이노 빌런 3단계 능력 등록:
  · 1단계(01094): 특수 없음 (순수 스탯, 이미 완성)
  · 2단계(01095): whenRevealed → 침입&약탈 사이드스킴 공개 + 조우덱 셔플
  · 3단계(01096): whenRevealed → Toughness(tough) + 각 히어로 기절(stun)
- ★ 엔진: advanceVillainStage에서 새 단계 whenRevealed 발화 신설. 사이드스킴 특정
  공개 헬퍼(revealSpecificSideScheme — 조우덱/버림/신규생성 탐색)
- ★ reassemble 순서 이슈 해결: mc_cards_fx.js(f)가 seed(s)보다 먼저 로드돼 seed 카드
  (라이노 01095/096) defineCardFx 시 "미등록" 에러. → 라이노 fx를 mc_cards_zzrhino_fx.js
  (z 접두 지연 로드)로 분리하여 seed 이후 로드되도록 해결
**검증:** 라이노 테스트(1단계 스탯 / 2단계 사이드스킴 공개 / 3단계 tough+전체기절 /
메인스킴 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조
247건 미등록 0 · 빌드 grep ✓ · 용량 1942KB
**엔진:** 단계 전환 whenRevealed 발화 + revealSpecificSideScheme
**카드 작업:** 다음 라이노 조우 카드 순차 — 01098 장갑 라이노 슈트(rhino-suit, attachment)
---

## v2026.07.10.126 — 기본 어스팩트 01093 끈기 (기본 어스팩트 완료)
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답 (정정 불필요).
  cost 2 / upgrade / Condition / deckLimit 3 (Core Set #93). 공식 flavor 없음
- 끈기(tenacity) 등록: activatedAbility(form:hero + payCost:physical + special:
  tenacityReady) → 피지컬 지불 + 자신 버림 → 히어로 준비. 불굴의 정신과 유사(방어
  조건 대신 자원 지불)
- ★ 플레이버: 굴하지 않는 의지 (공식 flavor 없음 — 자체 창작)
- 연출: combatInstall(재기/재정비)
**검증:** 끈기 테스트 5종(히어로 준비 / 자신 버림 / 피지컬 없이 발동 불가 / 알터에고
발동 불가 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출
참조 247건 미등록 0 · 빌드 grep ✓ · 용량 1938KB
**★ 기본 어스팩트 완료:** 01083~01093 전부 (모킹버드/닉퓨리/비상사태/응급처치/강타/
자원3종/어벤져스맨션/헬리캐리어/끈기)
**★ 코어셋 4어스팩트 + 기본 전부 완료:** 공격(01050~57)/정의(01058~65)/리더십
(01066~74)/보호(01075~82)/기본(01083~93)
**카드 작업:** 다음 = 라이노 세트 빌런/조우 카드 (01094~) 또는 나머지 영웅 신분/시그니처
---

## v2026.07.10.125 — 어스팩트 색상 설치 오라 연출
**무엇을:**
- ★ 문 질문: 어스팩트 카드 설치 애니메이션 있는지 → 있음(vfx.install 트리거, DEPLOY!/
  EQUIP! 라벨). 다만 tacticsInstall/combatInstall로 몰려 어스팩트 정체성 약했음
- ★ aspectAura 연출 신설: 어스팩트 색상으로 카드를 감싸는 확산 링 + 아이콘 배지 +
  색상 글로우. 마블 챔피언스 4어스팩트 색상 매핑:
  · 공격(Aggression)=빨강 ⚔ · 정의(Justice)=노랑 ⚖ · 리더십(Leadership)=파랑 ★
  · 보호(Protection)=초록 🛡 · 기본(Basic)=회색 ◆
- ★ 설치 트리거에 어스팩트 감지 추가 — 기존 install 연출과 함께 aspectAura 재생.
  카드 def.aspect 필드 활용. 서포트/업그레이드가 어느 어스팩트인지 즉시 각인
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 카드 기능 테스트 전체 통과 ·
연출 참조 245건 미등록 0 · 빌드 grep ✓ · 용량 1936KB
**연출 인덱스:** +aspectAura (어스팩트 색상 오라)
**카드 작업:** 다음 코어 mcode 순 — 01093 끈기(tenacity)
---

## v2026.07.10.124 — 기본 어스팩트 01092 헬리캐리어 + 비용 할인 시스템
**무엇을:**
- ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
  줄만 "⚡에너지" 오류 → 💪피지컬 정정. cost 3 / support / Location+S.H.I.E.L.D. (Core #92)
- 헬리캐리어(helicarrier) 등록: activatedAbility(exhaust + special:helicarrierDiscount)
  → 대상 플레이어 다음 카드 비용 -1 (이번 페이즈)
- ★ 엔진: nextCardDiscount 비용 할인 시스템 신설. playCard에서 유효 비용 = max(0,
  cost - discount). 사용 후 소비, 페이즈 종료 시 초기화. useCardAbility targetPlayer
- ★ FAQ: 자원 아님(빌런 페이즈 반응 불가). 팀 협동(다른 플레이어 할인)
- ★ 플레이버: 제니퍼 월터스(쉬헐크) 어이없어하는 반응 ("하늘을 나는 항공모함이라고? 지금 나 놀리는 거지?")
- 연출: 설치=tacticsInstall(헬리캐리어 홀로그램)
**검증:** 헬리캐리어 테스트 6종(할인 예약 / 소진 / Cost3을 자원2로 결제 / 할인 소비 /
첫 카드 후 할인0 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓,
비용 할인 추가 영향 없음) · 연출 참조 245건 미등록 0 · 빌드 grep ✓ · 용량 1933KB
**엔진:** nextCardDiscount 비용 할인 (playCard 유효비용 계산)
**카드 작업:** 다음 코어 mcode 순 — 01093 끈기(tenacity)
---

## v2026.07.10.123 — 기본 어스팩트 01091 어벤져스 맨션
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
  cost 4 / support / Avenger+Location / deckLimit 3 (Core Set #91)
- 어벤져스 맨션(avengers-mansion) 등록: activatedAbility(exhaust + special:
  avengersMansionDraw) → 플레이어 선택 후 1장 드로우. maxPerTarget:1
- ★ 엔진: useCardAbility ctx에 targetPlayer 추가 (멀티플레이 대상 플레이어 드로우).
  매 턴 반복 드로우 엔진 (소진 후 다음 라운드 준비)
- ★ 플레이버: 자넷 밴 다인(와스프) 저택 살림 걱정 위트 ("가스 잠갔어요?")
- 연출: 설치=tacticsInstall(어벤져스 본부 홀로그램)
**검증:** 어벤져스 맨션 테스트 4종(1장 드로우 / 소진 / 소진 재사용 불가 / 데이터
교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 244건 미등록 0 ·
빌드 grep ✓ · 용량 1930KB
**엔진:** useCardAbility targetPlayer 전달
**카드 작업:** 다음 코어 mcode 순 — 01092 헬리캐리어(helicarrier)
---

## v2026.07.10.122 — 기본 어스팩트 01088~01090 자원 카드 3종
**무엇을:**
- ★ 교차검증(공식 JSON): energy=⚡×2 / genius=🧠×2 / strength=💪×2 확정. DB 완전 일치.
  type:resource, deckLimit:1 (Core Set #88~90)
- 에너지/천재/힘(energy/genius/strength) 등록: 빈 fx {} — 특수 효과 없는 순수 자원
  카드. todoFx 해제. 자원은 DB resources 필드로 처리(resourceIconsOf가 읽어 아이콘 제공)
- ★ 참고: 게임에서 이미 자원으로 활용 중(테스트 결제·프리셋 덱)이었으나 fx 등록만
  누락됐던 것. 이제 정식 등록
**검증:** 자원 카드 테스트 6종(⚡/🧠/💪 아이콘 2개 각 / todoFx 해제 / 에너지 1장으로
Cost 2 결제 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 참조 243건 미등록 0 · 카드 미등록 0 · 빌드 grep ✓ · 용량 1929KB
**카드 작업:** 다음 코어 mcode 순 — 01091 어벤져스 맨션(avengers-mansion)
---

## v2026.07.10.121 — 기본 어스팩트 01087 강타
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "💪피지컬" 오류 → ⚡에너지 정정. cost 2 / event / Attack / deckLimit 3 (Core Set #87)
- 강타(haymaker) 등록: playForm:'hero' + effects dealDamage(target:chosen, amount:3,
  isAttack). 심플하지만 효율적 고정 피해 (기본 어스팩트 대표 딜링)
- ★ 엔진: dealDamage 이펙트에 isAttack 옵션 전달 추가 (applyDamage로 forwarding).
  공격 이벤트가 afterAttack 훅 등과 올바르게 상호작용
- ★ 플레이버: 강력한 어퍼컷 타격음 ("콰앙!")
- 연출: aggressionSlash
**검증:** 강타 테스트 4종(빌런 3피해 / 하수인 3피해 / 알터에고 사용 불가 / 데이터
교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓, isAttack 추가 영향 없음) ·
연출 참조 243건 미등록 0 · 빌드 grep ✓ · 용량 1927KB
**엔진:** dealDamage isAttack 옵션 전달
**카드 작업:** 다음 코어 mcode 순 — 01088 에너지 / 01089 천재 / 01090 힘 (기본 자원 카드)
---

## v2026.07.10.120 — 기본 어스팩트 01086 응급처치
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
  cost 1 / event / deckLimit 3 (Core Set #86)
- 응급처치(first-aid) 등록: effects heal(target:chosen, amount:2) — 아무 캐릭터 2 회복.
  의료팀과 유사하나 카운터 없는 단발. 히어로/동료/타 플레이어 동료 모두 대상 가능
- ★ 주의: needsTarget은 이벤트 최상위 baseFields 미등록 필드 (activatedAbility 내부
  전용). 이벤트는 targets로 대상 받음 → needsTarget 제거로 해결
- ★ 플레이버: 클린트 바튼 부상 잦은 호크아이 특유의 능청스러운 자조 유머
  ("입원 이틀째인데도 이걸 응급처치라고 부르는 거 맞아?")
- 연출: healPulse
**검증:** 응급처치 테스트 4종(동료 2회복 / 히어로 2회복 / maxHp 초과 안 함 / 데이터
교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 242건 미등록 0 ·
빌드 grep ✓ · 용량 1926KB
**카드 작업:** 다음 코어 mcode 순 — 01087 강타(haymaker)
---

## v2026.07.10.119 — 기본 어스팩트 01085 비상사태
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "🧠멘탈" 오류 → ⚡에너지 정정. cost 0 / event / Thwart / deckLimit 3 (Core Set #85)
- 비상사태(emergency) 등록: special(emergencyPrevent) → G.preventNextThreat에 1 예약
  → 다음 빌런 스킴 위협 배치 1 감소. 큰 힘에는 큰 책임의 preventNextThreat 재사용
  (히어로 피해 없이 순수 예방)
- ★ FAQ: "난입"이라 알터에고에서도 사용. 배치 방지만(이미 놓인 위협 제거 불가)
- ★ 플레이버: 긴급 무전 콜 ("전 대원 출동! 반복한다, 전 대원 출동!")
- 연출: threatDrain
**검증:** 비상사태 테스트 4종(preventNextThreat 예약 / 위협 3→2 감소 / 이미 놓인
위협 그대로 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 참조 241건 미등록 0 · 빌드 grep ✓ · 용량 1924KB
**카드 작업:** 다음 코어 mcode 순 — 01086 이후 기본 어스팩트 카드
---

## v2026.07.10.118 — 기본 어스팩트 01084 닉 퓨리 (동료) + 3택/라운드종료 버림
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
  cost 4 / ATK 2 / THW 2 / HP 3 / S.H.I.E.L.D.+Spy / unique (Core Set #84)
- 닉 퓨리(nick-fury) 등록: whenPlayed(nickFuryChoice, 3택 1: 위협2제거/드로우3/피해4) +
  endOfRound(nickFuryDiscard, 라운드 종료 시 버림)
- ★ 엔진: playCard ctx에 choice 전달. endOfRound 훅 활용(fireHook allInPlay).
  강력 즉발 효과 + 1회용 동료 패턴
- ★ FAQ: "라운드 끝" ≠ "페이즈 끝" — 빌런 공격 블록 후 버림
- ★ 플레이버: 닉 퓨리 능글맞고 자신만만한 첩보 대가 색깔 강화
  ("난 항상 히든카드를 쥐고 있지. 이번 판도 내가 이겨.")
**검증:** 닉 퓨리 테스트 6종(위협 2제거 / 빌런 4피해 / 드로우 3 / 등장 후 전장 /
라운드 종료 버림 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 참조 240건 미등록 0 · 빌드 grep ✓ · 용량 1923KB
**엔진:** whenPlayed choice + endOfRound 버림 패턴
**카드 작업:** 다음 코어 mcode 순 — 01085 비상사태(emergency)
---

## v2026.07.10.117 — 기본 어스팩트 01083 모킹버드 (동료)
**무엇을:**
- ★ 기본(basic) 어스팩트 진입 (보호 어스팩트 완료 후)
- ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
  줄만 "🧠멘탈" 오류 → 💪피지컬 정정. cost 3 / ATK 1 / THW 1 / HP 3 / S.H.I.E.L.D.+Spy /
  unique (Core Set #83)
- 웹 테마: 바비 모스, S.H.I.E.L.D. 첩보원, 배튼 무술가, 호크아이 파트너
- 모킹버드(mockingbird) 등록: whenPlayed(mockingbirdStun) → 대상 적에게 stun 부여.
  applyStatus/setStatus 재사용. 기본 어스팩트라 모든 히어로 덱 사용 가능
- ★ 플레이버: 모킹버드 첩보원 특유의 시크한 말투 ("정보는 내가 캐낸다. 넌 그냥 조용히 있어.")
- 연출: 설치=combatInstall(첩보/무술 테마)
**검증:** 모킹버드 테스트 4종(빌런 기절 / 전장 등장 / 하수인 기절 / 데이터 교차검증) ✓ ·
회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 238건 미등록 0 · 빌드 grep ✓ ·
용량 1920KB
**카드 작업:** 다음 코어 mcode 순 — 01084 닉 퓨리(nick-fury)
---

## v2026.07.10.116 — 보호 어스팩트 01082 불굴의 정신
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "💪피지컬" 오류 → ⚡에너지 정정. cost 1 / upgrade / Condition / deckLimit 3 (Core #82)
- 불굴의 정신(indomitable) 등록: activatedAbility(playCondition:justDefended +
  special:indomitableReady) → 방어 후 자신 버림 + 히어로 준비(readySelf)
- ★ justDefended 조건(카운터 펀치에서 만든 것) 재사용. 방어→준비→추가 행동 콤보
- ★ 플레이버: 캡틴 아메리카 결연한 불굴의 의지 ("우리에게 선택지는 없다. 그러니 싸운다...")
- 연출: combatInstall(재정비/재기 테마)
**검증:** 불굴의 정신 테스트 4종(히어로 준비 / 자신 버림 / 방어 안 함 시 발동 불가 /
데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 236건
미등록 0 · 빌드 grep ✓ · 용량 1918KB
**카드 작업:** 보호 어스팩트 완료 근접 (01075~01082). 다음 = 기본(basic) 어스팩트
01083 모킹버드(mockingbird)
---

## v2026.07.10.115 — 보호 어스팩트 01081 방탄 조끼
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB {mental:1} 정답, textKo 첫 줄만
  "💪피지컬" 오류 → 🧠멘탈 정정. cost 1 / upgrade / Armor / deckLimit 3 (Core Set #81)
- 방탄 조끼(armored-vest) 등록: statMod(stat:defense, amount:1) — 지속 DEF+1.
  전투 훈련(ATK+1)/히어로의 직감(THW+1)의 DEF 버전. statMod 재사용. maxPerTarget:1
- ★ 플레이버: 실용적이면서 스타일리시한 방어구 ("생명을 지켜주면서 스타일까지 챙긴다.")
- 연출: 설치=combatInstall(갑옷 장착 테마)
**검증:** 방탄 조끼 테스트 3종(DEF+1 statOf / statMod 등록 / 데이터 교차검증) ✓ ·
회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 234건 미등록 0 · 빌드 grep ✓ ·
용량 1916KB
**카드 작업:** 다음 코어 mcode 순 — 01082 불굴의 정신(indomitable)
---

## v2026.07.10.114 — 보호 어스팩트 01080 의료팀
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "💪피지컬" 오류 → ⚡에너지 정정. cost 3 / support / S.H.I.E.L.D. / Uses 3 (Core Set #80)
- 의료팀(med-team) 등록: uses:3 + activatedAbility(exhaust + useCounter:1 + heal
  target:chosen amount:2). 감시팀/전술공격팀과 동일 useCounter 구조 (회복 버전)
- ★ 연출: healPulse 신설 (초록 십자가 + 상승 회복 입자 + "+2 HP", 의료 테마)
- ★ 회복은 maxHp 초과 안 함 (healTarget이 상한 처리)
**검증:** 의료팀 테스트 6종(등장 카운터 3 / 동료 2 회복 / 카운터 감소+소진 / maxHp
초과 안 함 / 3회 후 버림 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격
일치 ✓) · 연출 참조 233건 미등록 0 · 빌드 grep ✓ · 용량 1914KB
**연출 인덱스:** +healPulse
**카드 작업:** 다음 코어 mcode 순 — 01081 방탄 조끼(armored-vest)
---

## v2026.07.10.113 — 보호 어스팩트 01077 카운터 펀치 + 방어 후 반응
**무엇을:**
- ★ 교차검증(공식 JSON): resource_physical 확정. DB 완전 일치 (정정 불필요).
  cost 0 / event / Attack / deckLimit 3 (Core Set #77)
- 카운터 펀치(counter-punch) 등록: playCondition(justDefended) + special(counterPunch)
  → 방금 방어한 적에게 히어로 ATK만큼 피해
- ★ 엔진: resolveDefensePending에 justDefendedAgainst 힌트 신설 (히어로 방어=identity
  시만, 동료 방어 제외). condCheck justDefended. 1회성 소비
- ★ FAQ: Guard 하수인 교전 중 빌런 공격 방어 시 사용 불가
- ★ 플레이버: 아이언 피스트 쿵푸 마스터의 통쾌한 반격 ("이게 바로 대가다!")
- 연출: aggressionSlash (반격 타격)
**검증:** 카운터 펀치 테스트 5종(빌런 ATK 피해 / 플래그 1회성 소비 / 하수인 반격 /
방어 안 함 시 발동 불가 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격
일치 ✓) · 연출 참조 231건 미등록 0 · 빌드 grep ✓ · 용량 1910KB
**엔진:** justDefendedAgainst 힌트 (방어 후 반응)
**카드 작업:** 다음 코어 mcode 순 — (01078 내 뒤로! ✅, 01079 수호의 힘 ✅) → 01080 의료팀
---

## v2026.07.10.112 — 강인(Tough) 지속 배리어 연출
**무엇을:**
- ★ 문 요청: 강인(Tough) 상태 캐릭터에 투명한 배리어가 보호하는 지속 연출.
  차후 강인 여러 개 가진 캐릭터도 대비
- ★ UI: 지속형 tough 배리어(.tough-barrier) 신설 — tough 상태 유지 동안 카드를
  감싸는 투명 방어막. 2.2s 주기로 맥동(barrierPulse) + 3.4s 주기 광택 스윕(barrierGlint).
  기존 일회성 toughGain(획득 순간)과 별개로 "유지 중" 상태를 시각화
- ★ 강인 여러 겹 대비: tough 개수 n≥2면 겹수 배지(.tough-count 🛡N) 좌상단 표시.
  toughBarrier(status) 헬퍼가 개수 받아 처리 (확장팩의 다중 tough 캐릭터 대응)
- 적용: 빌런/하수인/동료/히어로 신분 카드 모두 (cardArt badges로 toughBarrier 추가)
- 효과: 루크 케이지 등 tough 캐릭터가 배리어에 감싸여 맥동 → 피해 받아 tough 소진되면
  배리어 사라짐. 여러 겹이면 개수 배지로 표시
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 카드 기능 테스트 전체 통과 ·
연출 참조 231건 미등록 0 · 빌드 grep ✓ · 용량 1908KB
**UI:** 강인 지속 배리어(맥동+광택) + 다중 강인 겹수 배지
**카드 작업:** 다음 코어 mcode 순 — 01077 카운터 펀치(counter-punch)
---

## v2026.07.10.111 — 보호 어스팩트 01076 루크 케이지 (동료) + Toughness 등장
**무엇을:**
- ★ 보호(protection) 어스팩트 진입 (01075 블랙위도우는 기등록)
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "💪피지컬" 오류 → ⚡에너지 정정. cost 4 / ATK 2 / THW 1 / HP 5 / Defender / unique (Core #76)
- 웹 테마: 파괴 불가 피부의 히어로 포 하이어, 할렘의 수호자. HP 5 최고 체력 탱커
- 루크 케이지(luke-cage) 등록: whenPlayed(lukeCageTough) → 자신에게 tough 상태 부여.
  보호 어스팩트 최초 Toughness 동료. 기존 setStatus(tough) 재사용
- ★ 플레이버: 루크 케이지 히어로 포 하이어 시크한 자기소개 ("돈 받고 뛰는 파워맨—케이지다.")
- 연출: 설치=combatInstall(강인한 방벽 테마)
**검증:** 루크 케이지 테스트 6종(등장 시 tough 1 / HP 5 / tough 3피해 무효화 / tough
소진 / 소진 후 정상 피해 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격
일치 ✓) · 연출 참조 231건 미등록 0 · 빌드 grep ✓ · 용량 1906KB
**카드 작업:** 다음 코어 mcode 순 — 01077 카운터 펀치(counter-punch, 보호)
---

## v2026.07.10.110 — 리더십 어스팩트 01074 감화
**무엇을:**
- ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
  줄만 "🧠멘탈" 오류 → 💪피지컬 정정. cost 1 / upgrade / Condition (Core Set #74)
- 감화(inspired) 등록: attachTarget:'ally' + whenPlayed(inspiredAttach) → 부착 동료
  ATK+1/THW+1. maxPerTarget:1. 격분(enraged)과 유사하나 부수 피해 없는 순수 강화
- ★ 플레이버: 스타로드 가디언즈 특유의 가벼운 감탄조 ("저 친구가 우리 편이라 천만다행이지.")
- 연출: 설치=combatInstall(동료 고무/각성 테마)
**검증:** 감화 테스트 6종(ATK+1 / THW+1 / 부수 피해 없음 / 부착 / 동료당 최대 1장 /
데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 229건
미등록 0 · 빌드 grep ✓ · 용량 1904KB
**리더십 어스팩트 완료:** 01066~01074 전부 등록 완료 (호크아이/마리아힐/비전/준비완료/
선두에서이끌기/요청하기/트리스켈리온/감화 + 01072 리더십의 힘)
**카드 작업:** 다음 코어 mcode 순 — 01075 블랙위도우(✅ 기등록) → 01076 루크 케이지(보호)
---

## v2026.07.10.109 — 리더십 어스팩트 01073 트리스켈리온 + 동료 한도 시스템
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "🧠멘탈" 오류 → ⚡에너지 정정. cost 1 / support / Location+S.H.I.E.L.D. (Core Set #73)
- 트리스켈리온(the-triskelion) 등록: allyLimitBonus:1 (지속, 동료 한도 +1)
- ★ 엔진: allyLimitOf 헬퍼 신설 (기본 3 + 플레이 영역 카드 allyLimitBonus 합산).
  playCard 동료 case에 한도 검사 신설 (기존엔 한도 강제 없었음). baseFields에 등록.
  UI 동료 슬롯을 allyLimitOf만큼 동적 표시
- ★ 플레이버: 쉬헐크 — S.H.I.E.L.D. 본부 높이 농담조
- 연출: 설치=tacticsInstall(S.H.I.E.L.D. 본부 재사용)
**검증:** 트리스켈리온 테스트 5종(기본 한도 3 / 한도 4 / 트리스켈리온 없이 4번째
거부 / 있으면 배치 성공 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격
일치 ✓) · 연출 참조 228건 미등록 0 · 빌드 grep ✓ · 용량 1902KB
**엔진:** allyLimitOf 동료 한도 (기본 3 + 보너스, playCard 강제)
**카드 작업:** 다음 코어 mcode 순 — 01074 감화(inspired)
---

## v2026.07.10.108 — 01071 요청하기(make-the-call) 중복 정리
**무엇을:**
- ★ 발견: make-the-call(요청하기/호출하기)은 이전 세션에 이미 완성 등록돼 있었음
  (recallUid 방식, HP 최대 복구 + tempStatBonus 초기화 + whenPlayed 발화까지 완비).
  순서 확인 없이 중복 등록할 뻔한 것을 정리 — 중복 fx 블록 + 중복 테스트 제거
- ★ 교훈: 카드 등록 전 반드시 기존 fx 등록 여부 확인 (grep defineCardFx)
- ★ 01066~01072 전부 완료 확인. 다음 진짜 미등록 = 01073 트리스켈리온
- 참고: 01072 리더십의 힘(power-of-leadership)도 어스팩트 자원 카드로 기등록
**검증:** 기존 make-the-call 테스트 5종 유지 통과 · 회귀 전체 통과(재생 결정성
엄격 일치 ✓) · 연출 참조 227건 미등록 0 · 빌드 grep ✓ · 용량 1900KB
**카드 작업:** 다음 코어 mcode 순 — 01073 트리스켈리온(the-triskelion, 리더십 지원)
---

## v2026.07.10.108 — 리더십 어스팩트 01071 호출하기
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
  cost 0 / event / deckLimit 3 (Core Set #71)
- 호출하기(make-the-call) 등록: special(makeTheCall) — 버림 더미의 동료를 찾아
  전장 배치(시전자 통제) + HP 최대 복구 + whenPlayed 훅 발화(등장 효과 트리거).
  a.recallUid로 대상 지정. playCard ctx에 recallUid 전달
- ★ FAQ: "플레이"가 아닌 "전장 배치" (Helicarrier/Tower 할인 X, Play 제약 무시).
  등장 반응(마리아 힐 드로우 등)은 정상 발동 → whenPlayed 훅으로 처리
- ★ 플레이버: 마리아 힐 비상 소집 ("코드 레드다! 전원 출동!")
- 연출: 설치=tacticsInstall(소집/지휘 테마)
**검증:** make-the-call 테스트 5종(동료 전장 배치 / 버림 더미 제거 / HP 복구 /
whenPlayed 발화 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 참조 227건 미등록 0 · 빌드 grep ✓ · 용량 1899KB
**카드 작업:** 다음 코어 mcode 순 — 01072 이후 (리더십의 힘 등)
---

## v2026.07.10.107 — 임시 버프 UI 표시 (동료 스탯 allyStatOf 연결)
**무엇을:**
- ★ 문 요청: 임시 버프(선두에서 이끌기·비전 등)가 UI에서 확인 가능하도록
- ★ 문제: 동료 스탯이 a.attack(기본값)만 표시하고 allyStatOf(임시 버프 포함) 미사용
  → 비전/선두에서 이끌기 버프가 화면에 안 보였음
- ★ UI: 동료 스탯을 allyStatOf(G,a,stat)로 계산 + 버프량(mod) 표시.
  edgeStats는 이미 mod 지원 (boosted 클래스 = 노란 테두리 + 발광 + "+N" 표시).
  ATK/THW 버튼과 칩 모두 유효 스탯 반영. 히어로는 기존 idEdge(statOf+mod)로 이미 작동
- ★ 부수: 동료 활성화 능력 canUse에 playCondition/oncePerRound 검사 추가 (호크아이/비전
  버튼 정확도) + 조건부 능력 노란 테두리 하이라이트를 동료에도 적용
- 효과: 임시 버프 적용 시 해당 스탯 칩이 노랗게 빛나고 +N 표시 → 플레이어가 버프
  상태를 한눈에 확인. 페이즈 종료 시 자동 소멸도 화면에 반영
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 카드 기능 테스트 전체 통과 ·
연출 참조 226건 미등록 0 · 빌드 grep ✓ · 용량 1897KB
**UI:** 동료 유효 스탯(임시 버프 포함) 표시 + 버프 노란 강조
**카드 작업:** 다음 코어 mcode 순 — 01071 이후 리더십 카드
---

## v2026.07.10.106 — 리더십 어스팩트 01070 선두에서 이끌기 + 히어로 임시 버프
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "🧠멘탈" 오류 → ⚡에너지 정정. cost 2 / event / Tactic / deckLimit 3 (Core Set #70)
- 선두에서 이끌기(lead-from-the-front) 등록: special(leadFromFront) — 대상 플레이어의
  히어로 + 모든 동료가 페이즈 종료까지 THW+1/ATK+1. ctx.targetPlayer로 멀티 대상 지원
- ★ 엔진: statOf에 히어로 tempStatBonus 합산 신설 (비전에서 만든 동료 tempStatBonus의
  히어로 버전). 페이즈 종료 시 히어로 tempStatBonus 초기화. playCard ctx에 targetPlayer
- ★ 플레이버: 캐롤 댄버스 앞장서는 리더 구령 ("모두 가자!")
- 연출: 이벤트 시각화
**검증:** lead-from-the-front 테스트 6종(히어로 ATK+1/THW+1 / 동료 ATK+1/THW+1 /
강화 히어로 공격 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 참조 226건 미등록 0 · 빌드 grep ✓ · 용량 1896KB
**엔진:** 히어로 tempStatBonus (statOf 합산, 페이즈 종료 소멸)
**카드 작업:** 다음 코어 mcode 순 — 01071 이후 리더십 카드
---

## v2026.07.10.105 — 리더십 어스팩트 01069 준비 완료!
**무엇을:**
- ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
  줄만 "🧠멘탈" 오류 → 💪피지컬 정정. cost 0 / event / deckLimit 3 (Core Set #69)
- 준비 완료!(get-ready) 등록: readyTarget(target:chosen) — 소진된 동료를 준비 상태로.
  기존 readyTarget 이펙트 재사용. "행동"이라 알터에고에서도 사용 가능
- ★ 플레이버: 스티브 로저스 절제된 리더 어조 ("우리는 날마다 혹독하게 훈련한다...")
- 연출: 이벤트 기본 시각화
**검증:** get-ready 테스트 4종(소진 동료 준비 / 공격 후 소진 / 준비 후 재공격 /
데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 226건
미등록 0 · 빌드 grep ✓ · 용량 1893KB
**카드 작업:** 다음 코어 mcode 순 — 01070 이후 리더십 카드
---

## v2026.07.10.104 — 리더십 어스팩트 01068 비전 (동료) + 임시 스탯 버프
**무엇을:**
- ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
  줄만 "⚡에너지" 오류 → 💪피지컬 정정. cost 4 / ATK 2 / THW 1 / HP 3 / unique (Core #68)
- ★ 주의(헷갈리기 쉬움): 카드 비용 자원=💪피지컬, 능력 발동 비용=⚡에너지 (별개!)
- 웹 테마: 밀도 제어 안드로이드 어벤져, 냉정하고 논리적
- 비전(vision) 등록: activatedAbility(payCost energy + oncePerRound + special:visionBoost).
  choice(THW/ATK)에 따라 tempStatBonus +2 (페이즈 종료까지)
- ★ 엔진: allyStatOf에 tempStatBonus 합산 신설. useCardAbility에 oncePerRound(카드별)
  + choice 전달. 플레이어 페이즈 종료 시 동료 tempStatBonus 초기화. 라운드 리셋 시
  카드 usedAbilityThisRound 초기화
- ★ 플레이버: 비전 냉정한 안드로이드 말투 ("내가 처리하지.")
- 연출: 설치/활성화=combatInstall(안드로이드 밀도 강화 테마)
**검증:** 비전 테스트 6종(ATK+2 / THW+2 / 라운드당 1회 / 강화 ATK 공격 / 데이터
교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 226건 미등록 0 ·
빌드 grep ✓ · 용량 1892KB
**엔진:** tempStatBonus 임시 동료 버프 + useCardAbility oncePerRound/choice
**카드 작업:** 다음 코어 mcode 순 — 01069 이후 리더십 카드
---

## v2026.07.10.103 — 리더십 어스팩트 01067 마리아 힐 (동료)
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
  cost 2 / ATK 1 / THW 2 / HP 2 / S.H.I.E.L.D. / unique (Core Set #67)
- 웹 테마: S.H.I.E.L.D. 부국장, 냉철하고 유능한 지휘관. 카드 드로우=정보/지원 조율
- 마리아 힐(maria-hill) 등록: whenPlayed(mariaHillDraw) → 각 플레이어(who:all) 1장
  드로우. 기존 draw 이펙트 재사용
- ★ 플레이버: 마리아 힐 냉철한 지휘관 말투로 다듬기 ("믿든 말든, 우리 모두 원하는 건 결국 같아.")
- 연출: 설치=tacticsInstall(S.H.I.E.L.D. 지휘 홀로그램 재사용)
**검증:** 마리아 힐 테스트 4종(덱 1장 드로우 / 손패 순 -1 / 전장 등장 / 데이터
교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 223건 미등록 0 ·
빌드 grep ✓ · 용량 1889KB
**카드 작업:** 다음 코어 mcode 순 — 01068 이후 리더십 카드
---

## v2026.07.10.102 — 리더십 어스팩트 01066 호크아이 (동료) + 하수인 등장 반응
**무엇을:**
- ★ 리더십(leadership) 어스팩트 첫 카드 진입
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "🧠멘탈" 오류 → ⚡에너지 정정. cost 3 / ATK 1 / THW 1 / HP 3 / Avenger / unique (Core Set #66)
- 웹 테마: 클린트 바튼, 백발백중 명사수, 트릭 애로우. 화살 카운터가 테마와 일치
- 호크아이(hawkeye) 등록: uses:4 + activatedAbility(playCondition:minionJustEntered +
  useCounter:1 + special:hawkeyeArrow). exhaust:false (카운터만 소비, 여러 하수인 대응)
- ★ 엔진: 하수인 등장 시 G.minionJustEntered 힌트 신설(mc_5_encounter.js).
  condCheck minionJustEntered 조건. useCardAbility에 special 핸들러 실행 추가.
  호크아이는 방금 등장한 하수인에게 2 피해 (조건부 노란 테두리 하이라이트 자동 적용)
- ★ FAQ: 카운터로 하수인 처치해도 Surge/When Revealed 효과는 정상 발동
- ★ 플레이버: 클린트 바튼 — 냉소적이지만 자신감 있는 명사수 말투로 의역
- 연출: 설치=combatInstall(궁수 테마), 활성화=aggressionSlash(화살 명중, "화살!")
**검증:** 호크아이 테스트 7종(등장 카운터 4 / 하수인 2피해 / 카운터 감소 / 등장 전
발동 불가 / 4회 후 버림 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격
일치 ✓) · 연출 참조 221건 미등록 0 · 빌드 grep ✓ · 용량 1887KB
**엔진:** minionJustEntered 힌트 + useCardAbility special 핸들러
**카드 작업:** 다음 코어 mcode 순 — 01067 이후 리더십 카드
---

## v2026.07.10.101 — 정의 어스팩트 01065 히어로의 직감
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "🧠멘탈" 오류 → ⚡에너지 정정. cost 2 / upgrade / Skill / deckLimit 3 (Core Set #65)
- 히어로의 직감(heroic-intuition) 등록: statMod(stat:thwart, amount:1) — 지속 THW+1.
  전투 훈련(combat-training, ATK+1)의 THW 버전. statMod 재사용. maxPerTarget:1
- 연출: 설치=detectiveInstall(직감/통찰 테마 재사용)
**검증:** 히어로의 직감 테스트 4종(THW+1 statOf / 기본 저지량+1 / 데이터 교차검증 /
statMod 등록) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 218건
미등록 0 · 빌드 grep ✓ · 용량 1883KB
**카드 작업:** 다음 코어 mcode 순 — 01066 이후 정의/리더십 카드
---

## v2026.07.10.100 — 정의 어스팩트 01064 감시팀
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
  cost 2 / support / S.H.I.E.L.D. / deckLimit 3 / Uses 3 (Core Set #64). 공식 flavor 없음
- 감시팀(surveillance-team) 등록: uses:3 + activatedAbility(exhaust + useCounter:1 +
  removeThreat 1). tac-team(전술공격팀)과 동일 구조 — 차이는 피해 대신 위협 제거.
  useCounter 시스템 재사용
- 연출: 설치=tacticsInstall(S.H.I.E.L.D. 홀로그램 재사용), 활성화=threatDrain
**검증:** 감시팀 테스트 6종(등장 카운터 3 / 위협 1 제거 / 카운터 감소+소진 / 3회 후
버림 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조
217건 미등록 0 · 빌드 grep ✓ · 용량 1882KB
**카드 작업:** 다음 코어 mcode 순 — 01065 히어로의 직감(heroic-intuition) 등
---

## v2026.07.10.99 — 조건부 능력 노란 테두리 하이라이트 (UI)
**무엇을:**
- ★ 문 요청: 조건부 반응 능력(심문실처럼 특정 조건에서만 발동)이 지금 발동 가능한
  상태일 때 노란색 테두리로 하이라이트 → 플레이어가 "지금 쓸 수 있다"를 즉시 인지
- ★ UI: 서포트/업그레이드 활성화 능력 canUse 판정에 playCondition 검사 추가
  (기존엔 exhausted/form/phase만 검사, playCondition 누락으로 조건 미충족에도 버튼 활성).
  MC.condCheck를 UI에서 호출하여 실시간 조건 판정
- ★ 조건부 능력(ab.playCondition 보유)이 지금 발동 가능하면:
  · 카드에 ability-ready 클래스 → 노란 실선 테두리 + 은은한 펄스 애니메이션(abReady)
  · 능력 버튼도 gold 클래스로 강조
  · 조건 미충족 시 버튼 disabled
- CSS: .mat-slot.ability-ready .card-art (노란 outline + box-shadow 펄스) + abReady 키프레임
- ★ 효과: 심문실(하수인 처치 후)이 하수인 처치 직후에만 노랗게 빛나 발동 타이밍 안내.
  앞으로 playCondition 가진 모든 조건부 활성화 능력에 자동 적용
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 카드 기능 테스트 전체 통과 ·
연출 참조 215건 미등록 0 · 빌드 grep ✓ · 용량 1880KB
**UI:** 조건부 능력 발동 가능 시 노란 테두리 하이라이트 + playCondition 실시간 검사
**카드 작업:** 다음 코어 mcode 순 — 01064 감시팀(surveillance-team)
---

## v2026.07.10.98 — 정의 어스팩트 01063 심문실
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "🧠멘탈" 오류 → ⚡에너지 정정. cost 1 / support / Location / deckLimit 3 (Core Set #63)
- 심문실(interrogation-room) 등록: maxPerTarget:1 + activatedAbility(playCondition:
  justDefeatedMinionByHero + exhaust + removeThreat 1)
- ★ 엔진: onDefeated에 justDefeatedMinionByHero 플래그 신설 (하수인만, 히어로 소스,
  수단 무관 — chase-them-down의 justDefeatedEnemyByAttack과 별개). condCheck 조건 추가.
  useCardAbility에 playCondition 검사 + ctx targetScheme 추가
- ★ FAQ: "당신"=히어로 본인(정체성/업그레이드/자원카드/이벤트). 동료·지원 미포함
- ★ 플레이버: 미스티 나이트 — 강력계 형사 출신 시니컬·터프 말투로 의역
- 연출: 설치=detectiveInstall(수사 테마 재사용), 활성화=threatDrain
**검증:** 심문실 테스트 5종(하수인 처치 전 발동 불가 / 처치 플래그 / 위협 1 제거 /
소진 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조
215건 미등록 0 · 빌드 grep ✓ · 용량 1879KB
**엔진:** justDefeatedMinionByHero 플래그 + useCardAbility playCondition 검사
**카드 작업:** 다음 코어 mcode 순 — 01064 감시팀(surveillance-team)
---

## v2026.07.10.97 — 정의 어스팩트 01061 큰 힘에는 큰 책임
**무엇을:**
- ★ 교차검증(공식 JSON): resource_mental 확정. DB 정답 (정정 불필요).
  cost 0 / event / 특성 없음 / deckLimit 3 (Core Set #61). 공식 flavor 없음
- 큰 힘에는 큰 책임(great-responsibility) 등록: special 핸들러 —
  히어로 인터럽트로 위협을 피해로 대체. ctx.threatAmount만큼 히어로 피해 +
  G.preventNextThreat에 예약 → 다음 placeThreat가 그만큼 위협 배치 취소
- ★ 엔진: placeThreat에 preventNextThreat 소비 로직 신설. 이벤트 case에 special
  핸들러 호출 추가 (effects로 표현 어려운 인터럽트 로직). ctx에 threatAmount 전달
- ★ FAQ: 전량을 받아야 함(부분 방지 불가), 사이드 스킴 시작 위협은 적용 불가
**검증:** great-responsibility 테스트 4종(위협만큼 히어로 피해 / preventNextThreat
예약 / 위협 배치 취소 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격
일치 ✓) · 연출 참조 213건 미등록 0 · 빌드 grep ✓ · 용량 1877KB
**엔진:** preventNextThreat (위협→피해 대체) + 이벤트 special 핸들러 호출
**카드 작업:** 다음 코어 mcode 순 — (01062 정의의 힘 ✅ 완료) → 01063 심문실
---

## v2026.07.10.96 — 정의 어스팩트 01060 정의를 위해! + 캐릭터 말투 플레이버
**무엇을:**
- ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
  "🧠멘탈" 오류 → ⚡에너지 정정. cost 2 / event / Thwart / deckLimit 3 (Core Set #60)
- ★ 플레이버 방침 확립: 캐릭터 말투 살려서 의역. 캡틴 아메리카 대사를 정의롭고
  단호한 어조로 ("넌 끝났다. 네가 저지른 짓, 하나도 빠짐없이 책임지게 될 거다.")
- 정의를 위해!(for-justice) 등록: removeThreat(amount:3, amountIf paidWith mental → 4).
  킥커 = 멘탈 자원 지불 시 3→4 (photon-blast/거침없는 돌진과 동일 킥커 시스템)
- ★ 엔진: removeThreat에 amountIf 조건부 제거량 신설 (dealDamage amountIf와 동일 패턴)
- 연출: threatDrain (청록 위협 제거 입자) 재사용 + eventScheme
**검증:** for-justice 테스트 3종(에너지 지불 3제거 / 멘탈 지불 4제거 킥커 /
데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조 213건
미등록 0 · 빌드 grep ✓ · 용량 1874KB
**엔진:** removeThreat amountIf (조건부 위협 제거량)
**작업 방식:** 자원=공식 JSON resource_* / 플레이버=캐릭터 말투 의역 / 코어 mcode 순
**카드 작업:** 다음 코어 mcode 순 — 01061 큰 힘에는 큰 책임이 따른다(great-responsibility)
---

## v2026.07.10.95 — 정의 어스팩트 01059 제시카 존스 (동료) + 동적 스탯
**무엇을:**
- ★ 교차검증(메모리 #3, 개선된 방식): 공식 JSON(zzorba core.json /tmp/core.json)
  resource_energy 확정. DB resources {energy:1} 정답, textKo만 "🧠멘탈" 오류 →
  ⚡에너지 정정. cost 3 / ATK 2 / THW 1 / HP 3 / Defender / unique (Core Set #59)
- 웹 테마: 사립탐정(Alias Investigations), 초인적 힘, 사람 찾기 전문 →
  사이드 스킴(찾을 문제)이 많을수록 강해지는 컨셉
- 제시카 존스(jessica-jones) 등록: dynamicStat(stat:thwart, per:sideScheme) —
  전장의 사이드 스킴 개수만큼 THW +1 (지속)
- ★ 엔진: allyStatOf 동적 스탯 헬퍼 신설 (mc_4_players.js). allyThwart/allyAttack이
  ally.thwart/ally.attack 직접 참조 대신 allyStatOf로 유효 스탯 계산.
  baseFields에 dynamicStat 등록
- 연출: detectiveInstall 신설 (돋보기 스캔 + 보라색 추적 링, 사립탐정 테마)
**검증:** 제시카 존스 테스트 4종(사이드 스킴 0개 THW1 / 2개 THW3 / 저지 시 위협3
감소 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 참조
212건 미등록 0 · 빌드 grep ✓ · 용량 1872KB
**연출 인덱스(80종):** +detectiveInstall
**엔진:** allyStatOf 동적 동료 스탯 (dynamicStat per:sideScheme)
**카드 작업:** 다음 코어 mcode 순 — 01060 정의를 위해!(for-justice, justice event)
---

## v2026.07.10.94 — ★ 자원 아이콘 오판 정정 (타이그라/전술공격팀/데어데블)
**무엇을 (중대 정정):**
- ★★ 근본 오류 발견: 이전에 web_fetch로 marvelcdb 텍스트를 읽고 "Resource:" 뒤가
  공백이라 타이그라/전술공격팀/데어데블을 "자원 아이콘 없음"으로 정정한 것이 전부 오류.
  자원 아이콘은 이미지라 텍스트 추출 시 안 보일 뿐, 실제로는 있음. 마블챔피언스의
  모든 플레이어 카드는 최소 1개 자원 아이콘을 가짐 ("자원 없음" 카드는 존재하지 않음)
- ★ 공식 JSON 데이터로 확정 (GitHub zzorba/marvelsdb-json-data/pack/core.json의
  resource_* 필드):
  · 타이그라(01051) = 🧠 mental (resources 필드가 통째로 삭제돼 있던 것 복구)
  · 전술공격팀(01056) = ⚡ energy (원래 DB energy:1이 정답이었는데 {}로 잘못 지웠던 것 복구)
  · 데어데블(01058) = 💪 physical (원래 DB physical:1이 정답이었는데 {}로 잘못 지웠던 것 복구)
- textKo 자원 표기도 3장 모두 올바른 아이콘으로 정정 + 공식 JSON 출처 주석
- 테스트 3곳(자원없음 검증 → 올바른 자원 검증)으로 수정
- ★ 메모리 갱신: 자원 아이콘은 web_fetch 텍스트 금지, 공식 JSON resource_* 필드로
  확정. 모르면 모른다고 할 것. 작업은 코어셋 mcode 순서로.
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 카드 기능 테스트 전체 통과 ·
연출 참조 210건 미등록 0 · 세 카드 자원 공식값 확정 · 빌드 grep ✓
**교훈:** 자원 아이콘 = 공식 JSON resource_* 필드로만 확정. web_fetch 텍스트로
'자원 없음' 판단 절대 금지 (아이콘은 이미지).
**카드 작업:** 다음 코어 mcode 순 — 01059 제시카 존스
---

## v2026.07.10.93 — 정의 어스팩트 01058 데어데블 (동료) + afterThwart 훅
**무엇을:**
- ★★ 작업 순서 정정: 어스팩트 세로 진행이 아니라 코어셋 mcode 순서로 진행해야 함.
  코어 01002~01057 완료 확인 → 01058부터 이어감 (정의→리더십→보호→기본→라이노 세트)
- ★ 교차검증(메모리 #3): marvelcdb 원문 web_fetch — daredevil 자원 아이콘 없음
  (Resource 공백) 확정. DB의 physical:1 + textKo "🧠멘탈" 둘 다 오류 → 정정.
  cost 4 / ATK 2 / THW 2 / HP 3 / Defender / unique (Core Set #58)
- 웹 테마 확인: 맹인 변호사 매트 머독, 초인 감각(레이더 센스), 낮엔 법정 밤엔 주먹
- 데어데블(daredevil) 등록: afterThwart 핸들러 (저지 후 적 1명 1피해)
- ★ 엔진: allyThwart에 afterThwart 훅 신설 (thwCost 전 발화, afterAttack과 대칭).
  baseFields에 afterThwart 등록. ctx에 pingTargets 전달
- ★ FAQ(Blackhaven, Tigra 재정 준용): 저지 반응 조건은 consequential damage 전에
  판정 → 마지막 저지(HP 1)에서도 피해 가능. 테스트로 검증
- 연출: radarSense 신설 (붉은 레이더 파동 3겹 확산, 초인 감각 테마)
**검증:** 데어데블 테스트 6종(저지 위협2 / 빌런 1피해 / 자기피해 / 하수인 대상 /
마지막 저지 피해(FAQ) / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격
일치 ✓) · 연출 참조 210건 미등록 0 · 빌드 grep ✓ · 용량 1867KB(+4KB)
**연출 인덱스(79종):** +radarSense
**엔진:** afterThwart 훅 (동료 저지 후 반응, thwCost 전 발화)
**카드 작업:** 다음 코어 mcode 순 — 01059 제시카 존스(justice ally, 사이드스킴당 THW+1)
---

## v2026.07.10.92 — 공격 어스팩트 03031 격분 + 동료 부착 시스템
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb + cardgamedb 대조 — "Attached ally gets +2 ATK
  and takes +1 consequential damage after it attacks." 확정. DB 일치 (정정 불필요).
  cost 1 / 💪피지컬 / upgrade / condition (Captain America #31)
- 격분(enraged) 등록: attachTarget:'ally' + whenPlayed(enragedAttach) →
  부착 동료 attack+2, atkCost+1. maxPerTarget:1 (동료당 최대 1장)
- ★ 엔진: attachTarget:'ally' 지원 신설 (playCard upgrade 부착 처리에 ally 추가).
  동료 격파 시 부착물 함께 정리(releaseAttachments)되므로 스탯 원복 불필요
- ★ FAQ(Hall of Heroes): +2 ATK는 Assault 저지 시에도 적용되나 +1 consequential
  damage는 "공격할 때만"(저지 시 아님) → allyAttack의 atkCost에만 반영, allyThwart
  thwCost엔 미적용. 테스트로 검증
- 연출: 설치 = combatInstall 재사용 (붉은 분노 각인, 격분 테마)
**검증:** enraged 테스트 8종(ATK+2 / 부수피해+1 / 공격 시 강화 적용 / 저지 시
부수피해 미적용 / 동료당 최대 1장 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생
결정성 엄격 일치 ✓) · 연출 참조 208건 미등록 0 · 빌드 grep ✓ · 용량 1863KB(+2KB)
**엔진:** attachTarget:'ally' 동료 부착 (앞으로 동료 부착 카드 재사용)
**카드 작업:** 다음 인덱스 순서 — 04035 베놈 블라스트(venom-blast) 또는
04040 스파이더걸(spider-girl) 등 04xxx 공격 카드
---

## v2026.07.10.91 — 공격 어스팩트 01057 전투 훈련
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb + cardgamedb 대조 — "Your hero gets +1 ATK."
  확정. DB 완전 일치 (정정 불필요). cost 2 / 💪피지컬 / upgrade / skill / deckLimit 3
- 전투 훈련(combat-training) 등록: statMod(stat:attack, amount:1) — 지속 ATK+1.
  초인적인 힘(She-Hulk ATK+2)과 동일 패턴. passiveStatMod가 statOf에 합산.
  maxPerTarget:1 (Max 1 per player)
- 연출: 설치 = combatInstall 신설 (붉은 주먹 각인 + 임팩트 링 + ATK+1 표시, 무술 테마)
**검증:** combat-training 테스트 4종(ATK+1 statOf 반영 / 기본 공격 피해 +1 /
데이터 교차검증 / statMod 등록) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 참조 207건 미등록 0 · 빌드 grep ✓ · 용량 1861KB(+3KB)
**연출 인덱스(78종):** +combatInstall
**카드 작업:** 다음 — 03031 격분(enraged, 1💪 동료부착 ATK+2 부수피해+1) 또는
17028 급강하폭격(dive-bomb, 오버킬+dealDamageMulti 활용)
---

## v2026.07.10.90 — 공격 어스팩트 01056 전술공격팀 + 카운터 시스템
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb 원문 web_fetch 대조 — tac-team 자원 아이콘
  없음(Resource 공백) 확정. cost 3, uses 3(공격 카운터). DB 오류 2건 정정:
  · resources {energy:1} → {} (자원 아이콘 없음)
  · textKo "💪피지컬" → "(자원 아이콘 없음)" + 공식 주석/FAQ
- 전술공격팀(tac-team) 등록: uses:3 + activatedAbility(exhaust + useCounter:1 +
  적 2피해). needsTarget. 설치=tacticsInstall(S.H.I.E.L.D. 전술 홀로그램 재사용),
  활성화 공격=aggressionSlash
- ★ 엔진: activatedAbility에 useCounter 신설 (카운터 소비 + 소진 시 자동 버림)
- ★ FAQ: "공격(attack)"이 아니므로 Guard에 막히지 않고 기절도 안 됨 (동료와 차별점)
- ★★ 데이터 오염 대량 수정: mc_cards_ztraits.js의 S.H.I.E.L.D. 특성이 낱글자로
  깨져 있던 것(["s","h","i","e","l","d"])을 ["s.h.i.e.l.d."]로 전역 복원 — 25개
  카드 영향(nick-fury/war-machine/maria-hill/agent-13/helicarrier 등). 생성
  스크립트가 마침표로 split한 흔적. traits 판정(cardHasTrait) 정상화
**검증:** tac-team 테스트 9종(등장 카운터 3 / 활성화 2피해 / 카운터 감소 / 소진 /
재사용 불가 / 3회 후 버림 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성
엄격 일치 ✓) · 연출 참조 206건 미등록 0 · 빌드 grep ✓ · 용량 1858KB(+3KB)
**엔진:** activatedAbility useCounter (카운터 소비 + 소진 시 버림)
**카드 작업:** 다음 — 01057 전투훈련(combat-training, 2💪 ATK+1 영구 업그레이드)
---

## v2026.07.10.89 — 공격 어스팩트 01055 용맹의 힘 (검증)
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb 대조 — power-of-aggression Cost 0 / 🌟와일드 /
  deckLimit 2 / "용맹(빨간색) 카드 지불 시 생성 자원 2배" 확정. DB 완전 일치 (정정 불필요)
- ★ 발견: fx가 이전 세션에 이미 등록됨 (doubleForAspect:'aggression').
  정의/리더십/보호의 힘과 함께 4개 어스팩트 자원 카드 일괄 등록돼 있었음.
  메커니즘도 elementIcons(mc_4_players.js)에서 이미 처리 (대상 aspect 일치 시 icons *= 2)
- 남은 작업 = 실작동 검증 테스트 추가 + 데이터 교차검증만 (가벼운 검증 세션)
**검증:** power-of-aggression 테스트 4종(용맹 카드 결제 시 와일드 2개 / 비용맹 카드
결제 시 와일드 1개 / 데이터 교차검증 / doubleForAspect 등록) ✓ · 회귀 전체 통과
(재생 결정성 엄격 일치 ✓) · 연출 참조 204건 미등록 0 · 빌드 grep ✓ · 용량 1855KB
**카드 작업:** 다음 — 01056 전술공격팀(tac-team, 3⚡ 서포트 카운터3) 또는
17028 급강하폭격(dive-bomb, 오버킬+dealDamageMulti 활용)
---

## v2026.07.10.88 — 공격 이벤트 연출 (공용 3종 + 소급 적용)
**무엇을:**
- ★ 이벤트 카드 연출 방침 확립 (하이브리드): 효과 유형별 공용 연출을 기본으로
  깔고, 특징적 카드만 개별 강화. 이벤트도 애니메이션 부여 (기존엔 피격 리액션만)
- 공용 연출 3종 신설:
  · aggressionSlash — 붉은 X자 교차 슬래시 + 붉은 파편 6개 + 카드 반동 (공격 이벤트)
  · overkillPierce — 하수인 슬래시 + (오버킬 시) 빌런으로 향하는 관통 궤적 + 임팩트
  · threatDrain — 스킴에서 상승하며 사라지는 청록 입자 (위협 제거)
- ★ 엔진: 이벤트 플레이 시 vfx.event 지정하면 G.fxEvent 힌트 세팅 (targetUids/
  villainUid/scheme). eventScheme:true면 스킴 대상. baseFields에 eventScheme 등록
- ★ UI: fxEvent 재생 로직 — threatDrain(스킴)/overkillPierce(대상+빌런)/
  aggressionSlash(대상 순차) 분기. dispatch 정리에 fxEvent delete
- 이벤트 4장 소급 적용: 어퍼컷/근접전투=aggressionSlash, 거침없는 돌진=overkillPierce,
  추적하라!=threatDrain
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 카드 기능 테스트 전체 통과 ·
연출/대사 참조 204건 미등록 0 · 빌드 grep ✓ · 용량 1855KB(+7KB)
**연출 인덱스(77종):** +aggressionSlash +overkillPierce +threatDrain
**엔진:** G.fxEvent 이벤트 연출 힌트 시스템 (앞으로 모든 이벤트 카드 재사용)
**카드 작업:** 다음 — 01055 용맹의 힘(power-of-aggression, 0🌟와일드 자원)
---

## v2026.07.10.87 — 공격 어스팩트 01054 어퍼컷
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb 대조 — uppercut Cost 3 / 💪피지컬 /
  적 1명 5피해 확정. "적(enemy)"이라 하수인/빌런 모두 대상 (relentless-assault의
  하수인 전용과 대비). DB 이미 정확 (정정 불필요)
- 어퍼컷(uppercut) 등록: dealDamage(target:chosen, amount:5) — 가장 단순한 케이스,
  기존 dealDamage 재활용
**검증:** uppercut 테스트 3종(하수인 5피해 / 빌런 5피해 / 데이터 교차검증) ✓ ·
회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 인덱스 200건 미등록 0 ·
빌드 grep ✓ · 용량 1848KB(+2KB)
**카드 작업:** 다음 — 01055 용맹의 힘(power-of-aggression, 0🌟와일드 자원)
---

## v2026.07.10.86 — 공격 어스팩트 05030 근접 전투 + 다중 대상 엔진
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb + FAQ 대조 — melee Cost 3 / 🧠멘탈 /
  적 1명 3피해 + 다른 적 1명 3피해 확정. DB 이미 정확 (정정 불필요)
- 근접 전투(melee) 등록: dealDamageMulti(lines:2, amount:3)
- ★ 엔진: dealDamageMulti 신설 — 순차 다중 대상 피해. 각 라인 순서대로 해결,
  서로 다른 적 검증(uid 중복 금지), 처치 반영(앞 라인 결과로 대상 처치 시 스킵)
- ★ 공식 FAQ 4건 반영: ①서로 다른 적 필수 ②단일 공격/두 라인(기절 시 첫 라인만)
  ③Guard 첫 라인 처치 후 둘째 라인 빌런 타격 ④빌런 단계 처치 시 둘째도 빌런
**검증:** melee 테스트 6종(두 적 각 3피해 / 같은 적 중복 스킵 / 첫 라인 처치 후
둘째 빌런 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 인덱스 200건 미등록 0 · 빌드 grep ✓ · 용량 1846KB(+2KB)
**엔진:** dealDamageMulti (순차 다중 대상, 서로 다른 적, 처치 반영)
**카드 작업:** 다음 — 01054 어퍼컷(uppercut, 3💪, 적5피해) 등 순차 진행
---

## v2026.07.10.85 — 공격 어스팩트 #53 거침없는 돌진 + 오버킬 엔진
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb + cardgamedb + 리뷰 다수 대조 — 오버킬 조건 =
  "피지컬(💪) 자원 지불" 확정. cardgamedb 텍스트에 [Physical] 명시, marvelcdb
  리마인더엔 아이콘 생략되나 실제 조건은 physical. cost 2 / ⚡에너지 / 하수인 5피해.
  DB textKo가 이미 정확 (정정 불필요)
- 거침없는 돌진(relentless-assault) 등록: 하수인 5피해 + overkillIf(paidWith physical)
- ★ 엔진: applyDamage에 과잉살상(overkill) 초과피해→빌런 신설.
  하수인 처치 시 초과(-hp)를 빌런에게 전달 (빌런엔 overkill 미전파, 중복 방지).
  dealDamage에 overkillIf 조건부 오버킬 지원 (기존 amountIf/piercing과 동일 패턴)
- 기존 paidWith 킥커 시스템 재활용 (photon-blast 등과 동일) — ctx.paidIcons 검사
**검증:** 거침없는 돌진 테스트 5종(피지컬 지불 오버킬 초과→빌런 / 에너지 지불
오버킬 없음 / 하수인 처치 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생 결정성
엄격 일치 ✓) · 연출 인덱스 200건 미등록 0 · 빌드 grep ✓
**엔진:** overkill 초과피해→빌런 (applyDamage) · dealDamage overkillIf 조건부
**카드 작업:** 다음 — 05030 근접전투(melee, 3🧠, 적2명 각3피해)
---

## v2026.07.10.84 — 공격 어스팩트 #52 추적하라!(chase-them-down)
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb + DB 대조 — chase-them-down Cost 0 /
  자원 🧠멘탈 확정 (DB resources가 정답, textKo "💪피지컬"이 오류였음).
  Core Set #52. 효과: "Response(thwart): 히어로가 공격으로 적 처치 후 위협 2 제거"
- ★ 정정 1건: textKo 자원 표기 💪피지컬 → 🧠멘탈 + 공식 주석/FAQ 추가
- 능력 등록: playCondition(justDefeatedEnemyByAttack) + effects(removeThreat 2)
- ★ 엔진: onDefeated에 히어로 공격 처치 추적 플래그 신설
  (opt.isAttack + 히어로 source + 하수인/빌런 대상 → pl.justDefeatedEnemyByAttack).
  condCheck에 justDefeatedEnemyByAttack 조건 추가. basicThwart/basicRecover에
  리셋 로직 추가 (다른 기본 행동 시 반응 기회 소멸)
- ★ FAQ(Hall of Heroes): 빌런 단계 처치도 "적 처치"로 간주 → 발동.
  히어로의 기본/이벤트 공격 모두 트리거 (RRG 재정)
**검증:** chase-them-down 테스트 6종(하수인 처치 후 위협 2 제거 / 처치 플래그 /
적 미처치 시 플레이 불가 / 데이터 교차검증 / 텍스트 정정) ✓ · 회귀 전체 통과
(재생 결정성 엄격 일치 ✓) · 연출 인덱스 200건 미등록 0 · 빌드 grep ✓
**엔진:** justDefeatedEnemyByAttack 추적 플래그 (onDefeated/condCheck/리셋)
**카드 작업:** 다음 — 01053 거침없는 돌진(relentless-assault, 2⚡, 하수인5피해+오버킬)
---

## v2026.07.10.83 — 공격 어스팩트 #51 타이그라 (동료) + tigraPounce
**무엇을:**
- ★ 교차검증(메모리 #3): marvelcdb + DB 대조 — 타이그라 자원 아이콘 없음 확정
  (marvelcdb Resource 필드 공백). cost 3 / ATK 2 / THW 1 / HP 3 (Core Set #51).
  웹으로 테마(야수 본능 고양이류 여전사, 발톱·송곳니·사냥본능·재생력) 확인 후 제작
- 타이그라(tigra-ally) 반응: 공격하여 하수인을 처치한 후 → 1 피해 회복.
  afterAttack 훅으로 등록 (ctx.target이 하수인 type + hp<=0 판정)
- ★ 정정 3건 (이전 스텁 오류):
  · resources {mental:1} 제거 (공식 자원 아이콘 없음)
  · textKo "💪피지컬" 표기 삭제
  · 공식 주석 + FAQ 추가
- ★ 공식 FAQ 룰 정밀 반영: "타이그라 Response는 consequential damage보다
  먼저 발동" (Appendix IV FAQ). allyAttack에서 afterAttack 훅을 atkCost(자기
  피해) 적용 *전*으로 이동 → 회복(+1)이 자기피해(-1)를 상쇄 → 하수인만 계속
  잡으면 무한 생존 (Hall of Heroes 재정). maxHp 초과 시 회복 낭비(정상)
- ★ 연출 tigraPounce: 발톱 스크래치 3줄(앰버) + 호랑이 줄무늬 잔상 4개 +
  야수 도약 반동 + (처치 시) 회복 반짝임 상승 입자 + 사냥 성공! 버스트
**검증:** 타이그라 테스트 7종(하수인 처치 회복 / 생존 시 회복없음 / 빌런 회복없음 /
maxHp 초과 방지 / 회복 우선순위 / 데이터 교차검증) ✓ · 회귀 전체 통과(재생
결정성 엄격 일치 ✓) · 연출 인덱스 200건 미등록 0 · 빌드 grep ✓
**연출 인덱스(74종):** +tigraPounce
**엔진:** afterAttack 훅을 atkCost 전으로 이동(타이그라 FAQ) · fxTigra dispatch 정리
**카드 작업:** 다음 — 01052 추적하라!(chase-them-down) 또는 다음 공격 어스팩트
---

## v2026.07.10.82 — 공격 어스팩트 #50 헐크 (동료) + gammaSmash
**무엇을:**
- ★ 교차검증 우선(메모리 #3): marvelcdb 원문 + DB 대조 — 헐크 cost 2 / ⚡에너지 /
  ATK 3 / HP 5 (Core Set #50) 확정. 웹으로 테마("HULK SMASH!" 순수 파괴력·
  자기파괴 위험) 확인 후 제작
- 헐크(hulk-ally) 강제 반응: 공격 후 덱 위 1장 버림 → 인쇄 자원별 분기:
  · 💪 피지컬: 적 1명 2 피해(빌런 우선) · ⚡ 에너지: 각 캐릭터(아군 포함) 1 피해
  · 🧠 멘탈: 헐크 자멸(버림) · 🌟 와일드: 위 전부
  공식 룰 반영: 이중 아이콘 = 2회 발동(BGG), 와일드+다중은 동시 체크 후
  결정적 순서(피지컬→에너지→멘탈 자멸 마지막 — 헐크가 먼저 사라지지 않게)
- ★ 엔진: allyAttack에 afterAttack 훅 발화 신설(동료 공격 후 강제 반응 경로) +
  허용 필드 afterAttack 등록. 자멸 시 allies 배열 제거 + moveToDiscard
- ★ 연출 gammaSmash(헐크 전용, She-Hulk gammaSlam과 구분): 감마 녹색 충격파
  링 3겹 + 바닥 방사형 균열 6갈래 + 녹색 파편 10개 + 카드 격한 흔들림 +
  HULK SMASH! 버스트. G.fxHulk 힌트 → UI 재생
**검증:** 헐크 테스트 13종(4분기 + 이중 아이콘 + 와일드 전부 + 자멸 + 데이터
교차검증) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 인덱스 198건
미등록 0 · 빌드 grep ✓
**연출 인덱스(73종):** +gammaSmash
**엔진:** afterAttack 훅 · fxHulk dispatch 정리
**카드 작업:** 다음 — 01051 타이그라(동료, 반응: 공격으로 하수인 처치 후 1 회복)
---

## v2026.07.10.81 — BP 11장 비용/아이콘 교차검증 + 텍스트 정정
**무엇을:**
- ★ 카드 데이터 교차검증 원칙 확립 (메모리 저장): 비용·자원 아이콘·스탯을
  mc_cards_db.js + marvelcdb 원문과 대조. 인덱스(marvel_card_index.json)는
  자원 아이콘 null 누락 있으므로 단독 신뢰 금지
- BP 11장 전수 검증 결과 — 비용/자원 아이콘/스탯 전부 정확 확인:
  슈리 2💪(1/1/3) · 조상의 지식 1🧠 · 와칸다 포에버 1⚡ · 에너지 단검 2🧠 ·
  팬서 발톱 2⚡ · 전술적 재능 2💪 · 비브라늄 슈트 2🧠 · 비브라늄 0🌟🌟(와일드2) ·
  황금 도시 2⚡
- 정정 2건:
  · 와칸다 포에버 textKo가 낡은 스텁("비용 0" + 잘못된 4분기 효과)이던 것을
    marvelcdb 공식 기준으로 교체 (Cost 1 ⚡, 업그레이드 특수 순차 발동).
    실제 구현/등록값(cost:1, energy:1)은 원래 정확했고 텍스트만 낡았음
  · 슈리 "와카다" → "와칸다" 오타 수정
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 인덱스 196건 미등록 0 ·
카드 1244장 미등록 0 · 빌드 grep ✓
**원칙 추가:** 카드 등록 시 비용/아이콘/스탯 공식 교차검증 필수 (메모리 #3)
**카드 작업:** BP 세트 완전 검증 완료 → 다음 영웅/빌런 진행 대기
---

## v2026.07.10.80 — BP 업그레이드 4종 전용 설치 연출 (개별 정체성)
**무엇을:**
- 4종 공용이던 wakandaTech 설치를 장비별 전용 연출로 분화 — 나노 조립을
  공통 베이스로 내부 호출 후 ~650ms에 장비 정체성 악센트:
  · ★ daggersInstall: 보라 단검 2자루 X자 교차 등장·반짝
  · ★ clawsInstall: 은백 발톱 3줄 프리뷰 샤인(소형·저채도 — 공격과 구분)
  · ★ tacticsInstall: 홀로 조준 브래킷 락온 + 전술 마커(▲▼) 점멸
  · ★ suitInstall: 키네틱 흡수 링(밖→안 수축) + 카드 심장 펄스 2회
- wakandaTech는 슈리·황금 도시 등 비장비 와칸다 카드 설치용으로 유지
**검증:** 회귀 전체 통과(재생 결정성 엄격 일치 ✓) · 연출 인덱스 196건 미등록 0 ·
빌드 grep 4종 ✓
**연출 인덱스(72종):** +daggersInstall +clawsInstall +tacticsInstall +suitInstall
**카드 작업:** 다음 — 01050 헐크(동료)부터 공격(Aggression) 어스팩트, 또는
다음 영웅 세트 선택 대기
---

## v2026.07.10.79 — 코어 #44·#45 비브라늄 + 황금 도시 ★ 블랙팬서 시그니처 완성
**무엇을:**
- 비브라늄(01044, 자원 0): ★★ 와일드 2 — 데이터(resources wild:2) 완비,
  resourceIconsOf 결제 합산 검증. 등록 효과 없음(패시브)
- 황금 도시(01045, 지원 3, 장소·와칸다): 알터에고 행동 — 소진 → 2장 드로우.
  activatedAbility { form:'alter-ego', exhaust, draw 2 }
- ★ 연출 goldenCity: 비르닌 자나 테마 — 카드 금빛 글로우 + 황금 마천루
  실루엣 5개 차등 상승 + 금 입자 6개 + 마무리 금 링. vfx.ability 슬롯
  (UI 자동 재생). 설치는 wakandaTech 통일
- ★★★ 블랙팬서 세트 완성: 신분 2 + 시그니처 9종(슈리·조상의 지식·와칸다
  포에버·비브라늄·황금 도시·에너지 단검·팬서 발톱·전술적 재능·비브라늄 슈트)
**검증:** 테스트 5종(와일드 2/드로우 2/소진/재사용 불가/폼 제한) ✓ · 회귀 전체
통과(재생 결정성 엄격 일치 ✓) · 연출 인덱스 195건 미등록 0 · 빌드 grep ✓
**연출 인덱스(68종):** +goldenCity
**신분/세트 현황:** 5영웅 완성(스파이더맨·캡틴마블·쉬헐크·아이언맨·블랙팬서)
**카드 작업:** 다음 — 순차 기준 01050 헐크(동료)부터 어스팩트 카드(공격 세트),
또는 다음 영웅 세트(닥터 스트레인지 등) 선택
---

## v2026.07.10.78 — 와칸다 포에버 효과별 전용 발동 연출 4종
**무엇을:**
- 각 특수 발동에 효과별 전용 연출 추가 (카드 발광 + 280ms 후 재생):
  · ★ energyDaggers: 업그레이드 카드→각 적으로 보라 에너지 단검 비행 + 꽂힘
    스파크 + DAGGERS!(최종=대상당 2자루, DAGGER STORM!)
  · claws 확장: big(최종) 지원 — 발톱 4줄·1.45배·SHREDDED! (일반 3줄 SLASH!)
  · ★ tacticalHolo: 슈리표 전술 분석 — 스킴 위 홀로 그리드 + 조준 브래킷 +
    위협 하강 ▼ + ANALYZED!(최종=금색, OUTSMARTED!)
  · ★ kineticTransfer: 히어로 흡수 글로우 → 보라 에너지 볼 포물선 비행 →
    적 폭발 + KINETIC!(최종=볼 2개)
- 핸들러가 step에 연출 타겟 기록(targets/target/schemeUid/heroUid) →
  UI가 발광 후 효과별 분기 재생. 시퀀스 간격 700→950ms
- 조건부 연출 분리: 모든 특수가 일반/최종(big) 두 형태
**검증:** 테스트 11종(기존 7 + 연출 데이터 4) ✓ · 회귀 전체 통과(결정성 엄격
일치 ✓) · 연출 인덱스 194건 미등록 0 · 빌드 grep ✓
**연출 인덱스(67종):** +energyDaggers +tacticalHolo +kineticTransfer
**카드 작업:** 다음 — 01044 비브라늄(자원) · 01045 황금 도시(지원) → BP 완성
---

## v2026.07.10.77 — 코어 #43~49 와칸다 포에버! + BP 업그레이드 4종 (세트 심장)
**무엇을:**
- ★ 특수(Special) 능력 시스템 신설: 업그레이드 def에 special:'핸들러' 필드
  (화이트리스트 등록). 와칸다 포에버가 순차 호출하는 전용 발동 경로
- BP 업그레이드 4종 특수 등록 (설치 연출 wakandaTech 재사용):
  · 에너지 단검: 빌런+대상 플레이어 교전 적 각 1(최종 2) — 비공격(반격 미유발)
  · 팬서 발톱: 적 2(최종 4) — 공격(source:pl, 반격 유발 정확) · 빌런 우선
  · 전술적 재능: 메인 위협 1(최종 2) 제거
  · 비브라늄 슈트: 히어로 피해 1(최종 2) 적에게 이동 — 키네틱 재분배 테마,
    피해 없으면 무효(이동량 = min(수치, 받은 피해))
- 와칸다 포에버(01043, 이벤트 1, playForm hero): 조종 BP 업그레이드 특수를
  순차 해결, 마지막 단계 강화. 결정적 순서(전략 최적): 슈트→재능→단검→발톱.
  G.fxWakandaSeq { steps:[{uid,defCode,final}] } → UI 650ms+700ms 간격 순차 재생
- ★ 연출 3종: wakandaForever(X자 팔 교차 바 + 풀스크린 보라 파동 +
  WAKANDA FOREVER! 버스트) · specialGlow(일반 단계 보라 발광+SPECIAL!) ·
  specialGlowFinal(최종 강화 금색 대형+금 링+FINAL STRIKE!) — 조건부 연출
  분리 원칙(일반/최종) 적용
**검증:** 테스트 7종(풀 시퀀스 피해 합산 6/하수인 광역/위협/회복/steps final/
단일=최종 강화/무피해 슈트 무효) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 인덱스 190건 미등록 0 · 빌드 grep ✓
**연출 인덱스(64종):** +wakandaForever +specialGlow +specialGlowFinal
**엔진:** special 필드 · fxWakandaSeq · dispatch 정리 추가
**카드 작업:** 블랙팬서 세트 잔여 — 01044 비브라늄(자원) · 01045 황금 도시(지원).
완료 시 BP 시그니처 전체 완성 → 다음 영웅 진행
---

## v2026.07.10.76 — 코어 #42 조상의 지식 + ancestralPlane 연출
**무엇을:**
- 코어 #42 조상의 지식(ancestral-knowledge, BP 시그니처 이벤트 Cost 1):
  알터에고 행동(playForm:'alter-ego') — 버린 더미에서 서로 다른(defCode 기준,
  FAQ: 같은 이름=같은 카드) 카드 최대 3장 → 덱에 셔플. 자기 자신(해결 중) 제외.
  결정적 단순화 우선순위: ① BP 업그레이드 ② 와칸다 포에버 ③ 버림 최신순
  (UI 선택 모달 차후 확장)
- ★ 신규 연출 ancestralPlane: 조상 평원 테마 — 카드 보라 글로우 + 영혼 불꽃
  8개 상승·소멸 + 상공 별(✦) 반짝임 4개. vfx.play 슬롯
**검증:** 테스트 5종(3장 셔플/BP 회수/중복 이름 제외/로그/폼 제한) ✓ · 회귀
전체 통과(재생 결정성 엄격 일치 ✓) · 연출 인덱스 185건 미등록 0 · 빌드 grep ✓
**연출 인덱스(61종):** +ancestralPlane
**카드 작업:** 다음 — 01043 와칸다 포에버! ★ BP 세트 핵심 엔진: 전장의
비브라늄(Black Panther) 업그레이드 각각의 "특수" 능력을 순차 발동
(단검=전원 1피해/발톱=공격 2(마지막 4)/재능=저지 1(2)/슈트=피해 이동 1(2)),
마지막 발동 업그레이드는 강화 수치. 업그레이드 4종의 특수 능력 등록과 동시 진행
---

## v2026.07.10.75 — 코어 #40 슈리 + 블랙팬서 기본공격 claws + wakandaTech 설치
**무엇을:**
- 블랙팬서(01040a) 기본공격 연출을 신규 ★ claws 타입으로: 은백 발톱 3줄이
  좌상→우하로 대상을 가르는 스크래치 + SLASH! (블랙캣 등 발톱형 히어로 범용)
- 코어 #40 슈리(shuri, BP 시그니처 동료 2/1/1/3): 반응 — 등장 후 덱에서
  업그레이드 1장 손에 추가 + 덱 셔플. 결정적 단순화: Black Panther 업그레이드
  우선, 없으면 첫 업그레이드 (UI 선택 모달 차후). G.fxReveal(kind:'shuri') 힌트
- ★ 신규 설치 연출 wakandaTech (테마 웹 확인: 슈리 = 나노테크 천재 —
  "수트 전체가 목걸이 이빨 안에", 나노입자 운동에너지 흡수·재분배):
  나노입자 14개 사방 수렴 + 보라 스캔라인 아래→위 조립 + 홀로 링.
  BP 시그니처 업그레이드 4종(단검/발톱/재능/슈트) 설치에 재사용 예정
**검증:** 슈리 테스트 4종(서치/업그레이드 타입/BP 우선/로그) ✓ · 회귀 전체 통과
(재생 결정성 엄격 일치 ✓) · 연출 인덱스 184건 미등록 0 · 빌드 grep ✓
**연출 인덱스(60종):** +claws +wakandaTech
**카드 작업:** 다음 — 01042 조상의 지식(알터에고 행동: 버림 3장 덱에 셔플)

---

## v2026.07.10.74 — 신분 #01040 블랙팬서/티찰라 + 보복 키워드 신분 확장
**무엇을:**
- 신분 01040a 블랙팬서(히어로): Retaliate 1 — 공격받은 후 공격자에게 1 피해.
  applyDamage 보복 판정에 신분 카드(히어로 폼 한정) 인쇄 보복 합산 + ★ 재보복
  가드(!opt.isRetaliate — 상호 보복 무한루프 방지, 공식 룰: 보복은 공격 아님)
- 신분 01040b 티찰라(알터에고): Foresight — 셋업: 덱에서 Black Panther 업그레이드
  1장 손에 추가 + 덱 셔플. ★ setupGame에 신분 onSetup 훅 신설(양면 def 발화,
  초기 드로우 후). 결정적 단순화: 덱 순서상 첫 장(UI 선택 차후)
- 연출 kineticRebuke: 비브라늄 키네틱 테마 — 보라 파동 링 2겹 + 표범 발톱 3줄
  스크래치 + SHRAKK! (공격자 카드 스코프). G.fxRetaliate 힌트 → UI가 onHit 뒤
  300ms 시간차 재생. dispatch 정리 목록에 fxRetaliate 추가
- 허용 필드 목록에 onSetup 등록 (test_index 통과)
**검증:** 신분 테스트 7종(Foresight 서치/로그 · 보복 알터에고 미발동/히어로 발동/
fx 힌트 · 상호 보복 루프 정지 2종) ✓ · 회귀 전체 통과(재생 결정성 엄격 일치 ✓) ·
연출 인덱스 181건 미등록 0 · 빌드 grep ✓
**연출 인덱스(58종):** +kineticRebuke
**엔진:** 신분 retaliate(폼 판정) · 재보복 가드 · onSetup 신분 셋업 훅 · fxRetaliate
**신분 등록 현황:** 5영웅 10신분 (스파이더맨·캡틴마블·쉬헐크·아이언맨·블랙팬서)
**카드 작업:** 다음 — 블랙팬서 시그니처 01041 슈리부터 (와칸다 포에버 엔진 예정)

---

## v2026.07.09.73 — 코어 #39 로켓 부츠 + 일시적 트레잇(Aerial 부여)
**무엇을:**
- 코어 #39 로켓 부츠(rocket-boots, 아이언맨 업그레이드/Armor·Tech): 지속 HP +1 +
  히어로 행동(소진 + 멘탈 자원 1 지불 → 이번 페이즈 Aerial 획득). 아이언맨 Aerial
  부여 핵심 — 초음속 펀치/건틀릿/헬멧의 강화 조건을 켜는 카드
- ★ 일시적 트레잇 시스템 (tempTraits + grantTrait): playerHasTrait이 pl.tempTraits도
  판정. grantTrait 효과로 부여, 플레이어 페이즈 종료 시 tempTraits=[] 리셋
  (이번 페이즈 한정). 결정성 유지(재생 엄격 일치 확인)
- hpBonus:1(recomputeMaxHp 연동) + activatedAbility(payCost mental1)
- 설치 arcInstall(자동). 능력 연출 rocketBoost(화염 제트 분사 + 부양 + LIFTOFF!)
**검증:** 로켓 부츠 테스트 6종(HP+1/사용전Aerial없음/획득/소진/페이즈종료 소멸) ✓ ·
회귀 전체 통과(재생 결정성 ✓) · 빌드 grep ✓
**연출 인덱스(57종):** +rocketBoost
**엔진:** tempTraits(일시 트레잇) · grantTrait 효과 · 페이즈 종료 리셋
**아이언맨 세트 시그니처 완료:** 워머신·리펄서·초음속·페퍼·스타크타워·아크원자로·
  MK.5 아머/헬멧·건틀릿·로켓 부츠 (01030~01039)
**카드 작업:** 아이언맨 시그니처 완료 — 다음 빌런 카드 또는 신분 정리

## v2026.07.09.72 — 코어 #38 동력 건틀릿 + 활성 능력 대상 선택
**무엇을:**
- 코어 #38 동력 건틀릿(powered-gauntlets, 아이언맨 업그레이드/Armor·Tech): 히어로
  행동(공격) — 소진 → 적 1 피해 (Aerial이면 2). 매 턴 반복 화력
- ★ 활성 능력 대상 선택 (needsTarget): activatedAbility.needsTarget → UI가
  abilityTarget 모드로 적 선택(화염 하이라이트) 후 useCardAbility에 targets 전달.
  대상 지정형 활성 능력 최초 지원
- ★ 조건부 발사 연출 2종:
  · gauntletBlast(지상 1피해): 단발 리펄서 볼트 + ZAP!
  · gauntletBlastAerial(Aerial 2피해): 트윈 볼트 2연발 + 큰 폭발 ZAAP! + 흔들림
**검증:** 건틀릿 테스트 4종(Aerial 없음 1/소진/Aerial 2) ✓ · 회귀 전체 통과 · 빌드 grep ✓
**연출 인덱스(56종):** +gauntletBlast +gauntletBlastAerial
**엔진/UI:** activatedAbility.needsTarget(대상 지정 활성 능력) · abilityTarget 모드
**카드 작업:** 다음 01039 로켓 부츠

## v2026.07.09.71 — MK.5 헬멧 조건부 2연출 (Aerial 분기)
**무엇을 (사용자: 조건부 능력도 애니 다르게):**
- ★ 활성 능력 Aerial 조건부 연출 분기 (vfx.abilityAerial): _fireCardAbility에서
  playerHasTrait(aerial) 판정으로 ability↔abilityAerial 교체. (초음속 펀치의
  basicAttackAerial 패턴을 활성 능력에도 확장)
- MK.5 헬멧 2연출:
  · 단일(helmetTarget): HUD 조준 레티클 1개 락온 + LOCK ON!
  · Aerial 광역(helmetTargetAll): 화면 스윕 스캔 라인 + 스킴 존 다중 레티클 순차
    락온 + MULTI-LOCK! + 흔들림 (상공 다중 조준 테마)
**검증:** 회귀 전체 통과(vfx_index 177) · 헤드리스 단일 LOCK ON!/광역 MULTI-LOCK! ✓ ·
빌드 grep ✓
**연출 인덱스(54종):** +helmetTargetAll
**패턴:** vfx.abilityAerial(활성 능력 조건부 연출) — basicAttackAerial과 함께 상태별 분기
**카드 작업:** 다음 01038 파워 건틀릿

## v2026.07.09.70 — 코어 #37 MK.5 헬멧 + removeThreat 조건부 광역
**무엇을:**
- 코어 #37 MK.5 헬멧(mk5-helmet, 아이언맨 업그레이드/Armor·Tech): 히어로 행동(저지) —
  소진 → 스킴 1개 위협 1 제거 (Aerial이면 모든 스킴에서 1씩)
- ★ removeThreat 조건부 광역(allSchemesIf): 조건(Aerial 등) 충족 시 메인+모든
  사이드 스킴에서 제거, 아니면 단일(ctx.targetScheme 우선). condCheck 재사용
- ★ VFX.helmetTarget: 헬멧 HUD 조준 레티클 확장 스캔 + 십자선 + LOCK ON!
  (헬멧 표적 시스템 테마). 설치 arcInstall(자동)
**검증:** MK.5 헬멧 테스트 4종(Aerial 없음 메인-1/소진/Aerial 메인+사이드 각-1) ✓ ·
회귀 전체 통과 · 빌드 grep ✓
**연출 인덱스(53종):** +helmetTarget
**엔진:** removeThreat allSchemesIf(조건부 광역 저지)
**카드 작업:** 다음 01038 파워 건틀릿

## v2026.07.09.69 — 코어 #36 MK.5 아머 + 최대 HP 보너스 시스템
**무엇을:**
- 코어 #36 MK.5 아머(mk5-armor, 아이언맨 업그레이드/Armor·Tech): 지속 HP +6
  (최대 HP 증가, 버려지면 보너스 소멸)
- ★ 최대 HP 보너스 시스템 (hpBonus + recomputeMaxHp): 기본 HP + 플레이 영역 카드
  hpBonus 합으로 maxHp 동적 재계산. 설치(whenPlayed) 시 증가분만큼 현재 HP도 증가,
  제거(moveToDiscard) 시 최대 감소 + 현재 HP 상한 클램프 (코어 룰: HP 토큰 증감)
  · whenPlayed 핸들러 applyHpBonus, moveToDiscard에서 hpBonus 카드 감지 재계산
- 설치 연출 arcInstall(자동) · Tech라 아이언맨 손패 +1 연동
**검증:** MK.5 테스트 4종(9→15 증가/제거 시 9 클램프/traits) ✓ · 회귀 전체 통과
  (재생 결정성 ✓) · 빌드 grep ✓
**엔진:** hpBonus · recomputeMaxHp(최대 HP 동적)
**카드 작업:** 다음 01037 MK.5 헬멧

## v2026.07.09.68 — 코어 #35 아크 원자로 (아크 설치 연출 첫 실사용)
**무엇을:**
- 코어 #35 아크 원자로(arc-reactor, 아이언맨 업그레이드/Item·Tech): 히어로 행동 —
  소진 → Iron Man 준비(ready). 한 턴 추가 행동 (readySelf 재사용)
- ★ 설치 시 arcInstall(아크 원자로 테마) 실제 적용 첫 카드 — iron-man 매핑 자동
- ★ VFX.arcReactorReady: 아크 코어 재점화 밝은 맥동 + 에너지 파동 링 2겹 + ONLINE!
  (소진→준비 = 재충전 테마)
**검증:** 아크 원자로 테스트 5종(준비/소진/traits/알터에고 거부) ✓ · 회귀 전체 통과 ·
빌드 grep ✓
**연출 인덱스(52종):** +arcReactorReady
**아이언맨 Tech 손패 연동:** 아크 원자로(Tech) 설치 시 아이언맨 손패 +1 자동 반영
**카드 작업:** 다음 01036~ (MK.5 아머/헬멧·파워 건틀릿·로켓 부츠 등 Tech 업그레이드)
**미등록 신분(TODO):** 27영웅 54신분 (사용자 선택으로 아이언맨 카드 우선 진행 중)

## v2026.07.09.67 — 신분 능력 완비 (캡틴마블·캐롤·토니·제니퍼) + 신분 액션 프레임워크
**무엇을 (사용자 원칙: 시그니처 등록 시 히어로/신분 카드 우선):**
- ★ 신분 액션 프레임워크 (useIdentityAction, 라운드 1회): def.identityAction =
  { form, oncePerRound, payEnergy, selfHeal, effect, vfx }. usedIdentityActionThisRound
  필드 + 라운드 리셋. UI: 신분 슬롯에 ⚡[능력명] 금색 버튼(폼/사용여부 반영)
- 캡틴마블 Rechannel(01010a): 에너지 지불 + 자신 1 회복 → 드로우 (payEnergy+selfHeal).
  에너지 결제 팝업(identityPay 모드)
- 캐롤 댄버스 Commander(01010b): 플레이어 1명 드로우
- 토니 스타크 Futurist(01029b): 덱 위 3장 → 1장 손에 + 2장 버림(EFFECTS.tonyFuturist,
  결정적 단순화). fxReveal(futurist) 힌트
- 제니퍼 왈터스 "I Object!"(01019b): 위협 배치 시 1 방지(threatPrevent, 알터에고,
  라운드 1회). placeThreat 인터럽트로 자동 처리 + usedThreatPreventThisRound
- (앞서 v66: She-Hulk 파워·아이언맨 손패)
**검증:** 신분 테스트 6종(Rechannel 회복/라운드제한 · Futurist 손패+1/덱-3 ·
I Object 1방지) ✓ · 회귀 전체 통과(재생 결정성 ✓) · 빌드 grep ✓
**신분 능력 완료:** 스파이더맨·캡틴마블·She-Hulk·아이언맨 (4영웅 8신분)
**엔진:** useIdentityAction · threatPrevent 인터럽트 · EFFECTS.tonyFuturist
**원칙 확립:** 영웅 세트 진입 시 신분(히어로/알터에고) 카드 먼저 등록
**카드 작업:** 다음 01035 아크 원자로 (아이언맨 시그니처)

## v2026.07.09.66 — ★ 신분(Identity) 능력 등록 시작 (She-Hulk·아이언맨)
**무엇을 (사용자 지적: 신분 카드 능력 미등록 — 정확):**
- 진단: 스파이더맨(attackInterrupt:spiderSense)·피터(resourceAbility:scientist)만
  신분 능력 있고, She-Hulk·아이언맨·캡틴마블 등은 전부 빈 상태였음
- ★ She-Hulk 히어로 파워 "Do You Even Lift?"(01019a): 히어로로 변신 후 → 빌런 2피해.
  onFormChange 훅(신분 카드 자체) — flipForm에서 새 폼 신분 def의 onFormChange 발화
  추가. 연출 gammaSlam 재생(fxHeroPower 힌트, dispatch마다 리셋로 결정성 유지)
- ★ 아이언맨 동적 손패(01029a): Tech 업그레이드 1개당 손패 +1(최대 7).
  statOf handSize에 dynamicHandSize{perTrait:tech, cardType:upgrade, max:7} 반영
- ★ 신분 능력 파일 분리: cards/mc_cards_zidentity_fx.js (identities 뒤 로드 위해 z 접두사).
  defineCardFx가 CARDS 등록 후 실행돼야 하므로
- baseField: dynamicHandSize, onFormChange 추가
**검증:** 신분 테스트 5종(She-Hulk 2피해/알터에고 미발동/아이언맨 1→4→7) ✓ ·
회귀 전체 통과(재생 결정성 ✓) · 빌드 grep ✓
**남은 신분(TODO):** 제니퍼(위협1방지 인터럽트)·토니 Futurist(덱3장보고1장)·캡틴마블·
  기타 영웅 신분 — 순차 등록 예정
**엔진:** 신분 onFormChange 발화 · dynamicHandSize
**파일:** mc_cards_zidentity_fx.js(신분 능력)
**카드 작업:** 신분 능력 계속 or 다음 01035 아크 원자로

## v2026.07.09.65 — 코어 #34 스타크 타워 + 카드 특성(traits) 시스템
**무엇을:**
- 코어 #34 스타크 타워(stark-tower, 아이언맨 서포트/장소): 알터에고 행동 —
  소진 → 플레이어 선택 → 버림 더미 맨 위 Tech 업그레이드 손으로 회수
- ★ 카드 특성(traits) 데이터: cards/mc_cards_ztraits.js 자동 생성(zzorba 846장,
  "Item. Tech." → ['item','tech']). z 접두사로 마지막 로드. cardDef().traits
- ★ recallFromDiscard 효과: 버림 더미 맨 위에서 특성(trait)+타입(cardType) 필터로
  카드 회수. G.fxReveal(recall) 힌트. 단일플레이=자신 대상
- ★ VFX.techRecall: 스타크 타워 아크 홀로 링 + Tech 홀로그램 비트 4개 떠오름 +
  RECALL! (재보급 게이트 테마)
**검증:** 스타크 타워 테스트 6종(손패+1/Tech 회수/비Tech 건너뜀/소진/히어로 거부) ✓ ·
회귀 전체 통과(traits 인덱스 846) · 빌드 grep ✓
**연출 인덱스(51종):** +techRecall
**데이터:** mc_cards_ztraits.js(특성 846장) · 엔진 recallFromDiscard
**카드 작업:** [아이언맨 진행] → 다음 01035 아크 원자로

## v2026.07.09.64 — 코어 #33 페퍼 포츠 + 동적 자원(버림 맨 위) + 결제 미리보기 UI
**무엇을 (사용자: 덱/버림 확인 카드 — 무엇을 쓸지 잘 보이게):**
- 코어 #33 페퍼 포츠(pepper-potts, 아이언맨 서포트/페르소나): 자원 —
  소진 → 버린 더미 맨 위 카드의 자원 생성 (동적 자원 재활용 엔진)
- ★ resourceGenerator.fromDiscardTop: 고정 icons 대신 버림 더미 맨 위 카드의
  resourceIconsOf를 동적 반환. 버림 비면 사용 불가(검증). elementIcons 분기
- ★ 결제 팝업 미리보기 (pay-frombin): 페퍼 타일에 "♻ [버림 맨 위 카드명] + 썸네일 +
  실제 생성 자원 아이콘/합계" 표시 — 무슨 자원이 나올지 클릭 전에 확인
- ★ 자원 생성 카드 연출 배선: 결제에 쓰인 gen 카드의 vfx.resource를 그 카드 위에서
  재생(payConfirm에서 el 선캡처)
- ★ VFX.pepperAssist: 청록 자원 토큰 3개 솟아오름 + 카드 발광 + ASSIST!
  (설치 연출은 iron-man 매핑으로 arcInstall 자동)
**검증:** 페퍼 테스트(에너지 생성/소진/플레이/버림 비면 불가) ✓ · 회귀 전체 통과 ·
빌드 grep ✓
**연출 인덱스(50종):** +pepperAssist
**엔진:** resourceGenerator.fromDiscardTop(동적 자원)
**UI:** 결제 팝업 버림 맨 위 미리보기 · vfx.resource 재생
**카드 작업:** [아이언맨 진행] → 다음 01034 스타크 타워

## v2026.07.09.63 — 초음속 펀치 조건부 2연출 (Aerial 분기)
**무엇을 (사용자: 조건부 애니 2개가 테마에 맞음):**
- ★ 조건부 공격 연출 분기 (vfx.basicAttackAerial): 대상 이벤트(target 모드)에서
  플레이어가 Aerial 보유 시 전용 연출로 교체. playerHasTrait 판정
- 초음속 펀치 2연출:
  · 지상(4피해, supersonicPunch): 수평 스피드 라인 + 소닉붐 이중 링 + BOOM!
  · 비행(8피해, supersonicFlight): 상공에서 급강하 다이버(빛나는 실루엣) + 긴 궤적 +
    이중 소닉붐 확산(160→300→460) + SONIC BOOM! + 강한 흔들림 (지상판보다 과장)
**검증:** 회귀 전체 통과(vfx_index 172) · 헤드리스 지상 BOOM!/비행 SONIC BOOM!·다이버 ✓ ·
빌드 grep ✓
**연출 인덱스(49종):** +supersonicFlight
**패턴:** vfx.basicAttackAerial(조건부 공격 연출) — 향후 상태별 연출 분기 재사용
**카드 작업:** [아이언맨 진행] → 다음 01033 페퍼 포츠

## v2026.07.09.62 — 코어 #32 초음속 펀치 + dealDamage amountIf
**무엇을:**
- 코어 #32 초음속 펀치(supersonic-punch, 아이언맨 시그니처): 히어로 공격 —
  적 4 피해 (Aerial 특성 보유 시 8 피해)
- ★ dealDamage amountIf 지원: {cond, amount} 충족 시 피해량 대체(초음속=Aerial 시 8).
  기존 condCheck(hasTrait) 재사용. 조건부 피해 범용화
- ★ VFX.supersonicPunch: 초음속 스피드 라인 궤적 + 착탄 소닉붐 이중 링 + BOOM! +
  흔들림. 아이언맨 비행 돌진 강타 테마
**검증:** 초음속 테스트(Aerial 없음 4 / 보유 8) ✓ · 회귀 전체 통과 · 빌드 grep ✓
**연출 인덱스(48종):** +supersonicPunch (+repulsorBeam 포함)
**엔진:** dealDamage amountIf(조건부 피해)
**카드 작업:** [아이언맨 진행] → 다음 01033 페퍼 포츠

## v2026.07.09.61 — 덱 공개 시퀀스 UI (리펄서 등 "무엇을 뽑았나" 세련화)
**무엇을 (사용자 요청 — Claude 추천안):**
- ★ 덱 공개 시퀀스 오버레이 (fx-reveal-modal): 리펄서 블래스트처럼 덱을 뒤집는
  카드에서 공개된 덱 카드를 부채꼴로 펼침 + 에너지 카드는 청색 발광/⚡×N 태그 +
  비에너지는 흐릿 + 피해 공식(기본 + ⚡N×2) 표시 + 총 피해 카운트업. 확인 버튼
- ★ 결정적 엔진 유지하며 UI 힌트 전달: G.fxReveal(표시 전용, 밀한 카드 목록·에너지·
  피해). dispatch 진입 시 delete로 소거 → 재생 시 동일 지점 재생성 → 결정성 무손상
  (test_smoke 재생 엄격 일치 통과 확인)
- repulsorBlast 효과가 milledCards(defCode/name/energy) 기록하도록 확장
- 향후 유사 "덱 공개형" 카드에 재사용 가능한 패턴
**검증:** 회귀 전체 통과(재생 엄격 일치 ✓) · 빌드 CSS 균형/모달/부채꼴/발광/v61 grep ✓
**UI:** fx-reveal-modal(덱 공개 시퀀스)
**카드 작업:** [아이언맨 진행] → 다음 01032 초음속 펀치

## v2026.07.09.60 — 코어 #31 리펄서 블래스트 + ★아크 원자로 설치 연출(아이언맨 테마)
**무엇을:**
- ★★ 시그니처 설치 전용 연출 원칙 적용(메모리): 아이언맨 = arcInstall(아크 원자로).
  HERO_CARD_INSTALL에 'iron-man':'arcInstall' 추가 → 아이언맨 전 장비(아크 원자로·
  MK.5 아머/헬멧·스타크 타워·페퍼 포츠 등)가 통일된 아크 설치 연출 자동 적용
  · VFX.arcInstall: 청백색 아크 코어 점화 + 삼각 에너지 링 회전 수축 + 카드 발광 + EQUIP!
  · (참고: 설치 연출은 act() 신규 설치 감지가 우선순위 ①카드 vfx.install ②영웅 매핑
    ③공용 install로 자동 재생. She-Hulk=gammaInstall, 캡틴마블=starInstall 기존 적용)
- 코어 #31 리펄서 블래스트(repulsor-blast, 아이언맨 시그니처): 히어로 공격 —
  적 1 피해 + 덱 위 5장 버림 → 인쇄 에너지 아이콘당 추가 2 피해 (가변 대미지)
- ★ repulsorBlast 효과: 대상 chosen, 덱 밀(mill) + 에너지 아이콘 카운트 + 가변 피해.
  덱 소진 시 onEmptyPlayerDeck 처리
- ★ VFX.repulsorBeam: 청백색 리펄서 빔 차징→발사→착탄 ZAAP! (손바닥 에너지포 테마)
**검증:** 리펄서 테스트(1+에너지2×2=5/덱5장) ✓ · 회귀 전체 통과 ·
헤드리스 arcInstall/repulsorBeam ✓ · 빌드 grep ✓
**연출 인덱스(46종):** +arcInstall +repulsorBeam
**설치 연출 매핑:** she-hulk=gammaInstall, captain-marvel=starInstall, iron-man=arcInstall
**카드 작업:** [아이언맨 진행] → 다음 01032 초음속 펀치

## v2026.07.09.59 — 코어 #30 워 머신 (아이언맨 동료) + 동료 활성 능력 UI
**무엇을:**
- ★ 아이언맨/토니 스타크 테마 웹 확인: 천재 발명가·억만장자·자신감(오만)·재치있는
  위트/원라이너·리펄서/아크원자로 하이테크·무기/방어 시스템. 로디(워 머신)는
  중무장 아머·미사일/개틀링 중화기 특화 → 연출 톤 반영
- 코어 #30 워 머신(war-machine, 아이언맨 동료): 행동 — 소진 + 자신에게 2 피해 →
  모든 적에게 1 피해 (자기를 갈아 광역 딜)
- ★ selfDamageTarget:'card' 옵션: selfDamage 비용을 플레이어가 아닌 카드 자신(동료)에게.
  activatedAbility 조합에 추가
- ★ 동료 활성 능력 UI: activatedAbility 있는 동료에 ★ 버튼(폼/소진 조건 반영).
  _fireCardAbility에 vfx.ability 재생 추가(동료 능력 연출)
- ★ VFX.warMachineBarrage: 미사일 7발 부채꼴 일제사격 → 착탄 폭발 BOOM! + 흔들림.
  중화기 화력 지원 테마
**검증:** 워 머신 테스트 6종(자기2피해/빌런·하수인 각1/소진/selfDamageTarget) ✓ ·
회귀 전체 통과 · 빌드 grep ✓
**연출 인덱스(44종):** +warMachineBarrage
**엔진:** selfDamageTarget(카드 자신 피해)
**UI:** 동료 활성 능력 ★ 버튼
**카드 작업:** [아이언맨 진입] → 다음 01031~ (리펄서 블래스트·초음속 펀치·페퍼 포츠·스타크 타워·아크 원자로 등)

## v2026.07.09.58 — 코어 #28 초인적인 힘 + 기본공격후 강제반응 훅 (★웹 테마 확인 첫 적용)
**무엇을:**
- ★ 캐릭터 테마 웹 확인 원칙 첫 적용: She-Hulk 성향 검색 —
  히어로/변호사 이중정체성을 즐김·자신감·재치(savage wit)·4번째 벽 유머·정의감·
  감정(분노)이 강할수록 힘↑·초인적 힘(차량도 듦)이 트레이드마크. 연출 톤에 반영
- 코어 #28 초인적인 힘(superhuman-strength, She-Hulk 업그레이드):
  지속 She-Hulk ATK +2(statMod) + 강제 반응(기본 공격 후 자체 버림 + 공격받은 적 기절)
- ★ 기본 공격 후 강제 반응 훅 (fireAfterBasicAttack): basicAttack 끝에서 발동
  플레이어 플레이영역 카드의 afterBasicAttack 핸들러 발화(대상=공격받은 적).
  baseField afterBasicAttack 추가. ATTACK 이벤트(감마 슬램 등)는 트리거 X(기본 공격만)
- ★ VFX.superStrength (완력 강타): 거대 주먹 SMASH! + 크레이터 링 2겹 + 격노 진동 +
  회전 기절 별 3개. vfx.basicAttack 슬롯. UI: 강제 반응 발동(카드 소멸) 감지해
  대상 위에 재생(공격 전 스냅샷 diff)
**검증:** 초인적인 힘 테스트 6종(ATK+2/강화피해/버림/기절/제거) ✓ · 회귀 전체 통과 ·
헤드리스 SMASH!/기절별 ✓
**연출 인덱스(43종):** +focusedRage +superStrength
**엔진:** afterBasicAttack 훅 · fireAfterBasicAttack
**카드 작업:** [01001~01028 She-Hulk 완료 임박] → 다음 01029~ / 이후 01030 아이언맨

## v2026.07.09.57 — 코어 #27 집중된 분노 + selfDamage 비용
**무엇을:**
- 코어 #27 집중된 분노(focused-rage, She-Hulk 업그레이드): 히어로 행동 —
  소진 + 자신에게 1 피해 → 카드 1장 드로우 (감마 슬램 콤보용 자기 피해 엔진)
- ★ activatedAbility.selfDamage 비용: useCardAbility에서 소진 후 자신에게 N 피해
  (isCost 플래그). form/exhaust/payCost/discardCost/selfDamage 조합 완성
- ★ VFX.focusedRage: 카드 붉은 진동 + 감마 수축 링 3겹(밖→안 분노 응집) +
  RAGE! + 집중 섬광. vfx.ability 슬롯
**검증:** 집중된 분노 테스트 5종 ✓ · 회귀 전체 통과 · 헤드리스 RAGE!/수축링 ✓
**연출 인덱스(41종):** +focusedRage
**엔진:** activatedAbility.selfDamage
**카드 작업:** [01001~01027] → 다음 01028 초인적인 힘

## v2026.07.09.56 — 엣지 배지 잘림 수정
**무엇을:** .card-art overflow:hidden이 카드 밖(-10px) 배지를 클리핑 →
스탯/상태 배지를 카드 안쪽 모서리(right:2px)로 이동 + 크기 미세 축소.
어떤 컨테이너에서도 잘리지 않음. UI_VER v56

**검증:** 회귀 전체 통과 · 빌드 grep ✓

**카드 작업:** 다음 01027 집중된 분노

## v2026.07.09.55 — 조우/부스트 공개 확인 모달 (정독 페이싱)
**무엇을 (사용자: 페이즈가 훅훅 지나가 확인 불가 — 급증 연쇄·부스트 효과 정독 필요):**
- ★★ 공개 확인 모달 (reveal-modal): 조우/부스트가 공개될 때마다 자동 진행을 멈추고
  한 장씩 모달로 정독 → "계속 ▶" 눌러야 다음 진행 (남은 장수 표시, 전부 넘기기 ⏩)
  · 구성: 큰 카드(240px) + 이름 + 타입 뱃지(+부스트값) + 플레이버(이탤릭 금색) +
    한글 효과 전문(5줄) + 적용 로그(해당 액션의 급증/부스트/카드명 관련 줄 ▸ 녹색 박스)
  · 급증 연쇄도 대기열(revealQueue)로 한 장씩 순서대로. 부스트는 금테 모달
  · maybeStepVillain이 확인 중엔 정지(revealShowing/큐 게이트) — 사람 페이스로 진행
  · 차후 조우/부스트 대사 슬롯: 모달 구조에 플레이버 자리 확보(quotes 확장 예정)
  · 기존 1.8s 자동 오버레이(revealCard vfx) 경로는 모달로 대체
- UI_VER v55

**검증:** 회귀 전체 통과 · 빌드 CSS 균형 ✓ · 모달/게이트/v55 grep ✓

**카드 작업:** 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.54 — 난이도 선택 (표준/전문가)
**무엇을:**
- ★ 난이도 선택 (빌런/시나리오 선택 화면, STEP 2): 표준(1단계 시작·입문) /
  전문가(2단계 시작 — 코어 룰). APP.difficulty → startGame에서 nextStage로 시작
  단계 결정(다음 단계 없으면 1단계 유지) + makeGameState difficulty 저장
- 빌런 존 라벨에 "· 전문가" 적색 표기. 저장/이어하기에 자동 포함(G 직렬화)
- UI_VER v54

**검증:** 전문가 체인 테스트 4종(2단계 시작/저장/2→3 전환/3단계 격파 승리) ✓ ·
회귀 전체 통과 · 빌드 grep ✓

**카드 작업:** 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.53 — 대상 화염 하이라이트 + 공간 활용 + 공개 가시성 + 버튼 편의
**무엇을 (사용자 피드백 4건):**
- ★ 대상 지정 화염 하이라이트 (.targetable): 공격/대상/카운터 모드에서 유효 대상에
  금색 아웃라인 + 불꽃 드롭섀도 펄스(tgflame) + crosshair 커서 + hover 가속.
  빌런 카드에도 targetable 클래스 + 직접 클릭(pickTarget) 추가 (기존 zoneTap 유지)
- ★ 공간 활용: board-inner max-width 860 해제(컬럼 전체 사용) · layout 그리드
  1fr+324px(max 1680) — 화면 노는 공간 대폭 축소
- ★ 부스트/조우 가시성: vpanel 썸네일 38→56px + 한글 3줄 + 부스트 행 금색 강조.
  revealCard 오버레이에 이름표(rv-name) + 부스트 +N 표기 + 유지 1.35→1.8s
- ★ 페이즈 종료 버튼 sticky(bottom:10px z70) — 스크롤 무관 항상 접근
- UI_VER v53

**검증:** 회귀 전체 통과 · 빌드 CSS 균형 ✓ · tgflame/sticky/board폭/v53 grep ✓

**카드 작업:** 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.52 — ★★ CSS 파괴 버그 근본 수술 + 카드 엣지 스탯/상태 배지
**무엇을 (v51 "UI 안 바뀜"의 진짜 원인 — 사용자 정확):**
- ★★ CSS 전면 수술: 과거 삽입 사고로 @keyframes 3개(bulletfly·starinstall·desatpulse)가
  미종결 → 이후 CSS 전체가 중첩(depth 2)돼 브라우저가 무시. 그래서 v50~51의 그리드/
  하단 바/스탯 칩이 전부 죽어 있었음
  · 미종결 3곳 닫음 + 고아 꼬리 조각 2곳(aerialshadow·toughen 뒤) 제거
  · 검증 도구화: 주석 인식 brace-depth 스캐너로 소스+빌드 모두 depth0/음수0 확인.
    핵심 규칙(pending fixed/layout grid/edge-stats/vpanel sticky) 위치 depth 0 확인
- ★★ 카드 엣지 배지 (statChips 칩 컬럼 폐기 — 사용자: 촌스러움):
  · 우측상단 .edge-stats: 코믹 슬랩(스큐+Bangers+스탯별 색) — 신분(ATK/THW/DEF,
    알터에고 REC), 빌런(ATK/SCH), 하수인(ATK/SCH), 동료(ATK/THW)
  · statOf 실시간, 보정 시 금테 발광 + +N. 우측하단 .edge-status: 강인🛡/기절😵/혼란💫
    원형 토큰(하수인 구 상태 칩 제거)
- UI_VER v52. 매 빌드: UI_VER 갱신 + 빌드 CSS depth 검증 절차 고정

**검증:** 회귀 전체 통과 · 빌드 CSS 균형 ✓ · 핵심 규칙 depth0 ✓ · JS 파싱 ✓

**카드 작업:** 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.51 — 버전 스탬프 + 실시간 스탯 칩 + 플레이버 로드 순서 수정
**무엇을 (사용자: "UI 안 바뀜" — 구버전 파일 실행 의심 + 신규 요청):**
- ★ 버전 스탬프 (UI_VER): 상단바 ROUND 옆에 빌드 버전 상시 표시 —
  어떤 빌드를 실행 중인지 화면에서 즉시 확인 가능. 산출 시 UI_VER 갱신 필수(체크리스트)
  · 진단: v50 산출물엔 레이아웃/하단바가 grep으로 확인됨 — 사용자 화면(인라인 방어존,
    플레이버 없음)은 구버전 특징 → 캐시/이전 파일 실행으로 추정. 스탬프로 해결
- ★ 실시간 스탯 칩 (statChips): 신분 카드 옆 세로 스택 —
  히어로: ⚔ATK/🛡THW/🚧DEF · 알터에고: 💚REC/🃏손패. statOf(패시브 보정 포함) 기준,
  인쇄값과 다르면 금색 +N(감소는 적색) + 칩 발광. 헬멧 DEF+1 등 변동이 한눈에
- ★ 플레이버 버그 수정: mc_cards_flavor.js가 신분/빌런 등록(identities/scenarios)보다
  먼저 로드돼 라이노 등 누락 → mc_cards_zflavor.js로 개명(마지막 로드) + 생성기에
  코드 자체가 공식 번호인 카드(^\d{5}[ab]?$) 매칭 추가. 486장(라이노·제니퍼 포함)

**검증:** 회귀 전체 통과 · v51 빌드 직접 grep: 스탬프/스탯 칩/라이노 flavor/그리드/
하단 바/폼 잠금 전부 ✓

**절차 추가:** 매 빌드 UI_VER 갱신 → 산출 → 빌드 파일 직접 grep 검증

**카드 작업:** 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.50 — ★ 폼 액션 강제 + 2컬럼 레이아웃 + 하단 결정 바 + 플레이버
**무엇을 (사용자 피드백 4건):**
- ★★ 히어로/알터에고 액션 폼 강제 (미구현 지적 — 정확):
  · mc_cards_fx.js 끝에 자동 유도 패스: 전 이벤트 카드의 textKo에서
    "히어로 행동/인터럽트/반응"→playForm hero, "알터에고 행동/반응"→alter-ego (167장)
  · playCard가 폼 불일치 거부(기존 playForm 검증 재사용). 명시 등록은 유지
  · 손패 UI: 폼 불일치 카드 회색 처리 + 🔒영웅/알터 잠금 뱃지
  · 테스트 3건이 알터에고에서 히어로 액션을 쓰고 있던 것도 발견·수정(폼 전환 추가)
- ★★ 2컬럼 그리드 레이아웃 (좌우 공간 활용):
  · .layout{grid: 1fr 288px} — 본문(board-inner) + 우측 도크 컬럼(side-col)
  · vpanel: fixed→sticky 컬럼 배치. 보드와 완전 분리, 겹침 없음
  · 좁은 화면(≤1200px): 1컬럼 전환, 패널이 상단으로(order:-1, max-height 250px)
- ★★ 하단 고정 결정 바: .pending-zone(방어 선언·조우 인터럽트)을 position:fixed
  하단 중앙 플로팅으로 — 스크롤 없이 항상 결정 버튼 접근 가능. 등장 애니메이션
- ★ 플레이버 텍스트: cards/mc_cards_flavor.js 자동 생성(zzorba 공식, 451장,
  HTML 태그 제거). UI.info 카드 상세에 이탤릭 인용 표시(기존 .flavor 스타일 활용)
  · 재생성: node로 zz_by_code.json → 이미지 번호 매칭 → flavor 맵

**검증:** 폼 강제 테스트 5종 ✓ · 회귀 전체 통과 · 빌드 직접 검증(그리드/side-col/
하단 바/폼 잠금/플레이버/자동 유도 전부 grep 확인) ✓

**파일:** cards/mc_cards_flavor.js 신규 (db→flavor→fx 알파벳 로드 순서)
**엔진:** playForm 자동 유도 패스(MC._playFormDerived)
**UI:** .layout 2컬럼 · .pending-zone 하단 고정 · formlock 손패 잠금

**카드 작업:** 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.49 — 빌런 페이즈 사이드 패널 (넷러너 런 트래커 스타일)
**무엇을 (사용자 피드백 — 본문 한가운데 거대 카드로 가시성·편의성 파괴):**
- ★★ 우측 고정 사이드 패널 (#vpanel) — 본문을 밀지 않는 전용 UI:
  · 좌우 빈 공간 활용: position:fixed 우측, 보드 레이아웃과 독립
  · ① 단계 타임라인 (넷러너 런 스타일): 위협 배치→적 활성화→조우 배분→조우 공개→
    라운드 정리. 완료=✓녹색 / 진행중=노란 펄스 강조 / 대기=회색. G.vq[0] 기반 판정
  · ② 공개 카드 컴팩트 목록: 38px 썸네일 + 이름 + 타입 뱃지(+부스트값) +
    한글 텍스트 2줄(말줄임). 클릭=확대(UI.info)
  · 플레이어 페이즈엔 "라운드 기록"으로 유지(지난 빌런 페이즈 복기)
  · 헤더 클릭=접기 → 👁N 탭 버튼으로 축소. 좁은 화면 미디어쿼리 축소 대응
- 본문(메인 스킴 아래)의 reveal-panel 완전 제거 — 거대 카드 이미지가 본문을
  밀어내던 문제 해소
- 빌드 검증 강화: 산출 HTML에 CSS·함수·호출 포함 여부 직접 grep 확인 절차 추가

**검증:** 회귀 전체 통과 · 빌드 내 #vpanel CSS/vp-step/vpanelHTML/render 호출/본문
제거/38px 썸네일 전부 직접 확인 ✓

**UI:** #vpanel(빌런 페이즈 사이드 패널) · vp-step 타임라인 · vpanel-tab(접기)

**카드 작업:** 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.48 — 코어 #26 초인법 사무소 + 활성 능력 자원 지불(payCost)
**무엇을:**
- 코어 #26 초인법 사무소(superhuman-law, She-Hulk 시그니처 서포트/위치) 능력 등록:
  알터에고 행동(저지) — 소진 + 멘탈 자원 1 지불 → 한 스킴 위협 2 제거
- ★ 활성 능력 자원 지불 비용 (activatedAbility.payCost:{type,count}):
  · useCardAbility에서 a.payment로 지정 자원 지불 검증(아이콘 합산 + wild) + executePayment
  · 기존 discardCost(카드 버림 비용)와 병존. form/exhaust/payCost/discardCost 조합 가능
  · UI: payCost 있으면 자원 선택 팝업(abilityPay 모드) — 해당 타입 자원 카드만, 지불량
    실시간 표시. 초인법 사무소는 멘탈 자원 카드만 후보로
- 연출: 변호사 테마 → 법률 업무(legalWork) 재사용. vfx.ability 슬롯(활성 능력 연출)

**검증:** test_phase3_core 확장 — 위협2제거/소진/멘탈지불/히어로폼거부/멘탈없이거부 ✓ ·
회귀 전체 통과(core 200판·vfx_index 164건)

**엔진:** activatedAbility.payCost(자원 지불 비용)
**UI:** abilityPay(능력 자원 지불 팝업) · vfx.ability 슬롯

**카드 작업:** [01001~01026 진행] → 다음 01027 집중된 분노. 01xxx 번호순 계속


## v2026.07.09.47 — ★ 룰북 순서 교정 (부스트 후공개·하수인 암약·턴종료 준비) + 조우 한글 패널
**무엇을 (사용자 룰북 검증 — 프로젝트 지식의 이전 빌드 RRG 인용 확인):**
- ★★ 빌런 공격 부스트 룰북 순서 (사용자 지적 — 정확):
  ① 공격 선언 + 부스트 카드 "뒷면" 배분(pending.boostCard 보관, amount=기본 ATK만)
  ② 방어 선언 (부스트 값 모른 채 결정 — 룰 핵심 긴장감)
  ③ 방어 확정 후 부스트 공개 + 합산 → ④ 피해 적용
  · preventAmount는 방지량 "누적 예약"(pend.prevented)으로 변경 — 부스트 미공개라
    총피해 불명이므로 조기 완결 불가. 해소 시 총피해에서 차감
  · preventAll은 뒷면 부스트 공개(무효) 후 버림 (카드 유실 방지)
- ★★ 하수인 알터에고 암약 (공식 RRG 2.4.5 — 사용자 지적 정확, 직전 오수정 원복):
  "If the identity of the engaged player is in alter-ego form, the minion initiates
  a scheme." → 알터에고 상대론 빌런·하수인 모두 암약(SCH만큼 위협)
- ★★ 준비·드로우 = 플레이어 턴 종료 시 (공식 RRG — 이전 빌드 인용 확인):
  endPlayerPhase에서 전원 준비 + 핸드 크기까지 드로우 → 빌런 페이즈 진행.
  endRound의 드로우 제거(준비 리셋은 유지)
- ★ 방어 선언 존 UI: "피해 N + ?" 표기 + 🂠 뒷면 부스트 칩(공개 대기 안내) +
  방지 예약 칩(누적 −N). 부스트 공개는 방어 확정 후 revealCard 오버레이로 자동 재생
- ★ 공개 연출 일원화: act()가 revealLog diff로 revealCard 오버레이 재생 —
  villainStep·방어 해소 등 모든 경로 공통 (maybeStepVillain 중복 제거)
- ★★ 조우 공개 전용 패널 (사용자 요청 — 클릭 불편 해소):
  reveal-strip(썸네일만) → reveal-panel로 전면 교체. 카드별로 [썸네일 + 이름 +
  타입 뱃지(배반/하수인/사이드스킴/부착/부스트+N) + 한글 효과 텍스트(textKo 3줄)]가
  클릭 없이 한눈에. 썸네일 클릭=확대(UI.info). 접기 가능(details, 기본 열림)

**검증:** 룰북 순서 테스트 7종(부스트 후공개 5 + 하수인 암약 2 + 턴종료 준비·드로우 2) ✓ ·
기존 테스트 룰북 순서로 갱신(무방어=기본+부스트, 우주비행=방지 예약→해소 차감) ·
회귀 전체 통과(core 200판)

**교훈:** 룰 판단은 반드시 사용자 제공 룰북(프로젝트 지식 이전 빌드의 RRG 인용) 대조.
기억 기반 수정 금지 — 하수인 건은 오수정 후 원복했음

**카드 작업:** 다음 01026 초인법 사무소. 01xxx 번호순 계속


## v2026.07.09.46 — 코어 #25 이중인격 + 강제 폼 전환 + 감마 분열 연출
**무엇을:**
- 코어 #25 이중인격(split-personality, She-Hulk 시그니처) 능력 등록:
  행동 — 정체성 변신(라운드 제한 무시) → 인쇄된 핸드 크기까지 드로우
- ★ 강제 폼 전환: flipForm(G, pl, {force:true}) — 라운드 제한(formChangedThisRound)
  미소모/미검사. 일반 flipForm은 그대로 라운드 1회 제한
- ★ splitPersonality 효과: flipForm(force) + drawUpToHandSize. 폼 전환 후 새 폼의
  핸드 크기까지 손패 보충 (알터에고 6 / 히어로 4 등)
- ★ VFX.splitForm (이중인격 감마 분열 폼 전환): 초록 감마 이중상(좌우 고스트 분리) +
  formFlip 회전 변신(감마 오라 재사용) + 재결합 섬광 + CHANGE!. formFlip 지연
  디스패치 패턴 재사용
- ★ 폼 전환 이벤트 배선: payConfirm에서 splitPersonality 효과 감지 시 렌더 지연
  디스패치(상태 먼저 → 연출 → onDone 렌더). 신분 카드 스코프로 formChange 연출

**검증:** test_phase3_core 확장 — 일반 재전환 제한/라운드 무시 전환/핸드 크기 드로우 ✓ ·
회귀 전체 통과(core 200판·vfx_index 163건) · 헤드리스: splitForm 폴백 onDone·CHANGE! ✓

**연출 인덱스(40종):** ...(기존 39) + splitForm(이중인격 감마 분열)
**엔진:** flipForm force 옵션 · splitPersonality 효과

**카드 작업:** [01001~01025 진행] → 다음 01026 초인법 사무소. 01xxx 번호순 계속


## v2026.07.09.45 — 코어 #24 원투 펀치 연출 (능력은 기구현) + vfx.play 슬롯
**무엇을:**
- 코어 #24 원투 펀치(one-two-punch, She-Hulk 시그니처): 능력은 이전에 이미 구현됨
  (playCondition:justBasicAttacked + readySelf 효과). 이번엔 연출 + vfx 슬롯 정리
  · 반응(Response): 기본 공격 후에만 플레이 가능 → 자신을 준비(ready) 상태로(추가 행동)
  · justBasicAttacked 플래그: basicAttack이 set, 다른 기본 행동이 reset (기구현 확인)
- ★ VFX.oneTwoPunch (연속 두 방 펀치): ONE!(좌상) 빠른 잽 → TWO!(우하) 강타 +
  충격 링 + 준비 광채 → READY! (원-투 리듬감)
- ★ vfx.play 슬롯 정식화: 원투 펀치 vfx를 basicThwart(오배치) → play로 수정.
  payConfirm의 이벤트 연출 폴백에 play 추가 (basicAttack || play || basicThwart).
  자기 대상 이벤트(readySelf/discardForThreat)는 발동자 카드 스코프로 재생

**검증:** test_phase3_core — 기본공격 후 소진/준비 상태/공격 없이 거부/playCondition ✓ ·
회귀 전체 통과(core 200판·vfx_index 162건) · 헤드리스: ONE!/TWO!/READY! ✓

**연출 인덱스(39종):** ...(기존 38) + oneTwoPunch(연속 펀치)
**vfx 슬롯:** play(일반 이벤트 플레이 연출) 정식화

**카드 작업:** [01001~01024 진행] → 다음 01025 이중인격. 01xxx 번호순 계속


## v2026.07.09.45 — 코어 #24 원투 펀치 + Response(반응) + 준비 시스템
**무엇을:**
- 코어 #24 원투 펀치(one-two-punch, She-Hulk 시그니처) 능력 등록:
  반응(Response) — 자신이 기본 공격을 한 후 → 자신을 준비(ready) 상태로 (추가 행동)
- ★ 반응(Response) 트리거 시스템:
  · basicAttack 실행 시 pl.justBasicAttacked=true 플래그. basicThwart/basicRecover
    등 다른 기본 행동 시 해제(반응 기회 소멸)
  · condCheck에 justBasicAttacked 케이스 추가
  · playCard에 playCondition 검증(범용): cardDef.playCondition = {type} → condCheck
    불충족 시 플레이 거부. Response/조건부 이벤트에 재사용
- ★ readySelf 효과: 자신 소진 해제(준비). 추가 액션 1회 확보
- ★ VFX.oneTwoPunch (She-Hulk 연타): 감마 주먹 궤적 좌우 연속(ONE!/TWO!) +
  준비 완료 펄스(READY!) + 흔들림
- 자기 대상 이벤트 연출 배선: payConfirm에서 readySelf/discardForThreat 효과 이벤트는
  발동자 카드 위에서 vfx 재생(basicAttack/basicThwart 슬롯)

**검증:** test_phase3_core 확장 — 공격 후 소진/플래그/준비/추가공격/공격전 거부 ✓ ·
회귀 전체 통과(core 200판·vfx_index 162건) · 헤드리스: 펀치2회·ONE/TWO/READY ✓

**연출 인덱스(39종):** ...(기존 38) + oneTwoPunch(She-Hulk 연타)
**엔진:** playCondition(플레이 조건) · justBasicAttacked(반응 플래그) · readySelf(자신 준비)

**카드 작업:** [01001~01024 진행] → 다음 01025 이중인격. 01xxx 번호순 계속


## v2026.07.09.44 — 코어 #23 법률 업무 + 폼 제한 + 카드버림/위협제거
**무엇을:**
- 코어 #23 법률 업무(legal-practice, She-Hulk 시그니처, 제니퍼 왈터스) 능력 등록:
  알터에고 행동(저지) — 손에서 최대 5장 버림 → 버린 1장당 메인 스킴 위협 1 제거
- ★ 카드 플레이 폼 제한 (playForm): cardDef.playForm='alter-ego'|'hero'. playCard
  검증 단계에서 폼 불일치 시 거부. 범용(법률 업무 등 폼 전용 카드)
- ★ discardForThreat 효과: ctx.discardUids로 지정한 카드 버림 → 버린 수 × perCard
  만큼 위협 제거(p.max 상한, scheme 지정). event ctx에 discardUids 전달 추가
- ★ 이벤트 버림 선택 UI (eventDiscard 모드): 결제 후 손패에서 버릴 카드 가변 선택
  (최대 N장, 자기 자신 제외) → 선택 표시(빨간 아웃라인+"버림" 뱃지) + 실시간 위협
  제거량 표시 + 확정/취소 버튼. abilityDiscard(고정 수)와 구분되는 가변 선택
- ★ VFX.legalWork (변호사 서류 정리 테마): 신분 카드 위로 법률 서류 4장 솟아오름 +
  APPROVED 도장 쾅 + THWARTED! (지적·깔끔 — She-Hulk 물리 연출과 대비)

**검증:** test_phase3_core 확장 — 3장→위협3/최대5상한/히어로폼거부/playForm ✓ ·
회귀 전체 통과(core 200판·vfx_index 161건) · 헤드리스: 서류4·도장·THWARTED! ✓

**연출 인덱스(38종):** ...(기존 37) + legalWork(변호사 서류)
**엔진:** playForm(폼 제한) · discardForThreat(카드버림→위협제거)
**UI:** eventDiscard(가변 버림 선택)

**카드 작업:** [01001~01023 진행] → 다음 01024 원투 펀치. 01xxx 번호순 계속


## v2026.07.09.43 — 코어 #22 짓밟기 (She-Hulk 광역기) + allEnemies 대상
**무엇을:**
- 코어 #22 짓밟기(ground-stomp, She-Hulk 시그니처 광역기) 능력 등록:
  히어로 행동 — 모든 적(빌런 + 모든 하수인)에게 각 1 피해
- ★ allEnemies 대상 (resolveTarget): 빌런 + 전 플레이어의 교전 하수인 전체.
  광역기(AoE)에 재사용. dealDamage 등 기존 효과가 target:'allEnemies'로 그대로 광역화
- ★ VFX.groundStomp (She-Hulk 지면 강타 광역):
  · 발동자 발밑에서 지면 강타 코어 + 반원 균열선 7방사 + 감마 충격파 링 3겹 확산 +
    화면 폭 충격파 링 2연발 + 강한 흔들림 3연타 + STOMP! (광역 타격감)
- ★ 광역 이벤트 연출 배선: payConfirm에서 이벤트 효과가 target:'allEnemies'면
  발동자 위치 기준 vfx.basicAttack 재생 (chosen 아닌 이벤트도 연출 재생)

**검증:** test_phase3_core 확장 — 빌런/하수인2 각 1 피해/allEnemies 대상 ✓ ·
회귀 전체 통과(core 200판·vfx_index 160건) · 헤드리스: 충격파 3겹·균열·STOMP! ✓

**연출 인덱스(37종):** ...(기존 36) + groundStomp(She-Hulk 광역)
**엔진:** resolveTarget allEnemies(모든 적 광역 대상)

**카드 작업:** [01001~01018 캡틴마블 ✅][01020~01022 She-Hulk 진행] → 다음 01023 법률 업무.
01xxx 번호순 계속


## v2026.07.09.42 — 빌런 최종 격파 대연출 + 격파 대사(라이노 15) + 동적 결과창
**무엇을 (사용자 요청 3건):**
- ★ VFX.villainDefeat — 최종 격파(승리) 대연출 (최대한 화려·과장):
  ① 빌런 카드 중앙 + 격파 대사 말풍선 → ② 격렬한 흔들림(vdrage)과 함께 백색 금
  3줄이 순차로 자람 → ③ 대형 백섬광 + 카드 파편 12조각 방사 비산(카드 이미지 조각) +
  충격파 링 3연발(260→440→640) + 스파크 24 + 흔들림 4연타 →
  ④ 거대 VICTORY! 슬랩(96px) + 회전 후광 광선(무한 회전) → onDone으로 결과창 연결
- ★ QUOTES.rhino.defeat — 라이노 격파 대사 15개 (무너지는 돌진형, 믿기지 않는 패배):
  "말도 안 돼... 이 라이노가..." / "쓰러지는 건... 벽이 아니라... 나였군..." 등. 랜덤
- ★ 동적 결과창 (results-overlay, 승/패 공용):
  · VICTORY!/DEFEAT... 타이틀(확대 등장) + 사유
  · 행들이 좌→우 순차 슬라이드 등장(0.25s 간격): 빌런(단계) / 진행 라운드 /
    영웅별 남은 HP / 전투 기록 줄수
  · 숫자 카운트업 애니메이션(easeOutCubic 850ms, data-countup + rAF)
  · 버튼: 메인 메뉴 / 필드 보기(닫고 최종 필드 확인). 게임오버 배너에 "결과 보기"
    버튼 — 언제든 재열람
- 배선: act()가 게임 종료 전환 감지(overPrev diff). 승리=빌런 위치·이미지 선캡처 →
  villainDefeat(대사 랜덤) → onDone → 결과창+카운트업. 패배=0.7s 후 결과창.
  새 게임/이어하기 시 resultsShown 리셋

**검증:** test_phase3_core 확장 — 최종 격파 승리/사유 ✓ · 회귀 전체 통과 ·
헤드리스: defeat 15개·격파 레이어(카드·금·말풍선·백섬광·파편12·VICTORY·onDone) ✓

**연출 인덱스(36종):** ...(기존 35) + villainDefeat(최종 격파 대연출)
**QUOTES:** rhino { entrance 10, stageUp 10, defeat 15 }
**UI:** results-overlay(동적 결과창) · runCountups(숫자 카운트업)

**카드 작업:** 다음 01022 짓밟기(She-Hulk). 01xxx 번호순 계속
**대사 작업:** 타 빌런 등록 시 entrance 10/stageUp 10/defeat 15 세트로 추가


## v2026.07.09.41 — 빌런 스테이지 전환 UI + 빌런별 전환 대사 (라이노 10개)
**무엇을 (사용자 요청):**
- ★ VFX.stageChange — 빌런 격파 → 다음 단계 진입 전용 UI (무엇이 바뀌었는지 명확히):
  · 어두운 적색 배경 + "STAGE 1 → 2" 코믹 슬랩(확대 등장)
  · 새 스테이지 카드 이미지 슬램 등장 + 발광
  · 새 스탯 칩 3종: HP N/N (리셋 명시) · ATK · SCH — 뭐가 바뀌었는지 한눈에
  · 빌런 성격 전환 대사 말풍선 (한글, 랜덤) + 화면 흔들림. ~2.5초 후 페이드
- ★ QUOTES.rhino.stageUp — 라이노 전환 대사 10개 (성격: 무식한 돌진형, 맞을수록 분노.
  특정 영웅 지칭 없음): "크윽... 이제 슬슬 화가 나는군!" / "지금까진 장난이었다..." 등
- 배선: act() 스테이지 변화 감지(villainStagePrev diff) → STAGE DOWN! KO 버스트 후
  650ms 뒤 stageChange 재생. quoteKey별 randomQuote('stageUp') — 다른 빌런은 대사
  등록 시 자동 적용(말풍선만 생략됨)

**검증:** test_phase3_core 확장 — 격파 시 단계 증가/HP 리셋 ✓ · 회귀 전체 통과
(core 200판·vfx_index 159건 — stageUp 10개 검증 포함) · 헤드리스: 전환 UI 레이어·
STAGE 슬랩·새 스탯·대사 말풍선 ✓

**연출 인덱스(35종):** ...(기존 34) + stageChange(스테이지 전환 UI)
**QUOTES:** rhino { entrance 10, stageUp 10 }

**카드 작업:** [01001~01021 ✅ (캡틴마블 완료, She-Hulk 진행)] → 다음 01022 짓밟기.
**대사 작업:** 클로·울트론 등 다른 빌런 등록 시 entrance/stageUp 각 10개씩 추가


## v2026.07.09.40 — 코어 #21 감마 슬램 (She-Hulk 피니셔) + 누적 피해 효과
**무엇을:**
- 코어 #21 감마 슬램(gamma-slam, She-Hulk 시그니처 피니셔) 능력 등록:
  히어로 행동(공격) — 적에게 X 피해(최대 15). X = 자신의 누적 피해량(maxHp - hp)
- ★ 누적 피해 효과 (EFFECTS.dealDamageSustained):
  · 발동자의 누적 피해(maxHp-hp)만큼 대상 피해, p.max 상한. "자기 상태 기반 가변
    피해" 패턴. 재사용 가능
- ★ VFX.gammaSlam (She-Hulk 피니셔, 과장):
  ① 발동자 감마 차징(초록) + HULK SMASH!
  ② 대상 위로 거대한 감마 주먹이 위에서 내리꽂힘(gammafist)
  ③ 착탄: 대형 감마 코어 폭발 + 파워 링 3겹(200→340→480) + 스파크 20개 +
     강한 흔들림 3연타 + GAMMA SMASH!
- 링크: gamma-slam vfx.basicAttack='gammaSlam' (이벤트 공격 경로)

**검증:** test_phase3_core 확장 — 누적14→14/누적24→15상한/무손상→0/vfx ✓ ·
회귀 전체 통과(core 200판·vfx_index 159건) · 헤드리스: 차징·주먹·대형코어·GAMMA SMASH! ✓
(주의: 빌런 처치 시 스테이지 전환으로 hp 리셋되므로 테스트는 hp 높은 대상으로 검증)

**연출 인덱스(34종):** ...(기존 33) + gammaSlam(She-Hulk 피니셔)
**엔진 효과:** dealDamageSustained(누적 피해량 기반 가변 피해)

**카드 작업:** [01001~01018 캡틴마블 ✅][01020 헬캣·01021 감마슬램 ✅] → 다음 01022 짓밟기
(She-Hulk 이벤트). 01xxx 번호순 계속


## v2026.07.09.39 — She-Hulk 전용 연출(감마 설치/소환) 매핑
**무엇을 (사용자 요청 — She-Hulk 설치 전용 연출):**
- ★ She-Hulk 시그니처 전용 연출 2종 (감마 테마 — 초록빛 괴력, 묵직·파워풀):
  · VFX.gammaInstall (장비 설치): 초록 감마 에너지 응축(코어) + 파워 링 2겹 확산 +
    카드 강화 펄스(초록빛 부풀림) + 강한 흔들림 2연타 + EQUIP!
  · VFX.gammaEnter (동료 소환): 위에서 쿵 내리꽂히듯 착지(gammaslam) + 감마 충격파
    링 + 착지 스파크 + SMASH! (캡틴 마블 별=우아함과 대비되는 묵직한 파워)
- 매핑 등록 (인덱스 방식 유지):
  · HERO_ALLY_SUMMON: she-hulk → gammaEnter
  · HERO_CARD_INSTALL: she-hulk → gammaInstall
  · 헬캣(hero:she-hulk)은 소환 시 gammaEnter, She-Hulk 장비(focused-rage/
    superhuman-strength 등)는 설치 시 gammaInstall 자동 적용
- 설계 원칙 재확인: 능력=EFFECTS/HANDLERS/ACTIONS 인덱스, 연출=MC.VFX/QUOTES +
  HERO_* 매핑. 카드 정의엔 이름/데이터만. 새 영웅은 매핑에 한 줄 추가로 확장

**검증:** 회귀 전체 통과(core 200판·vfx_index 158건) · 헤드리스: gammaInstall
(감마 레이어·강화 펄스·코어/링·EQUIP!) · gammaEnter(슬램·SMASH!) ✓ ·
매핑 확인(헬캣→gammaEnter, She-Hulk 장비→gammaInstall)

**연출 인덱스(33종):** ...(기존 31) + gammaInstall + gammaEnter
**UI 매핑:** HERO_ALLY_SUMMON/HERO_CARD_INSTALL에 she-hulk 추가

**카드 작업:** [01001~01018 캡틴마블 ✅][01020 헬캣 ✅] → 다음 01021 감마 슬램. 01xxx 번호순.
  ※ She-Hulk 전용 연출 준비 완료 — 이후 She-Hulk 카드는 설치/소환 시 감마 연출 자동


## v2026.07.09.38 — 코어 #20 헬캣 (She-Hulk 시그니처 시작) + returnToHand 효과
**무엇을:**
- She-Hulk 카드군 시작 (01020~). 코어 #20 헬캣(hellcat, 시그니처 동료) 능력 등록:
  행동 — 헬캣을 소유자 손으로 반환 (HP 리셋 — 재배치 시 새 카드처럼)
- ★ returnToHand 효과 (EFFECTS.returnToHand, 범용):
  · self(발동 카드)를 플레이 영역에서 제거 → 부착물 해제 → 새 인스턴스로 손에 추가
    (makeInstance로 HP/소진/카운터 등 상태 초기화)
  · 활성 능력으로 발동. 자기 반환형 카드에 재사용
- 연출: 소환=공용 allyEnter, 공격=공용 gunshot, 저지=공용 patrol (베이직 방침)
  · She-Hulk 시그니처 동료지만 전용 연출은 She-Hulk 본격 플레이 시 추가 예정
    (HERO_ALLY_SUMMON 매핑에 she-hulk 추가하면 자동 적용)

**검증:** test_phase3_core 확장 — 손 반환/플레이 영역 제거/HP 리셋/손패 +1 ✓ ·
회귀 전체 통과(core 200판)

**엔진 효과:** returnToHand (카드 손 반환 + 상태 리셋)

**카드 작업:** [01001~01018 캡틴마블 ✅][01020 헬캣 ✅] → 다음 01021 감마 슬램
(She-Hulk 이벤트). 01xxx 번호순 계속
  ※ She-Hulk 시그니처 진행 중 — 전용 소환/설치 연출은 영웅 본격화 시 매핑 추가


## v2026.07.09.37 — 코어 #18 에너지 채널 + 카운터 능력(충전/발사) 시스템
**무엇을:**
- 코어 #18 에너지 채널(energy-channel, 캡틴 마블 시그니처 업그레이드) 능력 등록:
  · 충전(행동): 에너지 자원 X개 소비 → 카운터 X개 축적(게임 끝까지 누적)
  · 발사(히어로 행동): 카드 버림 → 적에게 카운터당 2 피해(최대 10, 최소 카운터 1)
- ★ 카운터 능력 시스템 (counterAbility — 충전/발사 2단):
  · cardDef.counterAbility = { charge:{resource}, fire:{perCounter, max, minCounters, discardSelf} }
  · ACTIONS.counterCharge: 지불한 자원의 해당 아이콘 수만큼 카운터 축적(가변 코스트).
    지불 요소 검증 + executePayment + counters 누적
  · ACTIONS.counterFire: 카운터당 피해(max 상한) + 카드 버림. minCounters 검증
  · 재사용: 카운터 축적형 카드(에너지 채널류)에 데이터 선언만으로 적용
  · UI: 카드 슬롯에 ⚡충전 버튼(자원 선택 팝업 — 에너지 아이콘 카드만, 카운터 미리보기) +
    💥발사 버튼(예상 피해 표시, 대상 선택 모드 counterFire). 카운터 뱃지 ⚡N
- 연출: 설치=캡틴 마블 전용(starInstall) / 발사=광자 폭발(photonBlast) 재사용

**검증:** test_phase3_core 확장 — 충전 +2/누적 5/발사 최대 10/발사 후 버림/카운터 0
발사 거부 ✓ · 회귀 전체 통과(core 200판·vfx_index)

**엔진 시스템:** counterAbility(충전/발사) · counterCharge/counterFire 액션
**UI:** 카운터 충전 팝업 · 발사 대상 선택 · 카운터 뱃지

**카드 작업:** [01001~01018 ✅] → 다음 01019 이하 캡틴 마블 잔여 시그니처. 01xxx 번호순 계속.
  ※ 캡틴 마블 핵심 콤보(에너지 흡수+광자 폭발+에너지 채널) 전부 동작


## v2026.07.09.36 — 빌런 페이즈 단계별 진행 + 페이즈 배너 + 공개 카드 확인 (사용자 요청 D)
**무엇을:**
- ★★ 빌런 페이즈 단계별 진행 시스템 (엔진 결정성 유지):
  · 엔진: endPlayerPhase에 stepwise 옵션 → G.villainStepMode=true.
    processVillainQueue는 stepMode면 자동 드레인 안 함. ACTIONS.villainStep이
    큐에서 정확히 1스텝 실행(MC.villainStepOnce). endRound에서 stepMode 해제
  · 결정성: 모든 진행이 dispatch된 액션(villainStep). 테스트로 비단계와 동일
    최종 상태 검증(위협/HP/덱). 기존 비단계 경로(테스트·시뮬) 무변경
  · UI: maybeStepVillain 루프 — G.vq[0]를 미리 보고 스텝 라벨 표시(#stepstrip:
    "⚡ 위협 배치"/"⚔ 리노 활성화"/"🃏 조우 카드 배분"/"👁 조우 카드 공개"/"🔄 라운드
    정리") → 딜레이 후 act(villainStep) → 각 스텝의 diff 연출(피격/상태/KO/체력바)
    자동 재생 → 다음 스텝. 방어/인터럽트 pending 시 정지, 해소 후 act 훅이 자동 재개
  · 이어하기: stepMode 저장 중이었으면 로드 후 자동 재개
- ★ 페이즈 전환 배너 (VFX.phaseBanner): 화면을 가로지르는 대형 코믹 슬랩.
  "VILLAIN PHASE!"(적색)/"HERO PHASE!"(청색) + 한글 부제. 페이즈 종료 버튼 →
  UI.endPhase()가 배너 후 단계 진행 시작
- ★ 공개 카드 확인 (사용자 요청 — 빌런 조우 때 나오는 카드 확인 가능):
  · 엔진: G.revealLog — 빌런 페이즈에 공개된 조우 카드(resolveEncounterCard) +
    부스트 카드(공격/스킴 부스트, boost값 포함) 기록. startVillainPhase에서 리셋
  · VFX.revealCard: 공개 순간 화면 중앙에 카드 이미지 크게(회전 등장→유지→소멸) +
    타입 라벨(배반/하수인/사이드 스킴/부스트)
  · UI reveal-strip: 메인 스킴 아래 "이번 라운드 공개 (N)" 썸네일 목록 — 클릭하면
    카드 상세(UI.info). 다음 빌런 페이즈까지 유지되어 언제든 확인 가능
  · 부스트 카드는 +N 뱃지 표시, 로그에도 "부스트 카드: 이름 (+N)" 기록

**검증:** test_phase3_core 확장 — 단계별 모드 6종(복귀/해제/결정성 3종/revealLog) ✓ ·
회귀 전체 통과(core 200판 비단계 경로 무변경 확인) · 헤드리스: phaseBanner·revealCard
(배반/부스트 라벨) ✓

**연출 인덱스(31종):** ...(기존 29) + phaseBanner + revealCard
**엔진:** villainStepMode/villainStep/revealLog · UI: maybeStepVillain/stepstrip/reveal-strip

**카드 작업:** [01001~01017 ✅] → 다음 01018 에너지 채널. 01xxx 번호순 계속


## v2026.07.09.35 — UI 개선: 움직이는 체력바 + 하수인/동료 체력바 + 위협 상승/가속 분리
**무엇을 (사용자 피드백 3건 반영):**
- ★ 움직이는 슬래시 체력바: cbar-fill의 대각(-55deg) 슬래시 패턴을 별도 ::before
  레이어로 분리 → 계속 흐르는 애니메이션(cbarslash .7s 무한). 정적이던 바가 살아있음
- ★ 하수인/동료 체력바 추가: 기존엔 "HP N" 텍스트 뱃지만 있었음 →
  comicBar mini 옵션(작은 버전) 추가하여 교전 하수인·동료에 실제 체력바 표시.
  barSnapshot에 하수인/동료 HP 키 추가 → 피격 시 부드러운 전환 애니메이션도 적용
- ★ 메인 스킴 위협 상승/가속 분리 (룰 명확화):
  · execStep threat: 기본 상승률(플레이어 수)과 가속(스킴 가속 아이콘 + 가속 토큰)을
    분리 계산·로그 ("메인 스킴 위협: 기본 +N · 가속 +M = +T")
  · UI: 메인 스킴에 "📈 다음 +T (기본 N + 가속 M)" 칩 + 가속 아이콘/토큰 분리 표시
- 남은 피드백(다음 작업): 빌런 페이즈(조우 공개·적 활성화) 단계별 진행 연출 — 현재
  processVillainQueue가 큐를 한 번에 비워 밋밋함. 엔진 결정성 유지하며 UI 단계별
  애니메이션 필요(구조 큼 — 별도 세션 집중)

**검증:** 회귀 전체 통과(core 200판·vfx_index 155건) · 위협 분리 로그 확인
(기본 +1 · 가속 +3 = +4) · 하수인/동료/움직이는 바 렌더 확인

**UI:** comicBar mini · cbarslash(움직이는 슬래시) · 하수인/동료 체력바 ·
  위협 상승 예고 칩(token-threatgain)

**카드 작업:** [01001~01017 ✅] → 다음 01018 에너지 채널. 01xxx 번호순 계속
**UI 개선 대기:** 빌런 페이즈 단계별 진행 연출(D)


## v2026.07.09.34 — 코어 #17 우주 비행 + 방어 인터럽트/부분 방지 + Aerial 부양 연출
**무엇을:**
- 코어 #17 우주 비행(cosmic-flight, 캡틴 마블 시그니처 업그레이드) 능력 등록:
  ① 지속 효과 — Aerial 트레잇 부여(grantsTrait) → 헬멧 DEF+2·위기저지 보너스 완전 연동
  ② 방어 인터럽트 — 피해받을 때 우주 비행 버림 → 피해 3 방지(1회용)
- ★ 부분 피해 방지 효과 (EFFECTS.preventAmount): 방어 pending 피해량을 N 감소,
  0 이하면 방어 완결. preventAll(전량)과 구분. 범용
- ★ 방어 인터럽트 액션 (ACTIONS.useDefenseInterrupt): 방어 pending 시 플레이 영역의
  defenseInterrupt 카드 발동 → preventAmount + discardSelf. 
  cardDef.defenseInterrupt = { prevent, discardSelf }. 재사용
  · UI: 방어 선언 존에 방어 인터럽트 카드(우주 비행) 버튼 추가(피해 N 방지)
- ★ Aerial 부양 지속 연출 (사용자 요청):
  · playerHasTrait('aerial') 판정으로 신분 카드 슬롯에 aerial-float 클래스
  · 카드가 위로 떠오르고(translateY) 부드러운 상하 부유(2.6s 무한) + 청색 드롭섀도우 +
    바닥 타원 그림자(부유에 맞춰 축소/투명도 변화). 특성 잃으면 클래스 제거로 하강
- 설치 연출: 캡틴 마블 매핑(starInstall)이 우주 비행에도 자동 적용

**검증:** test_phase3_core 확장 — Aerial 부여/헬멧 DEF+2 연동/방어 pending/3 방지/
자체 버림/버린 후 Aerial 상실 ✓ · 회귀 전체 통과(core 200판·vfx_index 155건)

**엔진 시스템:** preventAmount(부분 방지) · useDefenseInterrupt(방어 인터럽트 액션) ·
  defenseInterrupt(카드 정의)
**UI:** Aerial 부양 지속 상태 표현(aerial-float)

**카드 작업:** [01001~01017 ✅] → 다음 01018 에너지 채널(Energy Channel, 캡틴 마블 업그레이드).
01xxx 번호순 계속. ※ Aerial 연동(헬멧/위기저지/우주비행) 완전 동작 확인


## v2026.07.09.33 — 코어 #16 캡틴 마블 헬멧 + 패시브 스탯 수정 + 시그니처 설치 연출
**무엇을:**
- 코어 #16 캡틴 마블 헬멧(captain-marvel-helmet) 능력 등록:
  지속 효과 — 캡틴 마블 DEF +1 (Aerial 트레잇 보유 시 +2 대신)
- ★ 패시브 스탯 수정 시스템 (범용 — 지속 효과 업그레이드/서포트 전반):
  · statOf에 passiveStatMod 파이프라인 추가. 플레이 영역 카드의 statMod 합산
  · cardDef.statMod = { stat, amount, cond?, amountIf?:{cond, amount} }
    · cond: 조건 충족 시에만 적용 / amountIf: 조건 충족 시 대체값(헬멧 Aerial +2)
  · 앞으로 방탄조끼/불굴의 정신/전술적 재능 등 지속 스탯 업그레이드에 재사용
- ★ 시그니처 설치 연출 매핑 (HERO_CARD_INSTALL) + 우선순위 정리:
  · 설치 연출 우선순위: ① 카드 자체 vfx.install ② 영웅별 매핑(HERO_CARD_INSTALL)
    ③ 공용 install
  · 스파이더맨 장비(웹슈터/트레이서/메이/거미줄)는 카드별 vfx.install 유지,
    캡틴 마블 시그니처 장비(헬멧 등)는 매핑으로 starInstall
  · 등록: captain-marvel → starInstall. 새 영웅은 한 줄 추가
- ★ VFX.starInstall (캡틴 마블 장비 장착): 작은 별 6개가 카드로 모여들며 금-청
  에너지가 감싸고 안착 + 충격 링 + EQUIP! (소환보다 담백)

**검증:** test_phase3_core 확장 — 헬멧 DEF+1/Aerial 시 +2 대체/statMod 등록 ✓ ·
회귀 전체 통과(core 200판·vfx_index 155건) · 헤드리스: 별 장착 레이어·EQUIP! ✓

**연출 인덱스(29종):** ...(기존 28) + starInstall(캡틴 마블 장비 설치)
**엔진 시스템:** passiveStatMod(지속 스탯 수정, statMod) 
**UI 매핑:** HERO_CARD_INSTALL(영웅별 시그니처 장비 설치 연출)

**카드 작업:** [01001~01016 ✅] → 다음 01017 우주 비행(Cosmic Flight, grantsTrait:aerial
추가 필요 — 헬멧/위기저지 Aerial 연동). 01xxx 번호순 계속


## v2026.07.09.32 — 코어 #14 에너지 흡수(검증) + #15 알파 플라이트 기지 + 활성능력 확장
**무엇을:**
- 코어 #14 에너지 흡수(energy-absorption): 순수 자원 카드(에너지 3). 이미 완성 상태라
  검증만 — 광자 폭발 키커(에너지) 충족 + 결제 시 불타는 테두리 표시 확인. 테스트 추가
- 코어 #15 알파 플라이트 기지(alpha-station) 능력 등록:
  행동 — 소진 + 손에서 카드 1장 버림 → 1장 드로우(캐롤 댄버스 알터에고면 2장)
- ★ 활성 능력 시스템 확장 (재사용):
  · activatedAbility.discardCost: 손에서 카드 N장 버림 추가 코스트.
    액션 a.discardUids로 지정, 검증 후 버림. 헬리캐리어 등 재사용
  · UI: discardCost 있으면 버릴 카드 선택 모드(abilityDiscard) → 손패 탭으로 선택,
    필요 수 채우면 능력 실행
- ★ 조건부 신분 판정 (condCheck 확장):
  · isIdentity/notIdentity: 현재 신분(폼) 카드가 특정 코드인지 (캐롤 댄버스=01010b 등)
  · 알파 기지: draw 2(isIdentity 01010b) / draw 1(notIdentity 01010b) 상호배타 조건부

**검증:** test_phase3_core 확장 — 에너지흡수(자원3·키커) · 알파기지(비캐롤 1장/캐롤 2장/
버림 미지정 거부/소진) ✓ · 회귀 전체 통과(core 200판·vfx_index 155건)

**엔진 시스템:** activatedAbility.discardCost(버림 코스트) · condCheck isIdentity/notIdentity
**연출:** 신규 없음 (자원 카드·드로우 능력은 연출 불필요)

**카드 작업:** [01001~01015 ✅] → 다음 01016 캡틴 마블 헬멧(업그레이드). 01xxx 번호순 계속


## v2026.07.09.31 — 결제 화면 특별 카드 시각화 (불타는 노란 테두리)
**무엇을:**
- ★ 결제 팝업에서 "특별한 결제 카드"를 불타는 노란 테두리로 강조 (사용자 요청 —
  지불 편의). 앞으로 키커/자원 생성 카드가 많이 나오므로 선제 구축:
  · 대상 ① 자원 생성 카드(resourceGenerator — 웹 슈터 등)
    ② 지금 플레이하는 카드의 키커 자원을 인쇄한 손패 카드(광자 폭발=에너지 키커 →
       에너지/와일드 자원 카드)
  · kickerResources(cardDef): effects의 cond:paidWith에서 키커 자원 집합 추출
  · isHotPayCard(cand, kickerSet): 자원 생성 or 키커 자원 보유 판정
  · 결제 타일에 hot 클래스 → 불타는 그라디언트 테두리(주황-노랑 흐름 애니메이션) +
    발광. 선택 시 더 밝게
- 지불 시 어떤 카드가 추가 효과를 유발하는지 한눈에 보임 → 최적 결제 유도

**검증:** hot 판정 로직 — 광자폭발 키커=energy/메이숙모(energy)=hot/회전발차기(mental)=일반/
웹슈터(자원생성)=항상 hot ✓ · 회귀 전체 통과(core 200판·vfx_index 155건)

**UI:** 결제 팝업 hot 시각화(kickerResources/isHotPayCard) — 키커·자원생성 카드 강조

**카드 작업:** [01001~01013 ✅] → 다음 01014 에너지 흡수(캡틴 마블 자원). 01xxx 번호순 계속.
※ 이제 키커 있는 카드 결제 시 유발 자원이 불타는 테두리로 표시됨


## v2026.07.09.30 — 코어 #13 광자 폭발(캡틴 마블 메인 딜링기) + 키커 시스템
**무엇을:**
- 코어 #13 광자 폭발(photon-blast, 캡틴 마블 메인 딜링기) 능력 등록:
  공격 — 적 1명에게 5 피해 + 에너지 자원으로 결제 시 카드 1장 드로우
- ★ 키커 조건 시스템 (condCheck에 paidWith 추가):
  · cond:{type:'paidWith', resource:'energy', count?} — 결제에 특정 자원 아이콘을
    썼는지 판정(와일드 충족). runEffectList 조건부 효과와 결합
  · 앞으로 "특정 자원으로 냈으면 추가 효과" 키커 카드 전반에 재사용
  · 광자 폭발: draw 효과에 cond:paidWith energy
- ★ VFX.photonBlast (캡틴 마블 메인 딜링기, 과장되게):
  ① 발동자 광자 에너지 응축(차징 글로우, 금-청 그라디언트) + CHARGING...
  ② 대상으로 거대 광자 빔 발사(두꺼운 금-청 빔, 강한 발광)
  ③ 착탄 폭발: 폭발 코어 + 다중 에너지 링(180→300→420) + 방사 스파크 16개 +
     강한 흔들림 2연타
  ④ KA-BOOM! 온오마토페
- 링크: photon-blast vfx.basicAttack='photonBlast' (이벤트 공격 경로 재사용)

**검증:** test_phase3_core 확장 — 5피해/에너지 결제 드로우/비에너지 미발동/키커 조건 ✓ ·
회귀 전체 통과(core 200판·vfx_index 155건) · 헤드리스: 차징·빔·폭발코어·KA-BOOM! ✓

**연출 인덱스(28종):** ...(기존 27) + photonBlast(캡틴 마블 메인 딜링기)
**엔진 시스템:** 키커 조건(paidWith) — 특정 자원 결제 시 추가 효과

**카드 작업:** [01001~01013 ✅] → 다음 01014 에너지 흡수(캡틴 마블 자원). 01xxx 번호순 계속


## v2026.07.09.29 — 코어 #12 위기 저지 + 플레이어 트레잇 판정 + 조건부 효과 시스템
**무엇을:**
- 코어 #12 위기 저지(crisis-interdiction, 캡틴 마블 시그니처 이벤트) 능력 등록:
  저지 — 위협 2 제거 + Aerial 트레잇 보유 시 다른 스킴에서 2 추가 제거
- ★ 플레이어 트레잇 판정 시스템 (범용 — Aerial/Armor 등 조건부 트레잇):
  · MC.playerHasTrait(G, pl, trait): 신분(현재 폼) 트레잇 + 플레이 영역 카드가
    부여하는 트레잇(cardDef.grantsTrait) 합산 판정
  · condCheck에 hasTrait 케이스 추가
- ★ 조건부 효과 시스템 (runEffectList 확장):
  · effects의 step에 cond가 있으면 condCheck 통과 시에만 실행. 범용 —
    앞으로 모든 조건부 효과(트레잇/폼/상태 조건)에 재사용
  · 위기 저지: 두 번째 removeThreat에 cond:{type:hasTrait, trait:aerial}
- 연출: 저지 이벤트 — 공용 patrol 재사용 (캡틴 마블 전용 아님)
- 주의: Cosmic Flight(01017)에 grantsTrait:'aerial' 부여는 그 카드 등록 시 추가 예정
  (현재 미등록). 위기 저지의 Aerial 보너스는 그때 완전 연동됨

**검증:** test_phase3_core 확장 — Aerial 없으면 2제거/트레잇 판정 시스템 ✓ ·
회귀 전체 통과(core 200판·vfx_index 154건)

**엔진 시스템:** playerHasTrait(트레잇 판정) · runEffectList 조건부 효과(cond)
**연출 인덱스(27종):** 신규 없음(patrol 재사용)

**카드 작업:** [01001~01012 ✅] → 다음 01013 광자 폭발(캡틴 마블 이벤트). 01xxx 번호순 계속.
※ Cosmic Flight 등록 시 grantsTrait:aerial 추가 필요(위기 저지 완전 연동)


## v2026.07.09.28 — 캡틴 마블 시그니처 동료 소환 연출(starSummon) + 시그니처 매핑
**무엇을:**
- 스파이더 우먼(캡틴 마블 시그니처 동료) 전용 소환 연출 추가 (사용자 요청):
  이전 버전에서 모든 동료가 공용 allyEnter로 일괄 처리되던 문제 수정
- ★ 시그니처 동료 소환 매핑 (HERO_ALLY_SUMMON 레지스트리):
  · 동료 정의의 hero 필드(소속 영웅)로 영웅별 전용 소환 연출 매핑
  · 등록: captain-marvel → starSummon. 미등록 영웅/일반 동료(hero 없음)는 공용 allyEnter
  · 새 영웅 시그니처 동료는 레지스트리에 한 줄 추가로 확장
- ★ VFX.starSummon (캡틴 마블 할라 스타 소환, 세련되게):
  금빛-청색 에너지 별(할라 스타, 별 클립패스)이 회전하며 응축 등장 + 방사 광선 6방향 +
  발광 버스트 + 충격 링 + 카드 빛에서 나타나듯 페이드 + "HIGHER, FURTHER, FASTER!"
- 매핑 검증: 스파이더우먼(hero:captain-marvel)→starSummon / 블랙위도우(hero 없음)→allyEnter

**검증:** 회귀 전체 통과(core 200판·vfx_index 153건) · 헤드리스: 별 레이어·카드 등장·
할라스타/광선 HTML ✓ · 매핑 로직 검증 ✓

**연출 인덱스(27종):** ...(기존 26) + starSummon(캡틴 마블 시그니처 동료 소환)
**UI 매핑:** HERO_ALLY_SUMMON(영웅별 시그니처 동료 소환 연출)

**카드 작업:** [01001~01011 ✅] → 다음 01012 위기 저지(캡틴 마블 이벤트). 01xxx 번호순 계속


## v2026.07.09.27 — 코어 01xxx 번호순 진행 시작 + 스파이더 우먼 + 공용 혼란/강인함 연출
**무엇을:**
- ★ 진행 기준 전환: 스파이더맨 덱 단위 → 코어세트 01xxx 전체 번호순.
  주의: 기존 ✅(todoFx=N) 카드 상당수가 마이그레이션 자동 해제분으로 실제
  효과·훅·연출이 비어있음("가짜 완료"). 번호순으로 하나씩 실제 검증하며 진행
  · 01xxx 플레이어 카드 93장 중 제대로 등록된 건 스파이더맨 코어+블랙위도우+내뒤로뿐
- 코어 #11 스파이더 우먼(spider-woman-ally, 캡틴 마블 시그니처) 능력 등록:
  반응 — 등장 후 빌런 혼란(whenPlayed 훅 → applyStatus villain confused)
- ★ 공용 상태이상 연출 2종 (앞으로 광범위 재사용 — 사용자 요청으로 과장되게):
  · VFX.confuse: 대상 머리 위 별 5개가 궤도 회전 + 중앙 소용돌이(💫) + 대상 휘청임
    (wobble) + CONFUSED!
  · VFX.toughGain: 대상에 팔각 방어막 셸이 씌워지고 금속 광택 스윕 + 단단해짐 펄스 +
    화면 흔들림 + TOUGH!
- ★ 상태이상 diff 자동 연출: act 래퍼가 collectStatuses 스냅샷 비교 → confused/tough
  증가 시 해당 연출 자동 재생. 카드에 vfx 연결 없이도 동작(어느 카드가 걸든 자동).
  im-tough 등 기존 강인함 카드도 자동 적용
- 스파이더 우먼 연출: 소환=공용 allyEnter, 공격/저지=공용, 혼란=공용 confuse

**검증:** test_phase3_core 확장 — 등장 후 빌런 혼란/플레이 영역 배치 ✓ · 회귀 전체
통과(core 200판·vfx_index 153건) · 헤드리스: confuse(소용돌이·휘청·CONFUSED!)·
toughGain(방어막·광택·TOUGH!) ✓

**연출 인덱스(26종):** ...(기존 24) + confuse + toughGain (공용 상태이상)
**엔진/UI:** 상태이상 diff 자동 연출(collectStatuses)

**카드 작업:** [01001~01009 스파이더맨 ✅][01011 스파이더우먼 ✅] → 다음 01012 위기 저지
(캡틴 마블 이벤트). 01xxx 번호순 계속. ※ 기존 ✅ 카드도 실제 능력·연출 확인 필요


## v2026.07.09.26 — 기본 카드 내 뒤로! + 공용 취소 연출(cancelReveal) + 커스텀 interruptEffect
**무엇을:**
- 기본 카드 내 뒤로!(get-behind-me) 능력 등록:
  히어로 인터럽트 — 배반 공개 시 "공개 시" 효과 취소 + 대신 빌런이 당신을 공격
- ★ 커스텀 interruptEffect 핸들러 지원 (재사용):
  · interruptEffect가 'cancelReveal'이면 취소만, HANDLERS에 등록된 이름이면
    취소 플래그 세운 뒤 커스텀 핸들러 실행(추가 효과), 아니면 def.effects 실행
  · get-behind-me: getBehindMe 핸들러 → 취소 + EFFECTS.villainAttacks(방어 pending)
  · 앞으로 "취소 + 추가 대가" 형태 인터럽트에 재사용
- ★ VFX.cancelReveal (공용 취소 연출): 발동자 카드 위에 회색 X 마크 + 카드 순간
  탈색(그레이스케일 펄스) + CANCELED!. 기본 취소 카드 공용(스파이더맨 senseCancel과
  달리 담백). 앞으로 첩보술/그래플링 훅 등 기본 취소 카드에 재사용
- 링크: get-behind-me vfx.interrupt='cancelReveal'

**검증:** test_phase3_core 확장 — 배반 공개 인터럽트/취소/대신 빌런 공격/카드 버림 ✓ ·
회귀 전체 통과(core 200판·vfx_index 150건) · 헤드리스: 취소 X·탈색·CANCELED! ✓

**연출 인덱스(24종):** ...(기존 23) + cancelReveal(공용 취소)
**엔진 시스템:** 커스텀 interruptEffect 핸들러(취소 + 추가 효과)

**카드 작업:** [코어 스파이더맨 #1~9 ✅][기본 블랙위도우·내뒤로! ✅] → 다음 기본 카드
(01082 불굴의 정신, 01083 모킹버드, 01084 닉 퓨리, 01088~90 자원 카드 등)


## v2026.07.09.25 — 공용 동료 소환 연출(allyEnter) + 파괴 연출 재사용
**무엇을:**
- 동료 소환/파괴 연출 보강 (사용자 요청):
  · 기존 신규 설치 감지가 support/upgrade만 봐서 동료(allies) 소환 연출이 없었음
  · 신규 설치 감지에 allies 추가 → 동료 소환 시 allyEnter 연출 재생
- ★ VFX.allyEnter (공용 동료 소환): 카드가 아래에서 튀어올라 살짝 오버슈트 후
  착지(cubic-bezier 바운스) + 발밑 충격 링 + 화면 흔들림 + ALLY! 임팩트.
  베이직/성향 동료 전부 공용 (테마: 지원군의 힘찬 등장)
- 동료 파괴: 기존 공용 onDefeat(K.O. 파편 연출) 그대로 재사용 (요청대로 파괴는 동일)

**검증:** 회귀 전체 통과(core 200판·vfx_index 149건) · 헤드리스:
소환(등장 클래스·착지 충격링·ALLY!) · 파괴(K.O. 파편·K.O.! 재사용) ✓

**연출 인덱스(23종):** ...(기존 22) + allyEnter(공용 동료 소환)
  · 소환=allyEnter / 파괴=onDefeat(공용 재사용)

**카드 작업:** [코어 스파이더맨 #1~9 ✅][기본 블랙위도우 ✅] → 다음 기본 카드
(01078 내 뒤로!, 01082 불굴의 정신, 01083 모킹버드, 01084 닉 퓨리 등).
동료 카드는 이제 소환 연출 자동 적용됨


## v2026.07.09.24 — 기본 카드 블랙 위도우 + 동료 인터럽트 확장 + 공용 사격 연출
**무엇을:**
- 기본(Basic) 카드 등록 시작. 방침: 시그니처가 아닌 성향/기본 카드는 전용 연출
  안 만들고 공용 연출 재사용 (공격=공용 사격, 저지=기본 patrol)
- 블랙 위도우(black-widow-ally) 능력 등록:
  인터럽트 — 조우덱 카드 공개 시 → 소진 + 🧠멘탈 1 지불 → 취소·버림 → 1장 추가 공개.
  모든 조우 카드 대응(any), 폼 무관
- ★ 범용 인터럽트 시스템 확장 (동료/서포트 인터럽트):
  · collectRevealInterrupts: 손패 히어로 인터럽트 + 플레이영역 동료/서포트 인터럽트
    둘 다 수집. encounterType 'any' 지원, 폼 조건(io.form), 소진 상태 확인
  · resolveRevealInterrupt: 손패 이벤트 vs 동료/서포트 인터럽트 분기.
    동료형은 소진 + interruptOn.pay 자원 지불 + 취소 + thenReveal(추가 공개)
  · interruptOn 확장 필드: {encounterType, form?, pay?:{type,count}, thenReveal?}
  · UI: 인터럽트 배너가 손패+플레이영역 카드 모두 표시(자원 요구 힌트),
    useInterrupt/_fireInterrupt가 동료 카드·자원 지불 처리
- ★ VFX.gunshot (공용 사격): 발동자→대상 총알 3발 순차 발사 + 총구 섬광 +
  명중 임팩트 링 + BANG! (베이직 공격 동료/카드 공용 재사용)
- 링크: black-widow-ally vfx { basicAttack:'gunshot', basicThwart:'patrol'(재사용) }

**검증:** test_phase3_core 확장 — 조우 공개 인터럽트/동료 후보/취소/소진/추가 공개/
any 타입 ✓ · 회귀 전체 통과(core 200판·vfx_index 149건) · 헤드리스: 사격 궤적·섬광·
총알·BANG! ✓

**연출 인덱스(22종):** ...(기존 21) + gunshot(공용 사격)
**엔진 시스템:** 동료/서포트 인터럽트(interruptOn.pay/thenReveal/form)

**카드 작업:** [코어 스파이더맨 #1~9 ✅][기본 블랙위도우 ✅] → 다음 기본 카드
(01078 내 뒤로!, 01082 불굴의 정신, 01083 모킹버드, 01084 닉 퓨리 등)


## v2026.07.09.23 — 코어 #9 거미줄에 감기다 + 부착물 공격 인터럽트 + 부착 해제 연출
**무엇을:**
- 코어 #9 (webbed-up): 히어로 폼 전용, 적에 부착(적당 최대 1장).
  강제 인터럽트 — 부착된 적이 공격 시도 시 → 카드 버림(공격 대체) → 그 적 기절.
  실질 2번 차단(대체 + 기절로 다음 공격 스킵)
- ★ 부착물 공격 인터럽트 시스템 (재사용):
  · enemyActivation 기절 체크 직후 fireAttachAttackInterrupt 호출
  · 적의 부착물 중 attachAttackInterrupt 훅 발화 → true 반환 시 활성화 중단(공격 대체)
  · webbed-up: webbedUpInterrupt 핸들러(detach + 버림 + 기절 + return true)
- ★ maxPerTarget 제약: 부착 시 대상당 최대 장수 검증(playCard upgrade 부착 경로)
- ★ 부착 해제 연출 감지 (재사용): act 래퍼가 collectAttachments 스냅샷 비교 →
  사라진 부착물의 vfx.detach 연출을 적 위치에 재생
- VFX.webCocoon: 여러 방향에서 거미줄 가닥이 적으로 날아와 감싸고 거미줄 고치
  오버레이 + WEBBED! (스파이더맨 전용 부착 연출)
- VFX.webTear: 부착 해제 시 거미줄이 좌우로 갈라져 찢기고 파편 튐 + RIPP!
- 링크: webbed-up vfx { install:'webCocoon', detach:'webTear' }

**검증:** test_phase3_core 확장 — 부착/공격 대체/기절/버림/부착 해제/무피해/
다음 활성화 기절 스킵/maxPerTarget ✓ · 회귀 전체 통과(core 200판·vfx_index 147건) ·
헤드리스: webCocoon(감김·WEBBED!·고치)·webTear(찢김·RIPP!) ✓

**연출 인덱스(21종):** ...(기존 19) + webCocoon + webTear
**vfx 슬롯:** ...(기존) + detach(부착 해제 연출용)
**엔진 시스템:** 부착물 공격 인터럽트(attachAttackInterrupt) · maxPerTarget 제약

**카드 작업:** [코어 #1~9 ✅] → 스파이더맨 시그니처 대부분 완료. 남은 스파이더맨
카드 및 코어 공용 카드(각 관점 기본 카드) 계속


## v2026.07.09.22 — 코어 #8 웹 슈터 자원 생성 시스템 검증·정립
**무엇을:**
- 코어 #8 (web-shooter): 이전 세션에 자원 생성 시스템과 함께 등록 완료된 상태였음
  (uses:3, resourceGenerator:{form:hero, exhaust, counter:1, icons:{wild:1}}, webInstall).
  이번 세션은 자원 생성 시스템이 "차후 부착물 제거용 자원 원천"으로 제대로
  정립됐는지 전면 검증·확인
- ★ 자원 생성 시스템 (범용 인프라 — 이미 구축돼 있음을 확인):
  · cardDef.resourceGenerator = { form?, exhaust?, counter?, icons } 선언
  · 결제 요소 {kind:'card', uid} → elementIcons/executePayment가 폼·소진·카운터
    조건 검증 후 자원 아이콘 제공. 카운터 차감, 0이 되면 부착 해제 후 자동 버림
  · makeInstance가 def.uses → inst.counters 초기화
  · UI: 결제 팝업에 자원 생성 카드 후보 노출(폼/소진/카운터 조건, 🕸카운터 표시),
    자동선택에서는 제외(카운터 절약 — 수동만)
  · ★ 와일드 자원이 physical/mental/energy/wild 모든 requires 유형 커버 확인 →
    차후 "빌런/음모/적 부착물 제거 (와일드 N개 필요)" 카드가 requires:{type:'wild'}
    패턴으로 웹 슈터 자원을 원천으로 쓸 수 있음
- 설치 연출: 스파이더맨 전용 webInstall 재사용

**검증:** 웹 슈터 자원 생성 전 흐름 — uses=3 초기화/결제 편입(와일드 1 생성)/소진/
카운터 차감/3회 후 자동 버림/히어로 폼 전용/와일드 모든 유형 커버 ✓ ·
회귀 전체 통과(core 200판·vfx_index 145건)

**연출 인덱스(19종):** 신규 없음(webInstall 재사용)
**엔진 시스템:** resourceGenerator 자원 생성(검증 완료 — 부착물 제거 자원 원천)

**카드 작업:** [코어 #1~8 ✅] → 다음 코어 #9 (webbed-up 적 부착 공격 무효화 — 부착
시스템 활용) 등. 부착물 제거 카드는 웹 슈터 와일드 자원을 requires로 소모하게 설계


## v2026.07.09.21 — 코어 #7 스파이더 트레이서 + 범용 부착 시스템
**무엇을:**
- ★ 범용 부착 시스템 신설 (하수인/빌런/정체성/스킴 부착 전반에 재사용):
  · attachTo 양방향 강화: inst.attachedTo ↔ target.attachments (역참조)
  · detachFrom(부착 해제), releaseAttachments(대상 격파 시 부착물 일괄 처리):
    각 부착물 whenAttachedDefeated 훅 발화 → 소유별 정리(플레이어카드=소유자 버림,
    인카운터카드=조우 버림)
  · onDefeated에서 하수인/빌런 처치 시 releaseAttachments 호출
  · playCard upgrade 케이스 확장: attachTarget이 minion/enemy/scheme면 대상에 부착
    (부착물은 플레이영역에 두지 않음), hero/character면 정체성 부착(역참조)
  · baseFields에 whenAttachedDefeated/attachTarget 추가
- 코어 #7 능력 등록 (spider-tracer): 하수인 부착 → 처치 시 위협 3 제거
  (attachTarget:'minion' + whenAttachedDefeated:'tracerDefeated' 핸들러)
- VFX.attachPlace: 부착 카드가 대상 위에서 크게 확대(2.2x)됐다 작아지며(0.62x)
  대상에 겹쳐짐 + 히트플래시 + ATTACHED! (범용 부착 연출)
- ★ 부착 UI 시각화:
  · attachBadge — 카드 우상단 📎N 배지(부착 개수)
  · attachChips — 카드 아래 부착물 목록(각 돋보기🔍, 탭하면 상세). 여러 장 나열,
    플레이어/인카운터 카드 색 구분. 하수인+빌런 공통 적용(빌런 부착 표시도 통일)
- UI: 부착 업그레이드 플레이 시 대상 선택 모드(attachMode) → 하수인 탭 → 부착 +
  attachPlace 연출(imgUrl 전달)
- 링크: spider-tracer vfx.install='attachPlace'

**검증:** test_phase3_core 확장 — 양방향 부착/비영역 배치/여러 장 부착/처치 시 위협
장당 3제거/부착물 버림/하수인 제거 ✓ · 회귀 전체 통과(core 200판·vfx_index 144건) ·
헤드리스: 확대겹침·go(축소)·ATTACHED! ✓

**연출 인덱스(19종):** ...(기존 18) + attachPlace
**엔진 시스템:** 부착 양방향 링크·releaseAttachments(신규)
**UI:** attachBadge/attachChips(부착 시각화 — 여러 장·돋보기)

**카드 작업:** [코어 #1~7 ✅] → 다음 코어 #8 (web-shooter 와일드 자원 소진능력) 등


## v2026.07.09.20 — 코어 #6 메이 숙모 + 카드 활성 능력 시스템 + 소진 리셋 버그 수정
**무엇을:**
- ★ 카드 활성 능력 시스템 신설 (소진 능력 support/upgrade/ally 재사용 기반):
  · cardDef.activatedAbility = { form?, exhaust?, effect } 선언
  · ACTIONS.useCardAbility — 폼/소진 조건 검증 후 효과 실행
  · 앞으로 헬리캐리어/알파기지/스타크타워 등 소진 능력 카드에 재사용
- ★ 소진 리셋 버그 수정: endRound에서 카드 exhausted 리셋이 없어
  support/upgrade/ally가 한 번 소진되면 영영 준비 안 됐음. 라운드 준비 단계 추가
  (플레이어 + 모든 플레이영역 카드 exhausted=false). test_phase1 방어자 소진
  테스트도 라운드 준비 로직에 맞게 갱신(라운드 넘어가면 준비되는 게 정상)
- 코어 #6 능력 등록 (aunt-may): 알터에고 행동 — 소진 → 피터 파커 4 회복
  (activatedAbility 첫 사례)
- ★ 회복 연출 공용 인덱스화 (recover): 카드 하단에서 초록 십자(+) 여러 개가
  아래→위로 떠오름(CSS 도형 십자, 좌우 드리프트) + 초록 발광 펄스.
  기존 heal-plus(글리프)를 heal-cross(도형)로 교체
- 설치 연출: 스파이더맨 전용 webInstall 그대로 재사용 (vfx.install='webInstall')
- 링크: aunt-may vfx { install:'webInstall', recover:'recover' }
- UI: support/upgrade 활성 능력 버튼 노출(폼/소진 조건 disabled 처리) →
  useCardAbility → 회복 연출(회복 대상=신분 카드) 재생

**검증:** test_phase3_core 확장(4회복/소진/재사용 차단/폼 제한) · test_phase1 갱신 ·
회귀 전체 통과(core 200판·vfx_index 143건) · 헤드리스: 회복 레이어·healpulse ✓

**연출 인덱스(18종):** recover 개편(공용) — 신규 없음, webInstall 재사용
**엔진 시스템:** activatedAbility(신규) · 라운드 카드 준비(소진 리셋, 버그 수정)

**카드 작업:** [코어 #1~6 ✅] → 다음 코어 #7 (spider-tracer 하수인 부착) 등


## v2026.07.09.19 — 코어 #5 회전 거미줄 발차기 (화려한 연출)
**무엇을:**
- 코어 #5 (swinging-web-kick): 능력(8피해)은 마이그레이션 등록됨 → 연출만 추가.
  스파이더맨 유일 메인 딜링기라 화려하게 구성
- VFX.webKick (4단):
  ① 거미줄 줄기가 대상 상단 앵커로 뻗음(SVG 라인, 스파이더맨 카드 웅크림)
  ② 발차기 아이콘이 스윙 호(위로 크게 솟았다 내리꽂는 베지어)를 타고 720° 회전
     돌진 + 잔상 트레일
  ③ 회전 발차기 임팩트: 다중 충격링(160→260→360) + 방사 스파크 14개(sparkBurst
     신규 헬퍼) + 강한 화면 흔들림 2연타(intensity 2)
  ④ 2단 온오마토페 THWIP!(작게) → SMASH!(크게)
- 링크: swinging-web-kick vfx.basicAttack='webKick'
  (기존 pickTarget 경로가 이벤트 공격의 vfx.basicAttack 재생 — 배선 재사용)

**검증:** 회귀 전체 통과(core 200판·vfx_index 141건) ·
헤드리스: 거미줄레이어·발차기궤적·스파크버스트·THWIP!/SMASH! ✓

**연출 인덱스(18종):** ...(기존 17) + webKick
**연출 헬퍼:** ...(기존) + sparkBurst(방사 스파크)

**카드 작업:** [코어 #1~5 ✅] → 다음 코어 #6 (aunt-may 메이 숙모: 알터에고 4회복) 등


## v2026.07.09.18 — 코어 #4 강화된 스파이더 센스 + 범용 인터럽트 정지점 시스템
**무엇을:**
- ★ 범용 인터럽트 정지점 시스템 신설 (앞으로 취소/반응 카드 다수에 재사용):
  · resolveEncounterCard 진입 시 checkRevealInterrupt — 대응 가능한 인터럽트
    카드를 가진 히어로가 있으면 pending:{kind:'revealInterrupt'}로 정지
  · 각 인터럽트 카드는 cardDef.interruptOn={encounterType} + interruptEffect 선언
  · 공개 중 카드는 G.revealing 슬롯에 보관(미배치라 uid 조회 불가 대응)
  · resolveRevealInterrupt(사용/패스) → 사용 시 결제+취소플래그(revealCancelled),
    패스 시 원래 whenRevealed 발화. 그 후 resolveEncounterCard 재진입(interruptChecked)
  · fireRevealWithInterrupt로 whenRevealed 발화 일원화 (revealCancelled면 스킵)
  · ACTIONS.resolveRevealInterrupt, baseFields에 interruptOn/interruptEffect
- 코어 #4 능력 등록 (enhanced-spider-sense):
  히어로 인터럽트 — 배반(treachery) 공개 시 "공개 시" 효과 취소
  (interruptOn:{encounterType:'treachery'}, interruptEffect:'cancelReveal')
- VFX.senseCancel: 스파이더맨 카드에 스파이더센스 물결(기존 spiderSense 재사용) +
  취소된 배반 카드가 회색(그레이스케일)으로 흩어짐 + SENSED! 텍스트
- UI: 인터럽트 정지점 배너(사용 가능 카드 버튼 + 패스), useInterrupt/passInterrupt,
  결제 필요 시 팝업(interrupt 플래그) → payConfirm 처리, 연출 재생

**검증:** test_phase3_core 확장 — 배반 공개 인터럽트 pending/취소(whenRevealed 무효)/
패스(정상 발화)/인터럽트 없을 때 정상 발화 ✓ · 회귀 전체 통과(core 200판·vfx_index 140건) ·
헤드리스: 물결·회색흩어짐·그레이스케일·SENSED! ✓

**연출 인덱스(17종):** ...(기존 16) + senseCancel
**vfx 슬롯:** ...(기존) + interrupt(인터럽트 반응용)
**엔진 pending 종류:** defense, revealInterrupt(신규)

**카드 작업:** [코어 #1~4 ✅] → 다음 코어 #5 (01005 회전 거미줄 발차기 — 이미 8피해 등록됨,
연출만) 또는 코어 #6(aunt-may 회복). 범용 인터럽트로 get-behind-me/spycraft/
grappling-hook 등도 쉽게 등록 가능


## v2026.07.09.17 — 코어 #3 공중제비(Backflip) 방어 인터럽트
**무엇을:**
- 코어 #3 능력 등록 (backflip, 스파이더맨 전용 방어 이벤트):
  인터럽트(방어) — 공격으로 피해를 입으려 할 때 그 공격의 모든 피해 방지
- EFFECTS.preventAll 신규: 현재 방어 pending을 피해 0으로 해소 + 빌런 큐 재개
- 엔진: 방어 인터럽트 이벤트는 방어 pending 상태에서 플레이 허용(일반 턴 제약 우회).
  판정은 cardDef 기준(traits+effects) — 인스턴스엔 정의 전용 필드 미복사
- ★ event effects 실행도 정의(cardDef) 폴백 추가 — 인스턴스에 effects 없어도
  동작. 다른 즉발 이벤트(swinging-web-kick/tackle 등)에도 이로움
- VFX.backflip: 스파이더맨 카드가 뒤로 360° 공중제비 회전하며 공격 흘림 +
  뒤로 젖혀진 잔상 + MISS! 회피 텍스트. 카드 스코프
- UI: 방어 배너에 방어 이벤트 버튼 노출(손패의 defense+preventAll 카드) →
  playDefenseEvent → 결제 팝업(defenseInterrupt 플래그) → payConfirm이 연출 재생
- 링크: backflip vfx.defense='backflip'

**검증:** test_phase3_core 확장 — pending 생성/backflip 플레이/pending 해소/피해 0 ✓ ·
회귀 전체 통과(core 200판·vfx_index 139건) · 헤드리스: 공중제비 클래스·MISS! ✓

**연출 인덱스(16종):** ...(기존 15) + backflip
**vfx 슬롯:** ...(기존) + defense(방어 인터럽트용)

**카드 작업:** [코어 #1 ✅][코어 #2 ✅][코어 #3 ✅ 공중제비] → 다음 코어 #4
(01004 강화된 스파이더 센스: 계략 취소)


## v2026.07.09.16 — 자원 데이터 zzorba 교차검증 + 리프린트 오버라이드
**무엇을:**
- 사용자 지적("자원 뭐 보고 판단하냐")으로 자원 데이터 권위 검증 수행.
  엔진 resources는 marvel_card_index.json(원본에 자원 없음)이 아닌 마이그레이션에서
  채운 값 → zzorba(공식, resource_physical/mental/energy 보유)와 미검증 상태였음
- 이미지 코드로 엔진↔zzorba 자원 전수 대조:
  · 스파이더맨 코어세트(01xxx) 자원 불일치 0장 (블랙캣 멘탈 판정 근거 정확 확인)
  · 표면상 불일치 8장 발견 → 정밀 분석 결과 7장은 리프린트 이미지코드라
    zzorba 원판(08031/06018/06015/06032/06034 등)과 대조 시 정확했음(오탐)
  · 진짜 불일치 3장만 수정: goliath-ally(→mental), mockingbird-ally(→physical),
    weapons-master(→physical) — 모두 zzorba 원판 기준
- tools/migrate_index.py에 RESOURCE_OVERRIDE 테이블 추가(리프린트 코드 대응).
  자동생성 재실행 후에도 유지됨. migrate 재생성해도 fx 레이어(defineCardFx)가
  todoFx를 다시 해제하므로 능력 등록 전부 보존 확인
- inspect_card.py가 zzorba 원문까지 덤프하므로 향후 카드별 작업 시 자원/스탯
  대조가 도구로 자동화됨

**검증:** 회귀 전체 통과(test_index·core 200판·payment·phase1·phase3·vfx_index) ·
오버라이드 3장 반영 확인 · 실질 자원 불일치 0(잔여 7건은 zzorba 리프린트 코드 데이터 공백)

**카드 작업:** [코어 #1 ✅][코어 #2 ✅ 블랙캣] → 자원 검증 완료 → 코어 #3 준비


## v2026.07.09.15 — 코어 #2 블랙캣 완성 + fireCardHook 정의 훅 버그 수정
**무엇을:**
- ★ 중요 버그 수정 — fireCardHook이 인스턴스 필드만 조회해 whenPlayed/whenRevealed 등
  baseFields(정의 전용, 인스턴스 미복사) 훅을 못 찾고 있었음. 즉 1차 배치 조우 카드
  능력(shocker 등)이 실전에서 발화 안 됨. → 인스턴스에 없으면 cardDef에서 훅 조회하도록 수정.
  재조립 후 shocker·블랙캣 모두 발화 확인. test_phase3_core mkInst에서 whenRevealed
  명시 복사 제거(실전 동일화)
- 코어 #2 블랙캣 능력 등록 (whenPlayed:'blackCatForced'):
  강제 반응 — 플레이 후 덱 위 2장 버림, 인쇄 🧠멘탈 자원 카드는 손으로 회수
  (EFFECTS.millAndGrab 신규 — 조건부 자원 회수)
- 연출 링크: install=webInstall(거미줄), basicAttack=claw(발톱), basicThwart=patrol
- VFX.claw 신규: 대상 카드 위 발톱 3줄이 좌상→우하로 긁고 지나감 + 히트플래시 +
  SLASH! + 진동. 카드 스코프
- UI: 동료 공격/저지에 동료 카드 vfx 연출 배선 (claw는 대상 위, strike류는 궤적, 좌표 선캡처)

**검증:** test_phase3_core 확장 — 블랙캣 멘탈 회수/비멘탈 버림/연출 링크 ✓ ·
회귀 전체 통과(test_index·vfx_index 138건) · 헤드리스: 발톱 레이어·SLASH! ✓

**연출 인덱스(15종):** ...(기존 14) + claw

**카드 작업 진행:** [코어 #1 ✅ 스파이더맨] [코어 #2 ✅ 블랙캣] → 다음 코어 #3
워크플로우: inspect_card 진단 → 능력 인덱스 등록 → 사용자 애니메이션 타입 지정 → 연출 링크


## v2026.07.09.14 — 코어 #1 완성: 스파이더맨 Spider-Sense (능력+연출)
**무엇을:**
- 카드 인스펙터 도구 신설(tools/inspect_card.py): 공식 데이터·마이그레이션·구현 상태·
  연출 슬롯을 한번에 덤프. 카드 번호순 작업 워크플로우의 진단 도구
- 엔진: 공격 개시 인터럽트 훅 추가 — enemyActivation(빌런 활성화, 영웅형)에서
  방어 pending 생성 직후 MC.fireAttackInterrupt() 호출. 대상 신분(영웅면)의
  attackInterrupt 핸들러 발화. baseFields에 attackInterrupt 등록
- 코어 #1 능력 등록:
  · 스파이더맨(01001a) Spider-Sense — 인터럽트: 빌런이 나를 공격 개시할 때 카드 1장 드로우
    (attackInterrupt:'spiderSense' → HANDLERS.spiderSense, EFFECTS.draw 재사용)
  · 피터 파커(01001b) Scientist — 기존 resourceAbility로 이미 동작 (확인)
- VFX.spiderSense: 코믹 전통 문법(레퍼런스 조사) — 카드 상단서 위험 감지 물결선 6줄
  부채꼴 방사 + 빨강↔파랑 색조 펄스 + '!' 경보. 카드 스코프
- 링크: 01001a attackInterrupt='spiderSense', vfx.spiderSense='spiderSense'
- UI: act()가 방어 pending 신규 발생 감지 → 대상 신분의 attackInterrupt 연출 재생

**검증:** test_phase3_core 확장 — 공격 개시 시 1장 드로우 ✓ · 알터에고면 미발동 ✓ ·
pending 정상 ✓ · 회귀 전체 통과 · UI 트리거 spiderSense 발화 ✓

**연출 인덱스(14종):** ...(기존 13) + spiderSense

**카드 작업 진행:** [코어 #1 ✅ 01001 스파이더맨/피터파커] → 다음 코어 #2 (01002 블랙캣)
워크플로우: inspect_card로 진단 → 능력 인덱스 등록 → 사용자가 애니메이션 타입 지정 → 연출 링크


## v2026.07.09.13 — Phase 3 착수: 스파이더맨 + 라이노 코어 카드 능력 등록
**무엇을:**
- EFFECTS 확장(7종 신규): surge · healVillain · damageEachHero · statusEachHero ·
  toughEnemy · villainAttacks(pending 방식) · dealDamageIfPaid(조건부 자원 피해)
- playCard: 결제 자원 아이콘을 ctx.paidIcons로 전달 (조건부 효과용).
  ★ 결제 실행 '전'에 계산 — 실행 후엔 손패에서 사라져 계산 불가 (순서 버그 수정)
- 카드 능력 등록 (cards/mc_cards_fx.js, HANDLERS + defineCardFx):
  · shocker — 공개 시 각 히어로 1 피해
  · hard-to-keep-down — 빌런 4 회복 (풀피면 급증)
  · im-tough — 라이노 강인함 (이미 있으면 급증) + 부스트★
  · false-alarm — 히어로 혼란 (이미 혼란이면 급증)
  · tackle — 적 기절 + 💪피지컬 지불 시 3 피해 (조건부) + strike 연출
- UI: 이벤트 공격 카드(chosen 타깃)에 카드 정의의 vfx.basicAttack 연출 재생
  (tackle → strike, 좌표 선캡처). sel.cardDefCode 추가
- test_index 화이트리스트: boostStarEffect

**검증:** tests/test_phase3_core.js 신설 — shocker/hard-to-keep-down(회복·급증 양분기)/
im-tough(강인함·중복)/false-alarm/tackle(기절+조건부 피해) 전부 ✓ · 회귀 전체 통과

**등록 현황 (스파이더맨+라이노 코어):**
- 능력 동작 확정: shocker · hard-to-keep-down · im-tough · false-alarm · tackle ·
  swinging-web-kick · power-of-protection(자원 2배)
- 잔여 미등록 todoFx: 30여 종 (동료 반응/부착/카운터형 업그레이드/pending 유발 배반 등)

**다음 배치 후보:**
- pending 유발형: assault/gang-up(빌런·하수인 공격), stampede(공격+기절)
- 카운터 업그레이드: web-shooter/enhanced-awareness (자원 능력 확장)
- 동료 반응: mockingbird(기절)/nick-fury(선택)/black-widow(취소)
- 부착·조건: spider-tracer/webbed-up/rhino-suit/charge/horn-attack
- 상태 이벤트 예약형: get-behind-me/enhanced-spider-sense/preemptive-strike(인터럽트)


## v2026.07.09.12 — 캐릭터 전용 설치 연출: 스파이더맨 거미줄(webInstall)
**무엇을:**
- VFX.webInstall: 스파이더맨 전용 카드 설치 시 거미줄 발사기가 5~6방 THWIP! 발사 —
  웹 가닥이 카드 주위 방사 지점에서 카드로 발사(65ms 시차)되며 카드가 작게 시작해
  당겨지듯(지터) 완성. 발사 지점마다 THWIP! 버스트 + 진동. 카드 스코프
- 링크: 스파이더맨 신분(01001a) vfx.cardInstall='webInstall' (생성기 EXTRA, vfx 병합)
- 설치 트리거 분기 확장: 공용 카드 → install(EQUIP!/DEPLOY!), 캐릭터 전용 카드 →
  소유 영웅(pl.heroCode) 신분의 vfx.cardInstall 연출. 미정의 영웅은 대기(무연출)
  → 영웅별 전용 설치 연출을 이 슬롯에 계속 추가 가능
- test_vfx_index가 webInstall 링크 자동 검증(참조 133건 미등록 0)

**검증:** 회귀 전체 통과 · 헤드리스: 웹 가닥 6·THWIP! 6 ✓ · 실제 web-shooter(전용) 설치
시 webInstall 발화, 공용 install 미발화 ✓ · 스파이더맨 링크 ✓

**연출 인덱스 현황(13종):** screenShake · cardPop · wallBreak · strike · headbutt ·
formFlip · barBreak · patrol · recover · onHit · onDefeat · install · webInstall
+ 헬퍼(impactBurst/impactRing/flashEl/ghostOf/speechBubble)

**보류:** [V-4] 타 영웅 전용 설치 연출(캡틴=방패 장착 등) · 동료(ally) 등장 · 이벤트 사용 연출

## v2026.07.09.11 — 카드 설치 연출(install) · 공용 지원/업그레이드
**무엇을:**
- VFX.install: 공용 지원/업그레이드가 필드에 꽂힐 때 — 위에서 내리꽂혀 착지(스쿼시
  스트레치) → 충격 링 + 진동 → 네 모서리 볼트(🔩)가 회전 체결(45ms 시차) →
  EQUIP!(업그레이드)/DEPLOY!(지원) 버스트. 카드 스코프
- 트리거 자동화: act()가 디스패치 전후 필드 지원/업그레이드 uid diff → 신규 설치 감지.
  ★ 캐릭터 전용 카드(def.hero 있음)는 제외 — 별도 애니메이션 예정(사용자 지시)
  다수 동시 설치 시 80ms 시차
- 판정 확인: web-shooter(hero=spiderman)=전용 제외, energy-barrier(보호 공용)=설치 연출 O

**검증:** 회귀 전체 통과 · 헤드리스: 볼트/EQUIP! 생성 ✓ · 실제 플레이 흐름에서
공용 업그레이드 설치 시 install 발화 ✓ · 전용/공용 판정 정확

**연출 인덱스 현황(12종):** screenShake · cardPop · wallBreak · strike · headbutt ·
formFlip · barBreak · patrol · recover · onHit · onDefeat · install
+ 헬퍼(impactBurst/impactRing/flashEl/ghostOf/speechBubble)

**보류:** [V-4] 캐릭터 전용 카드 설치 애니메이션(영웅별) · 동료(ally) 등장 연출 ·
이벤트 카드 사용 연출


## v2026.07.09.10 — 처치 연출(onDefeat) · 과장 강화
**무엇을:**
- VFX.onDefeat: 대상이 쓰러질 때 ① 흰섬광(카드 자리 폭발광) ② K.O.! 대형 버스트(168px)
  + 320px 링 + 강진동 ③ 카드가 3×4=12조각으로 산산조각 — 각 조각이 카드 이미지의
  해당 부분을 배경으로 회전하며 아래로 낙하. 카드 스코프
- 빌런 단계 격파는 'STAGE DOWN!' 라벨로 구분 (uid 유지된 채 stage 변화로 판정)
- 트리거 자동화: act()가 디스패치 **전** 살아있는 적/동료의 좌표·이미지 스냅샷 →
  디스패치 후 사라진(또는 빌런 단계 하락) 대상에 KO 연출. 다수 처치 시 90ms 시차.
  피격(onHit)과 중복 방지: 처치된 uid는 onHit 제외
- clearVfx 정리 대상 확장 (koflash/shatter/heal)

**검증:** 회귀 전체 통과 · 헤드리스: onDefeat 섬광/파편/KO ✓ ·
빌런 단계격파(1→2) 시 onDefeat 자동(STAGE DOWN!) ✓

**연출 인덱스 현황(11종):** screenShake · cardPop · wallBreak · strike · headbutt ·
formFlip · barBreak · patrol · recover · onHit · onDefeat
+ 헬퍼(impactBurst/impactRing/flashEl/ghostOf/speechBubble)


## v2026.07.09.9 — 회복(recover) 연출 + 피격 리액션(onHit)
**무엇을:**
- VFX.recover: 대상 카드에서 초록 치유 글로우가 아래→위로 차오르고 '+' 크로스가
  떠오름, 카드 부드러운 맥동. 회복량 비례 파티클 수. 카드 스코프
- VFX.onHit: 데미지 받은 카드가 붉게 번쩍(hitflash) + 움찔(jolt). 3 이상 피해는
  강한 저크(jolt-big) + OUCH! 소형 버스트. 카드 스코프
- 트리거 자동화: act()가 HP 원시값 diff — 감소한 카드마다 onHit 자동 발화
  (빌런 박치기와 공존: onHit + headbutt 동시). 회복은 UI.recover에서 명시 재생
- ★ 액션 순수성 유지: 피격 억제 플래그를 액션 객체가 아닌 act()의 opt 파라미터로
  전달 (액션 로그 오염 금지 → 결정성 재생 테스트 무결). 기본 회복 버튼 → UI.recover 래퍼

**검증:** 회귀 전체 통과(결정성 재생 포함) · 헤드리스: 회복 연출/피격 억제 ✓ ·
빌런 공격 시 onHit 자동 ✓ · onHit jolt-big/heal 레이어 생성 ✓

**연출 인덱스 현황(9종):** screenShake · cardPop · wallBreak(등장) · strike(타격) ·
headbutt(적 공격) · formFlip(폼 변경) · barBreak(소진 해제) · patrol(저지) ·
recover(회복) · onHit(피격) + 헬퍼(impactBurst/Ring/flashEl/ghostOf/speechBubble)
남은 슬롯 후보: onDefeat(처치) · 하수인 개별 공격 · 스킴 완성


## v2026.07.09.8 — 저지 출동 연출(patrol) + 바 부드러운 전환(FLIP)
**무엇을:**
- VFX.patrol: 저지 캐릭터 위치에서 감시 차량(🚓) 팝 등장 → 지면 주행 바운스 +
  잔상 트레일로 스킴까지 감속 질주 → 급정거 스키드 → **THWARTED!** 버스트(영어 규칙)
  + 링 + 진동 → 전진 이탈 소멸. 방향 따라 차량 좌우 반전
- 링크: 전 신분 vfx.basicThwart='patrol' (생성기 공통 — EXTRA로 영웅별 교체 가능).
  test_vfx_index 132건 미등록 0
- 앵커: 메인 스킴 스트립·사이드 스킴 카드에 data-vuid — 저지 대상으로 차량이 정확히 주행
- ★ 바 부드러운 전환: 렌더가 DOM을 재생성해도 **이전 값 스냅샷 → 새 DOM에 이전 폭
  주입 → 리플로우 → 목표 폭 전환(.6s)** FLIP 패턴. HP(빌런/플레이어)·위협 모두 적용.
  감소/증가 양방향 그라데이션 이동
- 기본 저지 버튼 → UI.thwart 래퍼 (좌표 선캡처 + 성공 시 연출)

**검증:** 회귀 전체 통과 · patrol 프레임 시뮬 THWARTED ✓ · 전 신분 링크 ✓ ·
빌드에 barkey/0.6s 전환 포함 ✓


## v2026.07.09.7 — 소진 차단바 + 준비 회복 파열 연출
**무엇을:**
- 소진 표시 전면 교체: 배지 → **대각선 차단바** (노랑-검정 위험 스트라이프, '소진!' 라벨,
  낙하 등장 애니) + 카드 디밍(그레이스케일). 신분/동료/지원/업그레이드 공통
- VFX.barBreak: 준비 회복 순간 차단바가 **두 동강** 나 양쪽으로 튕겨 날아가며 회전 소멸
  + 스파크 3개 + SNAP! 소형 버스트. 동시 다발 회복 시 카드당 70ms 시차
- 트리거 자동화: act()가 액션 전후 **소진 상태 diff** — 소진→준비 전환된 카드를 찾아
  파열 재생 (endPlayerPhase 일괄 준비, 개별 준비 효과 모두 자동 커버)
- 지원/업그레이드 카드에 data-vuid 부여 (연출 앵커)
- clearVfx 정리 대상 확장 (barbreak/ring/ghost)

**검증:** 회귀 전체 통과 · 헤드리스 전 흐름: 공격 소진 → 차단바 렌더 ✓ →
페이즈 종료 준비 회복 → barBreak 호출 ✓ (headbutt와 공존 확인)


## v2026.07.09.6 — 카드 오버레이 정리 · 양면 전환
**무엇을:**
- 카드 정보 오버레이: **※ 판정 각주 라인 전부 필터** — 효과 텍스트 + 플레이버(이탤릭
  인용 스타일)만 표시. 본문 폰트 키움(13px, 밝게)
- **양면 전환 버튼**: 메인 스킴 1A↔1B (스크린샷 지적 — 1B 확인 가능), 신분 카드
  영웅면↔알터에고면. 전환 시 기존 오버레이 교체(중첩 방지)
- 단계 칩(1A/1B) 오버레이 내 표시

**검증:** 회귀 전체 통과 · 헤드리스: ※ 제거 ✓ / 본문 유지 ✓ / 1A↔1B 양방향 ✓ / 신분 양면 ✓

**참고:** ※ 각주 원문은 정의(textKo)에 그대로 보존 — Phase 3 능력 등록 시 판정 참고자료로 사용


## v2026.07.09.5 — 폼 변경 연출 + 전 이펙트 드라마 강화 · 의성어 영어화
**무엇을:**
- VFX.formFlip (폼 변경): 카드가 -46px 부양·1.45배 확대 → 측면(90°)에서 얼굴 교체
  (+플래시·링) → 720°까지 고속 회전 → 착지. 회전 중 오라 글로우(vfx-aura).
  렌더 지연 디스패치 패턴: 상태만 변경 → 연출 완료 onDone에서 render (교체 이음새 제거)
  전 신분 62면에 vfx.formChange 링크 (생성기 기본값 — EXTRA vfx는 병합)
- 드라마 강화 (공통 헬퍼 신설: impactBurst/impactRing/flashEl/ghostOf/강진동):
  - strike: 주먹 54px + 잔상 트레일(34ms 간격 고스트) + 랜덤 워드(POW!/BAM!/WHAM!/SMACK!)
    132px 버스트 + 임팩트 링 + 타깃 히트플래시 + 진동. 비행 0.42s로 가속
  - headbutt: 7키프레임 — 1.55배 부양+웅크림 홀드(긴장) → 스트레치 돌진(skew) →
    CRASH!!(160px)+WHAM! 이중 버스트 + 280px 링 + 강진동(intensity 2) → 바운스 착지
  - wallBreak: 파편 16개, SMASH!! 버스트 + 300px 링 + 강진동
  - screenShake intensity 2 변형(진폭 13px+회전)
- ★ 의성어 규칙: **이펙트 텍스트는 전부 영어** (CRASH/SMASH/WHAM/POW/BAM/SMACK) —
  대사(말풍선)는 한글 유지. 실텍스트 추출 검사로 확인

**검증:** test_vfx_index 70건 미등록 0 · 회귀 전체 통과 ·
헤드리스: headbutt 7키프레임·1.5배 ✓ / formFlip -46px·720° ✓ / 타이머 체인 무크래시


## v2026.07.09.4 — 적 공격 연출: 박치기(headbutt)
**무엇을:**
- VFX.headbutt: 발동자 카드 자체가 Web Animations 5키프레임으로
  ① 커지며 떠오름(scale 1.28, -16px) ② 대상 위로 급가속 돌진 ③ 반동
  ④ 제자리 복귀. 임팩트 시점(620ms)에 '쾅!!' 버스트 + 화면 진동. zIndex 승격/복원
- 트리거: 방어 선언 해소(resolveDefense) 성공 시 — 공격이 실제로 꽂히는 순간.
  임팩트 대상 rect 선캡처(신분/무방어=플레이어 카드, 동료 방어=그 동료 카드)
- 링크: 라이노 1·2·3단계 전부 vfx.enemyAttack='headbutt' (하수인도 같은 슬롯으로
  개별 연출 링크 가능한 범용 구조). 동료 카드에 data-vuid 부여
- screenShake 방어 가드 (classList 부재 환경)

**검증:** test_vfx_index 참조 8건 미등록 0 · 회귀 전체 통과 ·
헤드리스: 키프레임 5(떠오름/돌진 delta/복귀) ✓ · 쾅!! 버스트 ✓ · zIndex 정리 ✓


## v2026.07.09.3 — 공격 연출 인덱스: 타격(strike)
**무엇을:**
- VFX.strike 등록: 공격 주체→대상 **2차 베지어 호**를 그리는 주먹(👊) 투사체
  (진행 방향 회전), t=1 임팩트에서 대상 위 POW! 버스트(랜덤 기울기, 팝인→소멸),
  주먹은 t=1.38까지 **관통해 지나가며** 반투명 소멸
- 좌표 선캡처 패턴 확립: 디스패치 **전** 소스/대상 rect 캡처 → 재렌더/대상 처치로
  DOM이 사라져도 임팩트 위치 정확 (이후 모든 전투 연출의 표준)
- 앵커 체계: 카드 아트에 data-vuid(빌런/신분/하수인) — 연출 좌표 조회용
- 링크: 스파이더맨(01001a) vfx.basicAttack='strike' — gen_identities EXTRA에 등록해
  재생성에도 유지. test_vfx_index가 자동 검증 (참조 3건 미등록 0)
- act()가 성공 여부 반환 — 실패한 액션엔 연출 미재생

**검증:** 회귀 전체 통과 · strike 헤드리스 프레임 시뮬 (POW 생성 ✓ · 관통 반투명 ✓)

**다음 연출 슬롯 예약:** vfx.basicAttack(영웅별) · onHit(피격) · onDefeat(처치) ·
enemyAttack(빌런/하수인 공격 — pending 해소 시점) — 같은 인덱스에 계속 적재


## v2026.07.09.2 — 대사 범용화 · 코믹 바 · 스킴 효과 표현 · 1A/1B
**무엇을:**
- 대사 규칙 확정: **특정 영웅 지칭 금지** (영웅 확장 대비 범용 문구만). 라이노 4번 대사 교체
- 체력/위협 바 리디자인 — 코믹 스타일: 기울인(skew) 트랙 + 잉크 보더, 사선 스트라이프 채움,
  광택 하이라이트, Bangers 숫자(잉크 외곽선), 저체력(≤30%) 펄스. hpBar → comicBar 일반화
- 스킴 효과 표현: 가속(⚡)/위기(✛)/위험(☣) 아이콘 칩(툴팁 설명 포함) + 능력 미구현 시
  '✋ 수동' 칩 — 메인 스킴 스트립·사이드 스킴 슬롯 모두. 사이드 스킴에 돋보기 추가
- 메인 스킴 1A/1B: 01097a(셋업면) 정식 등록 + **양면 한글 텍스트** 작성.
  스트립에 단계 칩(1B) + [1A 셋업] 버튼 → 셋업 카드 이미지+한글 지시 오버레이

**검증:** 회귀 전체 통과 · 렌더 스모크 (cbar/stagechip/1A버튼/가속칩 ✓)


## v2026.07.09.1 — VFX 카드 스코프 원칙 · 필드 '디지털 플레이매트' 재설계
**무엇을:**
- ★ VFX 스코프 원칙 확정: **별도 지시 없는 연출은 해당 카드(cardEl) 기준**.
  전역 효과는 screenShake처럼 명시적으로만. wallBreak 크랙/섬광/파편을 빌런 존 →
  라이노 카드 위로 이동 (크랙 SVG를 세로 카드 비율 viewBox로 재작도)
- 필드 전면 재설계 — 실물 플레이매트 문법 + 디지털 장점:
  - 매트 질감(비네트+미세 도트+그라데이션), 존 색상 톤 분리(빌런 적색/영웅 청색)
  - 파일 슬롯: [조우덱|빌런|메인스킴 스트립|조우 버림] / [덱|신분|스탯·액션|버림] —
    카운트 뱃지, 카드백 패턴, **버림 더미 탭=열람 오버레이(보류 U-3 해소)**
  - 빈 슬롯 점선 아웃라인(동료 3칸·지원/업글) + 소문자 대문자 라벨 — 매트 느낌
  - 정보 정돈: 헤더 스트립(이름/선/형태 칩/스탯 요약), 섹션 구분선, 스킴 스트립 통합
  - 로그 → 접이식 드로어(기본 접힘) — 필드 시각 소음 대폭 감소
- 헤드리스 렌더 스모크 신설: 메뉴 5화면 + 보드 + 버림 오버레이 크래시/요소 검증

**검증:** 회귀 전체 통과(test_vfx_index 포함) · 렌더 스모크 전 화면 ✓

**주의:** 참조 이미지(rollinmats)는 네트워크 허용 목록 밖이라 직접 확인 불가 —
공식 플레이매트 관례 기반으로 설계. 사용자 실물 대조 피드백으로 미세조정 예정.


## v2026.07.08.9 — VFX/대사 인덱스 시스템 · 라이노 파괴 등장 · 돋보기
**무엇을:**
- ui/mc_vfx.js 신설 — 연출도 EFFECTS와 동일 인덱스 규율:
  - MC.VFX 레지스트리: screenShake / cardPop(커졌다→작아짐 바운스) /
    **wallBreak**(흔들림→크랙 SVG 2단계 드로잉→섬광·파편 10개→카드 거대→축소 등장→말풍선)
  - MC.QUOTES 레지스트리: rhino.entrance 대사 10개, randomQuote 랜덤 재생
  - 카드 정의엔 이름만: 01094에 vfx:{entrance:'wallBreak'}, quoteKey:'rhino'
  - 연출은 표현 계층 — G 무변경(결정성 보존), 연출 랜덤만 Math.random 허용
  - tests/test_vfx_index.js: vfx/quoteKey 미등록 참조 + 대사 10개 미달 검출
- 코믹 말풍선 컴포넌트(speechBubble): 잉크 보더+꼬리, 팝인, 자동 소멸, 화면 경계 클램프
- 등장 연출 트리거: 새 게임 시작 시(이어하기 제외), 메인 복귀/이어하기 시 잔여 연출 정리(clearVfx)
- 돋보기(🔍): 손패(우하단 배지)·빌런 카드·메인 스킴·하수인/동료(토큰형 버튼)·지원/업글 —
  전부 한국어 룰 텍스트 오버레이로 연결. 오버레이에 스탯 요약 줄(비용/ATK/THW/DEF/HP/증폭) 추가

**검증:** test_vfx_index 참조 2건 미등록 0 · 회귀 전체 통과 · 빌드 파싱 OK

**보류 추가:** [V-1] 등장 연출 스킵 탭 · [V-2] 피격/처치/스킴 완성 등 상황별 VFX 슬롯 확장
(vfx:{onHit, onDefeat, ...}) · [V-3] 타 빌런 대사·연출 (클로/울트론 구현 시)


## v2026.07.08.8 — 전 영웅 덱빌딩 · 10칸 저장 슬롯 · MarvelCDB 번호 가져오기
**무엇을:**
- tools/gen_identities.py 신설: zzorba 공식 스탯 × heroDB 한국어명 결합 →
  **영웅 31명 / 신분 카드 62장** 자동 생성 (cards/mc_cards_identities.js, MC.HEROES 메타 포함)
  - 카드 hero 필드의 접미사 키(hulk-hero 등 6종)를 정식 키로 채택 (시그니처 풀 연결 우선)
  - 다중 형태 영웅은 기본 면만 [H-1] · 영웅별 자원 능력은 과학자만 등록(EXTRA 확장 지점)
  - 시드의 스파이더맨 신분 제거 (생성기로 일원화 — 중복 등록 크래시 수정)
- 덱빌더: 진입 시 **영웅 픽커 오버레이(31종 그리드, 시그니처 장수 표시)** → 모든 영웅 덱 제작 가능
- 저장: **10칸 슬롯 시스템** — 슬롯 픽커 오버레이(덮어쓰기 확인·슬롯별 삭제),
  구버전 저장 자동 마이그레이션. 팀 구성 덱 드롭다운 = 프리셋 + [슬롯번호] 내 덱
- 가져오기 2탭: **MarvelCDB 번호**(이전 빌드 방식 승계 — api/public/decklist/{id}.json,
  a/b 접미사 제거+5자리 패딩 정규화, mcode→슬러그 역매핑, hero_code→영웅 자동 식별,
  URL 통째 붙여넣기 허용) / 텍스트 목록(기존)
- 팀 슬롯: 미니 로우 → 현재 영웅 카드 + 픽커. 덱 없는 영웅으로 출격 시 안내 후 차단

**검증:** 회귀 전체 통과 · 헤드리스 매핑 검증 (접미사/패딩/미인식/영웅 식별) ·
신분 표본 스탯 공식 일치 (베놈 ATK2/HP12, 토르 HP14 등)

**주의:**
- 31영웅은 커스텀/가져온 덱으로 플레이 가능하나 영웅별 고유 능력·시그니처 카드 능력은
  todoFx(수동) 상태 — Phase 3 파이프라인 대상
- marvelcdb fetch는 사용자 브라우저에서 실행 (공개 덱리스트만, 인터넷 필요)


## v2026.07.08.7 — 메뉴 재구성 (6종) · 덱빌더 · 가져오기 · 저장 · UI 과장
**무엇을:**
- 메인 메뉴 6종: 게임 시작(솔로) / 핫시트(1~4) / 멀티플레이(준비 중 태그) /
  덱빌더 / 덱 가져오기 / 이어하기(저장 있을 때 활성)
- 인원 선택 화면 제거 → 팀 구성 화면으로 흡수: 슬롯 단위 (+영웅 추가, 슬롯별
  영웅 미니 선택 + 덱 드롭다운[프리셋/내 덱])
- 빌런 화면 탭: 개별 빌런 / 시나리오(캠페인) — CAMPAIGNS.core (라이노→클로→울트론 체인 표시,
  준비 중 빌런 잠금)
- 덱빌더 v1: 영웅 필수 세트 자동 포함(공식 수량 copies — zzorba quantity 채택으로
  시그니처 15장 정확 일치 확인), 성향 탭(성향 전환 시 확인 후 비움), 기본 카드 풀,
  카드별 deckLimit(zzorba deck_limit 이식) 강제, 40~50장 검증, localStorage 저장
- 덱 가져오기 v1: 텍스트 파서 ("3x 태클"/"tackle x3"/슬러그, 한/영 이름 정규화 매칭),
  미인식 목록 표시, 영웅 자동 감지, 저장
- 저장/이어하기: 액션마다 자동 저장(MC.serialize → localStorage), 이어하기로 복원,
  버전 불일치 경고
- UI 과장: 스피드라인 방사 배경, POW!/BAM! 스타버스트, 4px 잉크 보더 + 7px 오프셋 섀도,
  버튼별 기울기 교차, 팝인 애니메이션, 컬러 블록 메뉴 버튼(빨/파/보/초/노/잉크)

**검증:** 회귀 전체 통과 · 빌드 파싱 OK · UI 헤드리스 로드 OK ·
시그니처 수량 15 정확 (backflip×2, 웹킥×3 등)

**주의:**
- localStorage는 배포 HTML(파일/웹) 기준 동작. 브라우저 프라이빗 모드에선 저장 안 될 수 있음
- 가져오기 v1은 텍스트 전용 — marvelcdb URL 직접 가져오기는 CORS 이슈로 보류 [I-1]
- 멀티플레이 버튼은 자리만 (RtcTransport N-1 대기)


## v2026.07.08.6 — 코믹스 테마 UI + 메뉴 흐름 재구성
**무엇을:**
- 코믹북 디자인 시스템 도입: 하프톤 도트 페이퍼 배경(메뉴), 굵은 잉크(3px) 테두리 +
  오프셋 섀도(5px 5px 0), 스타버스트(clip-path), 캡션 박스, 말풍선, 기울인 패널
  - 폰트: Bangers(라틴 타이틀) + Black Han Sans(한글) — Google Fonts
  - 팔레트: 코믹 원색 (레드 #e23636 / 옐로 #ffd23e / 블루 #2a6bd4)
- 메뉴 흐름 상태 머신: 타이틀 → STEP1 영웅 선택 → STEP2 빌런 선택 → STEP3 인원 → 전투 개시
  - 로스터 그리드: 준비 완료/준비 중 태그 (미구현 영웅·빌런은 잠금 표시로 확장 자리 확보)
  - 영웅 아트 코드 zzorba 검증: 캡틴마블 01010a·쉬헐크 01019a·아이언맨 01029a·블랙팬서 01040a,
    클로 01113 / 울트론 01134 (초기값 01127 오기 → 검증에서 정정)
- 게임 보드: 다크 코믹 패널 스타일로 통일 (잉크 테두리+그림자, 존별 그라데이션,
  방어 대기 존 펄스 애니메이션, 코믹 토큰/승패 배너)

**검증:** 회귀 전체 통과 · 빌드 파싱 OK

**보류 추가:** [U-4] 난이도 선택(표준/전문가) 화면 — 전문가 세트 마이그레이션과 함께
[U-5] 좌석별 영웅 개별 선택 (영웅 2종 이상 준비되면)


## v2026.07.08.5 — 결제 시스템 자동화 (요소 모델 + 결제 팝업 UI)
**무엇을:**
- 엔진(mc_4): 결제 요소(element) 모델 — {kind:'hand'} / {kind:'ability'}
  - computePayment(무변이 검증) / validatePayment / executePayment 분리
  - RESOURCE_ABILITIES 레지스트리 신설. 1호: 과학자(피터 파커) — 정신 1, 알터에고, 라운드 1회
    ★ 공식 대조로 인덱스 오류 정정: "아무 타입"(구 설명) → 공식은 [mental] 고정
  - doubleForAspect 모델: 수호/정의/리더십/용맹의 힘 — 해당 성향 결제 시 생성 자원 2배
    ★ 정정: "2배 제한 자원"이 아니라 "와일드 1 + 성향 일치 시 2배"가 공식
  - 요소 중복 거부·자원 카드 직접 플레이 금지·초과 지불 허용(소멸)
- playCard: payment 요소 배열 수용 (구형 paymentUids 호환 유지)
- UI: 결제 팝업 — 손패 타일(아이콘·×2 표시), 신분 자원 능력 타일(사용 불가 시 비활성),
  실시간 합계/부족·초과 표시, ⚙ 자동 선택(부분합 DP: 정확 합계 우선·최소 요소·최소 초과)
- 라운드 종료 시 자원 능력 플래그 리셋 (mc_5 endRound)

**검증:** test_payment 12/12 · 회귀 전체 통과 · autoSelect 헤드리스 검증
(보호 비용2→1요소 정확, 비용3→genius+tackle 정확 3)

**보류 추가:**
- [P-1] 자동 선택 고도화: 동가치일 때 제한/성향 일치 자원 우선 소비 (유연 자원 보존)
- [P-2] 인플레이 자원 생성기(퀸캐리어 등 소진형) — 요소 kind:'card'로 확장 예정
- [P-3] 특정 자원 요구 카드(requires) UI 노출


## v2026.07.08.4 — Phase 2: 카드 DB 마이그레이션 (1,177장 전량)
**무엇을:**
- tools/migrate_index.py: 인덱스 JSON → cards/mc_cards_db.js (데이터 전용, 슬러그 키)
  - 이미지 URL에서 공식 코드(mcode) 자동 추출 → zzorba(공식 데이터 4,230장)와 교차검증
  - ★ 표본 검증에서 인덱스 boost 아이콘 체계적 과소 발견 (샌드맨 1↔공식 2)
    → 스탯류(cost/atk/thw/hp/boost/sch/후유증)는 zzorba 값 자동 채택, 298건 리포트 보존
  - 스킴 위협은 zzorba 스키마 정밀 매핑 (base_threat_fixed / threat per-player / escalation)
  - 자원 아이콘: 52장 자동 보정 (이중 자원 포함), 잔여 미확정 6장 (사용자 질문 대상)
  - effect 플래그 947장 → docs/effect_flags_report.json 보존 + 카드에 todoFx 마커
- cards/mc_cards_fx.js: 능력 등록 레이어 신설 (defineCardFx — todoFx 해제 창구)
  1호 등록: swinging-web-kick
- cards/mc_cards_scenarios.js: 라이노 조우덱 29장(라이노+폭탄 위협+표준), 스파이더맨
  보호 프리셋 40장 (이전 빌드 PRESET_DECK_IDS 승계) — DB 무결성 검증 통과
- baseFields에서 텍스트/이미지류 제거 (정의 전용 — 인스턴스/직렬화 비대화 방지),
  hinder/incite 키워드 정식 등록
- UI: 프리셋/시나리오 연결, 정의 image 우선 사용, todoFx '수동' 배지,
  더블탭 카드 상세 오버레이(큰 이미지+룰 텍스트)

**검증:** test_index 1,183장 미등록 0 · 회귀 전체 통과 · 실전 조우덱 4인 스모크 크래시 0 ·
빌드 1.29MB 파싱 OK

**주의/보류:**
- [D-2 갱신] 자원 미확정 6장: hawkeye-cap, milano, odin-captive, odin-king, death-glow,
  dragonfang → 사용자 확인 필요
- [D-3] 이미지 없는 카드 40장 (텍스트 폴백으로 표시됨) — 목록은 effect_flags_report의 noImage
- [D-4] 능력 미구현(todoFx) 947장 — Phase 3 파이프라인 대상. UI '수동' 배지로 표시
- 조우 카드 능력이 아직 수동이라 배신 카드는 공개 후 무효과 버림 (룰과 다름 — Phase 3 전까지)


## v2026.07.08.3 — Phase 1(UI부): 정식 UI 이식 (이전 빌드 레이아웃 승계)
**무엇을:**
- 이전 빌드(v802)에서 디자인 토큰·존 구조 CSS 추출/이식 (RESET&TOKENS, GAME BOARD 계열)
- 카드 이미지 체계 확립: marvelcdb 코드 = 이미지 파일명 → `bundles/cards/{code}.png` 직결.
  구 IMAGES 맵(수동 매핑) 불필요. 로드 실패 시 텍스트 폴백.
- 4인 보드: 빌런 존(HP바·단계·상태토큰) / 스킴 존(위협바·사이드스킴) /
  플레이어 존×N(신분 카드 탭=flip, 스탯, 교전 하수인, 플레이 영역, 손패 이미지 행)
- 인터랙션: 결제 선택(금색=플레이 카드, 파랑=자원), 대상 선택 모드(점선 하이라이트),
  방어 선언 배너(신분/동료/무방어), 에러 토스트, 선 플레이어 토큰 표시
- 디버그 UI는 폐기, 정식 UI로 교체

**왜:** 사용자가 실제 판단 가능한 수준의 시각적 완성도 필요. 이미지 직결 방식으로
Phase 2 마이그레이션 시 1,177장이 자동으로 그림을 얻는 기반 마련.

**검증:** 회귀 전체 통과(엔진 무변경) · 빌드 62KB 파싱 OK

**보류 항목:** (기존 유지) + [U-1] 스킴 카드 가로 이미지 회전 표시(이전 빌드의 JS 인라인
rotate 방식 참조), [U-2] 카드 확대 보기(롱탭/더블탭), [U-3] 버림 더미 열람


## v2026.07.08.2 — Phase 1(엔진부): 핵심 룰 프레임 완성
**무엇을:**
- 플레이어 액션 세트 (mc_7): playCard(자원 결제·유니크 검증·유형 라우팅),
  basicAttack/Thwart/Recover(형태·소진·기절/혼란·수호 검증), allyAttack/Thwart(후유증 피해),
  flipForm(라운드 1회), resolveDefense, endPlayerPhase(보충→준비→빌런 페이즈)
- 빌런 페이즈 재설계 (mc_5): **스텝 큐(G.vq) + 대기-결정(G.pending) 머신** —
  방어 선언이 액션(resolveDefense)으로 들어와 큐 재개. 결정=액션이라 재생 동기화 그대로 성립.
  빌런+하수인 활성화(라이브 조회), 증폭(즉시 버림), 속공(공개 중 방어 대기 + 큐 복귀)
- 다단계 전환: 빌런 stage(HP 리셋·부착/상태 유지), 메인 스킴 stage, 사이드 스킴 격퇴 훅
- mc_4: drawUpToHandSize/readyAllFor/flip 라운드 제한 · mc_6: hasGuardEngaged, 단계 전환 실구현
- 시드 카드 11장 (블랙캣 추가 — thwCost 검증용)

**왜:** 4인 각자-화면의 전제인 "결정=액션" 구조를 방어 선언까지 관통시켜
멀티 동기화 계약을 실제 인터랙션에서 증명하기 위함.

**검증:** test_index 미등록 0 · test_phase1 **35/35** · test_smoke 9/9 ·
시뮬 200판(1~4인 혼합) **크래시 0** · ★ 전체 게임 재생=원본 직렬화 완전 일치(엄격)

**수정 이력(이번 세션):**
- nextStage를 정의 전용 필드로 정리 (인스턴스 복사 불필요 — cardDef 조회)
- 다단계 판정이 인스턴스 필드를 보던 버그 수정 (cardDef 경유로)
- 증폭 카드 라이브 참조 보관 제거 → 즉시 버림 (직렬화 안전 원칙: 상태엔 uid 참조만)

**보류 항목:** (기존 T-1, D-1, D-2, N-1 유지)
- [R-2] 과잉살상 잉여 피해 이월, 공격 이벤트의 isAttack 판정(보복 연동), 위기(crisis) 아이콘,
  페이즈 종료 시 선택적 손패 버림 — Phase 2
- [R-3] 하수인 순찰(patrol)/교전 규칙 정밀화, 알터에고 능력 사용 — Phase 2


## v2026.07.08.1 — Phase 0: 엔진 골격 + 도구 세트 (초기 커밋)
**무엇을:**
- 샤드 7종 생성 (mc_1_terms ~ mc_7_core, 플레이북 §12 구성 준수)
  - TERMS/GLOSSARY: 이전 빌드(v802) 한국어 용어 승계 (용맹/정의/리더십/보호, 수호 등)
  - EFFECTS 9종 원시 효과 + runEffectList / HANDLERS + fireHook·fireCardHook
  - 플레이어 모델 1~4인 1급 개념 (makePlayer, flip, 자원 결제 payCost, 덱 소진 룰)
  - 빌런 페이즈 자동화 프레임 (위협→활성화(증폭)→인카운터 배분/공개→선 이동)
  - 피해 파이프라인 (강인/관통/보복/처치) 단일화 + condCheck 6종
  - 시드 RNG(mulberry32) + 액션 로그 dispatch + 직렬화 — 멀티 동기화 계약의 심장
- 도구: reassemble.py / build.py / test_index.js / run_tests.sh / test_smoke.js
- net/mc_net.js 전송 어댑터 계층 (LocalTransport 완성, RtcTransport 자리)
- 시드 카드 10장 (zzorba core.json/core_encounter.json에서 데이터 확정, 능력 미등록)

**왜:** 4인 각자-화면 플레이 요구 → 결정적 엔진 + 액션 로그 방식이 전제.
이전 빌드는 1인 전용·하드코딩 1,384함수·Math.random 82곳이라 재사용 불가(의미 참조만).

**검증:** 문법 OK · test_index 10장/미등록 0 · 스모크 8/8 통과
(1인·4인 30라운드 크래시 0, 빌런 HP·스킴 한도 인원 스케일 확인, 결정성 직렬화 일치)

**아키텍처 규칙 (신규 확정):**
- ★ RNG는 오직 dispatch된 액션 실행 내부에서만 소모한다. 클라이언트 결정 로직이
  G의 RNG를 건드리면 재생(replay) 동기화가 깨진다. (스모크 테스트 3에서 확인된 원칙)
- Math.random 전면 금지 — MC.rand(G)만.

**보류 항목:**
- [T-1] 한국어판 공식 용어집 대조 (현재: 이전 빌드 용어 승계 상태)
- [D-1] 인덱스 JSON(1,177장) 마이그레이션 — Phase 2. dedupe 필요 (1,377→1,177)
- [D-2] 자원 아이콘 누락 58장 — zzorba 교차검증 후 잔여분 사용자 질문
- [N-1] RtcTransport(WebRTC 스타형, 수동 시그널링) 구현 — Phase 1 후반
- [R-1] 스킴/빌런 다단계 전환, 방어 선언, 잔여 손패 보충 규칙 정밀화 — Phase 1
