# HANDOFF — 마블 챔피언스

- **버전:** v2026.07.15.416 (졸라 시나리오 완전구현 — 레드스컬 캠페인 4번째. [빌런3단계] 04109/04110/04111(HP12/14/16, retaliate1 자동적용, 04110 whenRevealed revealSideScheme:04123, 04111 searchMinionEachPlayer). [메인스킴] 04112a/b 졸라섬(1B baseThreat0/max6 testPerVillainPhase nextStage04113b) → 04113a/b 미친박사(2B baseThreat1/max8 testPerVillainPhase whenRevealed searchMinionEachPlayer nextStage없음=완료시패배). [하수인3] 04114 얼티밋바이오서번트(toughness, minionStatScale.perSelfAttachment:1 자신부착당ATK+1, boostStar 빌런tough), 04115 졸라뮤테이트(whenRevealed attachTechToSelf 조우덱Tech탐색부착, boostStar shuffleSelfIntoEncounter), 04116 광폭뮤테이트(quickstrike, boostStar placeTestCounter+berserkTestBonus). [부착3] 04117방어프로그래밍(attachTarget minionMostHp+grantsMinionGuard+hp2)/04118통증억제기(hp2+retaliate1)/04119신경임플란트(hp2). [배반2] 04120마인드레이(formBranch 알터:졸라암약+혼란/히어로:졸라공격+기절)/04121기술적강화(incite1+placeTestCounter, boostStar placeTestCounter). [사이드스킴3] 04122하이드라감옥(hero전용동료 시스템 todoFx)/04123실험대상(whenDefeated discardUntilMinion)/04124졸라의실험(Tech부착 todoFx). [test counter 시스템] mc_5 빌런페이즈 step1후 testPerVillainPhase면 testCounters++, 3개도달시 discardUntilMinionIntoPlay+3제거. placeTestCounter/berserkTestBonus/revealSideScheme EFFECT 신규. condCheck discardHadTrait는 04105용. UI testChip(🧪 실험 카운터, delayChip 옆). [신규 EFFECT] revealSideScheme/placeTestCounter/attachTechToSelf/shuffleSelfIntoEncounter/berserkTestBonus. [baseFields추가] testPerVillainPhase/grantsMinionGuard. [부착 attachTarget] minionMostHp(하수인만 남은HP최다+동일부착없음, 없으면surge)+grantsMinionGuard. [enemyAtkPassive] perSelfAttachment 추가(04114). [QUOTES] zola 빌런10/10/10/5/5 + 하수인04114/04115/04116 5/5/5. [VFX] zolaEntrance(독성초록🧪🧬☣️)/zolaAttack(초록광선)/zolaStageUp(진화)/zolaDefeat(시스템붕괴). [SCENARIOS.zola] villainStart04109/mainScheme04112b/조우덱26장(Zola세트 매수정확)/setupRevealSideScheme04122/setupEngageMinion04114(각플레이어 교전배치)/defaultModular under-attack/comicDefeat[13,14] 졸라격파→레드스컬등장 의역. VILLAIN_ROSTER+META+캠페인 ready:true. startGame setupEngageMinion 처리. [under-attack 모듈러 수정] 잘못된 slug(shield-team등)→실제등록 under-attack/concussion-blasters/concussive-blast×2/vibranium-armor-u(Core#151-154). 검증: 게임셋업정상, test counter 정상, retaliate1, 메인스킴체인. 다음: 레드스컬 시나리오(캠페인 최종, 세트22장 04125-04144).
- **[신규] 처치 인터럽트 메커니즘:** 동료 처치 시 자원 지불 → 효과 + 손 반환 (Red Dagger)
- **[신규] 다중 활성능력 + 카드 보관소:** activatedAbilities 배열 + stored[] (Bruno)

## v2026.07.15.310 (미즈마블 프리빌트덱 — PRESET_DECKS 등록)
- **미즈마블(ms-marvel) 프리빌트덱 추가**: PRESET_DECKS에 '미즈마블 / 수호'(Protection) 40장 등록 → 이제 게임 시작 화면에서 미즈마블 선택+플레이 가능
- 시그니처 15: red-dagger + big-hands×3 + sneak-by×3 + wiggle-room×2 + aamir-khan + bruno-carrelli + nakia-bahadir + biokinetic-polymer-suit + embiggen + shrink
- 수호(Protection) 14: nova-ally + preemptive-strike×2 + energy-barrier×2 + tackle + med-team + armored-vest + indomitable + counter-punch + get-behind-me + electrostatic-armor + power-of-protection×2
- + _basicCore 11. 검증: 40장 누락 0·deckLimit 준수·셋업(덱34+손6, HP10) 정상. 회귀 통과
- ★ 미즈마블 네메시스(05025~29: home-by-dawn 의무·generation-why 사이드스킴·thomas-edison/edisons-giant-robot 하수인·harvest 배반)는 여전히 todoFx — 시나리오 셋업 통합 시 별도 배선(프리빌트덱과 독립)

## v2026.07.15.311 (미즈마블 프리빌트덱 검증·확정)
- **미즈마블 프리빌트덱(ms-marvel / 수호)** PRESET_DECKS 등록 확정 — 이전 세션(v310) 소스 작성분을 재조립·회귀 통과·배포로 마무리
- 구성 40장: 시그니처15(red-dagger + big-hands×3 + sneak-by×3 + wiggle-room×2 + aamir-khan + bruno-carrelli + nakia-bahadir + biokinetic-polymer-suit + embiggen + shrink) + 수호(Protection)14(nova-ally + preemptive-strike×2 + energy-barrier×2 + tackle + med-team + armored-vest + indomitable + counter-punch + get-behind-me + electrostatic-armor + power-of-protection×2) + _basicCore 11
- 검증: 누락0·덱리밋 준수·셋업(덱34+손6, HP10, 알터에고) 정상. test_preset_decks.js 회귀 통과(ms-marvel 셋업 6장/34장). 전체 회귀 통과
- 이제 게임 시작 화면에서 미즈마블 선택 → 프리셋 덱으로 플레이 가능(이전엔 "덱 없음" 토스트로 불가였음)
- ★ 미배선 잔여: 미즈마블 네메시스 5종(05025~29, 시나리오 셋업 통합 시 별도 배선). 프리빌트덱과 독립

## v2026.07.15.309 (호크아이 04004 — Mockingbird)
- **04004 Mockingbird**(방어 동료, cost3 ATK2/THW2/HP3, 🌟wild): "인터럽트: 빌런이 당신을 공격할 때 → 아무 자원1 소비 + 모킹버드 손 반환 → 그 공격 피해 전부 방지". 무한 재활용 방어 동료
- **useDefenseInterrupt 인덱스 확장(범용)**: payAny(자원 지불), preventAll(전체 방지, prevent:N과 분기), returnToHand(EFFECTS.returnToHand로 인플레이 제거+상태 리셋 손 반환, discardSelf 분기와 else)
- VFX mockingbirdEnter/mockingbirdBlock(청록 배튼). 검증: 자원1→전부 방지(pending 해소)+인플레이 제거+손 반환 정상. 회귀 통과
- 다음: 04005~09 화살 이벤트 5종(활 소진 비용 + ranged) → 04010 Expert Marksman

## v2026.07.15.309 (호크아이 04004 — Mockingbird)
- **04004 Mockingbird**(방어 동료, cost3 ATK2/THW2/HP3, 🌟wild): 인터럽트 "빌런이 당신을 공격할 때 → 아무 자원1 소비 + 모킹버드 손 반환 → 그 공격 피해 전부 방지". 무한 재활용 방어 동료
- **useDefenseInterrupt 인덱스 확장(범용)**: payAny(자원 지불), preventAll(EFFECTS.preventAll 전체 방지, prevent:N과 분기), returnToHand(EFFECTS.returnToHand로 인플레이 제거+상태 리셋 손 반환, discardSelf/카운터 소진과 else 분기)
- 공식 자원 🌟wild(trors.json). VFX mockingbirdEnter/mockingbirdBlock(청록 배튼). 검증: 방어 pending→자원1 지불→전부 방지(pending 해소)+인플레이 제거+손 반환 정상. 회귀 통과
- 다음: 04005~09 화살 이벤트 5종(활 소진 비용 + ranged, 공통 인덱스로 데이터 찍기) → 04010 Expert Marksman

## v2026.07.15.308 (호크아이 04003 — Hawkeye's Quiver)
- **04003 Hawkeye's Quiver**(도구 업그레이드, cost1): 지속 "부착된 화살(Arrow) 이벤트를 손처럼 플레이 가능" + 히어로 행동 "Quiver 소진 → 덱 top5에서 화살 이벤트 1장 앞면 부착(나머지 원순서 복귀)"
- activatedAbility{form:hero,exhaust,special:'quiverSearch'} + HANDLERS.quiverSearch(arrow trait event 첫 1장 부착). **playCard fromQuiver 소스(부착 화살을 손처럼 플레이, splice로 제거, 이벤트는 discard)** 완비
- VFX quiverInstall/quiverSearch(🏹 화살 꽂기). 검증: 서치→부착(sonic-arrow)·소진·덱-1·fromQuiver 소스 정상. 회귀 통과
- 다음: 04004 Mockingbird(방어 동료) → 04005~09 화살 이벤트(활 소진 비용 + ranged 부여, 부착 화살 플레이) → 04010 Expert Marksman
- ★ 미완: Quiver 부착 화살 UI 플레이 버튼(엔진 fromQuiver 완비, UI 노출 필요) — 화살 이벤트 배선 후 UI 작업

## v2026.07.15.307 (호크아이 04002 — Hawkeye's Bow)
- **04002 Hawkeye's Bow**(무기 업그레이드, 한정, cost0): "히어로 ATK +1 + 화살(Arrow) 공격에 원거리(ranged) 부여". **statMod{attack} → passiveStatMod 인덱스 재사용(combat-training 동일)** — ATK 부분 신규 코드 0줄
- grantsArrowRanged 플래그(baseFields 등록) — 화살 이벤트가 "활 소진" 시 참조해 그 공격에 ranged(수호 하수인 무시) 부여 예정
- 신규 파일 cards/mc_cards_zzhawkeye_fx.js(호크아이 시그니처 전용, mcode 순). VFX bowInstall(🏹 보라 에너지 호). 검증: ATK 2→3·제거 원복 정상. 회귀 통과
- 다음: 04003 Quiver(화살 비축) → 04004 Mockingbird(방어 동료, 자원1+손반환→피해 전부 방지) → 04005~09 화살 이벤트(활 소진 비용 + ranged) → 04010 Expert Marksman(화살 전용 자원)

## v2026.07.15.306 (호크아이 04001 신분 능력 — The Rise of Red Skull 팩 착수)
- **04001a Quick Draw**(히어로): "호크아이 소진 → 호크아이의 활(04002) 준비". exhaustSelf(자기 소진 비용) + readyNamedCard 인덱스. 활 재장전으로 화살 이벤트 연사
- **04001b Weapon of Choice**(알터에고): "아무 자원 1 소비 → 덱/버림에서 활 서치 → 손 (페이즈당 1회)". payAny + oncePerPhase + searchDeckToHand(mcode 필터+includeDiscard) 재사용
- **identityAction 인덱스 확장(범용, 재사용 가능)**: exhaustSelf(효과 후 히어로 소진, 준비상태 요구), payAny(아무 자원 N), oncePerPhase(usedIdentityActionThisPhase[form], 라운드 리셋에 추가). EFFECTS.readyNamedCard 신규(exhaustNamedCard 대칭 — 특정 slug/mcode 카드 준비)
- 공식: trors.json(RoRS 팩 코드 trors). VFX quickDraw/weaponChoice(🏹 보라 섬광). 검증: Quick Draw 활 준비+자기 소진+소진 재사용 거부 / Weapon of Choice 활 서치+페이즈당 1회 거부 전부 정상. 회귀 통과
- 다음: 호크아이 시그니처 mcode 순 — 04002 Hawkeye's Bow(활, ATK+1/화살 ranged) → 04003 Quiver → 04004 Mockingbird → 04005~09 화살 이벤트(활 소진 비용) → 04010 Expert Marksman

## v2026.07.15.305 (미즈마블 성향카드 05033 — Down Time / ★ 미즈마블 팩 성향카드 전체 완료)
- **05033 Down Time**(basic 업그레이드, condition, attachTarget:hero, cost1, 💪physical): "알터에고 REC +2(영구)". **statMod{stat:'recover',amount:2} → passiveStatMod 인덱스 100% 재사용(combat-training ATK+1 동일 패턴)** — 신규 엔진 코드 0줄
- basicRecover가 statOf(recover)를 사용하므로 REC +2 자동 반영. 공식 자원 재확정: 💪physical(textKo 🧠 오기)
- VFX downtimeInstall(초록 회복 오라 + REC＋２). 검증: REC 3→5·회복 액션 5 회복(down-time 없으면 3, +2 정확)·제거 시 원복 정상. 회귀 통과
- ★★ **미즈마블 팩 성향카드 10장 전체 완료**: Nova(05012)·Rapid Response(05013)·Preemptive Strike(05014)·Energy Barrier(05017)·Lockjaw(05018)·Endurance(05023)·Enhanced Reflexes(05024)·Concussive Blow(05031)·Morale Boost(05032)·Down Time(05033) + 기존 Tackle(05015)·Melee(05030)

## v2026.07.15.304 (미즈마블 성향카드 05032 — Morale Boost)
- **05032 Morale Boost**(leadership 이벤트, cost1, ⚡energy): "히어로 1명 이번 라운드 THW+1/ATK+1/DEF+1". **roundStatBuff 범용 EFFECT + roundStatBonus 인덱스(statOf 합산, 라운드 종료 리셋) 100% 재사용** — 신규 엔진 코드 0줄
- statOf(mc_4_players 64/330 히어로+동료)가 roundStatBonus 합산, 라운드 종료 시 리셋(mc_5_encounter 571). ctx.targetPlayer로 멀티 대상 선택 지원
- 공식 자원 재확정: ⚡energy (textKo 💪 오기). VFX moraleBoost(황금 상승 오라). 검증: THW/ATK/DEF 각 +1·라운드 종료 원복 정상. 회귀 통과

## v2026.07.15.303 (미즈마블 성향카드 05031 — Concussive Blow)
- **05031 Concussive Blow**(justice 공격 이벤트, cost3, 💪physical): "적 1명 혼란 + 💪피지컬 지불 시 3 피해". **tackle(applyStatus + dealDamageIfPaid) 인덱스 100% 재사용, status만 stunned→confused** — 신규 엔진 코드 0줄
- 공식 자원 재확정: 💪physical (db physical:1 정확, textKo 🧠 오기)
- VFX concussiveBlow(충격파 이중 링 + screenShake + 혼란 별 💫 3개 소용돌이). 검증: 💪 지불→혼란+3피해 / 비-💪(🧠) 지불→혼란만 피해0 전부 정상. 회귀 통과

## v2026.07.15.302 (미즈마블 성향카드 05024 — Enhanced Reflexes)
- **05024 Enhanced Reflexes**(basic 업그레이드, condition, uses3, cost2, ⚡): "히어로 자원: 소진 + 에너지 카운터1 제거 → ⚡에너지 자원 1개 생성(히어로폼 전용)". **web-shooter(uses+resourceGenerator{form:'hero',exhaust,counter}) 인덱스 100% 재사용, 아이콘만 wild→energy** — 신규 엔진 코드 0줄
- resourceGenerator 인덱스가 form 전용/소진/카운터 차감/카운터 소진 시 자동 버림 전부 처리
- VFX reflexInstall(에너지 카운터 3개 점등 + 속도선). 검증: 카운터 3로 설치·⚡1 생성(카운터-1·소진)·3회 소진 후 자동 버림·알터에고 거부 정상. 회귀 통과

## v2026.07.15.301 (미즈마블 성향카드 05023 — Endurance)
- **05023 Endurance**(basic 업그레이드, condition, attachTarget:hero, cost1, ⚡): "당신 HP +3(현재+최대 모두)". **hpBonus:3 + whenPlayed refreshMaxHp 인덱스 100% 재사용**(mk5-armor/rocket-boots 동일 패턴) — 신규 엔진 코드 0줄
- recomputeMaxHp가 설치 시 현재+최대 델타 조정 / 제거 시 최대 감소 + 현재 초과분만 클램프를 이미 정확히 처리
- VFX enduranceInstall(청록 생명력 방패 펄스 + ＋３HP 텍스트). 검증: 피해 상태 설치(6/10→9/13, 현재+3 최대+3)·제거(최대 원복 10, 현재 초과분만 감소) 정상. 회귀 통과

## v2026.07.15.300 (미즈마블 성향카드 05018 — Lockjaw 버린더미 재플레이)
- **05018 Lockjaw**(basic 동료, cost4, ATK2/THW2/HP4 Inhuman, unique): "당신의 턴 동안 버린더미에서 록조를 플레이 가능(정상 비용 지불)". playableFromDiscard:true 필드 — playCard의 fromDiscard 경로(이미 완비)로 처리. 반복 재플레이 블록 동료
- **UI fromDiscard 관통**: openPay(playerUid,cardUid,fromDiscard) → payPopupHTML/payConfirm 카드 조회를 pl.discard로 분기 → playCard dispatch에 fromDiscard 전달. pileViewHTML(자기 버림더미 모달)에 playableFromDiscard 카드 "플레이" 버튼 + UI.playFromDiscard. pileOpen에 playerUid 저장
- **재배치 리셋 룰**: playCard ally case에 fromDiscard 분기 — 인플레이를 떠났던 카드이므로 hp=maxHp + damage/exhausted/status/attachments 완전 초기화
- VFX lockjawTeleport(순간이동 이중 링 워프). 검증: 손패 정상플레이·처치→버림·버린더미 재플레이(HP 4/4 리셋)·유니크 중복 거부·일반카드 버린더미 거부 전부 정상. 회귀 통과

## v2026.07.15.299 (미즈마블 성향카드 05014·05017 — Preemptive Strike + Energy Barrier)
- **05014 Preemptive Strike**(protection 방어이벤트): 부스트 취소 — HANDLERS.preemptiveStrike: 방어 pending의 boostCard 취소(p.boostCard=null, 앞면공개 없이 버림→★미발동) + MC.boostOf 아이콘 수만큼 빌런 피해. defenseInterruptEvent:true 필드 → 방어창 defEvents 필터에 포함. maybeOfferMorphResponse에 G.pending 가드(방어창 이벤트가 morphResponse로 덮이는 것 방지)
- **05017 Energy Barrier**(protection 업그레이드): 반영 카운터 3(uses:3). useDefenseInterrupt 확장 — di.counter(카운터 소비) + di.damageEnemy(공격자 피해) + p.usedInterrupts(공격당 카드1회 제한) + 카운터 소진 시 자동 버림. 공격자 처치 시 공격 무효화. 방어창 버튼에 카운터/적피해 라벨
- baseFields에 defenseInterruptEvent 등록. VFX preemptiveStrike/energyBarrier
- 검증: Preemptive ▲3취소→빌런3피해·부스트없음 무피해 / Energy Barrier 카운터소비·1방지+1피해·공격당1회·소진버림 전부 정상. 회귀 통과

## v2026.07.15.298 (미즈마블 성향카드 05012~13 — Nova + Rapid Response)
- **05012 Nova**(protection ally): 공격개시 인터럽트 — attackInitiateInterrupt{cost:{energy:1},damage:2}. 방어 pending 중 동료 버튼 → novaPay 로컬 UI 결제(⚡/🌟) → ACTIONS.useAllyAttackInterrupt: 공격자 피해, 소진 안 함(반복), 공격자 HP≤0 시 방어 pending 해제(공격 무효). fireAttackInterrupt는 히어로만이라 방어창 UI로 처리
- **05013 Rapid Response**(leadership upgrade): 동료 처치 반응 — onDefeated ally 분기 → MC.maybeOfferRapidResponse(히어로 폼+RR 인플레이+동료 버린더미) → rapidResponse pending → ACTIONS.resolveRapidResponse: RR 버림 + 동료 전장 재소환(만피, 준비) + whenPlayed 재발동(등장효과) + 1피해. VFX rapidResponse(재소환)
- baseFields에 attackInitiateInterrupt/rapidResponse 등록
- 검증: Nova 빌런/하수인 피해·미소진·공격무효, Rapid Response 되살림(HP만피-1)·거부 전부 정상. 회귀 통과

## v2026.07.15.297 (Red Dagger + Bruno — 미즈마블 시그니처 10/10 완결)
- **05002 Red Dagger**: 처치 인터럽트 — ally 처치 시 defeatInterrupt(mc_6_keywords onDefeated) → allyDefeatInterrupt pending → 서로 다른 자원 2개 지불(MC.canPayDifferentTypes: 비-wild 서로 다른 타입+wild≥N) → 적 2피해 + 손 반환(피해/상태/부착 초기화). ACTIONS.resolveAllyDefeatInterrupt. UI: 대상 적 버튼 + 손패 자원 토글 + 지불/포기
- **05007 Bruno Carrelli**: 다중 능력 — activatedAbilities 배열(useCardAbility가 abilityIndex로 선택) + 뒷면 보관소 bruno.stored[]. AE 저장(brunoStore→brunoStorePick pending) + 어느 폼 회수 최대 3장(brunoRetrieve→brunoRetrievePick). moveToDiscard가 stored[] 동반 버림. UI: 능력 2버튼(activatedAbilities 렌더) + 저장/회수 pick
- **05010 Embiggen!/05011 Shrink**: 이벤트 부스트 인터럽트(v296, eventBoostChoice pending, +2 피해/위협제거)
- **엔진 확장**: MC.canPayDifferentTypes(자원 N종 서로 다름 검증), useCardAbility activatedAbilities 배열, moveToDiscard stored 처리. baseFields에 defeatInterrupt/eventBoost/activatedAbilities 등록
- 검증: Red Dagger 지불(2피해+손반환)·같은타입거부·포기 / Bruno 저장(AE)·회수(어느폼)·버림동반 전부 정상. 전체 회귀 통과
- **미즈마블(mc05) 시그니처 15장 전부 배선 완료** (05002~05011): 신분(Morphogenetics/Teen Spirit) + 시그니처 10종
- **[신규] 이벤트 강화 인터럽트 메커니즘:** 이벤트 해결 전 끼어들어 피해/위협 +2 (Embiggen! 05010, Shrink 05011)

## v2026.07.15.296 (이벤트 부스트 인터럽트 + Embiggen!/Shrink)
- **이벤트 플로우 리팩터링**: playCard 이벤트 브랜치 → `MC.resolveEventPlay(G,pl,card,ctx)`로 분리(effects+special+vfx+버림+Morphogenetics+whenPlayed). ctx.eventDamageBonus/eventThreatBonus 지원
- **부스트 선택 pending(eventBoostChoice)**: 이벤트 플레이 시 준비된 부스터(eventBoost 필드) 있으면 이벤트 해결 보류 → 플레이어가 소진할 부스터 선택 → resolveEventBoost가 보너스 얹고 resolveEventPlay. MC.readyEventBoosters(히어로폼+미소진+트레잇일치)
- **05010 Embiggen!**: eventBoost{trait:attack,stat:damage,amount:2} — 공격 이벤트 +2피해. **05011 Shrink**: eventBoost{trait:thwart,stat:threat,amount:2} — 저지 이벤트 +2위협제거
- **dealDamage/removeThreat**: ctx.eventDamageBonus/eventThreatBonus 가산. allowlist에 eventBoost 추가
- **UI**: eventBoostChoice 렌더(부스터 토글+확정/건너뛰기) + toggleEventBoost/confirmEventBoost/skipEventBoost
- 검증: Embiggen 6피해·Shrink 5제거·건너뛰기·소진제외 정상. 인터럽트→Morphogenetics 응답 체인 순서 정상. 전체 회귀 통과
- **남은 2장**: 05002 Red Dagger(처치 인터럽트+자원2 지불), 05007 Bruno(뒷면 카드 보관/회수)
- **[신규] 미즈마블 시그니처 6장:** Big Hands·Sneak By·Wiggle Room·Aamir Khan·Nakia·Biokinetic Suit

## v2026.07.15.295 (미즈마블 시그니처 배치1: 05003·04·05·06·08·09)
- **05003 Big Hands**(공격이벤트): dealDamage 4. **05004 Sneak By**(저지): removeThreat 3. **05005 Wiggle Room**(방어인터럽트): preventAmount 3 + draw 1
- **05006 Aamir Khan**(서포트 AE액션): 신규 EFFECTS.recycleDiscardBottomDraw(버림 1장→덱바닥 + 드로우). **05008 Nakia**(AE액션): reduceNextPlayCost 1
- **05009 Biokinetic Polymer Suit**(업그레이드): resourceGenerator{form:hero,exhaust,icons:wild}. (공식 "이벤트 전용" 제한은 미구현 — 향후 강화)
- **엔진 확장**: recycleDiscardBottomDraw 효과, 방어인터럽트 감지에 preventAmount 포함(Wiggle Room), 신규 fx파일 mc_cards_zzmsmarvel_fx.js
- 검증: 6장 효과 전부 정상. 전체 회귀 통과. 한국어 플레이버 textKo 포함
- **남은 복잡 4장**: 05002 Red Dagger(처치 시 자원2 지불→2피해+손반환), 05007 Bruno(뒷면 카드 보관), 05010 Embiggen!(공격이벤트 +2피해 인터럽트), 05011 Shrink(저지이벤트 +2위협제거 인터럽트) — 전용 인터럽트/보관 메커니즘 필요, 다음 배치
- **[신규] 미즈마블(mc05) 신분 능력:** Morphogenetics(히어로) + Teen Spirit(알터에고) 배선

## v2026.07.15.294 (미즈마블 신분 — Morphogenetics + Teen Spirit)
- **미즈마블 05001a "Morphogenetics"**: 공격/저지/방어 이벤트 플레이 후 → 소진 → 그 이벤트를 손으로 반환(재사용). `afterEventResponse:{traits,vfx,prompt}` 필드 + playCard 이벤트 버림 직후 `MC.maybeOfferMorphResponse` 훅 → morphResponse pending. 조건: 히어로폼+미소진+이벤트 트레잇 일치
- **카말라 칸 05001b "Teen Spirit"**: 행동(라운드1회) — 덱 위에서 ms-marvel 카드 나올 때까지 버림 → 손에. `identityAction` + 신규 `EFFECTS.discardUntilHeroCard`
- **엔진**: ACTIONS.resolveMorphResponse(accept시 소진+버림더미→손), allowlist에 afterEventResponse 추가
- **UI**: morphResponse 렌더(반환/패스 2버튼) + UI.resolveMorphResponse
- **VFX**: embiggen(기본공격 거대주먹), morphReturn(모프 소용돌이), teenSpirit(별 스파클) — ui/mc_vfx.js
- 검증: Teen Spirit 밀링+라운드제한 / Morphogenetics 반환·패스·소진 3케이스 정상. 감사 ★배선됨. 전체 회귀 통과
- **다음**: 미즈마블 시그니처 카드(05002-05011: red-dagger/aamir/nakia/bruno/biokinetic-suit/embiggen/shrink/big-hands/sneak-by/wiggle-room) mcode순 배선
- **[수정] 빌런 스테이지 수 (코어 룰):** 일반이 I→II→III(3스테이지)로 잘못됐음 → 공식은 게임당 2스테이지(일반=I·II, 전문가=II·III). II 처치 시 승리(III로 안 넘어감)

## v2026.07.15.293 (난이도 빌런 스테이지 = 각 2스테이지)
- **공식 룰 확인(웹검색)**: 각 빌런 3스테이지 존재하나 게임당 2스테이지만 플레이. Rhino/Klaw/Ultron "Villain deck: (I),(II). Remove (I) add (III) for expert." fistfulofmeeples: "1&2 for standard, 2&3 for expert". Risky Business도 "Norman (I),(II), remove I add III"(캠페인 가이드) + Hall of Heroes "flip Norman twice"(I→II→승리)
- **버그**: 일반이 3스테이지(I→II→III)였음. II 처치 후 III로 넘어가면 안 되고 승리해야 함
- **수정**: setupGame에 `G.villainFinalStageNum`(시작 스테이지+1) 계산. onDefeated 빌런 분기: 스테이지번호가 최종번호 이상이면 승리, 아니면 진행. Risky Business 노먼↔고블린 플립(defCode 02002a/02002b 다름) 때문에 정확한 코드가 아닌 **스테이지 번호** 기준
- **검증**: 라이노/클로/울트론/뮤타젠/리스키비즈니스 모두 일반 1→2→승리, 전문가 2→3→승리
- UI 난이도 설명 갱신(표준=1·2단계, 전문가=2·3단계). 테스트 6개(rhino/ultron/klaw/goblin_flip/phase1) 2스테이지 룰로 업데이트 — 스테이지 메커니즘 검증용은 villainFinalStageNum=3 주입. 전체 회귀 통과
- **[수정] 손패 자원 버림 선택화:** Tombstone(첫 매치 자동)·Power Drain(무작위!)이 공식 텍스트상 "choose/if able"인데 자동/랜덤이었음 → 플레이어 선택(resourceDiscardPick, 다중 플레이어 큐)

## v2026.07.15.292 (손패 자원 버림 선택화)
- **공식 텍스트 확인**: Tombstone "discard a 🧠/💪 resource, if able" / Power Drain "each player must **choose and discard** ... for each boost" → 둘 다 무작위 아님(선택). Power Drain은 discardRandomFromHand(무작위) 오류였음
- **공용 헬퍼**: MC.resourceCandidates(pl,types) / MC.discardHandCard / MC.setupResourceDiscardPick(다중 플레이어 큐: 후보 0=스킵, ≤필요=자동전부, >필요=선택 pending)
- **resourceDiscardPick pending**: {player,count,chosen,types,queue,perPlayerCount} — 한 플레이어 완료 시 큐의 다음 플레이어로 자동 진행
- **엔진 ACTIONS.resolveResourceDiscardPick**: 자원 필터 검증 후 버림, count 도달 시 setupResourceDiscardPick로 큐 진행
- **UI**: resourceDiscardPick 렌더(후보 자원 카드만 탭) + UI.resolveResourceDiscardPick
- **★ 빌런 페이즈 pending 유지 버그**: resolveDefensePending이 attackDamagedEffects가 세운 pending을 무조건 G.pending=null로 덮어썼음 → `if (G.pending !== p) return`으로 효과가 세운 선택 pending 유지(큐 재개는 UI line 563이 해소 후 자동)
- 검증: Tombstone(🧠/💪만 후보, energy 제외) + Power Drain(2인 큐: 선택+자동) 정상. 전체 회귀 통과
- **[수정] 통제 카드 버림 플레이어 선택:** Caught Off Guard(허를 찌르다) 등 "업그레이드/지원 1장 버림"이 첫 장 자동 선택이었음 → 후보 2장+ 시 플레이어가 직접 선택(pickControlledDiscard pending). 무작위 아닌 자기카드 버림은 전부 선택

## v2026.07.15.291 (통제 카드 버림 선택화)
- **원칙**: 무작위(random) 명시 안 된 자기(통제) 카드 버림은 소유 플레이어가 선택 (공식 룰)
- **discardUpgradeOrSupport**(Caught Off Guard 01188): 후보 0=급증 / 1=자동 / 2+=pickControlledDiscard pending(플레이어 선택). surge는 후보 유무로 선판정(_discardedUpgradeOrSupport)
- **discardControlledUpgrade**(의무·블랙팬서 등): 동일하게 2+ 후보 시 선택. 영구/부착 제외 필터 추가
- **공용 헬퍼 MC.discardControlledCard**(G,pl,card,reason): upgrades/supports/allies에서 제거→버림
- **엔진 ACTIONS.resolvePickControlledDiscard**: 선택 카드 검증 후 버림, pending 해제
- **UI**: pending.kind pickControlledDiscard 렌더(후보 카드 얼굴 탭 선택) + UI.resolvePickControlledDiscard 디스패치
- 테스트 3종(caught_off_guard/electric_whip/obligation) 선택 pending 해소로 업데이트. 전체 회귀 통과
- **백로그**: 손패 자원 버림(Tombstone discardResourceFromHand, Power Drain) 무작위 여부 공식 확인 후 선택화 검토
- **[수정] VFX 좌상단 구석 처박힘:** speechBubble/speechBubbleAt/impactBurst가 앵커 rect 무효(0,0/NaN) 시 clamp로 (8,8) 구석에 뜨던 문제 → 화면 중앙 폴백
- **[감사 완료] "확인/공개" 효과:** peek(팔콘)만 로그전용이었고 v289서 수정. lookAtTopChoose(cardPick 카드얼굴)·repulsorBlast(fxReveal) 이미 표면화. discardTop*/returnTopTrait는 밀링·버림더미(가시)라 해당없음

## v2026.07.15.290 (VFX 앵커 폴백 + 감사)
- **speechBubble/speechBubbleAt**: rect 무효(width·height 0 또는 left≤0&&top≤0) 시 화면 중앙-상단(innerWidth/2, innerHeight*0.32)으로 폴백
- **impactBurst**: x/y 무효(0/NaN/undefined) 시 화면 중앙(innerWidth/2, innerHeight*0.4)으로 폴백
- 근본은 앵커 요소 조회 실패지만, 폴백으로 최소한 구석 처박힘 방지(대상 앵커 정상 시엔 대상 위 표시 유지)
- **확인효과 전수감사**: 로그전용 확인 효과는 팔콘 peek뿐(수정 완료). 나머지는 이미 표면화. 전체 회귀 통과
- **[수정] "확인/공개" 효과 가시성:** peekEncounterRemoveThreat(팔콘)가 로그만 남기고 확인한 카드를 플레이어에게 안 보여줬음. 리펄서 블래스트 패턴(G.fxReveal)으로 오버레이 표시. 향후 "look at/reveal" 계열은 fxReveal로 표면화 원칙

## v2026.07.15.289 (팔콘 조우덱 확인 표시)
- **원인**: peekEncounterRemoveThreat가 MC.log만 → 플레이어는 확인한 상위 3장을 못 봄(로그만). 리펄서빔은 G.fxReveal로 오버레이 표시하는데 peek은 안 했음
- **수정**: peek이 G.fxReveal={kind:'peek', cards:[{defCode,name,isMatch}], matchCount, threatRemoved, title} 설정. UI fxReveal 감지에 'peek' 추가 + fxRevealHTML에 peek 분기(부채꼴 카드 + 배신 강조 ✔ + 위협 제거 카운트업)
- 검증: 팔콘 등장 → 상위3 표시(배신 강조), 위협 제거량 일치. 전체 회귀 통과
- **원칙 추가**: "확인/공개"류 효과는 로그뿐 아니라 fxReveal로 플레이어가 직접 보게
- **[수정] 캡틴 아메리카 리빙 레전드:** 엔진엔 구현돼 있었으나(03001b livingLegend + playCard 할인 로직) UI가 card.cost 원가만 봐서 할인이 안 보이고 지불도 원가 요구 → 사실상 사용 불가였음

## v2026.07.15.288 (리빙 레전드 UI 반영)
- **원인**: 엔진 playCard는 리빙 레전드(-1)/nextCardDiscount를 적용하지만, UI 지불창(cost)·payAuto·손패 비용 배지가 전부 card.cost 원가만 사용 → 할인 미표시·미적용
- **수정**: 할인 계산을 순수 함수 `MC.playDiscountOf(G,pl,card)`{discount,nextDisc,ll} + `MC.playCostOf(G,pl,card)`로 추출(엔진 playCard도 이걸 사용, 부수효과 분리). UI 3곳(지불 threshold·payAuto·손패 배지) 전부 playCostOf 사용
- **손패 배지**: 할인 적용 시 초록색 + 원가 툴팁으로 시각화 → 리빙 레전드가 눈에 보임
- 검증: ally 3→2(-1), support 미할인, 라운드 1회 소진. 전체 회귀 통과
- **주의**: 캡틴 아메리카 신분 자체(identityAction 등)는 별도 — livingLegend만 이번 대상. 나머지 26영웅 신분 배선은 여전히 백로그
- **[수정] 플레이버 누락:** GG 카드들에 대사(QUOTES)만 넣고 인쇄 플레이버(info 이탤릭)를 빠뜨림. db 카드는 영어 flavor가 있었지만 parseCardText가 영어 억제 → 공백으로 표시됨. 한국어 플레이버 전면 추가
- **[작업 원칙 재확인]** 카드 배선 시 대사 + 플레이버(한국어 창작) 둘 다 필수. 앞으로 신규 카드는 플레이버도 함께

## v2026.07.15.287 (GG 플레이버 텍스트)
- **신규 파일** cards/mc_cards_zzflavor_goblin_ko.js — GG 팩 전 카드(~55장) 오리지널 한국어 플레이버. 기존 FLAVOR_KO 패턴(MC.CARDS[key].flavor 주입)
- 빌런(노먼/고블린 스테이지별 차등), 메인스킴, 환경(악명/광기), RB 조우, MF 하수인/부착/사이드/배신, 모듈러 4종 전부
- parseCardText가 한국어 flavor 우선 표시(영어 억제) → info 돋보기에 이탤릭 플레이버 노출. 전체 회귀 통과
- **[수정] 환경(environment):** 두 가지 버그 — (1)startGame이 startEnvironment 미전달 (2)UI가 G.environments 렌더링 자체를 안 함. 둘 다 수정. 앞으로 환경 셋업 있는 시나리오 전부 적용됨

## v2026.07.15.286 (환경 셋업 + 렌더링)
- **버그1**: ui/mc_ui.js startGame의 makeGameState 호출에 `startEnvironment: scen.startEnvironment` 누락 → 그린 고블린 Criminal Enterprise/State of Madness 환경이 실제 게임에서 셋업 안 됨. 추가
- **버그2**: UI에 G.environments 렌더링이 전혀 없었음 → 환경 카드+카운터 안 보임. 빌런/사이드스킴 아래에 환경 존(env-row) 추가. 카운터 있으면 크게 표시(악명/광기 라벨: criminal-enterprise→악명, state-of-madness→광기, 그 외→카운터)
- 범용 구현 — G.environments 배열의 모든 환경을 렌더(향후 환경 셋업 시나리오 자동 적용)
- 전체 회귀 통과
- **[완료] 그린 고블린 MVC02:** 카드/애니/대사 + 시나리오 UI 선택 가능 + 모듈러 4종. 다음: 나머지 영웅 신분 등

## v2026.07.15.285 (그린 고블린 UI 선택 등록)
- **문제**: MC.SCENARIOS에 riskyBusiness/mutagenFormula 등록했지만 UI 빌런 선택 목록(VILLAIN_ROSTER/VILLAIN_META)이 별도 하드코딩이라 화면에 안 뜸
- **수정**: ui/mc_ui.js VILLAIN_ROSTER에 riskyBusiness(art 02001b)·mutagenFormula(art 02014) ready:true 추가 + VILLAIN_META에 이름/부제(그린 고블린 — 위험한 거래/뮤타젠 포뮬러)
- 모듈러 선택 UI는 MC.MODULAR_SETS 동적 조회라 4종 자동 노출(수정 불필요)
- **[완료] 그린 고블린 MVC02 전체:** 시나리오 2(Risky Business/Mutagen Formula 완전 플레이) + 모듈러 4종(Goblin Gimmicks/A Mess of Things/Power Drain/Running Interference). 다음: 나머지 영웅 신분 배선 등

## v2026.07.15.284 (신분 부착 메커니즘 + 모듈러 완성)
- **신분 부착 메커니즘 신규**: attachment 라우팅에 attachTarget:'identity' → pl.identityAttachments 부착. `identityAttachHas(G,pl,flag)` 헬퍼
  - readyAllFor: identityCannotReady면 신분 준비 스킵 / flipForm: identityCannotFlip면 형태변경 차단(force 포함)
  - useCardAbility에 신분 부착 탐색 + payIcons(다중 타입) 코스트 지원. discardSelfAttachment이 신분 부착도 처리
- **02048 All Tied Up**: 신분 부착 + 준비/변신 금지 + 액션(🧠💪→버림)
- **02049 Media Coverage**: 신분 부착 + 공개하는 각 WR 1회 추가 발동(wrDoubling) + 알터에고 액션(🧠→버림). fireRevealWithInterrupt에 더블링(첫 발동이 pending 없을 때만, 재귀 가드). ※ pending 세우는 WR은 더블링 스킵(안전) — 경미한 한계
- **MODULAR_SETS 'running-interference' 등록** → 모듈러 4종 전부 등록 완료
- **회귀**: test_goblin_mutagen 94→101체크(cannotReady/cannotFlip·버림·WR 더블링 런타임). 전체 회귀 통과
- **[진행 중] Running Interference 모듈러:** Tombstone·Running Interference 완료. 남은 2장(복잡·신규 메커니즘): All Tied Up(신분 부착+준비/변신 금지), Media Coverage(신분 부착+WR 2회 발동). 이 2장 완료 후 MODULAR_SETS 'running-interference' 등록 예정

## v2026.07.15.283 (Running Interference 착수)
- **02047 Tombstone**(Criminal 하수인 HP9): 강제반응 공격+피해 후 mental/physical 자원 손패 버림. **엔진 신규**: resolveDefensePending에 공격자 자신의 `attackDamagedEffects` 훅(피해 시, 기존 부착물 attackDamagedResponse와 별개). `EFFECTS.discardResourceFromHand`(types). **공격 애니 tombstoneStrike(거대 주먹 강타+지면 균열+"으드득!")**
- **02046 Running Interference**(사이드): WR 각 플레이어 [🧠💪 지불 / 위협 2] 선택. eachPlayerChoice 재사용
- 대사: Tombstone(enter/attack/defeat 각5), Running Interference(reveal 5)
- **회귀**: test_goblin_mutagen 90→94체크. 전체 회귀 통과
- **[미완] 신분 부착 메커니즘 필요**: All Tied Up(attachToIdentity + cannotReady/cannotFlip), Media Coverage(attachToIdentity + WR 2회 인터셉트). 확실히 하려면 별도 신규 배선
- **[진행 중] 그린 고블린 모듈러 4종:** Goblin Gimmicks·A Mess of Things·Power Drain 완료. 남은: Running Interference(마지막)

## v2026.07.15.282 (Power Drain 모듈러)
- **MODULAR_SETS 'power-drain'**: power-drain(사이드), electro, electromagnetic-pulse, lightning-bolt, shock-therapy
- **boostDrain 인덱스**(공통 메커니즘 수렴): 조우 N장 버림 → 버린 부스트 아이콘 합계를 G._lastBoostDiscarded에 기록. 파생: damagePerBoostDiscarded(간접피해), healVillain amountFrom:boostDiscarded, discardResourceEachPlayerPerBoost, summonElectroIfDiscarded
- **02042 Electro**: 강제반응 공격 후 조우1버림+부스트당 간접 / 부스트★ 조우3버림 / **공격 애니 electroStrike(지그재그 번개+전기 스파크 "지지직!")**
- 02043 EM Pulse(조우7→Electro소환/surge), 02044 Lightning Bolt(조우2+간접), 02045 Shock Therapy(조우1/히어로+빌런회복), 02041 Power Drain(격퇴 시 조우2+자원버림)
- 대사: Electro(enter/attack/defeat 각5) + 배신3·사이드(reveal 5)
- **회귀**: test_goblin_mutagen 84→90체크(부스트집계·간접피해·빌런회복·Electro소환). 전체 회귀 통과
- **[작업 원칙]** 하수인 배선 시 대사 + 공격 애니메이션 같이. Scorpion 공격 애니 보강 완료. Power Drain(Electro)·Running Interference(Tombstone)도 공격 애니 포함 예정

## v2026.07.15.281 (Scorpion 공격 애니메이션)
- **VFX.scorpionStrike**: 꼬리 독침(🦂)이 대상 아래에서 솟구쳐 찌름 + 초록 독 튀김 + "독침!" + 기절 어지럼 별(💫). 테마: 스콜피온 독침·마비
- scorpion defineCardFx에 vfx.attack 매핑. mc_vfx 문법 OK, 전체 회귀 통과, 빌드 포함 확인
- (Goblin Gimmicks는 하수인 없음 — 부착/배신뿐이라 공격 애니 불필요. A Mess of Things는 이제 Scorpion 애니까지 완비)
- **[진행 중] 그린 고블린 모듈러 4종:** Goblin Gimmicks·A Mess of Things 완료. 남은: Power Drain, Running Interference

## v2026.07.15.280 (A Mess of Things 모듈러)
- **MODULAR_SETS 'a-mess-of-things'**: a-mess-of-things(사이드), scorpion, gang-up(표준 재사용), tail-sweep×2
- **02038 Scorpion**: Quickstrike(기존) + 공격 피해 시 대상 기절. `stunOnDamage` def 플래그 → resolveDefensePending에서 공격자 def 존중(모든 공격 경로 적용, 중앙화). KNOWN_META 추가
- **02037 A Mess of Things**: WR 기절한 아군 1명당 위협 +2. `stunnedFriendlyCount` + threatHere에 amountFrom:'stunnedFriendliesX2' 확장
- **02040 Tail Sweep**: WR Scorpion이 공격(전장에 있으면)/없으면 기절. 부스트★ 기절. `scorpionAttacksOrStun`
- 대사: Scorpion(enter/attack/defeat 각5), Tail Sweep·A Mess of Things(reveal 5)
- **회귀**: test_goblin_mutagen 78→84체크(Scorpion 기절·기절아군 위협·Tail Sweep 분기·모듈러). 전체 회귀 통과
- **[진행 중] 그린 고블린 모듈러 4종:** Goblin Gimmicks 완료. 남은: A Mess of Things, Power Drain, Running Interference

## v2026.07.15.279 (Goblin Gimmicks 모듈러)
- **신규 파일** `cards/mc_cards_zzgoblin_mod_fx.js` (모듈러 4종 fx)
- **MODULAR_SETS 'goblin-gimmicks' 등록**: Goblin Glider(02019)·Pumpkin Bombs(02021) 각2(시나리오 카드 재사용) + Intimidation(02035)·Regenerative Healing 각2
- **02036 Regenerative Healing**: WR 빌런 2×스테이지 회복(회복 0이면 surge) / 부스트★ 빌런 2 회복. `healVillain`에 stageX2 추가, `EFFECTS.surgeIfNoHeal`
- **02035 Intimidation**(slug 'intimidation'은 플레이어 이벤트 선점 → 코드 등록): WR [자원2 지불/빌런 저장부스트] 선택 / 부스트★ 빌런 저장부스트. `EFFECTS.giveVillainBoost`(G.villainStoredBoost) + villainExtraBoost가 다음 활성화에 소비. payIconsSatisfied에 total(아무 타입 합계) 추가
- 대사 각5. **회귀**: test_goblin_mutagen 69→78체크(2×스테이지 회복·surge·저장부스트·모듈러 조립). 전체 회귀 통과
- **[완료] 그린 고블린 MVC02:** Risky Business + Mutagen Formula 모두 완전 플레이 가능. 다음: 모듈러 4종(goblin-gimmicks 등) / 나머지 영웅 신분

## v2026.07.15.278 (Risky Business 완전 플레이)
- **룰북 검증**(mc02 rules insert p4): "스테이지가 처치되면 다음 스테이지는 처치된 것과 같은 면으로 등장(대개 고블린 면)" → nextStage 체인(02001b→02002b 등 고블린 면 유지)이 정확함 확인
- **staged 해제**: 완전 플레이 검증 통과 — 셋업(노먼 I + Criminal Enterprise 악명2/히어로) → 악명 소진 플립(고블린 I + State of Madness) → 고블린 3스테이지 순차 처치(같은 면 진행) → 승리. 패배 경로(메인스킴 02004b→02005b)도 기존 검증
- **회귀**: test_goblin_flip 50→56체크(RB 풀 셋업·플립·스테이지 진행·승리). 전체 회귀 통과
- **상태**: 그린 고블린 = 카드 40장(RB19+MF21) + 애니메이션(등장/공격/전환/패배/변신/하수인) + 대사 + 2 시나리오 완전 플레이 가능
- **[완료] 그린 고블린 Mutagen Formula:** 카드 21장 + 시나리오 엔트리 등록 = 플레이 가능. 다음: Risky Business staged 해제 검토 / 모듈러 4종 / 나머지 영웅

## v2026.07.15.277 (Mutagen 시나리오 등록)
- **MC.SCENARIOS.mutagenFormula 등록**: villainStart 02014, mainScheme 02017b, 전용 조우 세트(공식 quantity — glider/hysteria/pumpkin 부착3, soldier×4/thrall×6/knight/monster, reinforcements×2/nation/overrun×2, death-from-above×2/i-see-you/overconfidence/wicked-ambitions×2), standard 세트, defaultModular goblin-gimmicks(미등록 시 스킵)
- 키 주의: goblin-glider='02019', pumpkin-bombs='02021'(코드 키), hysteria=슬러그
- **검증**: buildEncounter 33장 전부 정의 · 셋업(빌런 02014 HP16, 메인 02017b 위협2/7, Goblin Thrall 배치) · 스테이지 진행(02014→02015). staged 아님(완전 플레이 가능)
- **회귀**: test_goblin_mutagen 64→69체크(시나리오 등록·조우덱·셋업). 전체 회귀 통과
- **미세 편차(백로그)**: 셋업 mutagenSetup이 Thrall을 새로 spawn → 조우덱 6 thrall과 별개(공식은 6장 중 배치). 경미
- **[완료] 그린 고블린 Mutagen Formula:** 빌런3·메인4·하수인4·부착3·사이드3·배신4 = 전체 카드 effects 배선 완료. 다음: Mutagen SCENARIOS 엔트리 등록(playable 연결) / 모듈러 4종

## v2026.07.15.276 (Wicked Ambitions — Mutagen 전체 완료)
- **02032 Wicked Ambitions**: WR 조우덱 X장 버림(X=2×빌런 스테이지). 버린 각 고블린마다 공개 플레이어가 [피해3 / 그 고블린 교전 배치] 선택 — 순차 연쇄
- **선택 연쇄 배선**: HANDLERS.wickedAmbitions(고블린 uid 큐 수집) + MC.flushWickedGoblin(다음 고블린 선택 pending) + EFFECTS.wickedSummonCurrent(_wickedCurrentGob 버림더미→교전 배치). resolveRevealChoice에 연쇄 훅 추가(기존 flushThreatChoice/flushEachChoice 패턴)
- 대사 5(reveal, 사악한 야심). 
- **회귀**: test_goblin_mutagen 58→64체크(X=4 버림·고블린2·배치/피해 선택 연쇄). 전체 회귀 통과
- **★ Mutagen Formula 21장 전체 배선 완료** (Risky Business 19장에 이어)
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 — 02031 Overconfidence 완료. 남은: 02032 Wicked Ambitions(마지막)

## v2026.07.15.275 (Overconfidence)
- **02031 Overconfidence**: WR(알터에고) GG 암약, 위협 3+ 배치 시 이 카드 surge / WR(히어로) GG 공격, 피해 3+ 시 surge
- **조건부 surge 두 경로**(예전 타이밍 불확실 → 해결):
  - 알터에고: `EFFECTS.surgeIfThreat`(G._lastThreatPlaced ≥ 임계 → ctx.self.surge=true, 즉시 판정)
  - 히어로: villainAttacks가 `pending.surgeIfDamageGTE` 설정 → 방어 해소부에서 dmgDone ≥ 임계면 dealEncounterTo(surge). 피해가 방어 해소 후 결정되는 타이밍 문제를 pending 필드로 해결
- 대사 5(reveal, 고블린의 오만한 도발). KNOWN_META 불필요(효과 파라미터)
- **회귀**: test_goblin_mutagen 54→58체크(알터에고 2<3 무surge·4≥3 surge·히어로 피해3≥3 surge). 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 — 02030 I See You 완료. 남은: 02031 Overconfidence, 02032 Wicked Ambitions

## v2026.07.15.274 (I See You)
- **02030 I See You**: WR GG가 당신을 공격(부스트 부여, 알터에고 폼이면 부스트 생략) / 부스트★ 고블린 하수인 교전 시 이 카드 부스트 +1
- **부스트 값 중앙 집계 `MC.boostOf(G, card, pl)`**: 기본 boost + 조건부(boostBonusIfGoblinEngaged). 부스트 read 5곳(스킴 본체/추가·공격 본체/로그/추가) 전부 boostOf로 수렴
- **villainAttacks에 withBoost/noBoostIfAlterEgo 추가**: 공격에 부스트 카드 1장 부여, 알터에고 폼이면 생략(pending.boostCard가 방어 해소부에서 처리)
- **대사 5**(reveal, 어둠 속 스토킹의 섬뜩한 조롱). KNOWN_META에 boostBonusIfGoblinEngaged 추가
- **회귀**: test_goblin_mutagen 49→54체크(히어로 부스트부여·알터에고 생략·조건부 boostOf 1/2). 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 — 02028 Overrun 완료. 남은: 02030 I See You, 02031 Overconfidence, 02032 Wicked Ambitions

## v2026.07.15.273 (Overrun)
- **02028 Overrun**(사이드스킴): 격퇴 시(whenCompleted — onSideSchemeCleared가 발화) 각 플레이어 조우 2장 버리고 그렇게 버린 "각" 고블린 하수인 교전 배치
- **EFFECTS.overrunDiscardSummon**(각 고블린 배치 — mutagenDiscardSummon의 "첫 고블린"과 달리 전부). 대사 5(reveal, 고블린 군단 물량 위압)
- **회귀**: test_goblin_mutagen 46→49체크(조우2 소환·격퇴 발화). 전체 회귀 통과
- **[진행 중] 그린 고블린:** 빌런 애니(등장/공격/전환/패배/폼전환) + 하수인 공격 애니 완료. 그린 고블린 애니메이션 세트 완성. 다음: Mutagen 남은 카드(Overrun/I See You/Overconfidence/Wicked Ambitions) 효과+대사

## v2026.07.15.272 (고블린 하수인 공격 애니메이션)
- **하수인 공격 VFX 4종**(테마별, fxMinionAttack 힌트 → mdef.vfx.attack로 재생. 대사는 기존 attack 5종 재사용):
  - goblinSoldierStrike(호박폭탄 투척 "펑!"), goblinThrallStrike(마지못한 초록 채찍 "…미안…" 비극적), goblinKnightStrike(초록 에너지 창 "꿰뚫기!"), monsterStrike(야수 3연 발톱 "그르릉!")
- **vfx.attack 매핑**: goblin-soldier/thrall/knight/monster defineCardFx에 추가
- 헬퍼 _minionStrikePts(from/to 없으면 대사만) 재사용. mc_vfx 문법 OK, 전체 회귀 통과, 빌드 포함 확인
- **[진행 중] 그린 고블린:** 빌런 전용 애니메이션 — 등장/공격/전환/패배 + 폼전환 변신 완료. 남은: 하수인 공격 애니메이션

## v2026.07.15.271 (폼전환 변신 연출)
- **★시그니처 goblinTransform VFX**(노먼↔고블린):
  - toGoblin: 노먼의 냉철한 가면이 세로로 찢어지며 틈에서 초록 광기+호박폭탄 분출, 글라이더가 튀어나오고 "GOBLIN!"+광기의 웃음. 격렬한 진동+색 변질(→초록)
  - toNorman: 광기가 안으로 수렴(초록 링 역방향), 임상 스캔라인으로 가면 재형성, "노먼 오스본"
- **fx 힌트 패턴 배선**: goblinFlip이 `G.fxGoblinFlip{fromCode,toCode,dir,quote,seq}` 설정(기존 playVillainEntrance 직접호출 대체) → mc_ui가 seq 변화 감지해 goblinTransform 재생(다른 fxXxx 힌트와 동일 패턴). 새 면 등장 대사도 힌트에 실어 변신 후 말풍선
- **회귀**: test_goblin_flip 48→50체크(toGoblin/toNorman 힌트·seq 갱신). goblinTransform+fxGoblinFlip 빌드 포함 확인. 전체 회귀 통과
- **[진행 중] 그린 고블린:** 빌런 전용 애니메이션 우선 작업. 등장/공격/전환/패배 완료. 남은 애니: 폼전환 변신 연출(노먼↔고블린, 스테이지 전환 아님 → 전용 UI 훅 필요)

## v2026.07.15.270 (그린 고블린/노먼 전용 VFX)
- **ui/mc_vfx.js에 전용 VFX 7종 + 헬퍼 2개**:
  - 고블린(초록빛+호박폭탄+글라이더+광기): goblinEntrance(글라이더 횡단+호박폭탄+HAHAHA), goblinAttack(호박폭탄 투척→대상 폭발), goblinStageUp(광기 폭주 초록 링), goblinDefeat(글라이더 추락 회전낙하)
  - 노먼(차가운 오스코프 녹색): normanEntrance(임상 스캔라인), normanStageUp(악명 부식), normanDefeat(가면 균열 — 고블린 전조)
  - 헬퍼: pumpkinBlast(호박폭탄 폭발), goblinSparks(초록/보라/주황 파티클)
- **seed vfx 매핑**: 노먼 3(02001a/02002a/02003a: entrance/stageChange/defeat, 공격은 리다이렉트라 없음) + 고블린 6(02001b/02002b/02003b/02014/02015/02016: entrance/enemyAttack/stageChange/defeat)
- UI 디스패치(mc_ui.js)가 def.vfx로 자동 재생(등장 playVillainEntrance·전환 264·패배 538·공격 2711). mc_vfx 문법 OK, 전체 회귀 통과
- **남은 애니**: 노먼↔고블린 폼전환 변신 연출(goblinFlip은 스테이지 전환이 아니라 별도 UI 훅 필요), 하수인 공격 애니메이션
- **[진행 중] 그린 고블린 Mutagen Formula:** 하수인 4종 대사 추가(그동안 기계적 효과에 집중하며 누락했던 대사 보강). 다음: 02028 Overrun (효과+대사 함께)
- **[작업 원칙 재확인]** 카드 배선 시 효과+대사+VFX를 같이 완성한다. Mutagen 하수인 대사 보강 완료. 남은 대사 갭: Mutagen 배신/사이드스킴/부착 보조 대사, 빌런 전용 애니메이션(green-goblin/norman 등장·전환·패배·공격)

## v2026.07.15.269 (고블린 하수인 대사 세트)
- **ui/mc_vfx.js QUOTES에 Mutagen 하수인 4종 추가**(enter/attack/defeat 각 5, 슬러그별 = UI가 defCode로 조회):
  - goblin-soldier(신난 부하), goblin-thrall(뮤타젠에 조종당하는 비극적 시민), goblin-knight(오만한 기사), monster(이성 잃은 야수)
  - 각 캐릭터 성향 반영한 오리지널 한국어 창작 대사
- 빌런 green-goblin은 Risky Business 풀세트(등장10/전환10/패배10/승리5/스킴5) 재사용
- 빌드 HTML에 대사 포함 확인(원칙10 — Node vm/문자열 검증). mc_vfx 문법 OK, 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 — 02027 Goblin Nation 완료. 다음: 02028 Overrun, 02030 I See You, 02031 Overconfidence, 02032 Wicked Ambitions

## v2026.07.15.268 (Goblin Nation)
- **02027 Goblin Nation**(db): 패시브 각 고블린 적 +1 ATK(사본 수만큼) / 부스트★ 사이드 스킴으로 전장 배치
- **적 ATK 패시브 중앙 집계**(메모리 원칙): 기존 `enemyAtk(enemy)` → `enemyAtk(G, enemy)` 시그니처 변경 + `MC.enemyAtkPassive(G, enemy)` 훅 추가. Goblin Nation이 전장에 있으면 goblin trait 적 +1/장. 호출부 6곳(enemyActivation·minionsAttack·villainAttacks·titania 등) 전부 갱신
- **resolveBoostStar에 side_scheme 전장 배치** 추가(boostStarPutIntoPlay가 minion 외 side_scheme도 지원): 위협 셋업 후 G.sideSchemes 등록
- **회귀**: test_goblin_mutagen 41→46체크(패시브 없음 0·부스트★ 배치·빌런/하수인 +1·2장 +2). titania/genetic 테스트 시그니처 갱신. 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 — 02022 Goblin Knight 완료. 하수인 4종 전부 완료. 다음: 02027 Goblin Nation(패시브 ATK), 02028 Overrun, 02030~32 배신

## v2026.07.15.267 (Goblin Knight)
- **02022 Goblin Knight**(db, HP7 보정): 강제반응 공격 후 조우 1장 버림→고블린 하수인이면 교전 배치 / 부스트★ 활성화 후 조우덱 셔플백
- **엔진 신규**: resolveBoostStar에 `boostStarShuffleBack`(버리지 않고 조우덱 셔플 후 true 반환). `EFFECTS.discardEncounterSummonGoblin`(조우 1장→고블린이면 배치). 강제반응은 기존 minion forcedResponseEffects 재사용
- **test_index KNOWN_META에 boostStarShuffleBack 추가**
- **회귀**: test_goblin_mutagen 37→41체크(HP7·강제반응 소환·비고블린 버림·부스트★ 셔플백). 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 — 02021 Pumpkin Bombs 완료. 부착물 3종(Glider/Hysteria/Pumpkin) 전부 완료. 다음: 02022 Goblin Knight(부스트★ 셔플백)
- **[출력]** 고정 파일명 `marvel_champions.html` (버전 스탬프는 내부 유지)

## v2026.07.15.266 (Pumpkin Bombs — 빌런 공격후 강제반응)
- **02021 Pumpkin Bombs**(seed): 빌런 부착 / 빌런이 공격한 후(피해 무관) → 버림 + 간접 2 / 히어로 액션(💪💪 → 버림)
- **엔진 신규 훅 `attackResponseEffects`**(빌런 부착물): resolveDefensePending에서 빌런 공격 해소 후 피해 여부 무관하게 발화(기존 attackDamagedResponse는 피해 시만). attachments 복사본 순회(버림 안전). baseFields 등록
- **회귀**: test_goblin_mutagen 33→37체크(피해 0이어도 공격후 발동·버림·간접2). 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 — 02020 Hysteria 완료. 다음: 02021 Pumpkin Bombs(부착: 공격 후 강제반응)
- **[출력 규칙 변경]** 아티팩트 누적 방지 — 버전별 파일 대신 고정 파일명 `marvel_champions.html`로 덮어쓰기(내부 버전 스탬프는 유지)

## v2026.07.15.265 (Hysteria — 추가 부스트 중앙 집계)
- **02020 Hysteria**(db 스텁 → defineCardFx 배선): GG 부착 / 스킴·공격 시 부스트 카드 +1 / 히어로 액션(🧠🧠 → 버림)
- **`MC.villainExtraBoost(G, kind)` 중앙 집계**: villainAttackExtraBoost(클로, 공격 전용) + 부착물 grantsExtraBoost(Hysteria, 공격+스킴). enemyActivation 공격 분기가 이 집계 사용
- **스킴 분기 확장**: 추가 부스트 카드 공개·아이콘 합산·부스트★·버림 처리 신규 (기존엔 스킴에 추가 부스트 개념 없었음)
- **grantsExtraBoost baseFields 추가**. 히어로 액션은 activatedAbility(payCost) 재사용
- **회귀**: test_goblin_mutagen 29→33체크(부착 전/후 추가부스트·버림 원복). 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** mcode 순 진행 — 02019 Goblin Glider 완료. 다음: 02020 Hysteria(부착: GG 스킴/공격 +1 부스트)

## v2026.07.15.264 (Goblin Glider 부착물)
- **02019 Goblin Glider**(seed 등록): 최고 인쇄HP 적에 부착(ATK+1) / 부착 불가 시 surge / 히어로 액션(⚡⚡ → 버림)
- **엔진 확장**:
  - 부착 라우팅에 `attachTarget:'highestHpEnemy'` — 빌런+하수인 중 최고 maxHp(동일 부착물 없는) 대상, 없으면 inst.surge=true 후 버림(revealPendingEncounters가 surge 처리)
  - `EFFECTS.discardSelfAttachment` — 히어로 액션용 자기 detach+버림(attachStats 원복 포함)
  - `attachStats` baseFields 추가
  - 히어로 액션은 기존 `activatedAbility`(payCost 자원 지불, 빌런 부착물 탐색 지원) 재사용
- **회귀**: test_goblin_mutagen 25→29체크(최고HP 부착·ATK+1·히어로액션 버림·ATK원복). 전체 회귀 통과
- **보류(확실 검증 후)**: Hysteria/Pumpkin(부착 강제반응·인터럽트) · Goblin Nation(패시브 ATK) · Overrun(discard-summon) · Goblin Knight(부스트★ 셔플백) · I See You/Overconfidence/Wicked Ambitions
- **[진행 중] 그린 고블린 Mutagen Formula:** 빌런3 + 하수인3 + Monster + Death from Above + Goblin Reinforcements + 메인스킴 4면 완료. mcode 순 진행 중. 남은: 부착3·사이드스킴2·배신4·Goblin Knight (새 메커니즘, 확실 검증 후 한 장씩)

## v2026.07.15.263 (Mutagen 메인스킴 4면)
- **seed 등록**: 02017a/b Unleashing the Mutagen, 02018a/b Mutagen Cloud (정확 위협값)
- **02017a 셋업**(02017b onSetup `mutagenSetup`): 각 플레이어와 교전 상태로 Goblin Thrall 배치. 게임 1B 시작
- **02017b 완료**(`mutagenDiscardSummon`): 고블린 미교전 플레이어가 조우덱 3장 버리고 첫 고블린 하수인 전장 배치
- **02018a**: WR 2B 진행(advanceMainSchemeNow 재사용) / **02018b**: nextStage 없음 → 완료 시 자동 패배
- **02018b 동적 가속**: `accelFrom:'goblinEnemies'` — 빌런 페이즈 위협 계산에 전장 고블린 적 수(빌런+하수인) 추가. 엔진 가속 계산부에 훅
- **신규 헬퍼**: `goblinPutMinion`(하수인 교전 배치), `goblinEnemyCount`(고블린 적 수)
- **회귀**: test_goblin_mutagen 20→25체크(셋업 배치·완료 진행·동적 가속·자동 패배). 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** 빌런3 + 하수인3 + Monster + Death from Above + Goblin Reinforcements 완료. 남은 카드는 새 메커니즘/애매함으로 **한 장씩 확실한 것만** 진행 중

## v2026.07.15.262 (Goblin Reinforcements — 고블린 수 스케일링)
- **`MC.goblinMinionCount(G)`**: 전장의 goblin trait 하수인 수 (Soldier/Thrall/Knight/Monster 4종 전부 goblin trait 검증). 고블린 수 비례 카드 공용
- **`EFFECTS.threatHere`에 `amountFrom:'goblinMinions'` 확장** (Risky Business의 threatHere 재사용)
- **02026 Goblin Reinforcements**: WR 고블린 하수인 1마리당 이 스킴 위협 +1
- **회귀**: test_goblin_mutagen 17→20체크(카운트 3, 위협+3, 0마리 +0). 전체 회귀 통과
- **보류(확실치 않아 미착수)**: Overconfidence(공격 후 피해량 판정 타이밍) · I See You(폼별 부스트 유무) · Wicked Ambitions(플레이어 선택 UI) · Goblin Knight(부스트★ 셔플백) · Goblin Nation(패시브 ATK 집계) · 부착 3종(Pumpkin/Hysteria/Glider — 부착 강제반응·히어로액션 버림) · Overrun(discard-summon). 각각 새 메커니즘 필요 — 확실히 검증 후 한 장씩
- **[진행 중] 그린 고블린 Mutagen Formula:** 빌런 3 + 하수인 3 + Monster + Death from Above 완료. 다음: Overconfidence/I See You(폼조건부, 조건 surge/boost) / 부착 3 / 사이드스킴 3 / 메인스킴 / discard-summon

## v2026.07.15.261 (플레이어 폼조건부 WR + Death from Above)
- **신규 인덱스 `whenRevealedByPlayerForm:{hero:[...],'alter-ego':[...]}`** + `HANDLERS.goblinPlayerFormReveal`: 룰북 "When Revealed (Hero)/(Alter-Ego)" 패턴을 플레이어 폼으로 분기 (Risky Business 빌런폼 게이트 whenRevealedByForm의 플레이어 버전). baseFields 등록
- **villainAttacks/villainSchemes에 `bonusFrom:'villainStage'` 추가** (범용) — 빌런 스테이지 수만큼 ATK/SCH 증가
- **02029 Death from Above**: 알터에고→GG 암약 +스테이지 SCH / 히어로→GG 공격 +스테이지 ATK
- **회귀**: test_goblin_mutagen 15→17체크(알터에고 암약 SCH2+3, 히어로 공격 ATK3+3). 전체 회귀 통과
- **다음(정확도 순)**: Overconfidence(02031, 폼조건부 + 조건 surge) / I See You(02030) / 부착 Pumpkin Bombs·Hysteria·Goblin Glider / 사이드스킴 / 메인스킴 4면 + 고블린수 스케일링
- **[진행 중] 그린 고블린 Mutagen Formula:** 빌런 3스테이지 + 고블린 소환 하수인 + Monster 완료. 다음: 플레이어 폼조건부 WR / 고블린수 스케일링 / 부착·사이드스킴 / discard-summon

## v2026.07.15.260 (Mutagen Formula — Monster + 빌런 3스테이지)
- **뮤타젠 그린 고블린 3스테이지**(seed 02014/02015/02016, 단면·폼전환 없음): 정확 스탯 + 강제반응(공격 후 피해 시 메인 위협 배치) + WR(02015/16 각 플레이어 조우 카드 배분)
- **인덱스 재사용/추가**:
  - 강제반응 위협 = 기존 `pending.threatOnDamage` 재사용 + 빌런 def `attackThreatOnDamage` 필드 → enemyActivation이 공격 pending에 전달 (baseFields 등록)
  - `EFFECTS.dealEncounterEachPlayer`(dealEncounterTo 루프) — 각 플레이어 조우 N장
  - 빌런 스테이지 전환 시 whenRevealed 발화(advanceVillainStage 기존)로 02015/16 WR 자동 연결
- **02025 Monster**: WR 기절 / 이미 기절 시 피해 2 — `applyStatus` + 조건피해(cond `targetStatus` self stunned) 인덱스 재사용, 순서로 "이미 기절?" 판정
- **회귀**: test_goblin_mutagen 7→15체크(Monster 기절/조건피해·빌런 스탯·강제반응 위협·조우배분). 전체 회귀 통과
- **[진행 중] 그린 고블린 Mutagen Formula:** 정확도 확실한 것부터 순차 배선 시작. 고블린 소환 하수인 완료. 다음: Monster WR / 빌런 3스테이지 / 플레이어 폼조건부 WR

## v2026.07.15.259 (Mutagen Formula — 고블린 소환 하수인)
- **신규 파일** `cards/mc_cards_zzgoblin_mf_fx.js` (Mutagen Formula fx). 단면 그린 고블린(폼전환 없음) + 고블린 군단 시나리오
- **02023 Goblin Soldier**: 부스트★ 교전 전장배치(boostStarPutIntoPlay) + 처치 시 교전 플레이어 피해 1(whenDefeatedEffects dealDamage engagedPlayer). 인덱스 100% 재사용
- **02024 Goblin Thrall**: Guard(기존) + 부스트★ 교전 전장배치
- **엔진 인덱스 추가**: resolveTarget에 `engagedPlayer`(하수인과 교전 중인 플레이어) — 범용
- **회귀**: 신규 `test_goblin_mutagen.js` 7체크(부스트★ 전장배치·처치 피해·Guard). 전체 회귀 통과
- **다음(정확도 순)**: Monster(02025 WR 기절/피해) → 빌런 3스테이지(02014-16, 공격후 위협+조우배분) → 플레이어 폼조건부 WR(02029/30/31) → 고블린수 스케일링(02026/18b) → discard-summon(02017b/28/32)
- **[완료] 그린 고블린 Risky Business:** 빌런 6스테이지·환경 2·메인스킴 4·하수인 2·사이드스킴 3·배신 2 = **19장 effects 전부 배선.** 폼전환 엔진 + 공유 악명/광기 + 폼조건부 WR 전부 인덱스식. `GG_RISKY_PROGRESS.md` 참조. 다음: 빌런 전용 애니메이션 / Mutagen Formula / 모듈러 4종

## v2026.07.15.258 (Risky Business effects 전종 완료)
- **메인 스킴 진행 체인**: 02004b(1B) 완료 → whenCompleted(악명 1/히어로 배치 + 악명 수만큼 각 플레이어 덱버림) → 02005a(2A) whenRevealed(advanceMainSchemeNow) → 02005b(2B). 02005b는 nextStage 없음 → onMainSchemeThreshold가 자동 패배(setGameOver loss·schemeComplete, 노먼 승리 대사 노출)
- **폼 조건부 WR 인덱스** `whenRevealedByForm:{norman:[...],goblin:[...]}` + `HANDLERS.goblinFormReveal`: 02010 오스코프(노먼→이 스킴 +1/히어로 위협), 02013 광기의 천재(고블린→최소HP 히어로 공격, 대상없으면 surge / 노먼→악명당 덱버림)
- **추가 인덱스**: advanceMainSchemeNow, threatHere(인스턴스 직접 가산), villainAttacksFewestHp, goblinDiscardPerInfamy(scope), goblinCounter perHero 확장, goblinVillainForm/goblinInfamyCount 유틸
- **02007 Hired Gun**: 부스트★ 악명+1 + WR 악명+2 (부스트 부여 대안은 카운터 분기로 통일)
- **회귀**: test_goblin_flip 42→48체크(메인스킴 완료·2A→2B 진행·2B 자동패배·폼조건부 WR 노먼/고블린·최소HP 공격). 전체 회귀 통과. 빌드 HTML 대사 검증(원칙10)
- **[진행 중] 그린 고블린 MVC02:** Risky Business — 빌런 6스테이지 + 공유 메커니즘 카드 완료. `GG_RISKY_PROGRESS.md` 참조. 다음: 폼조건부 WR(02010 노먼 위협/02013 이중 WR) + 02007 WR 선택 + 메인스킴 완료효과(02004b/02005b)

## v2026.07.15.257 (공유 악명/광기 메커니즘 인덱스화)
- **공유 EFFECT `goblinCounter`** — "악명 배치 / 불가 시 광기 제거"를 인덱스 하나로 수렴. `MC.goblinInfamyOrMadness(G,n)`: 노먼 면(Criminal Enterprise 활성) → 악명+N, 고블린 면(State of Madness 활성) → 광기-N. "배치 불가" = Criminal Enterprise 미전장(고블린 면) 정확 구현
- **부스트★ 배선**(boostStarEffects, 인덱스식): 02007 hired-gun · 02008 private-security-specialist(Guard 기존) · 02009 collapsing-bridge · 02011 payoff → 악명+1
- **02012 All in a Day\'s Work** 완료: WR 악명+2 / 부스트★ 악명+1
- **완료**: 02008/02009/02011/02012. **부분**: 02007(부스트★ ✅, WR 선택 대기)
- **회귀**: test_goblin_flip 35→42체크(노먼/고블린 면별 goblinCounter 분기·부스트★ 데이터). 전체 회귀 통과
- **[진행 중] 그린 고블린 MVC02:** Risky Business — **빌런 6스테이지(노먼·고블린 양면) 전부 effects 완료.** `GG_RISKY_PROGRESS.md` 참조. 다음: 메인스킴 완료효과(02004b/02005b) + 하수인·사이드스킴·배신(공유 악명 메커니즘)

## v2026.07.15.256 (그린 고블린 b면 3스테이지)
- **schemeToCounter 데이터 배선**(defineCardFx): 02001b{1}·02002b{1}·02003b{2}. 엔진 훅(enemyActivation 알터에고 분기)은 v255에서 준비 완료 → 데이터만 얹음
- **When Revealed(플립 시 발화)**: goblinFlip이 새 면 whenRevealed 발화(룰북 준수). 인덱스 재사용 — `damageEachHero`에 `heroForm`(히어로 폼 한정) + `indirect` 파라미터 확장. 02001b:간접3 히어로폼 / 02002b:간접3 / 02003b:피해4
- **goblinFlip 개선**: WR 발화 시 빌런 인스턴스를 self로 전달 → runCardEffects가 defCode로 def·whenRevealedEffects 해소 (VFX source 정확)
- **회귀**: test_goblin_flip 27→35체크(스킴→광기·플립 WR 히어로폼 간접3·역플립). 전체 회귀 통과
- **[진행 중] 그린 고블린 MVC02:** Risky Business — 노먼 오스본 a면 3스테이지 완료. `GG_RISKY_PROGRESS.md` 참조. **다음: 02001b 그린 고블린(스킴→광기 + WR 간접피해)**

## v2026.07.15.255 (그린 고블린 — 노먼 오스본 메커니즘)
- **인덱스식 3필드 엔진 배선** (baseFields 등록 + 중앙 처리):
  - `attackToCounter:{amount}` — 빌런 공격 시 공격 대신 악명 카운터 +N. `enemyActivation` 히어로폼 분기 초입에서 처리(방어 pending·부스트·공격 트리거 전부 미발생, 룰북 준수)
  - `schemeToCounter:{amount}` — 빌런 스킴 시 스킴 대신 광기 카운터 -N. `enemyActivation` 알터에고 분기(고블린용, 다음 단계에서 데이터 부착)
  - `damageToCounter:true` — 빌런 피해 시 피해 대신 악명 카운터 제거(본체 무피해). `applyDamage` 상단 무적/면역 인덱스와 동일 패턴
- **노먼 3스테이지 데이터** (defineCardFx, amount만 다름): 02001a{1}·02002a{2}·02003a{3} + damageToCounter:true. seed todoFx 해제
- **동작**: 노먼 공격→악명 증가(플립에서 멀어짐), 피해→악명 감소(플립에 가까워짐, 0시 고블린으로 플립). HP 무손상 = "노먼은 직접 못 이김, 악명 소진시켜 고블린으로 끌어내 잡는다" 정확 구현
- **회귀**: test_goblin_flip 18→27체크(노먼 데이터·피해→악명·본체 무피해·악명0 플립·공격 add 경로). 전체 회귀 통과
- **[진행 중] 그린 고블린 MVC02:** Risky Business — 폼전환 코어 인프라 완성(02006a Criminal Enterprise / 02006b State of Madness). 카드별 진행은 `GG_RISKY_PROGRESS.md` 트래커 참조. **다음: 02001a부터 빌런/카드 개별 배선(코어 프리미티브 호출)**

## v2026.07.15.254 (그린 고블린 폼전환 엔진 코어)
- **신규 파일** `cards/mc_cards_zzgoblin_fx.js` — Risky Business 폼전환 인프라:
  - `MC.goblinActiveEnv(G)` — 활성 플립 환경(악명/광기) 탐색
  - `MC.goblinAddCounter(G,n)` / `MC.goblinRemoveCounter(G,n)` — 카운터 조작, 0 도달 시 자동 플립 (초과 제거 0 클램프)
  - `MC.goblinFlip(G)` — **코어**: 빌런 `defCode` 반대면 교체(인스턴스 유지 = HP·피해·부착·부스트·상태 전부 보존, 룰북 준수) + 활성 환경 반대면 교체 + 새 면 카운터 리셋 + 새 빌런 면 whenRevealed 발화
  - `MC.HANDLERS.goblinRiskyBusinessSetup` — 셋업 시 Criminal Enterprise 배치(악명 2×히어로), 메인스킴 02004b `onSetup`로 발화
  - 환경 메타데이터는 GG 모듈 로컬 상수 `GOBLIN_ENV`(인덱스식, baseFields 오염 없음)
- **02006a/b 환경 완료**: db todoFx 해제. 환경 behavior(카운터 0시 플립)는 `goblinRemoveCounter`가 처리
- **진행 트래커 신설** `GG_RISKY_PROGRESS.md` — 카드별 데이터/effects 상태 매 카드 갱신 (가시성)
- **회귀**: `test_goblin_flip.js` 18체크(셋업 배치·add/remove·정플립·역플립·HP 보존·인스턴스 유지·클램프). 전체 회귀 통과
- **다음 단계(개별 배선, mcode 순)**: 02001a 노먼(공격→악명+1, 피해→악명-N) → 02001b 고블린(WR 히어로 간접3, 스킴→광기-1) → ... 각 카드는 코어 프리미티브 호출만 얹으면 됨. 빌런 전용 애니메이션 순차 제작
- **[진행 중] 그린 고블린 MVC02:** Risky Business 데이터 등록 완료(빌런 6스테이지 양면 + 메인스킴 4면 + SCENARIOS). **폼전환 엔진 메커니즘(카운터 플립)은 다음 증분.** 상세는 아래 v253 항목

## v2026.07.15.253 (그린 고블린 Risky Business — 데이터 레이어)
- **룰북**: `ansqudwmns01-collab/mav` mc02_green_goblin_rules_insert.pdf 확보(8p) — Risky Business/Mutagen Formula 2시나리오 + 모듈러 4종. 카드 스탯/자원은 zzorba `gob_encounter.json`(57장)로 확정(원칙6)
- **핵심 메커니즘(신규 엔진 필요)**: 노먼 오스본(a면)↔그린 고블린(b면) 양면 폼전환 빌런. Criminal Enterprise(악명 카운터)/State of Madness(광기 카운터) 환경이 0되면 플립. 노먼 공격→악명+N(실공격 안함)/피해→악명 제거, 고블린 스킴→광기-N(실스킴 안함). 면별 When Revealed
- **이번 패스(데이터 레이어)**:
  - **빌런 6스테이지** seed 등록(02001a/b·02002a/b·02003a/b): 정확한 공식 HP/ATK/SCH + `form/altForm/pairedEnv/noAttack/noScheme` 폼전환 필드 + `nextStage`(면 유지 진행) + quoteKey + textKo. baseFields에 폼전환 필드 5종 등록
  - **메인스킴 4면**(02004a/b 적대적 인수, 02005a/b 기업 인수합병) seed 등록: baseThreat/maxThreatPerPlayer/accelIcons 공식값
  - **양 폼 대사 세트**(mc_vfx QUOTES): `norman-osborn`(냉혹한 사업가·오만·계산적) + `green-goblin`(광기·괴소·파괴) 각 entrance10/stageUp10/defeat10/heroDefeat5/schemeComplete5. 웹검색 캐릭터 성향 반영
  - **SCENARIOS.riskyBusiness**: villainStart 02001a + mainScheme 02004b + startEnvironment + 전용 조우 18장(공식 quantity) + 표준 세트. `staged:true`(폼전환 엔진 대기)
  - 조우 카드(환경2·하수인2·사이드스킴3·배신2)는 1177 인덱스 마이그레이션분이 db에 이미 존재(todoFx 스텁) — 재사용
- **명시적 다음 증분(엔진)**: ① 양면 폼전환 빌런 시스템(a/b 플립, 부착/피해/부스트 유지) ② infamy/madness 카운터 환경 + 0시 자동 플립 ③ 노먼 공격→카운터 리다이렉트 / 고블린 스킴→카운터 리다이렉트 / 노먼 피해→카운터 리다이렉트 ④ 면별 When Revealed(고블린 간접피해) ⑤ 조우 카드 스텁 effects 배선(악명/광기 공유 메커니즘) ⑥ 빌런 전용 애니메이션(등장/전환/패배/공격 × 노먼·고블린) ⑦ Mutagen Formula 시나리오 + 모듈러 4종
- **회귀**: test_index 폼전환 필드 가드 통과, 전체 회귀 통과. 빌드 HTML vm 검증(대사·빌런·시나리오 포함)
- **총 카드:** 11장 (시드 — 스윙 웹 킥만 effects 등록, 나머지 데이터만)
- **마지막 작업:** 캡아 팩 감사 → 미배선 effects 2종 발견·완결. 03033 Expert Defense(방어 DEF+3=preventAmount 3 재사용, 전용 aegis VFX), 03034 Enhanced Awareness(멘탈 카운터 자원생성=web-shooter 인덱스 재사용). 프리셋 hawkeye-cap(01066 reprint 중복슬러그·미배선)→코어 hawkeye 정정. 미등록 6종(03016/18/20/21/22/23)은 전부 reprint(duplicate_of)로 원본 슬러그 커버 확인. **캡아 팩 진짜 전종 완결(신규카드 effects 포함)**
- **다음 예정:**
  1. 사용자 실기기 테스트 피드백 반영
  2. 나머지 25영웅 신분 능력 배선 (audit_identities 순차)
  3. RtcTransport (WebRTC 스타형·수동 시그널링) + 4인 각자-화면 연결 흐름
  4. Phase 2: 인덱스 JSON 1,177장 마이그레이션 (dedupe + 자원 아이콘 58장 검증)
- **알려진 중복 카드 정리 백로그:** hawkeye-cap(03012=01066 reprint), 01120 armored guard, 01143 advanced drone, 01182 hydra soldier — 해당 시나리오/정리 시 통합

## v2026.07.15.252 (캡아 팩 잔여 effects 완결)
- **감사 결과**: 캡아 팩(cap.json) 신규카드 대조 → db 등록은 전종이나 **03033 Expert Defense·03034 Enhanced Awareness가 todoFx 스텁**(effects 미배선)이었음. 미등록 6종(03016→01071/03018→01072/03020→01083/03021→01088/03022→01089/03023→01090)은 전부 duplicate_of=reprint라 원본 슬러그로 커버(신규 작업 0)
- **03033 Expert Defense** (방어 이벤트, Protection, 비용0·🧠1): DEF +3. **[체크1] 인덱스 재사용** — DEF+3 = `preventAmount amount:3`(Cosmic Flight 3방지와 동일 등가, 라이더 없어 정확 일치). defense 트레잇 → 방어 pending 중 플레이(엔진 isDefenseInterrupt 게이트). 전용 VFX `expertDefense`(청록 육각 aegis 방어막 + "+3 DEF", 범용 색)
- **03034 Enhanced Awareness** (업그레이드, 비용2·🧠1): 멘탈 카운터 3, 소진+카운터1 제거→멘탈 자원1. **[체크1] 인덱스 재사용** — web-shooter의 `uses:3`+`resourceGenerator{form:hero,exhaust,counter:1,icons}` 그대로, 아이콘만 mental. 신규코드 0줄. VFX=detectiveInstall(지각/통찰 테마 재사용)
- **hawkeye-cap 정정**: 03012는 공식상 01066(코어 호크아이) reprint인데 db에 별도 슬러그로 있고 fx 미배선 → v251 프리셋이 이 미배선 슬러그를 참조하던 버그 수정. 프리셋을 배선된 코어 `hawkeye`로 교체. hawkeye-cap은 중복 정리 백로그 등재
- **회귀**: test_cap_cards_reverify 127→133체크(Expert Defense 방어 pending prevented 3 + 무변이 안전성, Enhanced Awareness resourceGenerator 검증). 전체 회귀 통과

## v2026.07.15.251 (캡틴 아메리카 — 6번째 플레이 가능 영웅)
- **PRESET_DECK 조립** (mc_cards_scenarios.js): `captain-america` 리더십 프리셋 40장 = 시그니처 15(Agent 13·두려움없는 결의×2·영웅적 일격×3·방패 막기×2·방패 던지기×2·스티브의 아파트·헬멧·방패·슈퍼솔저 혈청×2) + 리더십 13(팔콘·원더맨·호크아이·스쿼럴걸·요청하기×2·준비 태세×2·어벤져스 어셈블!·수적 우위·앞에서 이끌다·리더십의 힘×2) + 어벤져스 타워 1 + 기본코어 11
- **넴시스 세트** (NEMESIS_SETS.captainAmerica): minion=baron-zemo, sideScheme=hit-squad, rest=[hydra-soldier×2, hail-hydra×1] — 03026 Man Out of Time(의무)는 셋업 시 조우덱 셔플되므로 세트에서 제외(기존 규칙)
- **NEMESIS_BY_HERO**: 03001a/03001b → captainAmerica (앞/뒷면 둘 다 매핑, 기존 5영웅과 동일 패턴)
- **회귀**: test_preset_decks 5→6종(캡아 EXPECT: heroic-strike×3/fearless-determination×2/shield-block×2/super-soldier-serum×2/make-the-call×2/power-of-leadership×2/agent-13/cap-shield/falcon-ally 검증) + keys.length 5→6. 캡아 셋업 정상(스티브 로저스 오프닝 7장, 덱 33장). 회귀 전체 통과
- **핵심 학습/규칙:**
  - 결정=액션 (pending 머신) — RNG는 액션 내부에서만, 상태엔 라이브 참조 금지(uid만)
  - 정의 전용 필드(nextStage/hpPerPlayer/stage/maxThreatPerPlayer)는 cardDef로 조회
  - 액션은 검증 먼저·변이 나중 (실패 시 무변이·로그 미기록)
  - authoritative: zzorba core.json/core_encounter.json
- **환경 메모:** 이전 빌드는 ansqudwmns01-collab/mav 에서 curl 재입수 가능

## v2026.07.13.250 (03029 통합확인 + 03030 헤일 하이드라 — 캡아 팩 전종 완료)
- **03029 Hydra Soldier**: slug=hydra-soldier가 클로 모듈러(mcode 01182)로 이미 완전 배선됨(Guard + 처치 시 조우카드 dealEncounterToEngaged + 테마 VFX/대사). **동일 slug라 03029(캡아 넴시스)가 자동 커버** — 신규 작업 0. 검증: Guard 빌런공격 차단("유효하지 않은 대상") + 처치 시 조우카드 지급. (copies 3 vs 2 차이는 인카운터 세트 구성 레벨, 카드 def 무관)
- **03030 Hail Hydra!** (slug=hail-hydra): 배신/넴시스
  - 공개 시: 히어로 교전 중인 각 Hydra 하수인이 공격 / 공격 안 받은 각 플레이어는 조우덱+버림에서 Hydra 하수인 탐색→교전 배치(셔플)
  - **[체크2] minionsAttack 인덱스 확장**: reinforceUnattacked 옵션 추가. attackedPlayers Set 추적 → 공격 안 받은 각 플레이어에 searchMinionIntoPlay(per-player, 기존 전역 fallback과 별개). 공격 전 배치해도 새 하수인은 pairs 미포함(공식 순서와 결과 동일)
  - 대사: reveal 5종(하이드라 광신·증원 톤)
  - 검증: Hydra 교전 중→공격(방어 pending) / Hydra 없음→증원 배치(아무 Hydra 하수인)
- test_cap_cards 124→127체크. 회귀 94종/카드1262(미등록0)/VFX525 무결
- **★캡아 팩 카드 전종 배선 완료** (03001~03034 + 넴시스 03026~03030). **다음: 캡아 PRESET_DECK 조립 → 6번째 플레이가능 영웅**
  - 필요: 캡아 시그니처(03002 Agent13 등)+리더십 어스팩트 카드로 프리빌트 덱 구성. HERO_META/PRESET_DECKS에 captain-america 추가. villain roster는 무관(영웅 추가)
  - 캡아 넴시스 세트(captain_america_nemesis: hit-squad/baron-zemo/hydra-soldier×2/hail-hydra) buildEncounter 등록 필요(캡아가 히어로일 때 조우덱에 셔플)

## v2026.07.13.249 (03028 바론 제모 — 넴시스 하수인)
- **03028 Baron Zemo** (slug=baron-zemo): 하수인/넴시스, Hydra·Elite, ATK3/SCH1/HP5, 부스트▲2
  - Quickstrike(등장 즉시 공격) + 교전 중인 동안 그 플레이어 저지(thwart) 불가
  - **[체크2] quickstrike(기존 키워드) + whileEngagedCannotThwart(신규 패시브)**:
    - hasCannotThwartEngaged(G,pl) 헬퍼(mc_6_keywords): whileEngagedCannotThwart 필드 하수인 교전 판정. 순찰(Patrol=메인만)과 달리 모든 스킴 저지 차단
    - basicThwart에 체크 추가(mc_7_core, 스킴 무관). baseFields에 whileEngagedCannotThwart 등록
  - 대사: enter/attack/defeat 각 5종(귀족적 오만·하이드라 광신 톤). ★하수인은 quoteKey 없이 defCode를 대사 키로 사용(quoteKey 넣으면 빌런 검증 10개 규칙에 걸림 — 주의)
  - 검증: quickstrike 데이터 / 교전 중 메인·사이드 스킴 저지 차단 / 처치(hp0) 후 저지 가능
- test_cap_cards 118→124체크. 회귀 94종/카드1262(미등록0)/VFX524 무결
- **다음(넴시스 세트 마무리)**: 03029 hydra-soldier(하수인, Guard+처치 시 조우카드, **01182와 slug 중복→통합**), 03030 hail-hydra(배신, Hydra 하수인 공격+탐색). 그 후 캡아 팩 전부 배선 → PRESET_DECK 조립

## v2026.07.13.248 (03027 히트 스쿼드 — 넴시스 사이드 스킴)
- **03027 Hit Squad** (slug=hit-squad): 사이드 스킴/넴시스, 시작위협 3/인, 가속 ▲1
  - 공개 시: 플레이어 순서로 각자 조우덱 top 1장 버림 → 버린 카드 부스트 아이콘당 1피해
  - **[체크2] 신규 인덱스 eachPlayerDiscardEncounterBoostDamage** (mc_2_effects): playersInOrder 순회, drawEncounterCard(pop=top, 리셔플·가속 처리) 재사용, def.boost만큼 applyDamage. 부스트 0이면 무피해
  - 검증: under-attack(boost3)→3피해 / weapons-runner(boost1)→1피해 / boost0→무피해 / 조우덱 top 버림+버린더미
  - VFX: reveal 대사 5종(하이드라 암살조 톤). entrance=revealCard
- test_cap_cards 112→118체크. 회귀 94종/카드1262(미등록0)/VFX519 무결
- **다음(넴시스 세트)**: 03028 baron-zemo(하수인, quickstrike+교전 시 저지불가), 03029 hydra-soldier(하수인, Guard+처치 시 조우카드, **01182와 slug 중복→통합**), 03030 hail-hydra(배신, Hydra 하수인 공격+탐색). 캡아 팩 전부 배선 후 → PRESET_DECK 조립

## v2026.07.13.247 (카운터 배지 표시 + 전부 랜덤)
- **카운터 배지(counterBadge) 헬퍼 신설**: 카운터 확인용 ◉N 배지를 조건부 표시
  - 대상: counters 보유 중 OR counterAbility(에너지 채널 — 충전 전에도 ◉0) OR uses(웹 슈터) OR entersWithCounters(호크아이 화살) OR counterGainPerPhase(퀸젯 시간)
  - 적용: 동료(2171)·서포트/업글(2205) 렌더 모두. 기존 업글만 c.counters!==undefined일 때 ⚡N 뜨던 것 → 통일. 일반 카드엔 미표시
  - 검증: energy-channel 충전전◉0/충전후◉3, quinjet◉0, hawkeye◉4, web-shooter uses3, inspired(없음)
- **전부 랜덤**: STEP2 헤더에 "🎲 전부 랜덤" 버튼(UI.randomizeAll) — 빌런(준비된 것 중 무작위) + 모듈(modularMode=random 재추첨) 동시. 다시 누르면 전부 재추첨
- 회귀 94종 무결
- **다음(넴시스 세트 mcode순)**: 03027 hit-squad, 03028 baron-zemo, 03029 hydra-soldier(01182 중복통합), 03030 hail-hydra. 캡아 팩 전부 배선 후 → PRESET_DECK 조립

## v2026.07.13.246 (랜덤 빌런 선택 추가)
- **빌런 랜덤 선택**: STEP2 빌런 그리드 앞에 "🎲 랜덤 빌런" 타일 추가
  - UI.pickRandomVillain(): 준비된 빌런(VILLAIN_ROSTER ready:true 3종) 중 무작위 선택 → scenarioKey 미리보기 확정. 다시 누르면 재추첨
  - APP.villainRandom 플래그: 랜덤 타일 하이라이트 + 하단 VS 표시 "🎲 랜덤 — <빌런명>". pickVillain(개별 선택) 시 해제
  - 모듈 랜덤(modularMode:random + randomModularKeys)은 기존 기능 유지 — 랜덤 빌런 선택 시 modularRandomKeys 리셋으로 새 빌런 기준 재추첨
- 검증: 준비 빌런 3종(rhino/klaw/ultron) 전부 시나리오+기본모듈로 정상 개시. randomModularKeys 동작 확인
- 회귀 94종 무결
- **다음(넴시스 세트 mcode순)**: 03027 hit-squad, 03028 baron-zemo, 03029 hydra-soldier(01182 중복통합), 03030 hail-hydra. 캡아 팩 전부 배선 후 → PRESET_DECK 조립

## v2026.07.13.245 (UX 수정 5종 — 사용자 피드백)
- **① 신분 액션 폼별 독립**: 캡틴마블 알터에고 액션(Commander)과 히어로 액션(Rechannel)이 폼별로 독립 사용 가능함을 확인(usedIdentityActionThisRound[pl.form] 폼별 추적 — 엔진·UI 모두 정상). 이전 빌드가 공유 플래그였을 가능성 → 리빌드로 해결. test_identity_boost_ux.js로 회귀화
- **② 공개 모달 대사 버블(.rvx-quote) 가시성**: 흰색 text-shadow 제거(글자 번짐 원인) + 솔리드 흑색(#000) + Noto Sans KR 폰트 명시 + 배경 대비 강화(#fbf3dd)
- **③ 개발/구현 노트 노출 방지**: parseCardText가 ※에서 break하여 이미 제외하지만, 견고화 — window./_currentBoostCard/applyMinion/encounterDiscard/putIntoPlay/함수의/공식:/원본: 등 구현 키워드 라인 필터 추가 (※ 없이 새어나와도 차단)
- **④ 첫 라운드 종료 드로우 확인**: endPlayerPhase(라운드1)에서 핸드 크기까지 정상 드로우(3→6) 검증 완료
- **⑤ 부스트★ 하수인 중복 모달 억제**: 부스트★로 배치된 하수인이 revealLog에 부스트 항목+하수인 항목 둘 다 들어가 별도 공개 모달이 부스트 오버레이보다 먼저/중복으로 뜨던 문제 → 하수인 항목에 fromBoostStar 표시 + act 훅에서 해당 항목 모달 큐 제외. 부스트 공개 오버레이가 "★ 전장에 교전 상태로 등장!"으로 순서대로 안내
- 회귀 93→94종(test_identity_boost_ux 추가). 카드1262/VFX518 무결
- **다음(넴시스 세트 mcode순)**: 03027 hit-squad(사이드스킴), 03028 baron-zemo(하수인), 03029 hydra-soldier(하수인, 01182 중복통합), 03030 hail-hydra(배신). 캡아 팩 전부 배선 후 → PRESET_DECK 조립

## v2026.07.13.245 (플레이 피드백 수정 5종)
- **①폼별 신분 액션 독립**: `usedIdentityActionThisRound` boolean → **폼별 객체**({hero, alter-ego}). 알터에고 클릭능력 사용해도 히어로 클릭능력 별도 사용 가능(각 폼 라운드 1회). 캡틴마블 Commander(알터에고)/Rechannel(히어로) 독립. mc_4_players 초기화·mc_5_encounter 리셋·mc_7_core useIdentityAction 체크/세팅·mc_ui 버튼 판정 모두 [pl.form] 키
- **②조우 공개 모달 대사(rvx-quote) 가시성**: 폰트 14→15.5px, weight 700→800, 색 #1a1408→#0f0a02, letter-spacing/text-shadow 추가 (대비 강화)
- **③모달 구현노트 제거**: parseCardText가 `※`로 시작하는 줄만 걸러 하위 항목(들여쓰기 `- `)은 노출됨 → **첫 ※ 이후 전부 스킵**(break). ※ 주석은 항상 텍스트 끝이므로 안전. weapons-runner의 window._currentBoostCard/applyBoostStarEffect 등 코드 참조 완전 제거
- **④첫 라운드 턴종료 드로우**: 확인 결과 정상(endPlayerPhase가 손패 크기까지 드로우, 3→6). 문제 없음
- **⑤부스트★ 공개 순서**: `pumpRevealQueue`가 `revealShowing`만 체크 → ★효과가 만든 하수인 공개가 부스트 공개 모달보다 먼저 뜸. **boostRevealShowing/fxRevealShowing도 존중**하도록 수정 + boostRevealDone/fxRevealDone에서 pumpRevealQueue() 호출(확인 후 순서대로 재개)
- 테스트: test_captain_america_identity/test_identity_reverify 폼별 구조로 정정 + 폼별 독립 추적 검증 추가
- 회귀 93종/카드1262(미등록0)/VFX518 무결
- **다음(넴시스 세트 mcode순)**: 03027 hit-squad(사이드스킴), 03028 baron-zemo(하수인), 03029 hydra-soldier(01182 중복통합), 03030 hail-hydra(배신). **캡아 팩 전부 배선 후 → 캡아 PRESET_DECK 조립**

## v2026.07.13.244 (03026 시대에 뒤처진 사나이 — 의무, 폼전환+택1)
- **03026 Man Out of Time** (slug=man-out-of-time): 의무(Obligation)/넴시스, 부스트▲2
  - 공개 시: 알터에고 전환 가능(선택) → 택1: ⓐ스티브 로저스 소진→게임 제거(신분 준비 시만) / ⓑ손패 절반(내림) 선택 버림→의무 순환
  - **[체크2] 인덱스 확장 4종** (business-problems offerChoice 템플릿 재사용 + 확장):
    - **flipToAlterEgo** (mc_2_effects): 알터에고 폼 강제전환(라운드 1회 무시), 이미 알터에고면 no-op
    - **discardChooseFromHand** (mc_2_effects, 선택식): count 또는 countHalf(floor). discardChoose pending + afterEffects 캐리(버림 완료 후 실행). ACTIONS.resolveDiscardChoose + UI 렌더
    - **offerChoice availableIf** 옵션 필터: 옵션별 조건(condCheck) 미충족 시 숨김. condCheck 'identityReady'(신분 !exhausted) 추가
    - **2단계 offerChoice 체이닝**: 옵션 effects가 다시 offerChoice → 폼전환 선택 후 택1. resolveRevealChoice가 새 pending 살려두는 특성 활용
    - **findByUid 견고화**: 조우 영역(revealing/encounterDeck/encounterDiscard/pendingEncounters)까지 스캔 → 의무/배신 공개 처리 중 self 참조 안정. resolveObligation mode:game이 encounterDiscard에서도 제거(중복 방지), mode:discard 중복 push 방지
  - VFX: manOutOfTimeResolve(얼음 결정 파문)/manOutOfTimeDefer(카드 잔상 낙하) + quote(duty/defer 각5) 신규. entrance=revealCard
  - 검증: 폼전환X→소진 제거 / 폼전환O→손패 절반(3장) 선택 버림→순환 / 신분 소진 시 exhaust 옵션 숨김
- test_cap_cards 103→112체크. 회귀 93종/카드1262(미등록0)/VFX518 무결
- **다음(넴시스 세트 mcode순)**: 03027 hit-squad(사이드스킴, 공개 시 각 플레이어 조우덱 상단 버림+부스트당 피해), 03028 baron-zemo(하수인, quickstrike+교전 시 저지불가), 03029 hydra-soldier(하수인, Guard+처치 시 조우카드, **01182와 slug 중복→통합**), 03030 hail-hydra(배신, Hydra 하수인 공격+탐색). **캡아 팩 전부 배선 후 → 캡아 PRESET_DECK 조립**

## v2026.07.13.243 (03025 명예 어벤져 — 캐릭터 HP+1 & Avenger 특성 부여)
- **03025 Honorary Avenger** (slug=honorary-avenger): 업그레이드/Basic, 비용0, 💪물리, Title
  - 조건: 신분이 Avenger일 때만(playCondition hasTrait). 캐릭터당 최대 1장. 우호 캐릭터(히어로/동료) 부착 → HP+1 + Avenger 특성 부여
  - **[체크2] 인덱스 확장 3종**:
    - **allyHasTrait(G,ally,trait)** (mc_6_keywords, 신규 중앙 집계): 동료 인쇄 트레잇 + 부착물 grantsTrait. 인플레이 동료 트레잇 판정 지점 3곳(readyCharactersByTrait/buffCharactersByTrait/allyLimitCondAllTrait) 직접 cardDef.traits 조회 → allyHasTrait로 교체. 손패 동료(deployAllyFromHand)·플레이할 카드(nextCardDiscountFilter)는 부착물 없어 cardDef 유지
    - **attachTo/detachFrom hpBonus** (mc_5_encounter): hpBonus 부착물이 HP 인스턴스(동료/하수인, type+maxHp)에 부착 시 maxHp+hp 동시 증가, detach 시 원복(hp 클램프). appliedHpBonus 기록. 히어로는 기존 recomputeMaxHp
    - **attachCharacter 선택 picker** (mc_7_core): attachTarget:'character' → 히어로/동료 후보 pending. resolveAttachCharacter(target:'hero'|allyUid): 히어로=attachTo+recompute / 동료=upgrades에서 빼서 attachTo(hpBonus+트레잇). maxPerTarget 검사. UI 렌더+UI.resolveAttachCharacter
  - grantsTrait는 히어로(playerHasTrait)·동료(allyHasTrait) 양쪽 집계에서 읽힘 → 부착 대상 무관 Avenger 부여
  - 검증: 히어로 HP+1+Avenger / 동료 HP+1+Avenger 획득 / detach 원복 / 어벤져스 타워 조건부 한도(명예 어벤져 부착 동료 Avenger 카운트→한도4)
- test_cap_cards 93→103체크. 회귀 93종/카드1262(미등록0)/VFX517 무결
- **다음(한 장씩)**: 03026 man-out-of-time(의무, 폼전환+택1), 03027 hit-squad(사이드스킴,넴시스), 03028 baron-zemo(하수인,넴시스,quickstrike+저지불가), 03029 hydra-soldier(하수인, **01182와 slug 중복 통합**), 03030 hail-hydra(배신,넴시스). **캡아 팩 전부 배선 후 → 캡아 PRESET_DECK 조립(6번째 플레이가능영웅)**

## v2026.07.13.242 (03024 어벤져스 타워 — 조건부 동료 한도 + 필터 비용 할인)
- **03024 Avengers Tower** (slug=avengers-tower): 서포트/Basic, 비용2, 🧠멘탈, Avenger·Location
  - 지속: 모든 동료가 Avenger면 → 동료 한도 +1. 행동: 소진 → 이번 페이즈 다음 Avenger 동료 비용 -1
  - **[체크2] 인덱스 확장 2종**:
    - **allyLimitOf 조건부화**: `allyLimitBonus`(양) + `allyLimitCondAllTrait`(특성). 지정 시 pl의 모든 동료가 그 특성일 때만 보너스(동료 0명=공허참 적용). 무조건 보너스(triskelion)와 공존
    - **reduceNextPlayCost** (mc_2_effects, 헬리캐리어 special 일반화): `amount`+`allyTrait?`. `pl.nextCardDiscount` + `pl.nextCardDiscountFilter{type,trait}` 세팅. playCard가 필터 매치 시만 적용, 미매치면 미소모(다음 매칭 카드까지 유지)
  - **★핫패스 버그 수정**: nextCardDiscount 소모가 `discount>0`(리빙레전드 포함)이면 싸잡아 clear하던 문제 → nextDisc(필터 통과분) 별도 추적 → 그 몫이 실제 적용됐을 때만 clear. 리빙레전드(-1) + 타워(-1) 중첩 시 첫 Avenger 동료 -2 정상
  - 소모/페이즈 종료 시 nextCardDiscountFilter도 정리
  - test_index: allyLimitCondAllTrait 등록. baseFields는 cardDef에서 읽어 불필요
  - 검증: 조건부 한도(0명→4/전부Avenger→4/비Avenger섞임→3) / 필터 할인(비Avenger 유지→Avenger 적용) / 리빙레전드+타워 -2 중첩
- test_cap_cards 85→93체크. 회귀 93종/카드1262(미등록0)/VFX516 무결
- **다음(한 장씩)**: 03025 honorary-avenger(업글, Avenger특성+HP+1 부여, attachTarget:character), 03026 man-out-of-time(의무, 폼전환+택1), 03027~03030 넴시스세트 mcode순. **캡아 팩 전부 배선 후 → 캡아 PRESET_DECK 조립(6번째 플레이가능영웅)**

## v2026.07.13.241 (03019 퀸젯 — 시간 카운터 + Avenger 동료 무료 전개)
- **03019 Quinjet** (slug=quinjet): 서포트/리더십, 비용1, ⚡에너지, Avenger·Vehicle
  - 반응: 턴 시작 후 → 시간 카운터 1개 적립. 행동: 손에서 Avenger 동료(인쇄비용≤카운터) 전장 무료 배치 → 퀸젯 버림
  - **[체크2] 신규 인덱스 2종**:
    - **gainCounterOnPhase** (mc_3_handlers): 페이즈 훅에서 자신에게 카운터 적립. 데이터 counterGainPerPhase(기본1). playerPhaseStart 훅 필드가 이 핸들러명 가리키면 fireHook이 전장 카드마다 발화. 범용(미래 "턴 시작 카운터 적립" 카드 재사용)
    - **deployAllyFromHand** (mc_2_effects, 선택식): trait/costFromCounters/discardSelfAfter 데이터. 손에서 조건(특성+인쇄비용≤cap) 맞는 동료 후보로 deployAlly pending. 배치 가능 동료 없으면 throw(행동 불발, 소스 소비 방지)
    - **ACTIONS.resolveDeployAlly** (mc_7_core): 선택 동료 손→전장 무료 배치(동료 한도 검사) → discardSource면 소스 버림 → whenPlayed 훅으로 등장 반응 발화(팔콘 peek 등)
    - UI: deployAlly pending 렌더(손패 동료 카드+비용 표시, 탭→배치) + UI.resolveDeployAlly
  - baseFields: playerPhaseStart 기존 등록됨(makeInstance가 인스턴스 복사) / counterGainPerPhase는 cardDef에서 읽어 baseField 불필요, 단 test_index 허용 필드에 추가
  - 검증: 카운터 적립(3턴→3)/후보 필터(cost≤카운터 Avenger만, 팔콘cost4·마리아힐 non-Avenger 제외)/무료 배치+퀸젯 버림/카운터 부족 시 불발
- test_cap_cards 77→85체크. 회귀 93종/카드1262(미등록0)/VFX515 무결
- **다음(한 장씩)**: 03024 avengers-tower(조건부 동료한도+1, Avenger동료 비용-1 행동), 03025 honorary-avenger(업글, Avenger특성+HP+1 부여), 03026 man-out-of-time(의무), 03027~03030 넴시스세트(hit-squad/baron-zemo/hydra-soldier[01182 중복통합]/hail-hydra) mcode순. **캡아 팩 전부 배선 후 → 캡아 PRESET_DECK 조립**

## v2026.07.13.240 (준비 타이밍 버그 수정 — endRound 이중 준비 제거)
- **버그**: 준비(ready)/드로우가 endPlayerPhase(플레이어 페이즈 종료, 정답)에 더해 **endRound(빌런 페이즈 후)에서도 이중으로** 일어남
  - 결과: 빌런 페이즈에 방어로 소진한 히어로/동료가 다음 라운드에 즉시 준비돼버림 → **방어의 대가가 사라지는 오류**
- **공식 RRG 확정(웹 검색)**: "각 플레이어가 턴을 마친 후, 손패 크기까지 뽑고 카드를 준비한다. 그 후 빌런 페이즈로 넘어간다." → 준비/드로우는 **플레이어 페이즈 종료 시 딱 1회**, 라운드 종료(빌런 페이즈 후)에는 준비 **안 함**
- **수정**: mc_5_encounter.js endRound에서 `pl.exhausted=false` + 동료/서포트/업글 준비 루프 **제거** (라운드당 1회 능력 플래그 리셋은 유지)
  - 이제 빌런 페이즈에 방어(mc_5_encounter:763 히어로/:771 동료)로 소진한 카드는 **다음 플레이어 페이즈 내내 소진 유지**, endPlayerPhase에서 비로소 준비
- **테스트**: test_phase1 방어자 검증을 RRG 정답으로 정정(라운드 넘어가도 소진 유지) + **신규 test_ready_timing.js**(5체크): endPlayerPhase 준비 / 빌런 페이즈 방어 소진→라운드 넘어가도 유지 / 다음 endPlayerPhase에서 비로소 준비
- 회귀 92→93종. 카드1262/VFX513 무결
- **다음(한 장씩)**: 03019 quinjet(서포트, 시간카운터+Avenger동료 배치), 03024 avengers-tower, 03026 man-out-of-time(의무), 03027~03030 넴시스세트 등 리더십 mcode순

## v2026.07.13.239 (03017 수적 우위 — 동료 다중선택 소진→드로우)
- **03017 Strength In Numbers** (slug=strength-in-numbers): 이벤트/리더십, 비용0, 💪물리1
  - 행동: 원하는 수만큼 동료 소진 → 소진한 동료 1명당 카드 1장 드로우
  - **[체크2] 신규 인덱스 exhaustAlliesForDraw + allyExhaustDraw pending(임의 다중선택 — 선택 기능 보존)**:
    - EFFECTS.exhaustAlliesForDraw: 준비된 동료 후보로 pending 세움(없으면 no-op)
    - ACTIONS.resolveAllyExhaustDraw: mode toggle(선택/해제) / confirm(소진+드로우). 0명 확정 가능(드로우0)
    - UI: 동료 카드 토글 렌더(cardPick 방식) + 확정 버튼(N명 소진, N장 드로우) + UI.toggleAllyExhaustDraw/confirmAllyExhaustDraw
  - 검증: 3동료 중 2명 선택→소진+2드로우/0명 확정→드로우0/준비 동료 없음→no-op
- test_cap_cards 70→77체크. 회귀 92종/카드1262/VFX513 무결
- **다음(한 장씩)**: 03019 quinjet(서포트, 시간카운터+Avenger동료 배치), 03024 avengers-tower, 03026 man-out-of-time(의무), 03027~03030 넴시스세트 등 리더십 mcode순

## v2026.07.13.238 (03015 어벤져스 어셈블 — 트레잇 준비/버프 인덱스)
- **03015 Avengers Assemble!** (slug=avengers-assemble): 이벤트/리더십, 비용4, ⚡에너지, 라운드1회
  - 히어로 행동: 내가 조종하는 각 Avenger 캐릭터 준비 + 이 페이즈 끝까지 전장의 각 Avenger(전 플레이어) THW/ATK+1
  - **[체크2] 신규 인덱스 3개 (카드는 데이터만)**:
    - readyCharactersByTrait{trait,scope} — 히어로(playerHasTrait)+동료(traits) 준비. 히어로 소진 필드=pl.exhausted
    - buffCharactersByTrait{trait,stats} — 전장 트레잇 캐릭터 tempStatBonus 가산(statOf/allyStatOf가 읽음, 페이즈종료 소멸)
    - maxPerRound(이벤트 라운드제한) — playCard 사전검증+event분기 기록(pl.eventsUsedThisRound), endRound 리셋
  - 검증: 히어로/Avenger동료 준비/비-Avenger 제외/THW·ATK+1/maxPerRound 2회차 차단+라운드리셋 재사용
- playCard 핫패스(maxPerRound) — 회귀 92종 전수. test_index에 maxPerRound 등록. test_cap_cards 62→70체크
- **다음(한 장씩)**: 03017 strength-in-numbers(동료 소진수만큼 드로우), 03019 quinjet(시간카운터+Avenger동료 배치), 03024 avengers-tower 등 리더십 mcode순

## v2026.07.13.237 (03014 원더맨 — 공격 추가비용 선택 인덱스)
- **03014 Wonder Man** (slug=wonder-man): 동료/리더십, 비용2, 💪물리1, Avenger, ATK3/THW1/HP3
  - ★ 공격하려면 추가 비용으로 손패 1장 버림 (저지/방어엔 없음)
  - **[체크2] 신규 인덱스 attackExtraCost{discardFromHand:N}**:
    - allyAttack 코어를 performAllyAttack(G,pl,ally,target)로 분리(재사용)
    - allyAttack이 attackExtraCost 감지 → 손패<N이면 공격 불가(에러), 아니면 handDiscardCost pending 세우고 공격 지연
    - **어느 카드 버릴지 플레이어 선택**(선택 기능 구현 원칙): resolveHandDiscardCost가 손패 카드 버림 → count 채우면 performAllyAttack 실행
    - UI: handDiscardCost pending 렌더(손패 카드 클릭→버림, cardPick 방식 모방) + UI.resolveHandDiscardCost + 동료공격 VFX 지연 시 조기재생 방지
  - 검증: 공격→버림선택 pending(즉시공격 아님)/지불후 ATK3 공격+소진/손패0 공격불가/저지엔 추가비용 없음
- allyAttack 핫패스 리팩터 — 회귀 92종 전수 확인. test_index에 attackExtraCost 등록. test_cap_cards 57→62체크
- **다음(한 장씩)**: 03015 avengers-assemble(라운드1회, Avenger 준비+전체 Avenger THW/ATK+1), 03017 strength-in-numbers(동료 소진→드로우), 03019 quinjet 등 리더십 mcode순

## v2026.07.13.236 (03013 스쿼럴 걸 — AoE 인덱스 재사용)
- **03013 Squirrel Girl** (slug=squirrel-girl): 동료/리더십, 비용2, 🧠멘탈, Avenger, ATK1/THW1/HP2
  - 반응: 등장 후 각 적(빌런+모든 하수인)에게 1 피해
  - **[체크1] 기존 dealDamage/allEnemies 인덱스(ground-stomp 동일) 재사용 — 신규 코드 0줄, whenPlayedEffects 데이터만**. 인덱스 원칙 성공 사례
  - 검증: 빌런+하수인2체 각 1피해
- test_cap_cards 55→57체크. 회귀 92종/카드1262/VFX513 무결
- **다음(한 장씩)**: 03014 wonder-man(동료, 공격 추가비용 손1장 버림), 03015 avengers-assemble, 03017 strength-in-numbers 등 리더십 mcode순

## v2026.07.13.235 (★호크아이 하수인 등장 반응 — 선택 기능 구현)
- **★사용자 지시: 선택 기능이 있는 카드는 자동발동 생략 금지, 전부 구현**
- **v234의 호크아이 자동발동 → 플레이어 선택(발동/넘김)으로 교체**:
  - **minionEnteredPlay**: 자동 피해 → 반응 후보를 G._pendingMinionReactions에 큐잉만 (allyUid/minionUid/amount/counter/vfx)
  - **flushMinionReactions(G)** 신설(mc_6_keywords): flushThreatChoice/flushEachChoice 동일 패턴. 다음 유효 반응 1건을 revealChoice(fire/skip) pending으로. 하수인 처치·카운터 소진 시 스킵
  - **EFFECTS.minionReactionDamage** 신설(mc_2_effects): fire 선택 시 카운터 1 소진+하수인 피해+vfx
  - **flush 지점 3곳**: (1) dispatch 액션 후(플레이어 페이즈+step모드 villainStep) (2) processVillainQueue 루프 execStep 후(하수인 활성화 전) (3) resolveRevealChoice 체인(다중 하수인/다중 호크아이 순차 선택)
  - revealChoice 재사용 → UI(mc_ui.js:1903) 자동 렌더, 인카운터 정지/재개 그대로 활용
  - 검증: 큐잉(자동발동 아님)/발동→2피해+화살소진/넘김→보존/화살0→후보없음/다중 하수인 체인/**e2e 빌런 페이즈 공개→선택 pending 자동 발생**
- 타이밍: 하수인이 활성화하기 전에 선택 물음(룰 안전). test_cap_cards 51→55체크. 회귀 92종/카드1262/VFX513 무결
- **다음(한 장씩)**: 03013 squirrel-girl(반응: 각 적 1피해 AoE)

## v2026.07.13.234 (★중복카드 통합 메커니즘 + 03012 호크아이)
- **★사용자 지시: 중복 카드는 불러오는 키를 하나로 통합**
  - **defineCardFx(code, fields)**: code가 배열이면 여러 slug에 동일 fx 적용 → 리프린트 단일 정의(재사용). 예: `defineCardFx(['hawkeye','hawkeye-cap'], {...})`
  - **aliasCardFx(aliasCode, sourceCode)** 신설: 이미 정의된 원본의 fx/능력 필드를 별칭으로 복사(다른 파일 리프린트용). 고유 식별 필드(code/name/mcode/image/cost/stats/traits 등 FX_ALIAS_SKIP)는 보존
  - test_dedup_fx.js 7체크 신설. 앞으로 중복 카드는 이 두 방식으로 통합
- **03012 Hawkeye** (01066 Core = 03012 캡아, 동일 카드 → 통합 정의): 동료/리더십, 비용3, 🧠멘탈, Avenger, ATK1/THW1/HP3
  - 화살 카운터 4개 등장 + 반응: 하수인 등장 후 화살 1 소진→그 하수인 2피해
  - **[체크2] 신규 인덱스 2개**: (1) entersWithCounters(makeInstance에서 등장 카운터 설정, uses와 달리 소진-버림 없음) (2) onMinionEnterDamage{counter,amount} — 신규 중앙 헬퍼 minionEnteredPlay가 처리
  - **하수인 등장 6곳 중앙화**: 흩어진 G.minionJustEntered 할당(mc_2_effects:417, mc_5_encounter:45/301/332/413/934) → 전부 MC.minionEnteredPlay(G,minion,pl) 호출로 통합. 힌트 기록 + 동료 등장 반응 스캔. 핫패스라 회귀 전수 확인
  - 반응은 대상 고정(방금 등장 하수인)·유익하므로 카운터 있으면 자동 발동(시뮬 단순화). vfx.reaction=gunshot
  - 검증: 두 slug 통합 / 화살4 등장 / 하수인 등장 2피해 / 카운터 소진 / 0이면 미발동
- test_index에 entersWithCounters·onMinionEnterDamage 등록. test_cap_cards 45→51체크. 회귀 92종/카드1262/VFX513 무결
- **다음(한 장씩)**: 03013 squirrel-girl(반응: 각 적 1피해 AoE — ground-stomp/스쿼럴걸 패턴 재사용 확인)

## v2026.07.13.233 (03011 팔콘 — 조우덱 peek 인덱스)
- **03011 Falcon** (slug=falcon-ally, cap.json): 동료/리더십, 비용4, 💪물리1, Aerial·Avenger, ATK2/THW2/HP3
  - 반응: 등장 후 조우덱 상위 3장 확인 → 배신(treachery) 1장당 스킴 위협 1 제거
  - **[체크2] 신규 범용 EFFECT peekEncounterRemoveThreat 신설**(shards/mc_2_effects.js): count/matchType/perMatch/scheme 파라미터. 조우덱 상위 N장(deck.slice(-N), pop방향, 순서 유지=확인만) + 타입 카운트 + removeThreat. 카드는 whenPlayedEffects 데이터만
  - 검증: 배신 2장→위협2 제거 / 조우덱 33→33 순서 유지 / 배신 0장→제거 없음
  - ★배선 중 str_replace가 removeThreat 헤더를 실수로 삭제→복구. slug는 falcon-ally(falcon 아님, DB 확인)
- test_cap_cards 40→45체크. 회귀 91종/카드1262/VFX514 무결
- **다음(한 장씩)**: 03012 hawkeye-cap(동료, 화살 카운터+하수인 반응), 이후 리더십 어스펙트 계속 → 캡아 팩 완성 후 PRESET_DECK

## v2026.07.13.232 (03010 슈퍼솔저 혈청 — 캡아 시그니처 완료)
- **메모리 #11 추가**: 재사용 가능 능력은 반드시 인덱스(데이터) 방식. 매 카드 배선 전 3단계 체크 강제(재사용→확장→신규). 히어로 지속 보너스는 passiveXxx 집계로 수렴. 사용자 지적 전 선제 준수
- **03010 Super-Soldier Serum** (cap.json): 업그레이드/아이템, 비용2, 💪물리1. 자원: 소진→물리 자원 1 생성
  - **[체크1 통과] 기존 resourceGenerator 인덱스 재사용 — 신규 코드 0줄, 데이터만**: resourceGenerator{exhaust:true, icons:{physical:1}}. web-shooter와 동일 인덱스, 수치·대상만 다름
  - 검증: 물리 자원 1 생성 / 소진 시 불가
- test_cap_cards 38→40체크. 회귀 91종/VFX514/카드1262 무결
- **★캡아 시그니처 전부 배선 완료**: 03002 Agent13 / 03003 두려움없는결의 / 03004 영웅적일격 / 03005 방패막기 / 03006 방패던지기 / 03007 스티브아파트 / 03008 헬멧 / 03009 방패 / 03010 혈청. under-wired 5장(03005·07·08·09·10) 전부 해소
- **다음 마일스톤**: 캡아 리더십 어스펙트 카드(03011 팔콘/03013 스쿼럴걸/03014 원더맨/03015 어벤져스어셈블/03017 수적우위/03019 퀸젯) → 이후 캡아 PRESET_DECK 조립 → 6번째 플레이가능 영웅
- **다음(한 장씩)**: 03011 Falcon(동료)

## v2026.07.13.231 (★보복 집계 인덱스 통일 — passiveRetaliate)
- **사용자 지적**: "보복 블랙팬서도 그렇고 인덱스 타입으로 가고 있는 거 맞아?"
- **정밀 감사 결과**: 필드 구조는 이미 인덱스(retaliate=인스턴스/attachStats, grantsRetaliate=비부착 업그레이드)였으나, **집계 함수가 없어 triggerRetaliate에 인라인으로 흩어짐** — statMod은 passiveStatMod 집계 인덱스가 있는데 보복은 없었음. cap-shield 넣을 때 grantsRetaliate를 인라인 덧셈으로 붙인 게 불일치
- **수정**: `passiveRetaliate(G, character)` 집계 인덱스 신설 (passiveStatMod 대칭). 모든 보복 소스가 단일 함수로 수렴:
  ① 인스턴스 retaliate (적 기본 + attachStats.retaliate가 attachTo로 반영된 분)
  ② 히어로 신분 인쇄 보복 (블랙팬서, 히어로 폼만)
  ③ 히어로 비부착 업그레이드/서포트 grantsRetaliate (cap-shield)
  → triggerRetaliate가 이 함수만 호출. 새 보복 소스는 여기만 추가하면 트리거·표시 일괄 적용
- **검증**: BP 신분 보복 / cap-shield / 중첩(신분1+업1=2) / 알터에고 0 / 적 인스턴스 / 부착물 attachStats.retaliate 6+2 = test_retaliate_index.js 8체크 신설
- triggerRetaliate 핫패스 리팩터라 회귀 90→91종 전수 확인(기존 적 보복·BP·클로 반격 무사)
- **인덱스 원칙 정합**: 이제 스탯(statMod↔passiveStatMod)과 보복(grantsRetaliate/attachStats↔passiveRetaliate)이 동일 구조
- ※03010 슈퍼솔저 혈청은 아직(다음). under-wired 4/5 완료

## v2026.07.13.230 (03009 캡틴아메리카의 방패 — 방패 3종 세트 완성)
- **03009 Captain America의 방패** (cap.json 교차검증): 업그레이드/아이템, 비용1, 🃏와일드1, 제한(Restricted). DEF+1 + 보복1 (지속)
- **신규 메커니즘 (재사용)**: 히어로 업그레이드가 보복 부여 — triggerRetaliate가 히어로 폼일 때 playArea.upgrades/supports의 grantsRetaliate 합산. 지금까지 보복은 적(빌런/하수인)에만 있었고 히어로에 부여하는 첫 카드. VFX 힌트도 업그레이드 케이스 추가
- statMod{defense,+1}는 기존 passiveStatMod(playArea 스캔)로 동작. grantsRetaliate:1 신규
- 검증: DEF+1 / 공격받을 때 보복1(공격자 1피해) / 방패 없으면 보복 없음. triggerRetaliate 핫패스라 회귀 90종 전수 확인(기존 적 보복·BP 신분 보복 무사)
- test_index에 grantsRetaliate 등록. test_cap_cards 34→38체크. VFX513/카드1262 무결
- **★방패 3종 세트 완성**: 03005 방패 막기(소진→방지) + 03006 방패 던지기(반환+다중타격) + 03009 방패 본체(DEF+보복) 모두 배선. 서로 참조 정합
- under-wired 5장 중 4장 완료(03007,03008,03009). 남은: 03010 혈청(자원 생성)
- **패키징 정책 변경**: 이제 직전 2개 버전만 유지(자동 정리). outputs 114개→4개로 정리 완료
- **다음(한 장씩)**: 03010 Super-Soldier Serum(자원: 소진→물리 자원 생성 — resourceGenerator)

## v2026.07.13.229 (03008 캡틴아메리카의 헬멧 — 패배 방지)
- **03008 Captain America의 헬멧** (cap.json 교차검증): 업그레이드/방어구, 비용1, 💪물리1. 인터럽트: 캡틴이 패배당할 때 HP를 1로 만들고 이 카드 버림
- **신규 히어로 패배 방지 메커니즘** (재사용): applyDamage의 hp≤0 처리에 추가 — target(히어로)의 playArea.upgrades에서 preventDefeatToHp 필드 카드를 찾으면 → HP를 그 값으로 설정 + 카드를 소유자 버림 더미로 + 미탈락. 기존 reviveOnDefeat(부착물, 하수인/빌런)와 별개(헬멧은 attachTarget 없는 히어로 업그레이드라 playArea.upgrades 스캔 필요)
  - preventDefeatToHp:1 데이터만으로 동작. G.fxHelmetSave 힌트(UI 후속용)
- 검증: 헬멧 있으면 치명타→HP1 생존+헬멧 버림 / 없으면 탈락. applyDamage 핫패스 수정이라 회귀 90종 전수 확인
- test_index baseFields에 preventDefeatToHp 등록. test_cap_cards 28→34체크. VFX511/카드1262 무결
- under-wired 5장 중 2장 완료(03007,03008). 남은: 03009 방패(DEF+1+보복), 03010 혈청(자원생성)
- **다음(한 장씩)**: 03009 Cap Shield(제한, DEF+1+보복1 지속 — statMod+retaliate). ※shield-block/shield-toss가 참조하는 그 방패 — 능력 배선

## v2026.07.13.228 (03007 스티브의 아파트)
- **03007 Steve의 아파트** (cap.json 교차검증): 서포트/장소, 비용1, ⚡에너지1. 알터에고 행동: 소진→카드1 드로우 + 스티브 로저스 피해1 회복
  - activatedAbility{form:'alter-ego', exhaust:true, effect:[draw self 1, heal self 1]} — 기존 패턴 재사용
  - vfx.recover(회복 연출). 검증: 알터에고 사용 시 드로우/회복/소진 / 히어로 폼 사용 불가
- under-wired 5장 중 1장 완료(03007). 남은 under-wired: 03008 헬멧, 03009 방패, 03010 혈청
- test_cap_cards_reverify.js 27→28체크. 회귀 90종/VFX510/카드1262 무결
- ※환경 일시 장애로 03007 편집이 유실됐다 복구·재적용됨(v227 패키지는 온전, 데이터 유실 없음)
- **다음(한 장씩)**: 03008 Cap Helmet(인터럽트: 패배 시 HP1로 + 버림 — defeat-prevention)

## v2026.07.13.226 (03005 방패 막기 + 03006 방패 던지기 — 방패 인프라)
- **mcode 순서 준수** (사용자 지적: 순서대로가 맞음). 03005 → 03006
- **신규 재사용 인프라**:
  - EFFECTS.exhaustNamedCard: 특정 카드(slug) 준비된 1장 소진 (비용)
  - cond hasReadyCard: 특정 카드가 플레이영역에 준비(비소진) 상태로 존재
  - cond hasCardInPlay: 특정 카드가 플레이영역에 존재(소진 무관)
  - 이벤트 ctx에 discardUids 추가 (X장 버림 카드용)
- **03005 Shield Block** (이벤트/방어/cost0/🧠멘탈1): defense trait+preventAll → 방어 pending 중 플레이. playCondition:hasReadyCard(cap-shield) + exhaustNamedCard(cap-shield) + preventAll. 방패 소진→피해 전부 방지. 방패 없거나 소진 시 플레이 불가
- **03006 Shield Toss** (이벤트/공격·초능력/cost0/⚡에너지1): special:shieldTossPlay 핸들러 — ①손에서 X장 버림(ctx.discardUids) ②cap-shield 플레이영역→손 반환 ③dealDamageMulti(4, lines=X)로 X명 서로다른 적에게 4피해씩. playCondition:hasCardInPlay(cap-shield)
  - 기존 dealDamageMulti/returnToHand 패턴 재사용. 가변X+다중타겟+카드반환이라 special 핸들러 정당
  - **UI 후속 필요**: 다중 선택(X장 버림 + X적 타겟) UI 플로우. 엔진 로직은 완성·검증됨
- test_cap_cards_reverify.js 16→23체크 (03005 소진/방지/조건, 03006 X버림/반환/다중피해/조건). 회귀 90종/VFX509/카드1262 무결
- **캡아 시그니처 진행**: 03002✓ 03003✓ 03004✓ 03005✓ 03006✓ / 다음 under-wired: 03007 아파트, 03008 헬멧, 03009 방패, 03010 혈청

## v2026.07.13.225 (03004 영웅적 일격 + ★캡아 미완성 발견)
- **사용자 지적 "캡아 넘어간 거 아냐?" → 정밀 확인**:
  - 캡아 신분(03001a/b) 배선 ✓ 이지만 **캡아 프리셋 덱 없음** (spiderman/captain-marvel/she-hulk/iron-man/black-panther 5개만) → 캡아 아직 선택 불가
  - 캡아 팩 23장: 배선 3(→4) / 스탯 6 / ✋미배선 14
  - **★"스탯only" 5장이 실은 능력 미배선 (todoFx 플래그 없어 은폐됨)**:
    - 03005 Shield Block: 방어 인터럽트(방패 소진→피해 전부 방지) 미배선
    - 03007 Steve's Apartment: 알터에고 행동(소진→드로우1+회복1) 미배선
    - 03008 Cap Helmet: 인터럽트(패배 시 HP1) 미배선
    - 03009 Cap Shield: DEF+1+보복1 지속 미배선
    - 03010 Super-Soldier Serum: 자원 생성(소진→물리) 미배선
  - 캡아 완성 = todoFx 14 + under-wired 5 = 19장 + 프리셋 덱 조립
- **03004 Heroic Strike 배선** (cap.json 교차검증): 이벤트/공격/cost3/💪물리1. playForm hero + dealDamage(chosen,6,isAttack) + applyStatus(chosen,stunned,cond:paidWith physical). haymaker+for-justice 킥커 패턴 조합
  - 검증: 항상 6피해 / 물리 지불 시만 기절(킥커)
- test_cap_cards_reverify.js 6→10체크. 회귀 90종/VFX508/카드1262 무결
- **다음**: 03005/03006은 방패(cap-shield) 상호작용 — "특정 카드 소진/반환 비용" 신규 인프라 필요. 03005(방패소진→방지), 03006(방패반환+X버림+X적 피해)

## v2026.07.13.224 (카드 등록 재개 — 03003 두려움없는 결의)
- **stabilization 일단락 → mcode 순 카드 등록 재개**. 캡아 팩(03xxx) 프런티어 = 03003
- **03003 Fearless Determination 배선** (공식 cap.json 교차검증):
  - 이벤트, 초능력, 비용0, 🧠멘탈1. 히어로 행동: 이번 페이즈 THW+1 + 카드 1장 드로우
  - playForm:hero + whenPlayedEffects:[buffSelfStat(target:hero,thwart,1), draw(self,1)]
- **buffSelfStat 범용화**: target 파라미터 추가 — 'hero'/'player'=플레이어(pl.tempStatBonus), 미지정=ctx.self(이벤트/동료). spider-man-miles 하위호환 유지. 앞으로 "히어로 +N 이번 페이즈" 카드 재사용
  - 인프라 기존재 확인: statOf가 pl.tempStatBonus 읽음(mc_4_players:63), 페이즈 종료 시 리셋(mc_7_core:708)
- vfx: event:capReady (캡아 결의 테마)
- **신규 tests/test_cap_cards_reverify.js 6체크** (03003 THW버프/드로우/페이즈리셋 + buffSelfStat target 하위호환). 회귀 89→90종. VFX 507건
- 캡아 팩 다음 프런티어: 03004 Heroic Strike(P1,cost3), 03006 Shield Toss(E1,cost0), 03011 Falcon, 03013 Squirrel Girl, 03014 Wonder Man, 03015 Avengers Assemble 등

## v2026.07.13.223 (동료 부착/상태 연출 누락 수정 — v222 후속)
- **경미 누락 3건 수정** (v222에서 대칭이라 무해라 판정했던 부분, 애니 표시 복원):
  - collectAttachments: 빌런+하수인만 스캔 → **동료 스캔 추가**. 격분(enraged)/감화(inspired)는 ally.attachments에 저장(type upgrade지만 playArea.upgrades엔 없음)이라 미스캔 시 combatInstall 연출 안 나왔음
  - **설치 연출 host 해소 수정**: 부착 설치 VFX가 host 못 찾으면 `.villain-zone` 하드코딩 폴백 → 동료 부착물이 빌런에 잘못 재생. snapshot에 hostUid 저장 → `[data-vuid=hostUid] .card-art`로 정확한 host(동료/하수인/빌런) 해소
  - collectStatuses: 빌런+하수인만 → **동료 스캔 추가**. 동료 기절/혼란/강인 상태 연출(confuse/toughGain) 표시
- **대칭 유지**: 세 함수 모두 prev/now가 같은 함수라 동료 추가해도 대칭 → 과다발동 없음, 연출은 최초 1회만
- **과다발동 아님 재확인**: enraged(type upgrade)는 ally.attachments에 있고 playArea.upgrades엔 없어 installedNow 경로로 중복 감지 안 됨
- test_ui_snapshot_symmetry.js 5→8체크 (collectAttachments 동료+hostUid, collectStatuses 동료 검사 추가). 회귀 89종 유지

## v2026.07.13.222 (★동료 등장 연출 과다발동 버그 수정)
- **사용자 지적**: 동료 이펙트(allyEnter)가 유난히 자주 나옴
- **원인 (UI 스냅샷 비대칭)**: act()가 액션 전 collectInstalled()로 "이전 설치 목록" 스냅샷 → 액션 후 installedNow와 diff해서 신규만 VFX 재생. 근데 collectInstalled(ui/mc_ui.js:573)가 supports/upgrades만 담고 **allies(동료) 누락**. installedNow(383)는 동료 포함 → 비대칭 → 동료 uid가 매번 "신규"로 오인 → allyEnter가 매 액션마다 재발동. (지원/업그레이드는 목록에 있어 1회만 정상)
- **수정**: collectInstalled에 `for (const c of pl.playArea.allies) s.add(c.uid)` 추가 → 대칭 회복. 동료 등장 연출은 최초 1회만
- **인덱스 감사 (같은 클래스 전수 점검)**: 모든 collect* 스냅샷 함수 확인
  - collectInstalled: 동료 누락(비대칭)=버그 → 수정
  - collectAttachments/collectStatuses: prev·now 둘 다 같은 함수(대칭) → 과다발동 아님. 동료 부착/상태 VFX 미표시(경미 누락, 별도)
  - collectExhausted/collectHp/collectDefeatables/barSnapshot: 동료 포함 ✓
- **신규 tests/test_ui_snapshot_symmetry.js 5체크**: collectInstalled가 allies/supports/upgrades 3종 모두 포함하는지 소스 검사(UI 회귀 방지). 회귀 88→89종
- 알려진 경미 누락(버그 아님): 동료 부착물(enraged/inspired)·동료 상태 변화 VFX는 collectAttachments/collectStatuses가 동료 미스캔이라 애니 미표시. 필요 시 후속

## v2026.07.13.221 (★덱 소진 규칙 — 공식 RRG 대조·수정)
- **사용자 지적으로 RRG(공식 규칙서) 웹 검색 대조** — 기억 단정 금지
- **정정된 오해**: "덱 소진 시 히어로 피해 1"은 규칙에 없음(내 기억 오류). 실제 RRG = 리셔플 + 조우 카드 1장 딜
- **RRG 대조 결과 3가지**:
  - ② 조우 덱 소진 → 가속 토큰 +1: **이미 정확** (drawEncounterCard)
  - ① 플레이어 덱 리셔플 순서: dealEncounter 먼저→셔플 (역순)였으나 dealEncounterTo가 큐잉만 해서 기능 무해. RRG대로 "셔플 먼저→조우카드"로 정정
  - ③ **밀(덱에서 버리기) 중 소진 = 실제 버그**: RRG는 "밀 중 소진 시 새로 섞인 덱에선 안 버림"인데, 리셔플 후 루프가 계속 돌아 새 덱에서 밀어버림. 실증: 덱2장+5장밀 → 5장 전부 밀림(버그)
- **수정**: 밀 3곳(repulsorBlast mill / millAndGrab / discardTopOfDeck) — 소진 시 `onEmptyPlayerDeck` 후 `break`(새 덱에서 안 밀음). 뽑기(drawCards)는 RRG대로 계속 뽑음 유지
- **RRG 근거**: "If a player deck runs out of cards, shuffle discard to make new deck. Immediately deal 1 card from encounter deck. If drawing, continue up to number. If discarding from deck [milling], no cards discarded from newly shuffled deck." / "If encounter deck runs out, place 1 acceleration token on main scheme."
- **신규 tests/test_deck_exhaustion.js 7체크** (플레이어덱 리셔플+조우카드 / 뽑기 계속 / 밀 중단 millAndGrab·discardTopOfDeck / 조우덱 가속토큰). 회귀 87→88종

## v2026.07.13.220 (커스텀 핸들러 데이터화 ②단계 — 공통 fx로 10개 통합)
- **신규 범용 fx 3종 + cond 1종** (재사용 인프라):
  - EFFECTS.searchDeckToHand: filters[{type,trait,mcode}] 우선순위 탐색 + includeDiscard(버림더미) + reveal 힌트 → shuri/bpForesight/capShieldSetup 3개 통합
  - EFFECTS.buffAttachedAlly: attack/thwart/atkCost 가산 → enraged(ATK+2/부수+1)/inspired(ATK+1/THW+1) 2개 통합
  - EFFECTS.refreshMaxHp: 소유자 최대HP 재계산 → mk5-armor(+6)/rocket-boots(+1) 중복 2개 통합
  - cond 'targetStatus': 대상(villain/self/target) 상태 체크 → im-tough/false-alarm 급증-무효 분기 (기존 healedNone과 함께 hard-to-keep-down도)
- **데이터화된 10 핸들러**: shuriSearch/bpForesight/capShieldSetup/enragedAttach/inspiredAttach/applyHpBonus/applyHpBonusRB/rev_hardToKeepDown/rev_imTough/rev_falseAlarm
- **동작 보존 검증**: 전부 데이터 버전이 동일 효과(양쪽 분기 포함) → test_dataify_reverify.js 13체크 신설
- 낡은 assertion 업데이트: test_captain_america_identity(onSetup 데이터 배선)
- test_index.js: whenPlayedEffects/onSetupEffects를 fx검증+허용필드에 추가
- **커스텀 핸들러 32 → 16 (①6 + ②10 = 16개 제거, 절반)**. 회귀 86→87종/카드1262/VFX506 무결
- 남은 커스텀 16개 = 정당한 커스텀(hulkForcedResponse/klawMainMinion/빌런단계5/시나리오셋업2/runAttachDamagedEffects/fi_attackEachHero) + ③애매4(daredevilThwartPing/superhumanStrengthForced/tigraAfterAttack/sheHulkPower) + spiderSense
- **재사용 인프라 확보**: 앞으로 나올 덱검색/동료버프/HP업그레이드/상태체크 카드는 이 fx들 재사용

## v2026.07.13.219 (커스텀 핸들러 데이터화 ①단계 — 순수 래퍼 6개)
- **순수 래퍼 6개 데이터화** (커스텀 핸들러 → runCardEffects + 훅별 effects):
  - shocker: rev_shocker → whenRevealedEffects:[{fx:damageEachHero,amount:1}]
  - hydra-bomber: rev_hydraBomber → whenRevealedEffects:[{fx:offerChoice,options:[피해2/위협+1]}]
  - radioactive-man: fr_radioactiveMan → forcedResponseEffects:[{fx:discardFromHand,who:self,amount:1}] (boostStar 유지)
  - tiger-shark: fr_tigerShark → forcedResponseEffects:[{fx:applyStatus,target:card,status:tough}] (boostStar 유지)
  - black-cat: blackCatForced → whenPlayedEffects:[{fx:millAndGrab,amount:2,keepResource:mental}] (atkCost:0 유지)
  - defense-network: sideSchemeRevealThreatPerHero → whenRevealedEffects:[{fx:placeThreat,scheme:self,perHero:1}]
- **핵심 확인**: fireCardHook이 ctx.hook=hookName 세팅 → runCardEffects가 def[hook+'Effects']를 정확히 조회. 모든 훅(whenPlayed/whenRevealed/forcedResponse) 지원
- **동작 보존 검증**: tiger-shark(자신Tough)/radioactive-man(손패버림)/hydra-bomber(택2)/black-cat(밀)/shocker(각히어로1)/defense-network(위협) 전부 데이터 버전이 동일 효과 산출 → test_klaw/test_rhino에 정확 효과 assertion 추가(무에러→효과검증 강화)
- test_phase3_core.js 낡은 assertion 4개 업데이트(옛 핸들러명→데이터 배선 검사)
- test_index.js: whenPlayedEffects를 fx검증 루프 + 허용필드에 추가
- **커스텀 핸들러 32 → 26** (6개 제거). 회귀 86종/카드1262/VFX506 전부 무결
- 남은 데이터화 후보: ②공통 fx(덱검색3/급증무효3/동료버프2/HP중복2) + ①잔여(spiderSense 등)

## v2026.07.13.218 (★★ 넴시스 재검증 — 실플레이 경로 안정화 완결)
- **5영웅 넴시스 세트 재검증 (실버그 없음)** → 신규 tests/test_nemesis_reverify.js:
  - 소환 흐름: 셋업 시 nemesisSetAside 배치 → shadow-of-the-past 공개 → 하수인 등장 + 사이드스킴 배치
  - 블랙팬서: usurp-the-throne/heart-shaped-herb(Tough)/ritual-combat(택)
  - 스파이더맨: highway-robbery/sweeping-swoop/vultures-plans
  - 쉬헐크: personal-challenge/titanias-fury/genetic-enhancement(부착)
  - 아이언맨: imminent-overload/electric-whip-attack(택)/electromagnetic-backlash
  - 캡틴마블: psyche-magnitron/kree-manipulator(메인위협)/yon-roggs-treason(자원버림)
  - 넴시스 구조: NEMESIS_SETS[hero] = {minion, sideScheme, rest:[[code,count]]}. 하수인5=스탯, 배선15
- test_nemesis_reverify.js 18체크. 회귀 85→86종

## ★★★★ 안정화 완결 선언 (실제 플레이되는 모든 경로)
- **재검증 완료 & 영구 테스트화된 경로** (6개 전용 테스트, 126체크):
  - 코어 플레이어 39장(50) + 라이노(23) + 클로(19) + 울트론(16) + 6영웅 신분·공격VFX(28) + 넴시스 5세트(18)
- **커버리지 결론**: 프리셋 덱(6영웅) × 3시나리오 + 넴시스 = 실제 플레이되는 모든 카드/흐름이 매 빌드 자동 검증됨
  - 프리셋 덱 배선 카드 34종 = 코어39의 부분집합(이미 검증). 프리셋 덱엔 todoFx 0장
- **발견·수정 실버그 총 3개**(전부 코어): 블랙캣 atkCost / lookAtTopChoose 방향 / 리펄서 방향
- 인카운터·영웅·넴시스는 실버그 0 — 엔진 자체는 안정적이었고, 코어 카드 배치에만 버그 존재했음
- **다음은 안정화가 아닌 "콘텐츠 완성도"**: 선택배선 172 / 나머지26영웅 배선 / 커스텀27 데이터화

## v2026.07.13.217 (★영웅 신분 안정화 — 6영웅 재검증 + 공격 VFX 완성)
- **공격 애니메이션 누락 3영웅 수정**: 캡틴마블·쉬헐크·아이언맨은 basicAttack VFX가 없어 기본 공격 시 애니메이션이 안 나왔음
  - captain-marvel(01010a) → photonBlast (광자 에너지)
  - she-hulk(01019a) → gammaSmash (감마 에너지)
  - iron-man(01029a) → repulsorBeam (리펄서 빔)
  - 전부 테마 매칭 + 이미 존재하는 VFX. 이제 6영웅 전원 basicAttack VFX 보유(기존: 스파이더맨 strike/블랙팬서 claws/캡아 shieldToss)
- **배선 방식(중요)**: defineCardFx는 top-level Object.assign이라 vfx 통째 교체됨. 기존 vfx(formChange/basicThwart) 보존 위해 full vfx 객체로 재지정(cards/mc_cards_zidentity_fx.js의 기존 defineCardFx 호출에 병합)
- **6영웅 신분 카드 전체 재검증** → 신규 tests/test_identity_reverify.js:
  - 기본 공격 VFX 등록 + 기존 vfx 보존 확인(6)
  - 기본 공격 실행 → 빌런에 attack 스탯대로 피해(6): 스파이더맨2/캡마2/쉬헐크3/아이언맨1/블랙팬서2/캡아2
  - 폼 전환 왕복(6)
  - 신분 능력: 캡마 Rechannel(에너지지불→회복), 캡아 하루종일(손패버림→준비), 쉬헐크 sheHulkPower(폼전환 발동), 아이언맨 dynamicHandSize
- **테스트 파라미터 기록**: basicAttack는 targetUid(target 아님), useIdentityAction 지불은 payment:[{kind:hand,uid}], 캡아 버림은 discard:[uid]
- test_identity_reverify.js 28체크. 회귀 84→85종. VFX 참조 506건 무결

## v2026.07.13.216 (★★ 인카운터 안정화 완료 — 3개 시나리오 전부 재검증)
- **울트론 시나리오 재검증 (실버그 없음)** → 신규 tests/test_ultron_reverify.js:
  - 셋업: ultronSetup — 드론 환경(ultron-drones) 배치
  - 빌런 3단계: 01134→01135→01136(울트론의 명령 사이드스킴)
  - 드론 인카운터: android-efficiency(드론소환)/repair-sequence(교전드론×2 회복)/swarm-attack(드론공격)/rage-of-ultron(폼분기)/사이드스킴3종(drone-factory/invasive-ai/ultrons-imperative)/부착물2종/메인스킴 다단계(01138b/01139b)
  - ※드론은 MC.spawnFacedownDrone로 생성되는 페이스다운 인스턴스(등록카드 아님) — 테스트 시 주의
- test_ultron_reverify.js 16체크. 회귀 83→84종 전부 통과

## ★★★ 안정화 총결산 (코어+3시나리오)
- **재검증 완료 & 영구 테스트화**: 코어 플레이어 39장 + 라이노/클로/울트론 3개 시나리오 전 카드
- **전용 회귀 테스트 4종**: test_core_reverify(50) + test_rhino_reverify(23) + test_klaw_reverify(19) + test_ultron_reverify(16) = 108체크, 매 빌드 자동검증
- **발견·수정한 실버그 3개**: 블랙캣 atkCost / lookAtTopChoose 방향 / 리펄서 방향 (전부 코어 배치에서)
- 인카운터(라이노·클로·울트론)는 실버그 0 — 시나리오 엔진은 안정적이었음
- 이제 실제 플레이 가능한 게임(6영웅 × 3시나리오)의 핵심 경로가 매 빌드 자동 검증됨

## v2026.07.13.215 (인카운터 안정화 — 클로 시나리오 재검증 완료)
- **클로 시나리오 전 카드 재검증 (실버그 없음)** → 신규 tests/test_klaw_reverify.js:
  - 빌런 3단계: 01113→01114(불멸의클로 사이드스킴)→01115(Tough)
  - 메인스킴 klawMainMinion: 공개 시 하수인 등장까지 인카운터 버림(discardUntilMinion)
  - 클로셋: klaw-vengeance(폼분기 공격/버림), sonic-boom(자원지불 택), sound-manipulation(회복), illegal-arms-factory/defense-network(사이드스킴), sonic-converter/solid-sound-body(부착물)
  - masters-of-evil 모듈러: scheme, masters-of-mayhem, radioactive-man/whirlwind/tiger-shark(강제반응/인터럽트), melter
  - 표준셋(advance/assault 등)은 라이노 테스트에서 이미 검증(공유)
- test_klaw_reverify.js 19체크. 회귀 82→83종 전부 통과
- **인카운터 재검증 진행: 라이노·클로 完. 다음: 울트론 시나리오**

## v2026.07.13.214 (★인카운터 안정화 시작 — 라이노 시나리오 재검증 완료)
- **안정화 우선순위 확정**: 매 게임 실행되는 코어 인카운터/빌런 62장이 최고위험(미검증). 시나리오별 순차 재검증 시작 → 라이노부터
- **라이노 시나리오 전 카드 재검증 (실버그 없음)** → 신규 tests/test_rhino_reverify.js:
  - 빌런 3단계: 01094→01095(breakin-and-takin 공개)→01096(Tough+전체히어로 기절). 전환·효과 정상
  - 표준셋: advance(메인위협)/assault(히어로=공격,알터=급증)/stampede(급증)/caught-off-guard/gang-up/shadow-of-the-past
  - 라이노셋: shocker(각히어로1피해)/hard-to-keep-down(4회복,풀피급증)/im-tough(Tough,이미면급증)/crowd-control/breakin-and-takin(사이드스킴)
  - bomb-scare 모듈러: false-alarm(혼란)/bomb-threat(사이드스킴)/hydra-bomber/explosion
- **테스트 방식 주의(기록)**: 인카운터 treachery/minion은 fireCardHook('whenRevealed'), 사이드스킴은 revealSpecificSideScheme로 검증(scheme:'self' 해소 위해). resolveEncounterCard 직접 사용은 whenRevealed 미발화
- test_rhino_reverify.js 23체크. 회귀 81→82종 전부 통과
- **인카운터 재검증 진행: 라이노 完. 다음: 클로 시나리오**

## v2026.07.13.213 (★★ 코어 등록카드 재검증 39장 완료)
- **의무 카드 5장 재검증 (전부 정상)** → test_core_reverify.js:
  - 01155 찬탈자 / 01160 법률업무 / 01165 퇴거통지 / 01170 사업문제 / 01175 가족비상 — 전부 whenRevealed:runCardEffects + offerChoice 2택(영웅소진=영구해결 / 미루기). 데이터 방식(하드코딩 아님)
  - exhaust 경로(영웅 소진) + defer 경로(family=기절, legal=가속토큰) 양쪽 검증
- **test_core_reverify.js 50개 체크 — 회귀 81종에 편입**
- **★★ 코어 재검증 총결산 (39장 完)**:
  - 재검증 대상 = 코어 플레이어카드 中 fx배선 39장 전부 실제 dispatch 실행 검증 → 영구 테스트화
  - **발견·수정한 실버그 3개**: ①블랙캣 atkCost 1→0 ②lookAtTopChoose splice(0)→pop (덱 바닥→위) ③리펄서블래스트 shift→pop (덱 바닥→위)
  - 나머지 36장 정상 확인. "됐다고 했는데 안 되는" 문제를 영구 테스트로 방지
- 이 시점부터 코어 카드가 깨지면 test_core_reverify.js가 매 빌드에서 즉시 잡음

## v2026.07.13.212 (코어 재검증 배치7 — 01069~87, 버그 없음)
- **01069~01087 재검증 (전부 정상)** → test_core_reverify.js:
  - 01069 준비태세: 동료 준비(소진 해제)
  - 01074 감화: 동료 ATK 강화(부수피해 없음)
  - 01083 모킹버드: 등장 후 적 선택(chooseEnemy) → 기절. 플레이어가 대상 선택(하드코딩 아님) 확인
  - 01086 응급처치: 캐릭터 피해 2 회복
  - 01087 강타: 적 3 피해
- test_core_reverify 32→38개 체크. 회귀 81종 전부 통과
- **코어 재검증 진행: 39장 中 34장 완료. 남은 5장 = 의무 카드(01155/01160/01165/01170/01175)**

## v2026.07.13.211 (코어 재검증 배치6 — 데어데블/저지 이벤트, 버그 없음)
- **01052~01060 재검증 (전부 정상)** → test_core_reverify.js:
  - 01052 추적하라: 반응(저지) 적 처치 후 위협 2 제거 (playCondition:justDefeatedEnemyByAttack)
  - 01053 거침없는돌진: 하수인 5 피해
  - 01054 어퍼컷: 적 5 피해
  - 01058 데어데블: afterThwart 적 1 피해
  - 01060 정의를위해: 위협 3 제거 / 🧠멘탈 지불 시 4 제거(킥커) — 둘 다 검증
- **테스트 셋업 주의 기록**: `placeThreat(G,'main',N)`은 klaw 메인스킴 임계치 초과 시 단계전환→위협리셋됨. 재검증 테스트는 `G.mainScheme.threat = N` 직접 세팅으로 회피
- test_core_reverify 26→32개 체크. 회귀 81종 전부 통과
- **코어 재검증 진행: 39장 中 28장 완료. 다음: 01067 마리아힐(완료됨) 건너뛰고 01069 준비태세~**

## v2026.07.13.210 (코어 재검증 배치5 — 블랙팬서/헐크/타이그라, 버그 없음)
- **01041~01051 재검증 (전부 정상)** → test_core_reverify.js 추가:
  - 01041 슈리: 등장 후 덱에서 업그레이드 1장 손에
  - 01042 조상의 지식: 버린 더미 서로 다른 3장 → 덱 (덱 +3)
  - 01043a 와칸다 포에버: BP 업그레이드 특수 순차 발동(wakandaOrder pending)
  - 01050 헐크: 공격 후 덱 위 1장 버림
  - 01051 타이그라: 하수인 처치 후 1 회복(순증0=회복+atkCost)
- test_core_reverify 21→26개 체크. 회귀 81종 전부 통과
- **코어 재검증 진행: 39장 中 23장 완료. 다음: 01052 추적하라!~ mcode순**

## v2026.07.13.209 (코어 재검증 배치4 — 아이언맨 시그니처 + 리펄서 방향버그)
- **★01031 리펄서 블래스트 밀 방향 버그(진짜 버그) 수정**: `deck.shift()`(앞=바닥)로 밀어서 덱 *바닥* 5장을 버리고 있었음 → 에너지 카운트가 엉뚱한 카드 기준이라 피해 틀림. `deck.pop()`(끝=덱 위)로 수정. lookAtTopChoose와 동일 계열 버그
  - 검증: 덱 위 에너지0 → 정확히 1피해 / 에너지카드2장(⚡4아이콘) → 1+8=9피해
- **정상 확인(버그 없음)**: 01028 초인적인힘(지속ATK+2 + afterBasicAttack 자체버림+대상기절), 01032 초음속펀치(4피해), 01036 MK5아머(maxHP+6), 01039 로켓부츠(maxHP+1)
- test_core_reverify 14→21개 체크. 회귀 81종 전부 통과
- **코어 재검증 진행: 39장 中 18장 완료. 다음: 01041 슈리~ mcode순**

## v2026.07.13.208 (코어 재검증 배치3 — 쉬헐크 시그니처)
- **01021~01025 재검증 (버그 없음, 전부 정상)** → test_core_reverify.js 추가:
  - 01021 감마슬램: 누적피해량 = 빌런 피해 (6→6)
  - 01022 짓밟기: 빌런+하수인 각 1 피해 (AoE)
  - 01023 법률업무: 손 N장 버림 → N만큼 메인위협 제거
  - 01024 원투펀치: 기본공격 후 히어로 준비
  - 01025 이중인격: 폼 전환
- test_core_reverify 9→14개 체크. 회귀 81종 전부 통과
- **코어 재검증 진행: 39장 中 13장 완료(01002~76 + 01021~25). 다음: 01028 초인적인힘~ mcode순**

## v2026.07.13.207 (★재검증 = 영구 회귀 테스트로 — "거짓말 방지")
- **방법 전환**: 재검증을 임시 node 스크립트로 하고 버리면 다음에 깨져도 모름 → **영구 회귀 테스트 파일 tests/test_core_reverify.js** 생성. 매 빌드 자동 검증 = 다시 깨지면 즉시 잡힘
- **박은 검증 9개 (실제 작동 확인된 것만)**:
  - 01002 블랙캣: atkCost 0 + 멘탈카드 손/비멘탈 버림
  - 01011 스파이더우먼: 빌런 혼란
  - 01067 마리아힐: 각 플레이어 1장 드로우
  - 01076 루크케이지: 자신(동료) Tough / 히어로엔 안 걸림
  - 01012 위기저지: 위협 2+ 제거
  - 01013 광자폭발: 빌런 5 피해
  - lookAtTopChoose: 덱 위(끝) 3장 pop 순서 (Futurist 방향 버그 회귀 방지)
- **덱 방향 규약 명문화**: 덱 위 = 끝(pop 방향). 테스트에서 '위'에 심을 땐 deck.push
- 회귀 80→81종 전부 통과
- **코어 재검증 진행: 39장 中 검증완료 8장(01002/03/05/11/12/13/67/76). 다음: 01021 감마슬램~ 계속 test_core_reverify.js에 추가**

## v2026.07.13.206 (★하드코딩→데이터 리팩터 — 사용자 지적 "인덱스로 하라")
- **커스텀 핸들러 전수 인덱스**: 훅 배선 카드 분류 → 범용데이터(runCardEffects) 65장 / **커스텀 핸들러(하드코딩) 30장**. 상당수가 기존 EFFECTS 얇은 래퍼
- **순수 래퍼 3개 데이터화 (커스텀 제거)**:
  - maria-hill: mariaHillDraw → runCardEffects + effects:[{fx:draw,who:all,amount:1}]
  - spider-woman-ally: spiderWomanEnter → effects:[{fx:applyStatus,target:villain,status:confused}]
  - luke-cage: lukeCageTough → effects:[{fx:applyStatus,target:'card',status:tough}]
- **★resolveTarget에 'card' 타겟 추가**: [ctx.card||ctx.self] = 플레이된 카드/동료 자신. 'self'는 ctx.player(히어로)를 줘서 동료-자기버프에 부적합했음 → 'card'로 해결. 재사용 가능(향후 동료 자기버프 전부)
- 검증: 3개 동작 동일 + 루크 Tough가 히어로 아닌 동료 자신에 정확히 부여. 회귀 80종 통과
- **남은 커스텀 27장** — 다음: daredevilThwartPing/superhumanStrengthForced 등 준-커스텀 검토 후 가능한 것 데이터화. 일부(shuriSearch 덱검색, 빌런 stageReveal 등)는 정당한 커스텀

## v2026.07.13.205 (★코어 등록카드 재검증 — mcode순, 소배치)
- **작업 원칙 복귀**: 백로그 임의 배선 중단 → 코어(01xxx) 등록카드를 mcode 오름차순으로 *재검증*(실제 작동 확인). 재검증 대상 = 코어 플레이어카드 中 fx배선된 39장
- **배치1 (01002~01005) — 실버그 2개 발견·수정**:
  - **01002 블랙캣 atkCost 버그**: DB atkCost:1 → 공식은 "공격 후 부수 피해 없음" = atkCost 0. defineCardFx에 atkCost:0 추가. millAndGrab(멘탈카드 손/비멘탈 버림)은 정상 확인
  - **★lookAtTopChoose 방향 버그(인덱스급)**: `deck.splice(0,count)`(앞=바닥)로 뽑아 Futurist가 덱 *바닥* 3장을 보고 있었음. drawCards/repulsor/millAndGrab 전부 pop()(끝=위)인데 이것만 반대. → for+pop()으로 수정. **이 효과 쓰는 모든 카드(Futurist·Agatha·Aamir 등)에 동시 적용**
  - 01003 공중제비(preventAll 방어)·01005 회전거미줄발차기(8피해) 정상 확인
- 회귀 80종 통과
- **재검증 진행: 39장 중 3장 완료(01002/01003/01005). 다음 배치: 01011 스파이더우먼~ mcode순**

## v2026.07.13.204 (마일즈 배선 — 소배치 작업법 시작)
- **작업법 전환**: 세션 안정성 위해 카드 1~3장 소배치 + 매 카드 즉시 검증 + 자주 저장
- **스파이더맨(마일즈 13019)**: whenPlayed → offerChoice(ATK/THW) → 이번 페이즈 해당 스탯 +2. 신규 범용 효과 `EFFECTS.buffSelfStat`(ctx.self.tempStatBonus[stat] += amount, 페이즈종료 자동리셋 재사용). 검증: ATK택 ATK만+2 / THW택 THW만+2 / 페이즈종료 리셋 ✓
- **buffSelfStat**는 다른 "자기 스탯 이번 페이즈 +N" 카드에 재사용 가능 (비전 identityAction 등 백로그)
- 회귀 80종 통과. 선택 배선 백로그 173→172장

## v2026.07.13.203 (선택 pending 시스템 인덱스 + Nick Fury 배선)
- **★사용자 지적 "선택 하드코딩" 조사 결과 — 인덱스로 전수 확인**
  - 선택 인프라는 이미 완비: `EFFECTS.offerChoice`(revealChoice pending)+`chooseEnemy`(대상선택 then체인)+`lookAtTopChoose`(cardPick pending)+`resolveTarget('chosen')`. UI 렌더러(revealChoice 1894/chooseEnemy 1906/cardPick 1913)+해소액션(resolveRevealChoice/resolveChooseEnemy/resolveCardPick) 전부 존재
  - **Futurist(토니 01029b identityAction)**: 이미 lookAtTopChoose→cardPick 완전 배선. 엔진+UI 검증 통과(덱위3장→1택→손, 나머지2 버림). *미배선 아니었음* — 사용자가 hero 폼에서 시도했거나 구버전 가능성
  - **Nick Fury(01084)**: *진짜 미배선(todoFx)이었음* → 신규 cards/mc_cards_zzchoice_fx.js. whenPlayed:runCardEffects + offerChoice 3택(thwart=위협2제거 / draw=카드3 / damage=chooseEnemy→4피해). damage는 플레이어가 대상 직접 선택(하드코딩 아님). 6개 테스트 통과
  - **★ 선택 미배선 전수 인덱스: 173장(플레이어 129/인카운터 44)** → CHOICE_BACKLOG.tsv 저장. 선택 시스템은 완성됐고 개별 카드 배선이 대량 백로그
- **낡은 테스트 수정**: test_phase3_core의 Futurist/Nick Fury 테스트가 inline-choice(구설계) 가정 → 실제 pending 흐름(resolveCardPick/resolveRevealChoice+resolveChooseEnemy)으로 갱신. 최종결과 검증은 동일
- 회귀 80종 전부 통과, vfx 인덱스 503건 통과

## ★선택 배선 백로그 (CHOICE_BACKLOG.tsv — 다음 세션 대량 작업)
- 173장(P129/E44). 패턴별 재사용: 모드택1=offerChoice / 대상적선택=chooseEnemy / 덱상위N중택=lookAtTopChoose / 스탯버프택=신규 필요할수도
- 고가치 예: spider-man-miles(THW/ATK택), toe-to-toe(적선택), obligation 5종(택1), heimdall(조우조작), spiritual-meditation(2드로우1버림)

## v2026.07.13.202 (이번 세션 — 플레이버 + 공개모달 + 타이그라)
- **오리지널 한국어 플레이버**: 영어 flavor 억제 후 공백이던 자리 → 캐릭터 테마 기반 오리지널 한국어 창작(번역 아님)
  - 신분 12장(mc_cards_zzidentity_text.js IDENTITY_FLAVOR) + 코어 플레이어 54장(신규 cards/mc_cards_zzflavor_ko.js FLAVOR_KO)
  - info() 돋보기가 한국어 flavor 우선 표시 → 토니스타크 등 정상 표시 확인
  - 남은: 코어 외 나머지 영어flavor 카드 수백장(스타로드/네뷸라/헐크팩 등) 순차 확장 필요
- **공개 모달 텍스트 겹침 수정**: .reveal-modal 배경 딤이 rgba(5,4,10,.94)로 6% 투과 → 뒤 #vpanel(z60) 비쳐 겹침. .985~.995로 거의 불투명화 → 뒤 패널 안 비침
- **★ 타이그라(01051) 반응 배선(이전 todoFx 미발동)**: 신규 cards/mc_cards_zztigra_fx.js — HANDLERS.tigraAfterAttack + defineCardFx('tigra-ally',{afterAttack}). 공격으로 하수인 처치 시 1 회복(atkCost보다 먼저=FAQ). 검증: 처치 시 순증0(회복+atkCost 상쇄), 생존 시 -1(atkCost만)
- 회귀 80종 그린

## ★미해결 (다음 세션 최우선) — 사용자 지적 4건 중 2건
- **④ 선택 하드코딩 (Futurist·Nick Fury 등)**: 둘 다 todoFx:true, fx 핸들러 전무 → 플레이어 선택 모달 없이 기본만 동작(사용자 "하드코딩" 지적). 필요: 카드선택(cardPick)·모드선택 pending 시스템. Futurist=덱위3장 보고 1택, Nick Fury=위협2제거/드로우3/피해4 중 택1. 와칸다순서(v196)와 유사한 플레이어 선택 UI 확장
- **② 동료 이펙트 과다 발동**: 재현/원인 미확인. FX큐(v199) 연출 반복 or 반응 중복발동 의심 — 재현 후 조사 필요
- ※ ① 타이그라는 이번에 해결, ③ 공개모달 겹침도 이번에 해결

## v2026.07.13.201 (이번 세션 — 역습 공격 사이드 확장)
- **★ 역습(Retaliate) 공격 사이드 확장 — 이전 세션 남은 엣지 해소**:
  - 이전(v200): 방어 사이드(빌런→히어로)만 "공격받음" 기준으로 수정. 공격 사이드(히어로/동료→적)는 applyDamage 인라인이라 Tough 흡수 시 적 역습 누락 가능성 남아있었음
  - 수정: ACTIONS.basicAttack·allyAttack에 noRetaliate 위임 + 명시적 MC.triggerRetaliate(target, 공격자) 호출 → 대상(부착물 등으로 retaliate 보유)이 살아남으면 강인 흡수·0피해여도 역습 발동. RRG 순서(공격 해소 후 보복 → 그 다음 afterAttack 강제반응) 준수
  - 검증 추가(tests/test_retaliate.js ⑥~⑩): 히어로가 역습-적 공격/강인 흡수 시 역습/중복 방지, 동료 공격(atkCost1+역습1)/대조군(역습 없는 적=atkCost만)
  - ※ 발견: 모든 동료는 atkCost 1(공격·저지 시 자기 피해) — 공식 룰 정상. 솔리드 사운드 바디(01119)는 attachStats.retaliate 1로 attachTo가 klaw.retaliate에 병합
  - 잔여: 이벤트/능력 (attack) 효과(dealDamage 등, mc_2_effects)의 Tough-적 역습은 아직 인라인 — 드물어 후순위. source가 카드(hp없음)인 melee 이벤트는 역습 대상 없음
  - 회귀 80종 그린
## v2026.07.13.200 (이번 세션 — 역습 규칙 수정)
- **★ 역습(Retaliate) 트리거 수정 — "공격받음" 기준(피해량 무관)**:
  - 사용자 지적: BP가 신분 방어로 피해 0 만들면 역습이 안 터짐 → 웹 검색으로 공식 룰 확인: **역습은 "공격받으면" 발동, 피해량과 무관**(방어로 0피해·강인 흡수·전량 방지여도 발동). 단 그 공격에서 살아남아야(hp>0) 함
  - 기존 버그: 역습이 applyDamage 인라인(피해>0)에만 있어 — (1) amount<=0 즉시 return, (2) 강인이 역습보다 먼저 early return, (3) 방어 0피해 시 applyDamage 자체 미호출 → 전부 역습 누락. 또 처치돼도 역습 발동(살아남음 미체크)
  - 수정: MC.triggerRetaliate(G, attacked, attacker) 헬퍼 분리 — 살아남음(hp>0) 체크 + 신분 인쇄 역습(히어로 폼만) 합산 + 연출 힌트 + 재보복 방지(isRetaliate). applyDamage 인라인은 헬퍼 호출로 대체(+noRetaliate 가드). resolveDefensePending은 방어자 피해에 noRetaliate 위임 후, defenderChar(무방어/신분=히어로, 동료방어=동료)에 피해량 무관하게 triggerRetaliate 1회 호출 → 중복 없음
  - 검증: tests/test_retaliate.js — 신분방어0피해/무방어/강인흡수/사망시미발동/재보복방지 5케이스
  - 회귀 80종 그린
- ※ 남은 엣지: 히어로/동료/이벤트가 강인(tough) 적을 공격 시 그 적의 역습(부착물 부여)은 applyDamage 인라인이라 강인 흡수면 여전히 누락 가능 — 드문 케이스, 필요시 공격 사이트에도 triggerRetaliate 확장

## v2026.07.13.199 (이번 세션 — 빌런 페이즈 연출 순차화)
- **★ 빌런 페이즈 "중구난방 이펙트" 근본 수정 — FX 큐 직렬화**:
  - 원인(확정): act() 훅에 ~15개 독립 연출 감지 블록이 각자 setTimeout으로 동시 발사 + maybeStepVillain이 고정 딜레이로 진행 → 스텝N 연출이 스텝N+1과 겹쳐 난무
  - 해결: 빌런 페이즈(villainStepMode)에는 MC.playVfx를 래핑해 **순차 큐(fxq)**에 넣고 하나씩 재생. 큐가 빌 때까지 maybeStepVillain 대기 → 스텝 진행이 연출 완료를 기다림
  - fxPump: 연출 1개 재생→dur 대기→다음. 공개/부스트 모달 중엔 큐 정지(모달 해소 핸들러가 fxPump 재개). FX_DUR로 연출별 길이 추정(기본 850ms, onDefeat/stageChange 등 개별)
  - _playVfxRaw는 mc_vfx.js의 정규화(el↔cardEl) 버전을 캡처 → 이중 래핑 없음. 플레이어 페이즈는 기존대로 즉시 재생(래핑은 villainStepMode 때만)
  - 흐름: endPlayerPhase(stepwise)→villainStepMode=true→각 스텝 연출 큐잉→순차 재생→큐 비면 다음 스텝→endRound에서 해제
  - 트레이드오프: 겹침 제거 위해 연출이 순서대로 재생돼 빌런 페이즈가 다소 느려짐(orderly > fast, 사용자 요구 부합). 필요시 FX_DUR 튜닝
  - 회귀 79종 그린(엔진 무변경, UI 연출 계층만). 사용자 인게임 검증 필요
- ※ 다음: 사용자 검증 후 속도감 튜닝(FX_DUR 조정) 또는 캡틴 시그니처 03003 진행

## v2026.07.13.198 (이번 세션 — 동료 공격 대상선택 + 빌런페이즈 진단)
- **★ 동료(아군) 공격 대상 선택 구현**:
  - 기존: allyAct 공격이 targetUid:G.villain.uid로 빌런 하드코딩 → 동료가 빌런만 공격
  - 엔진 allyAttack은 이미 targetUid로 빌런/하수인 아무 대상 받음(수호 하수인 교전 시 빌런공격 차단 규칙 포함) → UI만 대상선택 필요했음
  - 수정: allyAct 공격 분기 → sel={mode:'attack',allyUid,player} 대상선택 모드 진입(히어로 기본공격과 동일 UX). pickTarget attack 블록에 sel.allyUid 분기 추가 → 선택 대상에 allyAttack 디스패치
  - 검증: tests/test_ally_attack_target.js(동료→하수인·동료→빌런·수호차단)
- **★ 빌런 페이즈 순서 "중구난방" 진단(인덱스 조사 완료, 수정 대기)**:
  - 사용자 기대 순서: 방어선택→빌런공격[부스트2공개]→데미지→방어자소진(방어시만)→하수인공격→조우→조우해결
  - 조사 결과: **엔진 큐 순서는 정확**(mc_5_encounter.js:443 threat→activations[빌런act→하수인act]→dealEnc→reveal→endRound). enemyActivation도 룰북 순서(부스트 뒷면보관→방어pending→해소후 부스트공개·데미지) 정확
  - **진짜 원인: UI 연출 타이밍** — act() 훅에 fxMinionAttack(seq,120ms)·fxDamageEachHero(seq,200~900ms)·fxBoostReveal(모달) 등 독립 감지가 각자 setTimeout으로 따로 발사 → 한 스텝에 여러 개 겹치면 이펙트 난무. maybeStepVillain은 boostReveal/revealQueue만 대기, 데미지·공격 애니는 미대기
  - **수정 방향(다음)**: 빌런 페이즈 연출을 단일 순차 큐(애니 완료 대기)로 통합. 각 act 스텝의 부스트공개→데미지→소진 애니를 체인. maybeStepVillain 게이트에 애니 진행중 상태 추가. 급하게 손대면 더 엉키므로 신중히 진행 필요
- 회귀 79종 그린, 연출/대사 503건, 22샤드, index 1262장

## v2026.07.13.197 (이번 세션 — 체력바 표시 수정)
- **★ 하수인·동료·사이드스킴 체력/위협 바 미표시 수정(근본원인)**:
  - 증상: 하수인·동료·사이드스킴에 히어로 같은 체력바가 안 뜨고 작은 "HP" 태그 알약만 보임 + 실시간 감소 안 됨
  - 근본원인: .mat-slot이 flex-direction:column+align-items:center라 자식 .cbar가 내용너비로 줄어듦 → flex:1 트랙이 펼쳐질 너비가 없어 붕괴(태그만 남음)
  - 수정: .mat-slot .cbar{align-self:stretch;width:100%} → 바가 카드(슬롯) 너비만큼 늘어나 트랙이 제대로 보임. mini 바 가독성도 향상(트랙 13→16px, 폰트↑)
  - 실시간 감소: 이미 barSnapshot(하수인/동료/사이드스킴 hp·threat 추적) + animateBars(data-barkey 전환) 배선 완비 → 바가 보이게 되면서 실시간 감소도 정상 작동
- 회귀 78종 그린(CSS 전용 변경), 연출/대사 503건, 22샤드, index 1262장
- ※ 교훈: CSS flex 컨테이너의 align-items:center가 자식 바 너비를 붕괴시키는 흔한 함정
## v2026.07.13.196 (이번 세션 — 버그 수정)
- **① 조우 공개모달 타입 정규화**: 엔진은 r.type='side_scheme'(언더스코어) 쓰는데 RVX_THEME은 'sideScheme'(카멜) → 매칭 실패로 라벨이 원시 "SIDE_SCHEME"·빨간 폴백테마·👁아이콘, 사이드스킴 시작위협도 미표시. revealModalHTML에 타입 정규화({side_scheme:'sideScheme',main_scheme:'mainScheme'}) 추가 → 라벨/색상/위협 정상
- **⑤ 와칸다 포에버! 플레이어 순서 선택 구현(하드코딩 순서 제거)**:
  - 기존: prio=['vibranium-suit',...] 고정순서 자동해결(하드코딩) → 사용자가 순서 못 정함
  - 신규: BP 업그레이드를 특성(black panther)+special로 식별(카드 고유속성), 순서는 플레이어가 탭으로 선택. 1개면 자동, 2개+면 pending(wakandaOrder)
  - MC.EFFECTS.wakandaForever 재작성 + MC.resolveWakandaUpgrade 헬퍼 + ACTIONS.resolveWakandaStep + UI.wakandaTap + 업그레이드 슬롯 탭가능화 + pending 안내존
  - 검증: tests/test_wakanda_order.js(0/1/3개 분기·잘못된uid차단·하드코딩제거) + test_phase3_core 갱신(순서선택 방식)
- **②③④ 재확인(옛 빌드 이슈)**: 블랙팬서 기본공격(claws)은 히어로 기본공격이 el:toEl 전달로 이미 정상, 하수인/동료 HP·사이드스킴 위협은 edgeStats+comicBar로 이미 렌더 중. v195부터 버전스탬프 자동화로 화면=실제빌드 확인 가능 → 옛 캐시빌드 테스트였을 가능성
- 회귀 78종 그린, 연출/대사 503건, 22샤드, index 1262장
- ※ 교훈 지속: 개별 증상이 아니라 데이터→트리거→해소→표시 전 체인을 인덱스로 전수검증

## v2026.07.13.195 (이번 세션 — 빌런 등장 대사 근본수정 + 인덱스화)
- **★ 빌런 게임시작 등장 대사 침묵 버그 근본 원인 규명(인덱스 감사)**: v194 klaw kind 수정 후에도 침묵 → 체인 끝까지 추적
  - 원인1: playVillainEntrance가 vfx.entrance 없으면 early return → 대사도 막힘
  - 원인2(핵심): 등장 vfx 함수마다 앵커 키가 el/cardEl 제각각. rhino=wallBreak(cardEl)만 작동, klaw=sonicEmerge·ultron=ultronEntrance는 ctx.el을 읽는데 playVillainEntrance가 cardEl만 넘겨 → 클로·울트론 둘 다 침묵(하나씩 봤으면 놓쳤을 것)
  - 수정: playVillainEntrance가 el/cardEl 둘 다 전달 + vfx 없어도 대사는 표시 + playVfx에 ctx.el↔cardEl 정규화(이 부류 버그 원천차단)
- **★ 버전 스탬프 자동화**: UI_VER이 v2026.07.10.129에 하드코딩돼 v190~194 전부 옛 버전 표시 → 어느 빌드인지 구분불가였음. build.py가 HANDOFF 버전을 UI_VER에 자동 주입
- **★ 빌런 대사 인덱스 회귀 테스트 신설(tests/test_villain_dialogue.js)**: 전 빌런 quoteKey 전수검사 — 필수 kind(entrance/stageUp/defeat) 존재 + 잘못된 kind(enter/stageChange 등) 미사용 + 등장 vfx 함수 등록 확인. 향후 kind 오류 자동 감지
- 회귀 77종 그린, 연출/대사 503건, 22샤드, index 1262장
- ※ 교훈: 개별 증상만 고치지 말고 데이터→트리거→해소→표시 전 체인을 인덱스로 전수검증

## v2026.07.13.194 (이번 세션 — 버그 수정)
- **신분 카드 돋보기 "(룰 텍스트 없음)" 수정**: textKo 없는 71장은 거의 전부 신분 카드(능력이 fx 필드에만 있고 텍스트 미저장)
  - 신규 파일 cards/mc_cards_zzidentity_text.js — 신분 능력 한국어 룰텍스트를 def.textKo에 주입
  - 우선 실사용 12장(코어5+캡틴): 스파이더맨/피터파커·캡틴마블/캐롤·쉬헐크/제니퍼·아이언맨/토니·블랙팬서/티찰라·캡틴아메리카/스티브
  - cardDef가 CARDS 원본 참조라 textKo 주입이 돋보기(info)에 즉시 반영. 스탯은 statline 별도 표시라 능력텍스트만 기입
  - ※ 남은 신분 59장(미배선 25영웅×2 + 기타)은 각 팩 공식 텍스트 확보 후 순차 확장
- **클로 대사 미출력 수정**: 클로 대사 블록의 kind 이름 오류 — 빌런은 entrance/stageUp를 써야 하는데 klaw만 enter/stageChange 사용
  - enter→entrance, stageChange→stageUp 정정 (대사 내용은 그대로, 등장10·단계전환10·패배10·heroDefeat5·schemeComplete5)
  - 빌드HTML vm 검증으로 klaw entrance/stageUp/defeat 모두 출력 확인. rhino/ultron은 정상(entrance/stageUp)이었음
- 회귀 76종 그린, 연출/대사 503건, 22샤드(신분텍스트 파일 추가), index 1262장

## v2026.07.13.193 (이번 세션 — 버그 수정 5종)
- **① 클로 시나리오 선택 불가 수정**: MC.SCENARIOS에 klaw 항목 자체가 없었음 → 공식 클로 세트(01113 빌런/01116b 메인스킴/01118~01127 조우 30장)로 추가. VILLAIN_ROSTER klaw·ultron에 ready:true. Masters of Evil 모듈러 세트(01128~01133) 신설해 클로 기본 모듈러로 배정
- **④ 조우/사이드스킴 등장 대사 미출력 수정**: revealModalHTML이 하수인(minion)일 때만 대사 조회했음 → 전 타입 범용화(하수인=enter, 배신·사이드스킴=reveal, quoteKey 우선 defCode 폴백). 빌드HTML vm 검증으로 배신·사이드·하수인 모두 한국어 대사 출력 확인
- **⑤ 기본 공격 애니메이션 미출력(스파이더맨 외) 수정**: 히어로 vfx.basicAttack이 스파이더맨(strike)·블랙팬서(claws)·캡틴(shieldToss)만 있었음 → UI 히어로 기본공격에 범용 strike 폴백 추가(전용 연출 있으면 우선). 27영웅 전부 최소 타격 연출 보장
- **②③ 카드 돋보기 텍스트/플레이버 영어 출력 수정**: 영어 flavor 486장(한국어 91장)이 영어 원문 그대로 노출됨 → info() 돋보기에서 한국어 플레이버(textKo 인용줄 또는 한국어 def.flavor)만 표시, 영어 flavor 억제. 효과 텍스트(textKo)는 이미 한국어라 기능정보 보존
- 회귀 76종 그린, 연출/대사 503건, 21샤드, index 1262장
- ※ 남은 개선: 영어 flavor 486장 한국어 번역(선택), 영웅별 전용 기본공격 연출(선택)

## v2026.07.13.192 (이번 세션 추가분)
- **★ 03002 에이전트 13 (Agent 13) — 캡틴아메리카 시그니처 동료 첫 등록**
  - 신규 파일 cards/mc_cards_zzcap_fx.js (캡틴아메리카 시그니처 fx, mcode 순 등록 예정)
  - 동료: 비용 3·ATK 1·THW 2·HP 3·🧠멘탈 1·유니크·S.H.I.E.L.D. 셰런 카터
  - 범용 whenPlayed:runCardEffects + effects:[removeThreat amount:2] (커스텀 핸들러 회피)
  - 등장 후 스킴 하나서 위협 2 제거 — targetScheme 지정 시 사이드 스킴, 없으면 메인
  - 대사블록 agent-13(entrance 10, thwart 5), vfx entrance=tacticsInstall·basicAttack=gunshot·basicThwart=patrol
  - 검증: tests/test_agent13.js (스탯·자원·유니크·메인위협제거·사이드스킴지정)
- **★ 범용 버그 수정: runCardEffects가 ctx.targetScheme/targetPlayer/choice/targets 누락**
  - HANDLERS.runCardEffects가 효과 ctx를 {player,card,self}로만 재구성해 대상 선택값을 떨어뜨림
  - → targetScheme 등 4개 필드 전달하도록 수정. whenPlayed:runCardEffects 쓰는 모든 카드의 스킴 지정이 정상화
- 회귀 76종 그린, 연출/대사 503건, 21샤드(cap fx 추가), index 1262장
- ※ 남은 캡틴 시그니처(03003~03010) db 데이터만 존재 → 다음 작업 (mcode 순)

## v2026.07.13.191 (이번 세션 추가분)
- **★ 캡틴아메리카 신분 03001a/b 등록 (히어로 팩 mc04 시작)** — 룰시트+공식 cap.json 교차검증, audit_identities로 미배선 확인 후 작업
  - 03001a "하루 종일도 가능해!": identityAction에 신규 discardCost(손패 버림 비용) 추가 → 손패 1장 버림 → readySelf(준비). 라운드당 1회. 소진 상태서도 사용 가능
  - 03001b 리빙 레전드: 신규 livingLegend 필드 — playCard 비용할인에 "매 라운드 첫 동료 -1" 훅 추가(usedLivingLegendThisRound, 라운드 리셋). onSetup=capShieldSetup(덱/버림에서 cap-shield 03009 손에 추가+셔플)
  - 신규 VFX: shieldToss(성조기 방패 회전 투척, 기본공격), capReady(방패문양 발광+결의광선+대사, 신분액션). 대사블록 captain-america(identityAction 5, setup 3)
  - baseFields+KNOWN_META에 livingLegend 등록. discardCost는 identityAction 하위필드
  - 검증: tests/test_captain_america_identity.js (액션 준비·손패버림·라운드1회·리빙레전드 동료할인·방패셋업)
- 회귀 75종 그린, 연출/대사 498건, 20샤드, index 1262장
- ※ 캡틴아메리카 시그니처 카드(03002~03010)는 db에 데이터만 존재(fx 미등록) → 다음 작업

## v2026.07.13.190 (이번 세션 추가분)
- **★ 코어 세트 공식 프리빌트 덱 5종 (룰북 STARTER DECKS)**: cards/mc_cards_scenarios.js의 MC.PRESET_DECKS 교체
  - 스파이더맨/정의, 캡틴마블/리더십, 쉬헐크/용맹, 아이언맨/용맹, 블랙팬서/보호 — 각 40장(시그니처+아스펙트+기본11)
  - 쉬헐크·아이언맨은 용맹 아스펙트 카드 공유(룰북 명시). 프리셋 키=MC.HEROES 키 일치 검증
  - 기존 스파이더맨(보호) 1종 프리셋을 룰북 공식 5종으로 확장
  - 검증: tests/test_preset_decks.js (5종·40장·slug유효·아트코드·핵심수량·기본카드·아스펙트·셋업·용맹공유)
  - 부작용 수정: test_payment/test_phase3_core가 PRESET_DECKS.spiderman을 범용 픽스처로 결합사용 → 자체 FIXTURE_DECK로 디커플링(옛 보호 40장 구성)
- **★ 영웅 신분 중복방지 감사도구 (tools/audit_identities.js)**:
  - db(mc_cards_identities.js 카드필드)+fx(zidentity_fx.js)를 합친 cardDef 기준으로 능력 배선 여부 판정
  - 전체 요약 + `<코드>` 상세 모드. 영웅 신분 작업 전 필수 실행
  - 확정: 실제 배선 5영웅뿐(스파이더맨·캡틴마블·쉬헐크·아이언맨·블랙팬서), 26영웅 미배선
  - 스파이더맨 중복작업 사고 롤백: db에 이미 attackInterrupt=spiderSense/resourceAbility=scientist 배선됨을 audit로 확인, 중복 훅 전부 제거
- 회귀 74종 그린, 연출/대사 497건, 20샤드, index 1262장

## v2026.07.13.189 (이번 세션 추가분)
- **표준 인카운터 세트 완결 (01186~192)**: Advance·Assault·Caught Off Guard·Gang-Up·Shadow of the Past·Exhaustion·Masterplan 7종 전부 등록
- **★ 넴시스 셋어사이드 시스템 신설 (Shadow of the Past 01190)**:
  - `MC.NEMESIS_SETS`(5세트: blackPanther/sheHulk/spiderMan/ironMan/captainMarvel) + `MC.NEMESIS_BY_HERO`(영웅 앞/뒷면 코드→세트 매핑) — cards/mc_cards_scenarios.js
  - setupGame 시 각 플레이어의 넴시스 하수인·사이드스킴·나머지를 `pl.nemesisSetAside`에 준비 (obligation은 별도 조우덱 셔플)
  - 신규 EFFECTS.revealNemesisSet: 하수인 교전 투입 + 사이드스킴 공개 + 나머지 조우덱 셔플, 이미 전장 시 재투입 방지
  - 신규 cond nemesisMinionNotEntered: 하수인 미등장 시 surge
  - 검증: 5영웅 각 셋어사이드 5장 정확 구성 + 킬몽거/왕좌찬탈 투입 + 이미 전장 시 surge
- **01191 Exhaustion**: surge + 신규 EFFECTS.exhaustIdentity(신분 소진). db mcode 01191 채움. 연출 exhaustionReveal(무기력), 대사 5
- **01192 Masterplan**: 각 사이드 스킴 위협 4(placeThreat eachSide 재사용) / 없으면 신규 EFFECTS.discardUntilSideScheme(조우덱 탐색·공개). 신규 cond noSideSchemesInPlay/anySideSchemeInPlay. db mcode 01192 채움. 연출 masterplanReveal(톱니바퀴 음모), 대사 5
- 회귀 73종 그린, 연출/대사 497건, 20샤드

## v2026.07.13.188 (이번 세션 추가분)
- **M.O.D.O.K. 모듈러 세트 완성(01183~185)** — cards/mc_cards_zzmodok_fx.js (신규 파일):
  - 01183 The Doomsday Chair(사이드 스킴 ×2, 가속): M.O.D.O.K. 소환. summonNamedMinionIfAbsent 재사용(Legions of Hydra 자산이 타 세트에도 그대로 통함). 시작 위협 8. 연출 doomsdayChairReveal/Cleared
  - 01184 M.O.D.O.K.(하수인 ATK2/SCH2/HP8): Retaliate 2(db 자동). 하수인 대사 15개. 연출 modokEntrance/Attack/Defeat(사이오닉)
  - 01185 Biomechanical Upgrades(부착 ×3, 급증): 최대 HP 하수인 부착(중복 불가) + 부활 방패. 신규 `reviveOnDefeat`(applyDamage 처치 판정에 인터셉트 — HP 전량 회복 후 부착물 버림) + attachToHighestHpMinion에 `excludeSameAttachment` 옵션. 연출 biomechUpgradesReveal/Revive
- **표준 인카운터 세트(01186~187)** — cards/mc_cards_zzstandard_fx.js (신규 파일):
  - 01186 Advance(배신 ×2): 빌런 암약(villainSchemes 재사용)
  - 01187 Assault(배신 ×2): 알터에고=surge / 히어로=빌런 공격(isHeroForm/isAlterEgoForm + villainAttacks)
- **★ 모듈러 인카운터 세트 선택 UI 추가** — ui/mc_ui.js:
  - 빌런 선택 화면(STEP 2)에 renderModularPanel 신설: 3모드(권장/랜덤/직접). 랜덤=1~3세트 무작위 + 🎲다시뽑기, 직접=4세트 자유 조합(폭탄위협/히드라군단/M.O.D.O.K./기습공격)
  - APP.modularMode/modularPick/modularRandomN/modularRandomKeys 상태 + 핸들러(modularMode/modularRandomN/rerollModular/toggleModular)
  - **잠재 버그 수정**: startGame이 옛 `scen.encounter`(undefined→크래시)를 읽던 것을 `MC.buildEncounter(scenarioKey, modularKeys)`로 교체. 같은 패턴 쓰던 테스트 3종(payment/phase3/ultron)도 buildEncounter로 수정
- 재사용 자산: reviveOnDefeat / attachToHighestHpMinion(excludeSameAttachment) / summonNamedMinionIfAbsent(타 세트 재사용 입증)
- KNOWN_META += reviveOnDefeat, onRevive, onReviveEffects
- 테스트 4종 신설, 전체 69종 그린 · 연출/대사 487건 · 20샤드
- 다음: 01188~ mcode 순 (표준 세트 나머지? 확인 필요)

## v2026.07.13.187 (이번 세션 추가분)
- **Legions of Hydra 모듈러 인카운터 세트 완성(01180~182)** — cards/mc_cards_zzhydra_fx.js (신규 파일, 18샤드):
  - 01180 Legions of Hydra(사이드 스킴 ×2, Hazard): 마담 히드라 소환(부재 시)+히드라 적 수×2 위협. 신규 `summonNamedMinionIfAbsent`{code}+`placeThreatPerEnemyTrait`{trait,mult}. searchMinionIntoPlay에 codeFilter 지원 추가(조우덱/버림 없으면 정의로 생성). 연출 legionsOfHydraReveal/Cleared
  - 01181 마담 히드라(하수인 ATK2/SCH2/HP6): ① Legions of Hydra 존재 시 피해 면역(신규 `invulnWhileScheme`, applyDamage 0.6단계 가드) ② Forced Response(스킴/공격 후 Legions에 위협 +2, forcedResponseEffects 재사용). 하수인 대사 enter/attack/defeat 각5+forced 5. 연출 4종
  - 01182 하이드라 솔저(하수인 ×3): Guard(db) + 처치 시 교전 플레이어 조우카드 1장(신규 `dealEncounterToEngaged`). **중복 등록 해소**: hydra-soldier와 hydra-soldier-loh 둘 다 mcode 01182(같은 카드)라 동일 FX 등록. hydra-soldier-patrol은 mcode 04153으로 별개 유지. 연출 3종
- 재사용 자산: summonNamedMinionIfAbsent / placeThreatPerEnemyTrait / invulnWhileScheme / dealEncounterToEngaged / searchMinionIntoPlay(codeFilter)
- KNOWN_META += invulnWhileScheme
- 테스트 3종 신설, 전체 65종 그린 · 연출/대사 473건
- 중복 백로그 갱신: 01182 완료(hydra-soldier/loh 통합). 남은 백로그=01120 armored-guard, 01143 advanced-drone 등
- 다음: 01183 The Doomsday Chair(사이드 스킴)·01184 M.O.D.O.K.(하수인) — mcode 순 계속

## v2026.07.13.186 (이번 세션 추가분)
- **욘-로그(캡틴 마블/캐롤 댄버스) 넴시스 세트 완성(01175~179)** — cards/mc_cards_zzyonrogg_fx.js:
  - 01177 욘-로그(하수인 ATK3/SCH2/HP5): Forced Response(공격 후 사이키-마그니트론 위협 +1). 데이터 기반 `forcedResponseEffects` 배열 지원(mc_5_encounter 확장) + placeThreat `scheme:'namedSide'`{slug} 신설. 하수인 대사 enter/attack/defeat 각5+forced 5. 연출 yonRoggEntrance/Attack/Defeat/ForcedResponse
  - 01178 크리 조종자(배신 ×2, 부스트★): 메인 위협 +1 + surge. 부스트★도 메인 +1. 기존 이펙트 재사용. 연출 kreeManipulatorReveal
  - 01179 욘-로그의 반역(배신): 손패 자원 카드 전체 버림, 없으면 surge. 신규 `EFFECTS.discardAllResourcesFromHand` + cond `treasonDiscardedNone`. ★규칙정정: marvelcdb 웹 확인 "each resource"(모든 자원, energy 한정 아님) 확정. 연출 yonRoggsTreasonReveal
- 재사용 자산: forcedResponseEffects(데이터 기반 강제반응) / placeThreat namedSide / discardAllResourcesFromHand / cond treasonDiscardedNone
- KNOWN_META += forcedResponseEffects
- 테스트 3종 신설, 전체 62종 그린 · 연출/대사 456건 · 17샤드
- 다음: 01180~ mcode 순(Legions of Hydra 모듈러? 확인 필요)

## v2026.07.13.185 (이번 세션 추가분)
- **위플래시(아이언맨/토니 스타크) 넴시스 세트 완성(01170~174)** — cards/mc_cards_zzwhiplash_fx.js:
  - 01172 위플래시(하수인 ATK3/SCH2/HP4): Retaliate 1(db 필드로 applyDamage 자동 처리). 하수인 대사 enter/attack/defeat 각5(이반 반코 복수 톤). 연출 whiplashEntrance/Attack/Defeat(전기 채찍)
  - 01173 전기 채찍 공격(배신 ×2, 부스트★): 택1 — 통제 업그레이드 수만큼 피해 / 업그레이드 1장 버림. 신규 `amountFrom:'upgradeCount'`(dealDamage) + discardControlledUpgrade 재사용. 부스트★=업그레이드 버림. 연출 electricWhipStrike
  - 01174 전자기 반발(배신): 각 플레이어 덱 top 5장 버림→에너지(⚡) 자원 수만큼 피해. 신규 `EFFECTS.discardTopEnergyDamage`(count param, resources.energy 합산). 연출 electromagneticBacklashReveal
- 재사용 자산: amountFrom:'upgradeCount' / discardTopEnergyDamage / exhaustAllUpgrades(01170)
- 테스트 3종 신설, 전체 57종 그린 · 연출/대사 442건
- 주의: 플레이어 덱 top=pop(). retaliate는 opt.source.hp!==undefined면 발동(byAttack 무관). 카드 자원은 d.resources 객체
- 다음: 01175~ mcode 순(다음 영웅 넴시스 세트)

## v2026.07.13.184 (이번 세션 추가분)
- **벌처(스파이더맨/피터 파커) 넴시스 세트 완성(01165~169)** — cards/mc_cards_zzvulture_fx.js:
  - 01167 벌처(하수인 ATK3/SCH1/HP4): Quickstrike(교전 즉시 공격). 판정을 def 기반으로 수정(inst.quickstrike||cardDef.quickstrike) + enemyAtk 적용(mc_5_encounter). 하수인 대사 enter/attack/defeat 각5. 연출 vultureEntrance(급강하)/Attack/Defeat
  - 01168 급강하 습격(배신 ×2, 부스트★): 히어로 기절 + 벌처 전장 시 급증. 신규 cond `enemyInPlay`{slug}(특정 하수인/빌런 생존 판정). 부스트★=`setBoostStunOnDamage` 플래그. 연출 sweepingSwoopStrike(급강하+기절별)
  - 01169 벌처의 계략(배신): 각 손패 무작위 1장 버림→서로 다른 자원 종류 수만큼 메인 위협. 신규 `EFFECTS.discardRandomCountResources`(카드 resources 객체의 physical/mental/energy/wild 종류 집계). 연출 vulturesPlansReveal(4색 자원 흩어짐)
- 재사용 자산: cond enemyInPlay / discardRandomCountResources / setBoostStunOnDamage / quickstrike def기반+enemyAtk
- 테스트 3종 신설, 전체 52종 그린 · 연출/대사 428건
- 주의: 카드 자원은 d.resources 객체({physical:1} 등). quickstrike는 def 기반 판정(defineCardFx 병합분 인식)
- 다음: 01170~ mcode 순(다음 영웅 넴시스 세트)

## v2026.07.13.183 (이번 세션 추가분)
- **벌처(스파이더맨/피터 파커) 넴시스 진입(01165~166)** — 새 파일 cards/mc_cards_zzvulture_fx.js:
  - 01165 퇴거 통지(obligation): 택1 — 피터 파커 소진→게임제거 / 손패 무작위 1장 버림+surge→의무 버림. 기존 discardFromHand+surge 재사용. 연출 evictionNoticeResolve/Defer
  - 01166 노상 강도(사이드 스킴, 가속): 각 플레이어 손패 무작위 1장 뒷면 보관→처치 시 소유자 반환. 신규 `EFFECTS.storeRandomFromEachHand`(inst.storedCards, _storedOwner 기록) + `returnStoredCards`. accelIcons 1. 연출 highwayRobberyReveal(강탈 흡입)/Cleared(회수)
- **보관 카드 UI 표시**: 사이드 스킴 토큰 영역에 `🃏 보관×N` 배지(mc_ui.js schemeTokensHTML, token-stored CSS). 툴팁으로 장수+소유자 표시. 뒷면이라 내용은 숨김
- 재사용 자산: storeRandomFromEachHand+returnStoredCards(카드 보관/반환 시스템)
- 테스트 2종 신설, 전체 49종 그린 · 연출/대사 418건 · 15샤드
- 주의: 무작위는 MC.rand(G). 보관 카드는 inst.storedCards 배열(card._storedOwner로 소유자 추적)
- 다음: 01167 벌처(하수인)~ mcode 순

## v2026.07.13.182 (이번 세션 추가분)
- **쉬헐크(제니퍼 월터스) 넴시스 세트 완성(01160~164)** — cards/mc_cards_zzsh_fx.js:
  - 01162 타이타니아(하수인 ATK X=현재HP/SCH1/HP6): 동적 ATK. 신규 헬퍼 `MC.enemyAtk(enemy)`(atkEqualsHp면 현재 hp 반환). 하수인 공격 3곳(mc_5_encounter 352·601·844행)을 MC.enemyAtk로 통일. 하수인 대사 enter/attack/defeat 각5. 연출 titaniaEntrance/Attack/Defeat
  - 01163 유전자 강화(부착): 최고 인쇄HP 하수인에 부착→HP+3, 없으면 surge. 신규 `EFFECTS.attachToHighestHpMinion`{surgeIfNone} + `attachStats:{hp:3,maxHp:3}`(attachTo 자동 적용). 타이타니아 강화 시 동적 ATK도 상승. 연출 geneticEnhanceReveal(DNA나선)
  - 01164 타이타니아의 분노(배신 ×2, 부스트★): 전장 타이타니아가 히어로 공격(동적 ATK), 부재/기절이면 완전회복+surge. 신규 `EFFECTS.titaniaFury` + `addVillainBoostCard`(G._extraBoostThisActivation). 연출 titaniasFuryAttack(격노 3연 임팩트)
- 재사용 자산: MC.enemyAtk(동적 ATK 헬퍼) / attachToHighestHpMinion+attachStats(hp,maxHp) / titaniaFury / addVillainBoostCard
- 테스트 3종 신설, 전체 47종 그린 · 연출/대사 414건
- 주의: 하수인 동적 ATK는 MC.enemyAtk로 조회(attacker.attack 직접 참조 금지). attachStats는 attachTo가 target[k]+=값 자동 적용, detachFrom 원복
- 다음: 01165~ mcode 순(다음 영웅 넴시스 세트)

## v2026.07.13.181 (이번 세션 추가분)
- **블랙 팬서 넴시스 세트 완성**: 01159 의식 결투(배신 ×2) — 조우덱 top 버림→X=부스트+1→히어로 X피해/메인 위협 X 선택. 신규 `EFFECTS.discardEncounterComputeX`(G._ritualX) + `amountFrom:'ritualX'`(dealDamage/placeThreat 확장). 연출 ritualCombatStrike/Scheme
  → 블랙팬서 넴시스 01155~159 전체 완결(cards/mc_cards_zzbp_fx.js)
- **쉬헐크(제니퍼 월터스) 넴시스 진입**: 새 파일 cards/mc_cards_zzsh_fx.js
  - 01160 법률 업무(obligation): 택1 — 제니퍼 소진→게임제거 / 메인 스킴 가속토큰+1→의무 버림. 신규 `EFFECTS.addAcceleration`(G.acceleration 전역 누적). 연출 legalWorkResolve(법봉)/Defer(서류)
  - 01161 개인적 도전(사이드 스킴, Crisis): 시작위협 3고정+공개시 +1/인. Crisis=메인 위협 제거 봉쇄. `crisis:true` 필드(defineCardFx 병합)→hasCrisisScheme 인식. EFFECTS.removeThreat에 crisis 가드 추가(ignoreCrisis 예외). 연출 personalChallengeReveal(위기 경고링)/Cleared. 타이타니아 원한 테마 대사
- 재사용 자산: discardEncounterComputeX+amountFrom:'ritualX' / addAcceleration / removeThreat crisis 가드
- 테스트 3종 신설, 전체 44종 그린 · 연출/대사 404건 · 14샤드
- 주의: 가속 토큰=G.acceleration 전역(빌런 페이즈 위협 accelGain=accelIcons+G.acceleration). crisis 판정=def.crisis+threat>0
- 다음: 01162~ mcode 순(쉬헐크 넴시스 나머지)

## v2026.07.13.180 (이번 세션)
- **블랙 팬서(티찰라) 넴시스 세트(01155~158)** — 새 파일 cards/mc_cards_zzbp_fx.js:
  - 01155 국정의 의무(obligation): 택1 — 티찰라 소진→게임제거 / 블랙팬서 업그레이드 버림→의무 버림. 신규 `EFFECTS.discardControlledUpgrade`+`resolveObligation`(obligation 최초 실동작, 기존 offerChoice 재사용)
  - 01156 왕좌 찬탈(사이드 스킴): 지속효과 알터에고 전환 봉쇄 `blocksAlterEgoFlip`(flipForm 가드, 강제전환도 차단·복귀는 허용). base_threat 3/인
  - 01157 킬몽거(하수인 ATK2/SCH2/HP5): 블랙팬서 업그레이드 피해 면역 `immuneToUpgradeDamage`(applyDamage 가드, def기반). db HP4→5 정정. 하수인 대사 enter/attack/defeat 각5
  - 01158 심장 모양 허브(배신, Surge): 빌런+교전하수인 tough 부여. 신규 `EFFECTS.grantTough`(scope villain/villainAndEngaged). 부스트★=빌런만
- 연출: affairsOfStateResolve/Defer, usurpThroneReveal/Cleared, killmongerEntrance/Attack/Defeat, heartHerbReveal · 대사 다수
- 주의: 하수인 대사는 quoteKey 없이 defCode 자체가 키(enter/attack/defeat 각5). quoteKey 넣으면 빌런 규칙(10개) 걸림
- 주의: surge는 pendingSurge 아니라 ctx.self.surge 플래그
- 테스트 4종 신설, 전체 41종 그린 · 연출/대사 398건
- 다음: 01159~ mcode 순. 코어셋 시나리오(라이노/클로/울트론)+Under Attack 모듈러+블랙팬서 넴시스 완성 상태

## v2026.07.13.179 (이번 세션)
- **Under Attack 모듈러 세트(01151~154)** — 새 파일 cards/mc_cards_zzunder_fx.js:
  - 01151 공격 받는 중(사이드 스킴): 각 플레이어 선택(위협2 or 히어로 피해3). 신규 `EFFECTS.eachPlayerChoice` + `flushEachChoice`(각 플레이어 순차 선택 체인, resolveRevealChoice 배선). 시작위협 3(고정)
  - 01152 비브라늄 갑옷(빌런 부착): 피해 후 tough 재생성 `grantsToughOnDamage`(applyDamage 처치판정 else 배선, 생존 시만) + 소진+💪💪 제거
  - 01153 충격파 블라스터(빌런 부착): retaliate 1 부여 `attachStats.retaliate`(기존 보복 시스템 재사용) + 소진+⚡⚡ 제거
  - 01154 충격파 폭발(배신 ×2): 광역 피해. resolveTarget `allFriendly`(모든 히어로+동료)/`controlled`(활성 플레이어 히어로+동료). 부스트★=boostStarEffects(controlled)
- KNOWN_META += grantsToughOnDamage, retaliate / resolveTarget += allFriendly, controlled
- 연출: underAttackReveal/Cleared, vibraniumArmorInstall/Retough, concussionBlastersInstall/Retaliate, concussiveBlast · 대사 5종 세트
- 테스트 3종 신설, 전체 37종 그린 · 연출/대사 386건
- 다음: 01155~ 블랙 팬서 영웅 카드군 (obligation/신분/시그니처). 클로+라이노+울트론 시나리오 + Under Attack 모듈러 완성 상태

## v2026.07.13.178 (이번 세션)
- **울트론 메인 스킴 3단계(01137/138/139)** seed 등록 + 엔진:
  - 01137 크림슨 카울: 1A 셋업=울트론 드론 환경 배치(HANDLERS.ultronSetup) · 1B 임계 3/인 · 공개 시 각 플레이어 드론(whenRevealed runCardEffects+spawnDrone eachPlayer)
  - 01138 노라드 습격: 2B 임계 10/인 · `forcedThreatChoice`(빌런 페이즈 위협 후 각 플레이어 선택: 위협2 or 드론 — flushThreatChoice 체인, resolveRevealChoice가 다음 플레이어로 이어감)
  - 01139 파멸의 카운트다운: 3B 임계 5/인 · `threatCannotRemove`(removeThreat 가드) · 완성 시 패배(nextStage 없음)
- **공식 필드 검증**: main scheme threat=maxThreatPerPlayer, escalation_threat=1(인원당 기본상승, baseGain 반영), base_threat_fixed 없음=per player. 원본 대조 확인
- **MC.SCENARIOS.ultron**: villainStart 01134, mainScheme 01137b, 울트론 조우 세트(android-efficiency×3 등)+표준. 셋업 시 드론 환경 자동 배치
- 메인 스킴 대사(ultron-scheme: crimson/norad/countdown 각 5) + 연출 ultronSchemeAdvance. 빌런 연출 4종 + 메인 연출
- baseFields += forcedThreatChoice, threatCannotRemove
- 테스트 test_ultron_mainscheme(셋업/진행 1B→2B→3B/제거불가/패배/강제반응), 전체 34종 그린 · 380건
- **★ 울트론 시나리오 전체 플레이 가능**: 빌런 3스테이지 + 메인 3단계 + 조우 세트(01140~150) + 드론 서브시스템 완비
- 다음: 01151~ mcode 순 (모듈러 인카운터/영웅 카드 등). 클로+라이노+울트론 3개 시나리오 완성 상태

## v2026.07.13.177 (이번 세션)
- **순서 정정**: 01133 다음 01134~01139(울트론 시나리오 본체)를 건너뛰고 조우 카드부터 했던 것 → 빠진 빌런 본체부터 순서대로 채움
- **울트론 빌런 3스테이지(01134/135/136)** seed 스탯 등록 + 강제효과 엔진 배선:
  - 01134 울트론 I (HP17/인 ATK2 SCH1): `forcedAttackChoice`(공격 후 선택 pending: 메인 위협1 or 드론 스폰) — resolveDefensePending 끝에서 revealChoice pending
  - 01135 울트론 II (HP22/인 ATK2 SCH2): `villainAttackSpawnDrone`(공격 시 드론 증원) + `attackBonusPerDrone`(교전 드론당 ATK+1) — enemyActivation 빌런 공격부
  - 01136 울트론 III (HP27/인 ATK4 SCH2): `invulnWhileDrone`(드론 있으면 빌런 피해 무효 — applyDamage 진입부) + `droneBuffVillain`(드론 전역 ATK/HP+1 — droneBaseStats 합산) + whenRevealed=ultronStage3Reveal(울트론의 명령 사이드 스킴 탐색)
- 빌런 대사 세트 40개(entrance/stageUp/defeat 각 10 + heroDefeat/schemeComplete 각 5) quoteKey:'ultron' 공유 · 연출 4종(ultronEntrance/ultronAttack/ultronStageChange/ultronDefeat)
- KNOWN_META += forcedAttackChoice, villainAttackSpawnDrone, attackBonusPerDrone, droneBuffVillain, invulnWhileDrone
- 테스트 test_ultron_villain(스탯/선택/드론+ATK/무적/버프/탐색/전환), 전체 33종 그린 · 연출/대사 377건
- 다음: 01137 The Crimson Cowl(메인1, 셋업=울트론 드론 환경 배치) → 01138 Assault on NORAD(메인2) → 01139 Countdown to Oblivion(메인3, 완성 시 패배) + MC.SCENARIOS.ultron 정의 → 울트론 시나리오 플레이 가능

## v2026.07.13.176 (이번 세션)
- **01148 드론 공장** — 사이드 스킴. 각 플레이어 드론 스폰 + 전장 Drone 수만큼 이곳 위협. 신규 placeThreat `perDroneInPlay`. 시작위협 4(고정, base_threat_fixed=True 원본 확인) + 가속1. 연출 droneFactoryActivate/Shutdown
- **01149 침습 AI** — 사이드 스킴, Hazard. 각 플레이어 덱 3장 밀링. discardTopDeck `scope:'eachPlayer'` 확장. 시작위협 3/인(per player). 연출 invasiveAiActivate/Shutdown(데이터 스트림)
- **01150 울트론의 명령** — 사이드 스킴, Hazard. 첫 플레이어 드론 2체 스폰. spawnDrone `scope:'firstPlayer'` + `count` 확장. 시작위협 2/인. 연출 hiveImperative/hiveDisconnect(지휘망)
- **검증 정확성**: 사이드 스킴 base_threat_fixed 원본 필드 확인 — 01148=고정4 / 01149=3인 / 01150=2인. preflight의 threat_fixed는 잘못된 키명(정답 base_threat_fixed)
- 각 사이드 스킴 완성(whenCompleted) 연출 + reveal/complete 대사 각 5 (빌런 사이드 스킴 테마 대사 원칙)
- 테스트 3종 신설, 전체 32종 그린 · 연출/대사 362건
- **울트론 조우 세트(01140~01150) 완결**: 드론 환경/부착/배신/사이드스킴 전부 · 드론 서브시스템 완비
- 다음: 01151~ mcode 순. 울트론 빌런 본체(01134~01139)는 db 미등록 → 시나리오 인프라 구축 시 별도 진행

## v2026.07.13.175 (이번 세션)
- **01146 수리 시퀀스** — 교전 드론 비례 빌런 회복. 신규: healVillain `perEngagedDrone`(활성 플레이어 교전 Drone 1명당 회복량), `boostStarEffects`(파라미터형 무조건 부스트★ — 단일 fx명 방식으로 표현 못 하는 데이터 효과용). whenRevealed 2/드론(회복0이면 surge, cond healedNone 분기) · 부스트★ 1/드론. 연출 ultronRepair/ultronRepairFail, 대사 heal/fail 각 5
- **01147 군집 공격** — 교전 드론 일제 공격, 없으면 드론 증원. minionsAttack 공용 인덱스에 `scope:'activePlayer'`(혼돈의 지배=allPlayers 기본 유지) + `fallback:'spawnDrone'` 확장만으로 구현(혼돈의 지배 회귀 무손상 확인). 연출 droneSwarmAttack/droneConversion 재사용, 대사 attack/reinforce 각 5
- KNOWN_META += boostStarEffects
- 테스트 2종 신설(test_repair_sequence/test_swarm_attack), 전체 29종 그린 · 연출/대사 356건
- 다음: 01148 drone-factory(사이드 스킴) → 01149 invasive-ai → 01150 ultrons-imperative (울트론 세트 마무리)

## v2026.07.13.174 (이번 세션)
- **01144a 안드로이드 효율** — whenRevealed=각 플레이어 뒷면 드론 스폰(EFFECTS.spawnDrone scope eachPlayer/activePlayer, 환경 있으면 그 스탯·없으면 fallback). 부스트★=선택(자원1 지불 OR 드론): 부스트 공개는 방어/암약 해소 도중이라 즉시 pending 불가 → **deferred**(boostStarChoice → flushDeferredBoostChoice, 공격/암약 종료 후 pending 세움, 자원 없으면 자동 드론). resolveRevealChoice(payIcons) 재사용. 연출 droneConversion, 대사 reveal/boost 각 5
- **01145 울트론의 분노** — 폼분기 배신. 알터에고=울트론 암약(villainSchemes 위협 캡처 G._lastThreatPlaced) → 놓인 위협만큼 밀링(EFFECTS.discardTopDeck amountFrom:'lastThreatPlaced'). 히어로=울트론 공격(villainAttacks discardDeckPerDamage) → 방어 해소 시 준 피해만큼 밀링. MC.discardTopOfDeck(리셔플 포함 밀링 헬퍼) 신설. 연출 ultronRageScheme/ultronRageAttack, 대사 scheme/attack 각 5
- KNOWN_META += boostStarChoice
- 테스트 2종 신설(test_android_efficiency/test_rage_of_ultron), 전체 27종 그린 · 연출/대사 353건
- 다음: 01146 repair-sequence → 01147 swarm-attack → 01148 drone-factory → 01149 invasive-ai → 01150 ultrons-imperative (울트론 세트 마무리). swarm-attack은 spawnDrone/minionsAttack 재사용 예상

## v2026.07.13.173 (이번 세션)
- **01128 악의 지배자들** — discardUntilMinion 인덱스 + mastersAssemble/mastersScatter 연출, 대사 10종
- **01133 혼돈의 지배** — 신규 범용: `EFFECTS.minionsAttack`(trait/fallback:'searchEngage'), `MC.startMinionAttackChain`(attackChain 순차 방어 pending, 기절 소모·사망 스킵), `MC.searchMinionIntoPlay`(덱+버림 탐색 교전+셔플), cond `minionsAttacked` — 분기별 연출(mastersOnslaught/mayhem ↔ mastersAssemble/reinforce 각 5)
- **엔진 버그픽스**: `revealPendingEncounters`가 공개 중 pending 발생 시 루프 정지+reveal 재큐 (배신의 방어 pending을 다음 공개가 덮어쓰던 잠재 버그)
- **01141 프로그램 전송기** — 신규 범용: `boostStarOnScheme`(암약 부스트 조건부 — resolveBoostStar에 actKind 'attack'|'scheme' 인자, 호출부 3곳), `placeThreat scheme:'eachSide'`, `removeAbility.exhaustHero`(소진 비용 없는 부착물은 소진 상태에서도 제거 가능하게 완화). attachStats{scheme:1}. transmitterInstall/transmitterPulse 연출, 대사 attach/signal 각 5 (울트론 톤 웹 검색 확정)
- **드론 서브시스템 (01142 선행 인프라, 범용)**:
  - `G.environments` 신설 — 환경 카드 전장 유지(resolveEncounterCard case 'environment'), allInPlay/removeEnemyAttachment hosts 포함
  - 부착 라우팅: `attachTarget:'<env-slug>'` → 그 환경에 부착, 부재 시 불발 버림
  - `MC.spawnFacedownDrone(G,pl)` — 덱 맨 위 카드 뒷면 드론화(교전), `MC.recalcDroneStats` — droneStats(환경)+droneStatBonus(부착) 합산, 피해 보존·HP 상한 하락 즉사
  - onDefeated isDrone 분기: 뒷면 카드 → 소유자 버림 더미 (토큰 소멸)
  - 유사카드 'facedown-drone' 등록 (하수인 관례: defCode 키 대사 enter/attack/defeat 각 5, quoteKey 필드 금지 — vfx_index가 defeat를 빌런 10개 규칙으로 오판)
- **01142 업그레이드 드론** — attachTarget:'ultron-drones' + droneStatBonus{attack:1,hp:1} + removeAbility(⚡🧠💪). 01140 울트론 드론 환경 stub → droneStats 기계화 승격. 연출 droneHiveDeploy/droneUpgrade/droneSwarmAttack, 대사 reveal/upgrade 각 5
- KNOWN_META += boostStarOnScheme, droneStats, droneStatBonus
- 테스트 4종 신설(test_masters_of_mayhem/test_program_transmitter/test_upgraded_drones + 01128), 전체 25종 그린
- 다음: 01144a android-efficiency → 01145 rage-of-ultron(드론 스폰 예상 — spawnFacedownDrone 재사용) → … → 01150. 울트론 빌런 01134~01139는 db 미등록(시나리오 구축 시 별도)

## v2026.07.12.172 (이번 세션)
- 클로 메인 스킴 01116a/b·01117a/b 등록 완료 (지하 유통망 1A/1B/2A/2B)
- 엔진 공용 헬퍼 신설(mc_5_encounter.js): `MC.revealSpecificSideScheme`(미발견 시 인스턴스 생성 폴백 포함), `MC.discardUntilMinionIntoPlay`(traitFilter 지원 — 01128 재사용 대비)
- setupGame: 메인 스킴 onSetup + whenRevealed 발화 / advanceMainScheme: 새 단계 whenRevealed 발화
- 핸들러: `undergroundDistributionSetup`(방어망 공개), `klawMainMinion`(하수인 탐색 교전 배치), 범용 `sideSchemeRevealThreatPerHero`(01125/01126 재사용)
- defense-network 텍스트 공식 정정 + whenRevealed 연결
- **충돌 해소**: zzrhino_fx.js의 자체 `revealSpecificSideScheme` 정의 제거 → 엔진 헬퍼로 통일 (공개가 resolveEncounterCard 정식 파이프라인 경유 — whenRevealed·인터럽트 정지점 정상화)
- 테스트: test_klaw_scheme.js 신설(셋업 방어망/1B 하수인/단계 전환/2B 패배), phase3 라이노·클로 테스트를 신 파이프라인에 맞게 갱신 — 회귀 전체 통과
- 다음: 01118 Sonic Converter부터 mcode 순차 등록, MC.SCENARIOS.klaw 정의

## v2026.07.12.172 (이번 세션)
- **01118 소닉 컨버터(Sonic Converter)** 등록 — 클로 부착 무기
  - attachStats {attack:1} (클로 ATK +1) / quoteKey 'klaw-sonic-converter'(부착 대사 5개)
  - 신규 엔진 훅 `attackDamagedResponse` (baseFields·test_index HOOK_FIELDS 등록): 공격자(빌런/하수인)가 공격하여 실제 피해를 준 후 부착물 강제반응 발화. 공격 해소부에서 dmgTarget/dmgDone 추적 도입
  - 핸들러 `sonicConverterInstall`(장착 연출), `sonicConverterStun`(피해 대상 기절)
  - VFX 신규: `sonicWeaponForge`(무기 결정화 장착), `sonicStunPulse`(관통 음파 기절 펄스)
  - 테스트: tests/test_klaw_sonic_converter.js (부착 ATK+1 / 공격+피해 후 기절 / 전량 방지 시 미기절 / 해제 원복) — 회귀 전체 통과, 연출·대사 316건
- 다음: 01119 Solid-Sound Body(부착 retaliate 1) → 01120 Armored Guard(하수인) 순차

## v2026.07.12.172 (이번 세션)
- **01119 솔리드 사운드 바디(Solid-Sound Body)** 등록 — 클로 부착, 클로 반격(Retaliate) 1 획득
  - `attachStats:{retaliate:1}` — 엔진 변경 없이 target.retaliate에 합산 → applyDamage가 자동 처리
  - 엔진: applyDamage 보복 블록에 빌런/하수인 부착물 반격 연출 배선(범용) — 부착물 vfx.retaliate 힌트(sonicRetaliate)를 fxRetaliate로 세팅
  - 핸들러 `solidSoundBodyInstall`(장착 연출) / VFX 신규 `sonicBodyHarden`(음파 신체 결정화), `sonicRetaliate`(반격 음파 펄스)
  - 부착 대사 5개(klaw-solid-sound)
  - 테스트: tests/test_klaw_solid_sound.js (부착 반격+1 / 공격 시 반격 1피해+연출 / 재보복 미발동 / 해제 원복) — 회귀 전체 통과, 연출·대사 319건
- 다음: 01120 Armored Guard(하수인 1/0/3 Guard+Toughness) — 하수인 필수 구성(등장/공격/패배 대사 각 5개 + 공격 애니) 착수

## v2026.07.12.172 (이번 세션)
- **01120 아머드 가드(Armored Guard)** 하수인 등록 — 클로 세트 ×3장, ATK1/SCH0/HP3
  - Guard(교전 중 빌런 공격 차단) + Toughness(등장 시 tough) — 둘 다 데이터(guard/toughness true)만으로 자동 작동. makeInstance가 tough 부여, hasGuardEngaged가 공격 차단 배선
  - 웹 검색으로 테마 확정: 클로 고용 중갑 용병 경비병(Mercenary), "지연시키는 방벽" 역할
  - 하수인 필수 4요소: 등장/공격/패배 대사 각 5개(QUOTES['01120']) + 공격 전용 연출 VFX.armoredGuardStrike(방패 돌진·강타·CLANG)
  - 회귀 전체 통과(하수인 대사 세트 검증 포함), 연출·대사 323건
  - ※ 작업 중 str_replace가 인접 함수 선언(VFX.hornGrow) 삭제한 문법 오류 발생 → 복구. 교훈: 함수 경계를 old_str로 잡을 때 선언부 보존 주의
- 다음: 01121 Weapons Runner(하수인 1/1/2, Surge + ★배치 ×2) — 부스트★로 전장 배치되는 하수인

## v2026.07.12.172 (이번 세션)
- **01121 웨폰스 러너(Weapons Runner)** — 사용자 지적으로 발견: 카드 데이터는 이미 코드 'weapons-runner'(이름 "무기 밀반출자")로 등록돼 있었음(mcode 01121). surge/boostStarPutIntoPlay 엔진 로직 + vfx.attack 'weaponSmuggle' 연출까지 완비. **비어 있던 건 하수인 대사 3세트뿐** → enter/attack/defeat 각 5개 채워 완결
  - ⚠ 검증 사각지대 발견: test_vfx_index의 하수인 대사 검사는 `QUOTES`에 키가 있는 하수인만 순회 → **대사가 아예 없는 하수인은 미검출**. weapons-runner가 이 사각으로 통과해 있었음. 강화하려면 "minion+vfx.attack 보유 카드는 QUOTES[defCode] enter/attack/defeat 5개 필수" 검사를 넣어야 하나, band-of-badoon 등 db의 todoFx 미완 하수인 다수가 걸려 대량 실패 → 별도 정리 필요(보류)
  - 교훈: 카드가 mcode(01121)가 아니라 slug 코드(weapons-runner)로 등록될 수 있음. 미등록 판단 시 `MC.cardDef(mcode)`만 보지 말고 slug/이름/mcode 병행 검색할 것
- 다음: 01122 Klaw's Vengeance(배신, 폼분기 ×2) — db에 이미 있을 가능성 높음, slug 검색으로 먼저 확인

## v2026.07.12.172 (이번 세션)
- **01122 클로의 복수(Klaw's Vengeance)** 완성 — db에 slug 'klaw-vengeance'로 stub(todoFx) 존재했음. 폼 분기 배신 효과·연출·대사 구현
  - 히어로: 클로 공격(피해 시 메인 위협 +1) / 알터에고: 손패 무작위 1장 버림
  - 엔진: `EFFECTS.villainAttacks`에 `threatOnDamage` 파라미터 추가 → 방어 pending에 실어 공격 해소부(dmgDone 추적)에서 피해 발생 시에만 메인 위협 배치. 조건부(전량 방지 시 미발동) 정확
  - 핸들러 `klawVengeance`(폼 분기), 연출 `sonicVengeanceScatter`(알터에고 음파 손패 강탈 — 히어로 분기는 공격 연출에 위임, 조건부 연출 분리), 대사 5개(quoteKey 'klaw-vengeance')
  - 테스트: tests/test_klaw_vengeance.js (알터에고 버림 / 히어로 공격+위협 / 무피해 시 위협 없음) — 회귀 전체 통과, 연출·대사 325건
- 다음: 01123 Sonic Boom(배신, 자원지불 or 전체소진 ×2) — slug 'sonic-boom' stub 존재. 01124 Sound Manipulation('sound-manipulation' 폼분기 클로회복), 01126 Illegal Arms Factory('illegal-arms-factory' 위협3+1/인) 순

## v2026.07.12.172 (이번 세션) — 조우 효과 EFFECTS 인덱스 기반화
사용자 요청: "조우로 인한 빌런 공격/암약이 많을 것 → 인덱스 타입으로 기반 확실히". 커스텀 핸들러 대신 데이터 파라미터만 넘기면 처리되는 범용 EFFECTS 인덱스로 기반화.
- **신규 이펙트 3종(shards/mc_2_effects.js):**
  - `villainSchemes(G,p,ctx)` — 빌런 암약: 메인 스킴에 (villain.scheme+bonus)만큼 위협. villainAttacks의 짝
  - `formBranch(G,p,ctx)` — 폼 분기: pl.form에 따라 p.hero / p.alter effects 배열을 runEffectList로 재귀 실행. 배신 카드 폼분기를 데이터화
  - `playVfx(G,p,ctx)` — 연출 힌트 범용: G.fxCardEffect={vfx,quote,target,...} 세팅. p:{vfx,quoteKey,quoteKind,target}
- **신규 핸들러(shards/mc_3_handlers.js):** `runCardEffects(G,ctx)` — 카드 def의 `def[hook+'Effects']||def.effects`를 runEffectList로 실행. 조우 카드가 whenRevealed:'runCardEffects'+effects:[...]만 선언하면 커스텀 핸들러 없이 데이터 처리
- **klaw-vengeance 리팩터:** 커스텀 klawVengeance 핸들러 제거 → formBranch 데이터 방식으로 통일. hero:[villainAttacks threatOnDamage:1] / alter:[discardFromHand, playVfx]. 커스텀 핸들러 없이 폼분기 완전 작동 실증
- **test_index 강화:** effects[].fx를 재귀(checkFx)로 검사 — formBranch의 hero/alter 중첩 effects 배열도 fx 등록 검증
- 회귀 전체 통과(test_index 1255장 0건, test_core 200판 크래시0, 연출/대사 325건), tests/test_klaw_vengeance.js를 데이터 실행 경로로 갱신 + villainSchemes 암약 동작 검증
- **앞으로 조우 카드 작성 패턴(하드코딩 제로):** `whenRevealed:'runCardEffects'` + `effects:[{fx:'formBranch', hero:[...], alter:[...]}]` 또는 `[{fx:'villainAttacks',...}]`/`[{fx:'villainSchemes',...}]` 등 데이터만 선언
- 다음: 01123 Sonic Boom(slug 'sonic-boom') — 이 기반(runCardEffects/villainAttacks/formBranch)으로 데이터 구현. 01124 Sound Manipulation(폼분기 클로회복), 01126 Illegal Arms Factory(사이드스킴) 순

## v2026.07.12.172 (이번 세션) — 01123 소닉 붐 + 선택 배신 인덱스 기반화
- **01123 소닉 붐(Sonic Boom)** 완성 — db slug 'sonic-boom' stub. 선택 배신(자원 지불 OR 전체 소진)을 커스텀 핸들러 없이 범용 인덱스로 데이터화
  - 공개 시: ⚡🧠💪 자원 각 1개 지불(회피) OR 통제하는 모든 캐릭터(히어로+동료) 소진
- **신규 기반 이펙트/헬퍼(하드코딩 제로 확장):**
  - `EFFECTS.exhaustControlled` — 히어로 자신+동료 전체 소진(범용 로그). exhaustAllAllies는 동료 전용+멜터 로그라 분리
  - `EFFECTS.offerChoice` — 선택 배신 pending(revealChoice)을 데이터로 세움. `effects:[{fx:'offerChoice', prompt, options:[{key,label,effects,payIcons}]}]`로 선언. 커스텀 rev_* 핸들러 대체
  - `resolveRevealChoice` 확장 — option.payIcons(다중 타입 자원 요구) 지불 검증·소비 범용 추가
  - `MC.payIconsSatisfied(icons, req)` 헬퍼 — 다중 타입 요구를 wild 유연 배정으로 충족 검증(shards/mc_4_players.js)
  - 연출 `sonicBoomBlast`(광역 음파 폭발), 대사 5개(quoteKey 'klaw-sonic-boom', kind 'boom')
  - 테스트 tests/test_klaw_sonic_boom.js (선택 pending / 전체 소진 / payIcons wild 유연 5종) — 회귀 전체 통과, 연출/대사 327건
  - ※ 부스트★("피해 시 히어로 소진")은 배신이 빌런 공격 부스트로 뒤집힐 때만 의미 → 조건부 boostStar, 추후 별도 구현(본체 선택 효과 우선 완결)
- **선택 배신 작성 패턴(신규):** `whenRevealed:'runCardEffects'` + `effects:[{fx:'offerChoice', options:[{key,label,payIcons?,effects:[...]}]}]`
- 다음: 01124 Sound Manipulation('sound-manipulation' 폼분기 클로 회복) — formBranch로 데이터화. 01126 Illegal Arms Factory(사이드스킴) 순

## v2026.07.12.172 (이번 세션) — 소닉 붐 부스트★ 완결 (미뤄둔 것 마저 구현)
- v155에서 본체 선택 효과만 하고 미뤄둔 **소닉 붐 부스트★("이 활성화가 피해를 주면 히어로 소진")** 구현
  - 부스트★는 배신 공개가 아니라, 소닉 붐이 빌런 공격 시 부스트 카드로 뒤집혔을 때 발동. 클로는 공격마다 부스트 추가라 실제로 자주 나옴
  - 엔진: 공격 해소부(resolveDefensePending)에 범용 `boostStarOnDamage` 처리 추가 — dmgDone>0일 때 boostEvents 순회하며 각 부스트 카드의 `boostStarOnDamage` effects 실행. 즉시형 boostStarEffect와 분리(피해 조건부)
  - 데이터: sonic-boom def에 `boostStarOnDamage:[{fx:'exhaustTarget', target:'self'}]` (resolveTarget('self')=히어로 → 히어로만 소진). KNOWN_META에 필드 등록
  - 테스트: 피해 발생 시 소진 / 전량 방지(무피해) 시 소진 안 됨 — 회귀 전체 통과
- **범용 재사용:** 앞으로 "부스트로 뒤집혀 피해 시 X" 효과는 `boostStarOnDamage:[...effects]` 데이터로 선언
- 다음: 01124 Sound Manipulation('sound-manipulation' 폼분기 클로 회복) — formBranch. 01126 Illegal Arms Factory(사이드스킴)

## v2026.07.12.172 (이번 세션) — 01124 음파 조작 (폼분기 + 조건부 급증)
- **01124 음파 조작(Sound Manipulation)** 완성 — db slug 'sound-manipulation' stub. 폼 분기 배신, 두 효과 모두 데이터 구현
  - 알터에고: 클로 4 회복 (이 방법으로 회복이 0이면 = 클로 풀피면 이 카드 급증)
  - 히어로: 히어로 2 피해 + 클로 2 회복
- **엔진 확장(하드코딩 제로):**
  - `healTarget` 실제 회복량 반환 + 로그 정확화(이전엔 요청량 표시). `EFFECTS.healVillain`이 G._lastHealDone에 실제 회복량 기록
  - `condCheck`에 `healedNone` 조건 추가 — 직전 healVillain 회복이 0이었는지. surge를 `{fx:'surge', cond:{type:'healedNone'}}`로 데이터 분기
  - 연출 `sonicHeal`(청록 음파 수렴+회복 입자), 대사 5개(quoteKey 'klaw-sound-manip', kind 'manip')
  - 테스트 tests/test_klaw_sound_manip.js (히어로 피해+회복 / 알터 회복 / 풀피 시 급증 / healedNone 조건) — 회귀 전체 통과, 연출/대사 329건
- **클로 세트 남은 카드:** 01126 Illegal Arms Factory('illegal-arms-factory' 사이드스킴, 위협3+1/인) — 마지막 클로 세트 카드
- **메모리 저장됨(#9):** 카드마다 모든 효과(본체+부스트★+분기) 같은 작업에서 완결, 범용 EFFECTS 인덱스 우선

## v2026.07.12.172 (이번 세션) — 01126 불법 무기 공장 (클로 세트 완성)
- **01126 불법 무기 공장(Illegal Arms Factory)** 완성 — db slug 'illegal-arms-factory' stub. 사이드 스킴, 공개+완성 효과 모두 데이터
  - 공개 시: 시작 위협 3 + 인원수당 위협 +1 (솔로=4, 3인=6)
  - 완성(위협 제거로 격퇴) 시: 폐쇄 연출/대사 (완료 효과는 원래 없음 — 테마 몰입용)
- **엔진 확장(하드코딩 제로):**
  - `EFFECTS.placeThreat` 범용 확장 — `scheme:'self'`(이 사이드 스킴 자신) + `perHero`(인원수 비례 추가 위협) 지원. 방어망(01125)의 커스텀 핸들러 sideSchemeRevealThreatPerHero 대신 데이터로 처리(앞으로 사이드 스킴 위협은 이 방식 재사용)
  - whenRevealed:'runCardEffects' + effects:[placeThreat self/perHero, playVfx] / whenCompleted:'runCardEffects' + whenCompletedEffects:[playVfx]. onSideSchemeCleared가 발화하는 whenCompleted 훅 활용
  - baseFields + test_index에 훅별 effects 필드(whenRevealedEffects/whenCompletedEffects/whenDefeatedEffects) 등록 + fx 재귀 검사 강화
  - 연출 armsFactoryActivate(붉은 경보+음파 코어+조립 스파크=공장 가동)/armsFactoryShutdown(전력 차단+잔해+연기=폐쇄), 대사 10개(quoteKey 'klaw-arms-factory', reveal 5 + complete 5)
  - 테스트 tests/test_klaw_arms_factory.js (공개 위협 solo 4/3인 6, 완성 격퇴+폐쇄 연출) — 회귀 전체 통과, 연출/대사 331건
- **★ 클로 세트 전체 완성** (01113~01128 시나리오 카드 전부): 빌런 3단계·메인스킴·부착물·하수인·배신·사이드스킴 모두 등록
- **메모리 #9 원칙 적용:** 카드마다 본체+분기+연출 전부 같은 작업에서 완결. 커스텀 핸들러 대신 범용 EFFECTS 인덱스 우선

## v2026.07.12.172 (이번 세션) — 덱빌더 검색 + 돋보기
- **덱빌더 카드 검색**: 검색창(이름·영문명·효과 텍스트·특성 매칭). builderPool()에 q 필터 추가. 검색 시 카드 풀 영역(#builder-pool)만 교체해 입력 포커스/커서 유지(UI.bSearch 부분 갱신), ✕ 클리어 버튼(UI.bSearchClear 전체 재렌더). 빈 결과 안내 메시지. APP.builder.search 상태
- **덱빌더 돋보기**: poolTile의 cardArt 호출에 mag=true 전달 → 각 카드에 🔍 배지 → 기존 UI.info 모달(확대 이미지+스탯+룰 텍스트+플레이버+양면 전환) 재사용. 신규 모달 불필요, 연결만
- 파일: ui/mc_ui.js(builderPool 필터/builderPoolInner 분리/renderBuilder 검색창/UI.bSearch·bSearchClear/APP.builder.search 초기화), ui/template.html(.builder-search CSS)
- 회귀 전체 통과, 필터 로직 검증(웹→1, 방어(효과)→29, avenger(특성)→53, 없는 검색→0)

## ★ 작업 순서 원칙 재확인 (사용자 지적)
- 카드 등록은 **mcode 오름차순 엄격 순차**. 클로 세트에서 01125/01127이 01126보다 먼저 들어간 순서 어긋남 반성. 다음 카드 작업은 반드시 mcode 순으로 진행

## v2026.07.12.172 (이번 세션) — 01106 쇄도 (코어 mcode 순차 재개)
- **★ mcode 오름차순 순차 등록 재개.** 코어셋 미완성 최하위 = 01106. (01105 이하 완료)
- **01106 쇄도(Stampede)** 완성 — db slug 'stampede'(라이노 세트). 폼 분기 배신, 두 효과 모두 데이터
  - 알터에고: 이 카드 급증(surge)
  - 히어로: 라이노가 공격, 피해 입은 캐릭터 기절(stunOnHit)
- **엔진 확장(하드코딩 제로):** 방어 해소부(resolveDefensePending)에 `p.stunOnHit && dmgDone>0 → 대상 기절` 범용 처리 추가(villainAttacks가 이미 pending에 stunOnHit 실었으나 해소부 미처리였음 → 완결). threatOnDamage 옆에 배치, 앞으로 stun 공격 배신 재사용
  - 연출은 기존 rhinoRampage(라이노 돌진) 재사용, 대사 5개(quoteKey 'rhino-stampede', kind 'stampede')
  - 데이터: formBranch{alter:[surge], hero:[playVfx rhinoRampage, villainAttacks stunOnHit]}
  - 테스트 tests/test_rhino_stampede.js (급증/공격 pending/무방어 기절/전량방지 기절X) — 회귀 전체 통과, 연출/대사 333건
- **다음(mcode 순):** 01107 breakin-and-takin, 01108 crowd-control, 01109 bomb-threat, 01111 explosion … (코어셋 미완성 55장 남음)

## v2026.07.12.172 (이번 세션) — 01107 침입 & 약탈 (Hazard 엔진 구현)
- **01107 침입 & 약탈(Breakin' & Takin')** 완성 — db slug 'breakin-and-takin'(라이노 세트). 사이드 스킴
  - 공개 시: 시작 위협 2 + 인원수당 +1 (솔로 3, 2인 4)
  - **위험(Hazard)**: 빌런 페이즈마다 조우 카드 +1
- **엔진 확장(하드코딩 제로):**
  - **Hazard 범용 구현** — 빌런 페이즈 dealEnc 스텝에 "전장의 hazard 사이드 스킴 1장당 조우 카드 +1" 처리 추가(hz 카운트, 플레이어 순서 배분). hazard는 baseFields 필드로만 있었고 실제 효과 미구현이던 것 완결. under-attack(01151)/invasive-ai(01149) 등 hazard:true 카드 모두 자동 적용
  - breakin-and-takin에 hazard:true 선언 + placeThreat(self/perHero) 공개 + whenCompleted 완성, 모두 데이터
  - 연출 rhinoRansack(먼지·파편·흔들림·SMASH, 신규) 공개/완성 공용 + 대사 10개(quoteKey 'rhino-ransack', reveal 5 + complete 5)
  - 테스트 tests/test_rhino_breakin.js (위협 solo3/2인4, Hazard 조우+1, 완성 격퇴) — 회귀 전체 통과, 연출/대사 335건
- **다음(mcode 순):** 01108 crowd-control, 01109 bomb-threat, 01111 explosion …

## v2026.07.12.172 (이번 세션) — 가속(acceleration) 버그 근본 수정
- **★ 근본 원인:** 공식 `escalation_threat`(메인 스킴 라운드당 기본 상승률, 인원수당 1)을 db가 `accelIcons`로 오매핑. 시뮬은 baseGain(인원수)로 escalation을 이미 처리하는데 accelIcons까지 또 더해 이중 계산 → 라이노 솔로 시작부터 라운드당 위협 +2 (정상은 +1)
- **공식 룰 확인:** 메인 스킴은 라운드당 인원수만큼 상승(라이노 솔로1/4인4, 가속 아이콘 없음). 진짜 가속 아이콘은 **사이드 스킴**에 있고, 전장에 가속 사이드 스킴이 있으면 빌런 페이즈 1단계에 메인 스킴 위협 +(가속 아이콘 수). Taskmaster/Hood 메인 스킴도 "adds one per turn"으로 가속 없음 → 메인 스킴 accelIcons 6개 전부 오매핑
- **수정(엔진, 하드코딩 제로):** threat 스텝을 `baseGain(인원수) + Σ(전장 사이드 스킴 가속 아이콘) + G.acceleration(토큰)`으로 재작성. **메인 스킴 accelIcons는 escalation 오매핑이라 위협 계산에서 제외**(이중 계산 방지). 이로써 사이드 스킴 가속 아이콘이 처음으로 실제 반영됨(hit-squad/overrun 등)
- **UI 일치(mc_ui.js schemeIconChips):** 메인 스킴 위협 예상치·가속 배지를 엔진과 동일하게 — 메인 스킴 오매핑 accelIcons 제외, 가속 아이콘 배지는 사이드 스킴에만, hazard 배지 boolean 처리
- **회귀:** test_acceleration.js 신규(시작 solo1/2인2/4인4, 사이드스킴 가속 solo+2, 가속2 solo+3, 토큰, 격퇴 시 가속 소멸). 전체 통과. 평균 라운드 3.9→4.3(위협 정상화로 게임이 조금 길어짐 — 버그 수정 결과)
- **다음(mcode 순):** 01108 crowd-control …

## v2026.07.12.172 (이번 세션) — 동료/업그레이드 소진 표시 통일
- **문제:** 소진(exhausted) 표시가 제각각 — 신분/업그레이드/서포트는 exhBar(차단바+어둡게), 동료는 작은 "소진" 텍스트 배지뿐이라 눈에 안 띔
- **수정(ui/mc_ui.js):**
  - 동료(ally)도 exhBar()로 통일 (badge exh 제거) — 업그레이드/서포트와 동일한 "소진!" 차단바 + 어둡게
  - 동료/업그레이드/서포트 슬롯(mat-slot)에 소진 시 `exhausted` 클래스 부여
- **수정(ui/template.html):** `.mat-slot.exhausted .card-art{transform:rotate(6deg)}` — 소진 카드를 실물처럼 살짝 기울여(tapped) 직관적 표시. 기존 exhBar(dim+차단바)와 함께 이중으로 명확
- 회귀 전체 통과
- **다음(mcode 순):** 01108 crowd-control …

## v2026.07.12.172 (이번 세션) — 01083 모킹버드 확인 + 돋보기 정보 정리
- **01083 모킹버드(Mockingbird)** 확인 — 기본 어스팩트 동료(ATK1/THW1/HP3, cost3, 💪피지컬). 등록 완료(todoFx:false), 등장 시 기절 효과 정상 작동(whenPlayed→mockingbirdStun→적 기절, 검증 완료). ※ 현재 대상 미지정 시 빌런 자동 — 공식은 "적 1명 선택"이라 하수인 선택 흐름은 개선 여지
- **돋보기(UI.info) 정보 정리** — 효과 텍스트 + 플레이버만 표시. textKo에서 제거: ①타입/코스트/자원 메타 줄(statline과 중복) ②스탯 줄(ATK n/THW n…) ③"시작 위협:" 메타 ④※ 판정 각주 ⑤마크다운 강조(**bold** *i* _u_). 플레이버는 따옴표/이탤릭 인용 줄을 분리, **한국어(textKo) 우선** def.flavor(영어) 후순위. 한글 뒤 \b 정규식 문제 해결
- 회귀 전체 통과
- **다음(mcode 순):** 01108 crowd-control …

## v2026.07.12.172 (이번 세션) — 모킹버드 대상 선택 + 범용 chooseEnemy 인덱스
- **★ chooseEnemy 범용 이펙트(인덱스 타입):** "적 1명 선택 → then 효과 실행". 후보(빌런+교전 하수인, scope로 제한 가능)가 1명이면 자동 대상, 여럿이면 선택 pending. then은 순수 데이터 effects 배열이라 **기절/혼란/조준/피해 등 어떤 후속 효과든 재사용**
  - 엔진: `EFFECTS.chooseEnemy`(mc_2_effects.js), `ACTIONS.resolveChooseEnemy`(mc_7_core.js, pending 해소 후 then 실행)
  - UI: pending.kind==='chooseEnemy'일 때 빌런/하수인에 targetable 하이라이트 + 클릭(pickTarget/zoneTap 확장), 🎯 대상 선택 프롬프트 배너. pickTarget이 선택 후 fxCardEffect 연출 재생
- **01083 모킹버드** 커스텀 핸들러(mockingbirdStun) 제거 → chooseEnemy 인덱스로 데이터화. whenPlayed → chooseEnemy{ then:[applyStatus stunned, playVfx stunStrike] }. 이제 하수인도 선택해 기절 가능
- **범용 연출 stunStrike:** 대상에 기절 별(★ 회전) + 임팩트, 적 선택 기절 카드 공용. 대사 5개(quoteKey 'mockingbird', kind 'stun' — S.H.I.E.L.D. 첩보원 톤)
- 테스트 tests/test_choose_enemy.js 신규(자동/pending/빌런·하수인 분기/유효성) + test_phase3_core 모킹버드 테스트 새 흐름 반영. 회귀 전체 통과
- **재사용 예정:** "적 선택 후 X" 카드 전부 chooseEnemy로 (혼란·조준·표식 등)
- **다음(mcode 순):** 01108 crowd-control …

## v2026.07.12.172 (이번 세션) — 01108 군중 통제 (Crisis 엔진 구현)
- **01108 군중 통제(Crowd Control)** 완성 — db slug 'crowd-control'(라이노 세트). 사이드 스킴
  - 공식 확인(BGG): 시작 위협 **인원수당 2**(솔로 2/2인 4, per player 심볼) — db baseThreatPerPlayer:2 정확
  - **위기(Crisis)**: 이 스킴이 전장에 있는 동안 메인 스킴 위협 제거 불가
- **엔진 확장(하드코딩 제로):**
  - **Crisis 범용 구현** — `MC.hasCrisisScheme(G)`(crisis 사이드 스킴 + threat>0 판정) 신규. basicThwart/allyThwart에서 메인 스킴 저지 시 Crisis면 throw(순찰 체크 옆). crisis는 baseFields 필드로만 있고 실제 차단 미구현이던 것 완결. 앞으로 crisis:true 사이드 스킴 모두 자동 적용
  - UI: _doThwart/_doAllyThwart에 Crisis 안내 toast(메인 저지 시도 시 "위기 스킴 먼저 처치"). schemeIconChips는 이미 ✛위기 배지 표시
  - crowd-control에 crisis:true + 공개/완성 연출·대사(시작 위협은 사이드 스킴 공개 처리가 자동)
  - 연출 crowdPanic(시민 인영 흩어짐+먼지, 신규) 공개/완성 공용 + 대사 10개(quoteKey 'rhino-crowd', reveal 5 + complete 5, 라이노가 시민을 방패로 이용하는 톤)
  - 테스트 tests/test_rhino_crowd_control.js (위협 per player, Crisis 저지 차단/사이드는 가능/처치 후 해제) — 회귀 전체 통과, 연출/대사 338건
- **다음(mcode 순):** 01109 bomb-threat(가속 아이콘 실재 — accelIcons 유지 확인), 01111 explosion …

## v2026.07.12.172 (이번 세션) — 01109 폭탄 위협 (진짜 가속 사이드 스킴)
- **01109 폭탄 위협(Bomb Scare)** 완성 — db slug 'bomb-threat'. Bomb Scare 모듈러 세트 사이드 스킴(라이노 권장 모듈러)
  - 공개 시: 시작 위협 2 + 인원수당 +1 (솔로 3, 2인 4)
  - **가속 아이콘(accelIcons:1 유지)**: 전장에 있으면 빌런 페이즈마다 메인 스킴 +1 — v162 가속 수정으로 실제 반영됨(라이노 메인 자체는 가속 없음 → +1, 폭탄 위협 있으면 +2)
- 데이터: placeThreat(self/perHero) 공개 + accelIcons:1(db 유지, 진짜 가속) + whenCompleted. 전부 범용 인덱스
- 연출 bombScareAlert(붉은 경보+💣+카운트다운 링, 신규)/bombDefused(초록+✓ 해체, 신규) + 대사 10개(quoteKey 'bomb-scare', reveal 5 + complete 5, 하이드라 폭탄 긴박한 상황 톤)
- 테스트 tests/test_bomb_scare.js (공개 위협, 진짜 가속 메인+1/처치 후 소멸, 완성) — 회귀 전체 통과, 연출/대사 340건
- ※ Bomb Scare 세트 연계: explosion(01111)이 폭탄 위협의 위협 수만큼 피해 분배 → 01111 등록 시 연계
- **다음(mcode 순):** 01110(bomb-scare-2), 01111 explosion …

## v2026.07.12.172 (이번 세션) — 01111 폭발! (완전 인덱스 타입 조건 분기)
- **01111 폭발!(Explosion)** 완성 — db slug 'explosion'. Bomb Scare 모듈러 배신. **커스텀 핸들러 없이 100% 데이터**
  - 공식: 폭탄 위협(bomb-threat)이 전장에 있으면 그 위협 수(X)만큼 피해, 없으면 급증(surge)
- **엔진 확장(전부 범용 재사용 요소):**
  - `condCheck`에 범용 **negate** wrapper 추가 — 어떤 조건이든 `negate:true`로 반전 재사용 (condCheck→condCheckRaw 분리)
  - `condCheck` 'schemeInPlay' 조건 — 특정 사이드 스킴(slug)이 전장에 위협>0으로 존재하는지
  - `dealDamage` 'amountFromSchemeThreat' — 특정 사이드 스킴 위협 수를 피해량으로
  - `resolveTarget` 'firstPlayer' — 첫 플레이어
  - 데이터: effects 각 step에 cond 부여 — schemeInPlay면 [dealDamage amountFromSchemeThreat + playVfx], schemeInPlay+negate면 [surge]
  - ※ 공식 "히어로/동료 간 X 피해 자유 분배" → 시뮬은 첫 플레이어 집중(분배 UI 추후)
- 연출 explosionBlast(붉은 섬광+화구+파편+충격 BOOM, 신규) + 대사 5개(quoteKey 'explosion', kind 'blast')
- 테스트 tests/test_bomb_explosion.js (위협 수=피해량, 급증 분기, 위협0 시 급증, negate 범용성) — 회귀 전체 통과, 연출/대사 342건
- **다음(mcode 순):** 01118 sonic-converter(재확인), 01119 solid-sound-body … 또는 남은 코어 미완성

## v2026.07.12.172 (이번 세션) — 폭발! 조건별 대사·연출 분리
- **01111 폭발!** 발동 조건 2가지에 각각 전용 대사·연출 (메모리 원칙: 조건부 효과=조건부 연출 분리)
  - ① 폭탄 위협 있음 → 대폭발: explosionBlast 연출 + blast 대사 5개(긴박·충격)
  - ② 폭탄 위협 없음 → 급증: fuseSpark 연출(도화선 불씨→▲급증, 신규) + fuse 대사 5개(폭탄 미설치, 불씨가 번지는 불길한 톤)
- surge 스텝 옆에 동일 cond(schemeInPlay+negate)로 playVfx fuseSpark 추가 — 데이터만으로 분기별 연출/대사
- 테스트 조건별 연출 분리 검증 추가(explosionBlast vs fuseSpark). 회귀 전체 통과, 연출/대사 342건
- **다음(mcode 순):** 남은 코어 미완성 (01118~ 등)

## v2026.07.12.172 (이번 세션) — 01118 소닉 컨버터 (인덱스 타입 리팩터 + 완결)
- **버그 발견/수정:** 소닉 컨버터가 code '01118'(seed)와 slug 'sonic-converter'(db)로 **중복 등록**돼 있었고, 게임이 쓰는 slug 쪽은 todoFx:true(미작동)였음. seed 01118 제거 → slug 'sonic-converter' 정본 통일. 공식에 없는 ATK+1(db/seed 오류) 제거
- **완전 인덱스 타입(커스텀 핸들러 sonicConverterInstall/Stun 제거):**
  - ① 부착: whenRevealed runCardEffects → playVfx sonicWeaponForge (장착 연출/대사)
  - ② 강제반응 기절: attackDamagedResponse 'runAttachDamagedEffects'(신규 범용 핸들러) + attackDamagedEffects[applyStatus target:'target' stunned, playVfx sonicStunPulse]. 클로 공격+피해 시 대상 기절
  - ③ 히어로 행동 제거: removeAbility{payIcons:⚡🧠💪 각1} + ACTIONS.removeEnemyAttachment(신규 범용 — 자원 지불→detach+버림)
- **범용 재사용 요소 신규:** resolveTarget 'target'(ctx.target 단일 대상), HANDLERS.runAttachDamagedEffects, ACTIONS.removeEnemyAttachment, baseFields attackDamagedEffects, KNOWN_META removeAbility. 다른 부착물(강제반응/제거)에 재사용
- 대사 5개(quoteKey 'sonic-converter', kind 'stun', 클로 음파 무기 톤). 옛 test_klaw_sonic_converter.js 제거 → test_sonic_converter.js 신규(부착/강제반응/제거/자원부족)
- 회귀 전체 통과, 연출/대사 342건
- **다음(mcode 순):** 01119 solid-sound-body …

## v2026.07.12.172 (이번 세션) — 01119 견고한 음체 (인덱스 타입, 소닉 컨버터와 동형)
- **01119 견고한 음체(Solid-Sound Body)** 완성 — 소닉 컨버터와 동일한 중복 버그(seed '01119' + slug 'solid-sound-body', slug 쪽 todoFx) 수정. seed 제거 → slug 정본 통일. db textKo '정신 자원 3개' 오류를 공식(⚡🧠💪 각1)으로 정정
- **완전 인덱스 타입(커스텀 핸들러 solidSoundBodyInstall 제거):**
  - 부착: whenRevealed → playVfx sonicBodyHarden (결정화 연출/대사)
  - 클로 반격: attachStats{retaliate:1} — statOf가 자동 적용(공격받으면 공격자 1 피해)
  - 히어로 행동 제거: removeAbility{payIcons:⚡🧠💪 각1} + removeEnemyAttachment(v170 범용 재사용)
- 테스트 tests/test_solid_sound_body.js 신규(부착/retaliate 발동·미발동/제거). 옛 test_klaw_solid_sound.js('01119' 참조) 제거. 회귀 전체 통과, 연출/대사 341건
- **클로 세트 부착물(01118·01119) 모두 인덱스 타입으로 재정비 완료**
- **다음(mcode 순):** 01127 immortal-klaw, 01128 masters-of-evil-scheme, 01133 masters-of-mayhem …

## [메모] 01120 아머드 가드 중복 (정리 대기)
- armored-guard(db slug, 무장 경호원, 연출 armorSlam)와 01120(seed code, 아머드 가드, copies:3, 연출 armoredGuardStrike)가 **둘 다 완성 상태로 중복**. 소닉 컨버터/견고한 음체와 같은 seed/db 이중 등록 패턴이나 이건 양쪽 다 fx 완비. 클로 시나리오 구현 시 실제 소환 코드를 확인해 하나로 통일 필요(공식 ×3이므로 copies:3 쪽 스펙 유지).

## v2026.07.12.172 (이번 세션) — 01127 불멸의 클로 (인덱스 + HP감소 버그 수정)
- **01127 불멸의 클로(The "Immortal" Klaw)** 완성 — slug 'immortal-klaw'(공식) 정본 통일. 중복 the-immortal-klaw(seed stub) 제거, 클로 2단계 소환도 immortal-klaw로 변경
- **버그 수정:** 기존 the-immortal-klaw는 whenDefeated로 HP -10을 걸었는데, 사이드 스킴 처치는 whenCompleted만 발화 → **HP -10이 실제로 미작동**이던 버그. whenCompleted로 이전해 수정
- **완전 인덱스 타입(커스텀 핸들러 immortalKlawReveal/Defeated 제거):**
  - 공개 시: buffVillainHp +10 (신규 범용 이펙트 — 빌런 max/현재 HP 증감, 감소 시 상한 클램프만이라 죽지 않음)
  - 해결(whenCompleted) 시: buffVillainHp -10
- 연출 immortalKlawForm(보라 음파 수렴+결정화, 신규)/immortalKlawShatter(균열+파편, 신규) + 대사 10개(quoteKey 'klaw-immortal', reveal 5 + shatter 5). ※ kind는 'defeat'가 아닌 'shatter' (빌런 패배 대사 10개 규칙 회피)
- 테스트 test_immortal_klaw.js 신규(HP+10/-10/손상 상태 안 죽음), test_phase3_core 불멸의 클로 부분 인덱스 방식 수정. 회귀 전체 통과, 연출/대사 343건
- **다음(mcode 순):** 01128 masters-of-evil-scheme, 01133 masters-of-mayhem …

═══════════════════════════════════════════════════════
## ★ 토큰 절약 워크플로우 (v172.5+, 필수 준수)
═══════════════════════════════════════════════════════

### 새 도구 (tools/)
| 도구 | 용도 | 사용 |
|---|---|---|
| **preflight.py** | 카드 등록 전 원샷 점검: 공식 JSON + db/seed 상태 + slug/code 중복 + 연출·대사 존재 | `python3 tools/preflight.py 01128` |
| **scan_dupes.py** | seed/db mcode 이중 등록 전수 스캔 | `python3 tools/scan_dupes.py` |
| **prefetch_next.py** | mcode 순 다음 N개 미완성의 공식 JSON → /tmp/next_cards.json | `python3 tools/prefetch_next.py 10` |
| **quick_check.sh** | 실패시만 상세, 성공시 한 줄 검증 (index + 지정 테스트) | `bash tools/quick_check.sh tests/test_X.js` |

### 카드 등록 사이클 (토큰 최소화)
1. **세션 시작 시 1회**: `prefetch_next.py 10` (공식 JSON 캐시) + `scan_dupes.py` (중복 파악)
2. **카드마다**: `preflight.py <mcode>` 딱 1번 → 바로 구현 (탐색 3~4연타 금지)
3. **카드마다 검증**: `quick_check.sh tests/test_해당카드.js` 만 (전체 회귀 아님)
4. **3~5장 묶음 완료 시에만**: `run_tests.sh` 전체 회귀 → 빌드 → 버전업 → tar 패키징 → present_files
5. node 인라인 검증 필요 시: 출력은 PASS/FAIL 판정 위주 한두 줄로. 상태 덤프 금지

### 중복 발견 시
- 미완성 쪽이 slug(공식)면: seed 제거 → slug 정본 (소닉 컨버터 패턴)
- 둘 다 완성이면: 즉시 정리하지 말고 아래 '중복 정리 대기 목록'에 추가 (시나리오 구현 시 일괄)

### 중복 정리 대기 목록 (scan_dupes 2026-07-13 기준, 코어셋)
- **01120**: armored-guard(무장 경호원, armorSlam) vs 01120(아머드 가드, copies:3, armoredGuardStrike) — 둘 다 완성. 클로 시나리오 구현 시 통일 (공식 ×3 → copies:3 스펙 유지)
- **01143**: advanced-drone vs advanced-ultron-drone — 둘 다 완성. 울트론 시나리오 시 통일
- **01182**: hydra-soldier vs hydra-soldier-loh — 둘 다 완성. 표준 세트 정리 시 통일
- (확장팩 10건: 04152, 09014, 13011, 16030, 16123, 16139, 21116, 22007, 32011, 33016 — 해당 팩 작업 시 처리)
