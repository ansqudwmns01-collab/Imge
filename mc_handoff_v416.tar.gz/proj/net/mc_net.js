/* ═══════════════════════════════════════════════════════════════
   mc_net.js — 전송 어댑터 계층 (엔진과 분리)
   계약: 엔진은 결정적. 동기화 = "액션 브로드캐스트"만.
     - 호스트: 초기 스냅샷(seed 포함 serialize) 1회 전송 후, 이후 액션만 중계
     - 게스트: 스냅샷 로드 → 수신 액션을 dispatch
   어댑터 인터페이스:
     { start(role, opt), send(action), onAction(cb), onSnapshot(cb), close() }
   구현체:
     LocalTransport  — 1인/개발용 no-op
     RtcTransport    — WebRTC P2P 스타형(호스트 중계), 수동 시그널링. Phase 1 구현.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC = global.MC || {};

/* 1인/개발용: 전송 없음 */
function LocalTransport(){
  return {
    start(){}, close(){},
    send(action){},
    onAction(cb){ this._cb = cb; },
    onSnapshot(cb){},
  };
}

/* WebRTC P2P (스타형: 호스트가 게스트 3명과 각각 DataChannel, 액션 중계)
   시그널링: 접속 코드 복사-붙여넣기 (서버리스). — Phase 1에서 구현 */
function RtcTransport(){
  return {
    start(role, opt){ throw new Error('RtcTransport: Phase 1 구현 예정'); },
    send(){}, onAction(){}, onSnapshot(){}, close(){},
  };
}

/* 게임 세션 래퍼: dispatch를 감싸 로컬 실행 + 브로드캐스트 통합 */
function makeSession(transport){
  const S = { G: null, transport, isHost: true };
  S.localDispatch = function(action){          // 내 조작
    MC.dispatch(S.G, action);
    transport.send(action);
  };
  transport.onAction(function(action){          // 원격 조작 수신
    MC.dispatch(S.G, action);
  });
  return S;
}

MC.NET = { LocalTransport, RtcTransport, makeSession };
})(typeof window !== 'undefined' ? window : globalThis);
