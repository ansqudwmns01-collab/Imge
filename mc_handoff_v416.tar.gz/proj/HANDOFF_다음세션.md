# 마블 챔피언스 시뮬레이터 — 다음 세션 인수인계

**현재 빌드: v2026.07.15.416** (졸라 시나리오 배포 완료, 파일: `/mnt/user-data/outputs/marvel_champions.html`)

---

## ⚠️ 최우선: 현재 진행 중이던 작업 (미완성)

사용자가 "대충 구현하는 것 아니냐"고 지적 → 정직하게 감사한 결과, **실제 게임에서 작동 안 하는 빈 껍데기 6개**를 발견했고 이걸 구현하던 중이었음. `runCardEffects`(mc_3_handlers.js:66)는 `whenRevealedEffects`가 null이면 `if(!list) return`으로 아무것도 안 함. 아래는 전부 능력 로직이 비어있는 상태:

### 졸라 시나리오 전용 (todoFx:true)
1. **04122 하이드라 감옥** (사이드스킴) — "각 플레이어 히어로 전용 동료를 스킴 아래 엎어 배치 + 동료 총비용만큼 위협 X + 처치 시 스킴 게임 제거 + 동료 손 반환". **hero-specific ally 시스템 필요**. 가장 복잡.
2. **04124 졸라의 실험** (사이드스킴) — "강제 반응: 하수인이 전장 등장한 후 → 조우 버린 더미 맨 위 Tech 부착을 그 하수인에 부착". **minionEnteredPlay 훅 필요**.

### under-attack 모듈러 (코어셋 공유, Core #151-154) — whenRevealedEffects=null
3. **under-attack** (01151 사이드스킴) — 공식: "Each player chooses to either place 2 threat here or deal 3 damage to their hero." → **eachPlayerChoice EFFECT 재사용** (위협2 vs 피해3). baseThreat:3, hazard:true. ※ eachPlayerChoice EFFECT는 이미 존재함(확인됨).
4. **concussive-blast** (01154 배반) — 공식: "Deal 1 damage to each friendly character. ★Boost: Deal 1 damage to each character you control." → **damageEachHero 재사용**(있음) + boostStarEffect. ※ damageEachCharacter는 없음, damageEachHero로 근사 or 신규 확장.
5. **vibranium-armor-u** (01152 부착) — 공식: "Attach to villain. Forced Response: After villain takes damage, give it tough. Hero Action: exhaust+💪💪→discard." → **attachTarget:'villain' + 빌런 피해 후 tough**(크로스본즈 아머 absorbsVillainDamage 유사 패턴 forcedResponse). 현재 attachStats=null.
6. **concussion-blasters** (01153 부착) — 공식: "Attach to villain. Villain gains retaliate 1." → **attachStats={retaliate:1} 이미 있음**. 부착=기본 빌런이므로 대체로 정상일 가능성 높음 → **재확인만** 하면 됨.

### 재사용 EFFECT 현황 (확인 완료)
- ✅ 있음: `eachPlayerChoice`, `damageEachHero`, `dealDamage`(target villain/self), `applyStatus`(tough/stunned/confused), `placeThreat`
- ❌ 없음: `damageEachCharacter` (필요 시 신규 or damageEachHero 확장)

---

## ✅ 이번 세션(v416)에서 완료한 것

- **졸라 시나리오 16장(04109-24) 전체 등록** — 능력 정확 번역 + 공식 플레이버. 빌런 3단계(HP12/14/16, retaliate1), 메인스킴 2개(졸라섬→미친박사, 완료 시 패배), 하수인 3, 부착 3, 배반 2, 사이드스킴 3.
- **test counter 시스템** — mc_5_encounter 빌런 페이즈 step1 후 `testPerVillainPhase`면 testCounters++, 3개 도달 시 `discardUntilMinionIntoPlay`(첫 플레이어) + 3 제거. UI에 🧪 실험 배지(testChip, delayChip 옆). **헤드리스 구동·mock 검증 완료**.
- **신규 EFFECT**: revealSideScheme / placeTestCounter / attachTechToSelf / shuffleSelfIntoEncounter / berserkTestBonus
- **신규 부착 대상**: minionMostHp (하수인 중 남은 HP 최다 + 동일 부착 없음, 없으면 surge) + grantsMinionGuard
- **enemyAtkPassive perSelfAttachment** (04114 자신 부착물당 ATK+1)
- **baseFields 추가**: testPerVillainPhase / grantsMinionGuard
- **QUOTES**: zola 빌런 10/10/10/5/5 + 하수인 3종 각 5/5/5 (미친 생화학 과학자 컨셉)
- **VFX**: zolaEntrance(독성 초록🧪🧬☣️)/zolaAttack/zolaStageUp/zolaDefeat
- **SCENARIOS.zola** + VILLAIN_ROSTER/META + 캠페인 sheet ready:true + startGame setupEngageMinion 처리 + comicDefeat[13,14] 졸라 격파→레드스컬 등장
- **under-attack 모듈러 slug 수정** — 잘못된 slug(shield-team 등)를 실제 등록 카드(under-attack/concussion-blasters/concussive-blast×2/vibranium-armor-u)로 교체. **단, 위 3~6번대로 능력 자체는 아직 미구현**.

---

## 📋 그 다음 백로그

### 레드 스컬 시나리오 (캠페인 최종, 세트 22장 04125-04144)
`/tmp/trors_enc.json`에 공식 데이터. 완전 구현 = 게임 로직 + 능력 정확 번역 + 공식 flavor + 대사 10/10/10/5/5 + VFX 4종 + comicDefeat[16].
- 빌런 3단계: 04125-27
- 메인스킴: 04128a/b (The Rise of Red Skull), 04129a/b (New World Hydra)
- 하수인: 04130 슬리퍼 / 04131 엑소솔저
- 부착: 04132 루거 / 04133 라이트훅 / 04134 마스터 전략가 / 04135 뒤틀린 현실
- 배반: 04136 라이벌 / 04137 거짓 유포 / 04138 무한의 힘
- 사이드스킴: 04139 붉은 집 / 04140 슬리퍼 각성 / 04141 포로수용소 / 04142 과거 검열 / 04143 하이드라 증원 / 04144 대혼란
- ※ 사용자 강조: 시나리오 전용 인카운터/부착/사이드스킴 전부 등록.

### 후속
- 레드스컬 확장 신규 히어로(넛헐크/스파이더우먼 등) + 성향(Aspect) 카드 + 모듈러 세트 등록

---

## 🔑 작업 원칙 (반드시 준수)

1. **인덱스 재사용 최우선** — 재사용 가능 능력은 범용 데이터 파라미터/중앙 집계(passiveXxx). "수치+대상만 다른" 능력은 신규 코드 0줄, 데이터만. 인라인 덧셈·카드 전용 분기·triggerXxx 하드코딩 금지. 새 키워드 부여도 (부여 필드 + passiveXxx 집계) 패턴으로 통일.
2. **카드/시나리오 1회 완전 구현** — 등록 시 모든 효과(본체+부스트★+조건분기+대사+VFX+룰텍스트) 같은 작업에서 완성. **필드 존재/mock만으로 "완성" 판정 금지 — 실제 게임 흐름에서 작동 검증 필수**(이번 세션 지적사항).
3. **룰텍스트/플레이버 정확 번역** — textKo에 능력을 의역/요약/창작 금지, 공식 text를 정확히 번역. 플레이버는 공식 flavor를 `"..."` 큰따옴표 한 줄로 넣으면 parseCardText가 자동 분리. 스탯(HP/ATK/SCH)은 UI 배지에 이미 나오므로 textKo에서 뺌. JSON/JS 문자열은 `\"` 이스케이프 주의.
4. **감사 방법** — `MC.cardDef`로 whenRevealed/whenRevealedEffects/forcedResponse/attachStats/todoFx 조회해서 실제 로직 유무 판정. whenRevealed='runCardEffects'인데 whenRevealedEffects=null이면 빈 껍데기.

---

## 🛠️ 환경/파이프라인

- 작업 디렉터리: `/home/claude/mc/proj/`
- 출력: `cp marvel_champions_build.html /mnt/user-data/outputs/marvel_champions.html`
- 파이프라인: `python3 tools/reassemble.py` → `python3 tools/build.py`(HANDOFF.md 버전 자동 주입) → `bash tools/run_tests.sh`
- **함정**: (1) db 새 필드는 반드시 baseFields(shards/mc_7_core.js:27-46 화이트리스트)에 추가. (2) 코드 수정 후 reassemble 안 하면 mc_engine.js 옛날 버전(헤드리스 검증 실패 흔한 원인). (3) mc_cards.js 문법 에러는 `node --check mc_cards.js`로 확인.
- 헤드리스 게임 구동 검증:
```js
const G = MC.makeGameState({seed:1, players:[{heroCode:"01001a", deckCodes:MC.PRESET_DECKS.spiderman.cards}], villainCode:"04109", mainScheme:"04112b", encounterCodes:MC.buildEncounter("zola",["under-attack"],"standard")});
MC.setupGame(G);
```

---

## 📂 공식 데이터

- 레드스컬 인카운터: `/tmp/trors_enc.json` (crossbones04058-75 / absorbing_man04076-92 / taskmaster04093-108 / zola04109-24 / **red_skull04125-44** / weap_master04145-51 / hydra_patrol04152-54)
- 코어 인카운터: `/tmp/core_encounter.json`
- 공식 raw: `raw.githubusercontent.com/zzorba/marvelsdb-json-data/master/pack/{code}.json`

---

## 📁 엔진 파일 구조 (요약)

- **엔진 샤드**(shards/): mc_1_terms / mc_2_effects(EFFECTS 인덱스) / mc_3_handlers(runCardEffects@66) / mc_4_players / mc_5_encounter(빌런 페이즈, test counter, minionMostHp 부착) / mc_6_keywords(applyDamage 중앙 함수) / mc_7_core(baseFields@27-46)
- **카드**(cards/): mc_cards_db.js(시나리오 빌런/카드, double-quote) / mc_cards_scenarios.js(MODULAR_SETS@14, SCENARIOS@122, buildEncounter) / mc_cards_seed.js(코어셋 빌런, single-quote) / mc_cards_zz*_fx.js
- **UI**(ui/): mc_vfx.js(QUOTES@14, VFX) / mc_ui.js(VILLAIN_ROSTER@158, CAMPAIGNS sheet@186, startGame@833, testChip, delayChip@1912) / template.html

---

## 캠페인 진행 현황

레드스컬 5시나리오: 크로스본즈✅ → 어보밍맨✅ → 태스크마스터✅ → **졸라✅(v416, 단 위 미구현 6개 잔존)** → 레드스컬(미구현).
