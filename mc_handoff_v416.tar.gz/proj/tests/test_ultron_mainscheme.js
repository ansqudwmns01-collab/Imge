/* test_ultron_mainscheme.js — 울트론 메인 스킴 3단계(01137~139) + 시나리오 회귀
   ★ ultronSetup(환경 배치), 진행형 메인 스킴(위협 임계 도달→다음 단계, 최종 완성→패배),
     forcedThreatChoice(01138b 빌런 페이즈 위협 후 선택), threatCannotRemove(01139b),
     각 단계 whenRevealed 드론 스폰. MC.SCENARIOS.ultron.
   사용: node tests/test_ultron_mainscheme.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mkUltron(seed){
  const sc = MC.SCENARIOS.ultron;
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode: sc.villainStart, mainScheme: sc.mainScheme, encounterCodes: MC.buildEncounter('ultron') });
  MC.setupGame(G);
  return G;
}

// ① 시나리오 존재 + 셋업: 울트론 드론 환경 배치 (01137b onSetup)
{
  const G = mkUltron(40001);
  assert(MC.SCENARIOS.ultron, 'MC.SCENARIOS.ultron 정의');
  assert(G.villain.defCode === '01134', '빌런 시작 = 울트론 I');
  assert(G.mainScheme.defCode === '01137b', '메인 스킴 = 크림슨 카울 1B');
  assert(G.environments && G.environments.some(e => e.defCode === 'ultron-drones'), '셋업: 울트론 드론 환경 배치');
  assert(G.mainScheme.maxThreat === 3, '1B 임계 3/인 (1인)');
}

// ② 메인 스킴 진행: 위협 임계 도달 → 다음 단계 (1B→2B→3B)
{
  const G = mkUltron(40002);
  MC.placeThreat(G, 'main', 3);            // 임계 도달 → 자동 진행
  assert(G.mainScheme.defCode === '01138b', '1B 완성 → 2B(노라드 습격) 자동 진행');
  assert(G.mainScheme.maxThreat === 10, '2B 임계 10/인');
  assert(G.players[0].engagedMinions.some(m => m.isDrone), '2B 공개: 드론 스폰');
  MC.placeThreat(G, 'main', 10);
  assert(G.mainScheme.defCode === '01139b', '2B 완성 → 3B(파멸의 카운트다운)');
  assert(G.mainScheme.maxThreat === 5, '3B 임계 5/인');
}

// ③ 3B 위협 제거 불가 (threatCannotRemove)
{
  const G = mkUltron(40003);
  MC.placeThreat(G, 'main', 3);
  MC.placeThreat(G, 'main', 10);
  assert(G.mainScheme.defCode === '01139b', '3B 도달 (자동 진행)');
  MC.placeThreat(G, 'main', 2);
  const t0 = G.mainScheme.threat;
  MC.removeThreat(G, 'main', 5);
  assert(G.mainScheme.threat === t0, '3B: 위협 제거 불가 (' + t0 + ' 유지)');
}

// ④ 3B 완성 → 플레이어 패배 (schemeComplete)
{
  const G = mkUltron(40004);
  MC.placeThreat(G, 'main', 3);
  MC.placeThreat(G, 'main', 10);
  MC.placeThreat(G, 'main', 5);
  assert(G.over && G.over.result === 'loss', '3B 완성: 플레이어 패배');
  assert(G.over.cause === 'schemeComplete', '패배 사유 = schemeComplete');
}

// ⑤ 01138b 강제반응: 빌런 페이즈 위협 후 선택 (위협2 or 드론)
{
  const G = mkUltron(40005); const pl = G.players[0];
  // 2B로 전환
  MC.placeThreat(G, 'main', 3);
  assert(G.mainScheme.defCode === '01138b', '2B 도달 (자동)');
  // 빌런 페이즈 위협 스텝 직접 태우기
  G.phase = 'villain'; G.vq = [{ op:'threat' }];
  MC.processVillainQueue(G);
  assert(G.pending && G.pending.kind === 'revealChoice', '2B 강제반응: 위협 후 선택 pending');
  const t0 = G.mainScheme.threat;
  MC.dispatch(G, { type:'resolveRevealChoice', option:'threat' });
  assert(G.mainScheme.threat === t0 + 2, '위협 선택: 메인 위협 +2');
}

console.log('══ 울트론 메인 스킴 3단계 + 시나리오 회귀 통과 ══');
