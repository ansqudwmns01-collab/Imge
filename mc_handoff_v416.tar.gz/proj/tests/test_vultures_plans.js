/* test_vultures_plans.js — 벌처의 계략(01169) 배신 회귀
   ★ 신규 discardRandomCountResources: 각 손패 무작위 버림 → 서로 다른 자원 종류 수만큼 메인 위협.
   사용: node tests/test_vultures_plans.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 손패 1장 버림 + 자원 종류만큼 메인 위협
{
  const G = mk(74001); const pl = G.players[0]; pl.form = 'hero';
  // 손패를 physical 자원 카드(shuri)만으로 구성 → 1종
  pl.hand = [MC.makeInstance(G, 'shuri', {})];
  const ms = G.mainScheme; const t0 = ms.threat || 0;
  const h0 = pl.hand.length;
  const inst = MC.makeInstance(G, 'vultures-plans', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.hand.length === h0 - 1, '손패 1장 버림');
  assert(G._vulturePlansX === 1, '자원 종류 1종 (physical)');
  assert((ms.threat || 0) === t0 + 1, '메인 위협 +1 (' + t0 + '→' + ms.threat + ')');
}

// ② 여러 자원 종류 카드면 그만큼 (wild 등 포함 시)
{
  const G = mk(74002); const pl = G.players[0]; pl.form = 'hero';
  // resources에 여러 종류 가진 카드 찾기 (없으면 shuri로 1종 검증)
  const multi = Object.keys(MC.CARDS).find(k => {
    const r = (MC.CARDS[k].resources) || {};
    return ['physical','mental','energy','wild'].filter(t => r[t] > 0).length >= 2;
  });
  if (multi){
    pl.hand = [MC.makeInstance(G, multi, {})];
    const rdef = MC.CARDS[multi].resources;
    const expect = ['physical','mental','energy','wild'].filter(t => rdef[t] > 0).length;
    const ms = G.mainScheme; const t0 = ms.threat || 0;
    const inst = MC.makeInstance(G, 'vultures-plans', {});
    MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
    assert(G._vulturePlansX === expect, '복수 자원 종류 ' + expect + '종 계산');
    assert((ms.threat || 0) === t0 + expect, '메인 위협 +' + expect);
  } else {
    console.log('✓ (복수 자원 카드 없음 — 스킵)');
  }
}

// ③ 빈 손패면 위협 0
{
  const G = mk(74003); const pl = G.players[0]; pl.form = 'hero';
  pl.hand = [];
  const ms = G.mainScheme; const t0 = ms.threat || 0;
  const inst = MC.makeInstance(G, 'vultures-plans', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G._vulturePlansX === 0, '빈 손패: 자원 0종');
  assert((ms.threat || 0) === t0, '메인 위협 변화 없음');
}

console.log('══ 벌처의 계략 (discardRandomCountResources) 회귀 통과 ══');
