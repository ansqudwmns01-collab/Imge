/* test_invasive_ai.js — 침습 AI(01149) 사이드 스킴 회귀
   ★ discardTopDeck scope:'eachPlayer' 확장 검증. hazard/시작위협 정의 확인.
   - 공개: 각 플레이어 덱 맨 위 3장 버림 · 시작 위협 3/인
   사용: node tests/test_invasive_ai.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 공개: 사이드 스킴 배치 + 시작 위협 3/인(1인=3) + 각 플레이어 덱 3장 밀링
{
  const G = mk(21001); const pl = G.players[0];
  const deck0 = pl.deck.length, disc0 = pl.discard.length;
  const ss = revealSide(G, pl, 'invasive-ai');
  assert(G.sideSchemes.some(s => s.uid === ss.uid), '침습 AI: 사이드 스킴 전장 배치');
  assert(ss.threat === 3, '시작 위협 3/인 (1인=3, 실제 ' + ss.threat + ')');
  assert(pl.deck.length === deck0 - 3, '덱 맨 위 3장 버림 (' + deck0 + '→' + pl.deck.length + ')');
  assert(pl.discard.length === disc0 + 3, '밀링 3장 버림 더미로');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'invasiveAiActivate', '해킹 연출');
}

// ② hazard 정의 유지 (빌런 페이즈 조우 +1 기여)
{
  const def = MC.cardDef('invasive-ai');
  assert(def.hazard === true, 'hazard(위험) 정의 유지');
  assert(def.baseThreatPerPlayer === 3, '시작 위협 per player 3 (정의 유지)');
}

// ③ 덱 얇을 때 리셔플 포함 밀링 (크래시 없음)
{
  const G = mk(21003); const pl = G.players[0];
  const keep = pl.deck.splice(0, Math.max(0, pl.deck.length - 1));  // 덱 1장만
  pl.discard.push(...keep);
  const total = pl.deck.length + pl.discard.length;
  revealSide(G, pl, 'invasive-ai');
  assert(pl.deck.length + pl.discard.length <= total + 2, '덱 얇음: 리셔플 포함 3장 밀링 (크래시 없음)');
}

// ④ 완성(whenCompleted) 연출 발화
{
  const G = mk(21004); const pl = G.players[0];
  const ss = revealSide(G, pl, 'invasive-ai');
  G.fxCardEffect = null;
  MC.fireCardHook(G, ss, 'whenCompleted', {});
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'invasiveAiShutdown', '완성: 연결 차단 연출');
}

console.log('══ 침습 AI (discardTopDeck eachPlayer) 회귀 통과 ══');
