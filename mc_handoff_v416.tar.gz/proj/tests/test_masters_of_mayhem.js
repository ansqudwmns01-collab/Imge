/* test_masters_of_mayhem.js — 혼돈의 지배(01133) 배신 회귀
   ★ 신규 범용: EFFECTS.minionsAttack(trait, fallback:'searchEngage') + startMinionAttackChain
     (attackChain 연쇄 방어 pending) + searchMinionIntoPlay(덱+버림 탐색 교전)
     + cond 'minionsAttacked' 분기별 연출.
   - 교전 중인 각 MoE 하수인이 순차 공격 (체인) · 타 특성 하수인은 공격 안 함
   - 기절 하수인은 기절 소모 후 공격 생략 · 전원 기절이면 증원 분기
   - 공격이 하나도 없으면 조우덱+버림에서 MoE 하수인 탐색 교전 + 덱 셔플
   사용: node tests/test_masters_of_mayhem.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function engage(G, pl, code){
  const m = MC.makeInstance(G, code, {});
  m.engagedWith = pl.uid; pl.engagedMinions.push(m);
  return m;
}
function fire(G, pl){
  const inst = MC.makeInstance(G, 'masters-of-mayhem', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}

// ① MoE 하수인 2명 교전 — 순차 공격 체인 (타 특성 하수인은 공격 안 함)
{
  const G = mk(2901); const pl = G.players[0]; pl.form = 'hero';
  const melter = engage(G, pl, 'melter');           // MoE ATK 3
  const whirl  = engage(G, pl, 'whirlwind');        // MoE ATK 2
  engage(G, pl, 'hydra-soldier');                    // 비-MoE — 공격 대상 아님
  fire(G, pl);
  assert(G.pending && G.pending.kind === 'defense', '공개: 첫 MoE 하수인 방어 pending');
  assert(G.pending.attackerUid === melter.uid, '첫 공격자 = 멜터');
  assert(G.pending.attackChain && G.pending.attackChain.length === 1 &&
         G.pending.attackChain[0].attackerUid === whirl.uid, '체인에 훨윈드 대기 (히드라 병사 제외)');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'mastersOnslaught', '공격 분기: 일제 공격 연출');
  // 첫 방어 해소 → 체인이 훨윈드 공격 pending으로 이어짐
  const hp0 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp0 - (melter.attack||0), '멜터 무방어 피해 ' + melter.attack);
  assert(G.pending && G.pending.attackerUid === whirl.uid, '체인: 훨윈드 공격 pending으로 연장');
  const hp1 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp1 - (whirl.attack||0), '훨윈드 무방어 피해 ' + whirl.attack);
  assert(!G.pending, '체인 종료: pending 해소');
}

// ② 기절 하수인은 기절 소모 후 공격 생략 — 유일 후보가 기절이면 증원 분기
{
  const G = mk(2905); const pl = G.players[0]; pl.form = 'hero';
  const melter = engage(G, pl, 'melter');
  melter.status.stunned = 1;
  G.encounterDeck = [MC.makeInstance(G, 'tiger-shark', {}), MC.makeInstance(G, 'im-tough', {})];
  G.encounterDiscard = [];
  fire(G, pl);
  assert(melter.status.stunned === 0, '기절 소모 (공격 생략)');
  assert(!G.pending, '공격 pending 없음');
  assert(pl.engagedMinions.some(m => m.defCode === 'tiger-shark'), '증원: 타이거 샤크 탐색 교전 배치');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'mastersAssemble', '증원 분기: 집결 연출 (분기별 연출 분리)');
}

// ③ MoE 하수인 없음 — 버림 더미에서도 탐색 (덱에 없을 때)
{
  const G = mk(2910); const pl = G.players[0]; pl.form = 'hero';
  G.encounterDeck = [MC.makeInstance(G, 'im-tough', {})];
  G.encounterDiscard = [MC.makeInstance(G, 'radioactive-man', {})];
  fire(G, pl);
  assert(pl.engagedMinions.some(m => m.defCode === 'radioactive-man'), '버림 더미에서 라디오액티브 맨 탐색 교전');
  assert(G.encounterDiscard.length === 0, '버림 더미에서 제거됨');
}

// ④ 어디에도 MoE 하수인 없음 — 안전 불발 (크래시 없음)
{
  const G = mk(2915); const pl = G.players[0]; pl.form = 'hero';
  G.encounterDeck = [MC.makeInstance(G, 'im-tough', {})];
  G.encounterDiscard = [];
  const before = pl.engagedMinions.length;
  fire(G, pl);
  assert(pl.engagedMinions.length === before && !G.pending, 'MoE 전무: 안전 불발');
}

console.log('══ 혼돈의 지배 (minionsAttack 체인 인덱스) 회귀 통과 ══');
