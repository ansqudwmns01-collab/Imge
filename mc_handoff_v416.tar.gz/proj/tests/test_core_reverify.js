/* test_core_reverify.js — 코어(01xxx) 등록 카드 실제 작동 재검증 (영구 회귀)
   ★ 목적: "배선했다"고 표시된 카드가 실제로 작동하는지 매 빌드마다 자동 검증.
     임시 스크립트 대신 회귀에 박아서 다시 깨지면 즉시 잡는다.
   ★ 덱 방향 규약: 덱 위 = 끝(pop 방향). 테스트에서 카드를 '위'에 심을 땐 deck.push.
   사용: node tests/test_core_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mkG(hero){
  const G = MC.makeGameState({ seed:3,
    players:[{ heroCode: hero || '01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  return G;
}
function ally(G, code){ const a = MC.makeInstance(G, code, {}); return a; }

/* 01002 블랙캣 — atkCost 0(부수피해 없음) + 플레이 후 덱 위 2장 중 🧠멘탈 카드만 손에 */
{
  assert(MC.cardDef('black-cat').atkCost === 0, '01002 블랙캣 — atkCost 0 (부수피해 없음)');
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  const g = MC.makeInstance(G, 'genius', {}), e = MC.makeInstance(G, 'energy', {});
  pl.deck.push(e, g);                       // g가 덱 위(끝). pop→g 먼저
  const bc = ally(G, 'black-cat'); pl.playArea.allies.push(bc);
  MC.fireCardHook(G, bc, 'whenPlayed', { player: pl, self: bc, card: bc });
  assert(pl.hand.includes(g) && pl.discard.includes(e),
    '01002 블랙캣 — 멘탈 카드 손에 / 비멘탈 버림');
}

/* 01011 스파이더 우먼 — 등장 후 빌런 혼란 */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  const sw = ally(G, 'spider-woman-ally'); pl.playArea.allies.push(sw);
  MC.fireCardHook(G, sw, 'whenPlayed', { player: pl, self: sw, card: sw });
  assert((G.villain.status.confused || 0) > 0, '01011 스파이더우먼 — 빌런 혼란');
}

/* 01067 마리아 힐 — 등장 후 각 플레이어 카드 1장 드로우 */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  const h0 = pl.hand.length;
  const m = ally(G, 'maria-hill'); pl.playArea.allies.push(m);
  MC.fireCardHook(G, m, 'whenPlayed', { player: pl, self: m, card: m });
  assert(pl.hand.length === h0 + 1, '01067 마리아 힐 — 카드 1장 드로우');
}

/* 01076 루크 케이지 — 등장 시 자신(동료)에 Tough. 히어로엔 안 걸림 */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  const heroTough0 = pl.status.tough;
  const lc = ally(G, 'luke-cage'); pl.playArea.allies.push(lc);
  MC.fireCardHook(G, lc, 'whenPlayed', { player: pl, self: lc, card: lc });
  assert(lc.status.tough > 0, '01076 루크 케이지 — 자신 Tough');
  assert(pl.status.tough === heroTough0, '01076 루크 케이지 — 히어로엔 Tough 안 걸림');
}

/* lookAtTopChoose 방향 — 덱 위(끝) N장을 pop 순서로 보여줘야 함 (Futurist 등 공용) */
{
  const G = mkG('01029a'); const pl = G.players[0]; pl.form = 'alter-ego';
  const marks = ['genius', 'energy', 'strength'].map(c => MC.makeInstance(G, c, {}));
  pl.deck.push(...marks);                    // strength가 맨 위(끝)
  const expected = [pl.deck[pl.deck.length-1].defCode, pl.deck[pl.deck.length-2].defCode, pl.deck[pl.deck.length-3].defCode];
  MC.dispatch(G, { type:'useIdentityAction', player: pl.uid });
  const shown = (G.pending._cards || []).map(c => c.defCode);
  assert(JSON.stringify(shown) === JSON.stringify(expected),
    'lookAtTopChoose — 덱 위(끝) 3장을 pop 순서로 (Futurist 방향)');
}

/* 01012 위기 저지 — 히어로 행동(저지): 스킴에서 위협 2 제거 (Aerial이면 다른 스킴 2 추가) */
{
  const G = mkG('01019a'); const pl = G.players[0]; pl.form = 'hero';
  MC.placeThreat(G, 'main', 5); const t0 = G.mainScheme.threat;
  const ci = MC.makeInstance(G, 'crisis-interdiction', {}); pl.hand.push(ci);
  for (let i=0;i<2;i++) pl.hand.push(MC.makeInstance(G, 'genius', {}));
  const pay = pl.hand.filter(c => c.defCode==='genius').slice(0,2).map(c => ({ kind:'hand', uid:c.uid }));
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: ci.uid, payment: pay, targetScheme:'main' });
  assert(t0 - G.mainScheme.threat >= 2, '01012 위기 저지 — 위협 2 이상 제거');
}

/* 01013 광자 폭발 — 히어로 행동(공격): 적 1명에게 5 피해 */
{
  const G = mkG('01019a'); const pl = G.players[0]; pl.form = 'hero';
  const v0 = G.villain.hp;
  const pb = MC.makeInstance(G, 'photon-blast', {}); pl.hand.push(pb);
  for (let i=0;i<2;i++) pl.hand.push(MC.makeInstance(G, 'energy', {}));
  const pay = pl.hand.filter(c => c.defCode==='energy').slice(0,2).map(c => ({ kind:'hand', uid:c.uid }));
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: pb.uid, payment: pay, targets:[G.villain.uid] });
  assert(v0 - G.villain.hp === 5, '01013 광자 폭발 — 빌런 5 피해');
}

/* ── She-Hulk(01019a) 시그니처 배치 ── */
function mkSH(){
  const G = MC.makeGameState({ seed:3,
    players:[{ heroCode:'01019a', deckCodes: MC.PRESET_DECKS['she-hulk'].cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  return G;
}
function payN(G, pl, code, n){
  const r = [];
  for (let i=0;i<n;i++){ const c = MC.makeInstance(G, code, {}); pl.hand.push(c); r.push({ kind:'hand', uid:c.uid }); }
  return r;
}

/* 01021 감마 슬램 — X 피해 = 누적 피해량 (최대 HP - 현재 HP) */
{
  const G = mkSH(); const pl = G.players[0]; pl.form = 'hero';
  pl.hp = (MC.heroFace(G, pl).hp || 14) - 6; const v0 = G.villain.hp;
  const gs = MC.makeInstance(G, 'gamma-slam', {}); pl.hand.push(gs);
  const pay = payN(G, pl, 'strength', 2);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: gs.uid, payment: pay, targets:[G.villain.uid] });
  assert(v0 - G.villain.hp === 6, '01021 감마 슬램 — 누적피해 6 = 빌런 6 피해');
}

/* 01022 짓밟기 — 모든 적(빌런+하수인)에게 각 1 피해 */
{
  const G = mkSH(); const pl = G.players[0]; pl.form = 'hero';
  const mn = MC.makeInstance(G, 'weapons-runner', {}); mn.engagedWith = pl.uid; pl.engagedMinions.push(mn);
  const v0 = G.villain.hp, m0 = mn.hp;
  const gs = MC.makeInstance(G, 'ground-stomp', {}); pl.hand.push(gs);
  const pay = payN(G, pl, 'strength', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: gs.uid, payment: pay });
  assert(v0 - G.villain.hp === 1 && m0 - mn.hp === 1, '01022 짓밟기 — 빌런+하수인 각 1 피해');
}

/* 01023 법률 업무 — 알터에고 저지: 손 N장 버림 → N만큼 메인 위협 제거 */
{
  const G = mkSH(); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  MC.placeThreat(G, 'main', 5); const t0 = G.mainScheme.threat;
  const lp = MC.makeInstance(G, 'legal-practice', {}); pl.hand.push(lp);
  const junk = payN(G, pl, 'energy', 3).map(p => p.uid);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: lp.uid, payment: [], discardUids: junk });
  assert(t0 - G.mainScheme.threat >= 1, '01023 법률 업무 — 버린 수만큼 위협 제거');
}

/* 01024 원투 펀치 — 기본 공격 후 반응: 히어로 준비(소진 해제) */
{
  const G = mkSH(); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = true;
  const otp = MC.makeInstance(G, 'one-two-punch', {}); pl.hand.push(otp); pl.justBasicAttacked = true;
  const pay = payN(G, pl, 'strength', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: otp.uid, payment: pay });
  assert(pl.exhausted === false, '01024 원투 펀치 — 히어로 준비(소진 해제)');
}

/* 01025 이중인격 — 폼 전환 */
{
  const G = mkSH(); const pl = G.players[0]; pl.form = 'hero'; const form0 = pl.form;
  const sp = MC.makeInstance(G, 'split-personality', {}); pl.hand.push(sp);
  const pay = payN(G, pl, 'genius', 2);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: sp.uid, payment: pay });
  assert(pl.form !== form0, '01025 이중인격 — 폼 전환');
}

/* 01028 초인적인 힘 — 지속 ATK+2 + 기본공격 후(afterBasicAttack) 자체버림 + 대상 기절 */
{
  const G = mkSH(); const pl = G.players[0]; pl.form = 'hero';
  assert(MC.cardDef('superhuman-strength').attack === 2, '01028 초인적인 힘 — 지속 ATK +2');
  const ss = MC.makeInstance(G, 'superhuman-strength', {}); pl.playArea.upgrades.push(ss);
  const mn = MC.makeInstance(G, 'weapons-runner', {}); mn.engagedWith = pl.uid; pl.engagedMinions.push(mn);
  MC.fireCardHook(G, ss, 'afterBasicAttack', { player: pl, self: ss, card: ss, target: mn });
  assert(!pl.playArea.upgrades.includes(ss) && pl.discard.includes(ss), '01028 초인적인 힘 — 반응 후 자체 버림');
  assert((mn.status.stunned || 0) > 0, '01028 초인적인 힘 — 대상 기절');
}

/* ── Iron Man(01029a) 시그니처 배치 ── */
function mkIM(){
  const G = MC.makeGameState({ seed:3,
    players:[{ heroCode:'01029a', deckCodes: MC.PRESET_DECKS['iron-man'].cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  return G;
}

/* 01031 리펄서 블래스트 — 적 1피해 + 덱 위 5장 버림, 인쇄 ⚡에너지당 +2. 덱 위를 비에너지로 통제 → 정확히 1피해 */
{
  const G = mkIM(); const pl = G.players[0]; pl.form = 'hero'; const v0 = G.villain.hp;
  for (let i=0;i<5;i++) pl.deck.push(MC.makeInstance(G, 'strength', {}));   // 💪만 = 에너지 0 → 추가피해 0
  const rb = MC.makeInstance(G, 'repulsor-blast', {}); pl.hand.push(rb);
  const pay = payN(G, pl, 'strength', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: rb.uid, payment: pay, targets:[G.villain.uid] });
  assert(v0 - G.villain.hp === 1, '01031 리펄서 블래스트 — 에너지 0장이면 정확히 1 피해');
}

/* 01032 초음속 펀치 — 4피해 (비Aerial) */
{
  const G = mkIM(); const pl = G.players[0]; pl.form = 'hero'; const v0 = G.villain.hp;
  const sp = MC.makeInstance(G, 'supersonic-punch', {}); pl.hand.push(sp);
  const pay = payN(G, pl, 'genius', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: sp.uid, payment: pay, targets:[G.villain.uid] });
  assert(v0 - G.villain.hp === 4, '01032 초음속 펀치 — 비Aerial 4 피해');
}

/* 01036 MK.5 아머 — maxHP +6 */
{
  const G = mkIM(); const pl = G.players[0]; pl.form = 'hero'; const max0 = pl.maxHp;
  const arm = MC.makeInstance(G, 'mk5-armor', {}); pl.hand.push(arm);
  const pay = payN(G, pl, 'genius', 2);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: arm.uid, payment: pay });
  assert(pl.maxHp === max0 + 6, '01036 MK.5 아머 — maxHP +6');
}

/* 01039 로켓 부츠 — maxHP +1 */
{
  const G = mkIM(); const pl = G.players[0]; pl.form = 'hero'; const max0 = pl.maxHp;
  const rb = MC.makeInstance(G, 'rocket-boots', {}); pl.hand.push(rb);
  const pay = payN(G, pl, 'genius', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: rb.uid, payment: pay });
  assert(pl.maxHp === max0 + 1, '01039 로켓 부츠 — maxHP +1');
}

/* ── Black Panther(01040a) 배치 ── */
function mkBP(){
  const G = MC.makeGameState({ seed:3,
    players:[{ heroCode:'01040a', deckCodes: MC.PRESET_DECKS['black-panther'].cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  return G;
}

/* 01041 슈리 — 등장 후 덱에서 업그레이드 1장 손에 */
{
  const G = mkBP(); const pl = G.players[0]; pl.form = 'hero';
  pl.deck.push(MC.makeInstance(G, 'vibranium-suit', {}));
  const sh = MC.makeInstance(G, 'shuri', {}); pl.playArea.allies.push(sh);
  MC.fireCardHook(G, sh, 'whenPlayed', { player: pl, self: sh, card: sh });
  assert(pl.hand.some(c => (MC.cardDef(c.defCode) || {}).type === 'upgrade'),
    '01041 슈리 — 덱에서 업그레이드 1장 손에');
}

/* 01042 조상의 지식 — 알터에고 행동: 버린 더미 서로 다른 3장 → 덱 (덱 +3) */
{
  const G = mkBP(); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  ['energy','genius','strength'].forEach(c => pl.discard.push(MC.makeInstance(G, c, {})));
  const ak = MC.makeInstance(G, 'ancestral-knowledge', {}); pl.hand.push(ak);
  const pay = payN(G, pl, 'energy', 1);
  const deck0 = pl.deck.length;
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: ak.uid, payment: pay });
  assert(pl.deck.length === deck0 + 3, '01042 조상의 지식 — 버린 더미 3장 덱으로');
}

/* 01043a 와칸다 포에버 — BP 업그레이드 2개 → 특수 순차 발동(wakandaOrder pending) */
{
  const G = mkBP(); const pl = G.players[0]; pl.form = 'hero';
  ['panther-claws','energy-daggers'].forEach(c => pl.playArea.upgrades.push(MC.makeInstance(G, c, {})));
  const wf = MC.makeInstance(G, 'wakanda-forever', {}); pl.hand.push(wf);
  const pay = payN(G, pl, 'energy', 3);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: wf.uid, payment: pay });
  assert(G.pending && G.pending.kind === 'wakandaOrder', '01043a 와칸다 포에버 — 특수 순차 시퀀스 대기');
}

/* 01050 헐크 — 공격 후 강제반응: 덱 위 1장 버림 */
{
  const G = mkBP(); const pl = G.players[0]; pl.form = 'hero';
  const hk = MC.makeInstance(G, 'hulk-ally', {}); pl.playArea.allies.push(hk);
  const dk0 = pl.deck.length;
  MC.fireCardHook(G, hk, 'afterAttack', { player: pl, self: hk, card: hk, attacker: hk, target: G.villain });
  assert(pl.deck.length === dk0 - 1, '01050 헐크 — 공격 후 덱 위 1장 버림');
}

/* 01051 타이그라 — 공격으로 하수인 처치 후 1 회복 (순증 0 = 회복+atkCost) / 생존 시 -1 */
{
  const G = mkBP(); const pl = G.players[0]; pl.form = 'hero';
  const tg = MC.makeInstance(G, 'tigra-ally', {}); tg.hp = 2; pl.playArea.allies.push(tg);
  const mn = MC.makeInstance(G, 'weapons-runner', {}); mn.hp = 1; mn.engagedWith = pl.uid; pl.engagedMinions.push(mn);
  MC.dispatch(G, { type:'allyAttack', player: pl.uid, allyUid: tg.uid, targetUid: mn.uid });
  assert(tg.hp === 2 && mn.hp <= 0, '01051 타이그라 — 하수인 처치 후 회복(순증0)');
}

/* 01052 추적하라! — 반응(저지): 적 처치 후 스킴 위협 2 제거 (playCondition: justDefeatedEnemyByAttack) */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  G.mainScheme.threat = 5; const t0 = G.mainScheme.threat;   // 직접 세팅(임계치 회피)
  pl.justDefeatedEnemyByAttack = true;                        // 조건 충족
  const cd = MC.makeInstance(G, 'chase-them-down', {}); pl.hand.push(cd);
  const pay = payN(G, pl, 'energy', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: cd.uid, payment: pay, targetScheme:'main' });
  assert(t0 - G.mainScheme.threat === 2, '01052 추적하라 — 적 처치 후 위협 2 제거');
}

/* 01053 거침없는 돌진 — 하수인 1명에게 5 피해 */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  const mn = MC.makeInstance(G, 'weapons-runner', {}); mn.hp = 8; mn.engagedWith = pl.uid; pl.engagedMinions.push(mn);
  const ra = MC.makeInstance(G, 'relentless-assault', {}); pl.hand.push(ra);
  const pay = payN(G, pl, 'genius', 2);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: ra.uid, payment: pay, targets:[mn.uid] });
  assert(mn.hp === 3, '01053 거침없는 돌진 — 하수인 5 피해');
}

/* 01054 어퍼컷 — 적 1명에게 5 피해 */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero'; const v0 = G.villain.hp;
  const uc = MC.makeInstance(G, 'uppercut', {}); pl.hand.push(uc);
  const pay = payN(G, pl, 'strength', 2);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: uc.uid, payment: pay, targets:[G.villain.uid] });
  assert(v0 - G.villain.hp === 5, '01054 어퍼컷 — 빌런 5 피해');
}

/* 01058 데어데블 — 저지 후 반응: 적 1명에게 1 피해 */
{
  const G = mkBP(); const pl = G.players[0]; pl.form = 'hero'; const v0 = G.villain.hp;
  const dd = MC.makeInstance(G, 'daredevil', {}); pl.playArea.allies.push(dd);
  MC.fireCardHook(G, dd, 'afterThwart', { player: pl, self: dd, card: dd, thwarter: dd, targets:[G.villain] });
  assert(v0 - G.villain.hp === 1, '01058 데어데블 — 저지 후 적 1 피해');
}

/* 01060 정의를 위해! — 위협 3 제거 (🧠멘탈 지불 시 4 제거 킥커) */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  G.mainScheme.threat = 5; const t0 = G.mainScheme.threat;
  const fj = MC.makeInstance(G, 'for-justice', {}); pl.hand.push(fj);
  const pay = payN(G, pl, 'strength', 1);   // 비멘탈
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: fj.uid, payment: pay, targetScheme:'main' });
  assert(t0 - G.mainScheme.threat === 3, '01060 정의를 위해 — 비멘탈 위협 3 제거');
}
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  G.mainScheme.threat = 5; const t0 = G.mainScheme.threat;
  const fj = MC.makeInstance(G, 'for-justice', {}); pl.hand.push(fj);
  const pay = payN(G, pl, 'genius', 1);   // 🧠멘탈 → 킥커
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: fj.uid, payment: pay, targetScheme:'main' });
  assert(t0 - G.mainScheme.threat === 4, '01060 정의를 위해 — 멘탈 지불 시 4 제거(킥커)');
}

/* 01069 준비 태세 — 행동: 동료 1명 준비(소진 해제) */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  const a = MC.makeInstance(G, 'spider-woman-ally', {}); a.exhausted = true; pl.playArea.allies.push(a);
  const gr = MC.makeInstance(G, 'get-ready', {}); pl.hand.push(gr);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: gr.uid, payment: [], targets:[a.uid] });
  assert(a.exhausted === false, '01069 준비 태세 — 동료 준비(소진 해제)');
}

/* 01074 감화 — 동료 강화(ATK 상승, 부수피해 없음) */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero';
  const a = MC.makeInstance(G, 'spider-woman-ally', {}); pl.playArea.allies.push(a);
  const atk0 = MC.allyStatOf(G, a, 'attack');
  const ins = MC.makeInstance(G, 'inspired', {}); pl.hand.push(ins);
  const pay = payN(G, pl, 'energy', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: ins.uid, payment: pay, targets:[a.uid] });
  assert(MC.allyStatOf(G, a, 'attack') > atk0, '01074 감화 — 동료 ATK 강화');
}

/* 01083 모킹버드 — 등장 후 적 1명 선택 → 기절 (chooseEnemy = 플레이어 선택) */
{
  const G = mkBP(); const pl = G.players[0]; pl.form = 'hero';
  const mb = MC.makeInstance(G, 'mockingbird', {}); pl.playArea.allies.push(mb);
  const mn = MC.makeInstance(G, 'weapons-runner', {}); mn.engagedWith = pl.uid; pl.engagedMinions.push(mn);
  MC.fireCardHook(G, mb, 'whenPlayed', { player: pl, self: mb, card: mb });
  assert(G.pending && G.pending.kind === 'chooseEnemy', '01083 모킹버드 — 기절 대상 선택 대기(하드코딩 아님)');
  MC.dispatch(G, { type:'resolveChooseEnemy', uid: mn.uid });
  assert((mn.status.stunned || 0) > 0, '01083 모킹버드 — 선택한 적 기절');
}

/* 01086 응급처치 — 행동: 캐릭터 피해 2 회복 */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero'; pl.hp = pl.maxHp - 3; const hp0 = pl.hp;
  const fa = MC.makeInstance(G, 'first-aid', {}); pl.hand.push(fa);
  const pay = payN(G, pl, 'energy', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: fa.uid, payment: pay, targets:[pl.uid] });
  assert(pl.hp === hp0 + 2, '01086 응급처치 — 피해 2 회복');
}

/* 01087 강타 — 히어로 공격: 적 3 피해 */
{
  const G = mkG(); const pl = G.players[0]; pl.form = 'hero'; const v0 = G.villain.hp;
  const hm = MC.makeInstance(G, 'haymaker', {}); pl.hand.push(hm);
  const pay = payN(G, pl, 'strength', 1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: hm.uid, payment: pay, targets:[G.villain.uid] });
  assert(v0 - G.villain.hp === 3, '01087 강타 — 빌런 3 피해');
}

/* ── 의무 카드 5장(01155/01160/01165/01170/01175) — whenRevealed → 2택(영구해결/미루기) ── */
{
  const OBL = {
    'obligation-bp':      ['01040a','black-panther'],
    'legal-work':         ['01019a','she-hulk'],
    'eviction-notice':    ['01001a','spiderman'],
    'business-problems':  ['01029a','iron-man'],
    'family-emergency':   ['01010a','captain-marvel'],
  };
  for (const code in OBL){
    const [hero, deckKey] = OBL[code];
    const G = MC.makeGameState({ seed:3,
      players:[{ heroCode: hero, deckCodes: MC.PRESET_DECKS[deckKey].cards.slice() }],
      villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
    MC.setupGame(G);
    const pl = G.players[0]; if (pl.form === 'hero') MC.flipForm(G, pl, { force:true });
    const ob = MC.makeInstance(G, code, {});
    MC.fireCardHook(G, ob, 'whenRevealed', { player: pl, self: ob, card: ob });
    assert(G.pending && G.pending.kind === 'revealChoice' && (G.pending.options||[]).length === 2,
      code + ' 의무 — whenRevealed 시 2택(해결/미루기)');
    pl.exhausted = false;
    MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'exhaust' });
    assert(pl.exhausted === true, code + ' 의무 — 영웅 소진 = 영구 해결');
  }
}

/* 의무 미루기(defer) 경로 검증 — family-emergency(기절+급증) / legal-work(가속토큰) */
{
  const G = MC.makeGameState({ seed:3,
    players:[{ heroCode:'01010a', deckCodes: MC.PRESET_DECKS['captain-marvel'].cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  const ob = MC.makeInstance(G, 'family-emergency', {});
  MC.fireCardHook(G, ob, 'whenRevealed', { player: pl, self: ob, card: ob });
  MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'stun' });
  assert((pl.status.stunned || 0) > 0, 'family-emergency 의무 — 미루기(자신 기절)');
}
{
  const G = MC.makeGameState({ seed:3,
    players:[{ heroCode:'01019a', deckCodes: MC.PRESET_DECKS['she-hulk'].cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  const acc0 = G.acceleration || G.accelTokens || 0;
  const ob = MC.makeInstance(G, 'legal-work', {});
  MC.fireCardHook(G, ob, 'whenRevealed', { player: pl, self: ob, card: ob });
  MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'accel' });
  assert((G.acceleration || G.accelTokens || 0) > acc0, 'legal-work 의무 — 미루기(가속 토큰 +1)');
}

console.log('\n[test_core_reverify] ' + pass + '개 통과 — 코어 39장 재검증 완료');
