/* test_family_emergency.js — 가족 비상사태(01175) obligation 회귀
   ★ obligation 재사용(exhaustTarget/resolveObligation) + applyStatus(기절) + surge.
   사용: node tests/test_family_emergency.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 공개: 선택 pending (2옵션)
{
  const G = mk(80001); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  pl.status = { stunned:0, confused:0, tough:0 };
  const inst = MC.makeInstance(G, 'family-emergency', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'revealChoice', '의무 공개 — 선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (소진/기절)');
}

// ② exhaust 옵션: 소진 + 게임 제거
{
  const G = mk(80002); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  pl.status = { stunned:0, confused:0, tough:0 };
  const inst = MC.makeInstance(G, 'family-emergency', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'exhaust' });
  assert(pl.exhausted === true, 'exhaust: 캐롤 댄버스 소진');
  assert((G.removedFromGame || []).includes('family-emergency'), 'exhaust: 게임에서 제거');
}

// ③ stun 옵션: 자신 기절 + surge (의무 버림)
{
  const G = mk(80003); const pl = G.players[0]; pl.form = 'hero';
  pl.status = { stunned:0, confused:0, tough:0 };
  const inst = MC.makeInstance(G, 'family-emergency', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'stun' });
  assert(pl.status.stunned > 0, 'stun: 자신 기절');
  assert(inst.surge === true, 'stun: surge 획득');
  assert(pl.exhausted !== true, 'stun: 소진 안 함');
  assert((G.removedFromGame || []).length === 0, 'stun: 게임 제거 아님(버림)');
}

console.log('══ 가족 비상사태 (obligation + 기절 + surge) 회귀 통과 ══');
