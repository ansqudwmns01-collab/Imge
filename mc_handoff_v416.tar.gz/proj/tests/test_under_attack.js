/* test_under_attack.js — 공격 받는 중(01151) 사이드 스킴 회귀
   ★ 신규 범용: EFFECTS.eachPlayerChoice(각 플레이어 순차 선택 체인) + flushEachChoice.
   - 공개: 각 플레이어 선택(위협2 or 히어로 피해3) · 시작 위협 3(고정)
   사용: node tests/test_under_attack.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 공개: 사이드 스킴 배치 + 시작 위협 3(고정) + 각 플레이어 선택 pending
{
  const G = mk(50001); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'under-attack');
  assert(G.sideSchemes.some(s => s.uid === ss.uid), '공격 받는 중: 사이드 스킴 배치');
  assert(ss.threat === 3, '시작 위협 3(고정)');
  assert(G.pending && G.pending.kind === 'revealChoice', '각 플레이어 선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (위협/피해)');
}

// ② 위협 선택: 이 스킴에 위협 +2
{
  const G = mk(50002); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'under-attack');
  const t0 = ss.threat, hp0 = pl.hp;
  MC.dispatch(G, { type:'resolveRevealChoice', option:'threat' });
  assert(ss.threat === t0 + 2, '위협 선택: 이 스킴 위협 +2 (' + t0 + '→' + ss.threat + ')');
  assert(pl.hp === hp0, '히어로 피해 없음');
  assert(!G.pending, '선택 해소 (1인)');
}

// ③ 피해 선택: 자기 히어로에 피해 3
{
  const G = mk(50003); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'under-attack');
  const t0 = ss.threat, hp0 = pl.hp;
  MC.dispatch(G, { type:'resolveRevealChoice', option:'damage' });
  assert(pl.hp === hp0 - 3, '피해 선택: 히어로 피해 3 (' + hp0 + '→' + pl.hp + ')');
  assert(ss.threat === t0, '스킴 위협 불변');
}

// ④ 완성(whenCompleted) 연출 발화
{
  const G = mk(50004); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'under-attack');
  if (G.pending) MC.dispatch(G, { type:'resolveRevealChoice', option:'threat' });
  G.fxCardEffect = null;
  MC.fireCardHook(G, ss, 'whenCompleted', {});
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'underAttackCleared', '완성: 위기 해소 연출');
}

console.log('══ 공격 받는 중 (eachPlayerChoice) 회귀 통과 ══');
