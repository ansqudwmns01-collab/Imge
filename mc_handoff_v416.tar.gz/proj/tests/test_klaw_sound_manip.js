/* test_klaw_sound_manip.js — 음파 조작(01124) 폼 분기 배신 회귀
   ★ 범용 인덱스(formBranch/healVillain/dealDamage/surge+cond healedNone/playVfx)로 데이터 실행.
   - 히어로: 히어로 2 피해 + 클로 2 회복
   - 알터에고: 클로 4 회복 (회복량 0이면 급증)
   사용: node tests/test_klaw_sound_manip.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const deck = MC.PRESET_DECKS.spiderman.cards.slice();
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: deck }],
    villainCode:'01114', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function fire(G, pl){
  const inst = MC.makeInstance(G, 'sound-manipulation', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}

// 조건 등록
assert(MC.condCheck({ _lastHealDone: 0 }, { type:'healedNone' }, {}) === true, 'condCheck healedNone: 회복 0 → true');
assert(MC.condCheck({ _lastHealDone: 3 }, { type:'healedNone' }, {}) === false, 'condCheck healedNone: 회복 3 → false');

// 히어로 분기 — 히어로 2 피해 + 클로 2 회복
{
  const G = mk(2601); const pl = G.players[0]; pl.form = 'hero';
  G.villain.hp = G.villain.maxHp - 5;
  const hp0 = pl.hp, vhp0 = G.villain.hp;
  fire(G, pl);
  assert(pl.hp === hp0 - 2, '히어로: 히어로 2 피해 (' + hp0 + '→' + pl.hp + ')');
  assert(G.villain.hp === vhp0 + 2, '히어로: 클로 2 회복 (' + vhp0 + '→' + G.villain.hp + ')');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'sonicHeal', '히어로: 음파 치유 연출(sonicHeal)');
}

// 알터에고 분기 (상처 있음) — 클로 4 회복, 급증 없음
{
  const G = mk(2602); const pl = G.players[0]; pl.form = 'alter';
  G.villain.hp = G.villain.maxHp - 6;
  const vhp0 = G.villain.hp;
  const inst = fire(G, pl);
  assert(G.villain.hp === vhp0 + 4, '알터에고(상처): 클로 4 회복 (' + vhp0 + '→' + G.villain.hp + ')');
  assert(!inst.surge, '알터에고(상처): 회복 있었으므로 급증 없음');
}

// 알터에고 분기 (풀피) — 회복 0 → 급증
{
  const G = mk(2603); const pl = G.players[0]; pl.form = 'alter';
  G.villain.hp = G.villain.maxHp;
  const vhp0 = G.villain.hp;
  const inst = fire(G, pl);
  assert(G.villain.hp === vhp0, '알터에고(풀피): 회복 0 (HP 불변)');
  assert(inst.surge === true, '알터에고(풀피): 회복 0 → 급증(surge) 획득');
}

console.log('══ 음파 조작 (데이터 기반 폼분기+조건부 급증) 회귀 통과 ══');
