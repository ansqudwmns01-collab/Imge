/* test_ultron_villain.js — 울트론 빌런(01134~136) 3스테이지 강제효과 회귀
   ★ 신규 엔진: forcedAttackChoice(01134 공격 후 선택: 위협/드론),
     villainAttackSpawnDrone + attackBonusPerDrone(01135 공격 시 드론+ATK),
     invulnWhileDrone(01136 드론 있으면 무적) + droneBuffVillain(드론 전역 버프),
     ultronStage3Reveal(울트론의 명령 탐색). 스테이지 전환(advanceVillainStage).
   사용: node tests/test_ultron_villain.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
// 울트론 빌런으로 게임 구성 (메인 스킴은 라이노 것 재사용 — 빌런 강제효과만 검증)
function mk(seed, stageCode){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode: stageCode || '01134', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function spawnDrones(G, pl, n){
  G.environments = G.environments || [];
  if (!G.environments.length) G.environments.push(MC.makeInstance(G, 'ultron-drones', {}));
  const out = []; for (let i=0;i<n;i++) out.push(MC.spawnFacedownDrone(G, pl)); return out;
}

// ── 스탯 확인
{
  const G = mk(30001);
  assert(G.villain.hp === 17, '울트론 I: HP 17 (1인)');
  assert(G.villain.attack === 2 && G.villain.scheme === 1, 'ATK2/SCH1');
}

// ① 01134 강제반응: 공격 후 선택 pending (위협/드론)
{
  const G = mk(30002); const pl = G.players[0]; pl.form = 'hero';
  // 빌런 공격 pending 직접 구성 후 해소 → forcedAttackChoice 발동
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: 2, prevented: 0 };
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(G.pending && G.pending.kind === 'revealChoice', '01134: 공격 후 선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (위협/드론)');
  // 위협 선택
  const mt0 = MC.resolveScheme(G, 'main').threat;
  MC.dispatch(G, { type:'resolveRevealChoice', option:'threat' });
  assert(MC.resolveScheme(G, 'main').threat === mt0 + 1, '위협 선택: 메인 위협 +1');
  assert(!G.pending, '선택 해소');
}
// ①-2 드론 선택
{
  const G = mk(30003); const pl = G.players[0]; pl.form = 'hero';
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: 2, prevented: 0 };
  MC.resolveDefensePending(G, pl.uid, 'none');
  MC.dispatch(G, { type:'resolveRevealChoice', option:'drone' });
  assert(pl.engagedMinions.some(m => m.isDrone), '드론 선택: 뒷면 드론 등장');
}

// ② 01135 강제개입: 공격 시 드론 스폰 + 교전 드론당 ATK+1
{
  const G = mk(30010, '01135'); const pl = G.players[0]; pl.form = 'hero';
  assert(G.villain.hp === 22, '울트론 II: HP 22');
  // 기존 교전 드론 1명
  spawnDrones(G, pl, 1);
  // 빌런 활성화(공격) — enemyActivation 경유
  G.phase = 'villain';
  MC.dispatch ? null : null;
  // 직접 enemyActivation 호출 대신 vq activations 태우기
  G.vq.push({ op:'act', enemyUid: G.villain.uid, player: pl.uid });
  MC.processVillainQueue(G);
  assert(G.pending && G.pending.kind === 'defense', '울트론 II 공격: 방어 pending');
  // 공격 시 드론 1명 추가 스폰 → 교전 드론 2명 → ATK 2(기본) + 2(드론) = 4
  const drones = pl.engagedMinions.filter(m => m.isDrone).length;
  assert(drones === 2, '공격 시 드론 1명 증원 → 교전 드론 2명 (실제 ' + drones + ')');
  assert(G.pending.amount === 2 + 2, '교전 드론 2명만큼 ATK +2 → 공격 4 (실제 ' + G.pending.amount + ')');
}

// ③ 01136 무적: 드론 있으면 빌런 피해 무효
{
  const G = mk(30020, '01136'); const pl = G.players[0];
  assert(G.villain.hp === 27, '울트론 III: HP 27');
  spawnDrones(G, pl, 1);
  const hp0 = G.villain.hp;
  const done = MC.applyDamage(G, G.villain, 5, { source: pl, isAttack: true });
  assert(done === 0 && G.villain.hp === hp0, '드론 존재: 울트론 피해 무효 (무적)');
  // 드론 제거 후엔 피해 통과
  pl.engagedMinions = pl.engagedMinions.filter(m => !m.isDrone);
  const done2 = MC.applyDamage(G, G.villain, 5, { source: pl, isAttack: true });
  assert(done2 === 5 && G.villain.hp === hp0 - 5, '드론 없으면 피해 통과');
}

// ④ 01136 드론 전역 버프: 드론 ATK/HP +1 (환경 스탯에 얹힘)
{
  const G = mk(30030, '01136'); const pl = G.players[0];
  const [d] = spawnDrones(G, pl, 1);   // 환경 droneStats(1/1/1) + 빌런 buff(+1atk/+1hp)
  MC.recalcDroneStats(G);
  assert(d.attack === 2 && d.maxHp === 2, '울트론 III 지속: 드론 ATK2/HP2 (환경1 + 빌런버프1)');
}

// ⑤ 01136 공개 시: 울트론의 명령 사이드 스킴 탐색 공개
{
  const G = mk(30040, '01136'); const pl = G.players[0];
  G.encounterDeck = [MC.makeInstance(G, 'ultrons-imperative', {}), MC.makeInstance(G, 'im-tough', {})];
  MC.fireCardHook(G, G.villain, 'whenRevealed', { villain: G.villain });
  assert(G.sideSchemes.some(s => s.defCode === 'ultrons-imperative'), '01136 공개: 울트론의 명령 사이드 스킴 공개');
}

// ⑥ 스테이지 전환: 01134 격파 → 01135로 (nextStage 연결)
{
  const G = mk(30050); 
  MC.advanceVillainStage(G);
  assert(G.villain.defCode === '01135', '01134 → 01135 스테이지 전환');
  assert(G.villain.hp === 22, '전환 후 HP 22 (스테이지2 만피)');
}

console.log('══ 울트론 빌런 (3스테이지 강제효과) 회귀 통과 ══');
