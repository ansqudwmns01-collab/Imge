/* test_under_attack_attach.js — 비브라늄 갑옷(01152)/충격파 블라스터(01153) 회귀
   ★ grantsToughOnDamage(피해 후 tough 부여, applyDamage 배선) + attachStats.retaliate(기존 보복 재사용)
     + removeAbility(소진+자원 제거).
   사용: node tests/test_under_attack_attach.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 비브라늄 갑옷: 빌런 피해 후 tough 부여 (생존 시)
{
  const G = mk(51001); const pl = G.players[0]; pl.form = 'hero';
  const arm = MC.makeInstance(G, 'vibranium-armor-u', {});
  MC.attachTo(G, arm, G.villain);
  G.villain.hp = 20; G.villain.status = { stunned:0, confused:0, tough:0 };
  MC.applyDamage(G, G.villain, 3, { source: pl, isAttack: true });
  assert(G.villain.status.tough === 1, '피해 후 강인(Tough) 부여');
  assert(G.villain.hp === 17, '피해 3 적용');
  // 다시 피해 → tough가 먼저 흡수(무피해), 그 후 또 tough 부여
  MC.applyDamage(G, G.villain, 3, { source: pl, isAttack: true });
  assert(G.villain.hp === 17, 'tough가 다음 피해 흡수 (무피해)');
}

// ① -2 처치 시엔 tough 부여 안 함
{
  const G = mk(51002); const pl = G.players[0]; pl.form = 'hero';
  const arm = MC.makeInstance(G, 'vibranium-armor-u', {});
  MC.attachTo(G, arm, G.villain);
  G.villain.hp = 3; G.villain.status = { stunned:0, confused:0, tough:0 };
  MC.applyDamage(G, G.villain, 5, { source: pl, isAttack: true });
  // 클로 I 처치 → 스테이지 전환(01114). 처치 시엔 tough 부여 안 함(전환된 빌런 tough 0).
  assert(G.villain.defCode === '01114', '치명 피해: 처치→스테이지 전환');
  assert((G.villain.status.tough||0) === 0, '처치 시 tough 부여 안 함');
}

// ② 비브라늄 갑옷 제거: 소진 + 💪💪
{
  const G = mk(51003); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const arm = MC.makeInstance(G, 'vibranium-armor-u', {});
  MC.attachTo(G, arm, G.villain);
  const pay = [];
  for (let i=0;i<2;i++){ const c = MC.makeInstance(G, 'uppercut', {}); c.ownerUid = pl.uid; pl.hand.push(c); pay.push({kind:'hand',uid:c.uid}); }  // physical
  MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: arm.uid, payment: pay });
  assert(!G.villain.attachments.some(a => a.uid === arm.uid), '비브라늄 갑옷 제거');
  assert(pl.exhausted === true, '히어로 소진');
}

// ③ 충격파 블라스터: 빌런에 보복 1 부여 (피해받은 후 공격자에 1 피해)
{
  const G = mk(51004); const pl = G.players[0]; pl.form = 'hero';
  const blast = MC.makeInstance(G, 'concussion-blasters', {});
  MC.attachTo(G, blast, G.villain);
  assert((G.villain.retaliate||0) >= 1, '빌런 보복 1 부여 (attachStats.retaliate)');
  G.villain.hp = 20; const php = pl.hp;
  MC.applyDamage(G, G.villain, 3, { source: pl, isAttack: true });
  assert(pl.hp === php - 1, '보복: 공격한 히어로에 1 피해');
  // 제거 시 보복 원복
  MC.detachFrom(G, blast);
  assert((G.villain.retaliate||0) === 0, '제거: 보복 원복');
}

// ④ 충격파 블라스터 제거: 소진 + ⚡⚡
{
  const G = mk(51005); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const blast = MC.makeInstance(G, 'concussion-blasters', {});
  MC.attachTo(G, blast, G.villain);
  const pay = [];
  for (let i=0;i<2;i++){ const c = MC.makeInstance(G, 'relentless-assault', {}); c.ownerUid = pl.uid; pl.hand.push(c); pay.push({kind:'hand',uid:c.uid}); }  // energy
  MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: blast.uid, payment: pay });
  assert(!G.villain.attachments.some(a => a.uid === blast.uid), '충격파 블라스터 제거');
}

console.log('══ Under Attack 부착물 (tough재생성/보복) 회귀 통과 ══');
