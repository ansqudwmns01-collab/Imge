/* test_dataify_reverify.js — 커스텀 핸들러 데이터화 리팩터 보호 (영구 회귀)
   ①순수래퍼 6 + ②공통fx(searchDeckToHand/buffAttachedAlly/refreshMaxHp) + targetStatus cond.
   사용: node tests/test_dataify_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mk(hero, deck){
  const G = MC.makeGameState({ seed:2,
    players:[{ heroCode: hero, deckCodes: deck }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') });
  MC.setupGame(G); return G;
}
const BP = () => MC.PRESET_DECKS['black-panther'].cards.slice();

/* ── searchDeckToHand: shuri(업그레이드 탐색) ── */
{
  const G = mk('01040a', BP()); const pl = G.players[0]; pl.form = 'hero';
  const upInDeck = pl.deck.filter(c => MC.cardDef(c.defCode).type === 'upgrade').length;
  const sh = MC.makeInstance(G, 'shuri', {});
  MC.fireCardHook(G, sh, 'whenPlayed', { player: pl, self: sh, card: sh });
  assert(upInDeck === 0 || pl.hand.some(c => MC.cardDef(c.defCode).type === 'upgrade'),
    'searchDeckToHand(shuri) — 덱 업그레이드를 손으로');
}
/* bpForesight: 01040b 셋업 시 BP 업그레이드 손에 */
{
  const G = mk('01040a', BP()); const pl = G.players[0];
  assert(pl.hand.some(c => { const d = MC.cardDef(c.defCode); return d && d.type === 'upgrade' && (d.traits||[]).includes('black panther'); }),
    'searchDeckToHand(bpForesight) — 셋업 시 BP 업그레이드 손에');
}
/* capShieldSetup: 방패(03009) — 덱/버림더미 탐색 */
{
  const deck = ['cap-shield']; for (let i=0;i<40;i++) deck.push('energy');
  const G = mk('03001a', deck); const pl = G.players[0];
  assert(pl.hand.some(c => MC.cardDef(c.defCode).mcode === '03009'), 'searchDeckToHand(capShield) — 셋업 시 방패 손에');
}
{ // includeDiscard 분기
  const deck = []; for (let i=0;i<40;i++) deck.push('energy');
  const G = mk('03001a', deck); const pl = G.players[0];
  pl.hand = pl.hand.filter(c => MC.cardDef(c.defCode).mcode !== '03009');
  pl.discard.push(MC.makeInstance(G, 'cap-shield', {}));
  MC.runEffectList(G, [{ fx:'searchDeckToHand', filters:[{ mcode:'03009' }], includeDiscard:true }], { player: pl });
  assert(pl.hand.some(c => MC.cardDef(c.defCode).mcode === '03009'), 'searchDeckToHand — includeDiscard(버림더미 탐색)');
}

/* ── buffAttachedAlly: enraged/inspired ── */
{
  const G = mk('01040a', BP()); const pl = G.players[0]; pl.form = 'hero';
  const ally = MC.makeInstance(G, 'hulk-ally', {}); const a0 = ally.attack||0, c0 = ally.atkCost||0;
  const en = MC.makeInstance(G, 'enraged', {});
  MC.fireCardHook(G, en, 'whenPlayed', { player: pl, self: en, card: en, targets:[ally] });
  assert(ally.attack === a0 + 2 && ally.atkCost === c0 + 1, 'buffAttachedAlly(enraged) — 동료 ATK+2/부수+1');
}
{
  const G = mk('01040a', BP()); const pl = G.players[0]; pl.form = 'hero';
  const ally = MC.makeInstance(G, 'hulk-ally', {}); const a0 = ally.attack||0, t0 = ally.thwart||0;
  const ins = MC.makeInstance(G, 'inspired', {});
  MC.fireCardHook(G, ins, 'whenPlayed', { player: pl, self: ins, card: ins, targets:[ally] });
  assert(ally.attack === a0 + 1 && ally.thwart === t0 + 1, 'buffAttachedAlly(inspired) — 동료 ATK+1/THW+1');
}

/* ── refreshMaxHp: mk5-armor(+6)/rocket-boots(+1) ── */
{
  const G = mk('01029a', MC.PRESET_DECKS['iron-man'].cards.slice()); const pl = G.players[0]; pl.form = 'hero';
  const mh0 = pl.maxHp; const c = MC.makeInstance(G, 'mk5-armor', {}); pl.playArea.upgrades.push(c);
  MC.fireCardHook(G, c, 'whenPlayed', { player: pl, self: c, card: c });
  assert(pl.maxHp === mh0 + 6, 'refreshMaxHp(mk5-armor) — maxHp +6');
}
{
  const G = mk('01029a', MC.PRESET_DECKS['iron-man'].cards.slice()); const pl = G.players[0]; pl.form = 'hero';
  const mh0 = pl.maxHp; const c = MC.makeInstance(G, 'rocket-boots', {}); pl.playArea.upgrades.push(c);
  MC.fireCardHook(G, c, 'whenPlayed', { player: pl, self: c, card: c });
  assert(pl.maxHp === mh0 + 1, 'refreshMaxHp(rocket-boots) — maxHp +1');
}

/* ── targetStatus cond + 급증-무효 (im-tough/false-alarm/hard-to-keep-down) ── */
function mkR(){ const G = MC.makeGameState({ seed:1, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }], villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') }); MC.setupGame(G); return G; }
function rev(G, pl, code){ const c = MC.makeInstance(G, code, {}); MC.fireCardHook(G, c, 'whenRevealed', { player: pl, self: c, card: c }); return c; }
{ const G = mkR(); const pl = G.players[0]; pl.form='hero'; if (G.villain.status) G.villain.status.tough = 0; rev(G, pl, 'im-tough');
  assert((G.villain.status.tough||0) > 0, 'im-tough 데이터 — Tough 부여'); }
{ const G = mkR(); const pl = G.players[0]; pl.form='hero'; MC.setStatus(G, G.villain, 'tough', true); const c = rev(G, pl, 'im-tough');
  assert(c.surge === true, 'im-tough 데이터 — 이미 Tough면 급증(targetStatus cond)'); }
{ const G = mkR(); const pl = G.players[0]; pl.form='hero'; if (pl.status) pl.status.confused = 0; rev(G, pl, 'false-alarm');
  assert((pl.status.confused||0) > 0, 'false-alarm 데이터 — 혼란 부여'); }
{ const G = mkR(); const pl = G.players[0]; pl.form='hero'; MC.setStatus(G, pl, 'confused', true); const c = rev(G, pl, 'false-alarm');
  assert(c.surge === true, 'false-alarm 데이터 — 이미 혼란이면 급증(targetStatus cond)'); }
{ const G = mkR(); const pl = G.players[0]; pl.form='hero'; G.villain.hp = G.villain.maxHp; const c = rev(G, pl, 'hard-to-keep-down');
  assert(c.surge === true, 'hard-to-keep-down 데이터 — 풀피면 급증(healedNone cond)'); }

console.log('\n[test_dataify_reverify] ' + pass + '개 통과 — 데이터화 리팩터 보호');
