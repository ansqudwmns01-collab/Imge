/* test_retaliate_index.js — 보복 집계 인덱스(passiveRetaliate) 통일 검증 (영구 회귀)
   statMod↔passiveStatMod 대칭. 모든 보복 소스가 단일 집계 함수로 수렴:
   ① 적 인스턴스 retaliate  ② 히어로 신분 인쇄(BP)  ③ 비부착 업그레이드 grantsRetaliate(cap-shield)
   ④ 부착물 attachStats.retaliate(attachTo로 인스턴스에 반영)
   사용: node tests/test_retaliate_index.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mk(hero){
  const G = MC.makeGameState({ seed:2, players:[{ heroCode: hero, deckCodes: Array(20).fill('energy') }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') });
  MC.setupGame(G); return G;
}

assert(typeof MC.passiveRetaliate === 'function', 'passiveRetaliate 집계 인덱스 존재');

// ② 블랙팬서 신분 인쇄 보복 (히어로 폼만)
{
  const G = mk('01040a'); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  assert(MC.passiveRetaliate(G, pl) === 1, 'BP 신분 보복 = 1 (히어로 폼)');
  const vhp0 = G.villain.hp; pl.hp = 20; MC.applyDamage(G, pl, 3, { source: G.villain, isAttack:true });
  assert(G.villain.hp === vhp0 - 1, 'BP 공격받음 → 보복 1 발동');
}
// 알터에고 폼에선 신분 보복 없음
{
  const G = mk('01040a'); const pl = G.players[0];
  assert(MC.passiveRetaliate(G, pl) === 0, 'BP 알터에고 폼 → 신분 보복 0');
}
// ③ 비부착 업그레이드 grantsRetaliate (cap-shield)
{
  const G = mk('03001a'); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const sh = MC.makeInstance(G, 'cap-shield', {}); sh.ownerUid = pl.uid; pl.playArea.upgrades.push(sh);
  assert(MC.passiveRetaliate(G, pl) === 1, 'cap-shield 업그레이드 보복 = 1');
}
// 중첩: 신분 + 업그레이드
{
  const G = mk('01040a'); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const sh = MC.makeInstance(G, 'cap-shield', {}); sh.ownerUid = pl.uid; pl.playArea.upgrades.push(sh);
  assert(MC.passiveRetaliate(G, pl) === 2, '신분(1) + 업그레이드(1) 중첩 = 2');
}
// ① 적 인스턴스 보복
{
  const G = mk('01001a'); const m = MC.makeInstance(G, 'omega-red', {});
  assert(MC.passiveRetaliate(G, m) >= 1, '적 인스턴스 보복(omega-red)');
}
// ④ 부착물 attachStats.retaliate → attachTo가 인스턴스에 반영 → 집계에 포함
{
  const G = mk('01001a'); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const ally = MC.makeInstance(G, 'hulk-ally', {}); pl.playArea.allies.push(ally);
  const r0 = MC.passiveRetaliate(G, ally);
  const att = MC.makeInstance(G, 'solid-sound-body', {});
  if (MC.cardDef('solid-sound-body') && MC.cardDef('solid-sound-body').attachStats && MC.cardDef('solid-sound-body').attachStats.retaliate){
    MC.attachTo(G, att, ally);
    assert(MC.passiveRetaliate(G, ally) === r0 + 1, '부착물 attachStats.retaliate → 집계 포함');
  } else {
    assert(true, '부착물 보복 카드 확인(스킵 — 데이터 없음)');
  }
}

console.log('\n[test_retaliate_index] ' + pass + '개 통과 — 보복 집계 인덱스 통일');
