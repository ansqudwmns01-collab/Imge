/* test_exhaustion_masterplan.js — Exhaustion(01191) + Masterplan(01192) 배신 회귀
   ★ Exhaustion: surge + 신분 소진.
   ★ Masterplan: 사이드 스킴 있으면 각각 위협 4 / 없으면 조우덱에서 사이드 스킴 탐색·공개.
   사용: node tests/test_exhaustion_masterplan.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed: seed || 1,
    players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','advance','assault'] });
  MC.setupGame(G);
  return G;
}
function reveal(G, slug, pl){
  const inst = MC.makeInstance(G, slug, {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl || G.players[G.firstPlayer] });
  return inst;
}

// ── Exhaustion(01191) ──
// ① 공개 시 신분 소진 + surge
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = reveal(G, 'exhaustion', pl);
  assert(pl.exhausted === true, 'Exhaustion: 신분 카드 소진');
  assert(inst.surge === true, 'Exhaustion: surge 획득');
}
// ② db 필드 확인 (mcode/boost)
{
  const d = MC.CARDS['exhaustion'];
  assert(d.mcode === '01191', 'Exhaustion mcode 01191');
  assert(d.boost === 2, 'Exhaustion boost 2');
}

// ── Masterplan(01192) ──
// ③ 사이드 스킴이 있으면 각각 위협 4
{
  const G = mk(); const pl = G.players[0];
  // 사이드 스킴 2개 전장에 배치
  const ss1 = MC.makeInstance(G, 'under-attack', {}); ss1.threat = 1;
  const ss2 = MC.makeInstance(G, 'invasive-ai', {}); ss2.threat = 0;
  G.sideSchemes = [ss1, ss2];
  reveal(G, 'masterplan', pl);
  assert(ss1.threat === 5, 'Masterplan: 사이드 스킴1 위협 +4 (1→5, 실제 ' + ss1.threat + ')');
  assert(ss2.threat === 4, 'Masterplan: 사이드 스킴2 위협 +4 (0→4, 실제 ' + ss2.threat + ')');
}
// ④ 사이드 스킴이 없으면 조우덱에서 사이드 스킴 탐색·공개
{
  const G = mk(); const pl = G.players[0];
  G.sideSchemes = [];
  // 조우덱에 사이드 스킴 하나 심기 (맨 아래) + 앞에 배신 몇 장
  const buried = MC.makeInstance(G, 'under-attack', {});
  const filler1 = MC.makeInstance(G, 'advance', {});
  const filler2 = MC.makeInstance(G, 'assault', {});
  G.encounterDeck = [buried, filler1, filler2];   // pop()은 끝에서 → filler2, filler1 버려진 뒤 buried(사이드스킴) 공개
  const disc0 = G.encounterDiscard.length;
  reveal(G, 'masterplan', pl);
  assert((G.sideSchemes || []).some(s => s.defCode === 'under-attack'), 'Masterplan: 조우덱에서 사이드 스킴 탐색·공개');
  assert(G.encounterDiscard.length > disc0, 'Masterplan: 사이드 스킴 전까지 카드 버림');
}
// ⑤ 사이드 스킴도 없고 조우덱에도 없으면 안전 불발
{
  const G = mk(); const pl = G.players[0];
  G.sideSchemes = [];
  G.encounterDeck = [MC.makeInstance(G, 'advance', {})];   // 사이드 스킴 없음
  G.encounterDiscard = [];
  reveal(G, 'masterplan', pl);
  assert((G.sideSchemes || []).length === 0, 'Masterplan: 사이드 스킴 없으면 안전 불발 (크래시 없음)');
}
// ⑥ db 필드 확인
{
  const d = MC.CARDS['masterplan'];
  assert(d.mcode === '01192', 'Masterplan mcode 01192');
  assert(d.boost === 2, 'Masterplan boost 2');
}

console.log('══ Exhaustion + Masterplan 회귀 통과 ══');
