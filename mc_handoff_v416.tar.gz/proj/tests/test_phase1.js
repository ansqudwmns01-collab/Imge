/* test_phase1.js — 핵심 룰 프레임 검증 (playCard·기본 파워·방어·다단계)
   사용: node tests/test_phase1.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

/* 테스트 픽스처: 수호 하수인 (실카드 아님 — 테스트 전용 등록) */
MC.registerCards({
  'T-GUARD': { code:'T-GUARD', side:'encounter', type:'minion', name:'수호 픽스처',
    hp:3, attack:1, scheme:0, guard:true },
});

let fail = 0;
function check(name, ok, extra){ console.log((ok?'✓':'✗') + ' ' + name + (ok?'':('  ← '+(extra||''))));
  if(!ok) fail++; }
function throws(name, fn, msgPart){
  try { fn(); check(name, false, 'throw 없음'); }
  catch(e){ check(name, !msgPart || e.message.includes(msgPart), e.message); }
}

function newGame(n, seed){
  const deck = [];
  for (let i=0;i<12;i++) deck.push('backflip');       // 물리 1
  for (let i=0;i<12;i++) deck.push('swinging-web-kick');       // 정신 1
  deck.push('black-cat');                                // 블랙캣
  const G = MC.makeGameState({
    seed: seed||7,
    players: Array.from({length:n}, () => ({ heroCode:'01001a', deckCodes: deck.slice() })),
    villainCode:'01094', mainScheme:'01097b',
    encounterCodes: Array(12).fill('hydra-mercenary'),
  });
  MC.setupGame(G);
  return G;
}
function handUids(pl, code, n){
  const out = pl.hand.filter(c => c.defCode === code).slice(0, n).map(c => c.uid);
  if (out.length < n) throw new Error('픽스처 부족: ' + code);
  return out;
}
function fillHandWith(G, pl, code){ // 손패를 특정 카드로 보정 (덱에서 끌어옴)
  const need = [];
  for (const c of pl.deck) if (c.defCode === code) need.push(c);
  pl.hand.push(...need.splice(0, 8));
  pl.deck = pl.deck.filter(c => !pl.hand.includes(c));
}

/* ── 1. playCard: 결제·이벤트 효과 ── */
{
  const G = newGame(1);
  const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true }); // 히어로 액션(웹킥)
  fillHandWith(G, pl, 'swinging-web-kick'); fillHandWith(G, pl, 'backflip');
  const kick = pl.hand.find(c => c.defCode === 'swinging-web-kick');
  const pay = handUids(pl, 'backflip', 2).concat(handUids(pl, 'swinging-web-kick', 2).filter(u => u !== kick.uid).slice(0,1));
  const hpBefore = G.villain.hp;
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid: kick.uid, paymentUids: pay, targets:[G.villain.uid] });
  check('스윙 웹 킥: 빌런 피해 8', G.villain.hp === hpBefore - 8, G.villain.hp);
  check('이벤트는 버림 더미로', pl.discard.some(c => c.uid === kick.uid));
  check('결제 카드 3장 버림', pl.discard.length >= 4);
  // 자원 부족
  const kick2 = pl.hand.find(c => c.defCode === 'swinging-web-kick');
  throws('자원 부족 시 거부', () => MC.dispatch(G, { type:'playCard', player:'P0', cardUid: kick2.uid,
    paymentUids: handUids(pl, 'backflip', 1), targets:[G.villain.uid] }), '자원 부족');
  check('거부 시 손패 무변이', pl.hand.some(c => c.uid === kick2.uid));
}

/* ── 2. 동료: 플레이·저지 후유증·유니크 ── */
{
  const G = newGame(1);
  const pl = G.players[0];
  fillHandWith(G, pl, 'black-cat'); fillHandWith(G, pl, 'backflip');
  const cat = pl.hand.find(c => c.defCode === 'black-cat');
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid: cat.uid, paymentUids: handUids(pl,'backflip',2) });
  check('블랙캣 플레이 영역 진입', pl.playArea.allies.length === 1);
  G.mainScheme.threat = 5;
  MC.dispatch(G, { type:'allyThwart', player:'P0', allyUid: cat.uid, scheme:'main' });
  const catInst = pl.playArea.allies[0];
  check('동료 저지: 위협 -1', G.mainScheme.threat === 4, G.mainScheme.threat);
  check('저지 후유증 피해 1 (HP 2→1)', catInst.hp === 1, catInst.hp);
  check('동료 소진', catInst.exhausted === true);
}

/* ── 3. 기본 파워: 공격/저지/회복 + 소진/형태 검증 ── */
{
  const G = newGame(1);
  const pl = G.players[0];
  throws('알터에고 상태 기본 공격 거부', () => MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid:G.villain.uid }), '영웅 형태');
  pl.hp = 5;
  MC.dispatch(G, { type:'basicRecover', player:'P0' });
  check('기본 회복: REC 3 (5→8)', pl.hp === 8, pl.hp);
  throws('소진 상태 재활성화 거부', () => MC.dispatch(G, { type:'basicRecover', player:'P0' }), '소진');
  MC.dispatch(G, { type:'flipForm', player:'P0' });
  throws('라운드 내 재flip 거부', () => MC.dispatch(G, { type:'flipForm', player:'P0' }), '이미 형태');
  pl.exhausted = false;
  const hpB = G.villain.hp;
  MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid: G.villain.uid });
  check('기본 공격: ATK 2', G.villain.hp === hpB - 2, G.villain.hp);
  pl.exhausted = false;
  G.mainScheme.threat = 3;
  MC.dispatch(G, { type:'basicThwart', player:'P0', scheme:'main' });
  check('기본 저지: THW 1 (3→2)', G.mainScheme.threat === 2, G.mainScheme.threat);
}

/* ── 4. 기절/혼란: 활성화 소모 ── */
{
  const G = newGame(1);
  const pl = G.players[0];
  MC.dispatch(G, { type:'flipForm', player:'P0' });
  pl.status.stunned = 1;
  const hpB = G.villain.hp;
  MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid: G.villain.uid });
  check('기절: 공격 대신 토큰 제거', G.villain.hp === hpB && pl.status.stunned === 0 && pl.exhausted);
  pl.exhausted = false; pl.status.confused = 1;
  G.mainScheme.threat = 3;
  MC.dispatch(G, { type:'basicThwart', player:'P0', scheme:'main' });
  check('혼란: 저지 대신 토큰 제거', G.mainScheme.threat === 3 && pl.status.confused === 0);
}

/* ── 5. 수호 ── */
{
  const G = newGame(1);
  const pl = G.players[0];
  MC.dispatch(G, { type:'flipForm', player:'P0' });
  const guard = MC.makeInstance(G, 'T-GUARD', { engagedWith:'P0' });
  pl.engagedMinions.push(guard);
  throws('수호: 빌런 공격 차단', () => MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid:G.villain.uid }), '수호');
  // ★ 룰 정정: 가드는 빌런 "공격"만 제한 — 메인 스킴 저지는 허용 (저지 차단은 순찰 키워드)
  MC.dispatch(G, { type:'basicThwart', player:'P0', scheme:'main' });
  check('수호: 메인 스킴 저지는 허용 (공식 룰)', true);
  pl.exhausted = false;
  guard.patrol = true;
  throws('순찰: 메인 스킴 저지 차단', () => MC.dispatch(G, { type:'basicThwart', player:'P0', scheme:'main' }), '순찰');
  guard.patrol = false;
  MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid: guard.uid });
  check('수호 하수인 자체는 공격 가능 (HP 3→1)', guard.hp === 1, guard.hp);
}

/* ── 6. 방어 선언: 대기→해소 ── */
{
  const G = newGame(1, 11);
  const pl = G.players[0];
  MC.dispatch(G, { type:'flipForm', player:'P0' }); // 영웅형 → 빌런이 공격
  MC.dispatch(G, { type:'endPlayerPhase' });
  check('방어 대기 발생', G.pending && G.pending.kind === 'defense');
  const amount = G.pending.amount;
  const hpB = pl.hp;
  const roundBefore = G.round;
  MC.dispatch(G, { type:'resolveDefense', player:'P0', defender:'identity' });
  const expected = Math.max(0, amount - 3); // 스파이더맨 DEF 3
  check('신분 방어: 피해 ' + amount + '-3', pl.hp === hpB - expected, pl.hp);
  // ★ 방어자 소진: 빌런 페이즈에 방어로 소진한 카드는 라운드가 넘어가도(다음 플레이어 페이즈까지) 소진 유지 (공식 RRG).
  //   준비/드로우는 플레이어 페이즈 종료(endPlayerPhase)에서만 일어나므로, 방어 직후엔 항상 소진 상태여야 함.
  check('방어자 소진 유지 (라운드 넘어가도 다음 플레이어 페이즈까지)',
        pl.exhausted === true,
        'round '+roundBefore+'→'+G.round+' exhausted='+pl.exhausted);
  check('페이즈 정상 재개 (pending 해소)', !G.pending || G.pending.kind === 'defense');
  while (G.pending) MC.dispatch(G, { type:'resolveDefense', player:'P0', defender:'none' });
  check('라운드 종료 후 플레이어 페이즈 복귀', G.phase === 'player' && G.round === 2);
}

/* ── 7. 무방어 = 전량 피해 / 알터에고 = 스킴 ── */
{
  const G = newGame(1, 13);
  MC.dispatch(G, { type:'flipForm', player:'P0' });
  MC.dispatch(G, { type:'endPlayerPhase' });
  const pl = G.players[0], hpB = pl.hp, amount = G.pending.amount;
  // ★ 룰북: 부스트는 방어 선언 후 공개·합산 (pending.amount는 기본 ATK만)
  const boostVal = G.pending.boostCard ? (G.pending.boostCard.boost || 0) : 0;
  MC.dispatch(G, { type:'resolveDefense', player:'P0', defender:'none' });
  check('무방어: 전량 피해 (기본+부스트)', pl.hp === hpB - amount - boostVal, pl.hp);
  while (G.pending) MC.dispatch(G, { type:'resolveDefense', player:'P0', defender:'none' });

  const G2 = newGame(1, 17); // 알터에고 유지
  const thrB = G2.mainScheme.threat;
  MC.dispatch(G2, { type:'endPlayerPhase' });
  check('알터에고: 방어 대기 없음(스킴)', !G2.pending);
  check('위협 증가 (배치+빌런 스킴)', G2.mainScheme.threat > thrB, G2.mainScheme.threat);
}

/* ── 8. 빌런 다단계 전환 ── */
{
  const G = newGame(2);
  G.villainFinalStageNum = 3;   // 스테이지 메커니즘 검증용: III까지 진행 허용
  MC.applyDamage(G, G.villain, 28, {}); // 14×2 = 28
  check('라이노 2단계 전환', G.villain.defCode === '01095');
  check('2단계 HP 리셋 (15×2=30)', G.villain.hp === 30, G.villain.hp);
  check('2단계 ATK 3', G.villain.attack === 3);
  MC.applyDamage(G, G.villain, 30, {});
  check('3단계 전환 (ATK 4)', G.villain.defCode === '01096' && G.villain.attack === 4);
  // 3단계 라이노는 Toughness — tough가 첫 피해(양과 무관)를 완전 흡수하므로 벗겨낸 뒤 격파
  if (G.villain.status && G.villain.status.tough){ MC.applyDamage(G, G.villain, 1, {}); }
  MC.applyDamage(G, G.villain, 32, {});
  check('최종 단계 격파 = 승리', G.over && G.over.result === 'win');
}

/* ── 9. 메인 스킴 한도 = 패배 ── */
{
  const G = newGame(1);
  MC.placeThreat(G, 'main', 7);
  check('메인 스킴 완성 = 패배', G.over && G.over.result === 'loss');
}

/* ── 10. 결정성: 전체 게임 재생 = 동일 상태 (엄격) ── */
{
  function autoPlay(seed){
    delete globalThis.MC;
    for (const k of Object.keys(require.cache)) delete require.cache[k];
    require(path.join(ROOT, 'mc_engine.js'));
    require(path.join(ROOT, 'mc_cards.js'));
    const M = globalThis.MC;
    M.registerCards({ 'T-GUARD': { code:'T-GUARD', side:'encounter', type:'minion', name:'수호 픽스처', hp:3, attack:1, scheme:0, guard:true } });
    const deck = [];
    for (let i=0;i<12;i++) deck.push('backflip');
    for (let i=0;i<12;i++) deck.push('swinging-web-kick');
    const G = M.makeGameState({ seed,
      players: [ {heroCode:'01001a', deckCodes:deck.slice()}, {heroCode:'01001a', deckCodes:deck.slice()},
                 {heroCode:'01001a', deckCodes:deck.slice()}, {heroCode:'01001a', deckCodes:deck.slice()} ],
      villainCode:'01094', mainScheme:'01097b', encounterCodes: Array(15).fill('hydra-mercenary') });
    M.setupGame(G);
    // 정책 RNG는 G와 분리 (액션 외부 RNG 소모 금지 원칙)
    let ps = seed ^ 0x9E3779B9;
    const prand = () => { let t=(ps+=0x6D2B79F5); t=Math.imul(t^(t>>>15),t|1); t^=t+Math.imul(t^(t>>>7),t|61); return ((t^(t>>>14))>>>0)/4294967296; };
    let guard = 0;
    while (!G.over && G.round < 12 && guard++ < 500){
      if (G.pending){
        if (G.pending.kind === 'revealChoice'){
          const opts = G.pending.options || [];
          const pick = opts[Math.floor(prand()*opts.length)] || opts[0];
          M.dispatch(G, { type:'resolveRevealChoice', player:G.pending.player, option: pick.key }); continue; }
        const dp = G.players.find(x=>x.uid===G.pending.player);
        const canDef = dp && !dp.exhausted;
        const readyAlly = dp && dp.playArea.allies.find(a=>!a.exhausted);
        let defender;
        if (G.pending.mustDefendWithAlly && readyAlly) defender = readyAlly.uid;
        else defender = (canDef && prand() < 0.5) ? 'identity' : 'none';
        M.dispatch(G, { type:'resolveDefense', player:G.pending.player, defender }); continue; }
      for (const pl of M.playersInOrder(G)){
        if (G.over || G.pending) break;
        if (prand() < 0.5 && !pl.formChangedThisRound) M.dispatch(G, { type:'flipForm', player: pl.uid });
        if (pl.form === 'hero' && !pl.exhausted && !G.pending && prand() < 0.6){
          // Guard 교전 중이면 빌런 대신 살아있는 가드 하수인부터 (실제 룰 반영)
          const guardM = (pl.engagedMinions||[]).find(m => m.guard && m.hp > 0);
          const tgt = guardM ? guardM.uid : G.villain.uid;
          M.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: tgt });
        }
      }
      if (!G.over && !G.pending) M.dispatch(G, { type:'endPlayerPhase' });
    }
    return { M, G };
  }
  const A = autoPlay(31337);
  const logA = JSON.parse(JSON.stringify(A.G.actionLog));
  const serA = A.M.serialize(A.G);
  // 재생: 새 엔진 + 같은 초기 조건 + 로그만 dispatch
  delete globalThis.MC;
  for (const k of Object.keys(require.cache)) delete require.cache[k];
  require(path.join(ROOT, 'mc_engine.js'));
  require(path.join(ROOT, 'mc_cards.js'));
  const M2 = globalThis.MC;
  M2.registerCards({ 'T-GUARD': { code:'T-GUARD', side:'encounter', type:'minion', name:'수호 픽스처', hp:3, attack:1, scheme:0, guard:true } });
  const deck = [];
  for (let i=0;i<12;i++) deck.push('backflip');
  for (let i=0;i<12;i++) deck.push('swinging-web-kick');
  const C = M2.makeGameState({ seed:31337,
    players: [ {heroCode:'01001a', deckCodes:deck.slice()}, {heroCode:'01001a', deckCodes:deck.slice()},
               {heroCode:'01001a', deckCodes:deck.slice()}, {heroCode:'01001a', deckCodes:deck.slice()} ],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: Array(15).fill('hydra-mercenary') });
  M2.setupGame(C);
  for (const a of logA) M2.dispatch(C, a);
  check('★ 재생 동기화: 직렬화 완전 일치', M2.serialize(C) === serA);
}

console.log(fail === 0 ? '[test_phase1] 전체 통과' : `[test_phase1] 실패 ${fail}건`);
process.exit(fail === 0 ? 0 : 1);
