/* test_biomech_upgrades.js — Biomechanical Upgrades(01185) 부착 회귀
   ★ attachToHighestHpMinion(excludeSameAttachment) + reviveOnDefeat(처치 방지·완전 회복).
   사용: node tests/test_biomech_upgrades.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 최대 HP 하수인에 부착
{
  const G = mk(90001); const pl = G.players[0]; pl.form = 'hero';
  const soldier = MC.makeInstance(G, 'hydra-soldier', {}); soldier.type = 'minion';  // HP 4
  const modok = MC.makeInstance(G, 'modok', {}); modok.type = 'minion';               // HP 8
  pl.engagedMinions.push(soldier, modok);
  const bmu = MC.makeInstance(G, 'biomechanical-upgrades', {});
  MC.fireCardHook(G, bmu, 'whenRevealed', { player: pl });
  assert((modok.attachments || []).some(a => a.uid === bmu.uid), '최대 HP(M.O.D.O.K.)에 부착');
  assert(!(soldier.attachments || []).some(a => a.uid === bmu.uid), '낮은 HP(솔저)에는 안 붙음');
}

// ② excludeSameAttachment: 이미 부착된 하수인은 제외 → 다른 하수인에
{
  const G = mk(90002); const pl = G.players[0]; pl.form = 'hero';
  const modok = MC.makeInstance(G, 'modok', {}); modok.type = 'minion';       // HP 8 (최고)
  const soldier = MC.makeInstance(G, 'hydra-soldier', {}); soldier.type = 'minion'; // HP 4
  pl.engagedMinions.push(modok, soldier);
  const b1 = MC.makeInstance(G, 'biomechanical-upgrades', {});
  MC.fireCardHook(G, b1, 'whenRevealed', { player: pl });   // → modok
  const b2 = MC.makeInstance(G, 'biomechanical-upgrades', {});
  MC.fireCardHook(G, b2, 'whenRevealed', { player: pl });   // modok 제외 → soldier
  assert((modok.attachments || []).filter(a => a.defCode === 'biomechanical-upgrades').length === 1, 'M.O.D.O.K.에 1개만');
  assert((soldier.attachments || []).some(a => a.uid === b2.uid), '2번째는 솔저에 부착 (중복 제외)');
}

// ③ reviveOnDefeat: 부착 하수인 처치 시 완전 회복 + 부착물 버림
{
  const G = mk(90003); const pl = G.players[0]; pl.form = 'hero';
  const modok = MC.makeInstance(G, 'modok', {}); modok.type = 'minion';
  modok.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(modok);
  const bmu = MC.makeInstance(G, 'biomechanical-upgrades', {});
  MC.fireCardHook(G, bmu, 'whenRevealed', { player: pl });
  const maxHp = modok.maxHp;
  // 치사량 피해
  MC.applyDamage(G, modok, 99, { source: pl, byAttack: true });
  assert(modok.hp === maxHp, '부활: HP 전량 회복 (' + modok.hp + '/' + maxHp + ')');
  assert(!(modok.attachments || []).some(a => a.defCode === 'biomechanical-upgrades'), '부활 후 부착물 버림');
  assert(pl.engagedMinions.some(m => m.uid === modok.uid), 'M.O.D.O.K. 생존(처치 안 됨)');
}

// ④ 부착물 벗긴 뒤엔 정상 처치
{
  const G = mk(90004); const pl = G.players[0]; pl.form = 'hero';
  const modok = MC.makeInstance(G, 'modok', {}); modok.type = 'minion';
  modok.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(modok);
  const bmu = MC.makeInstance(G, 'biomechanical-upgrades', {});
  MC.fireCardHook(G, bmu, 'whenRevealed', { player: pl });
  MC.applyDamage(G, modok, 99, { source: pl, byAttack: true });  // 1회 부활 (부착물 소진)
  MC.applyDamage(G, modok, 99, { source: pl, byAttack: true });  // 2회째 → 정상 처치
  assert(!pl.engagedMinions.some(m => m.uid === modok.uid && m.hp > 0), '부착물 소진 후 정상 처치');
}

console.log('══ Biomechanical Upgrades (부착 + 부활 방패) 회귀 통과 ══');
