/* test_preset_decks.js — 코어 세트 공식 프리빌트 덱 5종 회귀
   ★ 룰북 STARTER DECKS 그대로 구성됐는지 검증 (시그니처 + 아스펙트 + 기본).
   ★ 각 40장, slug 전부 유효, 아트 코드 일치, 게임 셋업 정상.
   사용: node tests/test_preset_decks.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function count(arr){ const m = {}; for (const s of arr) m[s] = (m[s]||0)+1; return m; }

// 룰북 공식 구성 (title→slug, 수량). 각 덱의 아스펙트+시그니처 핵심 검증용.
const EXPECT = {
  spiderman: { hero:'01010a_no', art:'01001a', aspect:'justice',
    key:{ 'swinging-web-kick':3, 'for-justice':2, 'surveillance-team':2, 'power-of-justice':2, 'daredevil':1, 'jessica-jones':1 } },
  'captain-marvel': { art:'01010a', aspect:'leadership',
    key:{ 'crisis-interdiction':3, 'photon-blast':3, 'cosmic-flight':2, 'make-the-call':2, 'hawkeye':1, 'vision':1, 'spider-woman-ally':1 } },
  'she-hulk': { art:'01019a', aspect:'aggression',
    key:{ 'one-two-punch':3, 'focused-rage':2, 'uppercut':2, 'hulk-ally':1, 'tigra-ally':1, 'hellcat':1, 'gamma-slam':1 } },
  'iron-man': { art:'01029a', aspect:'aggression',
    key:{ 'repulsor-blast':3, 'supersonic-punch':2, 'powered-gauntlets':2, 'rocket-boots':2, 'war-machine':1, 'tigra-ally':1, 'hulk-ally':1 } },
  'black-panther': { art:'01040a', aspect:'protection',
    key:{ 'wakanda-forever':5, 'vibranium-resource':3, 'armored-vest':2, 'med-team':2, 'luke-cage':1, 'black-widow-ally':1 } },
  'captain-america': { art:'03001a', aspect:'leadership',
    key:{ 'heroic-strike':3, 'fearless-determination':2, 'shield-block':2, 'super-soldier-serum':2, 'make-the-call':2, 'power-of-leadership':2, 'agent-13':1, 'cap-shield':1, 'falcon-ally':1 } },
};
const BASIC = ['avengers-mansion','emergency','energy','first-aid','haymaker','genius','mockingbird','nick-fury','helicarrier','strength','tenacity'];

// ① 8종 프리셋 존재 (스파이더맨·캡틴마블·쉬헐크·아이언맨·블랙팬서·캡아·미즈마블·토르)
{
  const keys = Object.keys(MC.PRESET_DECKS);
  assert(keys.length === 11, '프리빌트 덱 11종 등록 (실제 ' + keys.length + ')');
  for (const k of Object.keys(EXPECT)) assert(!!MC.PRESET_DECKS[k], '프리셋 존재: ' + k);
}

// ② 각 덱 40장 + slug 유효 + 아트 코드 일치 + 핵심 카드 수량 + 기본 카드 포함
for (const [k, exp] of Object.entries(EXPECT)){
  const d = MC.PRESET_DECKS[k];
  assert(d.cards.length === 40, k + ': 정확히 40장 (실제 ' + d.cards.length + ')');
  assert(d.hero === exp.art, k + ': 아트 코드 ' + exp.art);
  const bad = d.cards.filter(s => !MC.CARDS[s]);
  assert(bad.length === 0, k + ': 모든 slug 유효' + (bad.length?' — 미존재: '+[...new Set(bad)].join(','):''));
  const c = count(d.cards);
  for (const [slug, qty] of Object.entries(exp.key))
    assert(c[slug] === qty, k + ': ' + slug + ' ×' + qty + ' (실제 ' + (c[slug]||0) + ')');
  // 기본 카드 11종 각 1장
  for (const b of BASIC) assert(c[b] >= 1, k + ': 기본 카드 ' + b + ' 포함');
  // 아스펙트 카드가 실제 그 아스펙트인지 (기본/시그니처 제외)
  const aspectCards = d.cards.filter(s => { const cd = MC.CARDS[s]; return cd && cd.aspect === exp.aspect; });
  assert(aspectCards.length > 0, k + ': ' + exp.aspect + ' 아스펙트 카드 포함');
}

// ③ 각 프리셋으로 게임 셋업 정상 (덱 로드 + 오프닝 핸드 + 남은 덱)
for (const [k, d] of Object.entries(MC.PRESET_DECKS)){
  const G = MC.makeGameState({ seed:1, players:[{ heroCode:d.hero, deckCodes:d.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough'] });
  MC.setupGame(G);
  const pl = G.players[0];
  const expectedHand = MC.statOf(G, pl, 'handSize');   // 영웅별 손 크기 (토르·헐크류 4, 대부분 5~6)
  assert(pl.hand.length >= expectedHand, k + ': 셋업 후 오프닝 핸드 ' + pl.hand.length + '장 (기대 ' + expectedHand + ')');
  assert(pl.deck.length > 0, k + ': 셋업 후 덱에 카드 남음 (' + pl.deck.length + '장)');
}

// ④ 쉬헐크·아이언맨 용맹 아스펙트 카드 공유 확인 (룰북 명시)
{
  const sh = count(MC.PRESET_DECKS['she-hulk'].cards);
  const im = count(MC.PRESET_DECKS['iron-man'].cards);
  const shared = ['chase-them-down','combat-training','hulk-ally','relentless-assault','tac-team','power-of-aggression','tigra-ally','uppercut'];
  for (const s of shared)
    assert(sh[s] === im[s] && sh[s] > 0, '쉬헐크·아이언맨 용맹 공유: ' + s + ' 동일 수량(' + sh[s] + ')');
}

console.log('══ 코어 프리빌트 덱 5종 회귀 통과 ══');
