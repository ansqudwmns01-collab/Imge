/* test_sweeping_swoop.js — 급강하 습격(01168) 배신 회귀
   ★ applyStatus(히어로 기절) + 조건부 surge(enemyInPlay:vulture) + 부스트★ setBoostStunOnDamage.
   사용: node tests/test_sweeping_swoop.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 히어로 기절 (벌처 없으면 surge 없음)
{
  const G = mk(73001); const pl = G.players[0]; pl.form = 'hero';
  pl.status = { stunned:0, confused:0, tough:0 };
  const inst = MC.makeInstance(G, 'sweeping-swoop', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.status.stunned > 0, '히어로 기절');
  assert(inst.surge !== true, '벌처 없음: surge 없음');
}

// ② 벌처 전장이면 surge
{
  const G = mk(73002); const pl = G.players[0]; pl.form = 'hero';
  pl.status = { stunned:0, confused:0, tough:0 };
  const v = MC.makeInstance(G, 'vulture', {}); v.type = 'minion';
  pl.engagedMinions.push(v);
  const inst = MC.makeInstance(G, 'sweeping-swoop', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.status.stunned > 0, '히어로 기절');
  assert(inst.surge === true, '벌처 전장: surge 획득');
}

// ③ enemyInPlay 조건 — 처치된(hp0) 벌처는 미인정
{
  const G = mk(73003); const pl = G.players[0]; pl.form = 'hero';
  pl.status = { stunned:0, confused:0, tough:0 };
  const v = MC.makeInstance(G, 'vulture', {}); v.type = 'minion'; v.hp = 0;
  pl.engagedMinions.push(v);
  const inst = MC.makeInstance(G, 'sweeping-swoop', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(inst.surge !== true, 'HP 0 벌처: surge 없음');
}

// ④ 부스트★: 피해 시 기절 플래그
{
  const G = mk(73004); const pl = G.players[0]; pl.form = 'hero';
  G._boostStunOnDamage = false;
  const bc = MC.makeInstance(G, 'sweeping-swoop', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  assert(G._boostStunOnDamage === true, '부스트★: 피해 시 기절 플래그 세팅');
}

console.log('══ 급강하 습격 (기절 + enemyInPlay surge) 회귀 통과 ══');
