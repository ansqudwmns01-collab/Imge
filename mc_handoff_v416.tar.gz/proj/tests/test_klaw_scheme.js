/* test_klaw_scheme.js — 클로 메인 스킴 (01116 지하 유통망 / 01117 비밀 회합) 회귀
   1) 셋업: 방어망(01125) 자동 공개 + 위협 2 + 플레이어당 1
   2) 1B 공개 시: 조우덱에서 하수인 탐색 → 첫 플레이어 교전 배치 (비하수인은 버림)
   3) 위협 한도(6/인) 도달 → 01117b 전환 + 하수인 추가 배치
   4) 01117b 한도(8/인) 도달 → 게임 패배 (schemeComplete)
   사용: node tests/test_klaw_scheme.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function deck40(){
  const d = [];
  for (let i = 0; i < 20; i++) d.push('backflip');
  for (let i = 0; i < 20; i++) d.push('swinging-web-kick');
  return d;
}

const G = MC.makeGameState({
  seed: 12345,
  players: [{ heroCode: '01001a', deckCodes: deck40() }],
  villainCode: '01113',
  mainScheme: '01116b',
  // 배반 2장 + 방어망 + 하수인 2장: 셋업이 방어망을 뽑아내고,
  // 1B 공개가 배반들을 버린 뒤 첫 하수인을 배치하는지 검증
  encounterCodes: ['hydra-mercenary', 'sandman', 'defense-network', 'im-tough', 'im-tough'],
});
MC.setupGame(G);

// 1) 셋업 — 방어망 공개
const dn = G.sideSchemes.find(s => s.defCode === 'defense-network');
assert(!!dn, '셋업: 방어망 사이드 스킴 공개됨');
assert(dn.threat === 2 + 1 * G.players.length, '방어망 위협 = 기본 2 + 1/인 (실제 ' + dn.threat + ')');

// 2) 1B 공개 시 — 하수인 배치
const p1 = G.players[0];
assert(p1.engagedMinions.length === 1, '1B 공개: 하수인 1명 첫 플레이어와 교전 (실제 ' + p1.engagedMinions.length + ')');
assert(G.mainScheme.defCode === '01116b', '메인 스킴 = 01116b');
assert(G.mainScheme.maxThreat === 6 * G.players.length, '1B 한도 = 6/인');

// 3) 한도 도달 → 01117b 전환 + 하수인 추가
const before = p1.engagedMinions.length;
MC.placeThreat(G, 'main', G.mainScheme.maxThreat - G.mainScheme.threat);
assert(G.mainScheme.defCode === '01117b', '한도 도달 → 비밀 회합(01117b) 전환');
assert(G.mainScheme.maxThreat === 8 * G.players.length, '2B 한도 = 8/인');
assert(p1.engagedMinions.length === before + 1, '2A 공개: 하수인 추가 배치 (' + before + '→' + p1.engagedMinions.length + ')');
assert(!G.over, '아직 게임 계속');

// 4) 2B 한도 도달 → 패배
MC.placeThreat(G, 'main', G.mainScheme.maxThreat - G.mainScheme.threat);
assert(G.over && G.over.result === 'loss', '2B 완성 → 플레이어 패배');
assert(G.over.cause === 'schemeComplete', '패배 사유 = schemeComplete (빌런 승리 대사 분기)');

console.log('══ 클로 메인 스킴 회귀 통과 ══');
