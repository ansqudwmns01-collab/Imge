/* test_nemesis_reverify.js — 5영웅 넴시스 세트 실제 작동 재검증 (영구 회귀)
   ★ 매 게임 shadow-of-the-past로 도달하는 넴시스 소환 흐름 + 배선 카드 15장 검증.
   사용: node tests/test_nemesis_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mk(hero, deck){
  const G = MC.makeGameState({ seed:2,
    players:[{ heroCode: hero, deckCodes: MC.PRESET_DECKS[deck].cards.slice() }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') });
  MC.setupGame(G); return G;
}
function reveal(G, pl, code){ const c = MC.makeInstance(G, code, {}); MC.fireCardHook(G, c, 'whenRevealed', { player: pl, self: c, card: c }); return c; }
function ssThreat(G, code){ MC.revealSpecificSideScheme(G, code); const ss = G.sideSchemes.find(s => s.defCode === code); return ss && ss.threat > 0; }

/* 넴시스 소환 흐름: 셋업 aside → shadow-of-the-past 공개 → 하수인 등장 + 사이드 스킴 배치 */
{
  const G = mk('01001a', 'spiderman'); const pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  assert((pl.nemesisSetAside || []).length > 0, '넴시스 — 셋업 시 세트 aside 배치');
  const m0 = pl.engagedMinions.length, ss0 = G.sideSchemes.length;
  reveal(G, pl, 'shadow-of-the-past');
  assert(pl.engagedMinions.length > m0, 'shadow-of-the-past — 넴시스 하수인 등장');
  assert(G.sideSchemes.length > ss0, 'shadow-of-the-past — 넴시스 사이드 스킴 배치');
}

/* 블랙팬서 넴시스 */
{ const G = mk('01040a','black-panther'); const pl = G.players[0]; pl.form='hero';
  assert(ssThreat(G, 'usurp-the-throne'), 'usurp-the-throne — 사이드 스킴 위협'); }
{ const G = mk('01040a','black-panther'); const pl = G.players[0]; pl.form='hero'; reveal(G, pl, 'heart-shaped-herb');
  assert((G.villain.status.tough||0) > 0, 'heart-shaped-herb — 빌런+교전 Tough 부여'); }
{ const G = mk('01040a','black-panther'); const pl = G.players[0]; pl.form='hero'; reveal(G, pl, 'ritual-combat');
  assert(G.pending && G.pending.kind === 'revealChoice', 'ritual-combat — 택 pending'); }

/* 스파이더맨 넴시스 */
{ const G = mk('01001a','spiderman'); const pl = G.players[0]; pl.form='hero';
  assert(ssThreat(G, 'highway-robbery'), 'highway-robbery — 사이드 스킴 위협'); }
{ const G = mk('01001a','spiderman'); const pl = G.players[0]; pl.form='hero'; reveal(G, pl, 'sweeping-swoop');
  assert(true, 'sweeping-swoop — 공개 무에러'); }
{ const G = mk('01001a','spiderman'); const pl = G.players[0]; pl.form='hero';
  for (let i=0;i<3;i++) pl.hand.push(MC.makeInstance(G,'energy',{})); reveal(G, pl, 'vultures-plans');
  assert(true, 'vultures-plans — 공개 무에러(자원 카드 버림)'); }

/* 쉬헐크 넴시스 */
{ const G = mk('01019a','she-hulk'); const pl = G.players[0]; pl.form='hero';
  assert(ssThreat(G, 'personal-challenge'), 'personal-challenge — 사이드 스킴 위협'); }
{ const G = mk('01019a','she-hulk'); const pl = G.players[0]; pl.form='hero'; reveal(G, pl, 'titanias-fury');
  assert(true, 'titanias-fury — 공개 무에러'); }
{ const G = mk('01019a','she-hulk'); const pl = G.players[0]; pl.form='hero'; reveal(G, pl, 'genetic-enhancement');
  assert(true, 'genetic-enhancement — 부착 공개 무에러'); }

/* 아이언맨 넴시스 */
{ const G = mk('01029a','iron-man'); const pl = G.players[0]; pl.form='hero';
  assert(ssThreat(G, 'imminent-overload'), 'imminent-overload — 사이드 스킴 위협'); }
{ const G = mk('01029a','iron-man'); const pl = G.players[0]; pl.form='hero'; reveal(G, pl, 'electric-whip-attack');
  assert(G.pending && G.pending.kind === 'revealChoice', 'electric-whip-attack — 택 pending'); }
{ const G = mk('01029a','iron-man'); const pl = G.players[0]; pl.form='hero'; reveal(G, pl, 'electromagnetic-backlash');
  assert(true, 'electromagnetic-backlash — 공개 무에러'); }

/* 캡틴마블 넴시스 */
{ const G = mk('01010a','captain-marvel'); const pl = G.players[0]; pl.form='hero';
  assert(ssThreat(G, 'psyche-magnitron'), 'psyche-magnitron — 사이드 스킴 위협'); }
{ const G = mk('01010a','captain-marvel'); const pl = G.players[0]; pl.form='hero'; const t0 = G.mainScheme.threat; reveal(G, pl, 'kree-manipulator');
  assert(G.mainScheme.threat > t0, 'kree-manipulator — 메인 스킴 위협 증가'); }
{ const G = mk('01010a','captain-marvel'); const pl = G.players[0]; pl.form='hero';
  for (let i=0;i<3;i++) pl.hand.push(MC.makeInstance(G,'energy',{})); const h0 = pl.hand.length; reveal(G, pl, 'yon-roggs-treason');
  assert(pl.hand.length < h0, 'yon-roggs-treason — 손패 자원 카드 버림'); }

console.log('\n[test_nemesis_reverify] ' + pass + '개 통과 — 5영웅 넴시스 재검증 완료');
