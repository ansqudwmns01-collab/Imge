/* test_gang_up.js — Gang-Up(01189) 배신 회귀
   ★ 신규 villainAndMinionsAttack(빌런 + 교전 하수인 전원 공격 체인) + 폼 분기.
   사용: node tests/test_gang_up.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 알터에고 폼: surge, 공격 없음
{
  const G = mk(93001); const pl = G.players[0]; pl.form = 'alter-ego';
  const inst = MC.makeInstance(G, 'gang-up', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(inst.surge === true, '알터에고: surge 획득');
  assert(!(G.pending && G.pending.kind === 'defense'), '알터에고: 공격 없음');
}

// ② 히어로 폼: 빌런이 먼저 공격 (defense pending)
{
  const G = mk(93002); const pl = G.players[0]; pl.form = 'hero';
  const inst = MC.makeInstance(G, 'gang-up', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'defense', '히어로: 공격 개시 (defense pending)');
  assert(G.pending.attackerUid === G.villain.uid, '첫 공격자 = 빌런');
  assert(inst.surge !== true, '히어로: surge 없음');
}

// ③ 히어로 폼 + 교전 하수인 2명: 빌런 + 하수인 2명 = 3연속 공격 체인
{
  const G = mk(93003); const pl = G.players[0]; pl.form = 'hero';
  const m1 = MC.makeInstance(G, 'hydra-soldier', {}); m1.type = 'minion';
  m1.status = { stunned:0, confused:0, tough:0 };
  const m2 = MC.makeInstance(G, 'hydra-soldier', {}); m2.type = 'minion';
  m2.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m1, m2);
  const inst = MC.makeInstance(G, 'gang-up', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  // 빌런 공격 pending + attackChain에 하수인 2명 대기
  assert(G.pending && G.pending.kind === 'defense', '첫 공격 pending');
  assert(G.pending.attackerUid === G.villain.uid, '빌런이 먼저');
  const chainLen = (G.pending.attackChain || []).length;
  assert(chainLen === 2, '체인에 교전 하수인 2명 대기 (실제 ' + chainLen + ')');
}

// ④ 히어로 폼 + 교전 하수인 없음: 빌런만 공격
{
  const G = mk(93004); const pl = G.players[0]; pl.form = 'hero';
  pl.engagedMinions = [];
  const inst = MC.makeInstance(G, 'gang-up', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.attackerUid === G.villain.uid, '하수인 없음: 빌런만 공격');
  assert(!(G.pending.attackChain && G.pending.attackChain.length), '체인 비어있음');
}

console.log('══ Gang-Up (빌런+하수인 집중 공격) 회귀 통과 ══');
