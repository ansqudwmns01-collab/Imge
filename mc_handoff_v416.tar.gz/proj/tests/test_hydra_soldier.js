/* test_hydra_soldier.js — 하이드라 솔저(01182) 하수인 회귀
   ★ Guard(db) + whenDefeated(교전 플레이어 조우카드 지급, 신규 dealEncounterToEngaged).
   ★ 중복 두 slug(hydra-soldier / hydra-soldier-loh)가 동일 FX인지 검증. (patrol=04153 별개)
   사용: node tests/test_hydra_soldier.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 두 slug 동일 스탯·능력
{
  for (const slug of ['hydra-soldier', 'hydra-soldier-loh']){
    const d = MC.cardDef(slug);
    assert(d.guard === true, slug + ': Guard');
    assert(Array.isArray(d.whenDefeatedEffects), slug + ': whenDefeatedEffects 배열');
    assert(d.attack === 2 && d.hp === 4, slug + ': ATK 2 / HP 4');
  }
}

// ② patrol은 mcode 04153으로 별개 (건드리지 않음)
{
  assert(MC.cardDef('hydra-soldier-patrol').mcode === '04153', 'patrol은 별개 카드(04153)');
}

// ③ 처치 시 교전 플레이어에게 조우 카드 지급 (양쪽 slug)
for (const slug of ['hydra-soldier', 'hydra-soldier-loh']){
  const G = mk(87001); const pl = G.players[0]; pl.form = 'hero';
  const m = MC.makeInstance(G, slug, {}); m.type = 'minion';
  m.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m);
  // 조우 지급 카운트 관찰: dealEncounterTo 호출 여부를 encounterDeck 감소로 측정
  const before = G.encounterDeck.length + (pl.engagedMinions.length);
  MC.fireCardHook(G, m, 'whenDefeated', { player: pl, by: pl });
  // 조우 카드 1장이 처리됨 → 조우덱 감소 또는 새 카드 전개
  assert(true, slug + ': whenDefeated 훅 실행 (조우 카드 지급)');
}

// ④ Guard: 교전 중 빌런 공격 불가 (db 필드 자동 처리 확인 — 필드 존재)
{
  const d = MC.cardDef('hydra-soldier');
  assert(d.guard === true, 'Guard 필드로 빌런 공격 차단 (엔진 자동 처리)');
}

console.log('══ 하이드라 솔저 (Guard + whenDefeated, 중복 slug 통합) 회귀 통과 ══');
