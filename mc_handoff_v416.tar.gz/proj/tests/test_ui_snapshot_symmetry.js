/* test_ui_snapshot_symmetry.js — UI 설치 감지 스냅샷 대칭 회귀
   버그 히스토리: collectInstalled(prev)가 동료를 빠뜨려, installedNow(now)와 비대칭이 되면서
   매 액션마다 allyEnter 연출이 재발동함. prev/now가 같은 zone(allies/supports/upgrades)을
   다뤄야 대칭이 유지됨. 빌드된 HTML을 소스 수준으로 검사.
   사용: node tests/test_ui_snapshot_symmetry.js */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.dirname(__dirname);

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}

// 빌드 산출물 우선, 없으면 소스(ui/mc_ui.js)
let src = '';
const built = path.join(ROOT, 'marvel_champions_build.html');
const uiSrc = path.join(ROOT, 'ui', 'mc_ui.js');
if (fs.existsSync(built)) src = fs.readFileSync(built, 'utf8');
else if (fs.existsSync(uiSrc)) src = fs.readFileSync(uiSrc, 'utf8');
assert(src.length > 0, '검사 대상 소스 로드');

// collectInstalled 함수 본문 추출
const m = src.match(/function collectInstalled\(\)\{[\s\S]*?\n\}/);
assert(m, 'collectInstalled 함수 발견');
const body = m[0];

// installedNow(설치 감지)가 다루는 zone 3종을 collectInstalled(prev)도 전부 다뤄야 대칭
assert(/playArea\.allies/.test(body),   'collectInstalled — 동료(allies) 포함 (allyEnter 과다발동 방지)');
assert(/playArea\.supports/.test(body), 'collectInstalled — 지원(supports) 포함');
assert(/playArea\.upgrades/.test(body), 'collectInstalled — 업그레이드(upgrades) 포함');

// collectAttachments / collectStatuses 도 동료를 스캔해야 동료 부착/상태 연출이 표시됨
const ma = src.match(/function collectAttachments\(\)\{[\s\S]*?\n\}/);
assert(ma && /playArea\.allies/.test(ma[0]), 'collectAttachments — 동료 스캔 (부착 연출 표시)');
assert(ma && /hostUid/.test(ma[0]), 'collectAttachments — hostUid 저장 (동료 부착물 host 해소)');
const mst = src.match(/function collectStatuses\(\)\{[\s\S]*?\n\}/);
assert(mst && /playArea\.allies/.test(mst[0]), 'collectStatuses — 동료 스캔 (상태 연출 표시)');

console.log('\n[test_ui_snapshot_symmetry] ' + pass + '개 통과 — 설치 스냅샷 대칭 유지');
