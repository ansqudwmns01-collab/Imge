/* test_legal_work.js — 법률 업무(01160) obligation 회귀
   ★ obligation 재사용(exhaustTarget/resolveObligation) + 신규 addAcceleration.
   사용: node tests/test_legal_work.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 공개: 선택 pending (2옵션)
{
  const G = mk(65001); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'legal-work', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'revealChoice', '의무 공개 — 선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (소진/가속)');
}

// ② exhaust 옵션: 소진 + 게임 제거
{
  const G = mk(65002); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'legal-work', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'exhaust' });
  assert(pl.exhausted === true, 'exhaust: 제니퍼 소진');
  assert((G.removedFromGame || []).includes('legal-work'), 'exhaust: 게임에서 제거');
}

// ③ accel 옵션: 가속 토큰 +1 (의무 버림)
{
  const G = mk(65003); const pl = G.players[0]; pl.form = 'hero';
  const a0 = G.acceleration;
  const inst = MC.makeInstance(G, 'legal-work', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'accel' });
  assert(G.acceleration === a0 + 1, 'accel: 가속 토큰 +1 (' + a0 + '→' + G.acceleration + ')');
  assert(pl.exhausted !== true, 'accel: 소진 안 함');
  assert((G.removedFromGame || []).length === 0, 'accel: 게임 제거 아님(버림)');
}

console.log('══ 법률 업무 (obligation + addAcceleration) 회귀 통과 ══');
