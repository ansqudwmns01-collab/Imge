/* test_drone_factory.js — 드론 공장(01148) 사이드 스킴 회귀
   ★ 신규 범용: placeThreat perDroneInPlay(전장 Drone 수 비례 위협).
     spawnDrone(eachPlayer) 재사용. 완성 연출(whenCompleted) 검증.
   - 공개: 시작 위협 4 + 각 플레이어 드론 스폰 + 전장 드론 수만큼 이곳에 위협
   사용: node tests/test_drone_factory.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 공개: 사이드 스킴 전장 배치 + 시작 위협 4 + 드론 1 스폰 + 드론 수(1)만큼 위협 = 5
{
  const G = mk(20001); const pl = G.players[0];
  const deck0 = pl.deck.length;
  const ss = revealSide(G, pl, 'drone-factory');
  assert(G.sideSchemes.some(s => s.uid === ss.uid), '드론 공장: 사이드 스킴 전장 배치');
  const drone = pl.engagedMinions.find(m => m.isDrone);
  assert(drone, '각 플레이어 드론 스폰');
  assert(pl.deck.length === deck0 - 1, '덱 맨 위 1장 드론화');
  // 시작 위협 4(baseThreat) + 전장 드론 1 = 5
  assert(ss.threat === 5, '위협 = 시작4 + 드론1 = 5 (실제 ' + ss.threat + ')');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'droneFactoryActivate', '가동 연출');
}

// ② 이미 전장에 드론이 있으면 그것도 카운트 (스폰분 + 기존분)
{
  const G = mk(20002); const pl = G.players[0];
  // 기존 드론 2명 (환경 세팅 후 스폰)
  G.environments.push(MC.makeInstance(G, 'ultron-drones', {}));
  MC.spawnFacedownDrone(G, pl); MC.spawnFacedownDrone(G, pl);
  const ss = revealSide(G, pl, 'drone-factory');
  // 시작 4 + (기존 2 + 새 스폰 1 = 3) = 7
  assert(ss.threat === 7, '위협 = 시작4 + 전장드론3 = 7 (실제 ' + ss.threat + ')');
}

// ③ 완성(whenCompleted) 연출 발화
{
  const G = mk(20003); const pl = G.players[0];
  const ss = revealSide(G, pl, 'drone-factory');
  G.fxCardEffect = null;
  MC.fireCardHook(G, ss, 'whenCompleted', {});
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'droneFactoryShutdown', '완성: 공장 정지 연출');
}

// ④ 가속 아이콘 정의 유지 (빌런 페이즈 가속 기여)
{
  const G = mk(20004);
  const def = MC.cardDef('drone-factory');
  assert(def.accelIcons === 1, '가속 아이콘 1 (정의 유지)');
  assert(def.baseThreat === 4, '시작 위협 4 (정의 유지)');
}

console.log('══ 드론 공장 (placeThreat perDroneInPlay) 회귀 통과 ══');
