/* test_ally_attack_target.js — 동료 공격 대상 선택 회귀
   ★ 동료가 빌런뿐 아니라 교전 하수인도 공격 대상으로 선택 가능(엔진 allyAttack targetUid).
   ★ 수호(guard) 하수인 교전 중에는 빌런 공격 차단(공식 룰).
   사용: node tests/test_ally_attack_target.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(){
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  const pl = G.players[0]; pl.form = 'hero';
  return { G, pl };
}

// ① 동료가 교전 하수인(비수호)을 공격
{
  const { G, pl } = mk();
  const ally = MC.makeInstance(G, 'agent-13', {}); ally.exhausted = false; pl.playArea.allies.push(ally);
  const mn = MC.makeInstance(G, 'weapons-runner', {}); mn.engagedWith = pl.uid; pl.engagedMinions.push(mn);
  const hp0 = mn.hp;
  MC.dispatch(G, { type:'allyAttack', player:'P0', allyUid: ally.uid, targetUid: mn.uid });
  assert(mn.hp === hp0 - MC.allyStatOf(G, ally, 'attack'), '동료→하수인 공격: 하수인 피해 적용 (' + hp0 + '→' + mn.hp + ')');
  assert(ally.exhausted, '동료 공격 후 소진');
}

// ② 동료가 빌런을 공격 (수호 하수인 없을 때)
{
  const { G, pl } = mk();
  const ally = MC.makeInstance(G, 'agent-13', {}); ally.exhausted = false; pl.playArea.allies.push(ally);
  const vHp0 = G.villain.hp;
  MC.dispatch(G, { type:'allyAttack', player:'P0', allyUid: ally.uid, targetUid: G.villain.uid });
  assert(G.villain.hp === vHp0 - MC.allyStatOf(G, ally, 'attack'), '동료→빌런 공격: 빌런 피해 적용 (' + vHp0 + '→' + G.villain.hp + ')');
}

// ③ 수호(guard) 하수인 교전 중 → 동료의 빌런 공격 차단
{
  const { G, pl } = mk();
  const ally = MC.makeInstance(G, 'agent-13', {}); ally.exhausted = false; pl.playArea.allies.push(ally);
  const guard = MC.makeInstance(G, 'armored-guard', {}); guard.engagedWith = pl.uid; guard.guard = true; pl.engagedMinions.push(guard);
  let blocked = false;
  try { MC.dispatch(G, { type:'allyAttack', player:'P0', allyUid: ally.uid, targetUid: G.villain.uid }); }
  catch(e){ blocked = true; }
  assert(blocked, '수호 하수인 교전 중 동료의 빌런 공격 차단');
  // 하지만 그 수호 하수인 자체는 공격 가능
  const hp0 = guard.hp;
  MC.dispatch(G, { type:'allyAttack', player:'P0', allyUid: ally.uid, targetUid: guard.uid });
  assert(guard.hp <= hp0, '수호 하수인 자체는 동료 공격 대상 가능');
}

console.log('══ 동료 공격 대상 선택 회귀 통과 ══');
