/* test_rhino_crowd_control.js — 군중 통제(01108) Crisis 사이드 스킴 회귀
   ★ Crisis 범용 구현: crisis 사이드 스킴이 전장에 있으면 메인 스킴 위협 제거(저지) 차단.
   - 시작 위협: 인원수당 2 (솔로 2, 2인 4)
   - Crisis: 메인 스킴 저지 불가 (사이드 스킴 자체 저지는 가능) → 처치 후 해제
   사용: node tests/test_rhino_crowd_control.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed, np){
  const players = [];
  for (let i = 0; i < np; i++) players.push({ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() });
  const G = MC.makeGameState({ seed, players, villainCode:'01094', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealCC(G){
  const def = MC.cardDef('crowd-control');
  const inst = MC.makeInstance(G, 'crowd-control', {});
  inst.threat = (def.baseThreatPerPlayer||0) * G.players.length + (def.baseThreat||0);
  inst.peakThreat = inst.threat; inst.isMain = false;
  G.sideSchemes.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  return inst;
}

assert(MC.cardDef('crowd-control').crisis === true, '위기(Crisis) 필드 선언');

// 시작 위협 per player
assert(revealCC(mk(8001,1)).threat === 2, '솔로: 시작 위협 2 (per player)');
assert(revealCC(mk(8002,2)).threat === 4, '2인: 시작 위협 4 (per player)');

// Crisis: 메인 스킴 저지 차단
{
  const G = mk(8010, 1); const pl = G.players[0]; pl.form = 'hero';
  const cc = revealCC(G);
  const mainT0 = G.mainScheme.threat;
  let blocked = false;
  try { MC.ACTIONS.basicThwart(G, { player: pl.uid, scheme:'main' }); } catch(e){ blocked = /Crisis|위기/.test(e.message); }
  assert(blocked, 'Crisis 있음: 메인 스킴 저지 차단(throw)');
  assert(G.mainScheme.threat === mainT0, 'Crisis: 메인 위협 불변');
  assert(!pl.exhausted, 'Crisis: 저지 거부 시 소진 안 됨');
  // crowd-control 자체(사이드 스킴)는 저지 가능
  const t0 = cc.threat;
  MC.ACTIONS.basicThwart(G, { player: pl.uid, scheme: cc.uid });
  assert(cc.threat < t0, 'crowd-control 자체 저지는 가능');
}

// crowd-control 처치 → Crisis 해제 → 메인 저지 가능 + 완성 연출
{
  const G = mk(8011, 1); const pl = G.players[0]; pl.form = 'hero';
  const cc = revealCC(G);
  G.mainScheme.threat = 5;          // 저지 감소 확인용
  G.fxCardEffect = null;
  MC.removeThreat(G, cc.uid, 99);   // 처치
  assert(!G.sideSchemes.includes(cc), 'crowd-control 격퇴');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'crowdPanic', '완성: 대피 연출');
  const mainT0 = G.mainScheme.threat;
  MC.ACTIONS.basicThwart(G, { player: pl.uid, scheme:'main' });
  assert(G.mainScheme.threat < mainT0, 'Crisis 해제 후: 메인 저지 가능');
}

// crisis 사이드 스킴 없으면 정상 저지
{
  const G = mk(8012, 1); const pl = G.players[0]; pl.form = 'hero';
  G.mainScheme.threat = 5;
  assert(!MC.hasCrisisScheme(G), 'crisis 스킴 없음: hasCrisisScheme false');
  const mainT0 = G.mainScheme.threat;
  MC.ACTIONS.basicThwart(G, { player: pl.uid, scheme:'main' });
  assert(G.mainScheme.threat < mainT0, 'crisis 없음: 메인 저지 정상');
}

console.log('══ 군중 통제 (Crisis 사이드 스킴) 회귀 통과 ══');
