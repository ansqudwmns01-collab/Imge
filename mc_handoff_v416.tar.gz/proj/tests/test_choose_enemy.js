/* test_choose_enemy.js — 범용 적 선택 이펙트(chooseEnemy) + 모킹버드(01083) 회귀
   ★ 인덱스 타입: chooseEnemy → then 효과(applyStatus 등). 다른 카드에도 재사용.
   - 후보(빌런+교전 하수인)가 1명이면 자동 대상, 여럿이면 선택 pending
   - resolveChooseEnemy로 선택 해소 → then 효과 실행
   사용: node tests/test_choose_enemy.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function playMockingbird(G, pl){
  const mb = MC.makeInstance(G, 'mockingbird', {});
  pl.playArea.allies.push(mb);
  MC.fireCardHook(G, mb, 'whenPlayed', { player: pl });
  return mb;
}

// 후보가 빌런만 → 자동 기절, pending 없음
{
  const G = mk(7001); const pl = G.players[0]; pl.form = 'hero';
  playMockingbird(G, pl);
  assert(!G.pending, '빌런만: 자동 대상 (선택 pending 없음)');
  assert(G.villain.status.stunned === 1, '빌런만: 빌런 자동 기절');
}

// 교전 하수인 있으면 → 선택 pending (빌런 + 하수인 후보)
{
  const G = mk(7002); const pl = G.players[0]; pl.form = 'hero';
  const minion = MC.makeInstance(G, 'mister-sinister', {});
  minion.hp = minion.hp || 5;
  minion.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(minion);
  playMockingbird(G, pl);
  assert(G.pending && G.pending.kind === 'chooseEnemy', '하수인 있음: 적 선택 pending');
  assert(G.pending.enemyUids.length === 2, '후보 2명 (빌런 + 하수인)');
  assert(G.pending.enemyUids.includes(minion.uid), '하수인이 후보에 포함');
  // 하수인 선택 → 하수인 기절
  MC.ACTIONS.resolveChooseEnemy(G, { uid: minion.uid });
  assert(!G.pending, '선택 해소 후 pending 없음');
  assert(minion.status.stunned === 1, '선택한 하수인 기절');
  assert((G.villain.status.stunned||0) === 0, '선택 안 한 빌런은 기절 안 됨');
}

// 빌런 선택 분기
{
  const G = mk(7003); const pl = G.players[0]; pl.form = 'hero';
  const minion = MC.makeInstance(G, 'mister-sinister', {});
  minion.hp = 5; minion.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(minion);
  playMockingbird(G, pl);
  MC.ACTIONS.resolveChooseEnemy(G, { uid: G.villain.uid });
  assert(G.villain.status.stunned === 1, '빌런 선택 시 빌런 기절');
  assert(minion.status.stunned === 0, '하수인은 기절 안 됨');
}

// 유효하지 않은 대상 거부
{
  const G = mk(7004); const pl = G.players[0]; pl.form = 'hero';
  const minion = MC.makeInstance(G, 'mister-sinister', {});
  minion.hp = 5; minion.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(minion);
  playMockingbird(G, pl);
  let threw = false;
  try { MC.ACTIONS.resolveChooseEnemy(G, { uid: 'bogus-uid' }); } catch(e){ threw = true; }
  assert(threw, '후보 아닌 대상 선택은 거부');
}

console.log('══ 적 선택(chooseEnemy) + 모킹버드 회귀 통과 ══');
