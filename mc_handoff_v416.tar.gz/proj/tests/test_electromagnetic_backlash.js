/* test_electromagnetic_backlash.js — 전자기 반발(01174) 배신 회귀
   ★ 신규 discardTopEnergyDamage: 각 플레이어 덱 top 5장 버림 → 에너지 자원 수만큼 피해.
   사용: node tests/test_electromagnetic_backlash.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
// 에너지 자원 카드 찾기
const ENERGY_CARD = Object.keys(MC.CARDS).find(k => ((MC.CARDS[k].resources) || {}).energy > 0);

// ① 덱 top 5장 버림
{
  const G = mk(79001); const pl = G.players[0]; pl.form = 'hero';
  // 덱을 자원 없는(에너지 0) 카드로 채워 피해 0 검증
  pl.deck = [];
  for (let i = 0; i < 8; i++) pl.deck.push(MC.makeInstance(G, 'shuri', {})); // shuri = physical
  const d0 = pl.deck.length; const disc0 = (pl.discard || []).length;
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'electromagnetic-backlash', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.deck.length === d0 - 5, '덱 top 5장 버림 (' + d0 + '→' + pl.deck.length + ')');
  assert((pl.discard || []).length === disc0 + 5, '버린 더미 +5');
  assert(pl.hp === hp0, '에너지 0 카드: 피해 없음');
}

// ② 에너지 자원 카드 버리면 피해
if (ENERGY_CARD){
  const G = mk(79002); const pl = G.players[0]; pl.form = 'hero';
  const eEnergy = (MC.CARDS[ENERGY_CARD].resources).energy;
  pl.deck = [];
  for (let i = 0; i < 5; i++) pl.deck.push(MC.makeInstance(G, ENERGY_CARD, {}));
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'electromagnetic-backlash', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  const expected = eEnergy * 5;
  assert(pl.hp === hp0 - expected, '에너지 자원 ' + expected + ' → ' + expected + ' 피해 (' + hp0 + '→' + pl.hp + ')');
} else {
  console.log('✓ (에너지 자원 카드 없음 — 스킵)');
}

// ③ 덱이 5장 미만이면 있는 만큼만
{
  const G = mk(79003); const pl = G.players[0]; pl.form = 'hero';
  pl.deck = [MC.makeInstance(G, 'shuri', {}), MC.makeInstance(G, 'shuri', {})];
  const inst = MC.makeInstance(G, 'electromagnetic-backlash', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.deck.length === 0, '덱 2장 → 전부 버림');
}

console.log('══ 전자기 반발 (discardTopEnergyDamage) 회귀 통과 ══');
