/* test_identity_boost_ux — 신분 액션 폼별 독립성 + 부스트★ 하수인 중복 모달 억제
   ① 캡틴마블: 알터에고 액션과 히어로 액션은 폼별로 독립 (한쪽 사용이 다른 쪽을 막지 않음)
   ② 부스트★로 배치된 하수인은 revealLog에 fromBoostStar 표시 → 별도 공개 모달 억제(부스트 오버레이가 순서대로 안내) */
require('../mc_engine.js'); require('../mc_cards.js');
const MC = globalThis.MC;
let pass = 0, fail = 0;
function assert(c, m){ if (c){ pass++; } else { fail++; console.log('✗ ' + m); } }

/* ① 신분 액션 폼별 독립 */
{
  const G = MC.makeGameState({ seed:1, players:[{ heroCode:'01010a', deckCodes:Array(40).fill('energy') }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes:MC.buildEncounter('rhino') });
  MC.setupGame(G);
  const pl = G.players[0];
  if (pl.form !== 'alter-ego'){ MC.flipForm(G, pl, { force:true }); pl.formChangedThisRound = false; }
  // 알터에고 액션 (Commander: draw)
  MC.dispatch(G, { type:'useIdentityAction', player: pl.uid });
  assert(pl.usedIdentityActionThisRound['alter-ego'] === true, '① 알터에고 액션 사용 기록');
  assert(!pl.usedIdentityActionThisRound['hero'], '① 히어로 액션은 아직 미사용 (독립)');
  // 히어로로 전환
  MC.dispatch(G, { type:'flipForm', player: pl.uid });
  assert(pl.form === 'hero', '① 히어로 전환');
  // 히어로 액션 (Rechannel: payEnergy1 + selfHeal1) — 피해 만들고 에너지 지불
  pl.hp = pl.maxHp - 2;
  const e = pl.hand.find(c => c.defCode === 'energy');
  MC.dispatch(G, { type:'useIdentityAction', player: pl.uid, payment: e ? [{ kind:'hand', uid:e.uid }] : [] });
  assert(pl.usedIdentityActionThisRound['hero'] === true, '① 히어로 액션 사용 성공 (알터에고 사용과 무관하게 독립)');
}

/* ② 부스트★ 하수인 배치 → fromBoostStar 표시 (별도 모달 억제 대상) */
{
  const G = MC.makeGameState({ seed:11, players:[{ heroCode:'01010a', deckCodes:Array(40).fill('energy') }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes:MC.buildEncounter('klaw') });
  MC.setupGame(G);
  const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const wr = MC.makeInstance(G, 'weapons-runner', {});
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: 2, boostCard: wr };
  const len0 = (G.revealLog || []).length;
  MC.dispatch(G, { type:'resolveDefense', player: pl.uid, defender:'none' });
  const news = (G.revealLog || []).slice(len0);
  const minionEntry = news.find(r => r.type === 'minion');
  assert(minionEntry && minionEntry.fromBoostStar === true, '② 부스트★ 하수인 revealLog에 fromBoostStar 표시');
  assert(!!G.fxBoostReveal && G.fxBoostReveal.events.some(e => e.star && e.star.kind === 'minion'), '② 부스트 오버레이가 ★하수인 등장 안내');
  assert(pl.engagedMinions.some(m => m.defCode === 'weapons-runner'), '② 하수인 실제 전장 배치');
}

console.log((fail === 0 ? '[test_identity_boost_ux] ' + pass + '개 통과' : '[test_identity_boost_ux] ' + fail + '개 실패'));
if (fail > 0) process.exit(1);
