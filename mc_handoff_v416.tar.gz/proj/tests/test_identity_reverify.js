/* test_identity_reverify.js — 6영웅 신분 카드 실제 작동 재검증 (영구 회귀)
   ★ 매 게임 사용되는 기본 공격(+공격 VFX)·폼 전환·신분 능력을 실제 dispatch로 검증.
   VFX 등록 확인 위해 ui/mc_vfx.js 로드.
   사용: node tests/test_identity_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
global.window = global;
global.document = {
  addEventListener(){}, getElementById(){ return null }, querySelector(){ return null },
  querySelectorAll(){ return [] }, createElement(){ return { style:{}, classList:{add(){},remove(){}}, appendChild(){}, remove(){} } },
  body:{ appendChild(){} },
};
global.localStorage = { getItem(){return null}, setItem(){}, removeItem(){} };
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
require(path.join(ROOT, 'ui/mc_vfx.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mkHero(code, deckKey){
  const dk = MC.PRESET_DECKS[deckKey];
  const G = MC.makeGameState({ seed:2,
    players:[{ heroCode: code, deckCodes: (dk ? dk.cards.slice() : []) }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') });
  MC.setupGame(G);
  return G;
}

/* 6영웅: 기본 공격 VFX 등록 + 기본 공격 실행(스탯대로 피해) + 폼 전환 왕복 */
const HEROES = {
  '01001a': ['spiderman',        '스파이더맨',   'strike'],
  '01010a': ['captain-marvel',   '캡틴마블',     'photonBlast'],
  '01019a': ['she-hulk',         '쉬헐크',       'gammaSmash'],
  '01029a': ['iron-man',         '아이언맨',     'repulsorBeam'],
  '01040a': ['black-panther',    '블랙팬서',     'claws'],
  '03001a': ['captain-america',  '캡틴아메리카', 'shieldToss'],
};
for (const code in HEROES){
  const [deckKey, name, expVfx] = HEROES[code];
  // 공격 VFX 등록 확인
  const vAtk = MC.cardDef(code).vfx && MC.cardDef(code).vfx.basicAttack;
  assert(vAtk === expVfx && !!MC.VFX[vAtk], name + ' — 기본 공격 VFX 등록(' + expVfx + ')');
  // 기존 vfx 보존 확인
  const v = MC.cardDef(code).vfx;
  assert(v.formChange === 'formFlip' && v.basicThwart === 'patrol', name + ' — 기존 vfx(formChange/basicThwart) 보존');

  const G = mkHero(code, deckKey); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  // 기본 공격 → 빌런에 attack 스탯만큼 피해
  const atk = MC.statOf(G, pl, 'attack'); const hp0 = G.villain.hp;
  pl.exhausted = false; pl.status.stunned = 0;
  MC.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: G.villain.uid });
  assert(G.villain.hp === hp0 - atk, name + ' — 기본 공격 → 빌런 ' + atk + ' 피해');
  // 폼 전환 왕복(hero→alter→hero)
  MC.flipForm(G, pl, { force:true }); const f1 = pl.form;
  MC.flipForm(G, pl, { force:true });
  assert(f1 !== 'hero' && pl.form === 'hero', name + ' — 폼 전환 왕복');
}

/* 신분 능력 개별 검증 */
// 캡틴마블 Rechannel: 에너지 지불 → 회복 + 드로우
{
  const G = mkHero('01010a', 'captain-marvel'); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  pl.hp = pl.maxHp - 3; pl.usedIdentityActionThisRound = {}; pl.exhausted = false;
  const e = MC.makeInstance(G, 'energy', {}); pl.hand.push(e);
  const hp0 = pl.hp;
  MC.dispatch(G, { type:'useIdentityAction', player: pl.uid, payment:[{ kind:'hand', uid: e.uid }] });
  assert(pl.hp > hp0, '캡틴마블 Rechannel — 에너지 지불 → 회복');
}
// 캡틴아메리카 하루 종일도 가능해!: 손패 버림 → 준비(소진 해제)
{
  const G = mkHero('03001a', 'captain-america'); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  pl.exhausted = true; pl.usedIdentityActionThisRound = {};
  if (pl.hand.length === 0) pl.hand.push(MC.makeInstance(G, 'energy', {}));
  MC.dispatch(G, { type:'useIdentityAction', player: pl.uid, discard:[pl.hand[0].uid] });
  assert(pl.exhausted === false, '캡틴아메리카 하루 종일 — 소진 해제(readySelf)');
}
// 쉬헐크 sheHulkPower: 알터→히어로 폼 전환 시 능력 발동(무에러)
{
  const G = mkHero('01019a', 'she-hulk'); const pl = G.players[0];
  if (pl.form === 'hero') MC.flipForm(G, pl, { force:true });
  const hp0 = G.villain.hp;
  MC.flipForm(G, pl, { force:true });
  assert(G.villain.hp <= hp0, '쉬헐크 폼 전환 → 감마 파워(sheHulkPower) 발동');
}
// 아이언맨 dynamicHandSize: 손패 크기 계산 무에러
{
  const G = mkHero('01029a', 'iron-man'); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  const hs = MC.handSizeOf ? MC.handSizeOf(G, pl) : MC.cardDef('01029a').handSize;
  assert(typeof hs === 'number' && hs >= 1, '아이언맨 dynamicHandSize — 손패 크기 계산(' + hs + ')');
}

console.log('\n[test_identity_reverify] ' + pass + '개 통과 — 6영웅 신분 재검증 완료');
