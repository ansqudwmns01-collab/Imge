/* test_advance_assault.js — Advance(01186) / Assault(01187) 배신 회귀
   ★ villainSchemes / villainAttacks(기존) + isHeroForm/isAlterEgoForm 조건.
   사용: node tests/test_advance_assault.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① Advance: 빌런 암약 → 메인 위협 +빌런SCH
{
  const G = mk(91001); const pl = G.players[0]; pl.form = 'hero';
  const ms = G.mainScheme; const t0 = ms.threat || 0;
  const sch = G.villain.scheme || 0;
  const inst = MC.makeInstance(G, 'advance', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert((ms.threat || 0) === t0 + sch, 'Advance: 메인 위협 +빌런SCH(' + sch + ') (' + t0 + '→' + ms.threat + ')');
}

// ② Assault(히어로 폼): 빌런 공격 → defense pending
{
  const G = mk(91002); const pl = G.players[0]; pl.form = 'hero';
  const inst = MC.makeInstance(G, 'assault', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'defense', 'Assault(히어로): 빌런 공격 (defense pending)');
  assert(inst.surge !== true, 'Assault(히어로): surge 없음');
}

// ③ Assault(알터에고 폼): surge, 공격 없음
{
  const G = mk(91003); const pl = G.players[0]; pl.form = 'alter-ego';
  const inst = MC.makeInstance(G, 'assault', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(inst.surge === true, 'Assault(알터에고): surge 획득');
  assert(!(G.pending && G.pending.kind === 'defense'), 'Assault(알터에고): 빌런 공격 없음');
}

console.log('══ Advance / Assault (표준 인카운터) 회귀 통과 ══');
