/* test_genetic_enhancement.js — 유전자 강화(01163) 부착 회귀
   ★ 신규 attachToHighestHpMinion + attachStats{hp,maxHp}. 하수인 없으면 surge.
   사용: node tests/test_genetic_enhancement.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 최고 인쇄 HP 하수인에 부착 + HP +3
{
  const G = mk(68001); const pl = G.players[0];
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion';   // HP 6
  const k = MC.makeInstance(G, 'killmonger', {}); k.type = 'minion'; // HP 5
  pl.engagedMinions.push(k, t);
  const hp0 = t.hp;
  const inst = MC.makeInstance(G, 'genetic-enhancement', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(t.attachments && t.attachments.some(a => a.uid === inst.uid), '최고 HP 하수인(타이타니아 HP6)에 부착');
  assert(t.hp === hp0 + 3, 'HP +3 (' + hp0 + '→' + t.hp + ')');
  assert(t.maxHp === (MC.cardDef('titania').hp) + 3, 'maxHp +3');
}

// ② 타이타니아 강화 시 동적 ATK도 상승 (HP 9 → ATK 9)
{
  const G = mk(68002); const pl = G.players[0];
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion';
  pl.engagedMinions.push(t);
  const inst = MC.makeInstance(G, 'genetic-enhancement', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(MC.enemyAtk(G, t) === 9, 'HP 9 → 동적 ATK 9');
}

// ③ 하수인 없으면 surge
{
  const G = mk(68003); const pl = G.players[0];
  const inst = MC.makeInstance(G, 'genetic-enhancement', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(inst.surge === true, '하수인 없음 → surge');
}

// ④ 부착 제거(detach) 시 HP 원복
{
  const G = mk(68004); const pl = G.players[0];
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion';
  pl.engagedMinions.push(t);
  const inst = MC.makeInstance(G, 'genetic-enhancement', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  const hpUp = t.hp;
  if (MC.detachFrom) MC.detachFrom(G, inst);
  assert(t.hp === hpUp - 3 || t.maxHp === MC.cardDef('titania').hp, '부착 제거 시 스탯 원복');
}

console.log('══ 유전자 강화 (attachToHighestHpMinion) 회귀 통과 ══');
