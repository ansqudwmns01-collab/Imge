/* test_doomsday_chair.js — The Doomsday Chair(01183) 사이드 스킴 회귀
   ★ summonNamedMinionIfAbsent(M.O.D.O.K. 소환) 재사용 + 시작 위협 8 + 가속.
   사용: node tests/test_doomsday_chair.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 필드 확인
{
  const d = MC.cardDef('doomsday-chair-scheme');
  assert(d.baseThreat === 8, '시작 위협 8 고정');
  assert(d.accelIcons === 1, '가속 아이콘 1');
}

// ② 공개: M.O.D.O.K. 소환
{
  const G = mk(88001); const pl = G.players[0]; pl.form = 'hero';
  revealSide(G, pl, 'doomsday-chair-scheme');
  const modokPresent = pl.engagedMinions.some(m => (m.defCode || m.code) === 'modok');
  assert(modokPresent, 'M.O.D.O.K. 소환 (전장 교전)');
}

// ③ M.O.D.O.K. 이미 전장이면 중복 소환 안 함
{
  const G = mk(88002); const pl = G.players[0]; pl.form = 'hero';
  const m0 = MC.makeInstance(G, 'modok', {}); m0.type = 'minion';
  pl.engagedMinions.push(m0);
  revealSide(G, pl, 'doomsday-chair-scheme');
  const modokCount = pl.engagedMinions.filter(m => (m.defCode || m.code) === 'modok').length;
  assert(modokCount === 1, 'M.O.D.O.K. 중복 소환 안 함 (1명 유지)');
}

// ④ 시작 위협 8 반영
{
  const G = mk(88003); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'doomsday-chair-scheme');
  assert(ss.threat === 8, '공개 위협 = 8 (실제 ' + ss.threat + ')');
}

console.log('══ The Doomsday Chair (M.O.D.O.K. 소환 + 위협 8) 회귀 통과 ══');
