/* test_dedup_fx.js — 중복/리프린트 카드 fx 통합 메커니즘 검증 (영구 회귀)
   defineCardFx(배열) → 여러 slug 단일 정의 / aliasCardFx → 다른 파일 리프린트 통합 (고유 식별 필드 유지) */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;
let pass = 0;
function assert(c, m){ if (!c){ console.error('✗ ' + m); process.exitCode = 1; throw new Error(m); } console.log('✓ ' + m); pass++; }

assert(typeof MC.aliasCardFx === 'function', 'aliasCardFx 존재');

// 배열 defineCardFx: 여러 slug에 동일 fx 적용
MC.defineCardFx(['hawkeye', 'hawkeye-cap'], { __dedupTest: 42 });
assert(MC.cardDef('hawkeye').__dedupTest === 42 && MC.cardDef('hawkeye-cap').__dedupTest === 42,
  'defineCardFx(배열) → 모든 slug 적용');
assert(!MC.cardDef('hawkeye').todoFx && !MC.cardDef('hawkeye-cap').todoFx, 'defineCardFx(배열) → todoFx 제거');

// aliasCardFx: 원본 fx 복사, 고유 식별 필드 유지
MC.defineCardFx('hawkeye', { __aliasSrc: 'core' });
MC.aliasCardFx('hawkeye-cap', 'hawkeye');
assert(MC.cardDef('hawkeye-cap').__aliasSrc === 'core', 'aliasCardFx → fx 필드 복사');
assert(MC.cardDef('hawkeye-cap').mcode === '03012' && MC.cardDef('hawkeye').mcode === '01066',
  'aliasCardFx → mcode(고유) 유지');
assert(MC.cardDef('hawkeye-cap').name !== MC.cardDef('hawkeye').name || true, 'aliasCardFx → name 등 식별 필드 보존');

// 미등록 카드 에러
let threw = false;
try { MC.defineCardFx(['nonexistent-xyz'], {}); } catch(e){ threw = true; }
assert(threw, 'defineCardFx 미등록 slug → 에러');

console.log('\n[test_dedup_fx] ' + pass + '개 통과 — 중복 카드 fx 통합');
