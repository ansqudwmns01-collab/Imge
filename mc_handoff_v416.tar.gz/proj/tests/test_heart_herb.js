/* test_heart_herb.js — 심장 모양 허브(01158) 배신 회귀
   ★ 신규 grantTough(빌런+교전하수인 tough 부여) + surge(기존). 부스트★=빌런만.
   사용: node tests/test_heart_herb.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  G.villain.status = { stunned:0, confused:0, tough:0 };
  return G;
}

// ① 공개: 빌런 + 교전 하수인 tough 부여 + surge
{
  const G = mk(63001); const pl = G.players[0]; pl.form = 'hero';
  const m1 = MC.makeInstance(G, 'killmonger', {}); m1.type = 'minion'; m1.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m1);

  const inst = MC.makeInstance(G, 'heart-shaped-herb', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.villain.status.tough === 1, '빌런 tough 부여');
  assert(m1.status.tough === 1, '교전 하수인 tough 부여');
  assert(inst.surge === true, 'surge 플래그 획득');
}

// ② 비교전 하수인은 tough 안 받음
{
  const G = mk(63002); const pl = G.players[0]; pl.form = 'hero';
  const other = G.players[0]; // 단일 플레이어라 교전 하수인만 대상
  const m2 = MC.makeInstance(G, 'killmonger', {}); m2.type = 'minion'; m2.status = { stunned:0, confused:0, tough:0 };
  // engagedMinions에 넣지 않음 (비교전)
  const inst = MC.makeInstance(G, 'heart-shaped-herb', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(m2.status.tough === 0, '비교전 하수인 tough 미부여');
  assert(G.villain.status.tough === 1, '빌런은 tough 부여');
}

// ③ 부스트★: 빌런만 tough (하수인 제외)
{
  const G = mk(63003); const pl = G.players[0]; pl.form = 'hero';
  const m3 = MC.makeInstance(G, 'killmonger', {}); m3.type = 'minion'; m3.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m3);
  const bc = MC.makeInstance(G, 'heart-shaped-herb', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  assert(G.villain.status.tough === 1, '부스트★: 빌런 tough');
  assert(m3.status.tough === 0, '부스트★: 하수인은 제외');
}

console.log('══ 심장 모양 허브 (grantTough + surge) 회귀 통과 ══');
