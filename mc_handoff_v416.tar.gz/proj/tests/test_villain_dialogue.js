/* test_villain_dialogue.js — 전 빌런 대사 인덱스 검증 (하나씩 아닌 전수 검사)
   ★ 모든 빌런(quoteKey 기준)이 필수 대사 kind를 표준 이름으로 갖는지 검사.
   ★ 빌런 표준 kind: entrance / stageUp / defeat (+ heroDefeat / schemeComplete 권장).
     — 과거 클로가 enter/stageChange(잘못된 kind)를 써서 등장·단계전환 대사가 침묵했던 버그 재발 방지.
   ★ 등장 vfx가 있으면 그 vfx 함수가 ctx.el 또는 ctx.cardEl 어느 쪽으로도 앵커 가능해야 함
     (playVfx 정규화 + playVillainEntrance가 el/cardEl 둘 다 전달하므로 데이터 kind만 검증).
   사용: node tests/test_villain_dialogue.js
   ※ 대사(QUOTES)는 빌드 HTML에만 있으므로 빌드 HTML을 vm으로 로드해 검증. */
'use strict';
const fs = require('fs'), vm = require('vm'), path = require('path');
const ROOT = path.dirname(__dirname);
const buildPath = path.join(ROOT, 'marvel_champions_build.html');

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}

if (!fs.existsSync(buildPath)){
  console.log('⚠ marvel_champions_build.html 없음 — build.py 먼저 실행. (스킵)');
  process.exit(0);
}
const html = fs.readFileSync(buildPath, 'utf8');
const scripts = html.match(/<script>([\s\S]*?)<\/script>/g) || [];
const ctx = { console };
ctx.window = ctx; ctx.globalThis = ctx;
ctx.document = { createElement:()=>({style:{},appendChild:()=>{}}), querySelectorAll:()=>[], querySelector:()=>null, body:{} };
ctx.setTimeout = ()=>{}; ctx.localStorage = { getItem:()=>null, setItem:()=>{} };
vm.createContext(ctx);
for (const s of scripts){ try { vm.runInContext(s.replace(/<\/?script>/g,''), ctx, { timeout:5000 }); } catch(e){} }
const MC = ctx.MC;
assert(!!MC, '빌드 HTML에서 MC 로드');

// 전 빌런(quoteKey 있는 것) 인덱스 수집
const villains = Object.keys(MC.CARDS).filter(k => MC.CARDS[k].type === 'villain');
const byKey = {};
for (const v of villains){
  const d = MC.cardDef(v);
  if (!d.quoteKey) continue;
  (byKey[d.quoteKey] = byKey[d.quoteKey] || []).push(v);
}
const keys = Object.keys(byKey);
assert(keys.length > 0, '빌런 quoteKey 인덱스 수집 (' + keys.length + '종)');

// 필수 kind: entrance/stageUp/defeat. 표준 이름이 아니면(enter/stageChange 등) 침묵 버그.
const REQUIRED = ['entrance', 'stageUp', 'defeat'];
const RECOMMENDED = ['heroDefeat', 'schemeComplete'];
// 잘못 쓰기 쉬운 kind (있으면 표준 이름으로 안 잡혀 침묵) — 감지해 실패시킴
const WRONG = { enter:'entrance', stageChange:'stageUp', stage:'stageUp', dead:'defeat' };

for (const qk of keys){
  const sample = byKey[qk][0];
  // 필수 kind 존재
  for (const kind of REQUIRED)
    assert(MC.hasQuote(qk, kind), '빌런 ' + qk + ': 필수 대사 [' + kind + '] 존재');
  // 잘못된 kind 이름 사용 금지 (표준으로 안 잡혀 침묵)
  for (const wrong in WRONG)
    assert(!MC.hasQuote(qk, wrong),
      '빌런 ' + qk + ': 잘못된 kind [' + wrong + '] 미사용 (표준=' + WRONG[wrong] + ')');
  // 권장 kind (플레이어 패배 대사)
  for (const kind of RECOMMENDED)
    if (!MC.hasQuote(qk, kind)) console.log('  · (권장) ' + qk + ' [' + kind + '] 없음 — 플레이어 패배 대사 보강 권장');
}

// 등장 vfx가 있는 빌런은 그 vfx 함수가 실제 등록돼 있어야 함
for (const qk of keys){
  const d = MC.cardDef(byKey[qk][0]);
  if (d.vfx && d.vfx.entrance)
    assert(typeof MC.VFX[d.vfx.entrance] === 'function',
      '빌런 ' + qk + ': 등장 vfx [' + d.vfx.entrance + '] 함수 등록됨');
}

console.log('══ 빌런 대사 인덱스 검증 통과 (' + keys.length + '빌런) ══');
