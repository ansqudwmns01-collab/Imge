/* test_wakanda_order.js — 와칸다 포에버! 플레이어 순서 선택 회귀
   ★ 고정 순서 하드코딩 제거 → 플레이어가 BP 업그레이드 해결 순서를 탭으로 선택.
   ★ 업그레이드 1개면 자동 해결, 2개+면 pending(wakandaOrder)로 순서 선택.
   사용: node tests/test_wakanda_order.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(){
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01040a', deckCodes: MC.PRESET_DECKS['black-panther'].cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  const pl = G.players[0]; pl.form = 'hero';
  return { G, pl };
}
function addUp(G, pl, code){ const u = MC.makeInstance(G, code, {}); pl.playArea.upgrades.push(u); return u; }

// ① 업그레이드 0개 → 안전 (pending 없음, 크래시 없음)
{
  const { G, pl } = mk();
  MC.EFFECTS.wakandaForever(G, {}, { player: pl });
  assert(!G.pending, '업그레이드 0개: pending 없음 (안전)');
}

// ② 업그레이드 1개 → 자동 해결 (pending 없음)
{
  const { G, pl } = mk();
  addUp(G, pl, 'energy-daggers');
  MC.EFFECTS.wakandaForever(G, {}, { player: pl });
  assert(!G.pending, '업그레이드 1개: 자동 해결 (pending 없음)');
}

// ③ 업그레이드 3개 → 순서 선택 pending, 탭한 순서대로 해결
{
  const { G, pl } = mk();
  const u1 = addUp(G, pl, 'energy-daggers');
  const u2 = addUp(G, pl, 'panther-claws');
  const u3 = addUp(G, pl, 'vibranium-suit');
  MC.EFFECTS.wakandaForever(G, {}, { player: pl });
  assert(G.pending && G.pending.kind === 'wakandaOrder', '업그레이드 3개: wakandaOrder pending');
  assert(G.pending.remaining.length === 3, 'pending remaining 3개');
  assert(G.pending.total === 3, 'pending total 3');

  // 플레이어가 선택한 순서로 탭 (u2 → u3 → u1)
  MC.dispatch(G, { type:'resolveWakandaStep', uid: u2.uid });
  assert(G.pending && G.pending.remaining.length === 2, 'u2 탭 후 remaining 2');
  assert(G.pending.resolved[0] === u2.uid, '해결 순서 기록: u2 먼저');

  MC.dispatch(G, { type:'resolveWakandaStep', uid: u3.uid });
  assert(G.pending && G.pending.remaining.length === 1, 'u3 탭 후 remaining 1');

  MC.dispatch(G, { type:'resolveWakandaStep', uid: u1.uid });
  assert(!G.pending, '마지막 u1 탭 후 pending 종료(null)');
}

// ④ 유효하지 않은 uid 탭 → 차단
{
  const { G, pl } = mk();
  addUp(G, pl, 'energy-daggers');
  addUp(G, pl, 'panther-claws');
  MC.EFFECTS.wakandaForever(G, {}, { player: pl });
  let blocked = false;
  try { MC.dispatch(G, { type:'resolveWakandaStep', uid:'nonexistent' }); } catch(e){ blocked = true; }
  assert(blocked, '잘못된 업그레이드 uid 탭 차단');
}

// ⑤ 순서 하드코딩 제거 확인: 소스에 고정 prio 배열 없음
{
  const src = require('fs').readFileSync(path.join(ROOT, 'cards/mc_cards_fx.js'), 'utf8');
  const hasHardcodedPrio = /prio\s*=\s*\['vibranium-suit','tactical-genius-bp'/.test(src);
  assert(!hasHardcodedPrio, '고정 순서 하드코딩(prio 배열) 제거됨');
}

console.log('══ 와칸다 포에버 순서 선택 회귀 통과 ══');
