/* test_retaliate.js — 보복(Retaliate) 회귀
   ★ 공식 룰: 트리거는 "공격받음" — 방어로 0피해·강인 흡수여도 발동. 단 살아남아야 함.
   ★ 중복 발동 없음(applyDamage noRetaliate 위임). 보복은 재보복 안 함.
   사용: node tests/test_retaliate.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mkBP(){
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01040a', deckCodes: MC.PRESET_DECKS['black-panther'].cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  const pl = G.players[0]; pl.form = 'hero';
  return { G, pl };
}

// BP는 히어로 폼에서 retaliate 1
{
  const { G, pl } = mkBP();
  assert(MC.cardDef('01040a').retaliate === 1, 'BP 신분 retaliate 1');
}

// ① 신분 방어로 피해 0 → 그래도 역습 발동 (공격받았으니까)
{
  const { G, pl } = mkBP();
  const attacker = G.villain; attacker.attack = 1;   // DEF 2로 완전 흡수
  G.pending = { kind:'defense', player: pl.uid, attackerUid: attacker.uid, amount: 1, prevented: 0 };
  const vHp0 = attacker.hp;
  MC.dispatch(G, { type:'resolveDefense', player: pl.uid, defender:'identity' });
  assert(attacker.hp === vHp0 - 1, '신분 방어로 0피해여도 역습 1 발동 (' + vHp0 + '→' + attacker.hp + ')');
}

// ② 무방어(피해 입음) → 역습 발동 (한 번만)
{
  const { G, pl } = mkBP();
  const attacker = G.villain; attacker.attack = 2;
  G.pending = { kind:'defense', player: pl.uid, attackerUid: attacker.uid, amount: 2, prevented: 0 };
  const vHp0 = attacker.hp, pHp0 = pl.hp;
  MC.dispatch(G, { type:'resolveDefense', player: pl.uid, defender:'none' });
  assert(pl.hp === pHp0 - 2, '무방어 시 히어로 피해 2 입음');
  assert(attacker.hp === vHp0 - 1, '무방어여도 역습 1 발동 — 중복 아님 (' + vHp0 + '→' + attacker.hp + ')');
}

// ③ 강인(Tough) 흡수 → 그래도 역습 발동
{
  const { G, pl } = mkBP();
  const attacker = G.villain; attacker.attack = 3;
  pl.status.tough = 1;   // 강인으로 흡수
  G.pending = { kind:'defense', player: pl.uid, attackerUid: attacker.uid, amount: 3, prevented: 0 };
  const vHp0 = attacker.hp, pHp0 = pl.hp;
  MC.dispatch(G, { type:'resolveDefense', player: pl.uid, defender:'none' });
  assert(pl.hp === pHp0, '강인 흡수 — 히어로 무피해');
  assert(pl.status.tough === 0, '강인 토큰 소모');
  assert(attacker.hp === vHp0 - 1, '강인 흡수여도 역습 1 발동 (' + vHp0 + '→' + attacker.hp + ')');
}

// ④ 히어로가 공격에서 전멸(사망)하면 역습 안 함 — 살아남아야 함
{
  const { G, pl } = mkBP();
  const attacker = G.villain; attacker.attack = 99;
  pl.hp = 1;   // 치명타로 사망
  G.pending = { kind:'defense', player: pl.uid, attackerUid: attacker.uid, amount: 99, prevented: 0 };
  const vHp0 = attacker.hp;
  MC.dispatch(G, { type:'resolveDefense', player: pl.uid, defender:'none' });
  assert(pl.hp <= 0, '히어로 사망 (HP ' + pl.hp + ')');
  assert(attacker.hp === vHp0, '사망 시 역습 미발동 (살아남아야 함) — 빌런 HP 유지');
}

// ⑤ 보복은 재보복하지 않음 (무한루프 방지) — 빌런에도 retaliate 부여했다고 가정해도 1회
{
  const { G, pl } = mkBP();
  const attacker = G.villain; attacker.attack = 1; attacker.retaliate = 5;  // 빌런에 보복 부여
  const pHp0 = pl.hp, vHp0 = attacker.hp;
  G.pending = { kind:'defense', player: pl.uid, attackerUid: attacker.uid, amount: 1, prevented: 0 };
  MC.dispatch(G, { type:'resolveDefense', player: pl.uid, defender:'identity' });
  // BP 역습 1 → 빌런 피해. 빌런 보복은 "BP의 역습 피해(isRetaliate)"에 재보복 안 함.
  assert(attacker.hp === vHp0 - 1, 'BP 역습 1 빌런 피해');
  assert(pl.hp === pHp0, '빌런 보복은 BP 역습에 재보복 안 함 (히어로 HP 유지)');
}

// ⑥ 공격 사이드: 히어로가 역습-적을 공격 → 대상 생존 시 역습 받음 (피해 정상)
{
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; pl.form = 'hero';
  const att = MC.makeInstance(G, 'solid-sound-body', {}); MC.attachTo(G, att, G.villain);
  assert(G.villain.retaliate === 1, '솔리드 사운드 바디 → 클로 retaliate 1');
  const pHp0 = pl.hp;
  MC.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: G.villain.uid });
  assert(pl.hp === pHp0 - 1, '히어로가 역습-적 공격 → 역습 1 받음 (' + pHp0 + '→' + pl.hp + ')');
}

// ⑦ 공격 사이드 + 강인: 대상이 강인으로 피해 흡수해도 역습 발동 (공격받았으니까)
{
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; pl.form = 'hero';
  const att = MC.makeInstance(G, 'solid-sound-body', {}); MC.attachTo(G, att, G.villain);
  G.villain.status.tough = 1;   // 강인으로 히어로 공격 흡수
  const pHp0 = pl.hp, vHp0 = G.villain.hp;
  MC.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: G.villain.uid });
  assert(G.villain.hp === vHp0, '강인 흡수 — 빌런 무피해');
  assert(G.villain.status.tough === 0, '강인 토큰 소모');
  assert(pl.hp === pHp0 - 1, '강인 흡수여도 히어로는 역습 1 받음 (' + pHp0 + '→' + pl.hp + ')');
}

// ⑧ 공격 사이드 중복 방지: 역습이 딱 1회만 (noRetaliate 위임 + 명시 호출 이중발동 없음)
{
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; pl.form = 'hero';
  const att = MC.makeInstance(G, 'solid-sound-body', {}); MC.attachTo(G, att, G.villain);
  const pHp0 = pl.hp;
  MC.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: G.villain.uid });
  assert(pl.hp === pHp0 - 1, '역습 정확히 1회 (2회면 -2가 됨) — 중복 없음');
}

// ⑨ 공격 사이드 동료: 동료가 역습-적 공격 → 동료가 역습 받음
//   ※ 동료는 공격 시 atkCost 1(공식 룰: 동료 소모)도 받으므로, 역습-적 공격 시 총 2(atkCost1+역습1).
{
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; pl.form = 'hero';
  const ally0 = MC.makeInstance(G, 'agent-13', {});
  const atkCost = ally0.atkCost || 0;   // 동료 소모 피해 (공식 룰)
  const att = MC.makeInstance(G, 'solid-sound-body', {}); MC.attachTo(G, att, G.villain);
  const ally = MC.makeInstance(G, 'agent-13', {}); ally.exhausted = false; pl.playArea.allies.push(ally);
  const aHp0 = ally.hp;
  MC.dispatch(G, { type:'allyAttack', player: pl.uid, allyUid: ally.uid, targetUid: G.villain.uid });
  assert(ally.hp === aHp0 - (atkCost + 1), '동료가 역습-적 공격 → atkCost' + atkCost + '+역습1 = ' + (atkCost+1) + ' 피해 (' + aHp0 + '→' + ally.hp + ')');
}

// ⑩ 대조군: 동료가 역습 없는 적 공격 → atkCost만 (역습 없음, 이중발동 검증)
{
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; pl.form = 'hero';
  const ally = MC.makeInstance(G, 'agent-13', {}); ally.exhausted = false; pl.playArea.allies.push(ally);
  const atkCost = ally.atkCost || 0;
  const aHp0 = ally.hp;   // 클로는 기본 retaliate 없음
  MC.dispatch(G, { type:'allyAttack', player: pl.uid, allyUid: ally.uid, targetUid: G.villain.uid });
  assert(ally.hp === aHp0 - atkCost, '역습 없는 적 공격 → atkCost만 (역습 미발동 확인, ' + aHp0 + '→' + ally.hp + ')');
}

console.log('══ 보복(Retaliate) 회귀 통과 ══');
