/* test_ready_timing — 준비(ready)/드로우 타이밍 (공식 RRG)
   ★ 준비/드로우는 "플레이어 페이즈 종료(endPlayerPhase)"에서만 일어난다.
   ★ 라운드 종료(endRound=빌런 페이즈 후)에는 준비하지 않는다.
   → 빌런 페이즈에 방어 등으로 소진한 카드는 다음 플레이어 페이즈 내내 소진 유지 (방어의 대가).
   과거 버그: endRound에서 이중 준비 → 방어 소진이 사라짐. */
require('../mc_engine.js'); require('../mc_cards.js');
const MC = globalThis.MC;
let pass = 0, fail = 0;
function assert(c, m){ if (c){ pass++; } else { fail++; console.log('✗ ' + m); } }

function mk(){
  const G = MC.makeGameState({ seed:9, players:[{ heroCode:'03001a', deckCodes:Array(45).fill('energy') }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes:MC.buildEncounter('rhino') });
  MC.setupGame(G); return G;
}

/* 1. endPlayerPhase는 준비한다 */
{
  const G = mk(); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const ally = MC.makeInstance(G, 'maria-hill', {}); ally.ownerUid = pl.uid; pl.playArea.allies.push(ally);
  pl.exhausted = true; ally.exhausted = true;
  MC.dispatch(G, { type:'endPlayerPhase' });
  assert(pl.exhausted === false && ally.exhausted === false, 'endPlayerPhase는 히어로·동료 준비');
}

/* 2. 빌런 페이즈에 방어로 소진 → 라운드 넘어가도 소진 유지 (endRound는 준비 안 함) */
{
  const G = mk(); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const ally = MC.makeInstance(G, 'maria-hill', {}); ally.ownerUid = pl.uid; pl.playArea.allies.push(ally);
  MC.dispatch(G, { type:'endPlayerPhase' });
  // 빌런 페이즈 진입 후 방어로 소진했다고 가정
  pl.exhausted = true; ally.exhausted = true;
  const roundBefore = G.round;
  let guard = 0;
  while (G.phase !== 'player' && guard++ < 80){
    if (G.pending){
      const k = G.pending.kind;
      if (k === 'defense') MC.dispatch(G, { type:'resolveDefense', player:G.pending.player, defender:'none' });
      else if (k === 'revealChoice') MC.dispatch(G, { type:'resolveRevealChoice', player:G.pending.player, choice:(G.pending.options||['skip'])[0] });
      else if (k === 'chooseEnemy') MC.dispatch(G, { type:'resolveChooseEnemy', player:G.pending.player, uid:(G.pending.candidates||[])[0] });
      else break;
    } else MC.dispatch(G, { type:'villainStep' });
  }
  assert(G.round === roundBefore + 1, '라운드가 넘어감 (' + roundBefore + '→' + G.round + ')');
  assert(pl.exhausted === true, '방어 소진 히어로 — 다음 플레이어 페이즈까지 소진 유지 (endRound 준비 안 함)');
  assert(ally.exhausted === true, '방어 소진 동료 — 다음 플레이어 페이즈까지 소진 유지');
  // 다음 플레이어 페이즈 종료 시 비로소 준비돼야 함
  MC.dispatch(G, { type:'endPlayerPhase' });
  assert(pl.exhausted === false && ally.exhausted === false, '다음 endPlayerPhase에서 비로소 준비됨');
}

console.log((fail === 0 ? '[test_ready_timing] ' + pass + '개 통과' : '[test_ready_timing] ' + fail + '개 실패'));
if (fail > 0) process.exit(1);
