/* test_modok.js — M.O.D.O.K.(01184) 하수인 회귀
   ★ Retaliate 2 (db 필드로 applyDamage 자동 처리, opt.source가 캐릭터면 발동).
   사용: node tests/test_modok.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 필드 확인
{
  const d = MC.cardDef('modok');
  assert(d.retaliate === 2, 'Retaliate 2');
  assert(d.attack === 2 && d.hp === 8, 'ATK 2 / HP 8');
}

// ② 공격받으면 공격자에게 반격 2 피해
{
  const G = mk(89001); const pl = G.players[0]; pl.form = 'hero';
  const m = MC.makeInstance(G, 'modok', {}); m.type = 'minion';
  m.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m);
  const hp0 = pl.hp;
  MC.applyDamage(G, m, 3, { source: pl, byAttack: true });
  assert(pl.hp === hp0 - 2, 'Retaliate: 공격자에게 2 반격 피해 (' + hp0 + '→' + pl.hp + ')');
}

// ③ 출처 없는 효과 피해는 반격 없음
{
  const G = mk(89002); const pl = G.players[0]; pl.form = 'hero';
  const m = MC.makeInstance(G, 'modok', {}); m.type = 'minion';
  m.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m);
  const hp0 = pl.hp;
  MC.applyDamage(G, m, 3, {});
  assert(pl.hp === hp0, '출처 없는 피해는 반격 없음 (' + hp0 + ' 유지)');
}

console.log('══ M.O.D.O.K. (Retaliate 2) 회귀 통과 ══');
