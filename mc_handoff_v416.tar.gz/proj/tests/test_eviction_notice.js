/* test_eviction_notice.js — 퇴거 통지(01165) obligation 회귀
   ★ obligation 재사용(exhaustTarget/resolveObligation) + discardFromHand + surge.
   사용: node tests/test_eviction_notice.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 공개: 선택 pending (2옵션)
{
  const G = mk(70001); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'eviction-notice', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'revealChoice', '의무 공개 — 선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (소진/손패버림)');
}

// ② exhaust 옵션: 소진 + 게임 제거
{
  const G = mk(70002); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'eviction-notice', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'exhaust' });
  assert(pl.exhausted === true, 'exhaust: 피터 파커 소진');
  assert((G.removedFromGame || []).includes('eviction-notice'), 'exhaust: 게임에서 제거');
}

// ③ discard 옵션: 손패 무작위 1장 버림 + surge
{
  const G = mk(70003); const pl = G.players[0]; pl.form = 'hero';
  // 손패 보장
  while (pl.hand.length < 3) pl.hand.push(MC.makeInstance(G, 'shuri', {}));
  const h0 = pl.hand.length;
  const inst = MC.makeInstance(G, 'eviction-notice', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'discard' });
  assert(pl.hand.length === h0 - 1, 'discard: 손패 1장 감소 (' + h0 + '→' + pl.hand.length + ')');
  assert(inst.surge === true, 'discard: surge 획득');
  assert(pl.exhausted !== true, 'discard: 소진 안 함');
}

console.log('══ 퇴거 통지 (obligation + discardFromHand + surge) 회귀 통과 ══');
