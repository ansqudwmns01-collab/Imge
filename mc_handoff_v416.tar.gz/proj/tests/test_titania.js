/* test_titania.js — 타이타니아(01162) 하수인 회귀
   ★ 동적 ATK = 현재 HP (atkEqualsHp, MC.enemyAtk 헬퍼).
   사용: node tests/test_titania.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 필드 확인
{
  const d = MC.cardDef('titania');
  assert(d.atkEqualsHp === true, 'atkEqualsHp 플래그');
  assert(d.hp === 6, 'HP 6');
}

// ② 동적 ATK = 현재 HP (풀피 6 → ATK 6)
{
  const G = mk(67001); const pl = G.players[0];
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion';
  pl.engagedMinions.push(t);
  assert(MC.enemyAtk(G, t) === 6, 'HP 6 → ATK 6');
}

// ③ 피해로 HP 감소 시 ATK 비례 감소
{
  const G = mk(67002); const pl = G.players[0];
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion'; t.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(t);
  MC.applyDamage(G, t, 4, { source: pl });
  assert(t.hp === 2, 'HP 6→2 (4 피해)');
  assert(MC.enemyAtk(G, t) === 2, 'HP 2 → ATK 2 (동적 감소)');
}

// ④ HP 0 이하면 ATK 0 (음수 방지)
{
  const G = mk(67003); const pl = G.players[0];
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion';
  t.hp = 0;
  assert(MC.enemyAtk(G, t) === 0, 'HP 0 → ATK 0');
}

// ⑤ 일반 하수인은 고정 ATK (enemyAtk가 attack 필드 반환)
{
  const G = mk(67004); const pl = G.players[0];
  const km = MC.makeInstance(G, 'killmonger', {}); km.type = 'minion';
  assert(MC.enemyAtk(G, km) === 2, '일반 하수인(킬몽거)은 고정 ATK 2');
}

console.log('══ 타이타니아 (동적 ATK = HP) 회귀 통과 ══');
