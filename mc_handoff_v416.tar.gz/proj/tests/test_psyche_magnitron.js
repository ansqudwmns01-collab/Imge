/* test_psyche_magnitron.js — 사이키-마그니트론(01176) 사이드 스킴 회귀
   ★ whenRevealed 추가 위협 +1/인 + Hazard 아이콘(db 필드).
   사용: node tests/test_psyche_magnitron.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 필드 확인
{
  const d = MC.cardDef('psyche-magnitron');
  assert(d.baseThreat === 3, '시작 위협 3 고정');
  assert(d.hazard === true, 'Hazard 아이콘');
}

// ② 공개: 시작 3 + 추가 1/인 = 솔로 4
{
  const G = mk(81001); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'psyche-magnitron');
  assert(ss.threat === 4, '공개 위협 = 3 + 1/인 = 4 (솔로)');
}

console.log('══ 사이키-마그니트론 (Hazard 사이드 스킴) 회귀 통과 ══');
