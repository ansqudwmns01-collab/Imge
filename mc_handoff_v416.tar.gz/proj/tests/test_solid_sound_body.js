/* test_solid_sound_body.js — 견고한 음체(01119) 클로 부착 회귀
   ★ 완전 인덱스 타입: 부착 연출 + attachStats(retaliate 1) + removeAbility(⚡🧠💪). 커스텀 핸들러 없음.
   사용: node tests/test_solid_sound_body.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

assert(!MC.CARDS['solid-sound-body'].todoFx, 'todoFx 해제');
assert(!MC.CARDS['01119'], '01119 중복 stub 제거됨');
assert(MC.CARDS['solid-sound-body'].attachStats.retaliate === 1, 'attachStats retaliate 1');

// 부착 연출
{
  const G = mk(13001); const pl = G.players[0]; pl.form = 'hero';
  const ssb = MC.makeInstance(G, 'solid-sound-body', {}); MC.attachTo(G, ssb, G.villain);
  MC.fireCardHook(G, ssb, 'whenRevealed', { player: pl });
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'sonicBodyHarden', '부착: 결정화 연출');
  assert(G.villain.attachments.some(a => a.uid === ssb.uid), '클로에 부착됨');
}

// retaliate: 클로 공격 시 공격자 1 피해
{
  const G = mk(13002); const pl = G.players[0]; pl.form = 'hero';
  const ssb = MC.makeInstance(G, 'solid-sound-body', {}); MC.attachTo(G, ssb, G.villain);
  const hp0 = pl.hp;
  MC.applyDamage(G, G.villain, MC.statOf(G, pl, 'attack'), { source: pl, isAttack: true });
  assert(pl.hp === hp0 - 1, '클로 공격 시 반격 1 피해 (' + hp0 + '→' + pl.hp + ')');
}
// 부착 없으면 반격 없음
{
  const G = mk(13003); const pl = G.players[0]; pl.form = 'hero';
  const hp0 = pl.hp;
  MC.applyDamage(G, G.villain, MC.statOf(G, pl, 'attack'), { source: pl, isAttack: true });
  assert(pl.hp === hp0, '부착 없음: 반격 없음');
}

// 히어로 행동 제거: ⚡🧠💪 각 1 지불
{
  const G = mk(13004); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const ssb = MC.makeInstance(G, 'solid-sound-body', {}); MC.attachTo(G, ssb, G.villain);
  const pay = [];
  for (const s of ['relentless-assault','tigra-ally','uppercut']){   // energy, mental, physical
    const c = MC.makeInstance(G, s, {}); c.ownerUid = pl.uid; pl.hand.push(c); pay.push({ kind:'hand', uid:c.uid });
  }
  MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: ssb.uid, payment: pay });
  assert(!G.villain.attachments.some(a => a.uid === ssb.uid), '히어로 행동: 제거됨');
}

console.log('══ 견고한 음체 (인덱스 타입 부착 · retaliate) 회귀 통과 ══');
