/* test_rhino_stampede.js — 쇄도(01106) 폼 분기 배신 회귀
   ★ 범용 인덱스(formBranch/surge/villainAttacks stunOnHit/playVfx)로 데이터 실행.
   - 알터에고: 이 카드 급증
   - 히어로: 라이노 공격, 피해 입은 캐릭터 기절(stunOnHit)
   사용: node tests/test_rhino_stampede.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function fire(G, pl){
  const inst = MC.makeInstance(G, 'stampede', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}

// 알터에고 분기 — 급증, 공격 없음
{
  const G = mk(3101); const pl = G.players[0]; pl.form = 'alter';
  const inst = fire(G, pl);
  assert(inst.surge === true, '알터에고: 이 카드 급증(surge)');
  assert(!G.pending, '알터에고: 공격 pending 없음');
}

// 히어로 분기 — 라이노 공격 pending(stunOnHit) + 돌진 연출
{
  const G = mk(3102); const pl = G.players[0]; pl.form = 'hero';
  fire(G, pl);
  assert(G.pending && G.pending.kind === 'defense', '히어로: 라이노 공격 방어 pending');
  assert(G.pending.stunOnHit === true, '히어로: stunOnHit 플래그');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'rhinoRampage', '히어로: 돌진 연출(rhinoRampage)');
  // 무방어 → 피해 입고 기절
  const atk = G.villain.attack, hp0 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp0 - atk, '무방어: 라이노 ATK ' + atk + ' 피해 (' + hp0 + '→' + pl.hp + ')');
  assert(pl.status.stunned === 1, '무방어: 피해 입어 기절(stunned)');
}

// 히어로 분기 — 피해 완전 방지 시 기절 X (stunOnHit은 dmgDone>0 조건)
{
  const G = mk(3103); const pl = G.players[0]; pl.form = 'hero';
  fire(G, pl);
  G.pending.prevented = 999;   // 전량 방지 → dmgDone 0
  const hp0 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp0, '전량방지: 피해 0 (HP 불변)');
  assert(!pl.status.stunned, '전량방지: 피해 없으면 기절 X');
}

console.log('══ 쇄도 (데이터 기반 폼분기 + stunOnHit) 회귀 통과 ══');
