/* test_bomb_explosion.js — 폭발!(01111) Bomb Scare 조건 분기 배신 회귀
   ★ 완전 인덱스 타입(데이터 조건 분기): condCheck 'schemeInPlay'(+negate),
      dealDamage 'amountFromSchemeThreat', target 'firstPlayer'. 커스텀 핸들러 없음.
   - 폭탄 위협(bomb-threat) 전장에 있으면: 그 위협 수만큼 첫 플레이어에 피해
   - 없으면: 급증(surge)
   사용: node tests/test_bomb_explosion.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: Array(20).fill('im-tough') });
  MC.setupGame(G);
  return G;
}
function fire(G, pl){
  const ex = MC.makeInstance(G, 'explosion', {});
  MC.fireCardHook(G, ex, 'whenRevealed', { player: pl });
  return ex;
}
function withBomb(G, threat){
  const bt = MC.makeInstance(G, 'bomb-threat', {}); bt.threat = threat; bt.isMain = false;
  G.sideSchemes.push(bt); return bt;
}

// 폭탄 위협 있음 → 위협 수만큼 피해, 급증 없음
{
  const G = mk(10001); const pl = G.players[0]; pl.form = 'hero';
  withBomb(G, 3);
  const hp0 = pl.hp;
  const ex = fire(G, pl);
  assert(pl.hp === hp0 - 3, '폭탄 위협(3): 첫 플레이어 3 피해 (' + hp0 + '→' + pl.hp + ')');
  assert(!ex.surge, '폭탄 위협 있음: 급증 없음');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'explosionBlast', '폭발 연출');
}
// 위협 수만큼 정확히 (5 → 5 피해)
{
  const G = mk(10003); const pl = G.players[0]; pl.form = 'hero';
  withBomb(G, 5);
  const hp0 = pl.hp;
  fire(G, pl);
  assert(pl.hp === hp0 - 5, '폭탄 위협(5): 5 피해 (위협 수 = 피해량)');
}
// 폭탄 위협 없음 → 급증, 피해 없음
{
  const G = mk(10002); const pl = G.players[0]; pl.form = 'hero';
  const hp0 = pl.hp;
  const ex = fire(G, pl);
  assert(pl.hp === hp0, '폭탄 위협 없음: 피해 없음');
  assert(ex.surge === true, '폭탄 위협 없음: 급증');
}
// 폭탄 위협이 위협 0(격퇴 직전)이면 schemeInPlay 미충족 → 급증
{
  const G = mk(10004); const pl = G.players[0]; pl.form = 'hero';
  const bt = MC.makeInstance(G, 'bomb-threat', {}); bt.threat = 0; bt.isMain = false; G.sideSchemes.push(bt);
  const hp0 = pl.hp;
  const ex = fire(G, pl);
  assert(pl.hp === hp0, '폭탄 위협 위협0: 피해 없음');
  assert(ex.surge === true, '폭탄 위협 위협0: 급증 (schemeInPlay는 threat>0)');
}

// negate 범용성 — schemeInPlay negate 확인
{
  const G = mk(10005);
  assert(MC.condCheck(G, { type:'schemeInPlay', slug:'bomb-threat' }, {}) === false, 'schemeInPlay: 없으면 false');
  assert(MC.condCheck(G, { type:'schemeInPlay', slug:'bomb-threat', negate:true }, {}) === true, 'negate: 반전 true');
}

// 조건별 연출 분리 (메모리 원칙) — 대사 자체는 vfx_index(빌드 HTML)가 검증
{
  const G = mk(11001); const pl = G.players[0]; pl.form = 'hero';
  withBomb(G, 3);
  fire(G, pl);
  assert(G.fxCardEffect.vfx === 'explosionBlast', '폭탄 있음 분기: 폭발 연출(explosionBlast)');
}
{
  const G = mk(11002); const pl = G.players[0]; pl.form = 'hero';
  fire(G, pl);
  assert(G.fxCardEffect.vfx === 'fuseSpark', '폭탄 없음 분기: 급증 불씨 연출(fuseSpark)');
}

console.log('══ 폭발! (인덱스 타입 조건 분기 배신) 회귀 통과 ══');
