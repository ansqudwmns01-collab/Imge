/* test_concussive_blast.js — 충격파 폭발(01154) 배신 회귀
   ★ resolveTarget allFriendly(모든 히어로+동료) / controlled(활성 플레이어 히어로+동료).
   - 공개: 각 우호 캐릭터 1 피해 · ★부스트: 통제 캐릭터 각 1 피해
   사용: node tests/test_concussive_blast.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function addAlly(G, pl, code){
  const a = MC.makeInstance(G, code, {}); a.ownerUid = pl.uid;
  a.hp = a.maxHp = (MC.cardDef(code).hp || 3);
  pl.playArea.allies.push(a);
  return a;
}

// ① 공개: 우호 캐릭터(히어로 + 동료) 각 1 피해
{
  const G = mk(52001); const pl = G.players[0]; pl.form = 'hero';
  const ally = addAlly(G, pl, 'black-cat');
  const hp0 = pl.hp, ahp0 = ally.hp;
  const inst = MC.makeInstance(G, 'concussive-blast', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.hp === hp0 - 1, '히어로 피해 1 (' + hp0 + '→' + pl.hp + ')');
  assert(ally.hp === ahp0 - 1, '동료 피해 1 (' + ahp0 + '→' + ally.hp + ')');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'concussiveBlast', '광역 연출');
}

// ② 부스트★: 통제 캐릭터(활성 플레이어 히어로 + 동료) 각 1 피해
{
  const G = mk(52002); const pl = G.players[0]; pl.form = 'hero';
  const ally = addAlly(G, pl, 'black-cat');
  const hp0 = pl.hp, ahp0 = ally.hp;
  const bc = MC.makeInstance(G, 'concussive-blast', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  assert(pl.hp === hp0 - 1 && ally.hp === ahp0 - 1, '부스트★: 통제 캐릭터(히어로+동료) 각 1 피해');
}

// ③ 동료 없을 때 히어로만 피해 (안전)
{
  const G = mk(52003); const pl = G.players[0]; pl.form = 'hero';
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'concussive-blast', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.hp === hp0 - 1, '동료 없음: 히어로만 피해 1');
}

console.log('══ 충격파 폭발 (allFriendly/controlled 광역) 회귀 통과 ══');
