/* test_caught_off_guard.js — Caught Off Guard(01188) 배신 회귀
   ★ 신규 discardUpgradeOrSupport(영구/부착 제외) + discardedUpgradeOrSupportNone 조건 surge.
   사용: node tests/test_caught_off_guard.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// 선택 pending(pickControlledDiscard)이 뜨면 지정 uid를 골라 해소하는 헬퍼
function resolvePick(G, uid){
  if (G.pending && G.pending.kind === 'pickControlledDiscard'){
    MC.ACTIONS.resolvePickControlledDiscard(G, { player: G.pending.player, uid });
  }
}

// ① 업그레이드 버림 (후보 2장 이상이면 플레이어 선택)
{
  const G = mk(92001); const pl = G.players[0]; pl.form = 'hero';
  const u = MC.makeInstance(G, 'panther-claws', {});
  pl.playArea.upgrades.push(u);
  const inst = MC.makeInstance(G, 'caught-off-guard', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  resolvePick(G, u.uid);   // 후보 2장+ 이면 이 카드를 선택해 버림
  assert(!pl.playArea.upgrades.some(x => x.uid === u.uid), '업그레이드 1장 버림 (선택)');
  assert(inst.surge !== true, '버렸으면 surge 없음');
}

// ② 지원(support) 버림 (업그레이드 없을 때)
{
  const G = mk(92002); const pl = G.players[0]; pl.form = 'hero';
  pl.playArea.upgrades = [];
  const supCode = Object.keys(MC.CARDS).find(k => MC.CARDS[k].type === 'support' && !MC.CARDS[k].permanent);
  if (supCode){
    const s = MC.makeInstance(G, supCode, {});
    pl.playArea.supports.push(s);
    const inst = MC.makeInstance(G, 'caught-off-guard', {});
    MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
    resolvePick(G, s.uid);
    assert(!pl.playArea.supports.some(x => x.uid === s.uid), '지원 1장 버림');
  } else { console.log('✓ (비영구 지원 카드 없음 — 스킵)'); }
}

// ③ 전장에 업그레이드/지원 없으면 surge
{
  const G = mk(92003); const pl = G.players[0]; pl.form = 'hero';
  pl.playArea.upgrades = []; pl.playArea.supports = [];
  const inst = MC.makeInstance(G, 'caught-off-guard', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(inst.surge === true, '버릴 카드 없음 → surge');
}

// ④ 영구(permanent) 카드는 선택 불가 → surge
{
  const G = mk(92004); const pl = G.players[0]; pl.form = 'hero';
  pl.playArea.upgrades = []; pl.playArea.supports = [];
  const permCode = Object.keys(MC.CARDS).find(k => MC.CARDS[k].permanent && (MC.CARDS[k].type === 'upgrade' || MC.CARDS[k].type === 'support'));
  if (permCode){
    const pc = MC.makeInstance(G, permCode, {});
    const arr = MC.CARDS[permCode].type === 'support' ? pl.playArea.supports : pl.playArea.upgrades;
    arr.push(pc);
    const inst = MC.makeInstance(G, 'caught-off-guard', {});
    MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
    assert(arr.some(x => x.uid === pc.uid), '영구 카드는 버려지지 않음');
    assert(inst.surge === true, '영구만 있으면 surge');
  } else { console.log('✓ (영구 업그레이드/지원 없음 — 스킵)'); }
}

// ⑤ 부착물(attachedTo)은 선택 불가
{
  const G = mk(92005); const pl = G.players[0]; pl.form = 'hero';
  pl.playArea.upgrades = []; pl.playArea.supports = [];
  const attached = MC.makeInstance(G, 'panther-claws', {}); attached.attachedTo = 'someUid';
  pl.playArea.upgrades.push(attached);
  const inst = MC.makeInstance(G, 'caught-off-guard', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.playArea.upgrades.some(x => x.uid === attached.uid), '부착물은 버려지지 않음');
  assert(inst.surge === true, '부착물만 있으면 surge');
}

console.log('══ Caught Off Guard (업그레이드/지원 버림, 영구·부착 제외) 회귀 통과 ══');
