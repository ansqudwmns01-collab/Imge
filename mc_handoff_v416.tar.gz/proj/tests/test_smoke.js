/* test_smoke.js — 골격 스모크 테스트
   1) 1인·4인 게임 생성/셋업/수 라운드 자동 진행 — 크래시 0
   2) 결정성: 같은 seed + 같은 액션 로그 → 직렬화 상태 완전 동일 (멀티 동기화 계약)
   사용: node tests/test_smoke.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);

function freshMC(){
  // 모듈 캐시 제거 후 새 전역으로 로드 (결정성 재현 비교용)
  delete globalThis.MC;
  for (const k of Object.keys(require.cache)) delete require.cache[k];
  require(path.join(ROOT, 'mc_engine.js'));
  require(path.join(ROOT, 'mc_cards.js'));
  return globalThis.MC;
}

function seedDeck(){
  // 시드 카드로 40장 덱 구성 (데이터 검증용 임시)
  const d = [];
  for (let i=0;i<20;i++) d.push('backflip');
  for (let i=0;i<20;i++) d.push('swinging-web-kick');
  return d;
}
function encDeck(){
  const d = [];
  for (let i=0;i<10;i++) d.push('hydra-mercenary');
  for (let i=0;i<5;i++) d.push('sandman');
  return d;
}

function playGame(MC, nPlayers, seed, maxRounds){
  const G = MC.makeGameState({
    seed,
    players: Array.from({length:nPlayers}, () => ({ heroCode:'01001a', deckCodes: seedDeck() })),
    villainCode: '01094',
    mainScheme: '01097b',
    encounterCodes: encDeck(),
  });
  MC.setupGame(G);
  // ★ 정책 RNG는 G의 RNG와 분리 — 액션 외부에서 G RNG 소모 금지 (재생 계약)
  let ps = seed ^ 0xA5A5A5A5;
  const prand = () => { let t=(ps+=0x6D2B79F5); t=Math.imul(t^(t>>>15),t|1); t^=t+Math.imul(t^(t>>>7),t|61); return ((t^(t>>>14))>>>0)/4294967296; };
  let rounds = 0, guard = 0;
  while (!G.over && rounds < maxRounds && guard++ < 2000){
    if (G.pending){
      if (G.pending.kind === 'revealChoice'){
        // 조우 선택 (하이드라 폭파범 등): 랜덤 선택지 하나
        const opts = G.pending.options || [];
        const pick = opts[Math.floor(prand()*opts.length)] || opts[0];
        MC.dispatch(G, { type:'resolveRevealChoice', player: G.pending.player, option: pick.key });
        continue;
      }
      const dp = G.players.find(x=>x.uid===G.pending.player);
      const canDef = dp && !dp.exhausted;
      // 멜터 강제 동료 방어: 준비된 동료가 있으면 반드시 동료로 방어
      const readyAlly = dp && dp.playArea.allies.find(a=>!a.exhausted);
      let defender;
      if (G.pending.mustDefendWithAlly && readyAlly) defender = readyAlly.uid;
      else defender = (canDef && prand()<0.5)?'identity':'none';
      MC.dispatch(G, { type:'resolveDefense', player: G.pending.player, defender });
      continue;
    }
    for (const pl of MC.playersInOrder(G)){
      if (G.over || G.pending) break;
      if (prand() < 0.5 && !pl.formChangedThisRound) MC.dispatch(G, { type:'flipForm', player: pl.uid });
    }
    if (!G.over && !G.pending){ MC.dispatch(G, { type:'endPlayerPhase' }); rounds++; }
  }
  return G;
}

let fail = 0;
function check(name, ok){ console.log((ok?'✓':'✗') + ' ' + name); if(!ok) fail++; }

// 1) 1인 게임
{
  const MC = freshMC();
  const G = playGame(MC, 1, 12345, 30);
  check('1인 게임 30라운드 내 크래시 없음', true);
  check('1인 게임 로그 생성', G.gameLog.length > 5);
}
// 2) 4인 게임
{
  const MC = freshMC();
  const G = playGame(MC, 4, 99999, 30);
  check('4인 게임 30라운드 내 크래시 없음', true);
  check('4인 플레이어 수 = 4', G.players.length === 4);
  check('빌런 HP 4인 스케일 (14×4=56)', G.villain.maxHp === 56);
  check('메인 스킴 한도 4인 스케일 (7×4=28)', G.mainScheme.maxThreat === 28);
}
// 3) 결정성 (멀티플레이 동기화 계약)
{
  const MC1 = freshMC();
  const A = playGame(MC1, 4, 424242, 10);
  const sA = MC1.serialize(A);
  const MC2 = freshMC();
  const B = playGame(MC2, 4, 424242, 10);
  const sB = MC2.serialize(B);
  check('결정성: 같은 시드·정책 → 동일 직렬화 상태', sA === sB);
  // 액션 로그 재생 경로: A의 로그를 새 상태에 재생 → 동일 상태
  const MC3 = freshMC();
  const C = MC3.makeGameState({
    seed: 424242,
    players: Array.from({length:4}, () => ({ heroCode:'01001a', deckCodes: seedDeck() })),
    villainCode:'01094', mainScheme:'01097b', encounterCodes: encDeck(),
  });
  MC3.setupGame(C);
  let replayOK = true;
  try {
    for (const a of JSON.parse(sA).actionLog) MC3.dispatch(C, a);
  } catch(e){ replayOK = false; console.error('  재생 오류:', e.message); }
  check('액션 로그 재생 크래시 없음', replayOK);
  check('★ 재생 상태 = 원본 상태 (엄격 일치)', MC3.serialize(C) === sA);
}

console.log(fail === 0 ? '[test_smoke] 전체 통과' : `[test_smoke] 실패 ${fail}건`);
process.exit(fail === 0 ? 0 : 1);
