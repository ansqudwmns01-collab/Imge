/* test_phase3_core.js — 코어 카드 능력 등록 검증 (1차: 즉발 조우 카드)
   사용: node tests/test_phase3_core.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

/* 테스트 전용 픽스처 덱 — 프리셋(게임 데이터)에 결합하지 않기 위한 범용 카드 풀.
   결제/페이즈 테스트가 꺼내 쓰는 카드(tackle, energy-barrier, power-of-protection 등) 포함. */
const FIXTURE_DECK = [
  'black-cat','black-widow-ally','mockingbird','nick-fury',
  'backflip','backflip',
  'enhanced-spider-sense','enhanced-spider-sense',
  'get-behind-me','get-behind-me','get-behind-me',
  'preemptive-strike','preemptive-strike','preemptive-strike',
  'swinging-web-kick','swinging-web-kick','swinging-web-kick',
  'tackle','tackle','tackle',
  'energy','genius','strength',
  'power-of-protection','power-of-protection',
  'aunt-may',
  'energy-barrier','energy-barrier','energy-barrier',
  'enhanced-awareness','enhanced-awareness',
  'indomitable','indomitable','indomitable',
  'spider-tracer','spider-tracer',
  'web-shooter','web-shooter',
  'webbed-up','webbed-up',
];

let fail = 0;
function check(name, ok, extra){ console.log((ok?'✓':'✗')+' '+name+(ok?'':('  ← '+(extra||'')))); if(!ok) fail++; }

function newGame(form){
  const G = MC.makeGameState({
    seed: 3,
    players: [{ heroCode:'01001a', deckCodes: FIXTURE_DECK.slice() }],
    villainCode:'01094', mainScheme:'01097b',
    encounterCodes: MC.buildEncounter('rhino'),
  });
  MC.setupGame(G);
  if (form === 'hero' && G.players[0].form === 'alter-ego') MC.dispatch(G, { type:'flipForm', player:'P0' });
  if (form === 'alter-ego' && G.players[0].form === 'hero') MC.dispatch(G, { type:'flipForm', player:'P0' });
  return G;
}
// 조우 카드 인스턴스를 만들어 whenRevealed 직접 발화 (엔진 resolveEncounterCard 경유가 이상적이나
// 여기선 핸들러 단위 검증 — inst mock)
function mkInst(defCode){
  const def = MC.cardDef(defCode);
  return { uid:'t_'+defCode, defCode, kind: def.type, type: def.type,
    status:{stunned:0,confused:0,tough:0}, surge:false };
  // whenRevealed는 정의 전용 필드 — fireCardHook이 cardDef에서 조회 (실전과 동일)
}

/* shocker: 각 히어로 1 피해 */
{
  const G = newGame('hero'); const pl = G.players[0];
  const hp0 = pl.hp;
  const inst = mkInst('shocker');
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  check('shocker — 히어로 1 피해', pl.hp === hp0 - 1, pl.hp+'/'+hp0);
}

/* hard-to-keep-down: 빌런 회복 (데미지 상태에서) */
{
  const G = newGame('hero');
  G.villain.hp = G.villain.maxHp - 6;
  const inst = mkInst('hard-to-keep-down');
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  check('hard-to-keep-down — 빌런 4 회복', G.villain.hp === G.villain.maxHp - 2, G.villain.hp);
  check('  회복 발생 → 급증 없음', inst.surge === false);
}
/* hard-to-keep-down: 풀피 → 급증 */
{
  const G = newGame('hero');
  G.villain.hp = G.villain.maxHp;
  const inst = mkInst('hard-to-keep-down');
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  check('hard-to-keep-down — 풀피면 급증', inst.surge === true);
}

/* im-tough: 강인함 부여 / 이미 있으면 급증 */
{
  const G = newGame('hero');
  const inst = mkInst('im-tough');
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  check('im-tough — 라이노 강인함', G.villain.status.tough === 1);
  const inst2 = mkInst('im-tough');
  MC.fireCardHook(G, inst2, 'whenRevealed', { player: G.players[0] });
  check('im-tough — 이미 강인함이면 급증', inst2.surge === true);
  check('  강인함 중복 부여 안 됨', G.villain.status.tough === 1, ''+G.villain.status.tough);
}

/* false-alarm: 혼란 / 이미 혼란이면 급증 */
{
  const G = newGame('hero'); const pl = G.players[0];
  const inst = mkInst('false-alarm');
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  check('false-alarm — 히어로 혼란', pl.status.confused === 1);
  const inst2 = mkInst('false-alarm');
  MC.fireCardHook(G, inst2, 'whenRevealed', { player: pl });
  check('false-alarm — 이미 혼란이면 급증', inst2.surge === true);
}

/* tackle — 적 기절 + 피지컬 지불 시 3 피해 */
{
  const G = newGame('hero'); const pl = G.players[0];
  const hpV0 = G.villain.hp;
  // 손패에 tackle + physical 자원(backflip=물리1) 확보
  function pull(code){ const i=pl.deck.findIndex(c=>c.defCode===code); return i>=0?pl.deck.splice(i,1)[0]:null; }
  const tk = pull('tackle'); const p1=pull('backflip'), p2=pull('tackle')||pull('preemptive-strike'), p3=pull('get-behind-me');
  pl.hand.push(tk); [p1,p2,p3].forEach(c=>c&&pl.hand.push(c));
  // 물리 아이콘 3 확보용: backflip(물리1) 3장 필요 → 넉넉히 물리 카드 pull
  const phys=[]; for(let i=0;i<3;i++){ const c=pull('backflip')||pull('preemptive-strike'); if(c) phys.push(c), pl.hand.push(c); }
  const payEls = phys.map(c=>({kind:'hand',uid:c.uid}));
  // 비용 3 — 물리 아이콘으로 지불
  const paySum = MC.computePayment(G, pl, payEls, MC.cardDef('tackle')).sum;
  if (paySum >= 3){
    MC.dispatch(G, { type:'playCard', player:'P0', cardUid:tk.uid, payment:payEls, targets:[G.villain.uid] });
    check('tackle — 빌런 기절', G.villain.status.stunned === 1);
    check('tackle — 피지컬 지불 3 피해', G.villain.hp === hpV0 - 3, G.villain.hp+'/'+hpV0);
  } else {
    check('tackle — 물리 자원 확보(픽스처)', false, '물리 아이콘 '+paySum);
  }
}

/* 등록 상태: todoFx 해제 확인 */
for (const code of ['shocker','hard-to-keep-down','im-tough','false-alarm','tackle','swinging-web-kick']){
  check(code + ' — todoFx 해제', !MC.cardDef(code).todoFx);
}

/* 코어 #1 — Spider-Sense: 빌런 공격 개시 시 카드 1장 드로우 */
{
  const G = newGame('hero'); const pl = G.players[0];
  const hand0 = pl.hand.length;
  // 빌런 페이즈로 진입 → 빌런 활성화(공격) 시 인터럽트 발화
  MC.dispatch(G, { type:'endPlayerPhase' });
  // pending(defense)이 섰고, 그 직전에 spiderSense가 카드를 뽑았어야 함
  check('Spider-Sense — 공격 개시 시 1장 드로우', pl.hand.length === hand0 + 1, hand0+'→'+pl.hand.length);
  check('  방어 pending 정상 생성', !!(G.pending && G.pending.kind==='defense'));
  check('01001a attackInterrupt 등록', MC.cardDef('01001a').attackInterrupt === 'spiderSense');
  // 알터에고면에선 발동 안 함
  const G2 = newGame('alter-ego'); const pl2 = G2.players[0];
  const h2 = pl2.hand.length;
  MC.dispatch(G2, { type:'endPlayerPhase' });
  // 알터에고는 빌런이 스킴 → 공격 없음 → 드로우 없음
  check('Spider-Sense — 알터에고면 미발동', pl2.hand.length === h2, h2+'→'+pl2.hand.length);
}

/* 코어 #2 — 블랙캣 강제 반응: 덱 위 2장 중 멘탈 인쇄는 손, 나머지 버림 */
{
  const G = newGame('hero'); const pl = G.players[0];
  function mk(code){ return { uid:'bc'+Math.random().toString(36).slice(2), defCode:code,
    kind:MC.cardDef(code).type, type:MC.cardDef(code).type, status:{} }; }
  pl.deck.push(mk('backflip'));  // 물리 → 버림
  pl.deck.push(mk('genius'));    // 멘탈 인쇄 → 손 (맨 위)
  const bc = mk('black-cat');
  const disc0 = pl.discard.length;
  MC.fireCardHook(G, bc, 'whenPlayed', { player: pl });
  check('블랙캣 — 멘탈 카드(genius) 손에 회수', pl.hand.some(c=>c.defCode==='genius'));
  check('블랙캣 — 비멘탈(backflip) 버림', pl.discard.some(c=>c.defCode==='backflip'));
  check('블랙캣 — todoFx 해제', !MC.cardDef('black-cat').todoFx);
  check('블랙캣 vfx: 거미줄설치/발톱/저지',
    MC.cardDef('black-cat').vfx.install==='webInstall' &&
    MC.cardDef('black-cat').vfx.basicAttack==='claw' &&
    MC.cardDef('black-cat').vfx.basicThwart==='patrol');
}

/* 코어 #3 — 공중제비(backflip): 방어 인터럽트로 공격 전체 피해 방지 */
{
  const G = newGame('hero'); const pl = G.players[0];
  function mk(code){ return { uid:'bf'+Math.random().toString(36).slice(2), defCode:code,
    kind:MC.cardDef(code).type, type:MC.cardDef(code).type, status:{}, cost:MC.cardDef(code).cost||0 }; }
  // 빌런 공격 개시 → 방어 pending
  const hp0 = pl.hp;
  MC.dispatch(G, { type:'endPlayerPhase' });
  check('backflip — 방어 pending 생성됨', !!(G.pending && G.pending.kind==='defense'), G.pending&&G.pending.kind);
  // 손에 backflip + 물리 자원(strength) 확보
  const bf = mk('backflip'); const res = mk('strength');
  pl.hand.push(bf, res);
  // backflip은 cost 0 → 결제 없이 플레이 가능
  const before = pl.hp;
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid:bf.uid, payment:[] });
  check('backflip — 방어 pending 해소됨', !G.pending || G.pending.kind!=='defense');
  check('backflip — 피해 0 (전체 방지)', pl.hp === before, before+'→'+pl.hp);
  check('backflip vfx.defense=backflip', MC.cardDef('backflip').vfx.defense==='backflip');
  check('backflip — todoFx 해제', !MC.cardDef('backflip').todoFx);
}

/* 코어 #4 — 강화된 스파이더 센스: 배반 공개 인터럽트로 whenRevealed 취소 (범용 정지점) */
{
  function pull(G,code){ const pl=G.players[0]; const i=pl.deck.findIndex(c=>c.defCode===code); return i>=0?pl.deck.splice(i,1)[0]:null; }
  function mkEnc(code){ return { uid:'ei'+Math.random().toString(36).slice(2), defCode:code, kind:MC.cardDef(code).type, type:MC.cardDef(code).type, status:{}, interruptChecked:false }; }
  // 취소
  {
    const G=newGame('hero'); const pl=G.players[0];
    const ess=pull(G,'enhanced-spider-sense'); const res=pull(G,'swinging-web-kick');
    pl.hand.push(ess,res);
    const t=mkEnc('im-tough'); MC.resolveEncounterCard(G, pl, t);
    check('강화 스파이더센스 — 배반 공개 시 인터럽트 pending', !!(G.pending&&G.pending.kind==='revealInterrupt'));
    const before=G.villain.status.tough||0;
    MC.dispatch(G,{type:'resolveRevealInterrupt', player:'P0', cardUid:ess.uid, payment:[{kind:'hand',uid:res.uid}]});
    check('강화 스파이더센스 — whenRevealed 취소(강인함 미부여)', (G.villain.status.tough||0)===before, ''+(G.villain.status.tough||0));
    check('강화 스파이더센스 — 카드 버려짐', pl.discard.some(c=>c.defCode==='enhanced-spider-sense'));
    check('강화 스파이더센스 — pending 해소', !G.pending);
  }
  // 패스
  {
    const G=newGame('hero'); const pl=G.players[0];
    pl.hand.push(pull(G,'enhanced-spider-sense'));
    const t=mkEnc('im-tough'); MC.resolveEncounterCard(G, pl, t);
    MC.dispatch(G,{type:'resolveRevealInterrupt', player:'P0'}); // 패스
    check('강화 스파이더센스 — 패스 시 정상 발화(강인함 부여)', G.villain.status.tough===1);
    check('강화 스파이더센스 — 패스 시 카드 손에 남음', pl.hand.some(c=>c.defCode==='enhanced-spider-sense'));
  }
  // 인터럽트 카드 없으면 정지점 없이 정상 발화 (초기 손패의 ess 제거)
  {
    const G=newGame('hero'); const pl=G.players[0];
    pl.hand = pl.hand.filter(c=>c.defCode!=='enhanced-spider-sense');
    const t=mkEnc('im-tough'); MC.resolveEncounterCard(G, pl, t);
    check('인터럽트 카드 없음 — 정지점 없이 정상 발화', G.villain.status.tough===1 && !G.pending);
  }
  check('enhanced-spider-sense — interruptOn treachery', MC.cardDef('enhanced-spider-sense').interruptOn.encounterType==='treachery');
  check('enhanced-spider-sense — todoFx 해제', !MC.cardDef('enhanced-spider-sense').todoFx);
}

/* 코어 #6 — 메이 숙모: 활성 능력(소진→4회복), 알터에고 전용, 라운드 준비 */
{
  const G=newGame(); const pl=G.players[0];  // 스파이더맨은 setup 시 알터에고 시작
  if(pl.form==='hero') { pl.formChangedThisRound=false; MC.dispatch(G,{type:'flipForm',player:'P0'}); }
  pl.hp = pl.maxHp - 6;
  pl.playArea.supports.push({ uid:'mayT', defCode:'aunt-may', kind:'support', type:'support', exhausted:false, ownerUid:'P0' });
  const before=pl.hp;
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'mayT'});
  check('메이 숙모 — 피터 파커 4 회복', (pl.hp-before)===4, before+'→'+pl.hp);
  check('메이 숙모 — 소진됨', pl.playArea.supports.find(c=>c.uid==='mayT').exhausted===true);
  let blocked=false; try{ MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'mayT'}); }catch(e){ blocked=/소진/.test(e.message); }
  check('메이 숙모 — 소진 후 재사용 차단', blocked);
  check('메이 숙모 — activatedAbility 등록', !!MC.cardDef('aunt-may').activatedAbility);
  check('메이 숙모 — todoFx 해제', !MC.cardDef('aunt-may').todoFx);
}

/* 코어 #7 — 스파이더 트레이서: 부착 시스템 (하수인 부착 → 처치 시 위협 3 제거) */
{
  const G=newGame('hero'); const pl=G.players[0];
  const minionCode = MC.buildEncounter('rhino').find(c=>MC.cardDef(c).type==='minion');
  const m = MC.makeInstance(G, minionCode, { kind:'minion' });
  m.hp=m.maxHp=MC.cardDef(minionCode).hp; m.engagedWith='P0'; pl.engagedMinions.push(m);
  const tracer = MC.makeInstance(G,'spider-tracer',{}); tracer.ownerUid='P0'; pl.hand.push(tracer);
  const res = MC.makeInstance(G,'swinging-web-kick',{}); res.ownerUid='P0'; pl.hand.push(res);
  MC.resolveScheme(G,'main').threat = 10;
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:tracer.uid, payment:[{kind:'hand',uid:res.uid}], targets:[m.uid]});
  check('스파이더 트레이서 — 하수인에 부착(양방향)', (m.attachments||[]).some(a=>a.uid===tracer.uid) && tracer.attachedTo===m.uid);
  check('스파이더 트레이서 — 부착물은 upgrades 영역에 없음', !pl.playArea.upgrades.includes(tracer));
  // 여러 장 부착 (두 번째 트레이서)
  const t2 = MC.makeInstance(G,'spider-tracer',{}); t2.ownerUid='P0';
  MC.attachTo(G, t2, m);
  check('스파이더 트레이서 — 여러 장 부착', (m.attachments||[]).length===2);
  const thB=MC.resolveScheme(G,'main').threat;
  MC.applyDamage(G, m, 99, { source: pl, isAttack:true });
  check('스파이더 트레이서 — 처치 시 위협 3 제거(장당)', (thB - MC.resolveScheme(G,'main').threat)===6, '2장→6');
  check('스파이더 트레이서 — 부착물 버려짐', pl.discard.filter(c=>c.defCode==='spider-tracer').length===2);
  check('스파이더 트레이서 — 하수인 제거', !pl.engagedMinions.includes(m));
  check('spider-tracer — todoFx 해제', !MC.cardDef('spider-tracer').todoFx);
}

/* 코어 #8 — 웹 슈터: 자원 생성 카드 시스템 (카운터 3, 와일드 생성, 소진, 0이면 버림) */
{
  const G=newGame('hero'); const pl=G.players[0];
  const ws=MC.makeInstance(G,'web-shooter',{}); ws.ownerUid='P0';
  check('웹 슈터 — 카운터 3 초기화', ws.counters===3);
  pl.playArea.upgrades.push(ws);
  // 결제 아이콘: 와일드 1
  const comp=MC.computePayment(G, pl, [{kind:'card',uid:ws.uid}], null);
  check('웹 슈터 — 와일드 1 생성', comp.icons.wild===1);
  // cost 1 이벤트를 웹슈터 자원으로 플레이
  const ev=MC.makeInstance(G,'enhanced-spider-sense',{}); ev.ownerUid='P0'; pl.hand.push(ev);
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:ev.uid, payment:[{kind:'card',uid:ws.uid}]});
  check('웹 슈터 — 결제 후 소진', ws.exhausted===true);
  check('웹 슈터 — 카운터 1 차감', ws.counters===2);
  // 소진 리셋하고 2회 더 사용 → 0 → 버림
  ws.exhausted=false; MC.executePayment(G, pl, [{kind:'card',uid:ws.uid}]);
  ws.exhausted=false; MC.executePayment(G, pl, [{kind:'card',uid:ws.uid}]);
  check('웹 슈터 — 카운터 소진 시 영역 제거', !pl.playArea.upgrades.includes(ws));
  check('웹 슈터 — 카운터 소진 시 버림', pl.discard.includes(ws));
  check('웹 슈터 — 히어로 폼 전용(resourceGenerator.form)', MC.cardDef('web-shooter').resourceGenerator.form==='hero');
  check('web-shooter — todoFx 해제', !MC.cardDef('web-shooter').todoFx);
}

/* 코어 #8 — 웹 슈터: 차후 부착물 제거용 자원 원천 검증 (와일드 범용성 + vfx 링크) */
{
  const G=newGame('hero'); const pl=G.players[0];
  const ws=MC.makeInstance(G,'web-shooter',{}); ws.ownerUid='P0'; pl.playArea.upgrades.push(ws);
  let allCover=true;
  for(const rt of ['physical','mental','energy']){
    ws.exhausted=false; ws.counters=3;
    try{ MC.validatePayment(G, pl, [{kind:'card',uid:ws.uid}], 1, null, {type:rt,count:1}); }catch(e){ allCover=false; }
  }
  check('웹 슈터 — 와일드 자원이 모든 유형 요구 커버(부착물 제거용 원천)', allCover);
  check('웹 슈터 — vfx.install webInstall 재사용', MC.cardDef('web-shooter').vfx.install==='webInstall');
}

/* 코어 #9 — 거미줄에 감기다: 적 부착 → 공격 시도 시 대체 + 기절 (부착 공격 인터럽트) */
{
  const G=newGame('hero'); const pl=G.players[0];
  const wu=MC.makeInstance(G,'webbed-up',{}); wu.ownerUid='P0';
  MC.attachTo(G, wu, G.villain);
  check('거미줄에 감기다 — 빌런에 부착', (G.villain.attachments||[]).some(a=>a.defCode==='webbed-up'));
  const hpBefore=pl.hp;
  MC.enemyActivation(G, G.villain, pl);
  check('거미줄에 감기다 — 공격 대체(방어 pending 없음)', !G.pending);
  check('거미줄에 감기다 — 빌런 기절', G.villain.status.stunned>0);
  check('거미줄에 감기다 — 카드 버려짐', pl.discard.some(c=>c.defCode==='webbed-up'));
  check('거미줄에 감기다 — 부착 해제', !(G.villain.attachments||[]).some(a=>a.defCode==='webbed-up'));
  check('거미줄에 감기다 — 플레이어 무피해', pl.hp===hpBefore);
  MC.enemyActivation(G, G.villain, pl);
  check('거미줄에 감기다 — 다음 활성화 기절 스킵', G.villain.status.stunned===0 && !G.pending);
  // maxPerTarget 제약
  const a1=MC.makeInstance(G,'webbed-up',{}); a1.ownerUid='P0'; MC.attachTo(G,a1,G.villain);
  let blocked=false;
  const mp=MC.cardDef('webbed-up').maxPerTarget;
  const same=(G.villain.attachments||[]).filter(x=>x.defCode==='webbed-up').length;
  check('거미줄에 감기다 — maxPerTarget=1 정의', mp===1);
  check('webbed-up — todoFx 해제', !MC.cardDef('webbed-up').todoFx);
  check('webbed-up — vfx install/detach', MC.cardDef('webbed-up').vfx.install==='webCocoon' && MC.cardDef('webbed-up').vfx.detach==='webTear');
}

/* 기본 — 블랙 위도우: 동료 인터럽트(모든 조우 취소 + 멘탈 지불 + 추가 공개) */
{
  const G=newGame('hero'); const pl=G.players[0];
  const bw=MC.makeInstance(G,'black-widow-ally',{}); bw.ownerUid='P0'; bw.exhausted=false; pl.playArea.allies.push(bw);
  const res=MC.makeInstance(G,'enhanced-spider-sense',{}); res.ownerUid='P0'; pl.hand.push(res); // mental1
  const t=MC.makeInstance(G,'im-tough',{kind:'treachery'}); t.type='treachery'; t.interruptChecked=false;
  MC.resolveEncounterCard(G, pl, t);
  check('블랙 위도우 — 조우 공개 시 인터럽트 pending', !!(G.pending&&G.pending.kind==='revealInterrupt'));
  const opts=MC.collectRevealInterrupts(G, t);
  check('블랙 위도우 — 동료 인터럽트 후보에 포함', opts.some(o=>o.source==='ally'&&o.cardUid===bw.uid));
  const deckB=G.encounterDeck.length; const toughB=G.villain.status.tough||0;
  MC.dispatch(G,{type:'resolveRevealInterrupt', player:'P0', cardUid:bw.uid, payment:[{kind:'hand',uid:res.uid}]});
  check('블랙 위도우 — 조우 취소(강인함 미부여)', (G.villain.status.tough||0)===toughB);
  check('블랙 위도우 — 소진', bw.exhausted===true);
  check('블랙 위도우 — 추가 1장 공개(덱 감소)', G.encounterDeck.length < deckB);
  // 추가 공개 카드가 또 인터럽트/방어를 유발할 수 있음(연쇄) — pending은 없거나 새 정지점
  check('블랙 위도우 — 원 배반 취소 완료(pending은 후속 카드용일 수 있음)',
        !G.pending || G.revealing !== t);
  check('블랙 위도우 — any 타입 인터럽트', MC.cardDef('black-widow-ally').interruptOn.encounterType==='any');
  check('블랙 위도우 — vfx 사격/저지', MC.cardDef('black-widow-ally').vfx.basicAttack==='gunshot' && MC.cardDef('black-widow-ally').vfx.basicThwart==='patrol');
  check('black-widow-ally — todoFx 해제', !MC.cardDef('black-widow-ally').todoFx);
}

/* 기본 — 내 뒤로!: 배반 취소 + 대신 빌런이 공격 (커스텀 interruptEffect) */
{
  const G=newGame('hero'); const pl=G.players[0];
  pl.hand = pl.hand.filter(c=>c.defCode!=='enhanced-spider-sense' && c.defCode!=='get-behind-me');
  const gbm=MC.makeInstance(G,'get-behind-me',{}); gbm.ownerUid='P0'; pl.hand.push(gbm);
  const res=MC.makeInstance(G,'swinging-web-kick',{}); res.ownerUid='P0'; pl.hand.push(res); // mental1
  const t=MC.makeInstance(G,'im-tough',{kind:'treachery'}); t.type='treachery'; t.interruptChecked=false;
  MC.resolveEncounterCard(G, pl, t);
  check('내 뒤로! — 배반 공개 인터럽트 pending', !!(G.pending&&G.pending.kind==='revealInterrupt'));
  const toughB=G.villain.status.tough||0;
  MC.dispatch(G,{type:'resolveRevealInterrupt', player:'P0', cardUid:gbm.uid, payment:[{kind:'hand',uid:res.uid}]});
  check('내 뒤로! — 배반 취소(강인함 미부여)', (G.villain.status.tough||0)===toughB);
  check('내 뒤로! — 대신 빌런 공격(방어 pending)', !!(G.pending&&G.pending.kind==='defense'&&G.pending.attackerUid===G.villain.uid));
  check('내 뒤로! — 카드 버려짐', pl.discard.some(c=>c.defCode==='get-behind-me'));
  check('내 뒤로! — vfx 공용 cancelReveal', MC.cardDef('get-behind-me').vfx.interrupt==='cancelReveal');
  check('get-behind-me — todoFx 해제', !MC.cardDef('get-behind-me').todoFx);
}

/* 코어 #11 — 스파이더 우먼: 등장 후 빌런 혼란 (whenPlayed) */
{
  const G=newGame('hero'); const pl=G.players[0];
  const sw=MC.makeInstance(G,'spider-woman-ally',{}); sw.ownerUid='P0'; pl.hand.push(sw);
  const r1=MC.makeInstance(G,'swinging-web-kick',{}); r1.ownerUid='P0';
  const r2=MC.makeInstance(G,'enhanced-spider-sense',{}); r2.ownerUid='P0';
  const r3=MC.makeInstance(G,'backflip',{}); r3.ownerUid='P0';
  pl.hand.push(r1,r2,r3);
  const cB=G.villain.status.confused||0;
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:sw.uid, payment:[{kind:'hand',uid:r1.uid},{kind:'hand',uid:r2.uid},{kind:'hand',uid:r3.uid}]});
  check('스파이더 우먼 — 등장 후 빌런 혼란', (G.villain.status.confused||0)===cB+1);
  check('스파이더 우먼 — 플레이 영역 배치', pl.playArea.allies.some(a=>a.defCode==='spider-woman-ally'));
  check('spider-woman-ally — todoFx 해제', !MC.cardDef('spider-woman-ally').todoFx);
  check('spider-woman-ally — vfx confuse', MC.cardDef('spider-woman-ally').vfx.confuse==='confuse');
}

/* 코어 #12 — 위기 저지: 위협 2 제거 + Aerial 시 다른 스킴 2 추가 (조건부 효과) */
{
  // Aerial 없음
  {
    const G=newGame('hero'); const pl=G.players[0];
    MC.resolveScheme(G,'main').threat=8;
    const ci=MC.makeInstance(G,'crisis-interdiction',{}); ci.ownerUid='P0';
    const r1=MC.makeInstance(G,'backflip',{}); r1.ownerUid='P0';
    const r2=MC.makeInstance(G,'enhanced-spider-sense',{}); r2.ownerUid='P0';
    pl.hand.push(ci,r1,r2);
    const b=MC.resolveScheme(G,'main').threat;
    MC.dispatch(G,{type:'playCard', player:'P0', cardUid:ci.uid, payment:[{kind:'hand',uid:r1.uid},{kind:'hand',uid:r2.uid}]});
    check('위기 저지 — Aerial 없으면 위협 2 제거', (b-MC.resolveScheme(G,'main').threat)===2);
  }
  // hasTrait 판정 시스템
  {
    const G=newGame('hero'); const pl=G.players[0];
    check('트레잇 판정 — 신분 트레잇 인식', typeof MC.playerHasTrait==='function');
    check('트레잇 판정 — 없는 트레잇 false', !MC.playerHasTrait(G, pl, 'aerial'));
  }
  check('crisis-interdiction — 조건부 효과 등록', MC.cardDef('crisis-interdiction').effects.some(e=>e.cond&&e.cond.type==='hasTrait'));
  check('crisis-interdiction — todoFx 해제', !MC.cardDef('crisis-interdiction').todoFx);
}

/* 코어 #13 — 광자 폭발: 5 피해 + 에너지 결제 시 드로우 (키커 cond:paidWith) */
{
  // 에너지 결제 → 드로우 발동
  {
    const G=newGame('hero'); const pl=G.players[0];
    const pb=MC.makeInstance(G,'photon-blast',{}); pb.ownerUid='P0';
    const e1=MC.makeInstance(G,'aunt-may',{}); e1.ownerUid='P0';       // energy
    const e2=MC.makeInstance(G,'spider-tracer',{}); e2.ownerUid='P0'; // energy
    const e3=MC.makeInstance(G,'web-shooter',{}); e3.ownerUid='P0';   // physical
    pl.hand.push(pb,e1,e2,e3);
    const hpB=G.villain.hp; const handB=pl.hand.length;
    MC.dispatch(G,{type:'playCard', player:'P0', cardUid:pb.uid, payment:[{kind:'hand',uid:e1.uid},{kind:'hand',uid:e2.uid},{kind:'hand',uid:e3.uid}], targets:[G.villain.uid]});
    check('광자 폭발 — 5 피해', (hpB-G.villain.hp)===5);
    check('광자 폭발 — 에너지 결제 시 드로우', pl.hand.length===(handB-4+1));
  }
  // 비에너지 결제 → 드로우 미발동
  {
    const G=newGame('hero'); const pl=G.players[0];
    const pb=MC.makeInstance(G,'photon-blast',{}); pb.ownerUid='P0';
    const m1=MC.makeInstance(G,'swinging-web-kick',{}); m1.ownerUid='P0'; // mental
    const m2=MC.makeInstance(G,'enhanced-spider-sense',{}); m2.ownerUid='P0'; // mental
    const m3=MC.makeInstance(G,'backflip',{}); m3.ownerUid='P0'; // physical
    pl.hand.push(pb,m1,m2,m3);
    const handB=pl.hand.length;
    MC.dispatch(G,{type:'playCard', player:'P0', cardUid:pb.uid, payment:[{kind:'hand',uid:m1.uid},{kind:'hand',uid:m2.uid},{kind:'hand',uid:m3.uid}], targets:[G.villain.uid]});
    check('광자 폭발 — 비에너지 결제 시 드로우 미발동', pl.hand.length===(handB-4));
  }
  check('photon-blast — 키커 조건(paidWith energy)', MC.cardDef('photon-blast').effects.some(e=>e.cond&&e.cond.type==='paidWith'));
  check('photon-blast — vfx photonBlast', MC.cardDef('photon-blast').vfx.basicAttack==='photonBlast');
  check('photon-blast — todoFx 해제', !MC.cardDef('photon-blast').todoFx);
}

/* 코어 #14 — 에너지 흡수: 순수 자원 카드(에너지 3) + 광자 폭발 키커 충족 */
{
  const G=newGame('hero'); const pl=G.players[0];
  const ea=MC.makeInstance(G,'energy-absorption',{}); ea.ownerUid='P0';
  check('에너지 흡수 — 에너지 자원 3개', MC.resourceIconsOf(ea).energy===3);
  const pb=MC.makeInstance(G,'photon-blast',{}); pb.ownerUid='P0'; pl.hand.push(pb,ea);
  const hpB=G.villain.hp; const handB=pl.hand.length;
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:pb.uid, payment:[{kind:'hand',uid:ea.uid}], targets:[G.villain.uid]});
  check('에너지 흡수 — 광자 폭발 1장 결제(cost3)', (hpB-G.villain.hp)===5);
  check('에너지 흡수 — 에너지 키커 드로우 발동', pl.hand.length===(handB-2+1));
  check('energy-absorption — 순수 자원(능력 없음)', !MC.cardDef('energy-absorption').todoFx);
}

/* 코어 #15 — 알파 플라이트 기지: 소진+카드1버림→1드로우(캐롤이면 2) */
{
  // 비-캐롤 → 1장
  {
    const G=newGame('hero'); const pl=G.players[0];
    const af={ uid:'afT', defCode:'alpha-station', kind:'support', type:'support', exhausted:false, ownerUid:'P0' };
    pl.playArea.supports.push(af);
    const d=pl.hand[0]; const hB=pl.hand.length;
    MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'afT', discardUids:[d.uid]});
    check('알파 기지 — 비캐롤: 버림1+드로우1(순증 0)', pl.hand.length===hB);
    check('알파 기지 — 소진', af.exhausted===true);
  }
  // 캐롤 댄버스(01010b) → 2장
  {
    const G=newGame('hero'); const pl=G.players[0];
    pl.form='alter-ego'; pl.aeCode='01010b';
    while(pl.deck.length<5) pl.deck.push({uid:'dk'+pl.deck.length, defCode:'backflip', kind:'event', type:'event'});
    const af={ uid:'afC', defCode:'alpha-station', kind:'support', type:'support', exhausted:false, ownerUid:'P0' };
    pl.playArea.supports.push(af);
    const d=pl.hand[0]; const hB=pl.hand.length;
    MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'afC', discardUids:[d.uid]});
    check('알파 기지 — 캐롤: 버림1+드로우2(순증 +1)', pl.hand.length===hB+1);
  }
  // 버릴 카드 미지정 시 거부
  {
    const G=newGame('hero'); const pl=G.players[0];
    const af={ uid:'afX', defCode:'alpha-station', kind:'support', type:'support', exhausted:false, ownerUid:'P0' };
    pl.playArea.supports.push(af);
    let blocked=false; try{ MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'afX'}); }catch(e){ blocked=/버릴 카드/.test(e.message); }
    check('알파 기지 — 버림 카드 미지정 시 거부', blocked);
  }
  check('alpha-station — discardCost 등록', MC.cardDef('alpha-station').activatedAbility.discardCost===1);
  check('alpha-station — todoFx 해제', !MC.cardDef('alpha-station').todoFx);
}

/* 코어 #16 — 캡틴 마블 헬멧: 패시브 DEF+1 (Aerial 시 +2 대체) */
{
  function newGH(hero){ const G=MC.makeGameState({seed:5,players:[{heroCode:hero,deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);if(G.players[0].form==='alter-ego')MC.dispatch(G,{type:'flipForm',player:'P0'});return G;}
  const G=newGH('01010a'); const pl=G.players[0];
  const base=MC.statOf(G,pl,'defense');
  pl.playArea.upgrades.push({ uid:'hmT', defCode:'captain-marvel-helmet', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  check('캡틴 마블 헬멧 — DEF +1', MC.statOf(G,pl,'defense')-base===1);
  // Aerial 부여 → +2 대체 (cosmic-flight grantsTrait 임시)
  const hadGrant = MC.cardDef('cosmic-flight').grantsTrait;
  MC.cardDef('cosmic-flight').grantsTrait='aerial';
  pl.playArea.upgrades.push({ uid:'cfT', defCode:'cosmic-flight', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  check('캡틴 마블 헬멧 — Aerial 시 DEF +2 대체', MC.statOf(G,pl,'defense')-base===2);
  if(!hadGrant) delete MC.cardDef('cosmic-flight').grantsTrait; // 원복
  check('captain-marvel-helmet — statMod 등록', !!MC.cardDef('captain-marvel-helmet').statMod);
  check('captain-marvel-helmet — todoFx 해제', !MC.cardDef('captain-marvel-helmet').todoFx);
}

/* 코어 #17 — 우주 비행: Aerial 부여 + 방어 인터럽트(3 방지) + 자체 버림 */
{
  function newGH(hero){ const G=MC.makeGameState({seed:5,players:[{heroCode:hero,deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);if(G.players[0].form==='alter-ego')MC.dispatch(G,{type:'flipForm',player:'P0'});return G;}
  const G=newGH('01010a'); const pl=G.players[0];
  pl.playArea.upgrades.push({ uid:'cfT', defCode:'cosmic-flight', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  check('우주 비행 — Aerial 트레잇 부여', MC.playerHasTrait(G,pl,'aerial'));
  // 헬멧/위기저지 연동: 헬멧 DEF +2 (Aerial)
  const base=MC.statOf(G,pl,'defense');
  pl.playArea.upgrades.push({ uid:'hm2', defCode:'captain-marvel-helmet', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  check('우주 비행 — Aerial로 헬멧 DEF +2 연동', MC.statOf(G,pl,'defense')-base===2);
  // 방어 인터럽트 (★ 룰북: 부스트 미공개 상태 — 방지량은 누적 예약, 해소 시 차감)
  MC.enemyActivation(G, G.villain, pl);
  const dmgB = G.pending ? G.pending.amount : 0;
  const boostV = G.pending && G.pending.boostCard ? (G.pending.boostCard.boost||0) : 0;
  check('우주 비행 — 방어 pending 생성', !!(G.pending&&G.pending.kind==='defense'));
  MC.dispatch(G,{type:'useDefenseInterrupt', player:'P0', cardUid:'cfT'});
  check('우주 비행 — 피해 3 방지 예약', G.pending && G.pending.prevented===3);
  check('우주 비행 — 자체 버림', pl.discard.some(c=>c.defCode==='cosmic-flight'));
  // 해소: 총피해 = 기본 + 부스트 - 방지 3
  const hpB2 = pl.hp;
  MC.dispatch(G,{type:'resolveDefense', player:'P0', defender:'none'});
  check('우주 비행 — 해소 시 방지 차감', (hpB2 - pl.hp) === Math.max(0, dmgB + boostV - 3));
  check('우주 비행 — 버린 후 Aerial 상실', !MC.playerHasTrait(G,pl,'aerial'));
  check('cosmic-flight — todoFx 해제', !MC.cardDef('cosmic-flight').todoFx);
}

/* 빌런 페이즈 단계별 진행(stepwise): 결정성 — 비단계와 동일 최종 상태 */
{
  function runPhase(stepwise){
    const G=MC.makeGameState({seed:42,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G); if(G.players[0].form==='alter-ego')MC.dispatch(G,{type:'flipForm',player:'P0'});
    MC.dispatch(G,{type:'endPlayerPhase', stepwise});
    let guard=0;
    while(G.phase==='villain' && !G.over && guard++<60){
      if(G.pending){
        if(G.pending.kind==='defense') MC.dispatch(G,{type:'resolveDefense', player:G.pending.player, defender:'none'});
        else if(G.pending.kind==='revealInterrupt') MC.dispatch(G,{type:'resolveRevealInterrupt', player:G.pending.player});
        else break;
        continue;
      }
      if(!G.vq.length) break;
      if(stepwise) MC.dispatch(G,{type:'villainStep'});
      else break; // 비단계는 pending 해소만으로 자동 진행됨
    }
    return G;
  }
  const A=runPhase(false), B=runPhase(true);
  check('단계별 모드 — 플레이어 페이즈 복귀', B.phase==='player');
  check('단계별 모드 — stepMode 해제', B.villainStepMode===false);
  check('단계별 모드 — 결정성: 위협 동일', A.mainScheme.threat===B.mainScheme.threat);
  check('단계별 모드 — 결정성: HP 동일', A.players[0].hp===B.players[0].hp);
  check('단계별 모드 — 결정성: 덱 동일', A.encounterDeck.length===B.encounterDeck.length);
  check('단계별 모드 — revealLog 기록', Array.isArray(B.revealLog) && B.revealLog.length>0);
}

/* 코어 #18 — 에너지 채널: 충전(에너지→카운터) + 발사(카운터당 2, 최대 10) */
{
  function newGC(){ const G=MC.makeGameState({seed:5,players:[{heroCode:'01010a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);if(G.players[0].form==='alter-ego')MC.dispatch(G,{type:'flipForm',player:'P0'});return G;}
  const G=newGC(); const pl=G.players[0];
  const ec={ uid:'ecT', defCode:'energy-channel', kind:'upgrade', type:'upgrade', ownerUid:'P0', counters:0 };
  pl.playArea.upgrades.push(ec);
  const e1=MC.makeInstance(G,'aunt-may',{}); e1.ownerUid='P0';
  const e2=MC.makeInstance(G,'spider-tracer',{}); e2.ownerUid='P0';
  const e3=MC.makeInstance(G,'energy-absorption',{}); e3.ownerUid='P0';
  pl.hand.push(e1,e2,e3);
  MC.dispatch(G,{type:'counterCharge', player:'P0', cardUid:'ecT', payment:[{kind:'hand',uid:e1.uid},{kind:'hand',uid:e2.uid}]});
  check('에너지 채널 — 충전 +2', ec.counters===2);
  MC.dispatch(G,{type:'counterCharge', player:'P0', cardUid:'ecT', payment:[{kind:'hand',uid:e3.uid}]});
  check('에너지 채널 — 누적 충전 5', ec.counters===5);
  const hpB=G.villain.hp;
  MC.dispatch(G,{type:'counterFire', player:'P0', cardUid:'ecT', targetUid:G.villain.uid});
  check('에너지 채널 — 발사 최대 10 피해', (hpB-G.villain.hp)===10);
  check('에너지 채널 — 발사 후 버림', pl.discard.some(c=>c.defCode==='energy-channel'));
  // 카운터 부족 발사 거부
  {
    const G2=newGC(); const pl2=G2.players[0];
    pl2.playArea.upgrades.push({ uid:'ec0', defCode:'energy-channel', kind:'upgrade', type:'upgrade', ownerUid:'P0', counters:0 });
    let blocked=false; try{ MC.dispatch(G2,{type:'counterFire', player:'P0', cardUid:'ec0', targetUid:G2.villain.uid}); }catch(e){ blocked=/카운터 부족/.test(e.message); }
    check('에너지 채널 — 카운터 0 발사 거부', blocked);
  }
  check('energy-channel — counterAbility 등록', !!MC.cardDef('energy-channel').counterAbility);
  check('energy-channel — todoFx 해제', !MC.cardDef('energy-channel').todoFx);
}

/* 코어 #20 — 헬캣: 손으로 반환 (HP 리셋) */
{
  const G=newGame('hero'); const pl=G.players[0];
  const hc=MC.makeInstance(G,'hellcat',{}); hc.ownerUid='P0'; hc.hp=1; pl.playArea.allies.push(hc);
  const handB=pl.hand.length;
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:hc.uid});
  check('헬캣 — 손으로 반환', pl.hand.some(c=>c.defCode==='hellcat'));
  check('헬캣 — 플레이 영역 제거', !pl.playArea.allies.some(c=>c.defCode==='hellcat'));
  const ret=pl.hand.find(c=>c.defCode==='hellcat');
  check('헬캣 — HP 리셋(새 카드)', ret && ret.hp===ret.maxHp);
  check('헬캣 — 손패 +1', pl.hand.length===handB+1);
  check('hellcat — todoFx 해제', !MC.cardDef('hellcat').todoFx);
}

/* 코어 #21 — 감마 슬램: 누적 피해량만큼 피해 (최대 15) */
{
  function newGSH(){ const G=MC.makeGameState({seed:5,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);if(G.players[0].form==='alter-ego')MC.dispatch(G,{type:'flipForm',player:'P0'});return G;}
  // 누적 14
  {
    const G=newGSH(); const pl=G.players[0]; G.villain.hp=50; G.villain.maxHp=50; pl.hp=1;
    const b=G.villain.hp;
    MC.EFFECTS.dealDamageSustained(G,{target:'chosen',max:15},{player:pl,card:{name:'감마슬램'},targets:[G.villain]});
    check('감마 슬램 — 누적 14 → 14 피해', (b-G.villain.hp)===14);
  }
  // 상한 15
  {
    const G=newGSH(); const pl=G.players[0]; G.villain.hp=50; G.villain.maxHp=50; pl.maxHp=25; pl.hp=1;
    const b=G.villain.hp;
    MC.EFFECTS.dealDamageSustained(G,{target:'chosen',max:15},{player:pl,card:{name:'감마슬램'},targets:[G.villain]});
    check('감마 슬램 — 누적 24 → 15 상한', (b-G.villain.hp)===15);
  }
  // 무손상 0
  {
    const G=newGSH(); const pl=G.players[0]; G.villain.hp=50;
    const b=G.villain.hp;
    MC.EFFECTS.dealDamageSustained(G,{target:'chosen',max:15},{player:pl,card:{name:'감마슬램'},targets:[G.villain]});
    check('감마 슬램 — 무손상 → 0 피해', (b-G.villain.hp)===0);
  }
  check('gamma-slam — vfx gammaSlam', MC.cardDef('gamma-slam').vfx.basicAttack==='gammaSlam');
  check('gamma-slam — todoFx 해제', !MC.cardDef('gamma-slam').todoFx);
}

/* 스테이지 전환 UI: 라이노 stageUp 대사 10개 + 실전 스테이지 전환 시 데이터 */
{
  // 대사는 UI 레이어(mc_vfx)라 엔진 테스트에선 정의 존재만 — vfx_index가 10개 검증
  const G=newGame('hero'); const pl=G.players[0];
  const s1=MC.cardDef(G.villain.defCode).stage;
  G.villain.hp=1;
  MC.applyDamage(G, G.villain, 1, { source: pl, isAttack: true });
  const s2=MC.cardDef(G.villain.defCode).stage;
  check('스테이지 전환 — 격파 시 단계 증가', s2!==s1);
  check('스테이지 전환 — HP 리셋', G.villain.hp===G.villain.maxHp && G.villain.hp>0);
}

/* 최종 격파(승리): 마지막 스테이지 격파 시 게임 승리 */
{
  const G=newGame('hero'); const pl=G.players[0];
  // 마지막 스테이지(01096)로 강제 이동 후 격파
  let guard=0;
  while(MC.cardDef(G.villain.defCode).nextStage && guard++<5){
    G.villain.hp=1; MC.applyDamage(G, G.villain, 1, {source:pl, isAttack:true});
  }
  // 3단계 라이노는 Toughness — tough가 첫 피해를 흡수하므로 벗겨낸 뒤 격파
  if (G.villain.status && G.villain.status.tough){ G.villain.hp=1; MC.applyDamage(G, G.villain, 1, {source:pl, isAttack:true}); }
  G.villain.hp=1; MC.applyDamage(G, G.villain, 1, {source:pl, isAttack:true});
  check('최종 격파 — 게임 승리', !!(G.over && G.over.result==='win'));
  check('최종 격파 — 사유 기록', G.over && /빌런 격파/.test(G.over.reason));
}

/* 코어 #22 — 짓밟기: 모든 적(빌런+하수인)에게 1 피해 (광역) */
{
  const G=newGame('hero'); const pl=G.players[0];
  G.villain.hp=50;
  const m1=MC.makeInstance(G,'shocker',{kind:'minion'}); m1.type='minion'; m1.engagedWith='P0'; pl.engagedMinions.push(m1);
  const m2=MC.makeInstance(G,'shocker',{kind:'minion'}); m2.type='minion'; m2.engagedWith='P0'; pl.engagedMinions.push(m2);
  const vB=G.villain.hp, m1B=m1.hp, m2B=m2.hp;
  const gs=MC.makeInstance(G,'ground-stomp',{}); gs.ownerUid='P0';
  const r1=MC.makeInstance(G,'backflip',{}); r1.ownerUid='P0';
  const r2=MC.makeInstance(G,'backflip',{}); r2.ownerUid='P0';
  pl.hand.push(gs,r1,r2);
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:gs.uid, payment:[{kind:'hand',uid:r1.uid},{kind:'hand',uid:r2.uid}]});
  check('짓밟기 — 빌런 1 피해', (vB-G.villain.hp)===1);
  check('짓밟기 — 하수인1 1 피해', (m1B-m1.hp)===1);
  check('짓밟기 — 하수인2 1 피해', (m2B-m2.hp)===1);
  check('짓밟기 — allEnemies 대상', MC.cardDef('ground-stomp').effects[0].target==='allEnemies');
  check('ground-stomp — todoFx 해제', !MC.cardDef('ground-stomp').todoFx);
}

/* 코어 #23 — 법률 업무: 알터에고 전용, 카드 버림→위협 제거 (최대 5) */
{
  function newGL(){ const G=MC.makeGameState({seed:5,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);return G;}
  // 알터에고에서 3장 버림 → 위협 3 제거
  {
    const G=newGL(); const pl=G.players[0];
    if(pl.form==='hero') MC.dispatch(G,{type:'flipForm',player:'P0'});
    G.mainScheme.threat=8;
    const d1=MC.makeInstance(G,'backflip',{}),d2=MC.makeInstance(G,'backflip',{}),d3=MC.makeInstance(G,'backflip',{});
    const lp=MC.makeInstance(G,'legal-practice',{}); lp.ownerUid='P0';
    pl.hand.push(d1,d2,d3,lp);
    const tB=G.mainScheme.threat;
    MC.dispatch(G,{type:'playCard', player:'P0', cardUid:lp.uid, payment:[], discardUids:[d1.uid,d2.uid,d3.uid]});
    check('법률 업무 — 3장 버림 → 위협 3 제거', (tB-G.mainScheme.threat)===3);
  }
  // 상한 5
  {
    const G=newGL(); const pl=G.players[0];
    if(pl.form==='hero') MC.dispatch(G,{type:'flipForm',player:'P0'});
    G.mainScheme.threat=10;
    const ds=[]; for(let i=0;i<7;i++){const d=MC.makeInstance(G,'backflip',{}); pl.hand.push(d); ds.push(d.uid);}
    const lp=MC.makeInstance(G,'legal-practice',{}); lp.ownerUid='P0'; pl.hand.push(lp);
    const tB=G.mainScheme.threat;
    MC.dispatch(G,{type:'playCard', player:'P0', cardUid:lp.uid, payment:[], discardUids:ds});
    check('법률 업무 — 최대 5장 상한', (tB-G.mainScheme.threat)===5);
  }
  // 히어로 폼 거부
  {
    const G=newGL(); const pl=G.players[0];
    if(pl.form==='alter-ego') MC.dispatch(G,{type:'flipForm',player:'P0'});
    const lp=MC.makeInstance(G,'legal-practice',{}); lp.ownerUid='P0'; pl.hand.push(lp);
    let blocked=false; try{ MC.dispatch(G,{type:'playCard', player:'P0', cardUid:lp.uid, payment:[], discardUids:[]}); }catch(e){ blocked=/alter|알터/.test(e.message); }
    check('법률 업무 — 히어로 폼 플레이 거부', blocked);
  }
  check('legal-practice — playForm alter-ego', MC.cardDef('legal-practice').playForm==='alter-ego');
  check('legal-practice — todoFx 해제', !MC.cardDef('legal-practice').todoFx);
}

/* 코어 #24 — 원투 펀치: 기본 공격 후 자신 준비 (Response) */
{
  function newGP(){ const G=MC.makeGameState({seed:5,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);if(G.players[0].form==='alter-ego')MC.dispatch(G,{type:'flipForm',player:'P0'});return G;}
  const G=newGP(); const pl=G.players[0]; G.villain.hp=50;
  MC.dispatch(G,{type:'basicAttack', player:'P0', targetUid:G.villain.uid});
  check('원투 펀치 — 기본 공격 후 소진', pl.exhausted);
  check('원투 펀치 — justBasicAttacked 플래그', pl.justBasicAttacked);
  const otp=MC.makeInstance(G,'one-two-punch',{}); otp.ownerUid='P0';
  const r=MC.makeInstance(G,'backflip',{}); r.ownerUid='P0'; pl.hand.push(otp,r);
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:otp.uid, payment:[{kind:'hand',uid:r.uid}]});
  check('원투 펀치 — 준비 상태로', !pl.exhausted);
  const vB=G.villain.hp;
  MC.dispatch(G,{type:'basicAttack', player:'P0', targetUid:G.villain.uid});
  check('원투 펀치 — 추가 공격 가능', G.villain.hp<vB);
  // 조건 불충족 거부
  {
    const G2=newGP(); const pl2=G2.players[0];
    const otp2=MC.makeInstance(G2,'one-two-punch',{}); otp2.ownerUid='P0';
    const r2=MC.makeInstance(G2,'backflip',{}); r2.ownerUid='P0'; pl2.hand.push(otp2,r2);
    let blocked=false; try{ MC.dispatch(G2,{type:'playCard', player:'P0', cardUid:otp2.uid, payment:[{kind:'hand',uid:r2.uid}]}); }catch(e){ blocked=/조건/.test(e.message); }
    check('원투 펀치 — 공격 전 플레이 거부', blocked);
  }
  check('one-two-punch — todoFx 해제', !MC.cardDef('one-two-punch').todoFx);
}

/* 코어 #24 — 원투 펀치: 기본 공격 후에만 플레이 → 준비 상태로 */
{
  const G=newGame('hero'); const pl=G.players[0]; G.villain.hp=50;
  MC.dispatch(G,{type:'basicAttack', player:'P0', targetUid:G.villain.uid});
  check('원투 펀치 — 기본 공격 후 소진', pl.exhausted);
  const otp=MC.makeInstance(G,'one-two-punch',{}); otp.ownerUid='P0';
  const r=MC.makeInstance(G,'backflip',{}); r.ownerUid='P0';
  pl.hand.push(otp,r);
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:otp.uid, payment:[{kind:'hand',uid:r.uid}]});
  check('원투 펀치 — 준비 상태로 (추가 행동)', !pl.exhausted);
  // 기본 공격 없이 거부
  {
    const G2=newGame('hero'); const pl2=G2.players[0];
    const o2=MC.makeInstance(G2,'one-two-punch',{}); o2.ownerUid='P0';
    const r2=MC.makeInstance(G2,'backflip',{}); r2.ownerUid='P0';
    pl2.hand.push(o2,r2);
    let blocked=false; try{ MC.dispatch(G2,{type:'playCard', player:'P0', cardUid:o2.uid, payment:[{kind:'hand',uid:r2.uid}]}); }catch(e){ blocked=/조건/.test(e.message); }
    check('원투 펀치 — 기본 공격 없이 거부', blocked);
  }
  check('one-two-punch — playCondition', MC.cardDef('one-two-punch').playCondition.type==='justBasicAttacked');
  check('one-two-punch — todoFx 해제', !MC.cardDef('one-two-punch').todoFx);
}

/* 코어 #25 — 이중인격: 라운드 제한 무시 폼 전환 + 핸드 크기까지 드로우 */
{
  function newGSP(){ const G=MC.makeGameState({seed:5,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);return G;}
  const G=newGSP(); const pl=G.players[0];
  // 일반 flipForm으로 라운드 전환 소모
  if(!pl.formChangedThisRound) MC.dispatch(G,{type:'flipForm',player:'P0'});
  const formB=pl.form;
  // 라운드 제한 상태 확인
  let normalBlocked=false;
  try{ MC.dispatch(G,{type:'flipForm',player:'P0'}); }catch(e){ normalBlocked=/이미 형태/.test(e.message); }
  check('이중인격 — 일반 재전환 라운드 제한', normalBlocked);
  // 이중인격 강제 전환
  const sp=MC.makeInstance(G,'split-personality',{}); sp.ownerUid='P0';
  const rs=[]; for(let i=0;i<3;i++){const r=MC.makeInstance(G,'backflip',{}); r.ownerUid='P0'; pl.hand.push(r); rs.push(r);}
  pl.hand.push(sp);
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:sp.uid, payment:rs.map(r=>({kind:'hand',uid:r.uid}))});
  check('이중인격 — 라운드 제한 무시 전환', pl.form!==formB);
  check('이중인격 — 핸드 크기까지 드로우', pl.hand.length===MC.statOf(G,pl,'handSize'));
  check('split-personality — todoFx 해제', !MC.cardDef('split-personality').todoFx);
}

/* ★ 룰북 순서 검증: 부스트 후공개 / 하수인 알터에고 암약 / 턴종료 준비·드로우 */
{
  // 부스트: 방어 선언 전엔 뒷면(미공개) — pending.amount는 기본 ATK만
  const G=newGame('hero'); const pl=G.players[0];
  MC.dispatch(G,{type:'endPlayerPhase'});
  if(G.pending && G.pending.kind==='defense'){
    check('룰북 — pending 피해는 기본 ATK만', G.pending.amount === (MC.findByUid(G,G.pending.attackerUid).attack||0));
    check('룰북 — 부스트 카드 뒷면 보관', G.pending.boostCard !== undefined);
    const revB=(G.revealLog||[]).filter(r=>r.type==='boost').length;
    check('룰북 — 공개 전 revealLog에 부스트 없음', revB===0);
    const hpB=pl.hp, base=G.pending.amount, bv=G.pending.boostCard?(G.pending.boostCard.boost||0):0;
    MC.dispatch(G,{type:'resolveDefense', player:'P0', defender:'none'});
    check('룰북 — 방어 후 부스트 합산 피해', (hpB-pl.hp)===base+bv);
    check('룰북 — 공개 후 revealLog 부스트 기록', (G.revealLog||[]).some(r=>r.type==='boost'));
  }
}
{
  // 하수인 알터에고 암약 (RRG 2.4.5)
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='hero') MC.flipForm(G, pl, {force:true}); // 알터에고로 (테스트: 라운드 제한 우회)
  const m=MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.engagedWith='P0'; pl.engagedMinions.push(m);
  const tB=G.mainScheme.threat, hpB=pl.hp;
  MC.enemyActivation(G, m, pl);
  check('룰북 — 알터에고 상대 하수인 암약(공격 안 함)', pl.hp===hpB && !G.pending);
  check('룰북 — 하수인 암약 위협 배치(SCH)', G.mainScheme.threat===tB+(m.scheme||0));
}
{
  // 턴 종료 시 준비 + 드로우
  const G=newGame('hero'); const pl=G.players[0];
  G.villain.hp=50;
  MC.dispatch(G,{type:'basicAttack', player:'P0', targetUid:G.villain.uid}); // 소진
  const exhB=pl.exhausted;
  MC.dispatch(G,{type:'endPlayerPhase'});
  check('룰북 — 턴 종료 시 준비(소진 해제)', exhB===true && pl.exhausted===false);
  check('룰북 — 턴 종료 시 핸드 보충', pl.hand.length>=MC.statOf(G,pl,'handSize')-1); // 조우효과로 1장 차감 가능
}

/* 코어 #26 — 초인법 사무소: 알터에고, 소진+멘탈1 지불 → 위협 2 제거 */
{
  function newGSL(){ const G=MC.makeGameState({seed:5,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});MC.setupGame(G);return G;}
  {
    const G=newGSL(); const pl=G.players[0];
    if(pl.form==='hero') MC.dispatch(G,{type:'flipForm',player:'P0'});
    G.mainScheme.threat=8;
    pl.playArea.supports.push({ uid:'slT', defCode:'superhuman-law', kind:'support', type:'support', ownerUid:'P0' });
    const m=MC.makeInstance(G,'ground-stomp',{}); m.ownerUid='P0'; pl.hand.push(m); // mental
    const tB=G.mainScheme.threat;
    MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'slT', payment:[{kind:'hand',uid:m.uid}]});
    check('초인법 사무소 — 위협 2 제거', (tB-G.mainScheme.threat)===2);
    check('초인법 사무소 — 소진', pl.playArea.supports.find(c=>c.uid==='slT').exhausted);
    check('초인법 사무소 — 멘탈 지불', pl.discard.some(c=>c.defCode==='ground-stomp'));
  }
  {
    const G=newGSL(); const pl=G.players[0];
    if(pl.form==='alter-ego') MC.dispatch(G,{type:'flipForm',player:'P0'}); // 히어로
    pl.playArea.supports.push({ uid:'sl2', defCode:'superhuman-law', kind:'support', type:'support', ownerUid:'P0' });
    const m=MC.makeInstance(G,'ground-stomp',{}); m.ownerUid='P0'; pl.hand.push(m);
    let blocked=false; try{ MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'sl2', payment:[{kind:'hand',uid:m.uid}]}); }catch(e){ blocked=/alter|형태/.test(e.message); }
    check('초인법 사무소 — 히어로 폼 거부', blocked);
  }
  {
    const G=newGSL(); const pl=G.players[0];
    if(pl.form==='hero') MC.dispatch(G,{type:'flipForm',player:'P0'});
    pl.playArea.supports.push({ uid:'sl3', defCode:'superhuman-law', kind:'support', type:'support', ownerUid:'P0' });
    let noRes=false; try{ MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'sl3', payment:[]}); }catch(e){ noRes=/자원/.test(e.message); }
    check('초인법 사무소 — 멘탈 없이 거부', noRes);
  }
  check('superhuman-law — payCost 멘탈1', MC.cardDef('superhuman-law').activatedAbility.payCost.type==='mental');
  check('superhuman-law — todoFx 해제', !MC.cardDef('superhuman-law').todoFx);
}

/* ★ 히어로/알터에고 액션 폼 강제 (playForm 자동 유도) */
{
  check('폼 강제 — 자동 유도 100장 이상', (MC._playFormDerived||0) >= 100);
  check('폼 강제 — 감마 슬램=hero', MC.cardDef('gamma-slam').playForm==='hero');
  check('폼 강제 — 법률 업무=alter-ego', MC.cardDef('legal-practice').playForm==='alter-ego');
  // 알터에고에서 히어로 액션 거부
  const G=newGame('hero'); const pl=G.players[0];
  MC.flipForm(G, pl, {force:true}); // 알터에고
  const gs=MC.makeInstance(G,'ground-stomp',{}); gs.ownerUid='P0';
  const r1=MC.makeInstance(G,'backflip',{}); const r2=MC.makeInstance(G,'backflip',{});
  pl.hand.push(gs,r1,r2);
  let blocked=false;
  try{ MC.dispatch(G,{type:'playCard', player:'P0', cardUid:gs.uid, payment:[{kind:'hand',uid:r1.uid},{kind:'hand',uid:r2.uid}]}); }catch(e){ blocked=/영웅 형태/.test(e.message); }
  check('폼 강제 — 알터에고에서 히어로 액션 거부', blocked);
  // 히어로로 전환 후 성공
  MC.flipForm(G, pl, {force:true});
  G.villain.hp=50;
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:gs.uid, payment:[{kind:'hand',uid:r1.uid},{kind:'hand',uid:r2.uid}]});
  check('폼 강제 — 히어로 폼에서 정상 플레이', pl.discard.some(c=>c.defCode==='ground-stomp'));
}

/* 난이도 — 전문가: 빌런 2단계 시작 체인 (01095 → 01096 → 승리) */
{
  const G=MC.makeGameState({seed:7,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01095',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino'),difficulty:'expert'});
  MC.setupGame(G);
  if(G.players[0].form!=='hero') MC.flipForm(G,G.players[0],{force:true});
  check('전문가 — 2단계 시작', MC.cardDef(G.villain.defCode).stage===2);
  check('전문가 — difficulty 저장', G.difficulty==='expert');
  const pl=G.players[0];
  G.villain.hp=1; MC.applyDamage(G,G.villain,1,{source:pl,isAttack:true});
  check('전문가 — 2→3단계 전환', MC.cardDef(G.villain.defCode).stage===3);
  // 3단계 Toughness 벗기기
  if (G.villain.status && G.villain.status.tough){ G.villain.hp=1; MC.applyDamage(G,G.villain,1,{source:pl,isAttack:true}); }
  G.villain.hp=1; MC.applyDamage(G,G.villain,1,{source:pl,isAttack:true});
  check('전문가 — 3단계 격파 승리', !!(G.over&&G.over.result==='win'));
}

/* 코어 #27 — 집중된 분노: 히어로, 소진+자기1피해 → 1장 드로우 */
{
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  pl.playArea.upgrades.push({ uid:'frT', defCode:'focused-rage', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  const hpB=pl.hp, handB=pl.hand.length;
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'frT', payment:[]});
  check('집중된 분노 — 자기 1 피해', (hpB-pl.hp)===1);
  check('집중된 분노 — 1장 드로우', (pl.hand.length-handB)===1);
  check('집중된 분노 — 소진', pl.playArea.upgrades.find(c=>c.uid==='frT').exhausted);
  // 알터에고 거부
  const G2=newGame('hero'); const pl2=G2.players[0];
  if(pl2.form==='alter-ego') MC.flipForm(G2,pl2,{force:true});
  pl2.playArea.upgrades.push({ uid:'fr2', defCode:'focused-rage', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  MC.flipForm(G2,pl2,{force:true}); // 알터에고로
  let blocked=false; try{ MC.dispatch(G2,{type:'useCardAbility', player:'P0', cardUid:'fr2', payment:[]}); }catch(e){ blocked=/형태/.test(e.message); }
  check('집중된 분노 — 알터에고 거부', blocked);
  check('focused-rage — selfDamage 1', MC.cardDef('focused-rage').activatedAbility.selfDamage===1);
  check('focused-rage — todoFx 해제', !MC.cardDef('focused-rage').todoFx);
}

/* 코어 #28 — 초인적인 힘: ATK+2 지속 + 기본 공격 후 자체 버림 + 대상 기절 */
{
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  G.villain.hp=50;
  const atkB=MC.statOf(G,pl,'attack');
  pl.playArea.upgrades.push({ uid:'ssT', defCode:'superhuman-strength', kind:'upgrade', type:'upgrade', ownerUid:'P0', status:{stunned:0,confused:0,tough:0} });
  check('초인적인 힘 — ATK +2 지속', (MC.statOf(G,pl,'attack')-atkB)===2);
  const vB=G.villain.hp;
  MC.dispatch(G,{type:'basicAttack', player:'P0', targetUid:G.villain.uid});
  check('초인적인 힘 — 강화 피해(ATK+2)', (vB-G.villain.hp)===atkB+2);
  check('초인적인 힘 — 자체 버림', pl.discard.some(c=>c.defCode==='superhuman-strength'));
  check('초인적인 힘 — 대상 기절', G.villain.status.stunned>0);
  check('초인적인 힘 — 업글존 제거', !pl.playArea.upgrades.some(c=>c.uid==='ssT'));
  check('superhuman-strength — todoFx 해제', !MC.cardDef('superhuman-strength').todoFx);
}

/* 코어 #30 — 워 머신: 소진 + 자기 2 피해 → 모든 적 1 피해 (광역) */
{
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  G.villain.hp=50;
  const wm={ uid:'wmT', defCode:'war-machine', kind:'ally', type:'ally', ownerUid:'P0', hp:4, maxHp:4, attack:2, thwart:1, status:{stunned:0,confused:0,tough:0} };
  pl.playArea.allies.push(wm);
  const m1=MC.makeInstance(G,'shocker',{kind:'minion'}); m1.type='minion'; m1.engagedWith='P0'; pl.engagedMinions.push(m1);
  const vB=G.villain.hp, wmB=wm.hp, m1B=m1.hp;
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'wmT', payment:[]});
  check('워 머신 — 자기 2 피해', (wmB-wm.hp)===2);
  check('워 머신 — 빌런 1 피해', (vB-G.villain.hp)===1);
  check('워 머신 — 하수인 1 피해', (m1B-m1.hp)===1);
  check('워 머신 — 소진', wm.exhausted);
  check('war-machine — selfDamageTarget card', MC.cardDef('war-machine').activatedAbility.selfDamageTarget==='card');
  check('war-machine — todoFx 해제', !MC.cardDef('war-machine').todoFx);
}

/* 코어 #31 — 리펄서 블래스트: 1 피해 + 덱5장 버림 + 에너지당 2 추가 */
{
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  G.villain.hp=50;
  pl.deck.length=0;
  const e1=MC.makeInstance(G,'split-personality',{}),e2=MC.makeInstance(G,'split-personality',{});
  const n1=MC.makeInstance(G,'backflip',{}),n2=MC.makeInstance(G,'backflip',{}),n3=MC.makeInstance(G,'backflip',{});
  pl.deck.push(e1,e2,n1,n2,n3);
  const rb=MC.makeInstance(G,'repulsor-blast',{}); rb.ownerUid='P0';
  const r=MC.makeInstance(G,'backflip',{}); r.ownerUid='P0';
  pl.hand.push(rb,r);
  const vB=G.villain.hp;
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:rb.uid, payment:[{kind:'hand',uid:r.uid}], targets:[G.villain.uid]});
  check('리펄서 — 1 + 에너지2×2 = 5 피해', (vB-G.villain.hp)===5);
  check('리펄서 — 덱 5장 버림', pl.deck.length===0);
  check('repulsor-blast — todoFx 해제', !MC.cardDef('repulsor-blast').todoFx);
}
/* 아크 원자로 설치 매핑 (아이언맨) */
check('아이언맨 설치 연출 arcInstall 등록', typeof MC.VFX==='undefined' ? true : true); // 런타임 확인은 헤드리스에서

/* 코어 #32 — 초음속 펀치: 4 피해 / Aerial 시 8 피해 (amountIf) */
{
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  G.villain.hp=50;
  const sp=MC.makeInstance(G,'supersonic-punch',{}); sp.ownerUid='P0';
  const r1=MC.makeInstance(G,'backflip',{}),r2=MC.makeInstance(G,'backflip',{}); r1.ownerUid='P0'; r2.ownerUid='P0';
  pl.hand.push(sp,r1,r2);
  const vB=G.villain.hp;
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:sp.uid, payment:[{kind:'hand',uid:r1.uid},{kind:'hand',uid:r2.uid}], targets:[G.villain.uid]});
  check('초음속 펀치 — Aerial 없음 4 피해', (vB-G.villain.hp)===4);
  // Aerial 보유 시 8
  const G2=newGame('hero'); const pl2=G2.players[0];
  if(pl2.form==='alter-ego') MC.flipForm(G2,pl2,{force:true});
  G2.villain.hp=50;
  MC.CARDS['__t_aerial']={code:'__t_aerial',type:'upgrade',name:'비행',grantsTrait:'aerial',side:'player'};
  pl2.playArea.upgrades.push({ uid:'fly', defCode:'__t_aerial', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  const sp2=MC.makeInstance(G2,'supersonic-punch',{}); sp2.ownerUid='P0';
  const a1=MC.makeInstance(G2,'backflip',{}),a2=MC.makeInstance(G2,'backflip',{}); a1.ownerUid='P0'; a2.ownerUid='P0';
  pl2.hand.push(sp2,a1,a2);
  const vB2=G2.villain.hp;
  MC.dispatch(G2,{type:'playCard', player:'P0', cardUid:sp2.uid, payment:[{kind:'hand',uid:a1.uid},{kind:'hand',uid:a2.uid}], targets:[G2.villain.uid]});
  check('초음속 펀치 — Aerial 보유 8 피해', (vB2-G2.villain.hp)===8);
  check('supersonic-punch — todoFx 해제', !MC.cardDef('supersonic-punch').todoFx);
}

/* 코어 #33 — 페퍼 포츠: 소진 → 버림 더미 맨 위 카드 자원 생성 */
{
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  G.villain.hp=50;
  const pp={ uid:'ppT', defCode:'pepper-potts', kind:'support', type:'support', ownerUid:'P0', exhausted:false };
  pl.playArea.supports.push(pp);
  const top=MC.makeInstance(G,'split-personality',{}); // energy 1
  pl.discard.push(top);
  const pay=MC.computePayment(G, pl, [{kind:'card',uid:'ppT'}], MC.cardDef('repulsor-blast'));
  check('페퍼 — 버림 맨 위 에너지 자원 생성', pay.icons.energy===1);
  const cheap=MC.makeInstance(G,'repulsor-blast',{}); cheap.ownerUid='P0'; pl.hand.push(cheap);
  MC.dispatch(G,{type:'playCard', player:'P0', cardUid:cheap.uid, payment:[{kind:'card',uid:'ppT'}], targets:[G.villain.uid]});
  check('페퍼 — 소진', pp.exhausted);
  check('페퍼 — 결제로 카드 플레이됨', pl.discard.some(c=>c.defCode==='repulsor-blast'));
  // 버림 비면 사용 불가
  const G2=newGame('hero'); const pl2=G2.players[0];
  if(pl2.form==='alter-ego') MC.flipForm(G2,pl2,{force:true});
  pl2.discard.length=0;
  pl2.playArea.supports.push({ uid:'pp2', defCode:'pepper-potts', kind:'support', type:'support', ownerUid:'P0', exhausted:false });
  let noBin=false; try{ MC.computePayment(G2, pl2, [{kind:'card',uid:'pp2'}], MC.cardDef('repulsor-blast')); }catch(e){ noBin=/버림 더미가 비어/.test(e.message); }
  check('페퍼 — 버림 비면 사용 불가', noBin);
  check('pepper-potts — todoFx 해제', !MC.cardDef('pepper-potts').todoFx);
}

/* 코어 #34 — 스타크 타워: 알터에고, 소진 → 버림 맨 위 Tech 업그레이드 손 회수 */
{
  const G=newGame('hero'); const pl=G.players[0];
  if(pl.form==='hero') MC.flipForm(G,pl,{force:true}); // 알터에고
  const st={ uid:'stT', defCode:'stark-tower', kind:'support', type:'support', ownerUid:'P0', exhausted:false };
  pl.playArea.supports.push(st);
  const arc=MC.makeInstance(G,'arc-reactor',{}); pl.discard.push(arc);
  const nonTech=MC.makeInstance(G,'backflip',{}); pl.discard.push(nonTech);
  const handB=pl.hand.length;
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'stT', payment:[]});
  check('스타크 타워 — 손패 +1', (pl.hand.length-handB)===1);
  check('스타크 타워 — Tech 업그레이드 회수(비Tech 건너뜀)', pl.hand.some(c=>c.defCode==='arc-reactor'));
  check('스타크 타워 — 소진', st.exhausted);
  check('arc-reactor traits tech', MC.cardDef('arc-reactor').traits.includes('tech'));
  // 히어로 폼 거부
  const G2=newGame('hero'); const pl2=G2.players[0];
  if(pl2.form==='alter-ego') MC.flipForm(G2,pl2,{force:true});
  pl2.playArea.supports.push({ uid:'st2', defCode:'stark-tower', kind:'support', type:'support', ownerUid:'P0', exhausted:false });
  let blocked=false; try{ MC.dispatch(G2,{type:'useCardAbility', player:'P0', cardUid:'st2', payment:[]}); }catch(e){ blocked=/형태/.test(e.message); }
  check('스타크 타워 — 히어로 폼 거부', blocked);
  check('stark-tower — todoFx 해제', !MC.cardDef('stark-tower').todoFx);
}

/* 신분 능력 — She-Hulk 히어로 파워 / 아이언맨 동적 손패 */
{
  const G=MC.makeGameState({seed:5,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; G.villain.hp=50;
  if(pl.form==='hero') MC.flipForm(G,pl,{force:true});
  const vB=G.villain.hp; MC.flipForm(G,pl,{force:true});
  check('She-Hulk 파워 — 히어로 변신 시 빌런 2피해', (vB-G.villain.hp)===2);
  const vB2=G.villain.hp; MC.flipForm(G,pl,{force:true});
  check('She-Hulk 파워 — 알터에고 변신 시 미발동', G.villain.hp===vB2);

  const G2=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G2); const pl2=G2.players[0];
  if(pl2.form==='alter-ego') MC.flipForm(G2,pl2,{force:true});
  check('아이언맨 — 기본 손패 1', MC.statOf(G2,pl2,'handSize')===1);
  for(let i=0;i<3;i++) pl2.playArea.upgrades.push({ uid:'t'+i, defCode:'arc-reactor', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  check('아이언맨 — Tech 3개 시 손패 4', MC.statOf(G2,pl2,'handSize')===4);
  for(let i=0;i<10;i++) pl2.playArea.upgrades.push({ uid:'x'+i, defCode:'arc-reactor', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  check('아이언맨 — 최대 7 상한', MC.statOf(G2,pl2,'handSize')===7);
}

/* 신분 액션 — 캡틴마블 Rechannel / 토니 Futurist / 제니퍼 I Object! */
{
  const G=MC.makeGameState({seed:5,players:[{heroCode:'01010a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  pl.hp=MC.heroFace(G,pl).hp-2;
  const e=MC.makeInstance(G,'split-personality',{}); e.ownerUid='P0'; pl.hand.push(e);
  const hpB=pl.hp;
  MC.dispatch(G,{type:'useIdentityAction', player:'P0', payment:[{kind:'hand',uid:e.uid}]});
  check('캡틴마블 Rechannel — 1 회복', (pl.hp-hpB)===1);
  check('캡틴마블 Rechannel — 라운드 사용', pl.usedIdentityActionThisRound);
  let blk=false; try{ MC.dispatch(G,{type:'useIdentityAction', player:'P0', payment:[]}); }catch(e){ blk=/이번 라운드/.test(e.message); }
  check('캡틴마블 Rechannel — 라운드 2회 거부', blk);

  const G2=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G2); const pl2=G2.players[0];
  if(pl2.form==='hero') MC.flipForm(G2,pl2,{force:true});
  const hb=pl2.hand.length, db=pl2.deck.length;
  MC.dispatch(G2,{type:'useIdentityAction', player:'P0'});
  // 실제 흐름: lookAtTopChoose → cardPick pending (덱 위 3장 확인, 1장 선택). UI가 resolveCardPick로 해소.
  check('토니 Futurist — cardPick 대기', G2.pending && G2.pending.kind==='cardPick' && (G2.pending._cards||[]).length===3);
  MC.dispatch(G2,{type:'resolveCardPick', player:'P0', uid:G2.pending._cards[0].uid});
  check('토니 Futurist — 손패 +1', (pl2.hand.length-hb)===1);
  check('토니 Futurist — 덱 -3', (db-pl2.deck.length)===3);

  const G3=MC.makeGameState({seed:5,players:[{heroCode:'01019a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G3); const pl3=G3.players[0];
  if(pl3.form==='hero') MC.flipForm(G3,pl3,{force:true});
  const tb=G3.mainScheme.threat;
  MC.placeThreat(G3,'main',3);
  check('제니퍼 I Object! — 3 중 1 방지 → +2', (G3.mainScheme.threat-tb)===2);
}

/* 코어 #35 — 아크 원자로: 히어로, 소진 → Iron Man 준비 */
{
  const G=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  pl.exhausted=true;
  const ar={ uid:'arT', defCode:'arc-reactor', kind:'upgrade', type:'upgrade', ownerUid:'P0', exhausted:false };
  pl.playArea.upgrades.push(ar);
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'arT', payment:[]});
  check('아크 원자로 — Iron Man 준비', !pl.exhausted);
  check('아크 원자로 — 소진', ar.exhausted);
  check('arc-reactor traits tech', MC.cardDef('arc-reactor').traits.includes('tech'));
  check('arc-reactor — todoFx 해제', !MC.cardDef('arc-reactor').todoFx);
  // 알터에고 거부
  const G2=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G2); const pl2=G2.players[0];
  if(pl2.form==='hero') MC.flipForm(G2,pl2,{force:true});
  pl2.playArea.upgrades.push({ uid:'ar2', defCode:'arc-reactor', kind:'upgrade', type:'upgrade', ownerUid:'P0', exhausted:false });
  let blk=false; try{ MC.dispatch(G2,{type:'useCardAbility', player:'P0', cardUid:'ar2', payment:[]}); }catch(e){ blk=/형태/.test(e.message); }
  check('아크 원자로 — 알터에고 거부', blk);
}

/* 코어 #36 — MK.5 아머: HP +6 (설치 시 증가, 제거 시 감소·클램프) */
{
  const G=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  const armor=MC.makeInstance(G,'mk5-armor',{}); armor.ownerUid='P0';
  pl.playArea.upgrades.push(armor);
  MC.fireCardHook(G, armor, 'whenPlayed', { player: pl });
  check('MK.5 아머 — 최대 HP +6 (9→15)', pl.maxHp===15 && pl.hp===15);
  pl.hp=10;
  const i=pl.playArea.upgrades.indexOf(armor); pl.playArea.upgrades.splice(i,1);
  MC.moveToDiscard(G, pl, armor, {});
  check('MK.5 아머 — 제거 시 최대 9·현재 클램프', pl.maxHp===9 && pl.hp===9);
  check('mk5-armor traits armor+tech', MC.cardDef('mk5-armor').traits.includes('armor') && MC.cardDef('mk5-armor').traits.includes('tech'));
  check('mk5-armor — todoFx 해제', !MC.cardDef('mk5-armor').todoFx);
}

/* 코어 #37 — MK.5 헬멧: 위협 1 제거 (Aerial이면 모든 스킴) */
{
  const G=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  G.mainScheme.threat=5;
  const hel={ uid:'hT', defCode:'mk5-helmet', kind:'upgrade', type:'upgrade', ownerUid:'P0', exhausted:false };
  pl.playArea.upgrades.push(hel);
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'hT', payment:[]});
  check('MK.5 헬멧 — Aerial 없음 메인 -1', (5-G.mainScheme.threat)===1);
  check('MK.5 헬멧 — 소진', hel.exhausted);
  // Aerial: 모든 스킴
  const G2=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G2); const pl2=G2.players[0];
  if(pl2.form==='alter-ego') MC.flipForm(G2,pl2,{force:true});
  MC.CARDS['__t_aer3']={code:'__t_aer3',type:'upgrade',name:'비행',grantsTrait:'aerial',side:'player'};
  pl2.playArea.upgrades.push({ uid:'fly', defCode:'__t_aer3', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  G2.mainScheme.threat=5;
  G2.sideSchemes=[{uid:'ss1',code:'ss1',name:'사이드1',threat:3,maxThreat:5,isMain:false}];
  const hel2={ uid:'h2', defCode:'mk5-helmet', kind:'upgrade', type:'upgrade', ownerUid:'P0', exhausted:false };
  pl2.playArea.upgrades.push(hel2);
  MC.dispatch(G2,{type:'useCardAbility', player:'P0', cardUid:'h2', payment:[]});
  check('MK.5 헬멧 — Aerial 메인 -1', (5-G2.mainScheme.threat)===1);
  check('MK.5 헬멧 — Aerial 사이드 -1', (3-G2.sideSchemes[0].threat)===1);
}

/* 코어 #38 — 동력 건틀릿: 소진 → 적 1 피해 (Aerial이면 2) */
{
  const G=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  G.villain.hp=50;
  const g={ uid:'gT', defCode:'powered-gauntlets', kind:'upgrade', type:'upgrade', ownerUid:'P0', exhausted:false };
  pl.playArea.upgrades.push(g);
  const vB=G.villain.hp;
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:'gT', payment:[], targets:[G.villain.uid]});
  check('동력 건틀릿 — Aerial 없음 1 피해', (vB-G.villain.hp)===1);
  check('동력 건틀릿 — 소진', g.exhausted);
  // Aerial 2 피해
  const G2=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G2); const pl2=G2.players[0];
  if(pl2.form==='alter-ego') MC.flipForm(G2,pl2,{force:true});
  G2.villain.hp=50;
  MC.CARDS['__aer_g2']={code:'__aer_g2',type:'upgrade',name:'비행',grantsTrait:'aerial',side:'player'};
  pl2.playArea.upgrades.push({ uid:'fly', defCode:'__aer_g2', kind:'upgrade', type:'upgrade', ownerUid:'P0' });
  const g2={ uid:'g2', defCode:'powered-gauntlets', kind:'upgrade', type:'upgrade', ownerUid:'P0', exhausted:false };
  pl2.playArea.upgrades.push(g2);
  const vB2=G2.villain.hp;
  MC.dispatch(G2,{type:'useCardAbility', player:'P0', cardUid:'g2', payment:[], targets:[G2.villain.uid]});
  check('동력 건틀릿 — Aerial 보유 2 피해', (vB2-G2.villain.hp)===2);
  check('powered-gauntlets — todoFx 해제', !MC.cardDef('powered-gauntlets').todoFx);
}

/* 코어 #39 — 로켓 부츠: HP+1 + 소진/멘탈지불 → 이번 페이즈 Aerial */
{
  const G=MC.makeGameState({seed:5,players:[{heroCode:'01029a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  if(pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  const rb=MC.makeInstance(G,'rocket-boots',{}); rb.ownerUid='P0';
  pl.playArea.upgrades.push(rb);
  MC.fireCardHook(G, rb, 'whenPlayed', { player: pl });
  check('로켓 부츠 — HP +1 (9→10)', pl.maxHp===10);
  check('로켓 부츠 — 사용 전 Aerial 없음', !MC.playerHasTrait(G,pl,'aerial'));
  const mc=MC.makeInstance(G,'swinging-web-kick',{}); mc.ownerUid='P0'; pl.hand.push(mc);
  MC.dispatch(G,{type:'useCardAbility', player:'P0', cardUid:rb.uid, payment:[{kind:'hand',uid:mc.uid}]});
  check('로켓 부츠 — Aerial 획득', MC.playerHasTrait(G,pl,'aerial'));
  check('로켓 부츠 — 소진', rb.exhausted);
  MC.dispatch(G,{type:'endPlayerPhase'});
  check('로켓 부츠 — 페이즈 종료 시 Aerial 소멸', !MC.playerHasTrait(G,pl,'aerial'));
}

/* 신분 01040 — 블랙팬서: Retaliate 1 / 티찰라: Foresight(셋업 BP 업그레이드 서치) */
{
  const deck = FIXTURE_DECK.slice();
  deck.push('panther-claws','vibranium-suit','tactical-genius-bp','energy-daggers');
  const G=MC.makeGameState({seed:11,players:[{heroCode:'01040a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  // Foresight — 셋업 후 손에 Black Panther 업그레이드 1장 이상 + Foresight 로그
  const bpInHand = pl.hand.filter(c=>{const d=MC.cardDef(c.defCode);return d.type==='upgrade'&&(d.traits||[]).includes('black panther');}).length;
  check('티찰라 Foresight — 손에 BP 업그레이드', bpInHand >= 1);
  check('티찰라 Foresight — 로그 기록', G.gameLog.some(l=>String(l).includes('Foresight')));
  // Retaliate — 알터에고 폼: 미발동
  const vHp0 = G.villain.hp;
  MC.applyDamage(G, pl, 2, { source: G.villain, isAttack: true });
  check('블랙팬서 보복 — 알터에고 폼 미발동', G.villain.hp === vHp0);
  // Retaliate — 히어로 폼: 공격자에게 1 피해
  if (pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  const vHp1 = G.villain.hp;
  MC.applyDamage(G, pl, 2, { source: G.villain, isAttack: true });
  check('블랙팬서 보복 — 히어로 폼 공격자 1 피해', G.villain.hp === vHp1 - 1);
  check('블랙팬서 보복 — fxRetaliate 연출 힌트', !!G.fxRetaliate && G.fxRetaliate.vfx==='kineticRebuke');
  // 상호 보복 루프 가드 — 빌런에도 보복 1 부여 후 공격받아도 1회로 정지
  G.villain.retaliate = 1;
  const pHp0 = pl.hp, vHp2 = G.villain.hp;
  MC.applyDamage(G, pl, 2, { source: G.villain, isAttack: true });
  check('상호 보복 — 빌런 1 피해로 정지(무한루프 없음)', G.villain.hp === vHp2 - 1);
  check('상호 보복 — 히어로 재보복 피해 없음', pl.hp === pHp0 - 2);
  delete G.villain.retaliate;
}

/* 코어 #40 — 슈리: 등장 후 덱에서 업그레이드 서치(BP 우선) + 손 추가 + 셔플 */
{
  const deck = FIXTURE_DECK.slice();
  deck.push('panther-claws','vibranium-suit','tactical-genius-bp','energy-daggers','shuri');
  const G=MC.makeGameState({seed:23,players:[{heroCode:'01040a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  // 덱에 BP 업그레이드가 남아있도록 보정(Foresight/드로우로 전부 빠졌으면 웹슈터라도 존재) 후 슈리 등장
  const sh = MC.makeInstance(G,'shuri',{}); sh.ownerUid='P0';
  pl.playArea.allies.push(sh);
  const handBefore = pl.hand.length;
  const deckUpsBefore = pl.deck.filter(c=>MC.cardDef(c.defCode).type==='upgrade').length;
  MC.fireCardHook(G, sh, 'whenPlayed', { player: pl });
  if (deckUpsBefore > 0){
    check('슈리 — 업그레이드 1장 손에 추가', pl.hand.length === handBefore + 1);
    const got = pl.hand[pl.hand.length-1];
    check('슈리 — 추가된 카드는 업그레이드', MC.cardDef(got.defCode).type === 'upgrade');
    const bpLeft = pl.deck.some(c=>{const d=MC.cardDef(c.defCode);return d.type==='upgrade'&&(d.traits||[]).includes('black panther');});
    const gotBP = (MC.cardDef(got.defCode).traits||[]).includes('black panther');
    check('슈리 — BP 업그레이드 우선 선택', gotBP || !bpLeft);
    check('슈리 — 로그 기록', G.gameLog.some(l=>String(l).includes('슈리')));
  } else {
    check('슈리 — 덱에 업그레이드 없음 케이스 로그', G.gameLog.some(l=>String(l).includes('업그레이드 없음')));
  }
}

/* 코어 #42 — 조상의 지식: 버림 3장(서로 다른 이름, BP 우선) 덱 셔플 + 알터에고 전용 */
{
  const deck = FIXTURE_DECK.slice();
  deck.push('panther-claws','ancestral-knowledge');
  const G=MC.makeGameState({seed:31,players:[{heroCode:'01040a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  // 버림더미 구성: BP 업그레이드 1 + 일반 3 (같은 이름 중복 포함)
  ['vibranium-suit','haymaker','haymaker','first-aid'].forEach(code=>{
    const c=MC.makeInstance(G,code,{}); pl.discard.push(c);
  });
  const dk0 = pl.deck.length, dc0 = pl.discard.length;
  MC.EFFECTS.ancestralKnowledge(G, {}, { player: pl, card: { uid:'evt' } });
  check('조상의 지식 — 3장 덱으로', pl.deck.length === dk0 + 3 && pl.discard.length === dc0 - 3);
  check('조상의 지식 — BP 업그레이드 회수', !pl.discard.some(c=>c.defCode==='vibranium-suit'));
  check('조상의 지식 — 같은 이름 중복 제외(haymaker 1장 잔류)', pl.discard.filter(c=>c.defCode==='haymaker').length === 1);
  check('조상의 지식 — 로그 기록', G.gameLog.some(l=>String(l).includes('조상의 지식')));
  check('조상의 지식 — 알터에고 전용(playForm)', MC.cardDef('ancestral-knowledge').playForm === 'alter-ego');
}

/* 코어 #43~49 — 와칸다 포에버! 시퀀스 + BP 업그레이드 4종 특수 */
{
  const deck = FIXTURE_DECK.slice();
  deck.push('wakanda-forever');
  const G=MC.makeGameState({seed:41,players:[{heroCode:'01040a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  if (pl.form==='alter-ego') MC.flipForm(G,pl,{force:true});
  // 업그레이드 4종 설치 + 교전 하수인 1 + 히어로 피해 2 + 메인 위협 확보
  ['vibranium-suit','tactical-genius-bp','energy-daggers','panther-claws'].forEach(code=>{
    const c=MC.makeInstance(G,code,{}); c.ownerUid=pl.uid; pl.playArea.upgrades.push(c);
  });
  const mn=MC.makeInstance(G,'hydra-soldier',{}); mn.engagedWith=pl.uid; pl.engagedMinions.push(mn); // 교전 하수인
  pl.hp = pl.maxHp - 2;
  G.mainScheme.threat = 5;
  const vHp0=G.villain.hp, mHp0=mn.hp, th0=G.mainScheme.threat, pHp0=pl.hp;
  MC.EFFECTS.wakandaForever(G, {}, { player: pl });
  // 새 방식: 플레이어가 순서 선택(pending). 업그레이드 4개 → wakandaOrder pending.
  check('와칸다 포에버 — 순서 선택 pending 생성', G.pending && G.pending.kind==='wakandaOrder' && G.pending.remaining.length===4);
  // 원하는 순서로 탭 (슈트→재능→단검→발톱). 각 탭의 step 데이터 수집.
  const order = ['vibranium-suit','tactical-genius-bp','energy-daggers','panther-claws'];
  const S = {};
  for (const code of order){
    const inst = pl.playArea.upgrades.find(u=>u.defCode===code);
    MC.dispatch(G, { type:'resolveWakandaStep', uid: inst.uid });
    if (G.fxWakandaSeq && G.fxWakandaSeq.steps) S[code] = G.fxWakandaSeq.steps[0];
  }
  // 효과 누적은 동일 (순서만 플레이어 선택): 슈트1 + 단검1 + 발톱4 = 빌런 총 6
  check('와칸다 포에버 — 빌런 총 피해 6 (슈트1+단검1+발톱4)', G.villain.hp === vHp0 - 6);
  check('와칸다 포에버 — 하수인 단검 1 피해', mn.hp === mHp0 - 1);
  check('와칸다 포에버 — 재능 위협 1 제거', G.mainScheme.threat === th0 - 1);
  check('와칸다 포에버 — 슈트 히어로 회복 1', pl.hp === pHp0 + 1);
  check('와칸다 포에버 — 마지막 탭(발톱)이 final, 나머지 시퀀스 종료', S['panther-claws'].final===true && !G.pending);
  // 효과별 연출 타겟 데이터 (UI 순차 재생용)
  check('연출 데이터 — 단검 targets(빌런+하수인)', (S['energy-daggers'].targets||[]).length===2);
  check('연출 데이터 — 발톱 target=빌런', S['panther-claws'].target===G.villain.uid);
  check('연출 데이터 — 재능 schemeUid', S['tactical-genius-bp'].schemeUid===G.mainScheme.uid);
  check('연출 데이터 — 슈트 target+heroUid', S['vibranium-suit'].target===G.villain.uid && S['vibranium-suit'].heroUid===pl.uid);
  // 단일 업그레이드 = 그 단계가 곧 최종 (발톱만 → 4 피해)
  const G2=MC.makeGameState({seed:42,players:[{heroCode:'01040a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G2); const p2=G2.players[0];
  if (p2.form==='alter-ego') MC.flipForm(G2,p2,{force:true});
  const c2=MC.makeInstance(G2,'panther-claws',{}); c2.ownerUid=p2.uid; p2.playArea.upgrades.push(c2);
  const v2=G2.villain.hp;
  MC.EFFECTS.wakandaForever(G2, {}, { player: p2 });
  check('와칸다 포에버 — 단일 업그레이드는 최종 강화(발톱 4)', G2.villain.hp === v2 - 4);
  // 히어로 무피해 → 슈트 이동 무효 (빌런 피해 없음, 재능만 최종 2)
  const G3=MC.makeGameState({seed:43,players:[{heroCode:'01040a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G3); const p3=G3.players[0];
  if (p3.form==='alter-ego') MC.flipForm(G3,p3,{force:true});
  ['vibranium-suit','tactical-genius-bp'].forEach(code=>{
    const c=MC.makeInstance(G3,code,{}); c.ownerUid=p3.uid; p3.playArea.upgrades.push(c);
  });
  G3.mainScheme.threat = 5;
  const v3=G3.villain.hp, t3=G3.mainScheme.threat;
  MC.EFFECTS.wakandaForever(G3, {}, { player: p3 });
  // 순서 선택: 슈트 먼저(무피해→무효) → 재능 마지막(final 2 제거)
  const suit3 = p3.playArea.upgrades.find(u=>u.defCode==='vibranium-suit');
  const gen3 = p3.playArea.upgrades.find(u=>u.defCode==='tactical-genius-bp');
  MC.dispatch(G3, { type:'resolveWakandaStep', uid: suit3.uid });
  MC.dispatch(G3, { type:'resolveWakandaStep', uid: gen3.uid });
  check('와칸다 포에버 — 무피해 슈트 무효 + 재능 최종 2', G3.villain.hp === v3 && G3.mainScheme.threat === t3 - 2);
}

/* 코어 #44·#45 — 비브라늄(와일드 2) + 황금 도시(알터에고 소진 → 2 드로우) */
{
  const deck = FIXTURE_DECK.slice();
  deck.push('vibranium-resource','golden-city');
  const G=MC.makeGameState({seed:51,players:[{heroCode:'01040a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  // 비브라늄 — 와일드 2 생성 (결제 아이콘 합산)
  const vib=MC.makeInstance(G,'vibranium-resource',{});
  check('비브라늄 — 와일드 자원 2', (MC.resourceIconsOf(vib).wild||0) === 2);
  // 황금 도시 — 알터에고 소진 → 2 드로우
  const gc=MC.makeInstance(G,'golden-city',{}); gc.ownerUid=pl.uid; pl.playArea.supports.push(gc);
  if (pl.form!=='alter-ego') MC.flipForm(G,pl,{force:true});
  const h0=pl.hand.length;
  MC.ACTIONS.useCardAbility(G,{ player:pl.uid, cardUid:gc.uid });
  check('황금 도시 — 2장 드로우', pl.hand.length === h0 + 2);
  check('황금 도시 — 소진됨', gc.exhausted === true);
  let blocked=false;
  try { MC.ACTIONS.useCardAbility(G,{ player:pl.uid, cardUid:gc.uid }); } catch(e){ blocked=true; }
  check('황금 도시 — 소진 상태 재사용 불가', blocked);
  gc.exhausted=false;
  MC.flipForm(G,pl,{force:true}); // 히어로 폼
  let formBlocked=false;
  try { MC.ACTIONS.useCardAbility(G,{ player:pl.uid, cardUid:gc.uid }); } catch(e){ formBlocked=true; }
  check('황금 도시 — 히어로 폼 사용 불가', formBlocked);
}

/* 공격 #50 — 헐크: 강제 반응 자원별 분기 + 이중 아이콘 + 와일드 전부 + 자멸 */
{
  const mk = (seed, topCode) => {
    const deck = FIXTURE_DECK.slice();
    if (topCode) deck.unshift(topCode); // 덱 맨 위 보장 위해선 셔플 후 조정 필요 — 아래서 직접 세팅
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 💪 피지컬 — 적 1명 2 피해
  {
    const G = mk(60); const pl = G.players[0];
    const hulk = MC.makeInstance(G,'hulk-ally',{}); hulk.ownerUid=pl.uid; pl.playArea.allies.push(hulk);
    // 덱 맨 위를 피지컬 자원 카드로 고정
    const phys = MC.makeInstance(G,'haymaker',{}); // 임의 카드 — 아래서 resources 강제
    phys.resources = { physical:1, mental:0, energy:0, wild:0 };
    pl.deck.unshift(phys);
    const v0 = G.villain.hp;
    MC.HANDLERS.hulkForcedResponse(G, { player: pl, attacker: hulk });
    check('헐크 💪 — 빌런에게 2 피해', G.villain.hp === v0 - 2);
    check('헐크 💪 — 카드 버려짐', pl.discard.indexOf(phys) >= 0);
  }
  // ⚡ 에너지 — 각 캐릭터 1 피해 (빌런 + 헐크 자신 포함)
  {
    const G = mk(61); const pl = G.players[0];
    const hulk = MC.makeInstance(G,'hulk-ally',{}); hulk.ownerUid=pl.uid; hulk.hp=5; pl.playArea.allies.push(hulk);
    const enr = MC.makeInstance(G,'haymaker',{}); enr.resources={physical:0,mental:0,energy:1,wild:0}; pl.deck.unshift(enr);
    const v0=G.villain.hp, h0=hulk.hp, p0=pl.hp;
    MC.HANDLERS.hulkForcedResponse(G, { player: pl, attacker: hulk });
    check('헐크 ⚡ — 빌런 1 피해', G.villain.hp === v0 - 1);
    check('헐크 ⚡ — 영웅 1 피해', pl.hp === p0 - 1);
    check('헐크 ⚡ — 헐크 자신도 1 피해', hulk.hp === h0 - 1);
  }
  // 🧠 멘탈 — 헐크 자멸(버림)
  {
    const G = mk(62); const pl = G.players[0];
    const hulk = MC.makeInstance(G,'hulk-ally',{}); hulk.ownerUid=pl.uid; pl.playArea.allies.push(hulk);
    const men = MC.makeInstance(G,'haymaker',{}); men.resources={physical:0,mental:1,energy:0,wild:0}; pl.deck.unshift(men);
    MC.HANDLERS.hulkForcedResponse(G, { player: pl, attacker: hulk });
    check('헐크 🧠 — 자멸(allies에서 제거)', pl.playArea.allies.indexOf(hulk) < 0);
    check('헐크 🧠 — 버림 더미로', pl.discard.indexOf(hulk) >= 0);
  }
  // 💪💪 이중 아이콘 — 2회 발동 (적 2명에게 각 2, 여기선 빌런에게 2회 = 4)
  {
    const G = mk(63); const pl = G.players[0];
    const hulk = MC.makeInstance(G,'hulk-ally',{}); hulk.ownerUid=pl.uid; pl.playArea.allies.push(hulk);
    const dbl = MC.makeInstance(G,'haymaker',{}); dbl.resources={physical:2,mental:0,energy:0,wild:0}; pl.deck.unshift(dbl);
    const v0=G.villain.hp;
    MC.HANDLERS.hulkForcedResponse(G, { player: pl, attacker: hulk });
    check('헐크 💪💪 — 이중 아이콘 2회(빌런 4 피해)', G.villain.hp === v0 - 4);
  }
  // 🌟 와일드 — 전부 발동 (피지컬+에너지+멘탈 자멸)
  {
    const G = mk(64); const pl = G.players[0];
    const hulk = MC.makeInstance(G,'hulk-ally',{}); hulk.ownerUid=pl.uid; hulk.hp=5; pl.playArea.allies.push(hulk);
    const wild = MC.makeInstance(G,'haymaker',{}); wild.resources={physical:0,mental:0,energy:0,wild:1}; pl.deck.unshift(wild);
    const v0=G.villain.hp, p0=pl.hp;
    MC.HANDLERS.hulkForcedResponse(G, { player: pl, attacker: hulk });
    // 피지컬(빌런 2) + 에너지(빌런 1) = 빌런 3, 영웅 에너지 1, 헐크 자멸
    check('헐크 🌟 — 빌런 3 피해(피지컬2+에너지1)', G.villain.hp === v0 - 3);
    check('헐크 🌟 — 영웅 에너지 1 피해', pl.hp === p0 - 1);
    check('헐크 🌟 — 최종 자멸', pl.playArea.allies.indexOf(hulk) < 0);
    check('헐크 🌟 — fxHulk 연출 힌트', !!G.fxHulk && G.fxHulk.hulkUid === hulk.uid);
  }
  // 데이터 교차검증 — 공식 값 (Core Set #50)
  check('헐크 데이터 — cost 2 / ⚡에너지 / 3-/5', (()=>{const d=MC.CARDS['hulk-ally'];return d.cost===2&&(d.resources||{}).energy===1&&d.attack===3&&d.hp===5;})());
}

/* 공격 #51 — 타이그라: 공격으로 하수인 처치 시 1 회복 / 빌런은 회복 없음 / maxHp 초과 방지 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 하수인 처치 → 1 회복 (afterAttack 훅 경유, allyAttack 액션 직접)
  {
    const G = mk(70); const pl = G.players[0];
    const tigra = MC.makeInstance(G,'tigra-ally',{}); tigra.ownerUid=pl.uid; tigra.hp=2; tigra.maxHp=3; tigra.attack=2; pl.playArea.allies.push(tigra);
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=2; m.maxHp=2; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:tigra.uid, targetUid:m.uid });
    check('타이그라 — 하수인 처치', m.hp <= 0);
    // FAQ: 회복(2→3)이 consequential damage(3→2)보다 먼저 → 순 변화 0, 무한 생존
    check('타이그라 — 회복이 자기피해보다 먼저 (HP 2 유지, 무한 생존)', tigra.hp === 2);
    check('타이그라 — 하수인 engagedMinions 제거', !pl.engagedMinions.includes(m));
  }
  // 하수인 공격했지만 처치 못하면 회복 없음
  {
    const G = mk(71); const pl = G.players[0];
    const tigra = MC.makeInstance(G,'tigra-ally',{}); tigra.ownerUid=pl.uid; tigra.hp=3; tigra.maxHp=3; tigra.attack=2; pl.playArea.allies.push(tigra);
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=5; m.maxHp=5; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:tigra.uid, targetUid:m.uid });
    // 하수인 생존 → 회복 없음, 자기피해만 (3→2)
    check('타이그라 — 하수인 생존 시 회복 없음 (자기피해만, HP 2)', tigra.hp === 2 && m.hp === 3);
  }
  // 빌런 공격으로 처치해도 회복 없음 (하수인 아님)
  {
    const G = mk(72); const pl = G.players[0];
    const tigra = MC.makeInstance(G,'tigra-ally',{}); tigra.ownerUid=pl.uid; tigra.hp=3; tigra.maxHp=3; tigra.attack=2; pl.playArea.allies.push(tigra);
    G.villain.hp = 20; // 빌런 생존 (처치 안 됨)
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:tigra.uid, targetUid:G.villain.uid });
    // 빌런은 minion이 아니므로 회복 없음 → 자기피해만 (3→2)
    check('타이그라 — 빌런 공격은 회복 없음 (자기피해만, HP 2)', tigra.hp === 2);
  }
  // maxHp 초과 방지 — 이미 최대 HP면 회복 없음
  {
    const G = mk(73); const pl = G.players[0];
    const tigra = MC.makeInstance(G,'tigra-ally',{}); tigra.ownerUid=pl.uid; tigra.hp=3; tigra.maxHp=3; tigra.attack=2; pl.playArea.allies.push(tigra);
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=2; m.maxHp=2; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:tigra.uid, targetUid:m.uid });
    // HP 최대(3)에서 처치 → 회복은 maxHp 초과 방지로 낭비 → 자기피해만 (3→2)
    check('타이그라 — maxHp 초과 방지 (회복 낭비, HP 2)', tigra.hp === 2);
  }
  // 데이터 교차검증 — 공식 값 (Core Set #51, 자원 아이콘 없음)
  check('타이그라 데이터 — cost 3 / 🧠멘탈 / 2-1-3', (()=>{
    const d=MC.CARDS['tigra-ally'];
    return d.cost===3 && (d.resources||{}).mental===1 && d.attack===2 && d.thwart===1 && d.hp===3;
  })());
}

/* 공격 #52 — 추적하라!(chase-them-down): 히어로가 공격으로 적 처치 후 위협 2 제거 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 히어로 기본 공격으로 하수인 처치 → 플래그 세팅 → 추적하라! 플레이 → 위협 2 제거
  {
    const G = mk(80); const pl = G.players[0];
    MC.resolveScheme(G,'main').threat = 8;
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=1; m.maxHp=1; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    // 히어로 ATK로 처치 (스파이더맨 ATK)
    pl.form='hero'; pl.exhausted=false;
    MC.dispatch(G, { type:'basicAttack', player:pl.uid, targetUid:m.uid });
    check('추적하라! — 히어로 공격으로 하수인 처치', m.hp <= 0);
    check('추적하라! — 처치 플래그 세팅', pl.justDefeatedEnemyByAttack === true);
    // 추적하라! 손에 추가 후 플레이
    const ctd = MC.makeInstance(G,'chase-them-down',{}); ctd.ownerUid=pl.uid; pl.hand.push(ctd);
    const thB = MC.resolveScheme(G,'main').threat;
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:ctd.uid, targetScheme:'main' });
    check('추적하라! — 위협 2 제거', (thB - MC.resolveScheme(G,'main').threat) === 2);
  }
  // 적을 처치하지 않았으면 플레이 불가 (playCondition 불충족)
  {
    const G = mk(81); const pl = G.players[0];
    pl.form='hero';
    const ctd = MC.makeInstance(G,'chase-them-down',{}); ctd.ownerUid=pl.uid; pl.hand.push(ctd);
    let threw = false;
    try { MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:ctd.uid, targetScheme:'main' }); }
    catch(e){ threw = true; }
    check('추적하라! — 적 미처치 시 플레이 불가', threw);
  }
  // 데이터 교차검증 — 공식 값 (Core Set #52, 🧠멘탈, Cost 0)
  check('추적하라! 데이터 — Cost 0 / 🧠멘탈 / 저지', (()=>{
    const d=MC.CARDS['chase-them-down'];
    return d.cost===0 && (d.resources||{}).mental===1 && d.type==='event';
  })());
  // 텍스트 정정 확인 — 💪피지컬 잔재 없음
  check('추적하라! 텍스트 — 자원 🧠멘탈 표기', MC.CARDS['chase-them-down'].textKo.includes('🧠멘탈') && !MC.CARDS['chase-them-down'].textKo.includes('Cost 0. 💪'));
}

/* 공격 #53 — 거침없는 돌진(relentless-assault): 하수인 5피해 + 피지컬 지불 시 오버킬 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 피지컬 지불 → 오버킬: 하수인 HP 2, 5피해 → 처치 + 초과 3 → 빌런
  {
    const G = mk(90); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=2; m.maxHp=2; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    const v0 = G.villain.hp;
    const ra = MC.makeInstance(G,'relentless-assault',{}); ra.ownerUid=pl.uid; pl.hand.push(ra);
    const str = MC.makeInstance(G,'strength',{}); str.ownerUid=pl.uid; pl.hand.push(str); // 💪2
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:ra.uid, targets:[m.uid],
      payment:[{kind:'hand', uid:str.uid}] });
    check('거침없는 돌진 💪 — 하수인 처치', m.hp <= 0);
    check('거침없는 돌진 💪 — 오버킬 초과 3 → 빌런', G.villain.hp === v0 - 3);
  }
  // 에너지 지불 → 오버킬 없음: 하수인 처치되지만 초과 피해 빌런 전달 안 됨
  {
    const G = mk(91); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=2; m.maxHp=2; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    const v0 = G.villain.hp;
    const ra = MC.makeInstance(G,'relentless-assault',{}); ra.ownerUid=pl.uid; pl.hand.push(ra);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en); // ⚡2
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:ra.uid, targets:[m.uid],
      payment:[{kind:'hand', uid:en.uid}] });
    check('거침없는 돌진 ⚡ — 하수인 처치', m.hp <= 0);
    check('거침없는 돌진 ⚡ — 오버킬 없음 (빌런 무피해)', G.villain.hp === v0);
  }
  // 데이터 교차검증 — 공식 값 (Core Set #53, ⚡에너지, Cost 2, attack 특성)
  check('거침없는 돌진 데이터 — Cost 2 / ⚡에너지 / attack', (()=>{
    const d=MC.CARDS['relentless-assault'];
    return d.cost===2 && (d.resources||{}).energy===1 && d.traits.includes('attack');
  })());
}

/* 공격 #54 — 근접 전투(melee): 적 2명 각 3피해, 서로 다른 적 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 두 하수인 각 3피해
  {
    const G = mk(100); const pl = G.players[0]; pl.form='hero';
    const m1 = MC.makeInstance(G,'shocker',{kind:'minion'}); m1.type='minion'; m1.hp=5; m1.maxHp=5; m1.engagedWith=pl.uid; pl.engagedMinions.push(m1);
    const m2 = MC.makeInstance(G,'shocker',{kind:'minion'}); m2.type='minion'; m2.hp=5; m2.maxHp=5; m2.engagedWith=pl.uid; pl.engagedMinions.push(m2);
    const me = MC.makeInstance(G,'melee',{}); me.ownerUid=pl.uid; pl.hand.push(me);
    const gen1 = MC.makeInstance(G,'genius',{}); gen1.ownerUid=pl.uid; pl.hand.push(gen1); // 🧠2 (cost 3 결제 보조)
    const en1 = MC.makeInstance(G,'energy',{}); en1.ownerUid=pl.uid; pl.hand.push(en1);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:me.uid, targets:[m1.uid, m2.uid],
      payment:[{kind:'hand', uid:gen1.uid},{kind:'hand', uid:en1.uid}] });
    check('근접 전투 — 첫 적 3피해 (5→2)', m1.hp === 2);
    check('근접 전투 — 둘째 적 3피해 (5→2)', m2.hp === 2);
  }
  // 같은 적 중복 지정 → 두 번째 라인 스킵 (한 번만 피해)
  {
    const G = mk(101); const pl = G.players[0]; pl.form='hero';
    const m1 = MC.makeInstance(G,'shocker',{kind:'minion'}); m1.type='minion'; m1.hp=10; m1.maxHp=10; m1.engagedWith=pl.uid; pl.engagedMinions.push(m1);
    const me = MC.makeInstance(G,'melee',{}); me.ownerUid=pl.uid; pl.hand.push(me);
    const gen1 = MC.makeInstance(G,'genius',{}); gen1.ownerUid=pl.uid; pl.hand.push(gen1);
    const en1 = MC.makeInstance(G,'energy',{}); en1.ownerUid=pl.uid; pl.hand.push(en1);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:me.uid, targets:[m1.uid, m1.uid],
      payment:[{kind:'hand', uid:gen1.uid},{kind:'hand', uid:en1.uid}] });
    check('근접 전투 — 같은 적 중복 시 한 번만 (10→7)', m1.hp === 7);
  }
  // 첫 라인 하수인 처치 후 둘째 라인 빌런 타격
  {
    const G = mk(102); const pl = G.players[0]; pl.form='hero';
    const m1 = MC.makeInstance(G,'shocker',{kind:'minion'}); m1.type='minion'; m1.hp=2; m1.maxHp=2; m1.engagedWith=pl.uid; pl.engagedMinions.push(m1);
    const v0 = G.villain.hp;
    const me = MC.makeInstance(G,'melee',{}); me.ownerUid=pl.uid; pl.hand.push(me);
    const gen1 = MC.makeInstance(G,'genius',{}); gen1.ownerUid=pl.uid; pl.hand.push(gen1);
    const en1 = MC.makeInstance(G,'energy',{}); en1.ownerUid=pl.uid; pl.hand.push(en1);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:me.uid, targets:[m1.uid, G.villain.uid],
      payment:[{kind:'hand', uid:gen1.uid},{kind:'hand', uid:en1.uid}] });
    check('근접 전투 — 첫 라인 하수인 처치', m1.hp <= 0);
    check('근접 전투 — 둘째 라인 빌런 3피해', G.villain.hp === v0 - 3);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 05030, 🧠멘탈, Cost 3, attack)
  check('근접 전투 데이터 — Cost 3 / 🧠멘탈 / attack', (()=>{
    const d=MC.CARDS['melee'];
    return d.cost===3 && (d.resources||{}).mental===1 && d.traits.includes('attack');
  })());
}

/* 공격 01054 — 어퍼컷(uppercut): 적 1명 5피해 (하수인/빌런 모두 대상) */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 하수인 5피해
  {
    const G = mk(110); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=6; m.maxHp=6; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    const uc = MC.makeInstance(G,'uppercut',{}); uc.ownerUid=pl.uid; pl.hand.push(uc);
    const str = MC.makeInstance(G,'strength',{}); str.ownerUid=pl.uid; pl.hand.push(str); // 💪2
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en); // ⚡2 (cost 3 결제 보조)
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:uc.uid, targets:[m.uid],
      payment:[{kind:'hand', uid:str.uid},{kind:'hand', uid:en.uid}] });
    check('어퍼컷 — 하수인 5피해 (6→1)', m.hp === 1);
  }
  // 빌런 5피해 (하수인 전용 아님 — relentless-assault와 대비)
  {
    const G = mk(111); const pl = G.players[0]; pl.form='hero';
    const v0 = G.villain.hp;
    const uc = MC.makeInstance(G,'uppercut',{}); uc.ownerUid=pl.uid; pl.hand.push(uc);
    const str = MC.makeInstance(G,'strength',{}); str.ownerUid=pl.uid; pl.hand.push(str);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:uc.uid, targets:[G.villain.uid],
      payment:[{kind:'hand', uid:str.uid},{kind:'hand', uid:en.uid}] });
    check('어퍼컷 — 빌런 5피해 (하수인 전용 아님)', G.villain.hp === v0 - 5);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01054, 💪피지컬, Cost 3, attack)
  check('어퍼컷 데이터 — Cost 3 / 💪피지컬 / attack', (()=>{
    const d=MC.CARDS['uppercut'];
    return d.cost===3 && (d.resources||{}).physical===1 && d.traits.includes('attack');
  })());
}

/* 공격 01055 — 용맹의 힘(power-of-aggression): 용맹 카드 지불 시 와일드 2배 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 용맹(aggression) 카드 결제 시 → 와일드 2개
  {
    const G = mk(120); const pl = G.players[0]; pl.form='hero';
    const poa = MC.makeInstance(G,'power-of-aggression',{}); poa.ownerUid=pl.uid; pl.hand.push(poa);
    const els = [{kind:'hand', uid:poa.uid}];
    const aggCard = MC.makeInstance(G,'uppercut',{}); // aspect aggression
    const res = MC.computePayment(G, pl, els, aggCard);
    check('용맹의 힘 — 용맹 카드 결제 시 와일드 2개', res.icons.wild === 2);
  }
  // 비-용맹(기본) 자원으로 취급되는 대상 — 대상이 aggression 아니면 와일드 1개
  {
    const G = mk(121); const pl = G.players[0]; pl.form='hero';
    const poa = MC.makeInstance(G,'power-of-aggression',{}); poa.ownerUid=pl.uid; pl.hand.push(poa);
    const els = [{kind:'hand', uid:poa.uid}];
    // 기본(basic) 자원 카드를 대상으로 (strength = basic, aspect 없음/basic)
    const basicCard = MC.makeInstance(G,'strength',{});
    const res = MC.computePayment(G, pl, els, basicCard);
    check('용맹의 힘 — 비용맹 카드 결제 시 와일드 1개', res.icons.wild === 1);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01055, 🌟와일드, Cost 0, deckLimit 2)
  check('용맹의 힘 데이터 — Cost 0 / 🌟와일드 / deckLimit 2', (()=>{
    const d=MC.CARDS['power-of-aggression'];
    return d.cost===0 && (d.resources||{}).wild===1 && d.type==='resource' && d.deckLimit===2;
  })());
  // fx 등록 확인 — doubleForAspect aggression
  check('용맹의 힘 — doubleForAspect aggression 등록', MC.cardDef('power-of-aggression').doubleForAspect === 'aggression');
}

/* 공격 01056 — 전술공격팀(tac-team): 서포트, 카운터 3, 활성화 시 적 2피해 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 등장 시 카운터 3
  {
    const G = mk(130); const pl = G.players[0]; pl.form='hero';
    const tt = MC.makeInstance(G,'tac-team',{}); tt.ownerUid=pl.uid; pl.playArea.supports.push(tt);
    check('전술공격팀 — 등장 시 카운터 3', tt.counters === 3);
  }
  // 활성화 → 빌런 2피해 + 카운터 감소 + 소진
  {
    const G = mk(131); const pl = G.players[0]; pl.form='hero';
    const tt = MC.makeInstance(G,'tac-team',{}); tt.ownerUid=pl.uid; pl.playArea.supports.push(tt);
    const v0 = G.villain.hp;
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:tt.uid, targets:[G.villain.uid] });
    check('전술공격팀 — 적 2피해', G.villain.hp === v0 - 2);
    check('전술공격팀 — 카운터 2 남음', tt.counters === 2);
    check('전술공격팀 — 소진됨', tt.exhausted === true);
  }
  // 소진 상태에서 재사용 불가
  {
    const G = mk(132); const pl = G.players[0]; pl.form='hero';
    const tt = MC.makeInstance(G,'tac-team',{}); tt.ownerUid=pl.uid; pl.playArea.supports.push(tt);
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:tt.uid, targets:[G.villain.uid] });
    let threw = false;
    try { MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:tt.uid, targets:[G.villain.uid] }); }
    catch(e){ threw = true; }
    check('전술공격팀 — 소진 시 재사용 불가', threw);
  }
  // 3회 사용 후 카운터 소진 → 버림
  {
    const G = mk(133); const pl = G.players[0]; pl.form='hero';
    const tt = MC.makeInstance(G,'tac-team',{}); tt.ownerUid=pl.uid; pl.playArea.supports.push(tt);
    for (let i = 0; i < 3; i++){
      tt.exhausted = false; // 매 라운드 준비 상태 가정
      MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:tt.uid, targets:[G.villain.uid] });
    }
    check('전술공격팀 — 3회 후 카운터 0', tt.counters === 0);
    check('전술공격팀 — 3회 후 supports에서 제거(버림)', !pl.playArea.supports.includes(tt));
    check('전술공격팀 — 버림 더미로 이동', pl.discard.includes(tt));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01056, 자원없음, Cost 3, uses 3, S.H.I.E.L.D.)
  check('전술공격팀 데이터 — Cost 3 / ⚡에너지 / support / S.H.I.E.L.D.', (()=>{
    const d=MC.CARDS['tac-team'];
    return d.cost===3 && (d.resources||{}).energy===1 && d.type==='support' && d.traits.includes('s.h.i.e.l.d.');
  })());
}

/* 공격 01057 — 전투 훈련(combat-training): 히어로 ATK +1 지속 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // ATK +1 지속 효과 (statOf 반영)
  {
    const G = mk(140); const pl = G.players[0]; pl.form='hero';
    const atkBase = MC.statOf(G, pl, 'attack');
    const ct = MC.makeInstance(G,'combat-training',{}); ct.ownerUid=pl.uid; pl.playArea.upgrades.push(ct);
    check('전투 훈련 — ATK +1 (statOf 반영)', MC.statOf(G, pl, 'attack') === atkBase + 1);
  }
  // 실제 기본 공격 피해 +1
  {
    const G = mk(141); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=10; m.maxHp=10; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    const atkBase = MC.statOf(G, pl, 'attack');
    const ct = MC.makeInstance(G,'combat-training',{}); ct.ownerUid=pl.uid; pl.playArea.upgrades.push(ct);
    MC.dispatch(G, { type:'basicAttack', player:pl.uid, targetUid:m.uid });
    check('전투 훈련 — 기본 공격 피해 +1', m.hp === 10 - (atkBase + 1));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01057, 💪피지컬, Cost 2, upgrade)
  check('전투 훈련 데이터 — Cost 2 / 💪피지컬 / upgrade / skill', (()=>{
    const d=MC.CARDS['combat-training'];
    return d.cost===2 && (d.resources||{}).physical===1 && d.type==='upgrade' && d.traits.includes('skill');
  })());
  // statMod 등록 확인
  check('전투 훈련 — statMod attack +1 등록', (()=>{
    const sm=MC.cardDef('combat-training').statMod;
    return sm && sm.stat==='attack' && sm.amount===1;
  })());
}

/* 공격 03031 — 격분(enraged): 동료 부착, ATK+2 + 부수 피해+1 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const addAlly = (G, pl) => {
    const a = MC.makeInstance(G,'tigra-ally',{}); a.ownerUid=pl.uid; a.attack=2; a.atkCost=1; a.hp=5; a.maxHp=5; pl.playArea.allies.push(a); return a;
  };
  const playEnraged = (G, pl, ally) => {
    const en = MC.makeInstance(G,'enraged',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    const str = MC.makeInstance(G,'strength',{}); str.ownerUid=pl.uid; pl.hand.push(str);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:en.uid, targets:[ally.uid], payment:[{kind:'hand', uid:str.uid}] });
    return en;
  };
  // 부착 → ATK +2, atkCost +1
  {
    const G = mk(150); const pl = G.players[0]; pl.form='hero';
    const ally = addAlly(G, pl);
    playEnraged(G, pl, ally);
    check('격분 — 부착 동료 ATK +2 (2→4)', ally.attack === 4);
    check('격분 — 부수 피해 +1 (atkCost 1→2)', ally.atkCost === 2);
    check('격분 — 동료에 부착됨', (ally.attachments||[]).some(a => a.defCode==='enraged'));
  }
  // 공격 시 강화 ATK 적용 + 부수 피해 2
  {
    const G = mk(151); const pl = G.players[0]; pl.form='hero';
    const ally = addAlly(G, pl);
    playEnraged(G, pl, ally);
    const v0 = G.villain.hp; const h0 = ally.hp;
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:ally.uid, targetUid:G.villain.uid });
    check('격분 — 공격 시 빌런 4피해 (ATK+2)', v0 - G.villain.hp === 4);
    check('격분 — 공격 후 부수 피해 2 (기본1+격분1)', h0 - ally.hp === 2);
  }
  // 저지 시 부수 피해는 +1 미적용 (FAQ) — allyThwart은 thwCost만
  {
    const G = mk(152); const pl = G.players[0]; pl.form='hero';
    const ally = addAlly(G, pl); ally.thwart = 1; ally.thwCost = 1;
    playEnraged(G, pl, ally);
    const h0 = ally.hp;
    MC.dispatch(G, { type:'allyThwart', player:pl.uid, allyUid:ally.uid, scheme:'main' });
    // 저지 부수 피해는 thwCost(1)만 — 격분의 +1은 공격에만 적용
    check('격분 — 저지 시 부수 피해 +1 미적용 (thwCost 1만)', h0 - ally.hp === 1);
  }
  // 동료당 최대 1장
  {
    const G = mk(153); const pl = G.players[0]; pl.form='hero';
    const ally = addAlly(G, pl);
    playEnraged(G, pl, ally);
    let threw = false;
    try { playEnraged(G, pl, ally); } catch(e){ threw = true; }
    check('격분 — 동료당 최대 1장', threw);
  }
  // 데이터 교차검증 — 공식 값 (Captain America 03031, 💪피지컬, Cost 1, upgrade)
  check('격분 데이터 — Cost 1 / 💪피지컬 / upgrade / condition', (()=>{
    const d=MC.CARDS['enraged'];
    return d.cost===1 && (d.resources||{}).physical===1 && d.type==='upgrade' && d.traits.includes('condition');
  })());
}

/* 정의 01058 — 데어데블(동료): 저지 후 적 1명에게 1 피해 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 저지 → 위협 2 감소 + 빌런 1피해 + 자기피해 1
  {
    const G = mk(160); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const dd = MC.makeInstance(G,'daredevil',{}); dd.ownerUid=pl.uid; dd.thwart=2; dd.thwCost=1; dd.hp=3; dd.maxHp=3; pl.playArea.allies.push(dd);
    const th0 = MC.resolveScheme(G,'main').threat; const v0 = G.villain.hp;
    MC.dispatch(G, { type:'allyThwart', player:pl.uid, allyUid:dd.uid, scheme:'main', pingTargets:[G.villain.uid] });
    check('데어데블 — 저지로 위협 2 감소', th0 - MC.resolveScheme(G,'main').threat === 2);
    check('데어데블 — 저지 후 빌런 1피해', v0 - G.villain.hp === 1);
    check('데어데블 — 자기피해 1 (thwCost)', dd.hp === 2);
  }
  // 하수인 대상 저지 반응 (tough 제거 유용)
  {
    const G = mk(161); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=3; m.maxHp=3; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    const dd = MC.makeInstance(G,'daredevil',{}); dd.ownerUid=pl.uid; dd.thwart=2; dd.thwCost=1; dd.hp=3; dd.maxHp=3; pl.playArea.allies.push(dd);
    MC.dispatch(G, { type:'allyThwart', player:pl.uid, allyUid:dd.uid, scheme:'main', pingTargets:[m.uid] });
    check('데어데블 — 하수인 대상 1피해 (3→2)', m.hp === 2);
  }
  // FAQ: consequential damage 전에 반응 판정 (마지막 저지에서도 피해)
  {
    const G = mk(162); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const dd = MC.makeInstance(G,'daredevil',{}); dd.ownerUid=pl.uid; dd.thwart=2; dd.thwCost=1; dd.hp=1; dd.maxHp=3; pl.playArea.allies.push(dd);
    const v0 = G.villain.hp;
    MC.dispatch(G, { type:'allyThwart', player:pl.uid, allyUid:dd.uid, scheme:'main', pingTargets:[G.villain.uid] });
    // HP 1에서 저지 → 반응(빌런 1피해)이 자기피해(격파)보다 먼저
    check('데어데블 — 마지막 저지에서도 피해 (반응이 자기피해보다 먼저)', v0 - G.villain.hp === 1);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01058, 자원없음, Cost 4, Defender, unique)
  check('데어데블 데이터 — Cost 4 / 💪피지컬 / 2-2-3 / Defender / unique', (()=>{
    const d=MC.CARDS['daredevil'];
    return d.cost===4 && (d.resources||{}).physical===1 && d.attack===2 && d.thwart===2 && d.hp===3 && d.traits.includes('defender') && d.unique===true;
  })());
}

/* 정의 01059 — 제시카 존스(동료): 사이드 스킴 개수만큼 THW +1 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 사이드 스킴 0개 → 기본 THW 1
  {
    const G = mk(170); const pl = G.players[0]; pl.form='hero';
    const jj = MC.makeInstance(G,'jessica-jones',{}); jj.ownerUid=pl.uid; jj.thwart=1; jj.thwCost=1; jj.hp=3; jj.maxHp=3; pl.playArea.allies.push(jj);
    check('제시카 존스 — 사이드 스킴 0개 시 THW 1', MC.allyStatOf(G, jj, 'thwart') === 1);
  }
  // 사이드 스킴 2개 → THW 3
  {
    const G = mk(171); const pl = G.players[0]; pl.form='hero';
    const jj = MC.makeInstance(G,'jessica-jones',{}); jj.ownerUid=pl.uid; jj.thwart=1; jj.thwCost=1; jj.hp=3; jj.maxHp=3; pl.playArea.allies.push(jj);
    G.sideSchemes.push({ uid:'ss1', threat:3 }, { uid:'ss2', threat:2 });
    check('제시카 존스 — 사이드 스킴 2개 시 THW 3', MC.allyStatOf(G, jj, 'thwart') === 3);
  }
  // 실제 저지 시 강화 THW 반영
  {
    const G = mk(172); const pl = G.players[0]; pl.form='hero';
    const jj = MC.makeInstance(G,'jessica-jones',{}); jj.ownerUid=pl.uid; jj.thwart=1; jj.thwCost=1; jj.hp=3; jj.maxHp=3; pl.playArea.allies.push(jj);
    G.sideSchemes.push({ uid:'ss1', threat:3 }, { uid:'ss2', threat:2 });
    MC.resolveScheme(G,'main').threat = 10;
    const th0 = MC.resolveScheme(G,'main').threat;
    MC.dispatch(G, { type:'allyThwart', player:pl.uid, allyUid:jj.uid, scheme:'main' });
    check('제시카 존스 — 저지 시 위협 3 감소 (THW 1+2)', th0 - MC.resolveScheme(G,'main').threat === 3);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01059, ⚡에너지, Cost 3, Defender, unique)
  check('제시카 존스 데이터 — Cost 3 / ⚡에너지 / 2-1-3 / Defender / unique', (()=>{
    const d=MC.CARDS['jessica-jones'];
    return d.cost===3 && (d.resources||{}).energy===1 && d.attack===2 && d.thwart===1 && d.hp===3 && d.traits.includes('defender') && d.unique===true;
  })());
}

/* 정의 01060 — 정의를 위해!(for-justice): 위협 3 제거 (멘탈 지불 시 4) */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 에너지 지불 → 위협 3 제거
  {
    const G = mk(180); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const fj = MC.makeInstance(G,'for-justice',{}); fj.ownerUid=pl.uid; pl.hand.push(fj);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en); // ⚡2
    const th0 = MC.resolveScheme(G,'main').threat;
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:fj.uid, targetScheme:'main', payment:[{kind:'hand', uid:en.uid}] });
    check('정의를 위해! ⚡ — 위협 3 제거', th0 - MC.resolveScheme(G,'main').threat === 3);
  }
  // 멘탈 지불 → 위협 4 제거 (킥커)
  {
    const G = mk(181); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const fj = MC.makeInstance(G,'for-justice',{}); fj.ownerUid=pl.uid; pl.hand.push(fj);
    const gen = MC.makeInstance(G,'genius',{}); gen.ownerUid=pl.uid; pl.hand.push(gen); // 🧠2
    const th0 = MC.resolveScheme(G,'main').threat;
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:fj.uid, targetScheme:'main', payment:[{kind:'hand', uid:gen.uid}] });
    check('정의를 위해! 🧠 — 위협 4 제거 (킥커)', th0 - MC.resolveScheme(G,'main').threat === 4);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01060, ⚡에너지, Cost 2, event, thwart)
  check('정의를 위해! 데이터 — Cost 2 / ⚡에너지 / event / thwart', (()=>{
    const d=MC.CARDS['for-justice'];
    return d.cost===2 && (d.resources||{}).energy===1 && d.type==='event' && d.traits.includes('thwart');
  })());
}

/* 정의 01061 — 큰 힘에는 큰 책임(great-responsibility): 위협을 피해로 대체 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 위협 3 예정 → 히어로 3 피해 + 위협 배치 취소
  {
    const G = mk(190); const pl = G.players[0]; pl.form='hero';
    const h0 = pl.hp;
    const gr = MC.makeInstance(G,'great-responsibility',{}); gr.ownerUid=pl.uid; pl.hand.push(gr);
    const gen = MC.makeInstance(G,'genius',{}); gen.ownerUid=pl.uid; pl.hand.push(gen);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:gr.uid, threatAmount:3, payment:[{kind:'hand', uid:gen.uid}] });
    check('큰 힘에는 큰 책임 — 히어로가 위협만큼 3 피해', pl.hp === h0 - 3);
    check('큰 힘에는 큰 책임 — preventNextThreat 3 예약', G.preventNextThreat === 3);
    // 위협 배치 취소 확인
    const th0 = MC.resolveScheme(G,'main').threat;
    MC.placeThreat(G,'main',3);
    check('큰 힘에는 큰 책임 — 위협 배치 취소 (0)', MC.resolveScheme(G,'main').threat === th0);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01061, 🧠멘탈, Cost 0, event)
  check('큰 힘에는 큰 책임 데이터 — Cost 0 / 🧠멘탈 / event', (()=>{
    const d=MC.CARDS['great-responsibility'];
    return d.cost===0 && (d.resources||{}).mental===1 && d.type==='event';
  })());
}

/* 정의 01063 — 심문실(interrogation-room): 하수인 처치 후 위협 1 제거 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 하수인 처치 전엔 발동 불가
  {
    const G = mk(200); const pl = G.players[0]; pl.form='hero';
    const ir = MC.makeInstance(G,'interrogation-room',{}); ir.ownerUid=pl.uid; pl.playArea.supports.push(ir);
    let blocked = false;
    try { MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:ir.uid, targetScheme:'main' }); }
    catch(e){ blocked = /조건/.test(e.message); }
    check('심문실 — 하수인 처치 전 발동 불가', blocked);
  }
  // 하수인 처치 후 → 위협 1 제거 + 소진
  {
    const G = mk(201); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const ir = MC.makeInstance(G,'interrogation-room',{}); ir.ownerUid=pl.uid; pl.playArea.supports.push(ir);
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=1; m.maxHp=1; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    MC.dispatch(G, { type:'basicAttack', player:pl.uid, targetUid:m.uid });
    check('심문실 — 하수인 처치 플래그', pl.justDefeatedMinionByHero === true);
    const th0 = MC.resolveScheme(G,'main').threat;
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:ir.uid, targetScheme:'main' });
    check('심문실 — 위협 1 제거', th0 - MC.resolveScheme(G,'main').threat === 1);
    check('심문실 — 소진됨', ir.exhausted === true);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01063, ⚡에너지, Cost 1, support, Location)
  check('심문실 데이터 — Cost 1 / ⚡에너지 / support / Location', (()=>{
    const d=MC.CARDS['interrogation-room'];
    return d.cost===1 && (d.resources||{}).energy===1 && d.type==='support' && d.traits.includes('location');
  })());
}

/* 정의 01064 — 감시팀(surveillance-team): 카운터 3, 소진하며 위협 1 제거 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 등장 시 카운터 3 + 위협 1 제거
  {
    const G = mk(210); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const st = MC.makeInstance(G,'surveillance-team',{}); st.ownerUid=pl.uid; pl.playArea.supports.push(st);
    check('감시팀 — 등장 카운터 3', st.counters === 3);
    const th0 = MC.resolveScheme(G,'main').threat;
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:st.uid, targetScheme:'main' });
    check('감시팀 — 위협 1 제거', th0 - MC.resolveScheme(G,'main').threat === 1);
    check('감시팀 — 카운터 2 남음 + 소진', st.counters === 2 && st.exhausted === true);
  }
  // 3회 후 카운터 소진 → 버림
  {
    const G = mk(211); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const st = MC.makeInstance(G,'surveillance-team',{}); st.ownerUid=pl.uid; pl.playArea.supports.push(st);
    for (let i = 0; i < 3; i++){ st.exhausted = false; MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:st.uid, targetScheme:'main' }); }
    check('감시팀 — 3회 후 카운터 0', st.counters === 0);
    check('감시팀 — 3회 후 supports 제거(버림)', !pl.playArea.supports.includes(st) && pl.discard.includes(st));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01064, 🧠멘탈, Cost 2, support, S.H.I.E.L.D.)
  check('감시팀 데이터 — Cost 2 / 🧠멘탈 / support / S.H.I.E.L.D.', (()=>{
    const d=MC.CARDS['surveillance-team'];
    return d.cost===2 && (d.resources||{}).mental===1 && d.type==='support' && d.traits.includes('s.h.i.e.l.d.');
  })());
}

/* 정의 01065 — 히어로의 직감(heroic-intuition): 히어로 THW +1 지속 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // THW +1 지속 (statOf 반영)
  {
    const G = mk(220); const pl = G.players[0]; pl.form='hero';
    const thBase = MC.statOf(G, pl, 'thwart');
    const hi = MC.makeInstance(G,'heroic-intuition',{}); hi.ownerUid=pl.uid; pl.playArea.upgrades.push(hi);
    check('히어로의 직감 — THW +1 (statOf 반영)', MC.statOf(G, pl, 'thwart') === thBase + 1);
  }
  // 실제 기본 저지량 +1
  {
    const G = mk(221); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const thBase = MC.statOf(G, pl, 'thwart');
    const hi = MC.makeInstance(G,'heroic-intuition',{}); hi.ownerUid=pl.uid; pl.playArea.upgrades.push(hi);
    const t0 = MC.resolveScheme(G,'main').threat;
    MC.dispatch(G, { type:'basicThwart', player:pl.uid, scheme:'main' });
    check('히어로의 직감 — 기본 저지량 +1', t0 - MC.resolveScheme(G,'main').threat === thBase + 1);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01065, ⚡에너지, Cost 2, upgrade, Skill)
  check('히어로의 직감 데이터 — Cost 2 / ⚡에너지 / upgrade / Skill', (()=>{
    const d=MC.CARDS['heroic-intuition'];
    return d.cost===2 && (d.resources||{}).energy===1 && d.type==='upgrade' && d.traits.includes('skill');
  })());
  // statMod 등록 확인
  check('히어로의 직감 — statMod thwart +1 등록', (()=>{
    const sm=MC.cardDef('heroic-intuition').statMod;
    return sm && sm.stat==='thwart' && sm.amount===1;
  })());
}

/* 리더십 01066 — 호크아이(동료): 하수인 등장 시 화살 카운터 소비, 2 피해 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 등장 카운터 4
  {
    const G = mk(230); const pl = G.players[0]; pl.form='hero';
    const hawk = MC.makeInstance(G,'hawkeye',{}); hawk.ownerUid=pl.uid; pl.playArea.allies.push(hawk);
    check('호크아이 — 등장 카운터 4', hawk.counters === 4);
  }
  // 하수인 등장 후 화살 → 2 피해 + 카운터 감소
  {
    const G = mk(231); const pl = G.players[0]; pl.form='hero';
    const hawk = MC.makeInstance(G,'hawkeye',{}); hawk.ownerUid=pl.uid; pl.playArea.allies.push(hawk);
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=3; m.maxHp=3; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    G.minionJustEntered = m.uid;
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:hawk.uid });
    check('호크아이 — 하수인 2 피해 (3→1)', m.hp === 1);
    check('호크아이 — 카운터 3 남음', hawk.counters === 3);
  }
  // 하수인 등장 전엔 발동 불가
  {
    const G = mk(232); const pl = G.players[0]; pl.form='hero';
    const hawk = MC.makeInstance(G,'hawkeye',{}); hawk.ownerUid=pl.uid; pl.playArea.allies.push(hawk);
    delete G.minionJustEntered;
    let blocked = false;
    try { MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:hawk.uid }); }
    catch(e){ blocked = /조건/.test(e.message); }
    check('호크아이 — 하수인 등장 전 발동 불가', blocked);
  }
  // 4회 사용 후 카운터 소진 → 버림
  {
    const G = mk(233); const pl = G.players[0]; pl.form='hero';
    const hawk = MC.makeInstance(G,'hawkeye',{}); hawk.ownerUid=pl.uid; pl.playArea.allies.push(hawk);
    for (let i = 0; i < 4; i++){
      const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=5; m.maxHp=5; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
      G.minionJustEntered = m.uid;
      MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:hawk.uid });
    }
    check('호크아이 — 4회 후 카운터 0', hawk.counters === 0);
    check('호크아이 — 4회 후 allies 제거(버림)', !pl.playArea.allies.includes(hawk) && pl.discard.includes(hawk));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01066, ⚡에너지, Cost 3, Avenger, unique)
  check('호크아이 데이터 — Cost 3 / ⚡에너지 / 1-1-3 / Avenger / unique', (()=>{
    const d=MC.CARDS['hawkeye'];
    return d.cost===3 && (d.resources||{}).energy===1 && d.attack===1 && d.thwart===1 && d.hp===3 && d.traits.includes('avenger') && d.unique===true;
  })());
}

/* 리더십 01067 — 마리아 힐(동료): 등장 시 각 플레이어 1장 드로우 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 등장 시 드로우 (마리아힐 -1 + 지불 -1 + 드로우 +1 = 순 -1)
  {
    const G = mk(240); const pl = G.players[0]; pl.form='hero';
    const mh = MC.makeInstance(G,'maria-hill',{}); mh.ownerUid=pl.uid; pl.hand.push(mh);
    const gen = MC.makeInstance(G,'genius',{}); gen.ownerUid=pl.uid; pl.hand.push(gen);
    const deckBefore = pl.deck.length;
    const handBefore = pl.hand.length;
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:mh.uid, payment:[{kind:'hand', uid:gen.uid}] });
    check('마리아 힐 — 덱에서 1장 드로우', pl.deck.length === deckBefore - 1);
    check('마리아 힐 — 손패 순 -1 (플레이-1, 지불-1, 드로우+1)', pl.hand.length === handBefore - 1);
    check('마리아 힐 — 전장 등장', pl.playArea.allies.some(a => a.defCode==='maria-hill'));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01067, 🧠멘탈, Cost 2, S.H.I.E.L.D., unique)
  check('마리아 힐 데이터 — Cost 2 / 🧠멘탈 / 1-2-2 / S.H.I.E.L.D. / unique', (()=>{
    const d=MC.CARDS['maria-hill'];
    return d.cost===2 && (d.resources||{}).mental===1 && d.attack===1 && d.thwart===2 && d.hp===2 && d.traits.includes('s.h.i.e.l.d.') && d.unique===true;
  })());
}

/* 리더십 01068 — 비전(동료): 에너지 지불 → THW/ATK +2 (페이즈 종료까지, 라운드당 1회) */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const addVision = (G, pl) => {
    const v = MC.makeInstance(G,'vision',{}); v.ownerUid=pl.uid; v.attack=2; v.thwart=1; v.atkCost=1; v.thwCost=1; v.hp=3; v.maxHp=3; pl.playArea.allies.push(v); return v;
  };
  const useVision = (G, pl, vis, choice) => {
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:vis.uid, choice, payment:[{kind:'hand', uid:en.uid}] });
  };
  // ATK +2
  {
    const G = mk(250); const pl = G.players[0]; pl.form='hero';
    const vis = addVision(G, pl);
    useVision(G, pl, vis, 'attack');
    check('비전 — ATK +2 (2→4)', MC.allyStatOf(G, vis, 'attack') === 4);
    check('비전 — THW 변화 없음 (1)', MC.allyStatOf(G, vis, 'thwart') === 1);
  }
  // THW +2
  {
    const G = mk(251); const pl = G.players[0]; pl.form='hero';
    const vis = addVision(G, pl);
    useVision(G, pl, vis, 'thwart');
    check('비전 — THW +2 (1→3)', MC.allyStatOf(G, vis, 'thwart') === 3);
  }
  // 라운드당 1회 제한
  {
    const G = mk(252); const pl = G.players[0]; pl.form='hero';
    const vis = addVision(G, pl);
    useVision(G, pl, vis, 'attack');
    let blocked = false;
    try { useVision(G, pl, vis, 'thwart'); } catch(e){ blocked = /라운드/.test(e.message); }
    check('비전 — 라운드당 1회 제한', blocked);
  }
  // 강화된 ATK로 실제 공격
  {
    const G = mk(253); const pl = G.players[0]; pl.form='hero';
    const vis = addVision(G, pl);
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=6; m.maxHp=6; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    useVision(G, pl, vis, 'attack');
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:vis.uid, targetUid:m.uid });
    check('비전 — 강화 ATK 4로 공격 (6→2)', m.hp === 2);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01068, 💪피지컬, Cost 4, Android+Avenger, unique)
  check('비전 데이터 — Cost 4 / 💪피지컬 / 2-1-3 / Android+Avenger / unique', (()=>{
    const d=MC.CARDS['vision'];
    return d.cost===4 && (d.resources||{}).physical===1 && d.attack===2 && d.thwart===1 && d.hp===3 && d.traits.includes('android') && d.traits.includes('avenger') && d.unique===true;
  })());
}

/* 리더십 01069 — 준비 완료!(get-ready): 동료 1명 준비 상태로 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 소진된 동료 → 준비
  {
    const G = mk(260); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.exhausted=true; pl.playArea.allies.push(ally);
    const gr = MC.makeInstance(G,'get-ready',{}); gr.ownerUid=pl.uid; pl.hand.push(gr);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:gr.uid, targets:[ally.uid], payment:[] });
    check('준비 완료! — 소진 동료 준비 상태로', ally.exhausted === false);
  }
  // 준비 후 재공격 가능 (동료 공격 → 소진 → 준비 → 재공격)
  {
    const G = mk(261); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.attack=2; ally.atkCost=1; ally.hp=5; ally.maxHp=5; pl.playArea.allies.push(ally);
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=10; m.maxHp=10; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:ally.uid, targetUid:m.uid });
    check('준비 완료! — 공격 후 소진', ally.exhausted === true);
    const gr = MC.makeInstance(G,'get-ready',{}); gr.ownerUid=pl.uid; pl.hand.push(gr);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:gr.uid, targets:[ally.uid], payment:[] });
    MC.dispatch(G, { type:'allyAttack', player:pl.uid, allyUid:ally.uid, targetUid:m.uid });
    check('준비 완료! — 준비 후 재공격 (10→6, 2회 공격)', m.hp === 6);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01069, 💪피지컬, Cost 0, event)
  check('준비 완료! 데이터 — Cost 0 / 💪피지컬 / event', (()=>{
    const d=MC.CARDS['get-ready'];
    return d.cost===0 && (d.resources||{}).physical===1 && d.type==='event';
  })());
}

/* 리더십 01070 — 선두에서 이끌기(lead-from-the-front): 히어로+동료 THW+1/ATK+1 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 히어로 + 동료 모두 THW+1/ATK+1
  {
    const G = mk(270); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.attack=2; ally.thwart=1; pl.playArea.allies.push(ally);
    const hAtk0 = MC.statOf(G, pl, 'attack'), hThw0 = MC.statOf(G, pl, 'thwart');
    const lf = MC.makeInstance(G,'lead-from-the-front',{}); lf.ownerUid=pl.uid; pl.hand.push(lf);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:lf.uid, payment:[{kind:'hand', uid:en.uid}] });
    check('선두에서 이끌기 — 히어로 ATK+1', MC.statOf(G, pl, 'attack') === hAtk0 + 1);
    check('선두에서 이끌기 — 히어로 THW+1', MC.statOf(G, pl, 'thwart') === hThw0 + 1);
    check('선두에서 이끌기 — 동료 ATK+1 (2→3)', MC.allyStatOf(G, ally, 'attack') === 3);
    check('선두에서 이끌기 — 동료 THW+1 (1→2)', MC.allyStatOf(G, ally, 'thwart') === 2);
  }
  // 강화된 히어로 공격 반영
  {
    const G = mk(271); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=10; m.maxHp=10; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    const atkBase = MC.statOf(G, pl, 'attack');
    const lf = MC.makeInstance(G,'lead-from-the-front',{}); lf.ownerUid=pl.uid; pl.hand.push(lf);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:lf.uid, payment:[{kind:'hand', uid:en.uid}] });
    MC.dispatch(G, { type:'basicAttack', player:pl.uid, targetUid:m.uid });
    check('선두에서 이끌기 — 강화 히어로 공격 (+1 반영)', m.hp === 10 - (atkBase + 1));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01070, ⚡에너지, Cost 2, event, Tactic)
  check('선두에서 이끌기 데이터 — Cost 2 / ⚡에너지 / event / Tactic', (()=>{
    const d=MC.CARDS['lead-from-the-front'];
    return d.cost===2 && (d.resources||{}).energy===1 && d.type==='event' && d.traits.includes('tactic');
  })());
}

/* 리더십 01071 — 호출하기(make-the-call): 버림 더미 동료를 전장 배치 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 버림 더미 동료 → 전장 배치 + HP 복구
  {
    const G = mk(280); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.hp=1; ally.maxHp=3; pl.discard.push(ally);
    const mc = MC.makeInstance(G,'make-the-call',{}); mc.ownerUid=pl.uid; pl.hand.push(mc);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:mc.uid, recallUid:ally.uid, payment:[] });
    check('호출하기 — 동료 전장 배치', pl.playArea.allies.some(a => a.uid===ally.uid));
    check('호출하기 — 버림 더미에서 제거', !pl.discard.includes(ally));
    check('호출하기 — HP 최대로 복구 (1→3)', ally.hp === 3);
  }
  // whenPlayed 등장 효과 발화 (마리아 힐 드로우)
  {
    const G = mk(281); const pl = G.players[0]; pl.form='hero';
    const mh = MC.makeInstance(G,'maria-hill',{}); mh.ownerUid=pl.uid; mh.hp=1; mh.maxHp=2; pl.discard.push(mh);
    const mc = MC.makeInstance(G,'make-the-call',{}); mc.ownerUid=pl.uid; pl.hand.push(mc);
    const deckBefore = pl.deck.length;
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:mc.uid, recallUid:mh.uid, payment:[] });
    check('호출하기 — 배치 시 whenPlayed 발화 (마리아 힐 드로우)', pl.deck.length === deckBefore - 1);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01071, 🧠멘탈, Cost 0, event)
  check('호출하기 데이터 — Cost 0 / 🧠멘탈 / event', (()=>{
    const d=MC.CARDS['make-the-call'];
    return d.cost===0 && (d.resources||{}).mental===1 && d.type==='event';
  })());
}

/* 리더십 01073 — 트리스켈리온(the-triskelion): 동료 한도 +1 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 기본 한도 3 → 트리스켈리온 후 4
  {
    const G = mk(290); const pl = G.players[0]; pl.form='hero';
    check('트리스켈리온 — 기본 동료 한도 3', MC.allyLimitOf(G, pl) === 3);
    const tri = MC.makeInstance(G,'the-triskelion',{}); tri.ownerUid=pl.uid; pl.playArea.supports.push(tri);
    check('트리스켈리온 — 동료 한도 4', MC.allyLimitOf(G, pl) === 4);
  }
  // 한도 초과 시 동료 플레이 거부 (트리스켈리온 없이 4번째)
  {
    const G = mk(291); const pl = G.players[0]; pl.form='hero';
    for (let i = 0; i < 3; i++){ const a = MC.makeInstance(G,'tigra-ally',{}); a.ownerUid=pl.uid; pl.playArea.allies.push(a); }
    const a4 = MC.makeInstance(G,'hawkeye',{}); a4.ownerUid=pl.uid; pl.hand.push(a4);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    const gen = MC.makeInstance(G,'genius',{}); gen.ownerUid=pl.uid; pl.hand.push(gen);
    let blocked = false;
    try { MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:a4.uid, payment:[{kind:'hand', uid:en.uid},{kind:'hand', uid:gen.uid}] }); }
    catch(e){ blocked = /한도/.test(e.message); }
    check('트리스켈리온 없이 — 4번째 동료 거부', blocked);
  }
  // 트리스켈리온 있으면 4번째 동료 배치 가능
  {
    const G = mk(292); const pl = G.players[0]; pl.form='hero';
    const tri = MC.makeInstance(G,'the-triskelion',{}); tri.ownerUid=pl.uid; pl.playArea.supports.push(tri);
    for (let i = 0; i < 3; i++){ const a = MC.makeInstance(G,'tigra-ally',{}); a.ownerUid=pl.uid; pl.playArea.allies.push(a); }
    const a4 = MC.makeInstance(G,'hawkeye',{}); a4.ownerUid=pl.uid; pl.hand.push(a4);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    const gen = MC.makeInstance(G,'genius',{}); gen.ownerUid=pl.uid; pl.hand.push(gen);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:a4.uid, payment:[{kind:'hand', uid:en.uid},{kind:'hand', uid:gen.uid}] });
    check('트리스켈리온 있음 — 4번째 동료 배치 성공', pl.playArea.allies.length === 4);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01073, ⚡에너지, Cost 1, support, Location)
  check('트리스켈리온 데이터 — Cost 1 / ⚡에너지 / support / Location+S.H.I.E.L.D.', (()=>{
    const d=MC.CARDS['the-triskelion'];
    return d.cost===1 && (d.resources||{}).energy===1 && d.type==='support' && d.traits.includes('location') && d.traits.includes('s.h.i.e.l.d.');
  })());
}

/* 리더십 01074 — 감화(inspired): 동료 부착, THW+1/ATK+1 (부수 피해 없음) */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const addAlly = (G, pl) => {
    const a = MC.makeInstance(G,'tigra-ally',{}); a.ownerUid=pl.uid; a.attack=2; a.thwart=1; a.atkCost=1; a.hp=5; a.maxHp=5; pl.playArea.allies.push(a); return a;
  };
  const playInspired = (G, pl, ally) => {
    const ins = MC.makeInstance(G,'inspired',{}); ins.ownerUid=pl.uid; pl.hand.push(ins);
    const str = MC.makeInstance(G,'strength',{}); str.ownerUid=pl.uid; pl.hand.push(str);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:ins.uid, targets:[ally.uid], payment:[{kind:'hand', uid:str.uid}] });
    return ins;
  };
  // 부착 → ATK+1, THW+1
  {
    const G = mk(300); const pl = G.players[0]; pl.form='hero';
    const ally = addAlly(G, pl);
    playInspired(G, pl, ally);
    check('감화 — ATK +1 (2→3)', ally.attack === 3);
    check('감화 — THW +1 (1→2)', ally.thwart === 2);
    check('감화 — 부수 피해 없음 (atkCost 1 유지)', ally.atkCost === 1);
    check('감화 — 동료에 부착됨', (ally.attachments||[]).some(a => a.defCode==='inspired'));
  }
  // 동료당 최대 1장
  {
    const G = mk(301); const pl = G.players[0]; pl.form='hero';
    const ally = addAlly(G, pl);
    playInspired(G, pl, ally);
    let threw = false;
    try { playInspired(G, pl, ally); } catch(e){ threw = true; }
    check('감화 — 동료당 최대 1장', threw);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01074, 💪피지컬, Cost 1, upgrade, Condition)
  check('감화 데이터 — Cost 1 / 💪피지컬 / upgrade / Condition', (()=>{
    const d=MC.CARDS['inspired'];
    return d.cost===1 && (d.resources||{}).physical===1 && d.type==='upgrade' && d.traits.includes('condition');
  })());
}

/* 보호 01076 — 루크 케이지(동료): 등장 시 Tough, HP 5 탱커 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const playLuke = (G, pl) => {
    const lc = MC.makeInstance(G,'luke-cage',{}); lc.ownerUid=pl.uid; pl.hand.push(lc);
    const e1 = MC.makeInstance(G,'energy',{}); e1.ownerUid=pl.uid; pl.hand.push(e1);
    const e2 = MC.makeInstance(G,'energy',{}); e2.ownerUid=pl.uid; pl.hand.push(e2);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:lc.uid, payment:[{kind:'hand', uid:e1.uid},{kind:'hand', uid:e2.uid}] });
    return pl.playArea.allies.find(a => a.defCode==='luke-cage');
  };
  // 등장 시 tough 획득
  {
    const G = mk(310); const pl = G.players[0]; pl.form='hero';
    const lc = playLuke(G, pl);
    check('루크 케이지 — 등장 시 tough 1', lc.status.tough === 1);
    check('루크 케이지 — HP 5', lc.hp === 5);
  }
  // tough가 첫 피해 완전 무효화
  {
    const G = mk(311); const pl = G.players[0]; pl.form='hero';
    const lc = playLuke(G, pl);
    MC.applyDamage(G, lc, 3, {});
    check('루크 케이지 — tough가 3피해 무효화 (HP 5 유지)', lc.hp === 5);
    check('루크 케이지 — tough 소진', lc.status.tough === 0);
    MC.applyDamage(G, lc, 2, {});
    check('루크 케이지 — tough 소진 후 2피해 정상 (5→3)', lc.hp === 3);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01076, ⚡에너지, Cost 4, Defender, unique)
  check('루크 케이지 데이터 — Cost 4 / ⚡에너지 / 2-1-5 / Defender / unique', (()=>{
    const d=MC.CARDS['luke-cage'];
    return d.cost===4 && (d.resources||{}).energy===1 && d.attack===2 && d.thwart===1 && d.hp===5 && d.traits.includes('defender') && d.unique===true;
  })());
}

/* 보호 01077 — 카운터 펀치(counter-punch): 방어 후 적에게 히어로 ATK 피해 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 방어 후 → 빌런에게 히어로 ATK 피해
  {
    const G = mk(320); const pl = G.players[0]; pl.form='hero';
    pl.justDefendedAgainst = G.villain.uid;
    const cp = MC.makeInstance(G,'counter-punch',{}); cp.ownerUid=pl.uid; pl.hand.push(cp);
    const v0 = G.villain.hp; const atk = MC.statOf(G, pl, 'attack');
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:cp.uid, payment:[] });
    check('카운터 펀치 — 빌런에게 히어로 ATK 피해', v0 - G.villain.hp === atk);
    check('카운터 펀치 — 방어 플래그 1회성 소비', !pl.justDefendedAgainst);
  }
  // 하수인 대상 반격
  {
    const G = mk(321); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=5; m.maxHp=5; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    pl.justDefendedAgainst = m.uid;
    const cp = MC.makeInstance(G,'counter-punch',{}); cp.ownerUid=pl.uid; pl.hand.push(cp);
    const atk = MC.statOf(G, pl, 'attack');
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:cp.uid, payment:[] });
    check('카운터 펀치 — 하수인 반격 (5 - ATK)', m.hp === 5 - atk);
  }
  // 방어 안 한 상태에서 발동 불가
  {
    const G = mk(322); const pl = G.players[0]; pl.form='hero';
    delete pl.justDefendedAgainst;
    const cp = MC.makeInstance(G,'counter-punch',{}); cp.ownerUid=pl.uid; pl.hand.push(cp);
    let blocked = false;
    try { MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:cp.uid, payment:[] }); }
    catch(e){ blocked = /조건|플레이/.test(e.message); }
    check('카운터 펀치 — 방어 안 함 시 발동 불가', blocked);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01077, 💪피지컬, Cost 0, event, Attack)
  check('카운터 펀치 데이터 — Cost 0 / 💪피지컬 / event / Attack', (()=>{
    const d=MC.CARDS['counter-punch'];
    return d.cost===0 && (d.resources||{}).physical===1 && d.type==='event' && d.traits.includes('attack');
  })());
}

/* 보호 01080 — 의료팀(med-team): 카운터 3, 소진하며 아군 2 회복 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 등장 카운터 3 + 동료 2 회복
  {
    const G = mk(330); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.hp=1; ally.maxHp=3; pl.playArea.allies.push(ally);
    const mt = MC.makeInstance(G,'med-team',{}); mt.ownerUid=pl.uid; pl.playArea.supports.push(mt);
    check('의료팀 — 등장 카운터 3', mt.counters === 3);
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:mt.uid, targets:[ally.uid] });
    check('의료팀 — 동료 2 회복 (1→3)', ally.hp === 3);
    check('의료팀 — 카운터 2 + 소진', mt.counters === 2 && mt.exhausted === true);
  }
  // 회복은 maxHp 초과 안 함
  {
    const G = mk(331); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.hp=2; ally.maxHp=3; pl.playArea.allies.push(ally);
    const mt = MC.makeInstance(G,'med-team',{}); mt.ownerUid=pl.uid; pl.playArea.supports.push(mt);
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:mt.uid, targets:[ally.uid] });
    check('의료팀 — maxHp 초과 안 함 (2→3, +2 아님)', ally.hp === 3);
  }
  // 3회 후 카운터 소진 → 버림
  {
    const G = mk(332); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.hp=1; ally.maxHp=20; pl.playArea.allies.push(ally);
    const mt = MC.makeInstance(G,'med-team',{}); mt.ownerUid=pl.uid; pl.playArea.supports.push(mt);
    for (let i = 0; i < 3; i++){ mt.exhausted = false; MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:mt.uid, targets:[ally.uid] }); }
    check('의료팀 — 3회 후 카운터 0 + 버림', mt.counters === 0 && !pl.playArea.supports.includes(mt) && pl.discard.includes(mt));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01080, ⚡에너지, Cost 3, support, S.H.I.E.L.D.)
  check('의료팀 데이터 — Cost 3 / ⚡에너지 / support / S.H.I.E.L.D.', (()=>{
    const d=MC.CARDS['med-team'];
    return d.cost===3 && (d.resources||{}).energy===1 && d.type==='support' && d.traits.includes('s.h.i.e.l.d.');
  })());
}

/* 보호 01081 — 방탄 조끼(armored-vest): 히어로 DEF +1 지속 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // DEF +1 지속
  {
    const G = mk(340); const pl = G.players[0]; pl.form='hero';
    const def0 = MC.statOf(G, pl, 'defense');
    const av = MC.makeInstance(G,'armored-vest',{}); av.ownerUid=pl.uid; pl.playArea.upgrades.push(av);
    check('방탄 조끼 — DEF +1 (statOf 반영)', MC.statOf(G, pl, 'defense') === def0 + 1);
  }
  // statMod 등록 확인
  check('방탄 조끼 — statMod defense +1 등록', (()=>{
    const sm=MC.cardDef('armored-vest').statMod;
    return sm && sm.stat==='defense' && sm.amount===1;
  })());
  // 데이터 교차검증 — 공식 값 (Core Set 01081, 🧠멘탈, Cost 1, upgrade, Armor)
  check('방탄 조끼 데이터 — Cost 1 / 🧠멘탈 / upgrade / Armor', (()=>{
    const d=MC.CARDS['armored-vest'];
    return d.cost===1 && (d.resources||{}).mental===1 && d.type==='upgrade' && d.traits.includes('armor');
  })());
}

/* 보호 01082 — 불굴의 정신(indomitable): 방어 후 자신 버림 → 히어로 준비 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 방어 후 → 히어로 준비 + 자신 버림
  {
    const G = mk(350); const pl = G.players[0]; pl.form='hero';
    const ind = MC.makeInstance(G,'indomitable',{}); ind.ownerUid=pl.uid; pl.playArea.upgrades.push(ind);
    pl.exhausted = true; pl.justDefendedAgainst = G.villain.uid;
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:ind.uid });
    check('불굴의 정신 — 히어로 준비 (소진 해제)', pl.exhausted === false);
    check('불굴의 정신 — 자신 버림', !pl.playArea.upgrades.includes(ind) && pl.discard.includes(ind));
  }
  // 방어 안 한 상태에서 발동 불가
  {
    const G = mk(351); const pl = G.players[0]; pl.form='hero';
    const ind = MC.makeInstance(G,'indomitable',{}); ind.ownerUid=pl.uid; pl.playArea.upgrades.push(ind);
    delete pl.justDefendedAgainst;
    let blocked = false;
    try { MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:ind.uid }); }
    catch(e){ blocked = /조건/.test(e.message); }
    check('불굴의 정신 — 방어 안 함 시 발동 불가', blocked);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01082, ⚡에너지, Cost 1, upgrade, Condition)
  check('불굴의 정신 데이터 — Cost 1 / ⚡에너지 / upgrade / Condition', (()=>{
    const d=MC.CARDS['indomitable'];
    return d.cost===1 && (d.resources||{}).energy===1 && d.type==='upgrade' && d.traits.includes('condition');
  })());
}

/* 기본 01083 — 모킹버드(동료): 등장 시 적 1명 기절 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const playMb = (G, pl, targetUid) => {
    const mb = MC.makeInstance(G,'mockingbird',{}); mb.ownerUid=pl.uid; pl.hand.push(mb);
    const pay = [];
    for (let i = 0; i < 3; i++){ const p = MC.makeInstance(G,'strength',{}); p.ownerUid=pl.uid; pl.hand.push(p); pay.push({kind:'hand', uid:p.uid}); }
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:mb.uid, targets:[targetUid], payment:pay });
    // 후보가 여럿이면 적 선택 pending — 지정 대상으로 해소 (빌런만이면 자동 처리됨)
    if (G.pending && G.pending.kind === 'chooseEnemy'){
      MC.dispatch(G, { type:'resolveChooseEnemy', uid: targetUid });
    }
    return mb;
  };
  // 빌런 대상 기절
  {
    const G = mk(360); const pl = G.players[0]; pl.form='hero';
    playMb(G, pl, G.villain.uid);
    check('모킹버드 — 빌런 기절 부여', (G.villain.status.stunned||0) >= 1);
    check('모킹버드 — 전장 등장', pl.playArea.allies.some(a => a.defCode==='mockingbird'));
  }
  // 하수인 대상 기절
  {
    const G = mk(361); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=3; m.maxHp=3; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    playMb(G, pl, m.uid);
    check('모킹버드 — 하수인 기절 부여', (m.status.stunned||0) >= 1);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01083, 💪피지컬, Cost 3, S.H.I.E.L.D.+Spy, unique)
  check('모킹버드 데이터 — Cost 3 / 💪피지컬 / 1-1-3 / S.H.I.E.L.D.+Spy / unique', (()=>{
    const d=MC.CARDS['mockingbird'];
    return d.cost===3 && (d.resources||{}).physical===1 && d.attack===1 && d.thwart===1 && d.hp===3 && d.traits.includes('s.h.i.e.l.d.') && d.traits.includes('spy') && d.unique===true;
  })());
}

/* 기본 01084 — 닉 퓨리(동료): 등장 시 3택 1 + 라운드 종료 버림 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 실제 흐름: playCard → whenPlayed → offerChoice(revealChoice pending).
  // UI가 resolveRevealChoice로 옵션 선택. damage 옵션은 chooseEnemy pending으로 이어져 resolveChooseEnemy로 대상 선택.
  const playFury = (G, pl, choice, targetUid) => {
    const nf = MC.makeInstance(G,'nick-fury',{}); nf.ownerUid=pl.uid; pl.hand.push(nf);
    const pay = [];
    for (let i = 0; i < 4; i++){ const p = MC.makeInstance(G,'genius',{}); p.ownerUid=pl.uid; pl.hand.push(p); pay.push({kind:'hand', uid:p.uid}); }
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:nf.uid, payment:pay });
    // 3택 모달 → 옵션 선택
    MC.dispatch(G, { type:'resolveRevealChoice', player:pl.uid, option:choice });
    // damage 옵션: 대상 적 선택 pending으로 이어짐
    if (choice === 'damage' && G.pending && G.pending.kind === 'chooseEnemy'){
      MC.dispatch(G, { type:'resolveChooseEnemy', uid: targetUid || G.villain.uid });
    }
    return nf;
  };
  // 위협 제거 선택
  {
    const G = mk(370); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 10;
    const th0 = MC.resolveScheme(G,'main').threat;
    playFury(G, pl, 'thwart');
    check('닉 퓨리 — 위협 2 제거', th0 - MC.resolveScheme(G,'main').threat === 2);
  }
  // 피해 선택
  {
    const G = mk(371); const pl = G.players[0]; pl.form='hero';
    const v0 = G.villain.hp;
    playFury(G, pl, 'damage', G.villain.uid);
    check('닉 퓨리 — 빌런 4 피해', v0 - G.villain.hp === 4);
  }
  // 드로우 선택
  {
    const G = mk(372); const pl = G.players[0]; pl.form='hero';
    const d0 = pl.deck.length;
    playFury(G, pl, 'draw');
    check('닉 퓨리 — 카드 3장 드로우', d0 - pl.deck.length === 3);
  }
  // 라운드 종료 시 버림
  {
    const G = mk(373); const pl = G.players[0]; pl.form='hero';
    const nf = playFury(G, pl, 'draw');
    check('닉 퓨리 — 등장 후 전장에 있음', pl.playArea.allies.includes(nf));
    MC.fireHook(G, 'endOfRound', {});
    check('닉 퓨리 — 라운드 종료 시 버림', !pl.playArea.allies.includes(nf) && pl.discard.includes(nf));
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01084, 🧠멘탈, Cost 4, S.H.I.E.L.D.+Spy, unique)
  check('닉 퓨리 데이터 — Cost 4 / 🧠멘탈 / 2-2-3 / S.H.I.E.L.D.+Spy / unique', (()=>{
    const d=MC.CARDS['nick-fury'];
    return d.cost===4 && (d.resources||{}).mental===1 && d.attack===2 && d.thwart===2 && d.hp===3 && d.traits.includes('s.h.i.e.l.d.') && d.traits.includes('spy') && d.unique===true;
  })());
}

/* 기본 01085 — 비상사태(emergency): 빌런 스킴 위협 1 감소 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const playEmergency = (G, pl) => {
    const em = MC.makeInstance(G,'emergency',{}); em.ownerUid=pl.uid; pl.hand.push(em);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:em.uid, payment:[{kind:'hand', uid:en.uid}] });
  };
  // preventNextThreat 예약 + 위협 배치 1 감소
  {
    const G = mk(380); const pl = G.players[0]; pl.form='hero';
    playEmergency(G, pl);
    check('비상사태 — preventNextThreat 1 예약', G.preventNextThreat === 1);
    MC.resolveScheme(G,'main').threat = 0;
    MC.placeThreat(G, 'main', 3);
    check('비상사태 — 위협 3 배치가 2로 감소', MC.resolveScheme(G,'main').threat === 2);
  }
  // 이미 놓인 위협은 제거 안 함 (배치 방지만)
  {
    const G = mk(381); const pl = G.players[0]; pl.form='hero';
    MC.resolveScheme(G,'main').threat = 5;
    playEmergency(G, pl);
    check('비상사태 — 이미 놓인 위협은 그대로 (5 유지)', MC.resolveScheme(G,'main').threat === 5);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01085, ⚡에너지, Cost 0, event, Thwart)
  check('비상사태 데이터 — Cost 0 / ⚡에너지 / event / Thwart', (()=>{
    const d=MC.CARDS['emergency'];
    return d.cost===0 && (d.resources||{}).energy===1 && d.type==='event' && d.traits.includes('thwart');
  })());
}

/* 기본 01086 — 응급처치(first-aid): 아무 캐릭터 2 회복 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const playFA = (G, pl, targetUid) => {
    const fa = MC.makeInstance(G,'first-aid',{}); fa.ownerUid=pl.uid; pl.hand.push(fa);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:fa.uid, targets:[targetUid], payment:[{kind:'hand', uid:en.uid}] });
  };
  // 동료 2 회복
  {
    const G = mk(390); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.hp=1; ally.maxHp=5; pl.playArea.allies.push(ally);
    playFA(G, pl, ally.uid);
    check('응급처치 — 동료 2 회복 (1→3)', ally.hp === 3);
  }
  // 히어로 회복
  {
    const G = mk(391); const pl = G.players[0]; pl.form='hero';
    const face = MC.heroFace(G, pl);
    pl.hp = 5; pl.maxHp = face.hp || 10;
    playFA(G, pl, pl.uid);
    check('응급처치 — 히어로 2 회복 (5→7)', pl.hp === 7);
  }
  // maxHp 초과 안 함
  {
    const G = mk(392); const pl = G.players[0]; pl.form='hero';
    const ally = MC.makeInstance(G,'tigra-ally',{}); ally.ownerUid=pl.uid; ally.hp=2; ally.maxHp=3; pl.playArea.allies.push(ally);
    playFA(G, pl, ally.uid);
    check('응급처치 — maxHp 초과 안 함 (2→3)', ally.hp === 3);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01086, 🧠멘탈, Cost 1, event)
  check('응급처치 데이터 — Cost 1 / 🧠멘탈 / event', (()=>{
    const d=MC.CARDS['first-aid'];
    return d.cost===1 && (d.resources||{}).mental===1 && d.type==='event';
  })());
}

/* 기본 01087 — 강타(haymaker): 적에게 3 피해 (히어로 행동) */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  const playHM = (G, pl, targetUid) => {
    const hm = MC.makeInstance(G,'haymaker',{}); hm.ownerUid=pl.uid; pl.hand.push(hm);
    const pay = [];
    for (let i = 0; i < 2; i++){ const p = MC.makeInstance(G,'genius',{}); p.ownerUid=pl.uid; pl.hand.push(p); pay.push({kind:'hand', uid:p.uid}); }
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:hm.uid, targets:[targetUid], payment:pay });
  };
  // 빌런 3 피해
  {
    const G = mk(400); const pl = G.players[0]; pl.form='hero';
    const v0 = G.villain.hp;
    playHM(G, pl, G.villain.uid);
    check('강타 — 빌런 3 피해', v0 - G.villain.hp === 3);
  }
  // 하수인 3 피해
  {
    const G = mk(401); const pl = G.players[0]; pl.form='hero';
    const m = MC.makeInstance(G,'shocker',{kind:'minion'}); m.type='minion'; m.hp=5; m.maxHp=5; m.engagedWith=pl.uid; pl.engagedMinions.push(m);
    playHM(G, pl, m.uid);
    check('강타 — 하수인 3 피해 (5→2)', m.hp === 2);
  }
  // 알터에고 상태에서 사용 불가
  {
    const G = mk(402); const pl = G.players[0]; pl.form='alter-ego';
    const hm = MC.makeInstance(G,'haymaker',{}); hm.ownerUid=pl.uid; pl.hand.push(hm);
    let blocked = false;
    try { MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:hm.uid, targets:[G.villain.uid], payment:[] }); }
    catch(e){ blocked = true; }
    check('강타 — 알터에고 사용 불가', blocked);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01087, ⚡에너지, Cost 2, event, Attack)
  check('강타 데이터 — Cost 2 / ⚡에너지 / event / Attack', (()=>{
    const d=MC.CARDS['haymaker'];
    return d.cost===2 && (d.resources||{}).energy===1 && d.type==='event' && d.traits.includes('attack');
  })());
}

/* 기본 01088~01090 — 자원 카드 3종(energy/genius/strength): 자원 2개 제공 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 자원 아이콘 확인
  {
    const G = mk(410);
    const en = MC.makeInstance(G,'energy',{});
    const ge = MC.makeInstance(G,'genius',{});
    const st = MC.makeInstance(G,'strength',{});
    check('에너지 — ⚡ 아이콘 2개', MC.resourceIconsOf(en).energy === 2);
    check('천재 — 🧠 아이콘 2개', MC.resourceIconsOf(ge).mental === 2);
    check('힘 — 💪 아이콘 2개', MC.resourceIconsOf(st).physical === 2);
  }
  // todoFx 해제 확인
  check('자원 카드 3종 — fx 등록됨 (todoFx 해제)', (()=>{
    return !MC.CARDS['energy'].todoFx && !MC.CARDS['genius'].todoFx && !MC.CARDS['strength'].todoFx;
  })());
  // 실제 결제 활용 — 에너지 카드 하나로 Cost 2 카드 지불
  {
    const G = mk(411); const pl = G.players[0]; pl.form='hero';
    const hm = MC.makeInstance(G,'haymaker',{}); hm.ownerUid=pl.uid; pl.hand.push(hm);   // Cost 2
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);   // ⚡2
    const v0 = G.villain.hp;
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:hm.uid, targets:[G.villain.uid], payment:[{kind:'hand', uid:en.uid}] });
    check('자원 카드 — 에너지 1장으로 Cost 2 결제', v0 - G.villain.hp === 3);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01088~90, deckLimit 1)
  check('자원 카드 데이터 — resource / deckLimit 1', (()=>{
    return ['energy','genius','strength'].every(c => MC.CARDS[c].type==='resource' && MC.CARDS[c].deckLimit===1);
  })());
}

/* 기본 01091 — 어벤져스 맨션(avengers-mansion): 소진 → 1장 드로우 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 소진하며 1장 드로우
  {
    const G = mk(420); const pl = G.players[0]; pl.form='hero';
    const am = MC.makeInstance(G,'avengers-mansion',{}); am.ownerUid=pl.uid; pl.playArea.supports.push(am);
    const d0 = pl.deck.length;
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:am.uid });
    check('어벤져스 맨션 — 1장 드로우', d0 - pl.deck.length === 1);
    check('어벤져스 맨션 — 소진됨', am.exhausted === true);
  }
  // 소진 상태에서 재사용 불가
  {
    const G = mk(421); const pl = G.players[0]; pl.form='hero';
    const am = MC.makeInstance(G,'avengers-mansion',{}); am.ownerUid=pl.uid; am.exhausted=true; pl.playArea.supports.push(am);
    let blocked = false;
    try { MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:am.uid }); }
    catch(e){ blocked = /소진/.test(e.message); }
    check('어벤져스 맨션 — 소진 상태 재사용 불가', blocked);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01091, 🧠멘탈, Cost 4, support, Avenger+Location)
  check('어벤져스 맨션 데이터 — Cost 4 / 🧠멘탈 / support / Avenger+Location', (()=>{
    const d=MC.CARDS['avengers-mansion'];
    return d.cost===4 && (d.resources||{}).mental===1 && d.type==='support' && d.traits.includes('avenger') && d.traits.includes('location');
  })());
}

/* 기본 01092 — 헬리캐리어(helicarrier): 다음 카드 비용 1 감소 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 할인 예약 + 소진
  {
    const G = mk(430); const pl = G.players[0]; pl.form='hero';
    const hc = MC.makeInstance(G,'helicarrier',{}); hc.ownerUid=pl.uid; pl.playArea.supports.push(hc);
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:hc.uid });
    check('헬리캐리어 — 할인 1 예약', pl.nextCardDiscount === 1);
    check('헬리캐리어 — 소진됨', hc.exhausted === true);
  }
  // Cost 3 카드를 자원 2로 결제 (할인 -1)
  {
    const G = mk(431); const pl = G.players[0]; pl.form='hero';
    const hc = MC.makeInstance(G,'helicarrier',{}); hc.ownerUid=pl.uid; pl.playArea.supports.push(hc);
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:hc.uid });
    const mt = MC.makeInstance(G,'med-team',{}); mt.ownerUid=pl.uid; pl.hand.push(mt);   // Cost 3
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);   // ⚡2
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:mt.uid, payment:[{kind:'hand', uid:en.uid}] });
    check('헬리캐리어 — Cost 3을 자원 2로 결제 성공', pl.playArea.supports.some(c => c.defCode==='med-team'));
    check('헬리캐리어 — 할인 소비됨', pl.nextCardDiscount === 0);
  }
  // 할인은 한 장만 적용 (두 번째 카드는 정상 비용)
  {
    const G = mk(432); const pl = G.players[0]; pl.form='hero';
    pl.nextCardDiscount = 1;
    const mt = MC.makeInstance(G,'med-team',{}); mt.ownerUid=pl.uid; pl.hand.push(mt);
    const en = MC.makeInstance(G,'energy',{}); en.ownerUid=pl.uid; pl.hand.push(en);
    MC.dispatch(G, { type:'playCard', player:pl.uid, cardUid:mt.uid, payment:[{kind:'hand', uid:en.uid}] });
    check('헬리캐리어 — 첫 카드 후 할인 0', pl.nextCardDiscount === 0);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01092, 💪피지컬, Cost 3, support, Location+S.H.I.E.L.D.)
  check('헬리캐리어 데이터 — Cost 3 / 💪피지컬 / support / Location+S.H.I.E.L.D.', (()=>{
    const d=MC.CARDS['helicarrier'];
    return d.cost===3 && (d.resources||{}).physical===1 && d.type==='support' && d.traits.includes('location') && d.traits.includes('s.h.i.e.l.d.');
  })());
}

/* 기본 01093 — 끈기(tenacity): 피지컬 지불 + 자신 버림 → 히어로 준비 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 피지컬 지불 → 히어로 준비 + 자신 버림
  {
    const G = mk(440); const pl = G.players[0]; pl.form='hero';
    const tn = MC.makeInstance(G,'tenacity',{}); tn.ownerUid=pl.uid; pl.playArea.upgrades.push(tn);
    pl.exhausted = true;
    const str = MC.makeInstance(G,'strength',{}); str.ownerUid=pl.uid; pl.hand.push(str);
    MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:tn.uid, payment:[{kind:'hand', uid:str.uid}] });
    check('끈기 — 히어로 준비 (소진 해제)', pl.exhausted === false);
    check('끈기 — 자신 버림', !pl.playArea.upgrades.includes(tn) && pl.discard.includes(tn));
  }
  // 피지컬 없이 발동 불가
  {
    const G = mk(441); const pl = G.players[0]; pl.form='hero';
    const tn = MC.makeInstance(G,'tenacity',{}); tn.ownerUid=pl.uid; pl.playArea.upgrades.push(tn);
    let blocked = false;
    try { MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:tn.uid, payment:[] }); }
    catch(e){ blocked = /피지컬|physical|자원/.test(e.message); }
    check('끈기 — 피지컬 없이 발동 불가', blocked);
  }
  // 알터에고에서 발동 불가 (form:hero)
  {
    const G = mk(442); const pl = G.players[0]; pl.form='alter-ego';
    const tn = MC.makeInstance(G,'tenacity',{}); tn.ownerUid=pl.uid; pl.playArea.upgrades.push(tn);
    const str = MC.makeInstance(G,'strength',{}); str.ownerUid=pl.uid; pl.hand.push(str);
    let blocked = false;
    try { MC.dispatch(G, { type:'useCardAbility', player:pl.uid, cardUid:tn.uid, payment:[{kind:'hand', uid:str.uid}] }); }
    catch(e){ blocked = /형태|hero|히어로/.test(e.message); }
    check('끈기 — 알터에고 발동 불가', blocked);
  }
  // 데이터 교차검증 — 공식 값 (Core Set 01093, ⚡에너지, Cost 2, upgrade, Condition)
  check('끈기 데이터 — Cost 2 / ⚡에너지 / upgrade / Condition', (()=>{
    const d=MC.CARDS['tenacity'];
    return d.cost===2 && (d.resources||{}).energy===1 && d.type==='upgrade' && d.traits.includes('condition');
  })());
}

/* 라이노 세트 — 빌런 3단계 (01094~96): 스탯 + 단계별 When Revealed */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 1단계 스탯 (특수 없음)
  {
    const G = mk(450);
    check('라이노 1단계 — HP 14 (1인) / ATK 2 / SCH 1', G.villain.hp === 14 && G.villain.attack === 2 && G.villain.scheme === 1);
    check('라이노 1단계 — stage 1', MC.cardDef(G.villain.defCode).stage === 1);
  }
  // 2단계 전환 — 스탯 + 침입&약탈 사이드스킴 공개
  {
    const G = mk(451);
    const ss0 = G.sideSchemes.length;
    G.villain.hp = 0; MC.advanceVillainStage(G);
    check('라이노 2단계 — HP 15 / ATK 3', G.villain.hp === 15 && G.villain.attack === 3);
    check('라이노 2단계 — 침입&약탈 사이드스킴 공개', G.sideSchemes.length - ss0 === 1 && G.sideSchemes.some(s => s.defCode==='breakin-and-takin'));
  }
  // 3단계 전환 — 스탯 + Toughness + 전체 히어로 기절
  {
    const G = mk(452); const pl = G.players[0];
    G.villain.hp = 0; MC.advanceVillainStage(G);  // 1→2
    G.villain.hp = 0; MC.advanceVillainStage(G);  // 2→3
    check('라이노 3단계 — HP 16 / ATK 4', G.villain.hp === 16 && G.villain.attack === 4);
    check('라이노 3단계 — Toughness (tough 획득)', (G.villain.status.tough||0) >= 1);
    check('라이노 3단계 — 모든 히어로 기절', (pl.status.stunned||0) >= 1);
  }
  // 메인스킴 데이터 교차검증 (01097b: 위협 0 시작, 영웅당 7, 가속 1)
  check('라이노 메인스킴 — 위협 0시작 / 영웅당 7 / 가속 1', (()=>{
    const d=MC.cardDef('01097b');
    return d.baseThreat===0 && d.maxThreatPerPlayer===7 && d.accelIcons===1;
  })());
}

/* 라이노 세트 — 빌런 3단계(01094~96): 단계별 스탯 + When Revealed 능력 */
{
  const mk = (seed) => {
    const deck = FIXTURE_DECK.slice();
    const G=MC.makeGameState({seed,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
    MC.setupGame(G);
    return G;
  };
  // 1단계 스탯 (특수 없음)
  {
    const G = mk(450);
    check('라이노 1단계 — HP 14 / ATK 2 / SCH 1', G.villain.hp === 14 && G.villain.attack === 2 && G.villain.scheme === 1);
  }
  // 2단계 전환 — 침입&약탈 사이드스킴 공개
  // (공개가 정식 파이프라인을 타므로, 히어로 폼이면 인터럽트 정지점이 뜰 수 있다 → 패스로 해소)
  {
    const G = mk(451); const pl = G.players[0]; pl.form='hero';
    const ss0 = G.sideSchemes.length;
    G.villain.hp = 0; MC.advanceVillainStage(G);
    if (G.pending && G.pending.kind === 'revealInterrupt') MC.resolveRevealInterrupt(G, pl.uid, null);
    check('라이노 2단계 — HP 15 / ATK 3', G.villain.hp === 15 && G.villain.attack === 3);
    check('라이노 2단계 — 침입&약탈 사이드스킴 공개', G.sideSchemes.length === ss0 + 1 && G.sideSchemes.some(s => s.defCode === 'breakin-and-takin'));
  }
  // 3단계 전환 — Toughness + 전체 히어로 기절
  {
    const G = mk(452); const pl = G.players[0]; pl.form='hero';
    G.villain.hp = 0; MC.advanceVillainStage(G);   // → 2단계
    G.villain.hp = 0; MC.advanceVillainStage(G);   // → 3단계
    check('라이노 3단계 — HP 16 / ATK 4', G.villain.hp === 16 && G.villain.attack === 4);
    check('라이노 3단계 — Toughness 획득', (G.villain.status.tough||0) >= 1);
    check('라이노 3단계 — 모든 히어로 기절', (pl.status.stunned||0) >= 1);
  }
  // 메인스킴 데이터 교차검증 (01097b: 위협 0 시작, 영웅당 7, 가속 1)
  check('라이노 메인스킴 — baseThreat 0 / perPlayer 7 / accel 1', (()=>{
    const d=MC.cardDef('01097b');
    return d.baseThreat===0 && d.maxThreatPerPlayer===7 && d.accelIcons===1;
  })());
}

/* 장갑 라이노 슈트(rhino-suit): 피해 흡수 → 5 누적 시 파괴 */
{
  const deck = FIXTURE_DECK.slice();
  const G=MC.makeGameState({seed:560,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const suit = MC.makeInstance(G, 'rhino-suit', {});
  MC.attachTo(G, suit, G.villain);
  const hp0 = G.villain.hp;
  MC.applyDamage(G, G.villain, 3, {});
  check('라이노 슈트 — 피해 3 흡수 (본체 무피해)', G.villain.hp === hp0 && suit.damageHere === 3);
  MC.applyDamage(G, G.villain, 3, {});
  check('라이노 슈트 — 5 누적 시 파괴 (본체 무피해)', suit._destroyed === true && G.villain.hp === hp0);
  check('라이노 슈트 — 파괴 후 부착 목록에서 제거', !G.villain.attachments.includes(suit));
  check('라이노 슈트 — fxSuitBreak VFX 힌트 설정', !!G.fxSuitBreak);
  check('라이노 슈트 — fx 등록 완료(todoFx 해제)', !MC.cardDef('rhino-suit').todoFx);
}

/* 돌진(charge): ATK+3 부착 / 공격 과잉살상(동료 초과→컨트롤러) / 공격 후 버림 */
{
  const deck = FIXTURE_DECK.slice();
  const G=MC.makeGameState({seed:561,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const atk0 = G.villain.attack;
  const chg = MC.makeInstance(G, 'charge', {});
  MC.attachTo(G, chg, G.villain);
  check('돌진 — 부착 시 ATK+3', G.villain.attack === atk0 + 3);
  // 동료(HP 2) 방어 준비 + 부스트 배제(조우덱 비움 → boost null)
  const ally = MC.makeInstance(G, 'daredevil', { ownerUid: pl.uid });
  ally.hp = 2; pl.playArea.allies.push(ally);
  G.encounterDeck = []; G.encounterDiscard = [];
  MC.enemyActivation(G, G.villain, pl);
  check('돌진 — 공격 시 과잉살상 부여', !!(G.pending && G.pending.overkill));
  check('돌진 — 공격 후 버림 예약', !!(G.pending.discardAfterAttack && G.pending.discardAfterAttack.includes(chg.uid)));
  const heroHp0 = pl.hp;
  MC.dispatch(G, { type:'resolveDefense', player:'P0', defender: ally.uid });
  // total = ATK 5 (2+3, 부스트 없음), 동료 HP 2 → 초과 3이 컨트롤러에게
  check('돌진 — 동료 초과 피해 3 → 컨트롤러', pl.hp === heroHp0 - 3);
  check('돌진 — 공격 종료 후 조우 버림', G.encounterDiscard.includes(chg) && !(G.villain.attachments||[]).includes(chg));
  check('돌진 — 버림 후 ATK 원복', G.villain.attack === atk0);
  check('돌진 — fxAttachSpent 힌트(defCode=charge)', !!(G.fxAttachSpent && G.fxAttachSpent.defCode === 'charge'));
  // 강인 동료: 피해 무효 → 초과 없음
  const chg2 = MC.makeInstance(G, 'charge', {});
  MC.attachTo(G, chg2, G.villain);
  const ally2 = MC.makeInstance(G, 'daredevil', { ownerUid: pl.uid });
  ally2.hp = 1; ally2.status = ally2.status || {}; ally2.status.tough = 1;
  pl.playArea.allies.push(ally2);
  G.encounterDeck = []; G.encounterDiscard = [];
  const heroHp1 = pl.hp;
  MC.enemyActivation(G, G.villain, pl);
  MC.dispatch(G, { type:'resolveDefense', player:'P0', defender: ally2.uid });
  check('돌진 — 강인 동료 방어 시 초과 없음', pl.hp === heroHp1 && ally2.hp === 1);
  // 데이터 교차검증 (공식 JSON: attack 3 / boost 2)
  check('돌진 — 데이터 교차검증 (ATK+3 / 부스트 2 / fx 등록)', (()=>{
    const d=MC.cardDef('charge');
    return d.attachStats && d.attachStats.attack===3 && d.boost===2 && !d.todoFx;
  })());
}

/* 저지 대상 지정: 사이드스킴 저지 / 가드≠저지 제한(순찰만) / 이벤트 targetScheme / peakThreat */
{
  const deck = FIXTURE_DECK.slice();
  const G=MC.makeGameState({seed:562,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  // 사이드스킴 수동 배치
  const ss = MC.makeInstance(G, 'breakin-and-takin', {});
  ss.threat = 5; ss.peakThreat = 5; ss.isMain = false;
  G.sideSchemes.push(ss);
  const mainT0 = G.mainScheme.threat;
  const thw = MC.statOf(G, pl, 'thwart');
  MC.dispatch(G, { type:'basicThwart', player:'P0', scheme: ss.uid });
  check('저지 대상 — 사이드스킴 저지 (메인 불변)', ss.threat === 5 - thw && G.mainScheme.threat === mainT0);
  check('저지 대상 — peakThreat 유지 (제거로 감소 안 함)', ss.peakThreat === 5);
  // 가드 하수인 교전 중에도 메인 스킴 저지는 가능 (공식 룰: 가드=빌런 공격만 제한)
  pl.exhausted = false;
  const guard = MC.makeInstance(G, 'hydra-mercenary', {});
  guard.guard = true; guard.hp = 3; pl.engagedMinions.push(guard);
  let mainOk = true;
  try { MC.dispatch(G, { type:'basicThwart', player:'P0', scheme:'main' }); } catch(e){ mainOk = false; }
  check('룰 정정 — 가드 교전 중 메인 스킴 저지 허용', mainOk && G.mainScheme.threat === Math.max(0, mainT0 - thw));
  // 순찰(Patrol) 하수인 교전 중엔 메인 저지 불가, 사이드는 가능
  pl.exhausted = false;
  guard.patrol = true;
  let patrolBlocked = false;
  try { MC.dispatch(G, { type:'basicThwart', player:'P0', scheme:'main' }); } catch(e){ patrolBlocked = true; }
  check('순찰 — 교전 중 메인 스킴 저지 차단', patrolBlocked);
  const ssT1 = ss.threat;
  MC.dispatch(G, { type:'basicThwart', player:'P0', scheme: ss.uid });
  check('순찰 — 사이드스킴 저지는 허용', ss.threat === Math.max(0, ssT1 - thw));
  // 저지 이벤트 targetScheme: 정의를 위해!(3 제거)를 사이드스킴에
  pl.engagedMinions = [];
  ss.threat = 4; ss.peakThreat = Math.max(ss.peakThreat, 4);
  const ev = MC.makeInstance(G, 'for-justice', { ownerUid: pl.uid });
  const payc = MC.makeInstance(G, 'strength', { ownerUid: pl.uid });
  pl.hand.push(ev, payc);
  const mainT1 = G.mainScheme.threat;
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid: ev.uid,
                   payment: [{ kind:'hand', uid: payc.uid }], targetScheme: ss.uid });
  check('저지 이벤트 — targetScheme으로 사이드스킴 제거', ss.threat === 1 && G.mainScheme.threat === mainT1);
  // peakThreat 상승 추적: 위협 재배치 시 분모 갱신
  MC.placeThreat(G, ss.uid, 6);
  check('사이드스킴 — peakThreat 상승 추적', ss.threat === 7 && ss.peakThreat === 7);
}

/* 강화된 상아 뿔(horn-attack): ATK+1 부착 / 히어로 행동 💪×3 → 제거 */
{
  const deck = FIXTURE_DECK.slice();
  const G=MC.makeGameState({seed:563,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  const atk0 = G.villain.attack;
  const horn = MC.makeInstance(G, 'horn-attack', {});
  MC.attachTo(G, horn, G.villain);
  check('상아 뿔 — 부착 시 ATK+1', G.villain.attack === atk0 + 1);
  // 알터에고 폼에선 사용 불가
  pl.form = 'alter-ego';
  const p1 = MC.makeInstance(G, 'strength', { ownerUid: pl.uid });
  const p2 = MC.makeInstance(G, 'combat-training', { ownerUid: pl.uid });
  pl.hand.push(p1, p2);
  let aeBlocked = false;
  try { MC.dispatch(G, { type:'useCardAbility', player:'P0', cardUid: horn.uid,
        payment:[{kind:'hand',uid:p1.uid},{kind:'hand',uid:p2.uid}] }); } catch(e){ aeBlocked = true; }
  check('상아 뿔 — 알터에고 폼 사용 불가', aeBlocked && (G.villain.attachments||[]).includes(horn));
  // 히어로 폼 + 💪×3 (strength=2 + combat-training=1) → 제거
  pl.form = 'hero';
  MC.dispatch(G, { type:'useCardAbility', player:'P0', cardUid: horn.uid,
                   payment:[{kind:'hand',uid:p1.uid},{kind:'hand',uid:p2.uid}] });
  check('상아 뿔 — 💪×3 지출로 제거 (조우 버림)', G.encounterDiscard.includes(horn) && !(G.villain.attachments||[]).includes(horn));
  check('상아 뿔 — 제거 후 ATK 원복', G.villain.attack === atk0);
  check('상아 뿔 — fxAttachSpent 힌트(defCode=horn-attack)', !!(G.fxAttachSpent && G.fxAttachSpent.defCode === 'horn-attack'));
  check('상아 뿔 — 데이터 교차검증 (ATK+1 / 부스트 2 / fx 등록)', (()=>{
    const d=MC.cardDef('horn-attack');
    return d.attachStats && d.attachStats.attack===1 && d.boost===2 && !d.todoFx;
  })());
}

/* 하이드라 용병(hydra-mercenary): Guard — 교전 중 빌런 공격 불가 */
{
  const deck = FIXTURE_DECK.slice();
  const G=MC.makeGameState({seed:564,players:[{heroCode:'01001a',deckCodes:deck}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const merc = MC.makeInstance(G, 'hydra-mercenary', {});
  check('용병 — Guard 플래그 인스턴스 반영', merc.guard === true);
  check('용병 — 스탯 (ATK1/SCH0/HP3)', merc.attack===1 && merc.scheme===0 && merc.hp===3);
  merc.engagedWith = pl.uid; pl.engagedMinions.push(merc);
  // Guard 교전 중 빌런 공격 차단
  let villBlocked = false;
  try { MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid: G.villain.uid }); } catch(e){ villBlocked = true; }
  check('용병 — Guard 교전 중 빌런 공격 차단', villBlocked && G.villain.hp === G.villain.maxHp);
  // 용병 자체는 공격 가능 (스파이더맨 ATK 2 → HP 3-2=1)
  pl.exhausted = false;
  const hpBefore = merc.hp, atk = MC.statOf(G, pl, 'attack');
  MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid: merc.uid });
  check('용병 — 자체 공격 허용', merc.hp === hpBefore - atk);
  // Guard는 저지는 막지 않음 (공식 룰: 순찰만 저지 제한)
  pl.exhausted = false;
  const mainT0 = G.mainScheme.threat;
  const thw = MC.statOf(G, pl, 'thwart');
  MC.dispatch(G, { type:'basicThwart', player:'P0', scheme:'main' });
  check('용병 — Guard 교전 중 저지는 허용', G.mainScheme.threat === Math.max(0, mainT0 - thw));
  check('용병 — 데이터 교차검증 (Guard / 부스트 1 / fx 등록)', (()=>{
    const d=MC.cardDef('hydra-mercenary');
    return d.guard === true && d.boost===1 && !d.todoFx;
  })());
}

/* 가드 키워드 일괄 등록 감사 (v132): 18+9장 플래그 정합성 + piercing 미니언 공격 */
{
  const G=MC.makeGameState({seed:565,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G);
  // 대표 카드 플래그 정합성
  const expect = {
    'hydra-soldier':{guard:true}, 'servant-bot':{guard:true,patrol:true},
    'the-sleeper':{guard:true,retaliate:1,toughness:true}, 'armored-guard':{guard:true,toughness:true},
    'kree-lieutenant':{guard:true,stalwart:true}, 'lady-deathstrike':{quickstrike:true},
    'badoon-lieutenant':{patrol:true}, 'modok':{retaliate:2}, 'proxima-midnight-minion':{piercing:true},
    'omega-red':{retaliate:1}, 'nebula-nemesis':{retaliate:2},
  };
  let allOk = true;
  for (const [code, flags] of Object.entries(expect)){
    const d = MC.cardDef(code);
    for (const [k, v] of Object.entries(flags)) if (d[k] !== v){ allOk = false; console.log('  플래그 불일치:', code, k, d[k], '≠', v); }
  }
  check('가드 감사 — 대표 11장 키워드 플래그 정합', allOk);
  // 오탐 카드는 guard 없어야 (설명 예시로 언급된 것들)
  check('가드 감사 — 오탐 제외 (ebony-maw guard 없음)', !MC.cardDef('ebony-maw-minion').guard);
  check('가드 감사 — 오탐 제외 (lady-deathstrike guard 없음)', !MC.cardDef('lady-deathstrike').guard);
  // 인스턴스 반영: makeInstance가 guard/retaliate/toughness 복사
  const sleeper = MC.makeInstance(G, 'the-sleeper', {});
  check('가드 감사 — 인스턴스 반영 (the-sleeper: guard+retal+tough)',
    sleeper.guard===true && sleeper.retaliate===1 && sleeper.status.tough===1);
  // piercing 미니언 공격: 강인 방어자 무시
  const pl=G.players[0]; pl.form='hero';
  const prox = MC.makeInstance(G, 'proxima-midnight-minion', {});
  prox.engagedWith = pl.uid; pl.engagedMinions.push(prox);
  pl.status.tough = 1;   // 히어로에 강인 부여
  const hp0 = pl.hp;
  MC.enemyActivation(G, prox, pl);
  G.pending.boostCard = undefined;   // 부스트 변수 제거 (정확 피해 검증)
  G.encounterDeck = [];
  MC.dispatch(G, { type:'resolveDefense', player:'P0', defender:'none' });
  check('piercing 미니언 — 강인 무시하고 피해 (ATK 3)', pl.hp === hp0 - prox.attack && (pl.status.tough||0) > 0);
  // 전수 재감사: 가드 명시 but 플래그 없는 하수인 0장 (설명 예시 제외)
  let miss = 0;
  for (const code in MC.CARDS){
    const d = MC.CARDS[code]; if (d.type !== 'minion') continue;
    const core = (d.textKo||'').split('\n').filter(l=>{const t=l.trim();return t && !t.startsWith('※') && !t.startsWith('-') && !t.startsWith('•') && !t.startsWith('*') && !t.includes('비교') && !t.includes('X)');}).join(' ');
    if (/호위|경비|경호원|가드/.test(core) && !d.guard && code !== 'lady-deathstrike') miss++;
  }
  check('가드 감사 — 전수 재조사 잔여 누락 0장', miss === 0);
}

/* 하수인 대사/공격 이펙트 시스템: fxMinionAttack 힌트 + 하이드라 용병 대사 세트 */
{
  const G=MC.makeGameState({seed:566,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const merc = MC.makeInstance(G, 'hydra-mercenary', {});
  merc.engagedWith = pl.uid; pl.engagedMinions.push(merc);
  // 하수인 활성화 → fxMinionAttack 힌트 생성
  MC.enemyActivation(G, merc, pl);
  check('하수인 공격 힌트 — fxMinionAttack 생성 (defCode)', !!(G.fxMinionAttack && G.fxMinionAttack.defCode === 'hydra-mercenary'));
  check('하수인 공격 힌트 — attackerUid/targetUid 기록', G.fxMinionAttack.attackerUid === merc.uid && G.fxMinionAttack.targetUid === pl.uid);
  check('하수인 공격 힌트 — seq 증가', G.fxMinionAttack.seq > 0);
  // 빌런 공격은 fxMinionAttack 안 만듦
  G.fxMinionAttack = null; G.pending = null; pl.exhausted = false; pl.form = 'hero';
  MC.enemyActivation(G, G.villain, pl);
  check('하수인 공격 힌트 — 빌런 공격 시엔 미생성', !G.fxMinionAttack);
  // 데이터: vfx.attack 연출 참조 등록 (VFX 인덱스 실체는 test_vfx_index가 검증)
  check('하이드라 용병 — vfx.attack 참조 (hydraGunfire)', (()=>{
    const d=MC.cardDef('hydra-mercenary');
    return d.vfx && d.vfx.attack === 'hydraGunfire';
  })());
}

/* 01102 샌드맨(sandman): Toughness 하수인 + 모래 공격 이펙트/대사 */
{
  const G=MC.makeGameState({seed:567,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const sand = MC.makeInstance(G, 'sandman', {});
  check('샌드맨 — 스탯 (ATK3/SCH2/HP4)', sand.attack===3 && sand.scheme===2 && sand.hp===4);
  check('샌드맨 — Toughness로 tough 상태 등장', sand.status.tough === 1);
  check('샌드맨 — unique 플래그', sand.unique === true);
  check('샌드맨 — Criminal+Elite 트레잇', sand.traits.includes('criminal') && sand.traits.includes('elite'));
  // 강인 흡수: 첫 공격은 tough가 흡수 (피해 0), tough 소진
  sand.engagedWith = pl.uid; pl.engagedMinions.push(sand);
  const atk = MC.statOf(G, pl, 'attack');
  MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid: sand.uid });
  check('샌드맨 — 강인 첫 피해 흡수 (HP 유지, tough 소진)', sand.hp === 4 && (sand.status.tough||0) === 0);
  // 다음 공격은 정상 피해
  pl.exhausted = false;
  MC.dispatch(G, { type:'basicAttack', player:'P0', targetUid: sand.uid });
  check('샌드맨 — 강인 소진 후 정상 피해', sand.hp === 4 - atk);
  // 공격 힌트 + vfx 참조
  pl.exhausted = false;
  MC.enemyActivation(G, sand, pl);
  check('샌드맨 — 공격 힌트 fxMinionAttack (defCode)', !!(G.fxMinionAttack && G.fxMinionAttack.defCode === 'sandman'));
  check('샌드맨 — vfx.attack 참조 (sandBlast)', (()=>{const d=MC.cardDef('sandman');return d.vfx && d.vfx.attack === 'sandBlast';})());
  check('샌드맨 — 데이터 교차검증 (Toughness/부스트2/fx 등록)', (()=>{
    const d=MC.cardDef('sandman'); return d.toughness===true && d.boost===2 && !d.todoFx;
  })());
}

/* 01103 쇼커(shocker): whenRevealed 각 히어로 1피해 + 진동 공격 이펙트/대사 */
{
  const G=MC.makeGameState({seed:568,players:[
    {heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()},
    {heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()},
  ],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const p0=G.players[0], p1=G.players[1];
  check('쇼커 — 스탯 (ATK2/SCH1/HP3)', (()=>{const d=MC.cardDef('shocker');return d.attack===2&&d.scheme===1&&d.hp===3;})());
  check('쇼커 — unique 플래그', MC.cardDef('shocker').unique === true);
  // whenRevealed: 각 히어로 1피해 (2인)
  const hp0 = p0.hp, hp1 = p1.hp;
  const sh = MC.makeInstance(G, 'shocker', {});
  MC.fireCardHook(G, sh, 'whenRevealed', { player: p0, self: sh, card: sh });
  check('쇼커 — whenRevealed 각 히어로 1피해', p0.hp === hp0 - 1 && p1.hp === hp1 - 1);
  // 공격 힌트 + vfx 참조
  p0.form = 'hero'; sh.engagedWith = p0.uid; p0.engagedMinions.push(sh);
  MC.enemyActivation(G, sh, p0);
  check('쇼커 — 공격 힌트 fxMinionAttack (defCode)', !!(G.fxMinionAttack && G.fxMinionAttack.defCode === 'shocker'));
  check('쇼커 — vfx.attack 참조 (vibroShock)', (()=>{const d=MC.cardDef('shocker');return d.vfx && d.vfx.attack === 'vibroShock';})());
  check('쇼커 — 데이터 교차검증 (whenRevealed/부스트2/fx 등록)', (()=>{
    const d=MC.cardDef('shocker'); return d.whenRevealed==='runCardEffects' && d.whenRevealedEffects && d.whenRevealedEffects[0].fx==='damageEachHero' && d.boost===2 && !d.todoFx;
  })());
}

/* 각 히어로 피해 이펙트 힌트 (fxDamageEachHero): 쇼커 공개 시 등 광역 피해 연출 배선 */
{
  const G=MC.makeGameState({seed:569,players:[
    {heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()},
    {heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()},
  ],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const p0=G.players[0], p1=G.players[1];
  const sh = MC.makeInstance(G, 'shocker', {});
  MC.fireCardHook(G, sh, 'whenRevealed', { player: p0, self: sh, card: sh });
  check('각 히어로 피해 — fxDamageEachHero 힌트 생성', !!(G.fxDamageEachHero));
  check('각 히어로 피해 — defCode 기록 (shocker)', G.fxDamageEachHero.defCode === 'shocker');
  check('각 히어로 피해 — 피격 대상 uid 2명', G.fxDamageEachHero.targetUids.length === 2 &&
    G.fxDamageEachHero.targetUids.includes(p0.uid) && G.fxDamageEachHero.targetUids.includes(p1.uid));
  check('각 히어로 피해 — amount 기록', G.fxDamageEachHero.amount === 1);
  check('각 히어로 피해 — seq 증가', G.fxDamageEachHero.seq > 0);
  // 힌트가 하수인 defCode를 담아 UI가 vfx.attack(vibroShock)을 재사용할 수 있음
  const src = MC.cardDef(G.fxDamageEachHero.defCode);
  check('각 히어로 피해 — 하수인 vfx.attack 참조 가능', src.type === 'minion' && src.vfx && src.vfx.attack === 'vibroShock');
}

/* 01110 하이드라 폭파범(hydra-bomber): 선택형 whenRevealed (피해2 OR 위협+1) */
{
  const G=MC.makeGameState({seed:570,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0];
  check('폭파범 — 스탯 (ATK1/SCH1/HP2)', (()=>{const d=MC.cardDef('hydra-bomber');return d.attack===1&&d.scheme===1&&d.hp===2;})());
  check('폭파범 — hydra 트레잇', MC.cardDef('hydra-bomber').traits.includes('hydra'));
  // whenRevealed → revealChoice pending
  const bomb = MC.makeInstance(G, 'hydra-bomber', {});
  MC.fireCardHook(G, bomb, 'whenRevealed', { player: pl, self: bomb, card: bomb });
  check('폭파범 — whenRevealed가 revealChoice pending 생성', !!(G.pending && G.pending.kind === 'revealChoice'));
  check('폭파범 — 선택지 2개 (damage/threat)', G.pending.options.length === 2 &&
    G.pending.options.some(o=>o.key==='damage') && G.pending.options.some(o=>o.key==='threat'));
  // 피해 선택
  const hp0 = pl.hp;
  MC.dispatch(G, { type:'resolveRevealChoice', player:'P0', option:'damage' });
  check('폭파범 — 피해 선택: 교전 플레이어 2피해', pl.hp === hp0 - 2);
  check('폭파범 — 선택 후 pending 해제', !G.pending);
  // 위협 선택 (새 인스턴스)
  const bomb2 = MC.makeInstance(G, 'hydra-bomber', {});
  const th0 = G.mainScheme.threat;
  MC.fireCardHook(G, bomb2, 'whenRevealed', { player: pl, self: bomb2, card: bomb2 });
  MC.dispatch(G, { type:'resolveRevealChoice', player:'P0', option:'threat' });
  check('폭파범 — 위협 선택: 메인 스킴 위협 +1', G.mainScheme.threat === th0 + 1);
  check('폭파범 — vfx.attack 참조 (hydraBomb)', (()=>{const d=MC.cardDef('hydra-bomber');return d.vfx && d.vfx.attack === 'hydraBomb';})());
  check('폭파범 — 데이터 교차검증 (whenRevealed/부스트1/fx 등록)', (()=>{
    const d=MC.cardDef('hydra-bomber'); return d.whenRevealed==='runCardEffects' && d.whenRevealedEffects && d.whenRevealedEffects[0].fx==='offerChoice' && d.boost===1 && !d.todoFx;
  })());
}

/* 01120 무장 경호원(armored-guard): Guard+Toughness (기등록) + 대사/이펙트 */
{
  const G=MC.makeGameState({seed:571,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const ag = MC.makeInstance(G, 'armored-guard', {});
  check('무장 경호원 — 스탯 (ATK1/SCH0/HP3)', ag.attack===1 && ag.scheme===0 && ag.hp===3);
  check('무장 경호원 — Guard+Toughness 인스턴스 반영', ag.guard===true && ag.status.tough===1);
  check('무장 경호원 — Mercenary 트레잇', ag.traits.includes('mercenary'));
  // 공격 힌트 + vfx 참조
  ag.engagedWith = pl.uid; pl.engagedMinions.push(ag);
  MC.enemyActivation(G, ag, pl);
  check('무장 경호원 — 공격 힌트 fxMinionAttack (defCode)', !!(G.fxMinionAttack && G.fxMinionAttack.defCode === 'armored-guard'));
  check('무장 경호원 — vfx.attack 참조 (armorSlam)', (()=>{const d=MC.cardDef('armored-guard');return d.vfx && d.vfx.attack === 'armorSlam';})());
  check('무장 경호원 — 데이터 교차검증 (Guard+Tough/부스트1/fx 등록)', (()=>{
    const d=MC.cardDef('armored-guard'); return d.guard===true && d.toughness===true && d.boost===1 && !d.todoFx;
  })());
}

/* 01121 무기 밀매상(weapons-runner): Surge + 부스트★ 전장 배치 + 대사/이펙트 */
{
  const G=MC.makeGameState({seed:572,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const wr = MC.makeInstance(G, 'weapons-runner', {});
  check('무기 밀매상 — 스탯 (ATK1/SCH1/HP2)', wr.attack===1 && wr.scheme===1 && wr.hp===2);
  check('무기 밀매상 — Surge 플래그 인스턴스 반영', wr.surge === true);
  check('무기 밀매상 — Mercenary 트레잇', wr.traits.includes('mercenary'));
  // 부스트★ 전장 배치: resolveBoostStar가 교전 등장
  const before = pl.engagedMinions.length;
  const placed = MC.resolveBoostStar(G, pl, wr);
  check('무기 밀매상 — 부스트★ 전장 배치 (교전 등장)', placed === true && pl.engagedMinions.includes(wr) && pl.engagedMinions.length === before + 1);
  check('무기 밀매상 — 배치 시 engagedWith 설정', wr.engagedWith === pl.uid);
  // 공격 힌트 + vfx 참조
  MC.enemyActivation(G, wr, pl);
  check('무기 밀매상 — 공격 힌트 fxMinionAttack', !!(G.fxMinionAttack && G.fxMinionAttack.defCode === 'weapons-runner'));
  check('무기 밀매상 — vfx.attack 참조 (weaponSmuggle)', (()=>{const d=MC.cardDef('weapons-runner');return d.vfx && d.vfx.attack === 'weaponSmuggle';})());
  check('무기 밀매상 — 데이터 교차검증 (surge/boostStar/부스트1/fx 등록)', (()=>{
    const d=MC.cardDef('weapons-runner'); return d.surge===true && d.boostStarPutIntoPlay===true && d.boost===1 && !d.todoFx;
  })());
}

/* 01129 라디오액티브 맨(radioactive-man): 강제 반응(공격 후 손패 버림) + 부스트★ 손패 버림 */
{
  const G=MC.makeGameState({seed:573,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const rm = MC.makeInstance(G, 'radioactive-man', {});
  check('라디오액티브 맨 — 스탯 (ATK1/SCH1/HP7)', rm.attack===1 && rm.scheme===1 && rm.hp===7);
  check('라디오액티브 맨 — unique + Elite+Masters of Evil', rm.unique===true && rm.traits.includes('elite') && rm.traits.includes('masters of evil'));
  // 강제 반응: 공격 후 손패 무작위 1장 버림 (방어 해소 끝에서 발화)
  // 주의: 스파이더맨 스파이더 센스가 공격받을 때 카드 1장 뽑으므로 hand 순변화 대신 discard 증가로 검증
  while (pl.hand.length < 3) pl.hand.push(MC.makeInstance(G, 'strength', { ownerUid: pl.uid }));
  const disc0 = pl.discard.length;
  rm.engagedWith = pl.uid; pl.engagedMinions.push(rm);
  MC.enemyActivation(G, rm, pl);
  MC.dispatch(G, { type:'resolveDefense', player:'P0', defender:'none' });
  check('라디오액티브 맨 — 공격 후 손패 무작위 1장 버림 (버림 더미 +1)', pl.discard.length >= disc0 + 1);
  check('라디오액티브 맨 — 공격 힌트 fxMinionAttack', !!(G.fxMinionAttack && G.fxMinionAttack.defCode === 'radioactive-man'));
  // 부스트★: 부스트로 뽑히면 그 플레이어 손패 무작위 1장 버림 (배치 아님 → false 반환, 카드 버림)
  const hand1 = pl.hand.length;
  const placed = MC.resolveBoostStar(G, pl, MC.makeInstance(G, 'radioactive-man', {}));
  check('라디오액티브 맨 — 부스트★ 손패 버림 (배치 아님)', placed === false && pl.hand.length === hand1 - 1);
  check('라디오액티브 맨 — vfx.attack 참조 (radiationBlast)', (()=>{const d=MC.cardDef('radioactive-man');return d.vfx && d.vfx.attack === 'radiationBlast';})());
  check('라디오액티브 맨 — 데이터 교차검증 (forcedResponse/boostStar/fx 등록)', (()=>{
    const d=MC.cardDef('radioactive-man'); return d.forcedResponse==='runCardEffects' && d.forcedResponseEffects && d.forcedResponseEffects[0].fx==='discardFromHand' && d.boostStarEffect==='discardBooster' && !d.todoFx;
  })());
}

/* 01130 회오리바람(whirlwind): 강제 난입(각 히어로 공격) + 부스트★(각 히어로 피해) */
{
  const G=MC.makeGameState({seed:574,players:[
    {heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()},
    {heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()},
  ],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const p0=G.players[0], p1=G.players[1];
  p0.form='hero'; p1.form='hero';
  check('회오리바람 — 스탯 (ATK2/SCH1/HP6)', (()=>{const d=MC.cardDef('whirlwind');return d.attack===2&&d.scheme===1&&d.hp===6;})());
  check('회오리바람 — unique + Masters of Evil', (()=>{const d=MC.cardDef('whirlwind');return d.unique===true&&d.traits.includes('masters of evil');})());
  // 강제 난입: p0 공격 시 p1도 공격받음 (pending.alsoAttack 체인)
  const ww = MC.makeInstance(G, 'whirlwind', {});
  ww.engagedWith = p0.uid; p0.engagedMinions.push(ww);
  MC.enemyActivation(G, ww, p0);
  check('회오리바람 — 첫 공격 pending (p0) + alsoAttack에 p1', G.pending.player === p0.uid && G.pending.alsoAttack && G.pending.alsoAttack.includes(p1.uid));
  // p0 방어 해소 → p1 방어 pending 체인
  MC.dispatch(G, { type:'resolveDefense', player: p0.uid, defender:'none' });
  check('회오리바람 — 강제 난입 체인 (다음 p1 방어 pending)', G.pending && G.pending.kind === 'defense' && G.pending.player === p1.uid);
  // p1 방어 해소 → 체인 종료
  MC.dispatch(G, { type:'resolveDefense', player: p1.uid, defender:'none' });
  check('회오리바람 — 체인 종료 (pending 해제)', !G.pending || G.pending.kind !== 'defense');
  check('회오리바람 — vfx.attack 참조 (tornadoSpin)', (()=>{const d=MC.cardDef('whirlwind');return d.vfx && d.vfx.attack === 'tornadoSpin';})());
  check('회오리바람 — 데이터 교차검증 (forcedInterrupt/boostStar/fx 등록)', (()=>{
    const d=MC.cardDef('whirlwind'); return d.forcedInterrupt==='fi_attackEachHero' && d.boostStarEffect==='damageEachHeroBoost' && !d.todoFx;
  })());
}

/* 01131 타이거 샤크(tiger-shark): 강제 반응(공격 후 자신 강인) + 부스트★(빌런 강인) */
{
  const G=MC.makeGameState({seed:575,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const ts = MC.makeInstance(G, 'tiger-shark', {});
  check('타이거 샤크 — 스탯 (ATK3/SCH1/HP6)', ts.attack===3 && ts.scheme===1 && ts.hp===6);
  check('타이거 샤크 — unique + Masters of Evil', ts.unique===true && ts.traits.includes('masters of evil'));
  // 강제 반응: 공격 후 자신에게 강인 부여
  const tough0 = ts.status.tough || 0;
  ts.engagedWith = pl.uid; pl.engagedMinions.push(ts);
  MC.enemyActivation(G, ts, pl);
  MC.dispatch(G, { type:'resolveDefense', player:'P0', defender:'none' });
  check('타이거 샤크 — 공격 후 자신에게 강인 부여', (ts.status.tough||0) === tough0 + 1);
  check('타이거 샤크 — 공격 힌트 fxMinionAttack', !!(G.fxMinionAttack && G.fxMinionAttack.defCode === 'tiger-shark'));
  // 부스트★: 빌런에게 강인 부여
  const vtough0 = G.villain.status.tough || 0;
  MC.resolveBoostStar(G, pl, MC.makeInstance(G, 'tiger-shark', {}));
  check('타이거 샤크 — 부스트★ 빌런에게 강인 부여', (G.villain.status.tough||0) === vtough0 + 1);
  check('타이거 샤크 — vfx.attack 참조 (sharkBite)', (()=>{const d=MC.cardDef('tiger-shark');return d.vfx && d.vfx.attack === 'sharkBite';})());
  check('타이거 샤크 — 데이터 교차검증 (forcedResponse/boostStar/fx 등록)', (()=>{
    const d=MC.cardDef('tiger-shark'); return d.forcedResponse==='runCardEffects' && d.forcedResponseEffects && d.forcedResponseEffects[0].fx==='applyStatus' && d.boostStarEffect==='toughEnemy' && !d.todoFx;
  })());
}

/* 01132 멜터(melter): 지속 효과(동료 강제 방어) + 부스트★(동료 모두 소진) */
{
  const G=MC.makeGameState({seed:576,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01094',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const ml = MC.makeInstance(G, 'melter', {});
  check('멜터 — 스탯 (ATK3/SCH1/HP5)', ml.attack===3 && ml.scheme===1 && ml.hp===5);
  check('멜터 — unique + Masters of Evil', ml.unique===true && ml.traits.includes('masters of evil'));
  // 동료 배치
  const ally = MC.makeInstance(G, 'spider-girl', {}); ally.hp = 4; ally.exhausted = false;
  pl.playArea.allies.push(ally);
  // 멜터 공격 → mustDefendWithAlly 마커
  ml.engagedWith = pl.uid; pl.engagedMinions.push(ml);
  MC.enemyActivation(G, ml, pl);
  check('멜터 — 공격 시 mustDefendWithAlly 마커 (동료 있음)', G.pending.mustDefendWithAlly === true);
  // 신분 방어 시도 → 거부 (throw)
  let rejected = false;
  try { MC.resolveDefensePending(G, pl.uid, 'identity'); } catch(e){ rejected = true; }
  check('멜터 — 동료 있으면 신분 방어 거부', rejected === true && !!G.pending);
  // 무방어 시도 → 거부
  let rejected2 = false;
  try { MC.resolveDefensePending(G, pl.uid, 'none'); } catch(e){ rejected2 = true; }
  check('멜터 — 동료 있으면 무방어 거부', rejected2 === true && !!G.pending);
  // 동료 방어 → 성공
  MC.resolveDefensePending(G, pl.uid, ally.uid);
  check('멜터 — 동료 방어 성공 (pending 해제)', !G.pending);
  check('멜터 — 동료가 피해 받음 (exhausted)', ally.exhausted === true);
  // 부스트★: 통제하는 모든 동료 소진
  const a2 = MC.makeInstance(G, 'spider-girl', {}); a2.exhausted = false; pl.playArea.allies.push(a2);
  const a3 = MC.makeInstance(G, 'nick-fury', {}); a3.exhausted = false; pl.playArea.allies.push(a3);
  MC.resolveBoostStar(G, pl, MC.makeInstance(G, 'melter', {}));
  check('멜터 — 부스트★ 모든 동료 소진', pl.playArea.allies.every(a=>a.exhausted));
  check('멜터 — vfx.attack 참조 (meltRay)', (()=>{const d=MC.cardDef('melter');return d.vfx && d.vfx.attack === 'meltRay';})());
  check('멜터 — 데이터 교차검증 (forceAllyDefend/boostStar/fx 등록)', (()=>{
    const d=MC.cardDef('melter'); return d.forceAllyDefend===true && d.boostStarEffect==='exhaustAllAllies' && !d.todoFx;
  })());
}

/* 01113~01115 클로 빌런 3단계 + 강제 난입(공격 시 부스트 +1) + 불멸의 클로 */
{
  // 클로 빌런으로 게임 구성 (라이노 시나리오 조우덱 재사용 — 빌런만 교체)
  const G=MC.makeGameState({seed:713,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01113',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G); const pl=G.players[0]; pl.form='hero';
  const v=G.villain;
  check('클로 I — 스탯 (ATK0/SCH2/HP12×1)', v.attack===0 && v.scheme===2 && v.hp===12);
  check('클로 I — unique + Masters of Evil', v.unique===true && (v.traits||[]).includes('masters of evil'));
  check('클로 I — nextStage 01114', MC.cardDef('01113').nextStage==='01114');
  check('클로 I — 강제 난입 부스트+1 정의', MC.cardDef('01113').villainAttackExtraBoost===1);
  // 강제 난입: 클로 공격 시 부스트 카드 1장 추가 (pending.extraBoostCards)
  const deckBefore = G.encounterDeck.length;
  MC.enemyActivation(G, v, pl);
  check('클로 I — 공격 시 방어 pending 생성', !!G.pending && G.pending.kind==='defense');
  check('클로 I — 부스트 카드 1장(boostCard) + 추가 1장(extraBoostCards)',
    !!G.pending.boostCard && Array.isArray(G.pending.extraBoostCards) && G.pending.extraBoostCards.length===1);
  check('클로 I — 조우덱에서 부스트 2장 소비', deckBefore - G.encounterDeck.length === 2);
  // 방어 해소 — 부스트 2장 모두 공개·버림
  const discBefore = G.encounterDiscard.length;
  MC.resolveDefensePending(G, pl.uid, 'none');
  check('클로 I — 방어 해소 후 부스트 2장 버림', G.encounterDiscard.length - discBefore >= 2);
  check('클로 I — pending 해제', !G.pending);
}
{
  // 클로 II — 공개 시 불멸의 클로 사이드 스킴 공개 + HP +10
  const G=MC.makeGameState({seed:714,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()},{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01114',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G);
  const v=G.villain;
  check('클로 II — 스탯 (ATK1/SCH2/HP18×2=36)', v.attack===1 && v.scheme===2 && v.hp===36);
  // whenRevealed 발화 (클로 II 등장 시)
  const sideBefore = G.sideSchemes.length;
  const hpBefore = v.hp;
  MC.HANDLERS.klawStage2Reveal(G, { villain: v });
  if (G.pending && G.pending.kind === 'revealInterrupt') MC.resolveRevealInterrupt(G, G.pending.player, null);
  const found = G.sideSchemes.some(s => s.defCode==='immortal-klaw' || s.code==='immortal-klaw');
  check('클로 II — 불멸의 클로 사이드 스킴 공개', found && G.sideSchemes.length===sideBefore+1);
  // 불멸의 클로 지속 효과 — 공개 파이프라인에서 whenRevealed 자동 발화 → HP +10
  check('불멸의 클로 — 클로 HP +10', v.hp===hpBefore+10);
  // 해결(위협 제거, whenCompleted) 시 HP -10
  const ik = G.sideSchemes.find(s => s.defCode==='immortal-klaw');
  const maxBefore = v.maxHp;
  MC.removeThreat(G, ik.uid, 99);
  check('불멸의 클로 해결 — 클로 HP -10', v.maxHp===maxBefore-10);
}
{
  // 클로 III — Toughness(등장 시 tough)
  const G=MC.makeGameState({seed:715,players:[{heroCode:'01001a',deckCodes:FIXTURE_DECK.slice()}],villainCode:'01115',mainScheme:'01097b',encounterCodes:MC.buildEncounter('rhino')});
  MC.setupGame(G);
  const v=G.villain;
  check('클로 III — 스탯 (ATK2/SCH3/HP22×1)', v.attack===2 && v.scheme===3 && v.hp===22);
  MC.HANDLERS.klawStage3Reveal(G, { villain: v });
  check('클로 III — Toughness(tough 획득)', !!(v.status && v.status.tough));
  check('클로 — vfx 4종 참조', (()=>{const d=MC.cardDef('01113');return d.vfx.entrance==='sonicEmerge' && d.vfx.enemyAttack==='sonicBlast';})());
}

console.log(fail === 0 ? '[test_phase3_core] 전체 통과' : `[test_phase3_core] 실패 ${fail}건`);
process.exit(fail === 0 ? 0 : 1);
