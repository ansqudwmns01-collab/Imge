/* test_cap_cards_reverify.js — 캡틴아메리카 히어로 팩(03xxx) 카드 재검증 (영구 회귀)
   mcode 순으로 배선한 카드를 실제 dispatch로 검증. 카드 추가 시 여기에 이어서.
   사용: node tests/test_cap_cards_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mkCap(deck){
  const G = MC.makeGameState({ seed:2,
    players:[{ heroCode:'03001a', deckCodes: deck || Array(20).fill('energy') }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') });
  MC.setupGame(G); return G;
}

/* 03003 Fearless Determination — 히어로 행동: 이번 페이즈 THW+1 + 드로우 1 */
{
  const d = MC.cardDef('fearless-determination');
  assert(!d.todoFx && d.playForm === 'hero' && d.resources.mental === 1,
    '03003 — 배선 완료 + playForm hero + 멘탈1');

  const G = mkCap(); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  const thw0 = MC.statOf(G, pl, 'thwart'); const hand0 = pl.hand.length;
  const fd = MC.makeInstance(G, 'fearless-determination', {});
  MC.fireCardHook(G, fd, 'whenPlayed', { player: pl, self: fd, card: fd });
  assert(MC.statOf(G, pl, 'thwart') === thw0 + 1, '03003 — 히어로 THW +1 (이번 페이즈)');
  assert(pl.hand.length === hand0 + 1, '03003 — 카드 1장 드로우');

  // 페이즈 종료 시 THW 원복
  if (pl.tempStatBonus) pl.tempStatBonus = {};
  assert(MC.statOf(G, pl, 'thwart') === thw0, '03003 — 페이즈 종료 후 THW 원복');
}

/* buffSelfStat target 확장 — 하위호환(ctx.self=이벤트/동료) 유지 확인 */
{
  const G = mkCap(); const pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  const dummy = { uid:'x1', tempStatBonus:{} };
  MC.EFFECTS.buffSelfStat(G, { stat:'attack', amount:2 }, { self: dummy, player: pl });
  assert(dummy.tempStatBonus.attack === 2, 'buffSelfStat — target 미지정 시 ctx.self 버프(하위호환)');
  const thw0 = MC.statOf(G, pl, 'thwart');
  MC.EFFECTS.buffSelfStat(G, { target:'hero', stat:'thwart', amount:3 }, { self: dummy, player: pl });
  assert(MC.statOf(G, pl, 'thwart') === thw0 + 3, 'buffSelfStat — target:hero 시 플레이어 버프');
}

/* 03004 Heroic Strike — 공격: 적에게 6피해. 물리 지불 시 기절(킥커) */
{
  const d = MC.cardDef('heroic-strike');
  assert(!d.todoFx && d.playForm === 'hero' && d.resources.physical === 1,
    '03004 — 배선 완료 + playForm hero + 물리1');

  // 물리 지불 → 6피해 + 기절
  let G = mkCap(); let pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  let hp0 = G.villain.hp; if (G.villain.status) G.villain.status.stunned = 0;
  MC.runEffectList(G, d.effects, { player: pl, targets:[G.villain], paidIcons:{ physical:1 } });
  assert(G.villain.hp === hp0 - 6, '03004 — 6 피해');
  assert((G.villain.status.stunned || 0) > 0, '03004 — 물리 지불 시 기절(킥커)');

  // 비물리 지불 → 기절 없음
  G = mkCap(); pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  if (G.villain.status) G.villain.status.stunned = 0;
  MC.runEffectList(G, d.effects, { player: pl, targets:[G.villain], paidIcons:{ mental:1 } });
  assert((G.villain.status.stunned || 0) === 0, '03004 — 비물리 지불 시 기절 없음');
}

/* 03005 Shield Block — 방어 인터럽트: 방패 소진 → 피해 전부 방지 */
{
  const d = MC.cardDef('shield-block');
  assert(!d.todoFx && d.playCondition && d.playCondition.type === 'hasReadyCard' && d.playCondition.card === 'cap-shield',
    '03005 — 배선 완료 + playCondition(준비된 방패 필요)');

  // 방패 준비 → 소진 + 방어 해소 + 무피해
  let G = mkCap(); let pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  const shield = MC.makeInstance(G, 'cap-shield', {}); pl.playArea.upgrades.push(shield); shield.exhausted = false;
  const hp0 = pl.hp; G.pending = { kind:'defense', player: pl.uid, incoming:5 };
  MC.runEffectList(G, d.effects, { player: pl, card: MC.makeInstance(G, 'shield-block', {}) });
  assert(shield.exhausted === true, '03005 — 캡틴아메리카의 방패 소진(비용)');
  assert(G.pending === null, '03005 — preventAll로 방어 해소');
  assert(pl.hp === hp0, '03005 — 히어로 무피해(피해 전부 방지)');

  // 방패 없음/소진 → 조건 불충족
  G = mkCap(); pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  assert(MC.condCheck(G, d.playCondition, { player: pl }) === false, '03005 — 방패 없으면 플레이 불가');
  const ex = MC.makeInstance(G, 'cap-shield', {}); ex.exhausted = true; pl.playArea.upgrades.push(ex);
  assert(MC.condCheck(G, d.playCondition, { player: pl }) === false, '03005 — 방패 이미 소진 시 플레이 불가');
}

/* 03006 Shield Toss — X장 버림 + 방패 손 반환 + X적에게 4피해씩 */
{
  const d = MC.cardDef('shield-toss');
  assert(!d.todoFx && d.special === 'shieldTossPlay' && d.playCondition.type === 'hasCardInPlay',
    '03006 — 배선 완료 + special + playCondition(방패 플레이영역)');

  const G = mkCap(); const pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  const shield = MC.makeInstance(G, 'cap-shield', {}); shield.ownerUid = pl.uid; pl.playArea.upgrades.push(shield);
  while (pl.hand.length < 3) pl.hand.push(MC.makeInstance(G, 'energy', {}));
  const discUids = pl.hand.slice(0, 2).map(c => c.uid);
  const minion = MC.makeInstance(G, 'armored-guard', {}); minion.engagedWith = pl.uid; pl.engagedMinions.push(minion);
  if (minion.status) minion.status.tough = 0;   // Tough 흡수 배제 — 순수 피해 검증
  const vhp0 = G.villain.hp, mhp0 = minion.hp, disc0 = pl.discard.length;

  assert(MC.condCheck(G, d.playCondition, { player: pl }) === true, '03006 — 방패 있으면 playCondition 통과');
  MC.HANDLERS.shieldTossPlay(G, { player: pl, discardUids: discUids, targets:[G.villain, minion] });
  assert(pl.discard.length >= disc0 + 2, '03006 — X=2장 버림');
  assert(pl.playArea.upgrades.filter(c => c.defCode === 'cap-shield').length === 0 && pl.hand.some(c => c.defCode === 'cap-shield'),
    '03006 — 방패 플레이영역→손 반환');
  assert(G.villain.hp === vhp0 - 4, '03006 — 빌런에게 4 피해');
  assert(minion.hp === mhp0 - 4, '03006 — 하수인에게 4 피해');

  const G2 = mkCap(); const pl2 = G2.players[0]; if (pl2.form !== 'hero') MC.flipForm(G2, pl2, { force:true });
  assert(MC.condCheck(G2, d.playCondition, { player: pl2 }) === false, '03006 — 방패 없으면 플레이 불가');
}

/* 03007 Steve's Apartment — 알터에고 행동: 소진 → 드로우1 + 회복1 */
{
  const d = MC.cardDef('steves-apartment');
  assert(!d.todoFx && d.activatedAbility && d.activatedAbility.form === 'alter-ego' && d.activatedAbility.exhaust,
    '03007 — 배선 완료 + activatedAbility(alter-ego, exhaust)');

  // 알터에고: 소진 + 드로우 + 회복
  let G = mkCap(); let pl = G.players[0]; pl.hp = pl.maxHp - 3;   // 셋업 후 alter-ego
  const apt = MC.makeInstance(G, 'steves-apartment', {}); apt.ownerUid = pl.uid; pl.playArea.supports.push(apt);
  const hand0 = pl.hand.length, hp0 = pl.hp;
  MC.dispatch(G, { type:'useCardAbility', player: pl.uid, cardUid: apt.uid, payment:[] });
  assert(pl.hand.length === hand0 + 1, '03007 — 카드 1장 드로우');
  assert(pl.hp === hp0 + 1, '03007 — 스티브 1 회복');
  assert(apt.exhausted === true, '03007 — 아파트 소진');

  // 히어로 폼 사용 불가
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const apt2 = MC.makeInstance(G, 'steves-apartment', {}); apt2.ownerUid = pl.uid; pl.playArea.supports.push(apt2);
  let blocked = false; try { MC.dispatch(G, { type:'useCardAbility', player: pl.uid, cardUid: apt2.uid, payment:[] }); } catch(e){ blocked = true; }
  assert(blocked || !apt2.exhausted, '03007 — 히어로 폼에선 사용 불가');
}

/* 03008 Captain America's Helmet — 인터럽트: 패배당할 때 HP 1로 + 버림 */
{
  const d = MC.cardDef('cap-helmet');
  assert(!d.todoFx && d.preventDefeatToHp === 1, '03008 — 배선 완료 + preventDefeatToHp 1');

  // 헬멧 있음 → 치명타에 HP 1, 버림, 미탈락
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const h = MC.makeInstance(G, 'cap-helmet', {}); h.ownerUid = pl.uid; pl.playArea.upgrades.push(h);
  pl.hp = 5; MC.applyDamage(G, pl, 100, { source: G.villain });
  assert(pl.hp === 1, '03008 — 패배 방지: HP 1로');
  assert(!pl.eliminated, '03008 — 미탈락(생존)');
  assert(pl.discard.some(c => c.defCode === 'cap-helmet'), '03008 — 헬멧 버림 더미로');
  assert(!pl.playArea.upgrades.some(c => c.defCode === 'cap-helmet'), '03008 — 헬멧 플레이영역 제거');

  // 헬멧 없음 → 탈락
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  pl.hp = 5; MC.applyDamage(G, pl, 100, { source: G.villain });
  assert(pl.eliminated === true, '03008 — 헬멧 없으면 패배(탈락)');
}

/* 03009 Captain America's Shield — 제한. DEF+1 + 보복1 (지속) */
{
  const d = MC.cardDef('cap-shield');
  assert(!d.todoFx && d.statMod && d.statMod.stat === 'defense' && d.statMod.amount === 1 && d.grantsRetaliate === 1 && d.restricted,
    '03009 — 배선: statMod DEF+1 + grantsRetaliate1 + restricted');

  // DEF +1
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const def0 = MC.statOf(G, pl, 'defense');
  const sh = MC.makeInstance(G, 'cap-shield', {}); sh.ownerUid = pl.uid; pl.playArea.upgrades.push(sh);
  assert(MC.statOf(G, pl, 'defense') === def0 + 1, '03009 — 방패 설치 → DEF +1');

  // 보복 1: 히어로 공격받으면 공격자에게 1 피해
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const sh2 = MC.makeInstance(G, 'cap-shield', {}); sh2.ownerUid = pl.uid; pl.playArea.upgrades.push(sh2);
  const vhp0 = G.villain.hp; pl.hp = 20;
  MC.applyDamage(G, pl, 3, { source: G.villain, isAttack: true });
  assert(G.villain.hp === vhp0 - 1, '03009 — 공격받을 때 보복 1(공격자 1 피해)');

  // 방패 없으면 보복 없음
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const vhp1 = G.villain.hp; pl.hp = 20;
  MC.applyDamage(G, pl, 3, { source: G.villain, isAttack: true });
  assert(G.villain.hp === vhp1, '03009 — 방패 없으면 보복 없음');
}

/* 03010 Super-Soldier Serum — 자원: 소진 → 물리 자원 1 (resourceGenerator 인덱스 재사용) */
{
  const d = MC.cardDef('super-soldier-serum');
  assert(!d.todoFx && d.resourceGenerator && d.resourceGenerator.exhaust && d.resourceGenerator.icons.physical === 1,
    '03010 — 배선: resourceGenerator(exhaust, physical 1) 데이터 재사용');

  // 혈청 → 물리 자원 생성 (computePayment 경로)
  const G = mkCap(); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const serum = MC.makeInstance(G, 'super-soldier-serum', {}); serum.ownerUid = pl.uid; serum.exhausted = false; pl.playArea.upgrades.push(serum);
  if (MC.computePayment){
    const pay = MC.computePayment(G, pl, [{ kind:'card', uid: serum.uid }]);
    assert(pay && pay.icons && pay.icons.physical >= 1, '03010 — 혈청 소진 → 물리 자원 1 생성');
  } else {
    assert(true, '03010 — computePayment 미노출(데이터 배선만 확인)');
  }
}

/* 03011 Falcon — 반응: 조우덱 상위 3장 확인 → 배신 1장당 위협 1 제거 (peekEncounterRemoveThreat 인덱스) */
{
  const d = MC.cardDef('falcon-ally');
  assert(!d.todoFx && d.whenPlayedEffects && d.whenPlayedEffects[0].fx === 'peekEncounterRemoveThreat' && d.whenPlayedEffects[0].count === 3,
    '03011 — 배선: peekEncounterRemoveThreat(count 3) 데이터');
  assert(typeof MC.EFFECTS.peekEncounterRemoveThreat === 'function', '03011 — 범용 EFFECT peekEncounterRemoveThreat 존재');

  // 배신 2장 → 위협 2 제거, 덱 순서/장수 유지
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  G.mainScheme.threat = 5; let th0 = G.mainScheme.threat;
  G.encounterDeck.push(MC.makeInstance(G, 'armored-guard', {}), MC.makeInstance(G, 'advance', {}), MC.makeInstance(G, 'shadow-of-the-past', {}));
  const deckLen0 = G.encounterDeck.length;
  let falcon = MC.makeInstance(G, 'falcon-ally', {}); falcon.ownerUid = pl.uid; pl.playArea.allies.push(falcon);
  MC.fireCardHook(G, falcon, 'whenPlayed', { player: pl, self: falcon, card: falcon, targetScheme: 'main' });
  assert(th0 - G.mainScheme.threat === 2, '03011 — 배신 2장 → 위협 2 제거');
  assert(G.encounterDeck.length === deckLen0, '03011 — 조우덱 확인만(장수 유지)');

  // 배신 0장 → 제거 없음
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  G.mainScheme.threat = 5; th0 = G.mainScheme.threat;
  G.encounterDeck.push(MC.makeInstance(G, 'armored-guard', {}), MC.makeInstance(G, 'armored-guard', {}), MC.makeInstance(G, 'armored-guard', {}));
  falcon = MC.makeInstance(G, 'falcon-ally', {}); falcon.ownerUid = pl.uid; pl.playArea.allies.push(falcon);
  MC.fireCardHook(G, falcon, 'whenPlayed', { player: pl, self: falcon, card: falcon, targetScheme: 'main' });
  assert(G.mainScheme.threat === th0, '03011 — 배신 0장 → 위협 제거 없음');
}

/* 03012 Hawkeye — 화살 4개 등장 + 하수인 등장 반응(선택: 발동→화살 소진 2피해 / 넘김). 01066/03012 통합 정의 */
{
  for (const c of ['hawkeye', 'hawkeye-cap'])
    assert(!MC.cardDef(c).todoFx && MC.cardDef(c).entersWithCounters === 4 && MC.cardDef(c).onMinionEnterDamage && MC.cardDef(c).onMinionEnterDamage.amount === 2,
      '03012 — ' + c + ' 통합 배선(entersWithCounters 4 + onMinionEnterDamage 2)');

  // 발동(fire) 경로
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  let hawk = MC.makeInstance(G, 'hawkeye', {}); hawk.ownerUid = pl.uid; pl.playArea.allies.push(hawk);
  assert(hawk.counters === 4, '03012 — 화살 카운터 4개 등장');
  let m = MC.makeInstance(G, 'armored-guard', {}); if (m.status) m.status.tough = 0; let mhp0 = m.hp;
  m.engagedWith = pl.uid; pl.engagedMinions.push(m);
  MC.minionEnteredPlay(G, m, pl);
  assert((G._pendingMinionReactions || []).length === 1, '03012 — 하수인 등장 → 반응 큐잉(자동발동 아님)');
  assert(m.hp === mhp0 && hawk.counters === 4, '03012 — 선택 전에는 미발동');
  assert(MC.flushMinionReactions(G) && G.pending && G.pending.kind === 'revealChoice', '03012 — flush → 발동/넘김 선택 pending');
  assert(G.pending.options.length === 2 && G.pending.options[0].key === 'fire' && G.pending.options[1].key === 'skip', '03012 — 선택지 발동/넘김');
  MC.dispatch(G, { type:'resolveRevealChoice', option:'fire' });
  assert(m.hp === mhp0 - 2 && hawk.counters === 3, '03012 — 발동 선택 → 2 피해 + 화살 1 소진');

  // 넘김(skip) 경로 — 화살 보존
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  hawk = MC.makeInstance(G, 'hawkeye', {}); hawk.ownerUid = pl.uid; pl.playArea.allies.push(hawk);
  m = MC.makeInstance(G, 'armored-guard', {}); if (m.status) m.status.tough = 0; mhp0 = m.hp;
  m.engagedWith = pl.uid; pl.engagedMinions.push(m);
  MC.minionEnteredPlay(G, m, pl); MC.flushMinionReactions(G);
  MC.dispatch(G, { type:'resolveRevealChoice', option:'skip' });
  assert(m.hp === mhp0 && hawk.counters === 4, '03012 — 넘김 선택 → 피해 없음 + 화살 보존');

  // 화살 0 → 반응 후보 없음
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  hawk = MC.makeInstance(G, 'hawkeye', {}); hawk.counters = 0; pl.playArea.allies.push(hawk);
  m = MC.makeInstance(G, 'armored-guard', {}); m.engagedWith = pl.uid; pl.engagedMinions.push(m);
  MC.minionEnteredPlay(G, m, pl);
  assert(!(G._pendingMinionReactions || []).length, '03012 — 화살 0이면 반응 후보 없음');
}

/* 03013 Squirrel Girl — 반응: 각 적(빌런+모든 하수인) 1피해 AoE (dealDamage/allEnemies 인덱스 재사용) */
{
  const d = MC.cardDef('squirrel-girl');
  assert(!d.todoFx && d.whenPlayedEffects && d.whenPlayedEffects[0].fx === 'dealDamage' && d.whenPlayedEffects[0].target === 'allEnemies' && d.whenPlayedEffects[0].amount === 1,
    '03013 — dealDamage/allEnemies 데이터 재사용');

  const G = mkCap(); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const vhp0 = G.villain.hp;
  const m1 = MC.makeInstance(G, 'armored-guard', {}); if (m1.status) m1.status.tough = 0; m1.engagedWith = pl.uid; pl.engagedMinions.push(m1); const m1hp0 = m1.hp;
  const m2 = MC.makeInstance(G, 'armored-guard', {}); if (m2.status) m2.status.tough = 0; m2.engagedWith = pl.uid; pl.engagedMinions.push(m2); const m2hp0 = m2.hp;
  const sg = MC.makeInstance(G, 'squirrel-girl', {}); sg.ownerUid = pl.uid; pl.playArea.allies.push(sg);
  MC.fireCardHook(G, sg, 'whenPlayed', { player: pl, self: sg, card: sg });
  assert(G.villain.hp === vhp0 - 1 && m1.hp === m1hp0 - 1 && m2.hp === m2hp0 - 1, '03013 — 각 적(빌런+하수인2) 1 피해');
}

/* 03014 Wonder Man — 공격 추가 비용: 손패 1장 버림(선택). 저지/방어엔 추가 비용 없음 */
{
  const d = MC.cardDef('wonder-man');
  assert(!d.todoFx && d.attackExtraCost && d.attackExtraCost.discardFromHand === 1, '03014 — attackExtraCost.discardFromHand 1');

  // 공격 → 손패 버림 선택 pending → 지불 후 실제 공격
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  let wm = MC.makeInstance(G, 'wonder-man', {}); wm.ownerUid = pl.uid; wm.exhausted = false; pl.playArea.allies.push(wm);
  pl.hand = [MC.makeInstance(G, 'energy', {}), MC.makeInstance(G, 'strength', {})];
  const hand0 = pl.hand.length, vhp0 = G.villain.hp;
  MC.dispatch(G, { type:'allyAttack', player: pl.uid, allyUid: wm.uid, targetUid: G.villain.uid });
  assert(G.pending && G.pending.kind === 'handDiscardCost' && G.villain.hp === vhp0 && !wm.exhausted,
    '03014 — 공격 시 손패 버림 선택 pending(즉시 공격/소진 아님)');
  MC.dispatch(G, { type:'resolveHandDiscardCost', player: pl.uid, uid: pl.hand[0].uid });
  assert(pl.hand.length === hand0 - 1 && G.villain.hp === vhp0 - 3 && wm.exhausted && !G.pending,
    '03014 — 비용 지불 후 실제 공격(ATK 3) + 소진');

  // 손패 0 → 공격 불가
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  wm = MC.makeInstance(G, 'wonder-man', {}); wm.ownerUid = pl.uid; wm.exhausted = false; pl.playArea.allies.push(wm);
  pl.hand = [];
  let threw = false;
  try { MC.dispatch(G, { type:'allyAttack', player: pl.uid, allyUid: wm.uid, targetUid: G.villain.uid }); } catch(e){ threw = true; }
  assert(threw && !wm.exhausted, '03014 — 손패 0이면 공격 불가');

  // 저지엔 추가 비용 없음
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  wm = MC.makeInstance(G, 'wonder-man', {}); wm.ownerUid = pl.uid; wm.exhausted = false; pl.playArea.allies.push(wm);
  pl.hand = []; G.mainScheme.threat = 5;
  MC.dispatch(G, { type:'allyThwart', player: pl.uid, allyUid: wm.uid, scheme:'main' });
  assert(!G.pending && wm.exhausted && G.mainScheme.threat === 4, '03014 — 저지엔 추가 비용 없음(손패 0이어도 실행)');
}

/* 03015 Avengers Assemble! — 이벤트: Avenger 준비 + 페이즈끝까지 전장 Avenger THW/ATK+1. 라운드1회 */
{
  const d = MC.cardDef('avengers-assemble');
  assert(!d.todoFx && d.maxPerRound === 1 && d.effects.length === 2 && d.effects[0].fx === 'readyCharactersByTrait' && d.effects[1].fx === 'buffCharactersByTrait',
    '03015 — maxPerRound1 + readyCharactersByTrait + buffCharactersByTrait 데이터');
  assert(typeof MC.EFFECTS.readyCharactersByTrait === 'function' && typeof MC.EFFECTS.buffCharactersByTrait === 'function',
    '03015 — 범용 EFFECT 2종 존재');

  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  assert(MC.playerHasTrait(G, pl, 'avenger'), '03015 — 캡틴 아메리카는 Avenger');
  const sg = MC.makeInstance(G, 'squirrel-girl', {}); sg.ownerUid = pl.uid; sg.exhausted = true; pl.playArea.allies.push(sg);
  const nonAv = MC.makeInstance(G, 'maria-hill', {}); nonAv.ownerUid = pl.uid; nonAv.exhausted = true; pl.playArea.allies.push(nonAv);
  pl.exhausted = true;
  const thw0 = MC.statOf(G, pl, 'thwart'), atk0 = MC.statOf(G, pl, 'attack'), sgAtk0 = MC.allyStatOf(G, sg, 'attack');
  MC.runEffectList(G, d.effects, { player: pl });
  assert(!pl.exhausted && !sg.exhausted, '03015 — 히어로+Avenger동료 준비됨');
  assert(nonAv.exhausted, '03015 — 비-Avenger 동료는 준비 안 됨');
  assert(MC.statOf(G, pl, 'thwart') === thw0 + 1 && MC.statOf(G, pl, 'attack') === atk0 + 1, '03015 — 히어로 THW/ATK +1');
  assert(MC.allyStatOf(G, sg, 'attack') === sgAtk0 + 1, '03015 — Avenger 동료 ATK +1');

  // maxPerRound: 2회째 차단
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const c1 = MC.makeInstance(G, 'avengers-assemble', {}), c2 = MC.makeInstance(G, 'avengers-assemble', {});
  const en = () => MC.makeInstance(G, 'energy', {});
  pl.hand = [c1, c2, en(), en(), en(), en(), en(), en(), en(), en()];
  const pay = () => pl.hand.filter(x => x.defCode === 'energy').slice(0, 4).map(x => ({ kind:'hand', uid: x.uid }));
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: c1.uid, payment: pay() });
  let threw = false;
  try { MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: c2.uid, payment: pay() }); } catch(e){ threw = /라운드당 최대/.test(e.message); }
  assert(threw, '03015 — maxPerRound 2회째 플레이 차단');
}

/* 03017 Strength In Numbers — 원하는 수만큼 동료 소진(다중선택) → 소진 수만큼 드로우 */
{
  const d = MC.cardDef('strength-in-numbers');
  assert(!d.todoFx && d.effects[0].fx === 'exhaustAlliesForDraw', '03017 — exhaustAlliesForDraw 데이터');
  assert(typeof MC.EFFECTS.exhaustAlliesForDraw === 'function', '03017 — 범용 EFFECT 존재');

  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const a1 = MC.makeInstance(G, 'squirrel-girl', {}); a1.ownerUid = pl.uid; a1.exhausted = false; pl.playArea.allies.push(a1);
  const a2 = MC.makeInstance(G, 'maria-hill', {}); a2.ownerUid = pl.uid; a2.exhausted = false; pl.playArea.allies.push(a2);
  const a3 = MC.makeInstance(G, 'nick-fury', {}); a3.ownerUid = pl.uid; a3.exhausted = false; pl.playArea.allies.push(a3);
  const hand0 = pl.hand.length;
  MC.runEffectList(G, d.effects, { player: pl });
  assert(G.pending && G.pending.kind === 'allyExhaustDraw' && G.pending.allyUids.length === 3, '03017 — 준비 동료 다중선택 pending');
  MC.dispatch(G, { type:'resolveAllyExhaustDraw', player: pl.uid, mode:'toggle', uid: a1.uid });
  MC.dispatch(G, { type:'resolveAllyExhaustDraw', player: pl.uid, mode:'toggle', uid: a3.uid });
  MC.dispatch(G, { type:'resolveAllyExhaustDraw', player: pl.uid, mode:'confirm' });
  assert(a1.exhausted && a3.exhausted && !a2.exhausted, '03017 — 선택한 동료만 소진');
  assert(pl.hand.length === hand0 + 2 && !G.pending, '03017 — 소진 수(2)만큼 드로우');

  // 0명 확정 → 드로우 0
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const b1 = MC.makeInstance(G, 'squirrel-girl', {}); b1.ownerUid = pl.uid; b1.exhausted = false; pl.playArea.allies.push(b1);
  const h0 = pl.hand.length;
  MC.runEffectList(G, d.effects, { player: pl });
  MC.dispatch(G, { type:'resolveAllyExhaustDraw', player: pl.uid, mode:'confirm' });
  assert(pl.hand.length === h0 && !b1.exhausted, '03017 — 0명 확정 시 드로우 0');

  // 준비 동료 없음 → pending 없음
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  MC.runEffectList(G, d.effects, { player: pl });
  assert(!G.pending, '03017 — 준비 동료 없으면 no-op');
}

/* 03019 Quinjet — 턴 시작 시간 카운터 적립 + Avenger 동료 무료 배치(선택) → 퀸젯 버림 */
{
  const d = MC.cardDef('quinjet');
  assert(d.playerPhaseStart === 'gainCounterOnPhase' && typeof MC.HANDLERS.gainCounterOnPhase === 'function', '03019 — playerPhaseStart 카운터 훅');
  assert(d.activatedAbility.effect[0].fx === 'deployAllyFromHand', '03019 — deployAllyFromHand 데이터');
  assert(typeof MC.EFFECTS.deployAllyFromHand === 'function', '03019 — deployAllyFromHand 범용 EFFECT');

  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const q = MC.makeInstance(G, 'quinjet', {}); q.ownerUid = pl.uid; pl.playArea.supports.push(q);
  MC.fireHook(G, 'playerPhaseStart', {});
  MC.fireHook(G, 'playerPhaseStart', {});
  MC.fireHook(G, 'playerPhaseStart', {});
  assert(q.counters === 3, '03019 — 턴 시작마다 시간 카운터 적립 (3)');
  const falcon = MC.makeInstance(G, 'falcon-ally', {}); falcon.ownerUid = pl.uid; pl.hand.push(falcon);   // cost4
  const sg = MC.makeInstance(G, 'squirrel-girl', {}); sg.ownerUid = pl.uid; pl.hand.push(sg);             // cost2 Avenger
  const mh = MC.makeInstance(G, 'maria-hill', {}); mh.ownerUid = pl.uid; pl.hand.push(mh);                // cost2 non-Avenger
  MC.dispatch(G, { type:'useCardAbility', player: pl.uid, cardUid: q.uid });
  assert(G.pending && G.pending.kind === 'deployAlly' && G.pending.allyUids.length === 1 && G.pending.allyUids[0] === sg.uid,
    '03019 — 후보=cost≤카운터 Avenger만 (팔콘/마리아힐 제외)');
  MC.dispatch(G, { type:'resolveDeployAlly', player: pl.uid, uid: sg.uid });
  assert(pl.playArea.allies.some(a => a.defCode === 'squirrel-girl') && !pl.hand.some(c => c.uid === sg.uid), '03019 — 선택 동료 무료 배치');
  assert(!pl.playArea.supports.some(s => s.defCode === 'quinjet') && pl.discard.some(c => c.defCode === 'quinjet'), '03019 — 배치 후 퀸젯 버림');

  // 카운터 부족 → 배치 불가(throw), 퀸젯 유지
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const q2 = MC.makeInstance(G, 'quinjet', {}); q2.ownerUid = pl.uid; q2.counters = 1; pl.playArea.supports.push(q2);
  const f2 = MC.makeInstance(G, 'falcon-ally', {}); f2.ownerUid = pl.uid; pl.hand.push(f2);   // cost4 > 1
  let threw = false;
  try { MC.dispatch(G, { type:'useCardAbility', player: pl.uid, cardUid: q2.uid }); } catch(e){ threw = true; }
  assert(threw && pl.playArea.supports.some(s => s.defCode === 'quinjet'), '03019 — 카운터 부족 시 배치 불가, 퀸젯 유지');
}

/* 03024 Avengers Tower — 조건부 동료 한도 +1 + 다음 Avenger 동료 비용 -1(필터 할인) */
{
  const d = MC.cardDef('avengers-tower');
  assert(d.allyLimitBonus === 1 && d.allyLimitCondAllTrait === 'avenger', '03024 — 조건부 allyLimitBonus 데이터');
  assert(d.activatedAbility.effect[0].fx === 'reduceNextPlayCost' && typeof MC.EFFECTS.reduceNextPlayCost === 'function', '03024 — reduceNextPlayCost EFFECT');

  // 조건부 한도
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const tower = MC.makeInstance(G, 'avengers-tower', {}); tower.ownerUid = pl.uid; pl.playArea.supports.push(tower);
  assert(MC.allyLimitOf(G, pl) === 4, '03024 — 동료 0명 → 한도 4 (공허참)');
  const sg = MC.makeInstance(G, 'squirrel-girl', {}); sg.ownerUid = pl.uid; pl.playArea.allies.push(sg);
  assert(MC.allyLimitOf(G, pl) === 4, '03024 — 모든 동료 Avenger → 한도 4 유지');
  const mh0 = MC.makeInstance(G, 'maria-hill', {}); mh0.ownerUid = pl.uid; pl.playArea.allies.push(mh0);
  assert(MC.allyLimitOf(G, pl) === 3, '03024 — 비-Avenger 동료 섞임 → 한도 3 하락');

  // 필터 할인: 비-Avenger 먼저→유지, Avenger에 적용 (리빙레전드 격리)
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true }); pl.usedLivingLegendThisRound = true;
  const t2 = MC.makeInstance(G, 'avengers-tower', {}); t2.ownerUid = pl.uid; pl.playArea.supports.push(t2);
  MC.dispatch(G, { type:'useCardAbility', player: pl.uid, cardUid: t2.uid });
  assert(t2.exhausted === true && pl.nextCardDiscount === 1 && pl.nextCardDiscountFilter.trait === 'avenger', '03024 — 소진 + 필터 할인 세팅');
  const mh = MC.makeInstance(G, 'maria-hill', {}); mh.ownerUid = pl.uid; pl.hand.push(mh);
  const e1 = MC.makeInstance(G, 'energy', {}); e1.ownerUid = pl.uid; pl.hand.push(e1);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: mh.uid, payment:[{ kind:'hand', uid:e1.uid }] });
  assert(pl.nextCardDiscount === 1 && !!pl.nextCardDiscountFilter, '03024 — 비-Avenger엔 할인 미적용(유지)');
  const fal = MC.makeInstance(G, 'falcon-ally', {}); fal.ownerUid = pl.uid; pl.hand.push(fal);
  const e2 = MC.makeInstance(G, 'energy', {}); e2.ownerUid = pl.uid; pl.hand.push(e2);
  const e3 = MC.makeInstance(G, 'energy', {}); e3.ownerUid = pl.uid; pl.hand.push(e3);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: fal.uid, payment:[{ kind:'hand', uid:e2.uid }, { kind:'hand', uid:e3.uid }] });
  assert(pl.playArea.allies.some(a => a.defCode === 'falcon-ally') && pl.nextCardDiscount === 0 && !pl.nextCardDiscountFilter, '03024 — Avenger 동료 -1 적용 + 필터 소모');
}

/* 03025 Honorary Avenger — 우호 캐릭터(히어로/동료)에 부착, HP+1 + Avenger 특성 부여 */
{
  const d = MC.cardDef('honorary-avenger');
  assert(d.grantsTrait === 'avenger' && d.hpBonus === 1 && d.playCondition.trait === 'avenger', '03025 — grantsTrait+hpBonus+조건 데이터');
  assert(typeof MC.allyHasTrait === 'function', '03025 — allyHasTrait 집계 헬퍼');

  // 히어로 부착
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const maxB = pl.maxHp, hpB = pl.hp;
  const ha = MC.makeInstance(G, 'honorary-avenger', {}); ha.ownerUid = pl.uid; pl.hand.push(ha);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: ha.uid, payment:[] });
  assert(G.pending && G.pending.kind === 'attachCharacter' && G.pending.heroTarget, '03025 — attachCharacter 선택 pending');
  MC.dispatch(G, { type:'resolveAttachCharacter', player: pl.uid, target:'hero' });
  assert(pl.maxHp === maxB + 1 && pl.hp === hpB + 1 && MC.playerHasTrait(G, pl, 'avenger'), '03025 — 히어로 HP+1 + Avenger');

  // 동료 부착: 비-Avenger 동료 → Avenger 획득 + HP+1, detach 원복
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const mh = MC.makeInstance(G, 'maria-hill', {}); mh.ownerUid = pl.uid; pl.playArea.allies.push(mh);
  const mhHp = mh.hp, mhMax = mh.maxHp;
  assert(!MC.allyHasTrait(G, mh, 'avenger'), '03025 — 부착 전 비-Avenger 동료');
  const ha2 = MC.makeInstance(G, 'honorary-avenger', {}); ha2.ownerUid = pl.uid; pl.hand.push(ha2);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: ha2.uid, payment:[] });
  assert(G.pending.allyUids.includes(mh.uid), '03025 — 동료도 부착 후보');
  MC.dispatch(G, { type:'resolveAttachCharacter', player: pl.uid, target: mh.uid });
  assert(mh.maxHp === mhMax + 1 && mh.hp === mhHp + 1 && MC.allyHasTrait(G, mh, 'avenger'), '03025 — 동료 HP+1 + Avenger 획득');
  const inst = mh.attachments.find(x => x.defCode === 'honorary-avenger');
  MC.detachFrom(G, inst);
  assert(mh.maxHp === mhMax && !MC.allyHasTrait(G, mh, 'avenger'), '03025 — detach 시 HP·Avenger 원복');

  // 어벤져스 타워 조건부 한도와 상호작용
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const tw = MC.makeInstance(G, 'avengers-tower', {}); tw.ownerUid = pl.uid; pl.playArea.supports.push(tw);
  const mh2 = MC.makeInstance(G, 'maria-hill', {}); mh2.ownerUid = pl.uid; pl.playArea.allies.push(mh2);
  assert(MC.allyLimitOf(G, pl) === 3, '03025 — 비-Avenger 동료 → 타워 한도 3');
  const ha3 = MC.makeInstance(G, 'honorary-avenger', {}); ha3.ownerUid = pl.uid; pl.hand.push(ha3);
  MC.dispatch(G, { type:'playCard', player: pl.uid, cardUid: ha3.uid, payment:[] });
  MC.dispatch(G, { type:'resolveAttachCharacter', player: pl.uid, target: mh2.uid });
  assert(MC.allyLimitOf(G, pl) === 4, '03025 — 명예 어벤져 부착 → 타워 한도 4 (Avenger 카운트)');
}

/* 03026 Man Out of Time — 의무, 폼전환(선택) + 택1(소진→제거 / 손패절반 버림→순환) */
{
  const d = MC.cardDef('man-out-of-time');
  assert(d.whenRevealed === 'runCardEffects' && !d.todoFx, '03026 — whenRevealed offerChoice 배선');
  assert(typeof MC.EFFECTS.flipToAlterEgo === 'function' && typeof MC.EFFECTS.discardChooseFromHand === 'function', '03026 — 신규 EFFECT 존재');

  // A: 폼전환X → 소진 제거
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true }); pl.exhausted = false;
  let mot = MC.makeInstance(G, 'man-out-of-time', {}); mot.ownerUid = pl.uid; G.encounterDiscard.push(mot);
  MC.fireCardHook(G, mot, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'revealChoice', '03026 — 1단계 폼전환 선택 pending');
  MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'noflip' });
  assert(G.pending.options.some(o => o.key === 'exhaust'), '03026 — 신분 준비 시 exhaust 옵션 노출');
  MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'exhaust' });
  assert(pl.exhausted && (G.removedFromGame || []).includes('man-out-of-time') && !G.encounterDiscard.includes(mot),
    '03026 — 소진 → 게임 영구 제거');

  // B: 폼전환O → 손패 절반 버림 → 순환
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true }); pl.formChangedThisRound = false;
  pl.hand = []; for (let i = 0; i < 6; i++){ const e = MC.makeInstance(G, 'energy', {}); e.ownerUid = pl.uid; pl.hand.push(e); }
  mot = MC.makeInstance(G, 'man-out-of-time', {}); mot.ownerUid = pl.uid; G.encounterDiscard.push(mot);
  MC.fireCardHook(G, mot, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'flip' });
  assert(pl.form === 'alter-ego', '03026 — 폼 전환 (알터에고)');
  MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'discardHalf' });
  assert(G.pending && G.pending.kind === 'discardChoose' && G.pending.remaining === 3, '03026 — 손패 절반(3장) 선택 버림 pending');
  for (let i = 0; i < 3; i++) MC.dispatch(G, { type:'resolveDiscardChoose', player: pl.uid, uid: pl.hand[0].uid });
  assert(pl.hand.length === 3 && G.encounterDiscard.includes(mot) && !G.pending, '03026 — 3장 버림 + 의무 순환(버린더미)');

  // C: 신분 소진 → exhaust 옵션 숨김 (availableIf)
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true }); pl.exhausted = true;
  mot = MC.makeInstance(G, 'man-out-of-time', {}); mot.ownerUid = pl.uid; G.encounterDiscard.push(mot);
  MC.fireCardHook(G, mot, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', player: pl.uid, option:'noflip' });
  assert(!G.pending.options.some(o => o.key === 'exhaust') && G.pending.options.some(o => o.key === 'discardHalf'),
    '03026 — 신분 소진 시 exhaust 옵션 숨김');
}

/* 03027 Hit Squad — 사이드 스킴, 공개 시 각 플레이어 조우덱 top 버림 + 부스트 아이콘당 피해 */
{
  const d = MC.cardDef('hit-squad');
  assert(!d.todoFx && d.whenRevealedEffects[0].fx === 'eachPlayerDiscardEncounterBoostDamage', '03027 — eachPlayerDiscardEncounterBoostDamage 배선');
  assert(typeof MC.EFFECTS.eachPlayerDiscardEncounterBoostDamage === 'function', '03027 — 범용 EFFECT 존재');
  assert(d.type === 'side_scheme' && d.baseThreatPerPlayer === 3 && d.accelIcons === 1, '03027 — 사이드스킴/위협3/가속1');

  const G = mkCap(); const pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const ua = MC.makeInstance(G, 'under-attack', {}); G.encounterDeck.push(ua);   // boost 3 (top)
  const hp0 = pl.hp; const dlen0 = G.encounterDeck.length;
  const hs = MC.makeInstance(G, 'hit-squad', {}); G.sideSchemes.push(hs);
  MC.fireCardHook(G, hs, 'whenRevealed', { player: pl });
  assert(G.encounterDeck.length === dlen0 - 1, '03027 — 조우덱 top 1장 버림');
  assert(pl.hp === hp0 - 3, '03027 — 버린 카드 부스트 아이콘(3)만큼 피해');
  assert(G.encounterDiscard.some(c => c.uid === ua.uid), '03027 — 버린 카드 조우 버린더미로');
}

/* 03028 Baron Zemo — 하수인, quickstrike + 교전 중 저지 불가 */
{
  const d = MC.cardDef('baron-zemo');
  assert(!d.todoFx && d.quickstrike === true && d.whileEngagedCannotThwart === true, '03028 — quickstrike+whileEngagedCannotThwart 데이터');
  assert(d.attack === 3 && d.scheme === 1 && d.hp === 5, '03028 — 스탯 ATK3/SCH1/HP5');
  assert(typeof MC.hasCannotThwartEngaged === 'function', '03028 — hasCannotThwartEngaged 헬퍼');

  const G = mkCap(); const pl = G.players[0]; MC.flipForm(G, pl, { force:true }); pl.exhausted = false;
  const zemo = MC.makeInstance(G, 'baron-zemo', {}); zemo.engagedWith = pl.uid; pl.engagedMinions.push(zemo);
  assert(MC.hasCannotThwartEngaged(G, pl) === true, '03028 — 교전 중 저지 불가 판정');
  let blocked = false;
  try { MC.dispatch(G, { type:'basicThwart', player: pl.uid, scheme:'main' }); } catch(e){ blocked = /저지/.test(e.message); }
  assert(blocked, '03028 — 교전 중 메인 스킴 저지 차단');
  zemo.hp = 0;
  assert(MC.hasCannotThwartEngaged(G, pl) === false, '03028 — 처치(hp0) 후 저지 가능');
}

/* 03030 Hail Hydra! — 배신, Hydra 하수인 교전 시 공격 / 공격 안 받은 각 플레이어 증원 */
{
  const d = MC.cardDef('hail-hydra');
  assert(!d.todoFx && d.whenRevealedEffects[0].fx === 'minionsAttack' && d.whenRevealedEffects[0].reinforceUnattacked === true, '03030 — minionsAttack+reinforceUnattacked 배선');

  // A: Hydra 하수인 교전 → 공격 (방어 pending)
  let G = mkCap(); let pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const hs = MC.makeInstance(G, 'hydra-soldier', {}); hs.engagedWith = pl.uid; pl.engagedMinions.push(hs);
  const hh = MC.makeInstance(G, 'hail-hydra', {}); G.encounterDiscard.push(hh);
  MC.fireCardHook(G, hh, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'defense', '03030 — Hydra 교전 중 → 공격(방어 pending)');

  // B: Hydra 하수인 없음 → 증원 탐색 배치 (조우덱/버림의 아무 Hydra 하수인)
  G = mkCap(); pl = G.players[0]; MC.flipForm(G, pl, { force:true });
  const seed = MC.makeInstance(G, 'hydra-soldier', {}); G.encounterDeck.push(seed);
  const eng0 = pl.engagedMinions.length;
  const hh2 = MC.makeInstance(G, 'hail-hydra', {}); G.encounterDiscard.push(hh2);
  MC.fireCardHook(G, hh2, 'whenRevealed', { player: pl });
  const reinforced = pl.engagedMinions.find(m => (MC.cardDef(m.defCode).traits || []).includes('hydra'));
  assert(pl.engagedMinions.length > eng0 && reinforced, '03030 — 공격 안 받은 플레이어 Hydra 증원 배치');
}

/* 03033 Expert Defense — 방어 이벤트: 방어 중 DEF +3 (= 피해 3 방지 등가) */
{
  const d = MC.cardDef('expert-defense');
  assert(!d.todoFx && d.effects && d.effects[0].fx === 'preventAmount' && d.effects[0].amount === 3,
    '03033 — preventAmount 3 배선 (DEF+3 등가) + todoFx 제거');
  assert((d.traits || []).includes('defense'), '03033 — defense 트레잇 (방어 pending 중 플레이 가능)');

  // 방어 pending에서 effects 실행 → prevented 3 누적
  const G = mkCap(); const pl = G.players[0]; if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true });
  G.pending = { kind:'defense', player: pl.uid };
  const ed = MC.makeInstance(G, 'expert-defense', {});
  MC.runEffectList(G, d.effects, { player: pl, card: ed });
  assert(G.pending && G.pending.prevented === 3, '03033 — 방어 중 피해 3 방지 예약');

  // 방어 상황 아니면 무효 (안전)
  const G2 = mkCap(); const pl2 = G2.players[0]; G2.pending = null;
  const ed2 = MC.makeInstance(G2, 'expert-defense', {});
  MC.runEffectList(G2, d.effects, { player: pl2, card: ed2 });
  assert(!G2.pending, '03033 — 방어 상황 아니면 조용히 무효(무변이)');
}

/* 03034 Enhanced Awareness — 업그레이드: 멘탈 카운터 3, 소진+카운터1 제거 → 멘탈 자원 1 */
{
  const d = MC.cardDef('enhanced-awareness');
  assert(!d.todoFx && d.uses === 3, '03034 — uses 3 (멘탈 카운터) + todoFx 제거');
  const rg = d.resourceGenerator;
  assert(rg && rg.form === 'hero' && rg.exhaust === true && rg.counter === 1 && rg.icons.mental === 1,
    '03034 — resourceGenerator: 히어로폼·소진·카운터1·멘탈1 (web-shooter 인덱스 재사용)');
}

console.log('\n[test_cap_cards_reverify] ' + pass + '개 통과 — 캡아 팩 카드 재검증');
