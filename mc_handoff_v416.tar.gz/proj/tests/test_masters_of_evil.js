/* test_masters_of_evil.js — 악의 지배자들(01128) 사이드 스킴 회귀
   ★ 완전 인덱스 타입: 신규 범용 EFFECTS.discardUntilMinion(trait) + playVfx + whenCompleted.
   - 공개 시 위협: 인원수당 3 (솔로 3, 2인 6)
   - 공개 시: 조우덱에서 Masters of Evil 하수인 나올 때까지 버림 → 첫 플레이어 교전 배치
     (비-MoE 하수인/배신은 버려지고 지나감, MoE 하수인 부재 시 안전 불발)
   - 가속 아이콘 1 (진짜 가속 — v162 사이드 스킴 가속 반영)
   - 완성 시: 해산 연출/대사
   사용: node tests/test_masters_of_evil.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed, np){
  const players = [];
  for (let i = 0; i < np; i++) players.push({ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() });
  const G = MC.makeGameState({ seed, players, villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
// 실제 공개 흐름 재현: baseThreat 세팅 → sideSchemes.push → whenRevealed
function revealMoE(G){
  const def = MC.cardDef('masters-of-evil-scheme');
  const inst = MC.makeInstance(G, 'masters-of-evil-scheme', {});
  inst.threat = (def.baseThreatPerPlayer||0) * G.players.length + (def.baseThreat||0);
  inst.peakThreat = inst.threat;
  inst.isMain = false;
  G.sideSchemes.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  return inst;
}
// 조우덱 재구성 (pop이므로 배열 마지막이 덱 맨 위)
function setEncDeck(G, codes){
  G.encounterDeck = codes.map(c => MC.makeInstance(G, c, {}));
  G.encounterDiscard = [];
}

// ① 공개 위협: 인원수당 3 + 가속 아이콘 정의 유지
{
  const G = mk(2801, 1);
  setEncDeck(G, ['melter']);
  const inst = revealMoE(G);
  assert(inst.threat === 3, '솔로: 시작 위협 3 (실제 ' + inst.threat + ')');
  assert(inst.accelIcons === 1, '가속 아이콘 1 (사이드 스킴 진짜 가속 — 인스턴스 복사)');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'mastersAssemble', '공개: 악당 집결 연출');
}
{
  const G = mk(2802, 2);
  setEncDeck(G, ['melter']);
  const inst = revealMoE(G);
  assert(inst.threat === 6, '2인: 시작 위협 6 (실제 ' + inst.threat + ')');
}

// ② 하수인 탐색: 비-MoE 카드(배신·타 특성 하수인)는 버려지고 MoE 하수인만 교전 배치
{
  const G = mk(2810, 1);
  // 덱 맨 위(pop)부터: im-tough(배신) → hydra-soldier(비-MoE 하수인) → melter(MoE) 순으로 나오도록
  setEncDeck(G, ['melter', 'hydra-soldier', 'im-tough']);
  const pl = G.players[0];
  const before = pl.engagedMinions.length;
  revealMoE(G);
  const eng = pl.engagedMinions[pl.engagedMinions.length - 1];
  assert(pl.engagedMinions.length === before + 1, 'MoE 하수인 1명 교전 배치');
  assert(eng && eng.defCode === 'melter', '교전 하수인 = 멜터 (MoE 특성 일치)');
  assert(G.encounterDiscard.some(c => c.defCode === 'hydra-soldier'), '비-MoE 하수인(히드라 병사)은 버려짐');
  assert(G.encounterDiscard.some(c => c.defCode === 'im-tough'), '배신 카드는 버려짐');
  assert(!G.encounterDiscard.some(c => c.defCode === 'melter'), '멜터는 버림 더미가 아닌 전장에');
}

// ③ MoE 하수인 부재: 전량 버림 후 안전 불발 (크래시 없음)
{
  const G = mk(2815, 1);
  setEncDeck(G, ['im-tough', 'im-tough']);
  const pl = G.players[0];
  const before = pl.engagedMinions.length;
  revealMoE(G);
  assert(pl.engagedMinions.length === before, 'MoE 부재: 교전 하수인 없음 (안전 불발)');
}

// ④ 완성(위협 제거로 격퇴) → whenCompleted 해산 연출 + sideSchemes에서 제거
{
  const G = mk(2820, 1);
  setEncDeck(G, ['melter']);
  const inst = revealMoE(G);
  G.fxCardEffect = null;
  MC.removeThreat(G, inst.uid, 99);
  assert(inst.threat === 0, '완성: 위협 0으로 제거');
  assert(!G.sideSchemes.includes(inst), '완성: sideSchemes에서 격퇴 제거');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'mastersScatter', '완성: 연합 해산 연출');
}

console.log('══ 악의 지배자들 (discardUntilMinion 인덱스) 회귀 통과 ══');
