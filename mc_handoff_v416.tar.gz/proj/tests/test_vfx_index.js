/* test_vfx_index.js — 연출/대사 인덱스 무결성
   카드 정의의 vfx.* 이름 → MC.VFX 등록 여부, quoteKey → MC.QUOTES 등록 여부.
   대사는 종류당 최소 10개 규칙 (사용자 요구 사양).
   사용: node tests/test_vfx_index.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
global.window = global;
global.document = {
  addEventListener(){}, getElementById(){ return null }, querySelector(){ return null },
  querySelectorAll(){ return [] }, createElement(){ return { style:{}, classList:{add(){},remove(){}}, appendChild(){}, remove(){} } },
  body:{ appendChild(){} },
};
global.localStorage = { getItem(){return null}, setItem(){}, removeItem(){} };
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
require(path.join(ROOT, 'ui/mc_vfx.js'));
const MC = globalThis.MC;

let bad = 0, linked = 0;
for (const code in MC.CARDS){
  const c = MC.CARDS[code];
  if (c.vfx){
    for (const slot in c.vfx){
      linked++;
      if (!MC.VFX[c.vfx[slot]]){
        console.error(`✗ ${code} ${c.name}: 미등록 VFX '${c.vfx[slot]}' (${slot})`); bad++;
      }
    }
  }
  if (c.quoteKey){
    linked++;
    const q = MC.QUOTES[c.quoteKey];
    if (!q){ console.error(`✗ ${code} ${c.name}: 미등록 quoteKey '${c.quoteKey}'`); bad++; }
    else for (const kind in q){
      // 빌런 핵심 대사(등장/페이즈전환/패배)는 최소 10개, 부착 등 보조 대사는 최소 5개
      const coreKinds = { entrance:1, stageUp:1, defeat:1 };
      const min = coreKinds[kind] ? 10 : 5;
      if (q[kind].length < min){
        console.error(`✗ quotes '${c.quoteKey}.${kind}': ${q[kind].length}개 (최소 ${min}개 규칙)`); bad++;
      }
    }
  }
}
// 하수인 대사 세트 검증: minion defCode를 키로 갖는 QUOTES 항목은 enter/attack/defeat 각 5개.
// (하수인은 quoteKey 필드 없이 defCode 자체를 대사 키로 사용 — 이 관례를 여기서 강제)
for (const key in MC.QUOTES){
  const cd = MC.CARDS[key];
  if (!cd || cd.type !== 'minion') continue;   // 하수인 defCode 키만 대상
  const q = MC.QUOTES[key];
  for (const kind of ['enter','attack','defeat']){
    if (!q[kind] || q[kind].length < 5){
      console.error(`✗ 하수인 대사 '${key}.${kind}': ${q[kind]?q[kind].length:0}개 (최소 5개 규칙)`); bad++;
    } else linked++;
  }
}
// 하수인 vfx.attack 연출 등록 여부 (위 c.vfx 루프에서 이미 검사되지만, 하수인 커버리지 명시)

console.log(`[test_vfx_index] 연출/대사 참조 ${linked}건 — 미등록/미달 ${bad}건`);
process.exit(bad === 0 ? 0 : 1);
