/* test_whiplash.js — 위플래시(01172) 하수인 회귀
   ★ Retaliate 1 (db 필드로 applyDamage 자동 처리) 검증.
   사용: node tests/test_whiplash.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 필드 확인
{
  const d = MC.cardDef('whiplash');
  assert(d.retaliate === 1, 'Retaliate 1');
  assert(d.attack === 3 && d.hp === 4, 'ATK 3 / HP 4');
}

// ② 공격받으면 공격자에게 반격 1 피해
{
  const G = mk(77001); const pl = G.players[0]; pl.form = 'hero';
  const w = MC.makeInstance(G, 'whiplash', {}); w.type = 'minion';
  w.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(w);
  const hp0 = pl.hp;
  // 히어로가 위플래시를 공격 (source=pl)
  MC.applyDamage(G, w, 2, { source: pl, byAttack: true });
  assert(pl.hp === hp0 - 1, 'Retaliate: 공격자(히어로)에게 1 반격 피해 (' + hp0 + '→' + pl.hp + ')');
}

// ③ 출처 없는 효과 피해(source 미지정)는 반격 없음
{
  const G = mk(77002); const pl = G.players[0]; pl.form = 'hero';
  const w = MC.makeInstance(G, 'whiplash', {}); w.type = 'minion';
  w.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(w);
  const hp0 = pl.hp;
  MC.applyDamage(G, w, 2, {});  // source 없음 = 반격 대상 없음
  assert(pl.hp === hp0, '출처 없는 피해는 반격 없음 (' + hp0 + ' 유지)');
}

console.log('══ 위플래시 (Retaliate 1) 회귀 통과 ══');
