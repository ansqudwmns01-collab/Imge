/* test_payment.js — 결제 요소 시스템 검증
   손패 결제·과학자 능력·수호의 힘 2배·초과 지불·구형 호환
   사용: node tests/test_payment.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

/* 테스트 전용 픽스처 덱 — 프리셋(게임 데이터)에 결합하지 않기 위한 범용 카드 풀.
   결제/페이즈 테스트가 꺼내 쓰는 카드(tackle, energy-barrier, power-of-protection 등) 포함. */
const FIXTURE_DECK = [
  'black-cat','black-widow-ally','mockingbird','nick-fury',
  'backflip','backflip',
  'enhanced-spider-sense','enhanced-spider-sense',
  'get-behind-me','get-behind-me','get-behind-me',
  'preemptive-strike','preemptive-strike','preemptive-strike',
  'swinging-web-kick','swinging-web-kick','swinging-web-kick',
  'tackle','tackle','tackle',
  'energy','genius','strength',
  'power-of-protection','power-of-protection',
  'aunt-may',
  'energy-barrier','energy-barrier','energy-barrier',
  'enhanced-awareness','enhanced-awareness',
  'indomitable','indomitable','indomitable',
  'spider-tracer','spider-tracer',
  'web-shooter','web-shooter',
  'webbed-up','webbed-up',
];

let fail = 0;
function check(name, ok, extra){ console.log((ok?'✓':'✗') + ' ' + name + (ok?'':('  ← '+(extra||'')))); if(!ok) fail++; }
function throws(name, fn, msgPart){
  try { fn(); check(name, false, 'throw 없음'); }
  catch(e){ check(name, !msgPart || e.message.includes(msgPart), e.message); }
}

function newGame(){
  const G = MC.makeGameState({
    seed: 5,
    players: [{ heroCode:'01001a', deckCodes: FIXTURE_DECK.slice() }],
    villainCode:'01094', mainScheme:'01097b',
    encounterCodes: MC.buildEncounter('rhino'),
  });
  MC.setupGame(G);
  return G;
}
function pull(G, pl, code){ // 덱에서 특정 카드를 손패로 끌어옴 (픽스처)
  const i = pl.deck.findIndex(c => c.defCode === code);
  if (i < 0) throw new Error('덱에 없음: ' + code);
  const c = pl.deck.splice(i,1)[0];
  pl.hand.push(c);
  return c;
}
function H(uid){ return { kind:'hand', uid }; }

/* ── 1. 기본 손패 결제 + 이중 자원 카드 ── */
{
  const G = newGame(); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true }); // 히어로 액션
  const kick = pull(G, pl, 'swinging-web-kick');   // 비용 3
  const genius = pull(G, pl, 'genius');            // 정신×2
  const tackle = pull(G, pl, 'tackle');            // 물리×1
  const hpB = G.villain.hp;
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid:kick.uid,
    payment:[H(genius.uid), H(tackle.uid)], targets:[G.villain.uid] });
  check('이중 자원(천재 2)+단일(1) = 3 결제 성공', G.villain.hp === hpB - 8, G.villain.hp);
  check('결제 카드 버림 확인', pl.discard.some(c=>c.uid===genius.uid) && pl.discard.some(c=>c.uid===tackle.uid));
}

/* ── 2. 과학자 능력: 정신 1, 알터에고 전용, 라운드 1회 ── */
{
  const G = newGame(); const pl = G.players[0];
  const barrier = pull(G, pl, 'energy-barrier');   // 비용 2 (보호)
  const back = pull(G, pl, 'backflip');            // 물리×1
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid:barrier.uid,
    payment:[H(back.uid), { kind:'ability', id:'scientist' }] });
  check('과학자(정신1)+손패1 = 2 결제 성공', pl.playArea.upgrades.length === 1);
  check('능력 라운드 플래그 세팅', pl.usedResourceAbilityThisRound === true);
  const b2 = pull(G, pl, 'energy-barrier');
  const t2 = pull(G, pl, 'tackle');
  throws('같은 라운드 과학자 재사용 거부', () => MC.dispatch(G, { type:'playCard', player:'P0',
    cardUid:b2.uid, payment:[H(t2.uid), { kind:'ability', id:'scientist' }] }), '이번 라운드');
  // 영웅 형태에선 사용 불가
  MC.dispatch(G, { type:'flipForm', player:'P0' });
  pl.usedResourceAbilityThisRound = false;
  throws('영웅 형태에서 과학자 거부', () => MC.dispatch(G, { type:'playCard', player:'P0',
    cardUid:b2.uid, payment:[H(t2.uid), { kind:'ability', id:'scientist' }] }), '능력');
  // (영웅면엔 능력 자체가 없어 '신분에 없는 능력'으로 거부 — 정상)
}

/* ── 3. 수호의 힘: 보호 카드 결제 시 2배 ── */
{
  const G = newGame(); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true }); // 히어로 액션(웹킥) 포함
  const barrier = pull(G, pl, 'energy-barrier');       // 비용 2, aspect protection
  const pop = pull(G, pl, 'power-of-protection');      // 와일드×1 → 보호 결제 시 2
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid:barrier.uid, payment:[H(pop.uid)] });
  check('수호의 힘 단독(2배=2)으로 보호 비용2 결제', pl.playArea.upgrades.length === 1);

  const kick = pull(G, pl, 'swinging-web-kick');       // 비용 3, aspect hero
  const pop2 = pull(G, pl, 'power-of-protection');     // 프리셋 ×2 중 남은 1장
  const tk = pull(G, pl, 'tackle');
  throws('비보호 카드엔 2배 미적용 (1+1=2 < 3)', () => MC.dispatch(G, { type:'playCard', player:'P0',
    cardUid:kick.uid, payment:[H(pop2.uid), H(tk.uid)], targets:[G.villain.uid] }), '자원 부족');
}

/* ── 4. 초과 지불 허용 + 요소 중복 거부 + 자원 카드 플레이 금지 ── */
{
  const G = newGame(); const pl = G.players[0];
  if (pl.form !== 'hero') MC.flipForm(G, pl, { force:true }); // 히어로 액션(웹킥) 포함
  const back = pull(G, pl, 'backflip');    // 비용 0
  const gen = pull(G, pl, 'genius');
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid:back.uid, payment:[H(gen.uid)] });
  check('초과 지불 허용 (0비용에 2 지불)', pl.discard.some(c=>c.uid===gen.uid));
  const tackle = pull(G, pl, 'tackle');
  const kick = pull(G, pl, 'swinging-web-kick');
  throws('요소 중복 거부', () => MC.dispatch(G, { type:'playCard', player:'P0', cardUid:kick.uid,
    payment:[H(tackle.uid), H(tackle.uid), H(tackle.uid)], targets:[G.villain.uid] }), '중복');
  const en = pull(G, pl, 'energy');
  throws('자원 카드 직접 플레이 금지', () => MC.dispatch(G, { type:'playCard', player:'P0',
    cardUid:en.uid, payment:[] }), '자원 카드');
}

/* ── 5. 구형 호환 (paymentUids) ── */
{
  const G = newGame(); const pl = G.players[0];
  const barrier = pull(G, pl, 'energy-barrier');
  const g = pull(G, pl, 'genius');
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid:barrier.uid, paymentUids:[g.uid] });
  check('구형 paymentUids 경로 동작', pl.playArea.upgrades.length === 1);
}

/* ── 6. 라운드 넘어가면 과학자 리셋 ── */
{
  const G = newGame(); const pl = G.players[0];
  pl.usedResourceAbilityThisRound = true;
  MC.dispatch(G, { type:'endPlayerPhase' });
  while (G.pending) MC.dispatch(G, { type:'resolveDefense', player:G.pending.player, defender:'none' });
  check('라운드 종료 후 자원 능력 리셋', pl.usedResourceAbilityThisRound === false);
}

console.log(fail === 0 ? '[test_payment] 전체 통과' : `[test_payment] 실패 ${fail}건`);
process.exit(fail === 0 ? 0 : 1);
