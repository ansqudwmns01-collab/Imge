/* test_ultrons_imperative.js — 울트론의 명령(01150) 사이드 스킴 회귀
   ★ spawnDrone scope:'firstPlayer' + count 확장 검증. hazard/시작위협.
   - 공개: 첫 플레이어가 덱 맨 위 2장을 뒷면 드론으로 스폰 · 시작 위협 2/인
   사용: node tests/test_ultrons_imperative.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 공개: 사이드 스킴 배치 + 시작 위협 2/인(1인=2) + 첫 플레이어 드론 2체 스폰
{
  const G = mk(22001); const pl = G.players[0];
  const deck0 = pl.deck.length;
  const ss = revealSide(G, pl, 'ultrons-imperative');
  assert(G.sideSchemes.some(s => s.uid === ss.uid), '울트론의 명령: 사이드 스킴 배치');
  assert(ss.threat === 2, '시작 위협 2/인 (1인=2, 실제 ' + ss.threat + ')');
  const drones = pl.engagedMinions.filter(m => m.isDrone);
  assert(drones.length === 2, '첫 플레이어 드론 2체 스폰 (실제 ' + drones.length + ')');
  assert(pl.deck.length === deck0 - 2, '덱 맨 위 2장 드론화');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'hiveImperative', '명령 하달 연출');
}

// ② firstPlayer scope: 공개자가 아니어도 첫 플레이어 대상 (1인이라 개념 검증 — spawnDrone 직접)
{
  const G = mk(22002); const pl = G.players[0];
  const deck0 = pl.deck.length;
  MC.runEffectList
    ? MC.runEffectList(G, [{ fx:'spawnDrone', scope:'firstPlayer', count:2, fallback:{attack:1,scheme:1,hp:1} }], { player: pl })
    : null;
  const drones = pl.engagedMinions.filter(m => m.isDrone);
  assert(drones.length === 2, 'spawnDrone firstPlayer count:2 → 첫 플레이어에 2체');
  assert(pl.deck.length === deck0 - 2, '덱 2장 소모');
}

// ③ hazard/시작위협 정의 유지
{
  const def = MC.cardDef('ultrons-imperative');
  assert(def.hazard === true, 'hazard(위험) 정의 유지');
  assert(def.baseThreatPerPlayer === 2, '시작 위협 per player 2 (정의 유지)');
}

// ④ 완성(whenCompleted) 연출 발화
{
  const G = mk(22004); const pl = G.players[0];
  const ss = revealSide(G, pl, 'ultrons-imperative');
  G.fxCardEffect = null;
  MC.fireCardHook(G, ss, 'whenCompleted', {});
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'hiveDisconnect', '완성: 명령망 차단 연출');
}

// ⑤ 덱 부족(1장) 시 안전 (있는 만큼만 스폰)
{
  const G = mk(22005); const pl = G.players[0];
  const keep = pl.deck.splice(0, pl.deck.length - 1);   // 덱 1장만, 버림 비움(리셔플 소스 有)
  pl.discard = [];
  revealSide(G, pl, 'ultrons-imperative');
  const drones = pl.engagedMinions.filter(m => m.isDrone);
  assert(drones.length >= 1, '덱 부족: 가능한 만큼 드론 스폰 (' + drones.length + '체)');
}

console.log('══ 울트론의 명령 (spawnDrone firstPlayer/count) 회귀 통과 ══');
