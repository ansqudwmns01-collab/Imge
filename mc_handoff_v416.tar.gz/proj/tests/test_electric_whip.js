/* test_electric_whip.js — 전기 채찍 공격(01173) 배신 회귀
   ★ amountFrom:'upgradeCount'(업그레이드 수만큼 피해) + discardControlledUpgrade(기존) 재사용.
   사용: node tests/test_electric_whip.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function addUpgrades(G, pl, n){
  for (let i = 0; i < n; i++){
    const u = MC.makeInstance(G, i % 2 ? 'panther-claws' : 'shuri', {});
    pl.playArea.upgrades.push(u);
  }
}

// ① damage 옵션: 업그레이드 3장 → 히어로 3 피해
{
  const G = mk(78001); const pl = G.players[0]; pl.form = 'hero';
  addUpgrades(G, pl, 3);
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'electric-whip-attack', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'damage' });
  assert(pl.hp === hp0 - 3, 'damage: 업그레이드 3장 → 3 피해 (' + hp0 + '→' + pl.hp + ')');
}

// ② discard 옵션: 업그레이드 1장 버림
{
  const G = mk(78002); const pl = G.players[0]; pl.form = 'hero';
  addUpgrades(G, pl, 3);
  const u0 = pl.playArea.upgrades.length;
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'electric-whip-attack', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'discard' });
  if (G.pending && G.pending.kind === 'pickControlledDiscard')   // 후보 2장+ → 플레이어 선택
    MC.ACTIONS.resolvePickControlledDiscard(G, { player: G.pending.player, uid: G.pending.cardUids[0] });
  assert(pl.playArea.upgrades.length === u0 - 1, 'discard: 업그레이드 1장 버림 (' + u0 + '→' + pl.playArea.upgrades.length + ')');
  assert(pl.hp === hp0, 'discard: 피해 없음');
}

// ③ 업그레이드 0장이면 damage 옵션은 0 피해
{
  const G = mk(78003); const pl = G.players[0]; pl.form = 'hero';
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'electric-whip-attack', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'damage' });
  assert(pl.hp === hp0, '업그레이드 0장: 0 피해');
}

// ④ 부스트★: 업그레이드 1장 버림
{
  const G = mk(78004); const pl = G.players[0]; pl.form = 'hero';
  addUpgrades(G, pl, 2);
  const u0 = pl.playArea.upgrades.length;
  const bc = MC.makeInstance(G, 'electric-whip-attack', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  if (G.pending && G.pending.kind === 'pickControlledDiscard')
    MC.ACTIONS.resolvePickControlledDiscard(G, { player: G.pending.player, uid: G.pending.cardUids[0] });
  assert(pl.playArea.upgrades.length === u0 - 1, '부스트★: 업그레이드 1장 버림');
}

console.log('══ 전기 채찍 공격 (upgradeCount + discardControlledUpgrade) 회귀 통과 ══');
