/* test_obligation_bp.js — 국정의 의무(01155) obligation 회귀
   ★ 신규: EFFECTS.discardControlledUpgrade / resolveObligation + offerChoice(기존) 연계.
   - exhaust 옵션: 티찰라 소진 + 게임에서 제거
   - discard 옵션: 블랙 팬서 업그레이드 1장 버림 + 의무 버림
   사용: node tests/test_obligation_bp.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['panther-claws','shuri','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 공개: 선택 pending (2옵션)
{
  const G = mk(60001); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'obligation-bp', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'revealChoice', '의무 공개 — 선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (소진/업그레이드 버림)');
}

// ② exhaust 옵션: 티찰라 소진 + 게임에서 제거
{
  const G = mk(60002); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'obligation-bp', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'exhaust' });
  assert(pl.exhausted === true, 'exhaust: 티찰라 소진');
  assert((G.removedFromGame || []).includes('obligation-bp'), 'exhaust: 게임에서 제거');
}

// ③ discard 옵션: 블랙 팬서 업그레이드 1장 버림 + 의무 버림
{
  const G = mk(60003); const pl = G.players[0]; pl.form = 'hero';
  // 블랙 팬서 업그레이드(팬서 발톱) 통제 상태로 배치
  const claws = MC.makeInstance(G, 'panther-claws', {}); claws.ownerUid = pl.uid;
  pl.playArea.upgrades.push(claws);
  const inst = MC.makeInstance(G, 'obligation-bp', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'discard' });
  assert(!pl.playArea.upgrades.some(u => u.uid === claws.uid), 'discard: 블랙 팬서 업그레이드 버림');
  assert((pl.discard || []).some(c => c.uid === claws.uid), '버린 더미로 이동');
  assert(pl.exhausted !== true, 'discard: 소진 안 함');
}

// ④ discard 옵션인데 업그레이드 없음: surge 획득
{
  const G = mk(60004); const pl = G.players[0]; pl.form = 'hero';
  const inst = MC.makeInstance(G, 'obligation-bp', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  const s0 = G.pendingSurge || 0;
  // discard 옵션에 surgeIfNoDiscard가 없으므로 순수 no-op — 카드 정의상 surge 없음(공식). no-op 확인
  MC.dispatch(G, { type:'resolveRevealChoice', option:'discard' });
  assert((G.removedFromGame || []).length === 0, '업그레이드 없음: 게임 제거 아님(discard 모드)');
}

console.log('══ 국정의 의무 (obligation) 회귀 통과 ══');
