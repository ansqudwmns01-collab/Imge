/* test_sonic_converter.js — 소닉 컨버터(01118) 클로 부착 무기 회귀
   ★ 완전 인덱스 타입(커스텀 핸들러 없음):
     ① 부착: whenRevealed 장착 연출  ② 강제반응: 클로 공격+피해 대상 기절
        (runAttachDamagedEffects + applyStatus target:'target')
     ③ 히어로 행동: ⚡🧠💪 각 1 지불 → 제거 (removeEnemyAttachment)
   사용: node tests/test_sonic_converter.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// 데이터 정합성 — ATK 보너스 없음(공식), 중복 stub 없음
assert(!MC.CARDS['sonic-converter'].todoFx, 'todoFx 해제');
assert(MC.CARDS['sonic-converter'].attack === undefined, 'ATK 보너스 없음 (공식 정정)');
assert(!MC.CARDS['01118'], '01118 중복 stub 제거됨');

// ① 부착 연출
{
  const G = mk(12001); const pl = G.players[0]; pl.form = 'hero';
  const sc = MC.makeInstance(G, 'sonic-converter', {});
  MC.attachTo(G, sc, G.villain);
  MC.fireCardHook(G, sc, 'whenRevealed', { player: pl });
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'sonicWeaponForge', '부착: 장착 연출');
  assert(G.villain.attachments.some(a => a.uid === sc.uid), '클로에 부착됨');
}

// ② 강제반응: 클로 공격+피해 → 대상 기절
{
  const G = mk(12002); const pl = G.players[0]; pl.form = 'hero';
  const sc = MC.makeInstance(G, 'sonic-converter', {}); MC.attachTo(G, sc, G.villain);
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: 2, stunOnHit:false, threatOnDamage:0 };
  const hp0 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp < hp0, '클로 공격 피해 적중');
  assert(pl.status.stunned === 1, '강제반응: 피해 대상 기절');
}
// 피해 0이면 기절 안 함 (공격이 피해를 줘야)
{
  const G = mk(12003); const pl = G.players[0]; pl.form = 'hero';
  const sc = MC.makeInstance(G, 'sonic-converter', {}); MC.attachTo(G, sc, G.villain);
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: 2, prevented: 999 };
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(!pl.status.stunned, '피해 0: 기절 안 함');
}

// ③ 히어로 행동 제거: ⚡🧠💪 각 1 지불 → 제거
{
  const G = mk(12004); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const sc = MC.makeInstance(G, 'sonic-converter', {}); MC.attachTo(G, sc, G.villain);
  // 자원 카드 3종 손에 넣고 지불
  const pay = [];
  for (const s of ['relentless-assault','tigra-ally','uppercut']){   // energy, mental, physical
    const c = MC.makeInstance(G, s, {}); c.ownerUid = pl.uid; pl.hand.push(c); pay.push({ kind:'hand', uid:c.uid });
  }
  MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: sc.uid, payment: pay });
  assert(!G.villain.attachments.some(a => a.uid === sc.uid), '히어로 행동: 부착물 제거됨');
  assert(G.encounterDiscard.some(c => c.uid === sc.uid), '제거된 부착물 버림 더미로');
}
// 자원 부족 시 거부
{
  const G = mk(12005); const pl = G.players[0]; pl.form = 'hero';
  const sc = MC.makeInstance(G, 'sonic-converter', {}); MC.attachTo(G, sc, G.villain);
  const c = MC.makeInstance(G, 'uppercut', {}); c.ownerUid = pl.uid; pl.hand.push(c);   // physical 1개만
  let threw = false;
  try { MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: sc.uid, payment:[{kind:'hand',uid:c.uid}] }); }
  catch(e){ threw = true; }
  assert(threw, '자원 부족(⚡🧠 누락): 제거 거부');
}

console.log('══ 소닉 컨버터 (인덱스 타입 부착 무기) 회귀 통과 ══');
