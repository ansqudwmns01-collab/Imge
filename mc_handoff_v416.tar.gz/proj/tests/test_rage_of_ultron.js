/* test_rage_of_ultron.js — 울트론의 분노(01145) 폼 분기 배신 회귀
   ★ 신규 범용: villainSchemes 위협 캡처(G._lastThreatPlaced), EFFECTS.discardTopDeck(amountFrom),
     villainAttacks discardDeckPerDamage(방어 해소 시 준 피해만큼 밀링), MC.discardTopOfDeck.
   - 알터에고: 울트론 암약(SCH만큼 위협) → 놓인 위협 수만큼 덱 밀링
   - 히어로: 울트론 공격 → 준 피해만큼 덱 밀링 (무방어=전량, 전량방지=0)
   사용: node tests/test_rage_of_ultron.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function fire(G, pl){
  const inst = MC.makeInstance(G, 'rage-of-ultron', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}

// ① 알터에고: 울트론 암약(SCH) → 그만큼 메인 위협 + 그만큼 덱 밀링
{
  const G = mk(17001); const pl = G.players[0]; pl.form = 'alter';
  const sch = G.villain.scheme || 0;
  assert(sch > 0, '전제: 울트론 SCH > 0 (' + sch + ')');
  const mt0 = MC.resolveScheme(G, 'main').threat;
  const deck0 = pl.deck.length, disc0 = pl.discard.length;
  fire(G, pl);
  assert(MC.resolveScheme(G, 'main').threat === mt0 + sch, '알터에고: 메인 위협 +' + sch + ' (암약)');
  assert(pl.deck.length === deck0 - sch, '알터에고: 놓인 위협 수(' + sch + ')만큼 덱 밀링');
  assert(pl.discard.length === disc0 + sch, '밀링 카드 버림 더미로');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'ultronRageScheme', '암약 분기 연출');
  assert(!G.pending, '알터에고: pending 없음 (즉시 완결)');
}

// ② 히어로 무방어: 울트론 공격 전량 → 준 피해만큼 밀링
{
  const G = mk(17002); const pl = G.players[0]; pl.form = 'hero';
  G.villain.attack = 3;   // 클로1단계 ATK0 → 공격 분기 검증용 세팅 (울트론 대체)
  const atk = G.villain.attack;
  fire(G, pl);
  assert(G.pending && G.pending.kind === 'defense', '히어로: 공격 방어 pending');
  assert(G.pending.discardDeckPerDamage === true, 'discardDeckPerDamage 플래그');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'ultronRageAttack', '공격 분기 연출');
  const hp0 = pl.hp, deck0 = pl.deck.length;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp0 - atk, '무방어: ATK ' + atk + ' 피해');
  assert(pl.deck.length === deck0 - atk, '준 피해(' + atk + ')만큼 덱 밀링');
}

// ③ 히어로 전량 방지: 피해 0 → 밀링 0
{
  const G = mk(17003); const pl = G.players[0]; pl.form = 'hero';
  fire(G, pl);
  G.pending.prevented = 999;   // 전량 방지
  const deck0 = pl.deck.length, hp0 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp0, '전량방지: 피해 0');
  assert(pl.deck.length === deck0, '피해 0: 밀링 0장');
}

// ④ 덱 소진 밀링: 리셔플 후 계속 (크래시 없음)
{
  const G = mk(17004); const pl = G.players[0]; pl.form = 'hero';
  G.villain.attack = 5;
  const atk = G.villain.attack;
  // 덱을 얇게, 버림 더미에 카드 채워 리셔플 가능하게
  const keep = pl.deck.splice(0, Math.max(0, pl.deck.length - 1));  // 덱 1장만 남김
  pl.discard.push(...keep);
  fire(G, pl);
  const total = pl.deck.length + pl.discard.length;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(!G.over || G.over, '덱 소진 밀링: 크래시 없이 처리');
  assert(pl.deck.length + pl.discard.length <= total + 2, '리셔플 반영 (인카운터 보충 허용)');
}

console.log('══ 울트론의 분노 (formBranch + 밀링 후속값 캡처) 회귀 통과 ══');
