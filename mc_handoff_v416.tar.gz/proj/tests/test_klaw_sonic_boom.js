/* test_klaw_sonic_boom.js — 소닉 붐(01123) 선택 배신 회귀
   ★ 커스텀 핸들러 없이 범용 인덱스(offerChoice/exhaustControlled/payIcons/playVfx)로 데이터 실행.
   1) 기반 이펙트 등록 (offerChoice/exhaustControlled/payIconsSatisfied)
   2) 공개 → revealChoice pending (선택지 pay/exhaust)
   3) 전체 소진 선택 → 히어로+동료 소진 + 연출
   4) payIconsSatisfied 다중 타입 요구(wild 유연 배정)
   사용: node tests/test_klaw_sonic_boom.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const deck = MC.PRESET_DECKS.spiderman.cards.slice();
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: deck }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
// 부스트★ 피해 검증용 — ATK1 클로II(01114)
function mk2(seed){
  const deck = MC.PRESET_DECKS.spiderman.cards.slice();
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: deck }],
    villainCode:'01114', mainScheme:'01097b', encounterCodes:['im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// 1) 기반 이펙트 등록
assert(typeof MC.EFFECTS.offerChoice === 'function', 'EFFECTS.offerChoice 등록 (선택 배신 데이터화)');
assert(typeof MC.EFFECTS.exhaustControlled === 'function', 'EFFECTS.exhaustControlled 등록 (히어로+동료 소진)');
assert(typeof MC.payIconsSatisfied === 'function', 'payIconsSatisfied 헬퍼 등록');

// 2) 공개 → revealChoice pending
{
  const G = mk(2401); const pl = G.players[0];
  const inst = MC.makeInstance(G, 'sonic-boom', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'revealChoice', '공개 → revealChoice 선택 pending');
  const keys = (G.pending.options || []).map(o => o.key);
  assert(keys.includes('pay') && keys.includes('exhaust'), '선택지 2종(pay/exhaust) 제시');
  const payOpt = G.pending.options.find(o => o.key === 'pay');
  assert(payOpt.payIcons && payOpt.payIcons.energy === 1 && payOpt.payIcons.mental === 1 && payOpt.payIcons.physical === 1,
    '자원 지불 선택지: ⚡🧠💪 각 1 요구 데이터');
}

// 3) 전체 소진 선택 → 히어로+동료 소진 + 연출
{
  const G = mk(2402); const pl = G.players[0];
  const inst = MC.makeInstance(G, 'sonic-boom', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  G.pending.selfUid = inst.uid;
  pl.exhausted = false;
  const ally = { uid:'ally-test', exhausted:false };
  pl.playArea.allies.push(ally);
  MC.ACTIONS.resolveRevealChoice(G, { option:'exhaust' });
  assert(pl.exhausted === true, '전체 소진: 히어로 소진');
  assert(ally.exhausted === true, '전체 소진: 동료 소진');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'sonicBoomBlast', '전체 소진: 음파 폭발 연출(sonicBoomBlast)');
  assert(!G.pending, '선택 해소 후 pending 해제');
}

// 4) payIconsSatisfied 다중 타입 요구 (wild 유연 배정)
{
  const req = { energy:1, mental:1, physical:1 };
  assert(MC.payIconsSatisfied({ energy:1, mental:1, physical:1 }, req) === true, 'payIcons: 정확 지불 충족');
  assert(MC.payIconsSatisfied({ wild:3 }, req) === true, 'payIcons: wild 3으로 유연 충족');
  assert(MC.payIconsSatisfied({ energy:1, wild:2 }, req) === true, 'payIcons: 혼합(e1+wild2) 충족');
  assert(MC.payIconsSatisfied({ energy:1, mental:1 }, req) === false, 'payIcons: physical 부족 → 불충족');
  assert(MC.payIconsSatisfied({ energy:1, wild:1 }, req) === false, 'payIcons: wild 1로 2개 못메움 → 불충족');
}

// 5) 부스트★ — 소닉 붐이 빌런 공격 부스트로 뒤집혀 피해를 주면 히어로 소진 (피해 조건부)
{
  const G = mk2(2511); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const boostCard = MC.makeInstance(G, 'sonic-boom', {}); boostCard.boost = 1;
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: G.villain.attack || 0, boostCard };
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.exhausted === true, '부스트★: 피해 발생 → 히어로 소진');
}
{
  const G = mk2(2512); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const bc = MC.makeInstance(G, 'sonic-boom', {}); bc.boost = 1;
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: G.villain.attack || 0, boostCard: bc, prevented: 999 };
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.exhausted === false, '부스트★: 전량 방지(무피해) → 히어로 소진 안 됨');
}

console.log('══ 소닉 붐 (데이터 기반 선택 배신) 회귀 통과 ══');
