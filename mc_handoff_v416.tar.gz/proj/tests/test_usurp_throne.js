/* test_usurp_throne.js — 왕좌 찬탈(01156) 사이드 스킴 회귀
   ★ 지속 효과: 전장에 있는 동안 알터에고 전환 봉쇄(flipForm 가드 blocksAlterEgoFlip).
   사용: node tests/test_usurp_throne.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 공개: 사이드 스킴 배치 + 시작 위협 3/인
{
  const G = mk(61001); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'usurp-the-throne');
  assert(G.sideSchemes.some(s => s.uid === ss.uid), '왕좌 찬탈: 사이드 스킴 배치');
  assert(ss.threat === 3, '시작 위협 3/인 (1인)');
}

// ② 지속 효과: 히어로→알터에고 전환 봉쇄
{
  const G = mk(61002); const pl = G.players[0]; pl.form = 'hero'; pl.formChangedThisRound = false;
  revealSide(G, pl, 'usurp-the-throne');
  let blocked = false;
  try { MC.flipForm(G, pl); } catch(e){ blocked = true; }
  assert(blocked, '알터에고 전환 봉쇄됨');
  assert(pl.form === 'hero', '여전히 히어로 폼');
}

// ③ 강제 전환(이중인격)도 봉쇄
{
  const G = mk(61003); const pl = G.players[0]; pl.form = 'hero'; pl.formChangedThisRound = true;
  revealSide(G, pl, 'usurp-the-throne');
  let blocked = false;
  try { MC.flipForm(G, pl, { force: true }); } catch(e){ blocked = true; }
  assert(blocked, '강제 전환도 봉쇄됨');
}

// ④ 알터에고→히어로 복귀는 허용
{
  const G = mk(61004); const pl = G.players[0]; pl.form = 'alter-ego'; pl.formChangedThisRound = false;
  revealSide(G, pl, 'usurp-the-throne');
  MC.flipForm(G, pl);
  assert(pl.form === 'hero', '알터에고→히어로 복귀 허용');
}

// ⑤ 스킴 처치 후엔 전환 가능 (봉쇄 해제)
{
  const G = mk(61005); const pl = G.players[0]; pl.form = 'hero'; pl.formChangedThisRound = false;
  const ss = revealSide(G, pl, 'usurp-the-throne');
  // 사이드 스킴 제거 (처치 시뮬)
  G.sideSchemes = G.sideSchemes.filter(s => s.uid !== ss.uid);
  MC.flipForm(G, pl);
  assert(pl.form === 'alter-ego', '처치 후 알터에고 전환 가능');
}

console.log('══ 왕좌 찬탈 (알터에고 봉쇄) 회귀 통과 ══');
