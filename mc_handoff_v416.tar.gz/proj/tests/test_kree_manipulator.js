/* test_kree_manipulator.js — 크리 조종자(01178) 배신 회귀
   ★ placeThreat(메인 +1) + surge + 부스트★(메인 +1). 기존 이펙트 재사용.
   사용: node tests/test_kree_manipulator.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 공개: 메인 위협 +1 + surge
{
  const G = mk(83001); const pl = G.players[0]; pl.form = 'hero';
  const ms = G.mainScheme; const t0 = ms.threat || 0;
  const inst = MC.makeInstance(G, 'kree-manipulator', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert((ms.threat || 0) === t0 + 1, '메인 위협 +1 (' + t0 + '→' + ms.threat + ')');
  assert(inst.surge === true, 'surge 획득');
}

// ② 부스트★: 메인 위협 +1
{
  const G = mk(83002); const pl = G.players[0]; pl.form = 'hero';
  const ms = G.mainScheme; const t0 = ms.threat || 0;
  const bc = MC.makeInstance(G, 'kree-manipulator', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  assert((ms.threat || 0) === t0 + 1, '부스트★: 메인 위협 +1');
}

console.log('══ 크리 조종자 (위협 + surge) 회귀 통과 ══');
