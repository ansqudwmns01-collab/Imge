/* test_klaw_reverify.js — 클로 시나리오 실제 작동 재검증 (영구 회귀)
   ★ 매 게임 실행되는 빌런 단계/메인스킴 하수인 소환·인카운터 카드를 실제 dispatch로 검증.
   (표준셋 advance/assault 등은 test_rhino_reverify.js에서 이미 검증 — 공유)
   사용: node tests/test_klaw_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mkKlaw(hero){
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode: hero || '01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G);
  return G;
}
function reveal(G, pl, code){ const c = MC.makeInstance(G, code, {}); MC.fireCardHook(G, c, 'whenRevealed', { player: pl, self: c, card: c }); return c; }

/* 게임 시작 정상 */
{
  const G = mkKlaw();
  assert(G.villain.defCode === '01113' && G.encounterDeck.length > 0,
    '클로 — 게임 시작 정상 (빌런 01113 + 인카운터 덱)');
}

/* 빌런 단계 진행 — 일반: I→II→승리 (2스테이지) / 전문가: II→III→승리 */
{
  // 일반 모드 (01113=I 시작, 최종=II): I 처치 → II 진행 + 불멸의 클로, II(최종) 처치 → 승리
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero'; const ss0 = G.sideSchemes.length;
  G.villain.hp = 1;
  MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.villain.defCode === '01114', '클로 일반 — 1→2단계 전환(01114)');
  assert(G.sideSchemes.some(s => s.defCode === 'immortal-klaw') || G.sideSchemes.length > ss0,
    '클로 2단계 — 불멸의 클로 사이드 스킴 공개');
  G.villain.hp = 1;
  MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.over && G.over.result === 'win', '클로 일반 — II(최종) 처치 → 승리 (2스테이지 룰)');
}
{
  // 전문가 모드 (01114=II 시작, 최종=III): II 처치 → III 진행 + Tough, III(최종) 처치 → 승리
  const G = MC.makeGameState({ seed:1, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01114', mainScheme:'01116b', encounterCodes: MC.buildEncounter('klaw') });
  MC.setupGame(G); const pl = G.players[0]; pl.form = 'hero';
  assert(G.villain.defCode === '01114' && G.villainFinalStageNum === 3, '클로 전문가 — II 시작 + 최종 III');
  G.villain.hp = 1;
  MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.villain.defCode === '01115', '클로 전문가 — 2→3단계 전환(01115)');
  assert((G.villain.status.tough || 0) > 0, '클로 3단계 — 클로 Tough 획득');
  G.villain.status.tough = 0; G.villain.hp = 1;   // III는 Tough라 먼저 해제 후 처치
  MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.over && G.over.result === 'win', '클로 전문가 — III(최종) 처치 → 승리');
}

/* 메인 스킴 klawMainMinion — 공개 시 하수인 등장까지 인카운터 버림 */
{
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero'; const m0 = pl.engagedMinions.length;
  MC.fireCardHook(G, G.mainScheme, 'whenRevealed', { player: pl, self: G.mainScheme, card: G.mainScheme });
  assert(pl.engagedMinions.length > m0, '클로 메인 스킴 — 하수인 소환(discardUntilMinion)');
}

/* 클로 고유 인카운터 */
{
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero'; const hp0 = pl.hp;
  reveal(G, pl, 'klaw-vengeance');
  assert(pl.hp < hp0 || (G.pending && G.pending.kind === 'defense'), 'klaw-vengeance(히어로) — 빌런 공격');
}
{
  const G = mkKlaw(); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  if (pl.hand.length === 0) pl.hand.push(MC.makeInstance(G, 'energy', {}));
  const h1 = pl.hand.length; reveal(G, pl, 'klaw-vengeance');
  assert(pl.hand.length < h1, 'klaw-vengeance(알터에고) — 손패 버림');
}
{
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, 'sonic-boom');
  assert(G.pending && G.pending.kind === 'revealChoice', 'sonic-boom — 자원 지불 택 pending');
}
{
  const G = mkKlaw(); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  G.villain.hp = G.villain.maxHp - 6; const h0 = G.villain.hp;
  reveal(G, pl, 'sound-manipulation');
  assert(G.villain.hp > h0, 'sound-manipulation(알터에고) — 클로 회복');
}
{
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  MC.revealSpecificSideScheme(G, 'illegal-arms-factory');
  const ss = G.sideSchemes.find(s => s.defCode === 'illegal-arms-factory');
  assert(ss && ss.threat > 0, 'illegal-arms-factory — 사이드 스킴 시작 위협');
}
{
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  MC.revealSpecificSideScheme(G, 'defense-network');
  const ss = G.sideSchemes.find(s => s.defCode === 'defense-network');
  assert(ss && ss.threat > 0, 'defense-network — 사이드 스킴 시작 위협(perHero)');
}

/* 부착물 (빌런 부착) — 공개 무에러 */
['sonic-converter','solid-sound-body'].forEach(code => {
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, code);
  assert(true, code + ' — 부착 공개 무에러');
});

/* masters-of-evil 모듈러 세트 */
{
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  MC.revealSpecificSideScheme(G, 'masters-of-evil-scheme');
  assert(G.sideSchemes.some(s => s.defCode === 'masters-of-evil-scheme'), 'masters-of-evil-scheme — 사이드 스킴 공개');
}
{
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, 'masters-of-mayhem'); assert(true, 'masters-of-mayhem — whenRevealed 무에러');
}
/* masters 하수인 강제반응/인터럽트 발화 무에러 */
{ // radioactive-man 강제반응 — 손패 무작위 1장 버림 (데이터화: discardFromHand)
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  for (let i=0;i<3;i++) pl.hand.push(MC.makeInstance(G,'energy',{})); const h0 = pl.hand.length;
  const m = MC.makeInstance(G, 'radioactive-man', {}); m.engagedWith = pl.uid; pl.engagedMinions.push(m);
  MC.fireCardHook(G, m, 'forcedResponse', { player: pl, self: m, card: m, attacker: m, target: pl });
  assert(pl.hand.length === h0 - 1, 'radioactive-man — 강제반응 손패 1장 버림');
}
{ // tiger-shark 강제반응 — 자신에게 Tough (데이터화: applyStatus target:card)
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  const m = MC.makeInstance(G, 'tiger-shark', {}); m.engagedWith = pl.uid; pl.engagedMinions.push(m);
  MC.fireCardHook(G, m, 'forcedResponse', { player: pl, self: m, card: m, attacker: m, target: pl });
  assert((m.status.tough || 0) > 0, 'tiger-shark — 강제반응 자신 Tough');
}
{ // whirlwind 강제난입 — 발화 무에러
  const G = mkKlaw(); const pl = G.players[0]; pl.form = 'hero';
  const m = MC.makeInstance(G, 'whirlwind', {}); m.engagedWith = pl.uid; pl.engagedMinions.push(m);
  MC.fireCardHook(G, m, 'forcedInterrupt', { player: pl, self: m, card: m, attacker: m, target: pl });
  assert(true, 'whirlwind — forcedInterrupt 발화 무에러');
}

console.log('\n[test_klaw_reverify] ' + pass + '개 통과 — 클로 시나리오 재검증 완료');
