/* test_rhino_breakin.js — 침입 & 약탈(01107) 사이드 스킴 회귀
   ★ 범용 인덱스: placeThreat(scheme:'self', perHero) + playVfx + whenCompleted + hazard.
   - 공개 시: 시작 위협 2 + 인원수당 1 (솔로=3, 2인=4)
   - Hazard: 빌런 페이즈에 조우 카드 +1 (엔진 공용 dealEnc 처리)
   - 완성: 저지 연출/대사
   사용: node tests/test_rhino_breakin.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed, np){
  const players = [];
  for (let i = 0; i < np; i++) players.push({ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() });
  const G = MC.makeGameState({ seed, players, villainCode:'01094', mainScheme:'01097b', encounterCodes: Array(30).fill('im-tough') });
  MC.setupGame(G);
  return G;
}
function reveal(G){
  const def = MC.cardDef('breakin-and-takin');
  const inst = MC.makeInstance(G, 'breakin-and-takin', {});
  inst.threat = (def.baseThreatPerPlayer||0) * G.players.length + (def.baseThreat||0);
  inst.peakThreat = inst.threat; inst.isMain = false;
  G.sideSchemes.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  return inst;
}

// hazard 필드 선언
assert(MC.cardDef('breakin-and-takin').hazard === true, '위험(Hazard) 필드 선언');

// 공개 시 위협: 시작 2 + 인원수
{
  const G = mk(3201, 1);
  const inst = reveal(G);
  assert(inst.threat === 3, '솔로: 위협 2+1 = 3 (실제 ' + inst.threat + ')');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'rhinoRansack', '솔로: 약탈 연출(rhinoRansack)');
}
{
  const G = mk(3202, 2);
  const inst = reveal(G);
  assert(inst.threat === 4, '2인: 위협 2+2 = 4 (실제 ' + inst.threat + ')');
}

// Hazard: 빌런 페이즈 조우 카드 +1
function dealtCount(withHazard){
  const G = mk(withHazard?4001:4002, 1);
  if (withHazard){ const i = MC.makeInstance(G, 'breakin-and-takin', {}); i.threat=3; i.isMain=false; G.sideSchemes.push(i); }
  G.pendingEncounters = []; G.phase = 'villain'; G.villainStepMode = false; G.vq = [{ op:'dealEnc' }];
  MC.processVillainQueue(G);
  return G.pendingEncounters.length;
}
assert(dealtCount(false) === 1, 'Hazard 없음: 조우 카드 1장 (기본)');
assert(dealtCount(true) === 2, 'Hazard 있음: 조우 카드 2장 (기본1 + 위험1)');

// 완성(격퇴) → 저지 연출 + sideSchemes 제거
{
  const G = mk(3210, 1);
  const inst = reveal(G);
  G.fxCardEffect = null;
  MC.removeThreat(G, inst.uid, 99);
  assert(inst.threat === 0, '완성: 위협 0');
  assert(!G.sideSchemes.includes(inst), '완성: sideSchemes에서 격퇴');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'rhinoRansack', '완성: 저지 연출');
}

console.log('══ 침입 & 약탈 (데이터 사이드 스킴 + Hazard) 회귀 통과 ══');
