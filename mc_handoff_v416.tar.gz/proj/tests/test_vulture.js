/* test_vulture.js — 벌처(01167) 하수인 회귀
   ★ Quickstrike(교전 즉시 공격) def 기반 판정 + enemyAtk.
   사용: node tests/test_vulture.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 필드 확인
{
  const d = MC.cardDef('vulture');
  assert(d.quickstrike === true, 'quickstrike 플래그');
  assert(d.attack === 3 && d.hp === 4, 'ATK 3 / HP 4');
}

// ② 교전 시 즉시 공격 (Quickstrike → defense pending, amount = ATK 3)
{
  const G = mk(72001); const pl = G.players[0]; pl.form = 'hero';
  const v = MC.makeInstance(G, 'vulture', {});
  // 벌처를 조우로 공개 → 교전 + quickstrike
  G.pendingEncounters.push({ player: pl.uid, inst: v });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  assert(G.pending && G.pending.kind === 'defense', 'Quickstrike: 교전 즉시 공격 (defense pending)');
  assert(G.pending.amount === 3, 'defense amount = ATK 3');
  assert(G.pending.attackerUid === v.uid, '공격자 = 벌처');
}

// ③ 알터에고 폼이면 quickstrike 공격 안 함
{
  const G = mk(72002); const pl = G.players[0]; pl.form = 'alter-ego';
  const v = MC.makeInstance(G, 'vulture', {});
  G.pendingEncounters.push({ player: pl.uid, inst: v });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  assert(!(G.pending && G.pending.kind === 'defense'), '알터에고: quickstrike 공격 없음');
}

console.log('══ 벌처 (Quickstrike) 회귀 통과 ══');
