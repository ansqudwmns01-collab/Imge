/* test_immortal_klaw.js — 불멸의 클로(01127) 사이드 스킴 회귀
   ★ 완전 인덱스 타입: buffVillainHp(신규 범용). slug 'immortal-klaw' 정본(중복 the-immortal-klaw 제거).
   - 공개 시: 클로 HP +10
   - 스킴 해결(위협 제거, whenCompleted) 시: -10 (기존 whenDefeated 미발화 버그 수정)
   사용: node tests/test_immortal_klaw.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01116b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function reveal(G){
  const inst = MC.makeInstance(G, 'immortal-klaw', {});
  inst.threat = 3; inst.isMain = false;
  G.sideSchemes.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  return inst;
}

assert(!MC.CARDS['immortal-klaw'].todoFx, 'todoFx 해제');
assert(!MC.CARDS['the-immortal-klaw'], 'the-immortal-klaw 중복 stub 제거됨');

// 공개: 클로 HP +10
{
  const G = mk(14001);
  const hp0 = G.villain.hp, max0 = G.villain.maxHp;
  reveal(G);
  assert(G.villain.hp === hp0 + 10, '공개: 클로 현재 HP +10 (' + hp0 + '→' + G.villain.hp + ')');
  assert(G.villain.maxHp === max0 + 10, '공개: 클로 최대 HP +10');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'immortalKlawForm', '공개: 형태 복원 연출');
}

// 완성(위협 제거): 클로 HP -10 (버그 수정)
{
  const G = mk(14002);
  const hp0 = G.villain.hp, max0 = G.villain.maxHp;
  const inst = reveal(G);
  G.fxCardEffect = null;
  MC.removeThreat(G, inst.uid, 99);
  assert(G.villain.maxHp === max0, '완성: 클로 최대 HP 원상복구 (-10)');
  assert(G.villain.hp === hp0, '완성: 클로 현재 HP 원상복구');
  assert(!G.sideSchemes.includes(inst), '완성: 격퇴');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'immortalKlawShatter', '완성: 붕괴 연출');
}

// 클로가 HP 손상된 상태에서 완성 → 죽지 않고 상한만 감소
{
  const G = mk(14003);
  const inst = reveal(G);              // 예: 12→22
  G.villain.hp = 8;                    // 히어로가 공격해 8까지 깎음 (< 원래 max)
  MC.removeThreat(G, inst.uid, 99);    // 완성 → maxHp -10
  assert(G.villain.hp === 8, '손상 상태 완성: 현재 HP 8 유지 (상한만 감소, 죽지 않음)');
  assert(G.villain.hp > 0, '완성으로 클로가 죽지 않음');
}

console.log('══ 불멸의 클로 (인덱스 타입 buffVillainHp) 회귀 통과 ══');
