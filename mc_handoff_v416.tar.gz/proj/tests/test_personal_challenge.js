/* test_personal_challenge.js — 개인적 도전(01161) 사이드 스킴 회귀
   ★ crisis(메인 위협 제거 봉쇄) + whenRevealed 추가 위협 +1/인.
   사용: node tests/test_personal_challenge.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① crisis 필드 병합 확인
{
  const d = MC.cardDef('personal-challenge');
  assert(d.crisis === true, 'crisis 플래그 병합');
  assert(d.baseThreat === 3, '시작 위협 3 고정');
}

// ② 공개: 시작 3 + 추가 1/인 = 솔로 4
{
  const G = mk(66001); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'personal-challenge');
  assert(ss.threat === 4, '공개 위협 = 3 + 1/인 = 4 (솔로)');
  assert(MC.hasCrisisScheme(G) === true, 'crisis 스킴 전장 인식');
}

// ③ Crisis: 저지 이벤트로도 메인 위협 제거 불가
{
  const G = mk(66002); const pl = G.players[0]; pl.form = 'hero';
  revealSide(G, pl, 'personal-challenge');
  const ms = G.mainScheme; ms.threat = 5; const t0 = ms.threat;
  MC.runEffectList(G, [{ fx:'removeThreat', amount:3, scheme:'main' }], { player: pl, targetScheme:'main' });
  assert((ms.threat || 0) === t0, 'Crisis: 메인 위협 제거 봉쇄 (' + t0 + ' 유지)');
}

// ④ ignoreCrisis 저지는 통과
{
  const G = mk(66003); const pl = G.players[0]; pl.form = 'hero';
  revealSide(G, pl, 'personal-challenge');
  const ms = G.mainScheme; ms.threat = 5; const t0 = ms.threat;
  MC.runEffectList(G, [{ fx:'removeThreat', amount:3, scheme:'main', ignoreCrisis:true }], { player: pl, targetScheme:'main' });
  assert((ms.threat || 0) === t0 - 3, 'ignoreCrisis: 위협 제거 통과 (' + t0 + '→' + ms.threat + ')');
}

// ⑤ 사이드 스킴 자체 위협은 crisis와 무관하게 제거 가능
{
  const G = mk(66004); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'personal-challenge');
  const s0 = ss.threat;
  MC.runEffectList(G, [{ fx:'removeThreat', amount:2, scheme:ss.uid }], { player: pl });
  assert(ss.threat === s0 - 2, '사이드 스킴 자신 위협은 제거 가능 (' + s0 + '→' + ss.threat + ')');
}

// ⑥ 처치(위협 0) 후 crisis 해제 → 메인 제거 가능
{
  const G = mk(66005); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'personal-challenge');
  ss.threat = 0; // 처치 시뮬
  G.sideSchemes = G.sideSchemes.filter(s => s.threat > 0);
  assert(MC.hasCrisisScheme(G) === false, '처치 후 crisis 해제');
}

console.log('══ 개인적 도전 (Crisis + 추가 위협) 회귀 통과 ══');
