/* test_legions_of_hydra.js — Legions of Hydra(01180) 사이드 스킴 회귀
   ★ 신규 summonNamedMinionIfAbsent(마담 히드라 소환) + placeThreatPerEnemyTrait(히드라 적 ×2 위협).
   사용: node tests/test_legions_of_hydra.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 공개: 마담 히드라 소환 + 히드라 적 수(마담 1명) ×2 위협
{
  const G = mk(85001); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'legions-of-hydra-scheme');
  const madamePresent = pl.engagedMinions.some(m => (m.defCode || m.code) === 'madame-hydra');
  assert(madamePresent, '마담 히드라 소환 (전장 교전)');
  // 마담 히드라(hydra 트레잇) 1명 → 위협 2 추가. 시작 3 + 2 = 5
  assert(ss.threat === 3 + 2, '히드라 적 1명 × 2 → 시작 3 + 2 = 5 (실제 ' + ss.threat + ')');
}

// ② 마담 히드라 이미 전장이면 중복 소환 안 함
{
  const G = mk(85002); const pl = G.players[0]; pl.form = 'hero';
  const m0 = MC.makeInstance(G, 'madame-hydra', {}); m0.type = 'minion';
  pl.engagedMinions.push(m0);
  revealSide(G, pl, 'legions-of-hydra-scheme');
  const madameCount = pl.engagedMinions.filter(m => (m.defCode || m.code) === 'madame-hydra').length;
  assert(madameCount === 1, '마담 히드라 중복 소환 안 함 (1명 유지)');
}

// ③ 히드라 적 여럿이면 그만큼 위협 (마담 + 히드라 솔저 등)
{
  const G = mk(85003); const pl = G.players[0]; pl.form = 'hero';
  const m0 = MC.makeInstance(G, 'madame-hydra', {}); m0.type = 'minion'; pl.engagedMinions.push(m0);
  const s1 = MC.makeInstance(G, 'hydra-soldier', {}); s1.type = 'minion'; pl.engagedMinions.push(s1);
  const ss = revealSide(G, pl, 'legions-of-hydra-scheme');
  // 히드라 적 2명(마담+솔저) × 2 = 4. 시작 3 + 4 = 7
  assert(ss.threat === 3 + 4, '히드라 적 2명 × 2 → 시작 3 + 4 = 7 (실제 ' + ss.threat + ')');
}

console.log('══ Legions of Hydra (소환 + 히드라 적 ×2 위협) 회귀 통과 ══');
