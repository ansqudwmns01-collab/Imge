/* test_goblin_flip.js — 그린 고블린 Risky Business 폼전환 엔진 (영구 회귀)
   02006a Criminal Enterprise / 02006b State of Madness + 플립 코어 검증.
   사용: node tests/test_goblin_flip.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mkGG(nPlayers){
  const players = [];
  for (let i = 0; i < (nPlayers||2); i++) players.push({ heroCode:'01001a', deckCodes: Array(20).fill('energy') });
  const G = MC.makeGameState({ seed:5, players,
    villainCode:'02001a', mainScheme:'02004b', encounterCodes: [] });
  MC.setupGame(G);
  return G;
}

function mkFullRB(){
  const scen = MC.SCENARIOS.riskyBusiness;
  const G = MC.makeGameState({ seed:5, players:[{ heroCode:'01001a', deckCodes: Array(40).fill('energy') }],
    villainCode: scen.villainStart, mainScheme: scen.mainScheme,
    encounterCodes: MC.buildEncounter('riskyBusiness'), startEnvironment: scen.startEnvironment });
  MC.setupGame(G);
  return G;
}

/* 셋업: Criminal Enterprise 배치 + 악명 2×히어로 */
{
  const G = mkGG(2);
  const env = MC.goblinActiveEnv(G);
  assert(env && env.defCode === 'criminal-enterprise', '셋업 — Criminal Enterprise 전장 배치');
  assert(env.counters === 4, '셋업 — 악명 카운터 2×2히어로 = 4');
  assert(G.villain && G.villain.defCode === '02001a', '셋업 — 빌런 노먼 오스본(I)로 시작');

  // 3인 게임 = 6
  const G3 = mkGG(3);
  assert(MC.goblinActiveEnv(G3).counters === 6, '셋업 — 3인 게임 악명 6');
}

/* 카운터 add/remove (플립 미발생 구간) */
{
  const G = mkGG(2);
  MC.goblinAddCounter(G, 2);
  assert(MC.goblinActiveEnv(G).counters === 6, 'add — 악명 4→6');
  MC.goblinRemoveCounter(G, 2);
  assert(MC.goblinActiveEnv(G).counters === 4, 'remove — 악명 6→4 (플립 없음)');
  assert(G.villain.defCode === '02001a', 'remove — 아직 노먼 유지');
}

/* 악명 0 → 플립: 노먼→고블린, 환경 Criminal Enterprise→State of Madness, 광기 리셋 */
{
  const G = mkGG(2);
  const villainInst = G.villain;
  villainInst.hp = 5;   // 피해 누적 상태 (보존 확인용)
  MC.goblinRemoveCounter(G, 4);   // 악명 4→0 → 플립
  assert(G.villain.defCode === '02001b', '플립 — 노먼(02001a) → 그린 고블린(02001b)');
  assert(G.villain === villainInst, '플립 — 빌런 인스턴스 유지 (동일 객체)');
  assert(G.villain.hp === 5, '플립 — HP 보존 (피해 유지)');
  const env = MC.goblinActiveEnv(G);
  assert(env.defCode === 'state-of-madness', '플립 — 환경 → State of Madness');
  assert(env.counters === 4, '플립 — 광기 카운터 2×2히어로 = 4 리셋');
}

/* 광기 0 → 역플립: 고블린→노먼, State of Madness→Criminal Enterprise, 악명 리셋 */
{
  const G = mkGG(2);
  MC.goblinRemoveCounter(G, 4);   // → 고블린 + 광기 4
  assert(G.villain.defCode === '02001b', '역플립 준비 — 고블린 상태');
  MC.goblinRemoveCounter(G, 4);   // 광기 4→0 → 역플립
  assert(G.villain.defCode === '02001a', '역플립 — 고블린 → 노먼');
  const env = MC.goblinActiveEnv(G);
  assert(env.defCode === 'criminal-enterprise', '역플립 — 환경 → Criminal Enterprise');
  assert(env.counters === 4, '역플립 — 악명 4 리셋');
}

/* 넘치는 제거량은 0에서 멈춤 (음수 카운터 없음) */
{
  const G = mkGG(2);
  MC.goblinRemoveCounter(G, 99);   // 4개뿐 → 4 제거 후 플립
  assert(MC.goblinActiveEnv(G).counters === 4, '초과 제거 — 0 도달 후 플립·리셋 (음수 없음)');
  assert(G.villain.defCode === '02001b', '초과 제거 — 정상 플립');
}

/* ── 노먼 오스본 attackToCounter / damageToCounter (인덱스식) ── */
/* 데이터 배선 검증 (amount만 다른 인덱스식) */
{
  const d = MC.cardDef('02001a');
  assert(d.attackToCounter && d.attackToCounter.amount === 1 && d.damageToCounter === true && !d.todoFx,
    '02001a — attackToCounter{1} + damageToCounter 배선 + todoFx 해제');
  assert(MC.cardDef('02002a').attackToCounter.amount === 2 && MC.cardDef('02003a').attackToCounter.amount === 3,
    '02002a/02003a — attackToCounter 2/3 (인덱스식 amount)');
}
/* 노먼 피해 → 악명 제거(본체 무피해). applyDamage 경유 */
{
  const G = mkGG(2);   // 노먼(02001a) + 악명 4
  const v = G.villain; const hp0 = v.hp;
  const dealt = MC.applyDamage(G, v, 3, { source: G.players[0], isAttack:true });
  assert(dealt === 0 && v.hp === hp0, '노먼 피해 3 → 본체 무피해(HP 불변)');
  assert(MC.goblinActiveEnv(G).counters === 1, '노먼 피해 3 → 악명 4→1 제거');
  assert(v.defCode === '02001a', '악명 1 남음 → 아직 노먼');
  MC.applyDamage(G, v, 1, { source: G.players[0], isAttack:true });   // 악명 0 → 플립
  assert(v.defCode === '02001b', '악명 0 → 그린 고블린으로 플립');
  assert(MC.goblinActiveEnv(G).counters === 4, '플립 후 광기 4 리셋');
}
/* 노먼 공격 리다이렉트 = goblinAddCounter 경로 (add 테스트로 이미 E2E 검증됨).
   여기선 데이터 배선 + 방향성만 확인: 공격→add(증가), 피해→remove(감소·플립). */
{
  const G = mkGG(1);   // 1인 = 악명 2
  const before = MC.goblinActiveEnv(G).counters;   // 2
  MC.goblinAddCounter(G, MC.cardDef('02001a').attackToCounter.amount);   // 노먼 I 공격 = +1
  assert(MC.goblinActiveEnv(G).counters === before + 1, '노먼 I 공격량(1) → 악명 +1 (add 경로)');
  assert(!(G.pending && G.pending.kind === 'defense'), '공격 리다이렉트 — 방어 pending 없음');
}

/* ── 그린 고블린 schemeToCounter + When Revealed (플립 시 발화) ── */
/* 데이터 배선 검증 */
{
  const b1=MC.cardDef('02001b'), b2=MC.cardDef('02002b'), b3=MC.cardDef('02003b');
  assert(b1.schemeToCounter.amount===1 && b3.schemeToCounter.amount===2 && !b1.todoFx,
    '02001b/02003b — schemeToCounter 1/2 + todoFx 해제');
  assert(b1.whenRevealedEffects[0].fx==='damageEachHero' && b1.whenRevealedEffects[0].heroForm===true && b1.whenRevealedEffects[0].amount===3,
    '02001b — WR damageEachHero 3 heroForm(인덱스 재사용)');
  assert(b3.whenRevealedEffects[0].amount===4 && !b3.whenRevealedEffects[0].heroForm,
    '02003b — WR 각 플레이어 피해 4');
}
/* 플립 시 고블린 WR 발화 — 노먼→고블린 전환 순간 각 히어로 간접 3 */
{
  const G = mkGG(2);   // 노먼 + 악명 4, 두 플레이어
  for (const pl of G.players) if (pl.form!=='hero') MC.flipForm(G, pl, {force:true});
  const hp0 = G.players.map(pl=>pl.hp);
  MC.goblinRemoveCounter(G, 4);   // 악명 0 → 고블린 플립 → WR 발화
  assert(G.villain.defCode==='02001b', '플립 → 그린 고블린(I)');
  assert(G.players.every((pl,i)=>pl.hp===hp0[i]-3), '플립 WR — 히어로 폼 각 플레이어 간접 3 피해');
}
/* 고블린 스킴(알터에고 폼 상대) → 광기 제거. 광기 0 → 노먼 역플립 */
{
  const G = mkGG(1);
  MC.goblinRemoveCounter(G, 2);   // 1인 악명 2 → 0 → 고블린, 광기 2
  assert(G.villain.defCode==='02001b' && MC.goblinActiveEnv(G).counters===2, '고블린 전환 + 광기 2');
  // schemeToCounter 경로 = goblinRemoveCounter (스킴 대신 광기 제거)
  MC.goblinRemoveCounter(G, MC.cardDef('02001b').schemeToCounter.amount);   // 광기 2→1
  assert(MC.goblinActiveEnv(G).counters===1 && G.villain.defCode==='02001b', '고블린 스킴량(1) → 광기 -1');
  MC.goblinRemoveCounter(G, 1);   // 광기 0 → 역플립
  assert(G.villain.defCode==='02001a', '광기 0 → 노먼 역플립');
}

/* ── 공유 메커니즘: goblinCounter (악명 배치 / 불가 시 광기 제거) ── */
{
  // 노먼 면(Criminal Enterprise 활성) → 악명 +N
  const G = mkGG(2);   // 노먼 + 악명 4
  MC.goblinInfamyOrMadness(G, 1);
  assert(MC.goblinActiveEnv(G).defCode==='criminal-enterprise' && MC.goblinActiveEnv(G).counters===5,
    '공유 — 노먼 면: 악명 +1 (4→5)');
  // 고블린 면(State of Madness 활성) → 광기 -N
  const G2 = mkGG(2);
  MC.goblinRemoveCounter(G2, 4);   // 고블린으로 플립, 광기 4
  MC.goblinInfamyOrMadness(G2, 1); // 광기 -1
  assert(MC.goblinActiveEnv(G2).defCode==='state-of-madness' && MC.goblinActiveEnv(G2).counters===3,
    '공유 — 고블린 면: 광기 -1 (배치 불가 → 4→3)');
}
/* 부스트★/WR 데이터 배선 검증 */
{
  for (const s of ['hired-gun','private-security-specialist','collapsing-bridge','payoff']){
    const d=MC.cardDef(s);
    assert(d.boostStarEffects && d.boostStarEffects[0].fx==='goblinCounter' && d.boostStarEffects[0].amount===1,
      s+' — 부스트★ goblinCounter 1');
  }
  const t=MC.cardDef('all-in-a-days-work');
  assert(t.whenRevealedEffects[0].fx==='goblinCounter' && t.whenRevealedEffects[0].amount===2 && t.boostStarEffects[0].amount===1 && !t.todoFx,
    '02012 — WR 악명+2 / 부스트★ 악명+1 + todoFx 해제');
}

/* ── 메인 스킴 진행 + 폼 조건부 WR ── */
/* 02004b 완료 → 악명 1/히어로 배치 + 악명당 덱버림, 이어 2A→2B 진행 */
{
  const G = mkGG(2);   // 노먼 + 악명 4, 메인 02004b
  const ms = G.mainScheme;
  ms.threat = ms.maxThreat;   // 임계 도달
  const infamyBefore = MC.goblinActiveEnv(G).counters;
  MC.onMainSchemeThreshold(G, ms);   // 완료 → whenCompleted → advance
  // whenCompleted: 악명 +2(1×2히어로). advance로 2A→2B.
  assert(G.mainScheme.defCode === '02005b', '02004b 완료 → 2A 거쳐 2B로 진행');
}
/* 02005b(2B) 완료 → 플레이어 전원 패배 (nextStage 없음 → 자동) */
{
  const G = mkGG(1);
  // 강제로 메인스킴을 02005b로 전환
  MC.onMainSchemeThreshold(G, G.mainScheme);   // 1B→2A→2B 체인
  const ms2 = G.mainScheme;
  assert(ms2.defCode === '02005b', '2B 도달');
  ms2.threat = ms2.maxThreat;
  MC.onMainSchemeThreshold(G, ms2);   // 2B 완료 → 패배
  assert(G.over && G.over.result === 'loss' && G.over.cause === 'schemeComplete',
    '02005b 완료 → 플레이어 패배(setGameOver loss·schemeComplete)');
}
/* 02010 Oscorp Manufacturing — 노먼 면 WR: 이 스킴 +1/히어로 위협 / 고블린 면: 무효 */
{
  const G = mkGG(2);   // 노먼 면
  const ss = MC.makeInstance(G, 'oscorp-manufacturing', {});
  ss.threat = ss.threat || 0;
  const before = ss.threat;
  MC.fireCardHook(G, ss, 'whenRevealed', { player: G.players[0] });
  assert(ss.threat === before + 2, '02010 노먼 면 → 위협 +2 (1×2히어로)');

  const G2 = mkGG(2);
  MC.goblinRemoveCounter(G2, 4);   // 고블린 면으로 플립
  const ss2 = MC.makeInstance(G2, 'oscorp-manufacturing', {});
  const b2 = ss2.threat || 0;
  MC.fireCardHook(G2, ss2, 'whenRevealed', { player: G2.players[0] });
  assert((ss2.threat||0) === b2, '02010 고블린 면 → 위협 변화 없음(노먼 전용 WR)');
}
/* 02013 Mad Genius — 고블린 면: 최소HP 히어로 공격(방어 pending) / 노먼 면: 악명당 덱버림 */
{
  const G = mkGG(2);
  MC.goblinRemoveCounter(G, 4);   // 고블린 면
  for (const pl of G.players) if (pl.form!=='hero') MC.flipForm(G, pl,{force:true});
  G.players[1].hp = 3;   // 최소 HP
  const t = MC.makeInstance(G, 'mad-genius', {});
  MC.fireCardHook(G, t, 'whenRevealed', { player: G.players[0] });
  assert(G.pending && G.pending.kind==='defense' && G.pending.player===G.players[1].uid,
    '02013 고블린 면 → 최소HP 히어로(P2) 공격 pending');
}

/* 폼 전환 시 변신 연출 힌트(fxGoblinFlip) 설정 — UI가 goblinTransform 재생 */
{
  const G = mkGG(1);   // 노먼 + 악명 2
  MC.goblinRemoveCounter(G, 2);   // 악명 0 → 고블린 플립
  assert(G.fxGoblinFlip && G.fxGoblinFlip.dir==='toGoblin' && G.fxGoblinFlip.toCode==='02001b',
    '노먼→고블린 플립 → fxGoblinFlip(toGoblin) 힌트');
  const seq1 = G.fxGoblinFlip.seq;
  MC.goblinRemoveCounter(G, 4);   // 광기 0 → 노먼 역플립
  assert(G.fxGoblinFlip.dir==='toNorman' && G.fxGoblinFlip.seq!==seq1,
    '고블린→노먼 역플립 → fxGoblinFlip(toNorman) 힌트 갱신');
}

/* Risky Business 완전 플레이 검증 (staged 해제) — 셋업·플립·스테이지 진행·승리 */
{
  const scen = MC.SCENARIOS.riskyBusiness;
  assert(!scen.staged, 'Risky Business — staged 해제(완전 플레이 가능)');
  const G = mkFullRB();
  assert(G.villain.defCode === '02001a' && MC.goblinActiveEnv(G).defCode === 'criminal-enterprise',
    'RB 셋업 — 노먼 I + Criminal Enterprise 환경');
  // 악명 소진 → 고블린 I
  MC.applyDamage(G, G.villain, MC.goblinActiveEnv(G).counters, { source:G.players[0], isAttack:true });
  assert(G.villain.defCode === '02001b' && MC.goblinActiveEnv(G).defCode === 'state-of-madness', 'RB 플립 → 고블린 I + 광기 환경');
  // 일반 모드 = 2스테이지: 고블린 I 처치 → II 진행, II(최종) 처치 → 승리 (III로 안 넘어감)
  G.villain.hp = 1; MC.applyDamage(G, G.villain, 5, { source:G.players[0], isAttack:true });
  assert(G.villain.defCode === '02002b', 'RB 스테이지 진행(같은 면) → 02002b (고블린 II)');
  G.villain.hp = 1; MC.applyDamage(G, G.villain, 5, { source:G.players[0], isAttack:true });
  assert(G.over && G.over.result === 'win', 'RB 고블린 II(최종) 처치 → 승리 (일반 2스테이지 룰)');
}

console.log('\n[test_goblin_flip] ' + pass + '개 통과 — 그린 고블린 폼전환 엔진');
