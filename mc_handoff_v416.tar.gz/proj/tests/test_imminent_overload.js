/* test_imminent_overload.js — 임박한 과부하(01171) 사이드 스킴 회귀
   ★ whenRevealed 추가 위협 +1/인 + 가속 아이콘.
   사용: node tests/test_imminent_overload.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 필드 확인
{
  const d = MC.cardDef('imminent-overload');
  assert(d.baseThreat === 3, '시작 위협 3 고정');
  assert(d.accelIcons === 1, '가속 아이콘 1');
}

// ② 공개: 시작 3 + 추가 1/인 = 솔로 4
{
  const G = mk(76001); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'imminent-overload');
  assert(ss.threat === 4, '공개 위협 = 3 + 1/인 = 4 (솔로)');
}

// ③ 가속 아이콘이 빌런 페이즈 위협 상승에 반영 (전장 가속 합)
{
  const G = mk(76002); const pl = G.players[0]; pl.form = 'hero';
  revealSide(G, pl, 'imminent-overload');
  let sideAccel = 0;
  for (const s of (G.sideSchemes || [])){
    const sd = MC.cardDef(s.defCode);
    if (sd && sd.accelIcons) sideAccel += (sd.accelIcons === true ? 1 : sd.accelIcons);
  }
  assert(sideAccel >= 1, '전장 가속 아이콘 합 ≥ 1');
}

console.log('══ 임박한 과부하 (가속 사이드 스킴) 회귀 통과 ══');
