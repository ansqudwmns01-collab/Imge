/* test_captain_america_identity.js — 캡틴아메리카(03001a) + 스티브 로저스(03001b) 신분 능력 회귀
   ★ "하루 종일도 가능해!" — 행동: 손패 1장 버림 → 캡틴 준비(ready). 라운드당 1회.
   ★ 리빙 레전드 — 매 라운드 첫 동료 카드 비용 1 감소.
   ★ 셋업 — 덱/버림에서 캡틴아메리카의 방패(cap-shield) 손에 추가.
   사용: node tests/test_captain_america_identity.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  // 오프닝 핸드 후에도 덱 남도록 충분한 덱 (동료 agent-13 포함)
  const deckCodes = ['agent-13','fearless-determination','heroic-strike','shield-block','shield-toss',
    'steves-apartment','cap-helmet','cap-shield','super-soldier-serum','haymaker','first-aid','emergency','genius',
    'strength','energy','avengers-mansion','helicarrier'];
  const G = MC.makeGameState({ seed: seed || 1,
    players:[{ heroCode:'03001a', deckCodes }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 신분 def 능력 필드 등록
{
  const G = mk();
  const h = MC.cardDef('03001a'), ae = MC.cardDef('03001b');
  assert(h.identityAction && h.identityAction.discardCost === 1, '캡틴: identityAction discardCost 1');
  assert(h.identityAction.effect && h.identityAction.effect[0].fx === 'readySelf', '캡틴: 액션 효과 readySelf');
  assert(ae.livingLegend === true, '스티브: livingLegend 등록');
  assert(ae.onSetup === 'runCardEffects' && ae.onSetupEffects && ae.onSetupEffects[0].fx === 'searchDeckToHand'
    && ae.onSetupEffects[0].filters[0].mcode === '03009' && ae.onSetupEffects[0].includeDiscard === true,
    '스티브: onSetup 데이터화(searchDeckToHand mcode 03009 + 버림더미)');
}

// ② 셋업: 캡틴아메리카의 방패가 손에 추가됨
{
  const G = mk(); const pl = G.players[0];
  const hasShield = pl.hand.some(c => MC.cardDef(c.defCode).mcode === '03009');
  assert(hasShield, '셋업: 캡틴아메리카의 방패(cap-shield) 손에 추가됨');
  // 덱·버림에 방패가 중복 없이 손에만 있어야
  const inDeck = pl.deck.some(c => MC.cardDef(c.defCode).mcode === '03009');
  assert(!inDeck, '셋업: 방패가 덱에 남아있지 않음 (손으로 이동)');
}

// ③ "하루 종일도 가능해!": 소진 상태 → 손패 1장 버림 → 준비, 손패 -1
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  pl.exhausted = true;
  const handBefore = pl.hand.length;
  const discardBefore = pl.discard.length;
  const discardUid = pl.hand[0].uid;
  MC.dispatch(G, { type:'useIdentityAction', player:'P0', discard:[discardUid] });
  assert(pl.exhausted === false, '캡틴 액션: 소진 해제(준비됨)');
  assert(pl.hand.length === handBefore - 1, '캡틴 액션: 손패 1장 버림 (' + handBefore + '→' + pl.hand.length + ')');
  assert(pl.discard.length === discardBefore + 1, '캡틴 액션: 버림 더미 +1');
  assert(pl.usedIdentityActionThisRound[pl.form] === true, '캡틴 액션: 라운드당 1회 소모 (폼별)');
}
// ④ 라운드당 1회 제한
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = true;
  MC.dispatch(G, { type:'useIdentityAction', player:'P0', discard:[pl.hand[0].uid] });
  pl.exhausted = true;
  let blocked = false;
  try { MC.dispatch(G, { type:'useIdentityAction', player:'P0', discard:[pl.hand[0].uid] }); }
  catch(e){ blocked = true; }
  assert(blocked, '캡틴 액션: 같은 라운드 재사용 차단');
}

// ⑤ 리빙 레전드: 첫 동료 카드 비용 1 감소
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  pl.usedLivingLegendThisRound = false;
  // agent-13(동료)를 손에 확보
  let ally = pl.hand.find(c => c.defCode === 'agent-13');
  if (!ally){ const i = pl.deck.findIndex(c => c.defCode === 'agent-13'); if (i>=0){ ally = pl.deck.splice(i,1)[0]; pl.hand.push(ally); } }
  assert(!!ally, '리빙 레전드: 테스트용 동료(agent-13) 확보');
  const baseCost = MC.cardDef('agent-13').cost || 0;
  // 자원 충분히 확보 (손패에 자원카드 다수 push)
  for (let i=0;i<6;i++){ const e = MC.makeInstance(G, 'energy', {}); pl.hand.push(e); }
  const payUids = pl.hand.filter(c => c.defCode === 'energy').slice(0, Math.max(0, baseCost-1)).map(c => ({ kind:'hand', uid:c.uid }));
  const allyCountBefore = pl.playArea.allies.length;
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid: ally.uid, payment: payUids });
  assert(pl.playArea.allies.length === allyCountBefore + 1, '리빙 레전드: 첫 동료가 비용 -1로 플레이됨 (기본비용 ' + baseCost + ', 자원 ' + payUids.length + '개)');
  assert(pl.usedLivingLegendThisRound === true, '리빙 레전드: 라운드당 1회 소모 표시');
}

console.log('══ 캡틴아메리카 신분(액션·리빙레전드·방패셋업) 회귀 통과 ══');

/* 폼별 신분 액션 독립 추적 (알터에고 사용해도 히어로 액션 별도 가능) */
{
  const G = mk(); const pl = G.players[0];
  pl.usedIdentityActionThisRound = {};
  pl.usedIdentityActionThisRound['alter-ego'] = true;
  assert(!pl.usedIdentityActionThisRound['hero'], '폼별 신분액션: 알터에고 사용 후 히어로 폼 미사용 유지');
  pl.usedIdentityActionThisRound['hero'] = true;
  assert(pl.usedIdentityActionThisRound['alter-ego'] && pl.usedIdentityActionThisRound['hero'],
    '폼별 신분액션: 히어로/알터에고 독립 추적');
}
