/* test_shadow_of_the_past.js — Shadow of the Past(01190) 배신 회귀
   ★ 넴시스 셋어사이드 시스템: 하수인 교전 투입 + 사이드스킴 공개 + 나머지 조우덱 셔플.
   ★ 하수인 미등장(이미 전장) 시 surge.
   사용: node tests/test_shadow_of_the_past.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(heroCode, seed){
  const G = MC.makeGameState({ seed: seed || 1,
    players:[{ heroCode, deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function reveal(G, pl){
  const inst = MC.makeInstance(G, 'shadow-of-the-past', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}

// ① 셋업 시 넴시스 세트가 셋어사이드됨 (각 영웅)
{
  const heroes = {
    '01040a': { minion:'killmonger', ss:'usurp-the-throne', n:5 },
    '01019a': { minion:'titania', ss:'personal-challenge', n:5 },
    '01001a': { minion:'vulture', ss:'highway-robbery', n:5 },
    '01029a': { minion:'whiplash', ss:'imminent-overload', n:5 },
    '01010a': { minion:'yon-rogg', ss:'psyche-magnitron', n:5 },
  };
  for (const [code, exp] of Object.entries(heroes)){
    const G = mk(code);
    const aside = G.players[0].nemesisSetAside || [];
    assert(aside.length === exp.n, code + ': 셋어사이드 ' + exp.n + '장 (실제 ' + aside.length + ')');
    assert(aside.some(c => c.defCode === exp.minion && c._nemesisRole === 'minion'), code + ': 하수인 ' + exp.minion);
    assert(aside.some(c => c.defCode === exp.ss && c._nemesisRole === 'sideScheme'), code + ': 사이드스킴 ' + exp.ss);
  }
}

// ② 공개 시: 하수인 교전 투입 + 사이드스킴 공개 + 나머지 조우덱 셔플
{
  const G = mk('01040a'); const pl = G.players[0]; pl.form = 'hero';
  const deck0 = G.encounterDeck.length;
  const inst = reveal(G, pl);
  assert(pl.engagedMinions.some(m => m.defCode === 'killmonger'), '킬몽거 교전 투입');
  assert((G.sideSchemes || []).some(s => s.defCode === 'usurp-the-throne'), '왕좌 찬탈 사이드스킴 공개');
  assert(G.encounterDeck.length === deck0 + 3, '나머지 3장 조우덱 셔플 (' + deck0 + '→' + G.encounterDeck.length + ')');
  assert((pl.nemesisSetAside || []).length === 0, '셋어사이드 비워짐');
  assert(inst.surge !== true, '하수인 등장 → surge 없음');
}

// ③ 이미 넴시스 하수인이 전장에 있으면 재투입 안 함 → surge
{
  const G = mk('01040a'); const pl = G.players[0]; pl.form = 'hero';
  // 먼저 킬몽거를 전장에 배치
  const km = MC.makeInstance(G, 'killmonger', {}); km.type = 'minion';
  km.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(km);
  const inst = reveal(G, pl);
  const kmCount = pl.engagedMinions.filter(m => m.defCode === 'killmonger').length;
  assert(kmCount === 1, '킬몽거 중복 투입 안 함 (1명 유지)');
  assert(inst.surge === true, '하수인 미등장 → surge');
}

// ④ 넴시스 없는 영웅(매핑 없음)은 셋어사이드 없음 → 안전 처리
{
  // 넴시스 매핑에 없는 영웅으로 테스트 (스파이더맨 외 임의 영웅이 없다면 스킵)
  const noNemesis = Object.keys(MC.CARDS).find(k => {
    const d = MC.CARDS[k];
    return d.type === 'hero' && !MC.NEMESIS_BY_HERO[k];
  });
  if (noNemesis){
    const G = mk(noNemesis);
    const pl = G.players[0]; pl.form = 'hero';
    assert((pl.nemesisSetAside || []).length === 0, noNemesis + ': 넴시스 없음 → 셋어사이드 0');
    const inst = reveal(G, pl);
    assert(inst.surge === true, '넴시스 없으면 하수인 미등장 → surge');
  } else { console.log('✓ (넴시스 없는 영웅 없음 — 스킵)'); }
}

console.log('══ Shadow of the Past (넴시스 세트 투입) 회귀 통과 ══');
