/* test_klaw_arms_factory.js — 불법 무기 공장(01126) 사이드 스킴 회귀
   ★ 범용 인덱스로 데이터화: placeThreat(scheme:'self', perHero) + playVfx + whenCompleted.
   - 공개 시: 시작 위협 3 + 인원수당 1 (솔로=4, 3인=6)
   - 완성 시(위협 제거로 격퇴): 폐쇄 연출/대사
   사용: node tests/test_klaw_arms_factory.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed, np){
  const players = [];
  for (let i = 0; i < np; i++) players.push({ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() });
  const G = MC.makeGameState({ seed, players, villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
// 실제 공개 흐름 재현: baseThreat 세팅 → sideSchemes.push → whenRevealed
function revealFactory(G){
  const def = MC.cardDef('illegal-arms-factory');
  const inst = MC.makeInstance(G, 'illegal-arms-factory', {});
  inst.threat = (def.baseThreatPerPlayer||0) * G.players.length + (def.baseThreat||0);
  inst.peakThreat = inst.threat;
  inst.isMain = false;
  G.sideSchemes.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  return inst;
}

// 공개 시 위협: 시작 3 + 인원수×1
{
  const G = mk(2701, 1);
  const inst = revealFactory(G);
  assert(inst.threat === 4, '솔로: 시작 위협 3 + 1 = 4 (실제 ' + inst.threat + ')');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'armsFactoryActivate', '솔로: 공장 가동 연출');
}
{
  const G = mk(2703, 3);
  const inst = revealFactory(G);
  assert(inst.threat === 6, '3인: 시작 위협 3 + 3 = 6 (실제 ' + inst.threat + ')');
}

// 완성(위협 제거로 격퇴) → whenCompleted 폐쇄 연출 + sideSchemes에서 제거
{
  const G = mk(2710, 1);
  const inst = revealFactory(G);         // 위협 4
  G.fxCardEffect = null;
  MC.removeThreat(G, inst.uid, 99);      // 전량 제거 → onSideSchemeCleared → whenCompleted
  assert(inst.threat === 0, '완성: 위협 0으로 제거');
  assert(!G.sideSchemes.includes(inst), '완성: sideSchemes에서 격퇴 제거');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'armsFactoryShutdown', '완성: 공장 폐쇄 연출');
}

console.log('══ 불법 무기 공장 (데이터 기반 사이드 스킴) 회귀 통과 ══');
