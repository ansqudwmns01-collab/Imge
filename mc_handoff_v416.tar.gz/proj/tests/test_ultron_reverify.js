/* test_ultron_reverify.js — 울트론 시나리오 실제 작동 재검증 (영구 회귀)
   ★ 드론 소환·빌런 단계·드론 중심 인카운터를 실제 dispatch로 검증.
   사용: node tests/test_ultron_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mkUltron(hero){
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode: hero || '01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01134', mainScheme:'01137b', encounterCodes: MC.buildEncounter('ultron') });
  MC.setupGame(G);
  return G;
}
function reveal(G, pl, code){ const c = MC.makeInstance(G, code, {}); MC.fireCardHook(G, c, 'whenRevealed', { player: pl, self: c, card: c }); return c; }

/* 게임 시작 + 드론 환경 배치(ultronSetup) */
{
  const G = mkUltron();
  assert(G.villain.defCode === '01134' && G.encounterDeck.length > 0, '울트론 — 게임 시작 정상');
  assert((G.environments || []).some(e => e.defCode === 'ultron-drones'), '울트론 셋업 — 드론 환경 배치');
}

/* 빌런 단계 1→2→3 + 3단계 공개(울트론의 명령) */
{
  const G = mkUltron(); const pl = G.players[0]; pl.form = 'hero';
  G.villainFinalStageNum = 3;   // 스테이지 메커니즘 검증용: III까지 진행 허용
  G.villain.hp = 1; MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.villain.defCode === '01135', '울트론 — 1→2단계 전환(01135)');
  G.villain.hp = 1; const ss0 = G.sideSchemes.length; MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.villain.defCode === '01136', '울트론 — 2→3단계 전환(01136)');
  assert(G.sideSchemes.some(s => s.defCode === 'ultrons-imperative') || G.sideSchemes.length > ss0,
    '울트론 3단계 — 울트론의 명령 사이드 스킴 공개');
}

function droneCount(G, pl){ return pl.engagedMinions.filter(m => m.isDrone || (m.traits||[]).includes('drone')).length; }

/* android-efficiency — 드론 소환 */
{
  const G = mkUltron(); const pl = G.players[0]; pl.form = 'hero'; const d0 = droneCount(G, pl);
  reveal(G, pl, 'android-efficiency');
  assert(droneCount(G, pl) > d0, 'android-efficiency — 드론 소환');
}

/* repair-sequence — 교전 드론당 울트론 2 회복 */
{
  const G = mkUltron(); const pl = G.players[0]; pl.form = 'hero';
  MC.spawnFacedownDrone(G, pl, { attack:1, scheme:1, hp:3 });
  MC.spawnFacedownDrone(G, pl, { attack:1, scheme:1, hp:3 });
  const dc = droneCount(G, pl);
  G.villain.hp = G.villain.maxHp - 10; const h0 = G.villain.hp;
  reveal(G, pl, 'repair-sequence');
  assert(G.villain.hp === h0 + dc * 2, 'repair-sequence — 교전 드론 × 2 회복');
}

/* swarm-attack — 드론 공격(또는 폴백 소환) 무에러 */
{
  const G = mkUltron(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, 'swarm-attack');
  assert(true, 'swarm-attack — 드론 공격/폴백 무에러');
}

/* rage-of-ultron(알터에고) — 빌런 암약(위협 증가) */
{
  const G = mkUltron(); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  const t0 = G.mainScheme.threat; reveal(G, pl, 'rage-of-ultron');
  assert(G.mainScheme.threat > t0, 'rage-of-ultron(알터에고) — 빌런 암약');
}

/* 사이드 스킴 3종 */
['drone-factory','invasive-ai','ultrons-imperative'].forEach(code => {
  const G = mkUltron(); const pl = G.players[0]; pl.form = 'hero';
  MC.revealSpecificSideScheme(G, code);
  assert(G.sideSchemes.some(s => s.defCode === code), code + ' — 사이드 스킴 공개');
});

/* 부착물 2종 — 공개 무에러 */
['program-transmitter','upgraded-drones'].forEach(code => {
  const G = mkUltron(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, code);
  assert(true, code + ' — 부착 공개 무에러');
});

/* 메인 스킴 다단계 whenRevealed 무에러 (01138b/01139b) */
['01138b','01139b'].forEach(code => {
  const G = mkUltron(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, code);
  assert(true, code + ' 메인 스킴 — whenRevealed 무에러');
});

console.log('\n[test_ultron_reverify] ' + pass + '개 통과 — 울트론 시나리오 재검증 완료');
