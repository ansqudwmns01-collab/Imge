/* test_agent13.js — 에이전트 13(03002) 캡틴아메리카 시그니처 동료 회귀
   ★ 등장 후 스킴에서 위협 2 제거 (ctx.targetScheme 우선, 없으면 main).
   ★ 스탯·자원·유니크 db 확정.
   사용: node tests/test_agent13.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const deckCodes = ['agent-13','shield-toss','heroic-strike','shield-block','fearless-determination',
    'cap-helmet','cap-shield','super-soldier-serum','haymaker','first-aid','emergency','genius','strength','energy'];
  const G = MC.makeGameState({ seed: seed || 1,
    players:[{ heroCode:'03001a', deckCodes }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough'] });
  MC.setupGame(G);
  return G;
}
function pull(pl, code){
  let c = pl.hand.find(x=>x.defCode===code);
  if (c) return c;
  const i = pl.deck.findIndex(x=>x.defCode===code); if(i<0) return null;
  c = pl.deck.splice(i,1)[0]; pl.hand.push(c); return c;
}

// ① db 스탯·자원·유니크 확정
{
  const d = MC.CARDS['agent-13'];
  assert(d.type === 'ally', 'agent-13: 동료');
  assert(d.cost === 3, 'agent-13: 비용 3');
  assert(d.hp === 3, 'agent-13: HP 3');
  assert(d.unique === true, 'agent-13: 유니크');
  assert(d.resources && d.resources.mental === 1, 'agent-13: 🧠멘탈 자원 1');
  assert((d.traits||[]).includes('s.h.i.e.l.d.'), 'agent-13: S.H.I.E.L.D. 트레잇');
  assert(d.whenPlayed === 'runCardEffects', 'agent-13: whenPlayed runCardEffects');
  assert(d.effects && d.effects[0].fx === 'removeThreat' && d.effects[0].amount === 2, 'agent-13: 위협 2 제거 효과');
}

// ② 등장 후 메인 스킴에서 위협 2 제거 (targetScheme 미지정 → main)
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  G.mainScheme.threat = 6;
  const ally = pull(pl, 'agent-13');
  assert(!!ally, '테스트: agent-13 손에 확보');
  // 자원 충분 확보
  for (let i=0;i<4;i++){ pl.hand.push(MC.makeInstance(G, 'energy', {})); }
  const pay = pl.hand.filter(c=>c.defCode==='energy').slice(0,3).map(c=>({kind:'hand',uid:c.uid}));
  const before = G.mainScheme.threat;
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid: ally.uid, payment: pay });
  assert(pl.playArea.allies.some(a=>a.defCode==='agent-13'), '에이전트 13 전장 배치');
  assert(G.mainScheme.threat === before - 2, '등장 후 메인 스킴 위협 -2 (' + before + '→' + G.mainScheme.threat + ')');
}

// ③ targetScheme 지정 시 해당 사이드 스킴에서 제거
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  // 사이드 스킴 배치
  const ss = MC.makeInstance(G, 'under-attack', {}); ss.threat = 3;
  G.sideSchemes = [ss];
  G.mainScheme.threat = 5;
  const ally = pull(pl, 'agent-13');
  for (let i=0;i<4;i++){ pl.hand.push(MC.makeInstance(G, 'energy', {})); }
  const pay = pl.hand.filter(c=>c.defCode==='energy').slice(0,3).map(c=>({kind:'hand',uid:c.uid}));
  MC.dispatch(G, { type:'playCard', player:'P0', cardUid: ally.uid, payment: pay, targetScheme: ss.uid });
  assert(ss.threat === 1, '사이드 스킴 지정 시 그 스킴 위협 -2 (3→' + ss.threat + ')');
  assert(G.mainScheme.threat === 5, '메인 스킴은 영향 없음 (5 유지)');
}

console.log('══ 에이전트 13(등장 위협제거) 회귀 통과 ══');
