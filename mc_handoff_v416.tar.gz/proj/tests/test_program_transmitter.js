/* test_program_transmitter.js — 프로그램 전송기(01141) 부착물 회귀
   ★ 신규 범용: boostStarOnScheme(암약 부스트 조건부 — boostStarOnDamage의 짝),
     placeThreat scheme:'eachSide', removeAbility.exhaustHero.
   - 부착: 빌런 SCH +1, 이탈 시 원복 (attachStats)
   - 암약 부스트★: 각 사이드 스킴에 위협 1 (사이드 없으면 안전 불발)
   - 공격 부스트로 뒤집히면 ★ 미발동 (아이콘만)
   - 히어로 행동: 히어로 소진 + 🧠🧠 → 버림 (소진 상태/자원 부족 거부)
   사용: node tests/test_program_transmitter.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function addSide(G, code){
  const ss = MC.makeInstance(G, code, {});
  ss.threat = 2; ss.peakThreat = 5; ss.isMain = false;
  G.sideSchemes.push(ss);
  return ss;
}

// ① 부착: 빌런 SCH +1 (attachStats) · 이탈 시 원복
{
  const G = mk(14001);
  const sch0 = G.villain.scheme || 0;
  const pt = MC.makeInstance(G, 'program-transmitter', {});
  MC.attachTo(G, pt, G.villain);
  assert(G.villain.scheme === sch0 + 1, '부착: 빌런 SCH +1 (' + sch0 + '→' + G.villain.scheme + ')');
  MC.detachFrom(G, pt);
  assert(G.villain.scheme === sch0, '이탈: SCH 원복');
}

// ② 암약 부스트★ — 각 사이드 스킴에 위협 +1
{
  const G = mk(14002); const pl = G.players[0];
  const s1 = addSide(G, 'breakin-and-takin');
  const s2 = addSide(G, 'crowd-control');
  const t1 = s1.threat, t2 = s2.threat, tm = MC.resolveScheme(G, 'main').threat;
  const pt = MC.makeInstance(G, 'program-transmitter', {});
  MC.resolveBoostStar(G, pl, pt, 'scheme');
  assert(s1.threat === t1 + 1 && s2.threat === t2 + 1, '암약★: 각 사이드 스킴 위협 +1 (' + t1 + '→' + s1.threat + ', ' + t2 + '→' + s2.threat + ')');
  assert(MC.resolveScheme(G, 'main').threat === tm, '메인 스킴 위협은 불변');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'transmitterPulse', '암약★ 전용 연출(transmitterPulse)');
}

// ③ 공격 부스트로 뒤집히면 ★ 미발동
{
  const G = mk(14003); const pl = G.players[0];
  const s1 = addSide(G, 'breakin-and-takin');
  const t1 = s1.threat;
  const pt = MC.makeInstance(G, 'program-transmitter', {});
  MC.resolveBoostStar(G, pl, pt, 'attack');
  assert(s1.threat === t1, '공격 부스트: 위협 불변 (★는 암약 전용)');
}

// ④ 사이드 스킴 없음 — 안전 불발
{
  const G = mk(14004); const pl = G.players[0];
  const pt = MC.makeInstance(G, 'program-transmitter', {});
  MC.resolveBoostStar(G, pl, pt, 'scheme');   // 크래시 없이 통과해야 함
  assert(true, '사이드 스킴 없음: 안전 불발');
}

// ⑤ 히어로 행동 제거: 히어로 소진 + 🧠🧠 → 버림
{
  const G = mk(14005); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const pt = MC.makeInstance(G, 'program-transmitter', {});
  MC.attachTo(G, pt, G.villain);
  const pay = [];
  for (let i = 0; i < 2; i++){   // tigra-ally = mental 자원
    const c = MC.makeInstance(G, 'tigra-ally', {}); c.ownerUid = pl.uid; pl.hand.push(c); pay.push({ kind:'hand', uid:c.uid });
  }
  MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: pt.uid, payment: pay });
  assert(!G.villain.attachments.some(a => a.uid === pt.uid), '제거: 전송기 부착 해제');
  assert(G.encounterDiscard.some(c => c.uid === pt.uid), '제거된 전송기 버림 더미로');
  assert(pl.exhausted === true, '히어로 소진 (제거 비용)');
}

// ⑤-2 소진 상태 거부 (소진 비용을 낼 수 없음)
{
  const G = mk(14006); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = true;
  const pt = MC.makeInstance(G, 'program-transmitter', {});
  MC.attachTo(G, pt, G.villain);
  const c = MC.makeInstance(G, 'tigra-ally', {}); c.ownerUid = pl.uid; pl.hand.push(c);
  const c2 = MC.makeInstance(G, 'tigra-ally', {}); c2.ownerUid = pl.uid; pl.hand.push(c2);
  let threw = false;
  try { MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: pt.uid,
        payment:[{kind:'hand',uid:c.uid},{kind:'hand',uid:c2.uid}] }); }
  catch(e){ threw = true; }
  assert(threw, '소진 상태: 제거 거부 (히어로 소진 비용)');
}

// ⑤-3 정신 자원 부족 거부
{
  const G = mk(14007); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const pt = MC.makeInstance(G, 'program-transmitter', {});
  MC.attachTo(G, pt, G.villain);
  const c = MC.makeInstance(G, 'uppercut', {}); c.ownerUid = pl.uid; pl.hand.push(c);   // physical
  let threw = false;
  try { MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: pt.uid, payment:[{kind:'hand',uid:c.uid}] }); }
  catch(e){ threw = true; }
  assert(threw, '🧠 부족: 제거 거부');
}

console.log('══ 프로그램 전송기 (boostStarOnScheme/eachSide/exhaustHero) 회귀 통과 ══');
