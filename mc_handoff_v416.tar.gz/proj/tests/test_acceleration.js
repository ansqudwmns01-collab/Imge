/* test_acceleration.js — 가속(acceleration) 위협 상승률 회귀
   ★ 버그 히스토리: 공식 escalation_threat(=인원수당 1 기본 상승)를 db가 accelIcons로 오매핑 →
      라이노 시작부터 라운드당 2씩 상승(이중 계산). 수정: threat 스텝은 기본(인원수) +
      전장 사이드 스킴 가속 아이콘 + 누적 가속 토큰만 합산. 메인 스킴 accelIcons는 무시.
   사용: node tests/test_acceleration.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(np, seed){
  const players = [];
  for (let i = 0; i < np; i++) players.push({ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() });
  const G = MC.makeGameState({ seed, players, villainCode:'01094', mainScheme:'01097b', encounterCodes: Array(40).fill('im-tough') });
  MC.setupGame(G);
  return G;
}
function threatGain(G){
  const t0 = G.mainScheme.threat;
  G.phase = 'villain'; G.villainStepMode = false; G.vq = [{ op:'threat' }];
  MC.processVillainQueue(G);
  return G.mainScheme.threat - t0;
}

// 라이노 게임 시작 — 가속 없음, 라운드당 인원수만큼만 상승
assert(threatGain(mk(1, 5001)) === 1, '라이노 솔로 시작: 라운드당 +1 (가속 없음)');
assert(threatGain(mk(2, 5002)) === 2, '라이노 2인 시작: 라운드당 +2');
assert(threatGain(mk(4, 5004)) === 4, '라이노 4인 시작: 라운드당 +4');

// 메인 스킴(01097b)에 오매핑된 accelIcons가 남아있어도 위협에 반영되지 않아야 함
{
  const G = mk(1, 5010);
  assert((MC.cardDef('01097b').accelIcons || 0) >= 0, '01097b accelIcons 존재 여부 무관');
  assert(threatGain(G) === 1, '메인 스킴 오매핑 accelIcons 무시 — 솔로 +1');
}

// 진짜 가속 = 전장의 가속 사이드 스킴 아이콘
{
  const G = mk(1, 5100);
  const inst = MC.makeInstance(G, 'hit-squad', {});   // accelIcons 1
  inst.threat = 3; inst.isMain = false; G.sideSchemes.push(inst);
  assert(threatGain(G) === 2, '가속 사이드 스킴 1: 솔로 +2 (기본1+가속1)');
}
{
  const G = mk(1, 5101);
  const inst = MC.makeInstance(G, 'overrun', {});      // accelIcons 2
  inst.threat = 3; inst.isMain = false; G.sideSchemes.push(inst);
  assert(threatGain(G) === 3, '가속 사이드 스킴 2: 솔로 +3 (기본1+가속2)');
}

// 가속 토큰(덱 리셔플 누적)
{
  const G = mk(1, 5102); G.acceleration = 1;
  assert(threatGain(G) === 2, '가속 토큰 1: 솔로 +2 (기본1+토큰1)');
}
// 가속 사이드 스킴 격퇴 시 가속 사라짐
{
  const G = mk(1, 5103);
  const inst = MC.makeInstance(G, 'hit-squad', {});
  inst.threat = 3; inst.isMain = false; G.sideSchemes.push(inst);
  assert(threatGain(G) === 2, '격퇴 전: 솔로 +2');
  MC.removeThreat(G, inst.uid, 99);   // 사이드 스킴 격퇴
  assert(threatGain(G) === 1, '격퇴 후: 솔로 +1 (가속 제거됨)');
}

console.log('══ 가속 위협 상승률 회귀 통과 ══');
