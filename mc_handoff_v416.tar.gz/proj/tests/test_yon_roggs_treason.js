/* test_yon_roggs_treason.js — 욘-로그의 반역(01179) 배신 회귀
   ★ 신규 discardAllResourcesFromHand(손패 자원 카드 전체 버림) + treasonDiscardedNone 조건 surge.
   사용: node tests/test_yon_roggs_treason.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 손패 자원 카드 전체 버림 (버린 게 있으면 surge 없음)
{
  const G = mk(84001); const pl = G.players[0]; pl.form = 'hero';
  // 자원 카드(shuri=physical) 3장으로 손패 구성
  pl.hand = [MC.makeInstance(G, 'shuri', {}), MC.makeInstance(G, 'shuri', {}), MC.makeInstance(G, 'shuri', {})];
  const h0 = pl.hand.length;
  const inst = MC.makeInstance(G, 'yon-roggs-treason', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.hand.length === 0, '자원 카드 전부 버림 (' + h0 + '→' + pl.hand.length + ')');
  assert(inst.surge !== true, '버린 게 있으면 surge 없음');
}

// ② 자원 없는 손패면 surge (버린 게 없음)
{
  const G = mk(84002); const pl = G.players[0]; pl.form = 'hero';
  pl.hand = []; // 빈 손패 = 버릴 자원 없음
  const inst = MC.makeInstance(G, 'yon-roggs-treason', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(inst.surge === true, '버린 자원 없음 → surge');
}

// ③ 자원 카드만 선별 버림 (자원 없는 카드는 남김)
{
  const G = mk(84003); const pl = G.players[0]; pl.form = 'hero';
  // 자원 없는 카드 찾기
  const noRes = Object.keys(MC.CARDS).find(k => {
    const r = (MC.CARDS[k].resources) || {};
    const side = MC.CARDS[k].side;
    return side === 'player' && !['physical','mental','energy','wild'].some(t => r[t] > 0);
  });
  const resCard = MC.makeInstance(G, 'shuri', {});
  pl.hand = [resCard];
  if (noRes){ const nr = MC.makeInstance(G, noRes, {}); pl.hand.push(nr);
    const inst = MC.makeInstance(G, 'yon-roggs-treason', {});
    MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
    assert(pl.hand.some(c => c.uid === nr.uid), '자원 없는 카드는 손패에 남음');
    assert(!pl.hand.some(c => c.uid === resCard.uid), '자원 카드는 버림');
  } else {
    const inst = MC.makeInstance(G, 'yon-roggs-treason', {});
    MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
    assert(pl.hand.length === 0, '자원 카드 버림 (자원 없는 카드 없어 선별 스킵)');
  }
}

console.log('══ 욘-로그의 반역 (discardAllResourcesFromHand) 회귀 통과 ══');
