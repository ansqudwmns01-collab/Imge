/* test_ritual_combat.js — 의식 결투(01159) 배신 회귀
   ★ 신규 discardEncounterComputeX(조우덱 버림+X) + amountFrom:'ritualX'(dealDamage/placeThreat) + offerChoice.
   사용: node tests/test_ritual_combat.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 공개: 조우덱 top 버림 + X 계산 + 선택 pending
{
  const G = mk(64001); const pl = G.players[0]; pl.form = 'hero';
  const deck0 = G.encounterDeck.length;
  const topBoost = G.encounterDeck.length ? (MC.cardDef(G.encounterDeck[0].defCode)?.boost || 0) : 0;
  const inst = MC.makeInstance(G, 'ritual-combat', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.encounterDeck.length === deck0 - 1, '조우덱 top 1장 버림');
  assert(G._ritualX === topBoost + 1, 'X = 부스트(' + topBoost + ') + 1 = ' + G._ritualX);
  assert(G.pending && G.pending.kind === 'revealChoice', '선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (피해/위협)');
}

// ② 피해 선택: 히어로에 X 피해
{
  const G = mk(64002); const pl = G.players[0]; pl.form = 'hero';
  const inst = MC.makeInstance(G, 'ritual-combat', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  const X = G._ritualX, hp0 = pl.hp;
  MC.dispatch(G, { type:'resolveRevealChoice', option:'damage' });
  assert(pl.hp === hp0 - X, '피해 선택: 히어로 X(' + X + ') 피해 (' + hp0 + '→' + pl.hp + ')');
}

// ③ 위협 선택: 메인 스킴에 X 위협
{
  const G = mk(64003); const pl = G.players[0]; pl.form = 'hero';
  const inst = MC.makeInstance(G, 'ritual-combat', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  const X = G._ritualX;
  const ms = G.mainScheme; const t0 = ms.threat || 0;
  MC.dispatch(G, { type:'resolveRevealChoice', option:'threat' });
  assert((ms.threat || 0) === t0 + X, '위협 선택: 메인 스킴 위협 +X(' + X + ') (' + t0 + '→' + ms.threat + ')');
}

// ④ X 최소 1 보장 (부스트 0 카드 버려도)
{
  const G = mk(64004); const pl = G.players[0]; pl.form = 'hero';
  // 조우덱 top을 부스트 0 카드로 강제
  const zero = MC.makeInstance(G, 'im-tough', {});
  G.encounterDeck.unshift(zero);
  const inst = MC.makeInstance(G, 'ritual-combat', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G._ritualX >= 1, 'X 최소 1 (부스트 0 → X ' + G._ritualX + ')');
}

console.log('══ 의식 결투 (discardEncounterComputeX + amountFrom) 회귀 통과 ══');
