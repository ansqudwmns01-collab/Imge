/* test_core.js — 시뮬레이션 하네스: 1~4인 혼합 200판, 엔진 크래시/오류 0 확인
   사용: node tests/test_core.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function seedDeck(){
  const d = [];
  for (let i=0;i<12;i++) d.push('backflip');
  for (let i=0;i<12;i++) d.push('swinging-web-kick');
  d.push('black-cat');
  return d;
}

function simOne(seed, nPlayers){
  const G = MC.makeGameState({
    seed,
    players: Array.from({length:nPlayers}, () => ({ heroCode:'01001a', deckCodes: seedDeck() })),
    villainCode:'01094', mainScheme:'01097b',
    encounterCodes: Array(10).fill('hydra-mercenary').concat(Array(4).fill('sandman')),
  });
  MC.setupGame(G);
  let ps = seed ^ 0xC0FFEE;
  const prand = () => { let t=(ps+=0x6D2B79F5); t=Math.imul(t^(t>>>15),t|1); t^=t+Math.imul(t^(t>>>7),t|61); return ((t^(t>>>14))>>>0)/4294967296; };
  let guard = 0;
  while (!G.over && G.round < 40 && guard++ < 5000){
    if (G.pending){
      const dp = G.players.find(x=>x.uid===G.pending.player);
      const canDef = dp && !dp.exhausted;
      MC.dispatch(G, { type:'resolveDefense', player:G.pending.player,
        defender: (canDef && prand()<0.6) ? 'identity' : 'none' });
      continue;
    }
    for (const pl of MC.playersInOrder(G)){
      if (G.over || G.pending) break;
      // 정책: 알터에고에서 다치면 회복, 아니면 영웅으로 나가 공격/저지
      if (pl.form === 'alter-ego'){
        if (pl.hp < pl.maxHp - 3 && !pl.exhausted && prand() < 0.7){
          MC.dispatch(G, { type:'basicRecover', player: pl.uid });
        } else if (!pl.formChangedThisRound && prand() < 0.7){
          MC.dispatch(G, { type:'flipForm', player: pl.uid });
        }
      }
      if (pl.form === 'hero' && !pl.exhausted && !G.pending){
        const guardM = pl.engagedMinions.find(m => m.guard && m.hp > 0);
        const anyM = pl.engagedMinions.find(m => m.hp > 0);
        const r = prand();
        if (guardM){
          MC.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: guardM.uid });
        } else if (anyM && r < 0.5){
          MC.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: anyM.uid });
        } else if (r < 0.75){
          MC.dispatch(G, { type:'basicAttack', player: pl.uid, targetUid: G.villain.uid });
        } else if (G.mainScheme.threat > 0){
          MC.dispatch(G, { type:'basicThwart', player: pl.uid, scheme:'main' });
        }
      }
      // 다친 영웅은 알터에고로 복귀 시도
      if (pl.form === 'hero' && pl.hp <= 4 && !pl.formChangedThisRound && prand() < 0.5)
        MC.dispatch(G, { type:'flipForm', player: pl.uid });
    }
    if (!G.over && !G.pending) MC.dispatch(G, { type:'endPlayerPhase' });
  }
  return G;
}

const N = 200;
let crash = 0, win = 0, loss = 0, timeout = 0, totalRounds = 0;
for (let i=0;i<N;i++){
  const nPlayers = 1 + (i % 4); // 1~4인 균등
  try {
    const G = simOne(1000 + i * 7919, nPlayers);
    if (!G.over){ timeout++; }
    else if (G.over.result === 'win') win++;
    else loss++;
    totalRounds += G.round;
  } catch(e){
    crash++;
    console.error(`✗ 판 #${i} (${nPlayers}인, seed ${1000+i*7919}) 크래시: ${e.message}`);
    if (crash > 5) break;
  }
}
console.log(`[test_core] ${N}판 (1~4인 혼합) — 크래시 ${crash} · 승 ${win} · 패 ${loss} · 미결 ${timeout} · 평균 ${Math.round(totalRounds/N*10)/10}라운드`);
process.exit(crash === 0 ? 0 : 1);
