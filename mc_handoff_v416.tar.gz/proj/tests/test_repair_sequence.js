/* test_repair_sequence.js — 수리 시퀀스(01146) 배신 회귀
   ★ 신규 범용: healVillain perEngagedDrone(교전 드론 비례 회복),
     boostStarEffects(무조건 발동 파라미터형 부스트★). surge는 cond healedNone 재사용.
   - 공개: 교전 드론 1명당 울트론 2 회복 · 회복 0이면 급증(surge)
   - 부스트★: 교전 드론 1명당 1 회복 (무조건)
   사용: node tests/test_repair_sequence.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function spawnDrones(G, pl, n){
  G.environments = G.environments || [];
  if (!G.environments.length) G.environments.push(MC.makeInstance(G, 'ultron-drones', {}));
  for (let i = 0; i < n; i++) MC.spawnFacedownDrone(G, pl);
}
function fire(G, pl){
  const inst = MC.makeInstance(G, 'repair-sequence', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}

// ① 교전 드론 2명 → 회복 2×2=4 (빌런에 피해 있을 때)
{
  const G = mk(18001); const pl = G.players[0];
  spawnDrones(G, pl, 2);
  G.villain.hp = G.villain.maxHp - 6;   // 6 피해 상태
  const hp0 = G.villain.hp;
  const inst = fire(G, pl);
  assert(G.villain.hp === hp0 + 4, '드론 2명: 울트론 +4 회복 (' + hp0 + '→' + G.villain.hp + ')');
  assert(!inst.surge, '회복 발생: 급증 없음');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'ultronRepair', '회복 연출');
}

// ② 드론 0명 → 회복 0 → 급증(surge) + 실패 연출
{
  const G = mk(18002); const pl = G.players[0];
  G.villain.hp = G.villain.maxHp - 5;
  const hp0 = G.villain.hp;
  const inst = fire(G, pl);
  assert(G.villain.hp === hp0, '드론 없음: 회복 0');
  assert(inst.surge === true, '회복 0: 급증(surge) 획득');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'ultronRepairFail', '회복0 분기 연출');
}

// ③ 드론 있으나 이미 만피 → 회복 0 → 급증
{
  const G = mk(18003); const pl = G.players[0];
  spawnDrones(G, pl, 2);
  G.villain.hp = G.villain.maxHp;   // 만피
  const inst = fire(G, pl);
  assert(G.villain.hp === G.villain.maxHp, '만피: 회복 0 (초과 안 됨)');
  assert(inst.surge === true, '만피 회복 0: 급증');
}

// ④ 부스트★: 교전 드론 1명당 1 회복 (무조건)
{
  const G = mk(18004); const pl = G.players[0];
  spawnDrones(G, pl, 3);
  G.villain.hp = G.villain.maxHp - 6;
  const hp0 = G.villain.hp;
  const bc = MC.makeInstance(G, 'repair-sequence', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  assert(G.villain.hp === hp0 + 3, '부스트★: 드론 3명 × 1 = +3 회복');
}

// ⑤ 부스트★ 드론 0명 → 회복 0 (크래시 없음, 급증 없음 — 부스트는 surge 무관)
{
  const G = mk(18005); const pl = G.players[0];
  G.villain.hp = G.villain.maxHp - 3;
  const hp0 = G.villain.hp;
  const bc = MC.makeInstance(G, 'repair-sequence', {});
  MC.resolveBoostStar(G, pl, bc, 'scheme');
  assert(G.villain.hp === hp0, '부스트★ 드론 없음: 회복 0 (안전)');
}

console.log('══ 수리 시퀀스 (perEngagedDrone + boostStarEffects) 회귀 통과 ══');
