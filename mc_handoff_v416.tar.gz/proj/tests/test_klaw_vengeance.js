/* test_klaw_vengeance.js — 클로의 복수(01122) 폼 분기 배신 회귀
   ★ 커스텀 핸들러가 아니라 범용 인덱스(formBranch/villainAttacks/discardFromHand/playVfx)로
     데이터 실행됨을 검증 (whenRevealed:'runCardEffects' → def.effects).
   사용: node tests/test_klaw_vengeance.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed, villain){
  const deck = MC.PRESET_DECKS.spiderman.cards.slice();
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: deck }],
    villainCode: villain || '01114', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function fireVengeance(G, pl){
  const inst = MC.makeInstance(G, 'klaw-vengeance', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
}

// 기반 이펙트 인덱스 등록 확인
assert(typeof MC.EFFECTS.villainAttacks === 'function', 'EFFECTS.villainAttacks 등록');
assert(typeof MC.EFFECTS.villainSchemes === 'function', 'EFFECTS.villainSchemes 등록 (빌런 암약)');
assert(typeof MC.EFFECTS.formBranch === 'function', 'EFFECTS.formBranch 등록 (폼 분기)');
assert(typeof MC.EFFECTS.playVfx === 'function', 'EFFECTS.playVfx 등록 (연출 힌트)');
assert(typeof MC.HANDLERS.runCardEffects === 'function', 'HANDLERS.runCardEffects 등록 (데이터 실행)');

// 알터에고 — 손패 1장 버림 + 연출
{
  const G = mk(2301); const pl = G.players[0]; pl.form = 'alter';
  const h0 = pl.hand.length;
  fireVengeance(G, pl);
  assert(pl.hand.length === h0 - 1, '알터에고: 손패 무작위 1장 버림 (' + h0 + '→' + pl.hand.length + ')');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'sonicVengeanceScatter',
    '알터에고: playVfx→fxCardEffect(sonicVengeanceScatter) 연출 힌트');
}

// 히어로 — 클로 공격 + 피해 시 위협 +1
{
  const G = mk(2302); const pl = G.players[0]; pl.form = 'hero';
  fireVengeance(G, pl);
  assert(G.pending && G.pending.kind === 'defense', '히어로: 클로 공격 방어 pending 생성');
  assert(G.pending.threatOnDamage === 1, '히어로: threatOnDamage 1 부착');
  const t0 = G.mainScheme.threat, hp0 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp0 - 1, '히어로: 클로 공격으로 피해 1 (' + hp0 + '→' + pl.hp + ')');
  assert(G.mainScheme.threat === t0 + 1, '히어로: 피해 발생 → 메인 위협 +1 (' + t0 + '→' + G.mainScheme.threat + ')');
}

// 히어로 — 전량 방지(무피해) → 위협 없음
{
  const G = mk(2303); const pl = G.players[0]; pl.form = 'hero';
  fireVengeance(G, pl);
  const t0 = G.mainScheme.threat;
  G.pending.prevented = 999;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(G.mainScheme.threat === t0, '히어로: 전량 방지(무피해) → 메인 위협 배치 없음 (' + G.mainScheme.threat + ')');
}

// villainSchemes(암약) 동작 — 클로 SCH만큼 메인 위협
{
  const G = mk(2304); const pl = G.players[0];
  const t0 = G.mainScheme.threat, sch = G.villain.scheme || 0;
  MC.EFFECTS.villainSchemes(G, {}, { player: pl });
  assert(G.mainScheme.threat === t0 + sch, 'villainSchemes: 메인 위협 +SCH(' + sch + ') (' + t0 + '→' + G.mainScheme.threat + ')');
}

console.log('══ 클로의 복수 (데이터 기반) 회귀 통과 ══');
