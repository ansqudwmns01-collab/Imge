/* test_android_efficiency.js — 안드로이드 효율(01144) 배신 회귀
   ★ 신규 범용: EFFECTS.spawnDrone(scope eachPlayer/activePlayer, fallback),
     boostStarChoice + flushDeferredBoostChoice(자원 판정 후 선택 pending / 자원 불가 시 자동 드론),
     resolveRevealChoice(resource/drone)로 해소.
   사용: node tests/test_android_efficiency.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function fireReveal(G, pl){
  const inst = MC.makeInstance(G, 'android-efficiency', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}
// energy 자원 카드 손패 확보
function giveEnergy(G, pl, n){
  for (let i = 0; i < n; i++){
    const c = MC.makeInstance(G, 'relentless-assault', {});   // energy 자원
    c.ownerUid = pl.uid; pl.hand.push(c);
  }
}

// ① 공개 시: 각 플레이어 드론 스폰 (환경 없이도 fallback 스탯으로 등장)
{
  const G = mk(16001); const pl = G.players[0];
  const deck0 = pl.deck.length, topUid = pl.deck[pl.deck.length - 1].uid;
  fireReveal(G, pl);
  const drone = pl.engagedMinions.find(m => m.isDrone);
  assert(drone, '공개: 뒷면 드론 스폰');
  assert(pl.deck.length === deck0 - 1 && drone.facedownCard.uid === topUid, '덱 맨 위 카드가 뒷면 드론으로');
  assert(drone.attack === 1 && drone.scheme === 1 && drone.hp === 1, 'fallback 스탯 (환경 없음) ATK1/SCH1/HP1');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'droneConversion', '공개 연출(droneConversion)');
}

// ①-2 환경 있으면 그 스탯 우선 (업그레이드 부착 보정까지)
{
  const G = mk(16002); const pl = G.players[0];
  const env = MC.makeInstance(G, 'ultron-drones', {}); G.environments.push(env);
  const up = MC.makeInstance(G, 'upgraded-drones', {}); MC.attachTo(G, up, env);
  fireReveal(G, pl);
  const drone = pl.engagedMinions.find(m => m.isDrone);
  assert(drone.attack === 2 && drone.hp === 2, '환경+업그레이드: 드론 ATK2/HP2 (환경 스탯 우선)');
}

// ② 부스트★ deferred 적재 + flush(자원 있음) → 선택 pending
{
  const G = mk(16003); const pl = G.players[0];
  giveEnergy(G, pl, 1);
  const bc = MC.makeInstance(G, 'android-efficiency', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  assert(G._deferredBoostChoice && G._deferredBoostChoice.playerUid === pl.uid, '부스트★: 선택 예약(deferred)');
  assert(!G.pending, 'deferred 단계: 아직 pending 없음 (즉시 세우지 않음)');
  const set = MC.flushDeferredBoostChoice(G);
  assert(set && G.pending && G.pending.kind === 'revealChoice', 'flush(자원 있음): 선택 pending 세움');
  assert(G.pending.options.length === 2, '선택지 2개 (자원/드론)');
  assert(!G._deferredBoostChoice, 'flush 후 deferred 소거');
}

// ②-1 선택: 자원 지불(회피) → 드론 안 나옴
{
  const G = mk(16004); const pl = G.players[0];
  giveEnergy(G, pl, 1);
  const eUid = pl.hand[pl.hand.length - 1].uid;
  const bc = MC.makeInstance(G, 'android-efficiency', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  MC.flushDeferredBoostChoice(G);
  const droneBefore = pl.engagedMinions.filter(m => m.isDrone).length;
  MC.dispatch(G, { type:'resolveRevealChoice', option:'resource', payment:[{kind:'hand',uid:eUid}] });
  assert(!G.pending, '자원 선택: pending 해소');
  assert(pl.engagedMinions.filter(m => m.isDrone).length === droneBefore, '자원 지불: 드론 미등장(회피)');
  assert(!pl.hand.some(c => c.uid === eUid), '지불한 자원 카드 소모');
}

// ②-2 선택: 드론 등장
{
  const G = mk(16005); const pl = G.players[0];
  giveEnergy(G, pl, 1);
  const bc = MC.makeInstance(G, 'android-efficiency', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  MC.flushDeferredBoostChoice(G);
  MC.dispatch(G, { type:'resolveRevealChoice', option:'drone' });
  assert(!G.pending, '드론 선택: pending 해소');
  assert(pl.engagedMinions.some(m => m.isDrone), '드론 선택: 뒷면 드론 등장');
}

// ③ 자원 없음 → flush 시 자동 드론 (선택 pending 없음)
{
  const G = mk(16006); const pl = G.players[0];
  pl.hand = [];   // 자원 전무
  const bc = MC.makeInstance(G, 'android-efficiency', {});
  MC.resolveBoostStar(G, pl, bc, 'scheme');
  const set = MC.flushDeferredBoostChoice(G);
  assert(!set && !G.pending, '자원 없음: 선택 pending 안 세움');
  assert(pl.engagedMinions.some(m => m.isDrone), '자원 없음: 자동 드론 등장');
}

console.log('══ 안드로이드 효율 (spawnDrone + boostStarChoice deferred) 회귀 통과 ══');
