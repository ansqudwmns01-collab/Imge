/* test_killmonger.js — 킬몽거(01157) 하수인 회귀
   ★ 지속 효과: 블랙 팬서 업그레이드 피해 면역(applyDamage immuneToUpgradeDamage 가드).
   사용: node tests/test_killmonger.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 스탯 HP 5 (db 스텁 4 → 공식 5 정정)
{
  const d = MC.cardDef('killmonger');
  assert(d.hp === 5, '킬몽거 HP 5 (공식)');
  assert(d.immuneToUpgradeDamage === 'black-panther', '블랙 팬서 업그레이드 면역 플래그');
}

// ② 블랙 팬서 업그레이드(팬서 발톱) 피해 면역
{
  const G = mk(62001); const pl = G.players[0]; pl.form = 'hero';
  const km = MC.makeInstance(G, 'killmonger', {}); km.type = 'minion';
  pl.engagedMinions.push(km);
  const hp0 = km.hp;
  const claws = MC.cardDef('panther-claws'); // 블랙 팬서 업그레이드 (source)
  MC.applyDamage(G, km, 4, { source: claws });
  assert(km.hp === hp0, '블랙 팬서 업그레이드 피해 무효 (' + hp0 + ' 유지)');
}

// ③ 일반 공격(비-블랙팬서 출처)은 정상 피해
{
  const G = mk(62002); const pl = G.players[0]; pl.form = 'hero';
  const km = MC.makeInstance(G, 'killmonger', {}); km.type = 'minion';
  pl.engagedMinions.push(km);
  const hp0 = km.hp;
  MC.applyDamage(G, km, 3, { source: pl });  // 히어로 기본 공격 출처
  assert(km.hp === hp0 - 3, '일반 피해는 정상 적용 (' + hp0 + '→' + km.hp + ')');
}

// ④ 다른 영웅 업그레이드(예: 아이언맨)는 면역 대상 아님
{
  const G = mk(62003); const pl = G.players[0]; pl.form = 'hero';
  const km = MC.makeInstance(G, 'killmonger', {}); km.type = 'minion';
  pl.engagedMinions.push(km);
  const hp0 = km.hp;
  const arc = MC.cardDef('powered-gauntlets'); // 아이언맨 업그레이드 (hero != black-panther)
  MC.applyDamage(G, km, 2, { source: arc });
  assert(km.hp === hp0 - 2, '비-블랙팬서 업그레이드 피해는 정상 적용');
}

console.log('══ 킬몽거 (블랙 팬서 업그레이드 면역) 회귀 통과 ══');
