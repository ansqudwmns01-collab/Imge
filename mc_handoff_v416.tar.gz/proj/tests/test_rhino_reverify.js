/* test_rhino_reverify.js — 라이노 시나리오 실제 작동 재검증 (영구 회귀)
   ★ 매 게임 실행되는 빌런 단계/공개 효과·인카운터 카드를 실제 dispatch로 검증.
   사용: node tests/test_rhino_reverify.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mkRhino(hero){
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode: hero || '01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') });
  MC.setupGame(G);
  return G;
}

/* 라이노 게임 시작 정상 (인카운터 덱 구성) */
{
  const G = mkRhino();
  assert(G.villain.defCode === '01094' && G.encounterDeck.length > 0,
    '라이노 — 게임 시작 정상 (빌런 01094 + 인카운터 덱)');
}

/* 빌런 단계 1→2→3 전환 + 각 단계 공개 효과 */
{
  const G = mkRhino(); const pl = G.players[0];
  G.villainFinalStageNum = 3;   // 스테이지 메커니즘 검증용: III까지 진행 허용
  // 1→2
  G.villain.hp = 1; const ss0 = G.sideSchemes.length;
  MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.villain.defCode === '01095', '라이노 — 1→2단계 전환(01095)');
  assert(G.sideSchemes.some(s => s.defCode === 'breakin-and-takin') || G.sideSchemes.length > ss0,
    '라이노 2단계 — breakin-and-takin 사이드 스킴 공개');
  // 2→3
  G.villain.hp = 1;
  MC.applyDamage(G, G.villain, 5, { isAttack:true });
  assert(G.villain.defCode === '01096', '라이노 — 2→3단계 전환(01096)');
  assert((G.villain.status.tough || 0) > 0, '라이노 3단계 — 라이노 Tough 획득');
  assert((pl.status.stunned || 0) > 0, '라이노 3단계 — 모든 히어로 기절');
}

function reveal(G, pl, code){ const c = MC.makeInstance(G, code, {}); MC.fireCardHook(G, c, 'whenRevealed', { player: pl, self: c, card: c }); return c; }

/* 표준 인카운터 세트 */
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero';
  const t0 = G.mainScheme.threat; reveal(G, pl, 'advance');
  assert(G.mainScheme.threat > t0, 'advance — 메인 스킴 위협 증가');
}
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero'; const hp0 = pl.hp;
  reveal(G, pl, 'assault');
  assert(pl.hp < hp0 || (G.pending && G.pending.kind === 'defense'), 'assault(히어로폼) — 빌런 공격');
}
{
  const G = mkRhino(); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  const c = reveal(G, pl, 'assault');
  assert(c.surge === true, 'assault(알터에고) — 급증');
}
{
  const G = mkRhino(); const pl = G.players[0]; if (pl.form==='hero') MC.flipForm(G, pl, { force:true });
  const c = reveal(G, pl, 'stampede');
  assert(c.surge === true, 'stampede(알터에고) — 급증');
}
['caught-off-guard','gang-up','shadow-of-the-past'].forEach(code => {
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, code);
  assert(true, code + ' — whenRevealed 무에러');
});

/* 라이노 고유 인카운터 */
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero'; const hp0 = pl.hp;
  reveal(G, pl, 'shocker');
  assert(pl.hp === hp0 - 1, 'shocker — 각 히어로 1 피해');
}
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero';
  G.villain.hp = G.villain.maxHp - 6; const h0 = G.villain.hp;
  reveal(G, pl, 'hard-to-keep-down');
  assert(G.villain.hp === h0 + 4, 'hard-to-keep-down — 라이노 4 회복');
}
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero'; G.villain.hp = G.villain.maxHp;
  const c = reveal(G, pl, 'hard-to-keep-down');
  assert(c.surge === true, 'hard-to-keep-down 풀피 — 급증');
}
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero'; if (G.villain.status) G.villain.status.tough = 0;
  reveal(G, pl, 'im-tough');
  assert((G.villain.status.tough || 0) > 0, 'im-tough — 라이노 Tough');
}
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero'; MC.setStatus(G, G.villain, 'tough', true);
  const c = reveal(G, pl, 'im-tough');
  assert(c.surge === true, 'im-tough 이미Tough — 급증');
}
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero';
  MC.revealSpecificSideScheme(G, 'breakin-and-takin');
  const ss = G.sideSchemes.find(s => s.defCode === 'breakin-and-takin');
  assert(ss && ss.threat > 0, 'breakin-and-takin — 사이드 스킴 등장 + 시작 위협');
}

/* bomb-scare 모듈러 세트 */
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero'; if (pl.status) pl.status.confused = 0;
  reveal(G, pl, 'false-alarm');
  assert((pl.status.confused || 0) > 0, 'false-alarm — 히어로 혼란');
}
{
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero';
  MC.revealSpecificSideScheme(G, 'bomb-threat');
  const ss = G.sideSchemes.find(s => s.defCode === 'bomb-threat');
  assert(ss && ss.threat > 0, 'bomb-threat — 사이드 스킴 등장 + 시작 위협');
}
{ // hydra-bomber — 공개 시 택 pending 2개 (데이터화: offerChoice)
  const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, 'hydra-bomber');
  assert(G.pending && G.pending.kind === 'revealChoice' && (G.pending.options||[]).length === 2,
    'hydra-bomber — 공개 시 택 pending 2개(피해2/위협+1)');
}
{ const G = mkRhino(); const pl = G.players[0]; pl.form = 'hero';
  reveal(G, pl, 'explosion'); assert(true, 'explosion — whenRevealed 무에러'); }

console.log('\n[test_rhino_reverify] ' + pass + '개 통과 — 라이노 시나리오 재검증 완료');
