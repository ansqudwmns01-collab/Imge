/* test_business_problems.js — 사업 문제(01170) obligation 회귀
   ★ obligation 재사용(exhaustTarget/resolveObligation) + 신규 exhaustAllUpgrades.
   사용: node tests/test_business_problems.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 공개: 선택 pending (2옵션)
{
  const G = mk(75001); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'business-problems', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(G.pending && G.pending.kind === 'revealChoice', '의무 공개 — 선택 pending');
  assert(G.pending.options.length === 2, '선택지 2개 (소진/업그레이드 소진)');
}

// ② exhaust 옵션: 소진 + 게임 제거
{
  const G = mk(75002); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const inst = MC.makeInstance(G, 'business-problems', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'exhaust' });
  assert(pl.exhausted === true, 'exhaust: 토니 스타크 소진');
  assert((G.removedFromGame || []).includes('business-problems'), 'exhaust: 게임에서 제거');
}

// ③ exhaustUpgrades 옵션: 통제 업그레이드 전체 소진 (의무 버림)
{
  const G = mk(75003); const pl = G.players[0]; pl.form = 'hero';
  // 업그레이드 2장 배치 (미소진)
  const u1 = MC.makeInstance(G, 'panther-claws', {}); u1.exhausted = false;
  const u2 = MC.makeInstance(G, 'shuri', {}); u2.exhausted = false;
  pl.playArea.upgrades.push(u1, u2);
  const inst = MC.makeInstance(G, 'business-problems', {}); pl.deck.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  MC.dispatch(G, { type:'resolveRevealChoice', option:'exhaustUpgrades' });
  assert(u1.exhausted === true && u2.exhausted === true, 'exhaustUpgrades: 모든 업그레이드 소진');
  assert(pl.exhausted !== true, 'exhaustUpgrades: 히어로는 소진 안 함');
  assert((G.removedFromGame || []).length === 0, 'exhaustUpgrades: 게임 제거 아님(버림)');
}

console.log('══ 사업 문제 (obligation + exhaustAllUpgrades) 회귀 통과 ══');
