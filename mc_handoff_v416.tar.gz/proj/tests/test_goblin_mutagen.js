/* test_goblin_mutagen.js — Mutagen Formula (단면 그린 고블린) 영구 회귀
   현재: 고블린 소환 하수인(Goblin Soldier/Thrall). 사용: node tests/test_goblin_mutagen.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(c, m){ if(!c){ console.error('✗ '+m); process.exitCode=1; throw new Error(m); } console.log('✓ '+m); pass++; }

function mkGame(){
  const players=[{ heroCode:'01001a', deckCodes: Array(20).fill('energy') },
                 { heroCode:'01001a', deckCodes: Array(20).fill('energy') }];
  const G = MC.makeGameState({ seed:7, players, villainCode:'01094', mainScheme:'01097b', encounterCodes:[] });
  MC.setupGame(G);
  return G;
}

/* 데이터 배선 */
{
  const sol=MC.cardDef('goblin-soldier'), thr=MC.cardDef('goblin-thrall');
  assert(sol.boostStarPutIntoPlay===true && !sol.todoFx, 'Goblin Soldier — 부스트★ 전장배치 + todoFx 해제');
  assert(sol.whenDefeatedEffects[0].fx==='dealDamage' && sol.whenDefeatedEffects[0].target==='engagedPlayer' && sol.whenDefeatedEffects[0].amount===1,
    'Goblin Soldier — 처치 시 교전 플레이어 피해 1');
  assert(thr.boostStarPutIntoPlay===true && thr.guard===true, 'Goblin Thrall — 부스트★ 전장배치 + Guard');
}

/* 부스트★ 전장 배치: 부스트로 공개되면 교전 상태로 등장 */
{
  const G=mkGame(); const pl=G.players[0];
  const before=pl.engagedMinions.length;
  const soldier=MC.makeInstance(G,'goblin-soldier',{});
  MC.resolveBoostStar(G, pl, soldier, 'attack');
  assert(pl.engagedMinions.some(m=>m.defCode==='goblin-soldier'), 'Goblin Soldier 부스트★ → 교전 상태로 전장 등장');
  assert(pl.engagedMinions.length===before+1, '교전 하수인 +1');
}

/* 처치 시 교전 플레이어 피해 1 (engagedPlayer 타겟) */
{
  const G=mkGame(); const pl=G.players[0];
  const soldier=MC.makeInstance(G,'goblin-soldier',{});
  soldier.engagedWith=pl.uid; pl.engagedMinions.push(soldier);
  const hp0=pl.hp;
  MC.fireCardHook(G, soldier, 'whenDefeated', { by: pl });
  assert(pl.hp===hp0-1, 'Goblin Soldier 처치 → 교전 플레이어(P1) 피해 1');
}

/* Thrall도 부스트★ 전장 배치 */
{
  const G=mkGame(); const pl=G.players[1];
  const thrall=MC.makeInstance(G,'goblin-thrall',{});
  MC.resolveBoostStar(G, pl, thrall, 'scheme');
  assert(pl.engagedMinions.some(m=>m.defCode==='goblin-thrall'), 'Goblin Thrall 부스트★ → 교전 상태로 전장 등장');
}

/* Monster WR — 기절 / 이미 기절 시 피해 2 */
{
  const G=mkGame(); const pl=G.players[0];
  const m1=MC.makeInstance(G,'monster',{});
  const hp0=pl.hp;
  MC.fireCardHook(G, m1, 'whenRevealed', { player: pl });
  assert(pl.status.stunned>0 && pl.hp===hp0, 'Monster WR — 미기절 시 기절만(피해 없음)');
  // 이미 기절 상태에서 또 공개 → 피해 2
  const m2=MC.makeInstance(G,'monster',{});
  MC.fireCardHook(G, m2, 'whenRevealed', { player: pl });
  assert(pl.hp===hp0-2, 'Monster WR — 이미 기절 시 피해 2');
}

/* 뮤타젠 빌런 데이터 + 강제반응(공격 후 위협) + WR 조우배분 */
{
  for(const [c,hp,a,s,td] of [['02014',16,2,1,1],['02015',18,2,2,1],['02016',20,3,2,2]]){
    const d=MC.cardDef(c);
    assert(d && d.hpPerPlayer===hp && d.attack===a && d.scheme===s && d.attackThreatOnDamage===td,
      c+' — 스탯 HP/h'+hp+' A'+a+' S'+s+' 위협반응'+td);
  }
  assert(MC.cardDef('02015').whenRevealedEffects[0].fx==='dealEncounterEachPlayer' && MC.cardDef('02015').whenRevealedEffects[0].amount===2,
    '02015 — WR 각 플레이어 조우 2장');
  assert(MC.cardDef('02016').whenRevealedEffects[0].amount===3, '02016 — WR 각 플레이어 조우 3장');
}
/* 빌런 공격이 피해를 입히면 메인 위협 배치 (threatOnDamage 경유) */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:8,players,villainCode:'02014',mainScheme:'01097b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0]; if(pl.form!=='hero') MC.flipForm(G,pl,{force:true});
  const th0=G.mainScheme.threat;
  // 공격 pending 수동 구성 (attackThreatOnDamage 반영 확인)
  G.pending={kind:'defense',player:pl.uid,attackerUid:G.villain.uid,amount:2,prevented:0,threatOnDamage:MC.cardDef('02014').attackThreatOnDamage};
  MC.dispatch(G,{type:'resolveDefense',player:pl.uid,defender:'none'});
  assert(G.mainScheme.threat===th0+1, '02014 공격 피해 → 메인 위협 +1 (강제반응)');
}

/* Death from Above — 플레이어 폼조건부 WR (villainStage 보너스) */
{
  // 알터에고: GG 암약 +스테이지 SCH → 메인 위협
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:9,players,villainCode:'02016',mainScheme:'01097b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0]; if(pl.form!=='alter-ego') MC.flipForm(G,pl,{force:true});
  const th0=G.mainScheme.threat;
  const t=MC.makeInstance(G,'death-from-above',{});
  MC.fireCardHook(G, t, 'whenRevealed', { player: pl });
  // 02016 SCH 2 + stage 3 = 5 위협
  assert(G.mainScheme.threat===th0+5, 'Death from Above 알터에고 → 암약 SCH2+스테이지3 = 위협+5');

  // 히어로: GG 공격 +스테이지 ATK → 방어 pending
  const G2=MC.makeGameState({seed:9,players:[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}],villainCode:'02016',mainScheme:'01097b',encounterCodes:[]});
  MC.setupGame(G2);
  const pl2=G2.players[0]; if(pl2.form!=='hero') MC.flipForm(G2,pl2,{force:true});
  const t2=MC.makeInstance(G2,'death-from-above',{});
  MC.fireCardHook(G2, t2, 'whenRevealed', { player: pl2 });
  // 02016 ATK 3 + stage 3 = 6
  assert(G2.pending && G2.pending.kind==='defense' && G2.pending.amount===6,
    'Death from Above 히어로 → 공격 ATK3+스테이지3 = 피해 6 pending');
}

/* Goblin Reinforcements — WR: 전장 고블린 하수인 수만큼 이 스킴 위협 */
{
  const G=mkGame(); const p0=G.players[0], p1=G.players[1];
  // 고블린 하수인 3마리 전장 배치 (soldier×2 p0, thrall×1 p1)
  const s1=MC.makeInstance(G,'goblin-soldier',{}); s1.engagedWith=p0.uid; p0.engagedMinions.push(s1);
  const s2=MC.makeInstance(G,'goblin-soldier',{}); s2.engagedWith=p0.uid; p0.engagedMinions.push(s2);
  const th=MC.makeInstance(G,'goblin-thrall',{}); th.engagedWith=p1.uid; p1.engagedMinions.push(th);
  assert(MC.goblinMinionCount(G)===3, '고블린 하수인 카운트 = 3');
  const ss=MC.makeInstance(G,'goblin-reinforcements',{}); const base=ss.threat||0;
  MC.fireCardHook(G, ss, 'whenRevealed', { player: p0 });
  assert((ss.threat||0)===base+3, 'Goblin Reinforcements — 고블린 3마리 → 위협 +3');

  // 고블린 하수인 0마리 → 추가 위협 0
  const G2=mkGame();
  const ss2=MC.makeInstance(G2,'goblin-reinforcements',{}); const b2=ss2.threat||0;
  MC.fireCardHook(G2, ss2, 'whenRevealed', { player: G2.players[0] });
  assert((ss2.threat||0)===b2, 'Goblin Reinforcements — 고블린 0마리 → 추가 위협 없음');
}

/* ── Mutagen 메인 스킴 4면 ── */
/* 02017a 셋업: 각 플레이어에 Goblin Thrall 배치 (02017b onSetup) */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')},{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:11,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  assert(G.players.every(pl=>pl.engagedMinions.some(m=>m.defCode==='goblin-thrall')),
    'Mutagen 셋업 — 각 플레이어에 Goblin Thrall 배치');
}
/* 02017b 완료: 고블린 미교전 플레이어가 덱 3장 버리고 첫 고블린 배치 → 2A→2B 진행 */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:11,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  // 셋업으로 이미 thrall 교전 중 → 완료 시 그 플레이어는 소환 스킵(고블린 교전 중)
  const ms=G.mainScheme; ms.threat=ms.maxThreat;
  MC.onMainSchemeThreshold(G, ms);
  assert(G.mainScheme.defCode==='02018b', '02017b 완료 → 2A 거쳐 2B 진행');
}
/* 02018b 동적 가속: 고블린 적 수(빌런+하수인)만큼 가속 */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:11,players,villainCode:'02016',mainScheme:'02018b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  // 셋업 없이 시작(02018b 직접) — 빌런 고블린 1 + thrall 없음
  pl.engagedMinions.length=0;   // 하수인 정리
  assert(MC.goblinEnemyCount(G)===1, '고블린 적 수 = 빌런(고블린) 1');
  const s1=MC.makeInstance(G,'goblin-soldier',{}); s1.engagedWith=pl.uid; pl.engagedMinions.push(s1);
  assert(MC.goblinEnemyCount(G)===2, '고블린 적 수 = 빌런 + 솔저 = 2');
}
/* 02018b 완료 → 플레이어 패배 (nextStage 없음, 자동) */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:11,players,villainCode:'02016',mainScheme:'02018b',encounterCodes:[]});
  MC.setupGame(G);
  const ms=G.mainScheme; ms.threat=ms.maxThreat;
  MC.onMainSchemeThreshold(G, ms);
  assert(G.over && G.over.result==='loss', '02018b 완료 → 플레이어 패배');
}

/* ── Goblin Glider 부착물 ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:12,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  // 데이터 검증
  const gd=MC.cardDef('02019');
  assert(gd.attachTarget==='highestHpEnemy' && gd.attachStats.attack===1 && gd.activatedAbility.payCost.type==='energy' && gd.activatedAbility.payCost.count===2,
    'Goblin Glider — 최고HP 타겟 + ATK+1 + 히어로액션 energy2');
  // 최고 HP 적 = 빌런(02014 HP16). 부착 → 빌런 ATK +1
  const vAtk0=G.villain.attack;
  const glider=MC.makeInstance(G,'02019',{});
  MC.resolveEncounterCard(G, pl, glider);
  assert((G.villain.attachments||[]).some(a=>a.defCode==='02019'), 'Goblin Glider → 최고HP 적(빌런)에 부착');
  assert(G.villain.attack===vAtk0+1, '부착 → 빌런 ATK +1');
  // 히어로 액션(energy2)으로 버림 → detach + ATK 원복
  const hand=[]; for(let i=0;i<2;i++){const e=MC.makeInstance(G,'energy',{}); pl.hand.push(e); hand.push({kind:'hand',uid:e.uid});}
  MC.dispatch(G,{type:'useCardAbility',player:pl.uid,cardUid:glider.uid,payment:hand});
  assert(!(G.villain.attachments||[]).some(a=>a.defCode==='02019') && G.villain.attack===vAtk0,
    'Goblin Glider 히어로액션 → detach + ATK 원복');
}

/* ── Hysteria 부착물 (추가 부스트) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:13,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const hd=MC.cardDef('hysteria');
  assert(hd.attachTarget==='villain' && hd.grantsExtraBoost===1 && hd.activatedAbility.payCost.type==='mental' && !hd.todoFx,
    'Hysteria — GG 부착 + grantsExtraBoost 1 + 히어로액션 mental2 + todoFx 해제');
  // 부착 전: 추가 부스트 0
  assert(MC.villainExtraBoost(G,'scheme')===0 && MC.villainExtraBoost(G,'attack')===0, '부착 전 추가 부스트 0');
  // Hysteria 부착 → 공격·스킴 모두 +1
  const hy=MC.makeInstance(G,'hysteria',{});
  MC.attachTo(G, hy, G.villain);
  assert(MC.villainExtraBoost(G,'scheme')===1 && MC.villainExtraBoost(G,'attack')===1,
    'Hysteria 부착 → 공격+스킴 추가 부스트 각 1');
  // 히어로 액션(mental2)으로 버림 → 추가 부스트 원복
  const hand=[]; for(let i=0;i<2;i++){const m=MC.makeInstance(G,'genius',{}); if(!MC.resourceIconsOf(m).mental){/*보정*/} }
  // mental 아이콘 카드가 덱에 없을 수 있으니 detach 경로만 직접 검증
  MC.EFFECTS.discardSelfAttachment(G, {}, { self: hy });
  assert(MC.villainExtraBoost(G,'scheme')===0, 'Hysteria 버림 → 추가 부스트 0 원복');
}

/* ── Pumpkin Bombs 부착물 (공격 후 강제반응) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:14,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0]; if(pl.form!=='hero') MC.flipForm(G,pl,{force:true});
  const pd=MC.cardDef('02021');
  assert(pd.attachTarget==='villain' && pd.attackResponseEffects[0].fx==='dealDamage' && pd.attackResponseEffects[0].amount===2 && pd.activatedAbility.payCost.type==='physical',
    'Pumpkin Bombs — 빌런 부착 + 공격후 간접2 + 히어로액션 physical2');
  // 부착
  const pb=MC.makeInstance(G,'02021',{}); MC.attachTo(G, pb, G.villain);
  assert((G.villain.attachments||[]).some(a=>a.defCode==='02021'), 'Pumpkin Bombs 빌런 부착');
  // 빌런 공격 → 방어 후 강제반응: 버림 + 간접 2
  const hp0=pl.hp;
  G.pending={kind:'defense',player:pl.uid,attackerUid:G.villain.uid,amount:0,prevented:0};  // 피해 0으로도 발동해야(피해 무관)
  MC.dispatch(G,{type:'resolveDefense',player:pl.uid,defender:'none'});
  assert(!(G.villain.attachments||[]).some(a=>a.defCode==='02021'), 'Pumpkin Bombs — 공격 후 버림(피해 0이어도)');
  assert(pl.hp===hp0-2, 'Pumpkin Bombs — 공격 후 간접 피해 2');
}

/* ── Goblin Knight (강제반응 소환 + 부스트★ 셔플백) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:15,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  const kd=MC.cardDef('goblin-knight');
  assert(kd.hp===7 && kd.forcedResponseEffects[0].fx==='discardEncounterSummonGoblin' && kd.boostStarShuffleBack===true && !kd.todoFx,
    'Goblin Knight — HP7 + 강제반응 소환 + 부스트★ 셔플백 + todoFx 해제');
  // 강제반응: 조우덱 맨 위를 고블린 하수인으로 세팅 → 공격 후 배치
  const goblin=MC.makeInstance(G,'goblin-soldier',{}); G.encounterDeck.unshift(goblin);
  const before=pl.engagedMinions.length;
  MC.EFFECTS.discardEncounterSummonGoblin(G, {}, { player: pl });
  assert(pl.engagedMinions.length===before+1 && pl.engagedMinions.some(m=>m.defCode==='goblin-soldier'),
    'Goblin Knight 강제반응 → 고블린 하수인 배치');
  // 비고블린이면 그냥 버림
  const nong=MC.makeInstance(G,'energy',{}); G.encounterDeck.unshift(nong);
  const b2=pl.engagedMinions.length, d2=G.encounterDiscard.length;
  MC.EFFECTS.discardEncounterSummonGoblin(G, {}, { player: pl });
  assert(pl.engagedMinions.length===b2 && G.encounterDiscard.length===d2+1, '비고블린 카드 → 배치 없이 버림');
  // 부스트★ 셔플백: resolveBoostStar → 조우덱에 복귀, true 반환(버림 안함)
  const knight=MC.makeInstance(G,'goblin-knight',{});
  const deck0=G.encounterDeck.length;
  const placed=MC.resolveBoostStar(G, pl, knight, 'attack');
  assert(placed===true && G.encounterDeck.some(c=>c.defCode==='goblin-knight'),
    'Goblin Knight 부스트★ → 조우덱 셔플백(버림 안함)');
}

/* ── Goblin Nation (패시브 +1 ATK + 부스트★ 사이드스킴 배치) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:16,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  const vAtk=G.villain.attack;   // 02014 ATK 2
  // 고블린 하수인 배치
  const s1=MC.makeInstance(G,'goblin-soldier',{}); s1.engagedWith=pl.uid; pl.engagedMinions.push(s1);
  // Goblin Nation 없을 때: 패시브 0
  assert(MC.enemyAtk(G,G.villain)===vAtk && MC.enemyAtk(G,s1)===s1.attack, 'Goblin Nation 없음 → ATK 패시브 0');
  // 부스트★로 Goblin Nation 전장 배치
  const nation=MC.makeInstance(G,'goblin-nation',{});
  const placed=MC.resolveBoostStar(G, pl, nation, 'attack');
  assert(placed===true && G.sideSchemes.some(s=>s.defCode==='goblin-nation'), 'Goblin Nation 부스트★ → 사이드스킴 전장 배치');
  // 패시브: 빌런·하수인 모두 +1 ATK
  assert(MC.enemyAtk(G,G.villain)===vAtk+1, 'Goblin Nation → 빌런(고블린) ATK +1');
  assert(MC.enemyAtk(G,s1)===s1.attack+1, 'Goblin Nation → 고블린 하수인 ATK +1');
  // 사본 2장이면 +2
  const nation2=MC.makeInstance(G,'goblin-nation',{}); MC.resolveBoostStar(G, pl, nation2, 'attack');
  assert(MC.enemyAtk(G,G.villain)===vAtk+2, 'Goblin Nation 2장 → ATK +2');
}

/* ── Overrun (격퇴 시 discard-summon) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:17,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  const od=MC.cardDef('overrun');
  assert(od.whenCompletedEffects[0].fx==='overrunDiscardSummon' && od.whenCompletedEffects[0].count===2 && !od.todoFx,
    'Overrun — 격퇴 시 조우2 discard-summon + todoFx 해제');
  // 조우덱 맨 위 2장을 고블린으로 세팅 → 격퇴 시 둘 다 배치
  const g1=MC.makeInstance(G,'goblin-soldier',{}); const g2=MC.makeInstance(G,'goblin-thrall',{});
  G.encounterDeck.unshift(g1); G.encounterDeck.unshift(g2);
  const before=pl.engagedMinions.length;
  MC.EFFECTS.overrunDiscardSummon(G, {count:2}, {player:pl});
  assert(pl.engagedMinions.length===before+2, 'Overrun — 고블린 2장 전부 교전 배치');
  // 사이드스킴으로 등장 후 격퇴 시 whenCompleted 발화 확인
  const ss=MC.makeInstance(G,'overrun',{isMain:false}); ss.threat=0; G.sideSchemes.push(ss);
  const g3=MC.makeInstance(G,'goblin-soldier',{}); G.encounterDeck.unshift(g3);
  const b2=pl.engagedMinions.length;
  MC.onSideSchemeCleared(G, ss);
  assert(pl.engagedMinions.length>b2, 'Overrun 격퇴(onSideSchemeCleared) → whenCompleted 발화로 소환');
}

/* ── I See You (알터에고 부스트 억제 + 조건부 부스트 아이콘) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:18,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  const d=MC.cardDef('i-see-you');
  assert(d.whenRevealedEffects[0].fx==='villainAttacks' && d.whenRevealedEffects[0].withBoost===true && d.whenRevealedEffects[0].noBoostIfAlterEgo===true && d.boostBonusIfGoblinEngaged===1 && !d.todoFx,
    'I See You — WR 공격+부스트/알터에고억제 + 조건부부스트 + todoFx 해제');
  // 히어로 폼: 공격에 부스트 카드 부여됨
  if(pl.form!=='hero') MC.flipForm(G,pl,{force:true});
  G.encounterDeck.unshift(MC.makeInstance(G,'goblin-soldier',{}));  // 부스트로 뽑힐 카드
  const t1=MC.makeInstance(G,'i-see-you',{});
  MC.fireCardHook(G, t1, 'whenRevealed', {player:pl});
  assert(G.pending && G.pending.kind==='defense' && G.pending.boostCard, 'I See You 히어로 → 공격 + 부스트 카드 부여');
  G.pending=null;
  // 알터에고 폼: 부스트 생략
  if(pl.form!=='alter-ego') MC.flipForm(G,pl,{force:true});
  G.encounterDeck.unshift(MC.makeInstance(G,'goblin-soldier',{}));
  const t2=MC.makeInstance(G,'i-see-you',{});
  MC.fireCardHook(G, t2, 'whenRevealed', {player:pl});
  assert(G.pending && G.pending.kind==='defense' && !G.pending.boostCard, 'I See You 알터에고 → 부스트 카드 생략');
  // 조건부 부스트: 고블린 교전 시 boostOf +1
  const iseeCard=MC.makeInstance(G,'i-see-you',{});  // base boost 1
  const plNoGob={engagedMinions:[]};
  assert(MC.boostOf(G, iseeCard, plNoGob)===1, 'I See You boostOf — 고블린 없음 → 1');
  const gob=MC.makeInstance(G,'goblin-soldier',{});
  const plGob={engagedMinions:[gob]};
  assert(MC.boostOf(G, iseeCard, plGob)===2, 'I See You boostOf — 고블린 교전 → 1+1=2');
}

/* ── Overconfidence (폼조건부 + 조건부 surge) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  // 알터에고: 암약 위협 3+ → surge (02016 SCH2, 하지만 스테이지 보너스 없음 → 위협 2 < 3, surge 안됨)
  const G=MC.makeGameState({seed:19,players,villainCode:'02016',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0]; if(pl.form!=='alter-ego') MC.flipForm(G,pl,{force:true});
  const t=MC.makeInstance(G,'overconfidence',{});
  MC.fireCardHook(G, t, 'whenRevealed', {player:pl});
  // 02016 SCH 2 < 3 → surge 없음
  assert(!t.surge, 'Overconfidence 알터에고 — 위협 2<3 → surge 없음');
  // SCH 높은 상황: 빌런 SCH 조작해 3+ 위협
  const G2=MC.makeGameState({seed:19,players:[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}],villainCode:'02016',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G2); const pl2=G2.players[0]; if(pl2.form!=='alter-ego') MC.flipForm(G2,pl2,{force:true});
  G2.villain.scheme=4;  // SCH 4 ≥ 3
  const t2=MC.makeInstance(G2,'overconfidence',{});
  MC.fireCardHook(G2, t2, 'whenRevealed', {player:pl2});
  assert(t2.surge===true, 'Overconfidence 알터에고 — 위협 4≥3 → surge');

  // 히어로: 공격 피해 3+ → surge (pending.surgeIfDamageGTE)
  const G3=MC.makeGameState({seed:19,players:[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}],villainCode:'02016',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G3); const pl3=G3.players[0]; if(pl3.form!=='hero') MC.flipForm(G3,pl3,{force:true});
  const t3=MC.makeInstance(G3,'overconfidence',{});
  MC.fireCardHook(G3, t3, 'whenRevealed', {player:pl3});
  assert(G3.pending && G3.pending.surgeIfDamageGTE===3, 'Overconfidence 히어로 → pending surgeIfDamageGTE 3');
  G3.encounterDeck.push(MC.makeInstance(G3,'goblin-soldier',{}));  // surge가 뽑을 카드 공급
  const pe0=G3.pendingEncounters.length;
  MC.dispatch(G3,{type:'resolveDefense',player:pl3.uid,defender:'none'});  // 무방어 → 피해 3(02016 ATK3) ≥ 3
  assert(G3.pendingEncounters.length>pe0, 'Overconfidence 히어로 — 피해 3≥3 → surge(조우 1장 추가)');
}

/* ── Wicked Ambitions (조우 버림 + 고블린마다 선택 연쇄) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:20,players,villainCode:'02015',mainScheme:'02017b',encounterCodes:[]});  // 02015 = 스테이지 2 → X=4
  MC.setupGame(G);
  const pl=G.players[0];
  const d=MC.cardDef('wicked-ambitions');
  assert(d.whenRevealed==='wickedAmbitions' && !d.todoFx, 'Wicked Ambitions — WR 핸들러 + todoFx 해제');
  // 조우덱 맨 위 2장을 고블린으로 (나머지는 비고블린 자원)
  G.encounterDeck=[]; 
  G.encounterDeck.push(MC.makeInstance(G,'goblin-soldier',{}));
  G.encounterDeck.push(MC.makeInstance(G,'goblin-thrall',{}));
  G.encounterDeck.push(MC.makeInstance(G,'energy',{}));
  G.encounterDeck.push(MC.makeInstance(G,'energy',{}));
  const t=MC.makeInstance(G,'wicked-ambitions',{});
  MC.fireCardHook(G, t, 'whenRevealed', {player:pl});
  // X=4 버림, 고블린 2 → 첫 선택 pending
  assert(G.pending && G.pending.kind==='revealChoice' && G._pendingWickedGoblins, 'X=4 버림, 고블린 2 → 첫 선택 대기');
  // 첫 고블린: 배치 선택
  const eng0=pl.engagedMinions.length;
  MC.dispatch(G,{type:'resolveRevealChoice',option:'summon'});
  assert(pl.engagedMinions.length===eng0+1, '첫 고블린 → 배치 선택 → 교전 +1');
  // 두 번째 고블린 선택 연쇄
  assert(G.pending && G.pending.kind==='revealChoice', '두 번째 고블린 선택 연쇄 대기');
  // 두 번째: 피해 3 선택
  const hp0=pl.hp;
  MC.dispatch(G,{type:'resolveRevealChoice',option:'damage'});
  assert(pl.hp===hp0-3, '둘째 고블린 → 피해 3 선택');
  assert(!G.pending, '고블린 2마리 선택 완료 → pending 해제');
}

/* ── Mutagen Formula 시나리오 엔트리 (플레이 연결) ── */
{
  const scen=MC.SCENARIOS.mutagenFormula;
  assert(scen && scen.villainStart==='02014' && scen.mainScheme==='02017b', 'mutagenFormula 시나리오 등록');
  const enc=MC.buildEncounter('mutagenFormula');
  assert(enc.length>0 && enc.every(c=>MC.cardDef(c)), '조우덱 전부 정의됨 ('+enc.length+'장)');
  const G=MC.makeGameState({seed:1,players:[{heroCode:'01001a',deckCodes:Array(40).fill('energy')}],
    villainCode:scen.villainStart, mainScheme:scen.mainScheme, encounterCodes:enc});
  MC.setupGame(G);
  assert(G.villain.defCode==='02014' && G.villain.hp===16, '셋업 — 빌런 02014 HP16');
  assert(G.mainScheme.defCode==='02017b' && G.mainScheme.threat===2, '셋업 — 메인 02017b 위협 2');
  assert(G.players[0].engagedMinions.some(m=>m.defCode==='goblin-thrall'), '셋업 — Goblin Thrall 배치');
}

/* ── Goblin Gimmicks 모듈러 (Regenerative Healing + Intimidation) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:21,players,villainCode:'02015',mainScheme:'02017b',encounterCodes:[]});  // 02015 스테이지 2
  MC.setupGame(G);
  // Regenerative Healing: 빌런 피해 후 2×스테이지(=4) 회복
  G.villain.hp = G.villain.maxHp - 10;  // 10 피해 상태
  const hp0=G.villain.hp;
  const t=MC.makeInstance(G,'regenerative-healing',{});
  MC.fireCardHook(G, t, 'whenRevealed', {player:G.players[0]});
  assert(G.villain.hp===hp0+4, 'Regenerative Healing — 빌런 2×스테이지2=4 회복');
  assert(!t.surge, '회복 발생 → surge 없음');
  // 풀 HP에서 공개 → 회복 0 → surge
  G.villain.hp=G.villain.maxHp;
  const t2=MC.makeInstance(G,'regenerative-healing',{});
  MC.fireCardHook(G, t2, 'whenRevealed', {player:G.players[0]});
  assert(t2.surge===true, 'Regenerative Healing — 풀HP 회복 0 → surge');
  // 부스트★: 빌런 2 회복
  G.villain.hp=G.villain.maxHp-5;
  MC.resolveBoostStar(G, G.players[0], MC.makeInstance(G,'regenerative-healing',{}), 'attack');
  assert(G.villain.hp===G.villain.maxHp-3, 'Regenerative Healing 부스트★ — 빌런 2 회복');
}
{
  // Intimidation: WR 선택(pay/boost) + boost 선택 시 villainStoredBoost
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:21,players,villainCode:'02015',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const t=MC.makeInstance(G,'02035',{});
  MC.fireCardHook(G, t, 'whenRevealed', {player:G.players[0]});
  assert(G.pending && G.pending.kind==='revealChoice' && G.pending.options.length===2, 'Intimidation — 선택 pending(pay/boost)');
  MC.dispatch(G,{type:'resolveRevealChoice',option:'boost'});
  assert(G.villainStoredBoost===1, 'Intimidation boost 선택 → 빌런 저장 부스트 +1');
  // 저장 부스트는 다음 활성화에서 villainExtraBoost로 소비
  assert(MC.villainExtraBoost(G,'attack')===1 && G.villainStoredBoost===0, '저장 부스트 → 다음 활성화 소비');
  // 부스트★도 저장 부스트 +1
  MC.resolveBoostStar(G, G.players[0], MC.makeInstance(G,'02035',{}), 'attack');
  assert(G.villainStoredBoost===1, 'Intimidation 부스트★ → 저장 부스트 +1');
}
{
  // 모듈러 조립: goblin-gimmicks가 시나리오에 섞임
  const enc=MC.buildEncounter('mutagenFormula',['goblin-gimmicks']);
  const base=MC.buildEncounter('mutagenFormula',[]).length;
  assert(enc.length===base+8 && enc.every(c=>MC.cardDef(c)), 'goblin-gimmicks 모듈러 8장 조립·전부 정의');
}

/* ── A Mess of Things 모듈러 (Scorpion/Tail Sweep/side scheme) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:22,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0];
  // Scorpion: quickstrike + stunOnDamage
  const sc=MC.cardDef('scorpion');
  assert(sc.quickstrike===true && sc.stunOnDamage===true && !sc.todoFx, 'Scorpion — quickstrike + stunOnDamage');
  // Scorpion 공격 피해 → 대상 기절 (stunOnDamage 중앙 처리)
  if(pl.form!=='hero') MC.flipForm(G,pl,{force:true});
  const scorp=MC.makeInstance(G,'scorpion',{}); scorp.engagedWith=pl.uid; pl.engagedMinions.push(scorp);
  G.pending={kind:'defense',player:pl.uid,attackerUid:scorp.uid,amount:3};
  MC.dispatch(G,{type:'resolveDefense',player:pl.uid,defender:'none'});
  assert(pl.status.stunned>0, 'Scorpion 공격 피해 → 대상 기절');
  // A Mess of Things: 기절 아군 1명 → 위협 +2
  const ss=MC.makeInstance(G,'a-mess-of-things',{isMain:false}); ss.threat=0;
  MC.fireCardHook(G, ss, 'whenRevealed', {player:pl});
  assert(ss.threat===2, 'A Mess of Things — 기절 아군 1 → 위협 +2');
  // Tail Sweep: Scorpion 있으면 공격 / 없으면 기절
  pl.status.stunned=0; G.pending=null;
  const ts=MC.makeInstance(G,'tail-sweep',{});
  MC.fireCardHook(G, ts, 'whenRevealed', {player:pl});
  assert(G.pending && G.pending.attackerUid===scorp.uid, 'Tail Sweep — Scorpion 있음 → Scorpion 공격');
  // Scorpion 제거 후 Tail Sweep → 기절
  pl.engagedMinions=[]; G.pending=null;
  const ts2=MC.makeInstance(G,'tail-sweep',{});
  MC.fireCardHook(G, ts2, 'whenRevealed', {player:pl});
  assert(pl.status.stunned>0 && !G.pending, 'Tail Sweep — Scorpion 없음 → 기절');
  // 모듈러 조립
  const enc=MC.buildEncounter('riskyBusiness',['a-mess-of-things']);
  assert(enc.every(c=>MC.cardDef(c)), 'a-mess-of-things 모듈러 전부 정의');
}

/* ── Power Drain 모듈러 (boostDrain 인덱스 + Electro) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}];
  const G=MC.makeGameState({seed:23,players,villainCode:'02015',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0]; if(pl.form!=='hero') MC.flipForm(G,pl,{force:true});
  // 부스트 총 3짜리 카드들을 조우덱에 (goblin-soldier boost 확인용 대신 boost 있는 카드)
  const b=MC.cardDef('hired-gun').boost;  // 부스트값 있는 카드
  // Lightning Bolt: 조우 2장 버림 → 부스트당 간접 피해
  G.encounterDeck=[MC.makeInstance(G,'hired-gun',{}),MC.makeInstance(G,'hired-gun',{})];
  const hp0=pl.hp;
  const lb=MC.makeInstance(G,'lightning-bolt',{});
  MC.fireCardHook(G, lb, 'whenRevealed', {player:pl});
  assert(G._lastBoostDiscarded===b*2, 'Lightning Bolt — 조우 2장 부스트 '+(b*2)+' 집계');
  assert(pl.hp===hp0-b*2, 'Lightning Bolt — 부스트당 간접 피해 '+(b*2));
  // Shock Therapy: 빌런 회복
  G.villain.hp=G.villain.maxHp-10;
  G.encounterDeck=[MC.makeInstance(G,'hired-gun',{})];  // 1/히어로=1장
  const vhp=G.villain.hp;
  const st=MC.makeInstance(G,'shock-therapy',{});
  MC.fireCardHook(G, st, 'whenRevealed', {player:pl});
  assert(G.villain.hp===vhp+b, 'Shock Therapy — 부스트당 빌런 회복 '+b);
  // EM Pulse: Electro가 버려지면 소환
  G.encounterDeck=[]; for(let i=0;i<6;i++)G.encounterDeck.push(MC.makeInstance(G,'energy',{}));
  G.encounterDeck.push(MC.makeInstance(G,'electro',{}));  // 7번째 = electro
  const emp=MC.makeInstance(G,'electromagnetic-pulse',{});
  MC.fireCardHook(G, emp, 'whenRevealed', {player:pl});
  assert(pl.engagedMinions.some(m=>m.defCode==='electro'), 'EM Pulse — Electro 버려짐 → 전장 배치');
  // Electro 데이터 + 애니
  const ed=MC.cardDef('electro');
  assert(ed.vfx.attack==='electroStrike' && ed.forcedResponseEffects[0].fx==='boostDrain' && !ed.todoFx, 'Electro — 강제반응 boostDrain + 공격 애니 + todoFx 해제');
  // 모듈러 조립
  const enc=MC.buildEncounter('riskyBusiness',['power-drain']);
  assert(enc.every(c=>MC.cardDef(c)), 'power-drain 모듈러 전부 정의');
}

/* ── Running Interference 모듈러 (Tombstone + Running Interference) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('genius')}];  // genius=mental 자원
  const G=MC.makeGameState({seed:24,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0]; if(pl.form!=='hero') MC.flipForm(G,pl,{force:true});
  // Tombstone: 공격+피해 후 자원 버림
  const td=MC.cardDef('tombstone');
  assert(td.vfx.attack==='tombstoneStrike' && td.attackDamagedEffects[0].fx==='discardResourceFromHand' && !td.todoFx, 'Tombstone — 공격+피해 후 자원버림 + 애니 + todoFx 해제');
  const tomb=MC.makeInstance(G,'tombstone',{}); tomb.engagedWith=pl.uid; pl.engagedMinions.push(tomb);
  // 손패에 mental 자원 카드 확보
  pl.hand=[MC.makeInstance(G,'genius',{}),MC.makeInstance(G,'genius',{})];
  const hand0=pl.hand.length;
  G.pending={kind:'defense',player:pl.uid,attackerUid:tomb.uid,amount:3};
  MC.dispatch(G,{type:'resolveDefense',player:pl.uid,defender:'none'});
  if(G.pending && G.pending.kind==='resourceDiscardPick')   // 자원 2장+ → 플레이어 선택
    MC.ACTIONS.resolveResourceDiscardPick(G,{player:G.pending.player,uid:MC.resourceCandidates(pl,G.pending.types)[0].uid});
  assert(pl.hand.length===hand0-1, 'Tombstone 공격+피해 → 손패 자원 1장 버림 (선택)');
  // Running Interference: 각 플레이어 선택
  const ri=MC.makeInstance(G,'running-interference',{isMain:false}); ri.threat=0; G.sideSchemes.push(ri);
  MC.fireCardHook(G, ri, 'whenRevealed', {player:pl});
  assert(G.pending && G.pending.kind==='revealChoice', 'Running Interference — 각 플레이어 선택 pending');
  MC.dispatch(G,{type:'resolveRevealChoice',option:'threat'});
  assert(ri.threat===2, 'Running Interference — 위협 2 선택 → 위협 +2');
}

/* ── 신분 부착 (All Tied Up / Media Coverage) ── */
{
  const players=[{heroCode:'01001a',deckCodes:Array(20).fill('genius')}];
  const G=MC.makeGameState({seed:25,players,villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
  MC.setupGame(G);
  const pl=G.players[0]; if(pl.form!=='hero') MC.flipForm(G,pl,{force:true});
  // All Tied Up 부착 → 준비/변신 금지
  const atu=MC.makeInstance(G,'all-tied-up',{});
  (pl.identityAttachments=pl.identityAttachments||[]).push(atu); atu.attachedToPlayer=pl.uid;
  pl.exhausted=true;
  MC.readyAllFor(G, pl);
  assert(pl.exhausted===true, 'All Tied Up — 준비 불가(exhausted 유지)');
  let flipBlocked=false;
  try{ MC.flipForm(G,pl,{force:true}); }catch(e){ flipBlocked=true; }
  assert(flipBlocked, 'All Tied Up — 형태 변경 불가');
  // 신분 부착 버림 → 원복
  MC.EFFECTS.discardSelfAttachment(G,{},{self:atu});
  assert(!(pl.identityAttachments||[]).length, 'All Tied Up 버림 → 신분 부착 제거');
  MC.readyAllFor(G, pl);
  assert(pl.exhausted===false, '버림 후 준비 정상');

  // Media Coverage: wrDoubling 플래그 + identityAttachHas 감지
  const mc=MC.makeInstance(G,'media-coverage',{});
  pl.identityAttachments=[mc]; mc.attachedToPlayer=pl.uid;
  const mcd=MC.cardDef('media-coverage');
  assert(mcd.wrDoubling===true && mcd.attachTarget==='identity' && mcd.activatedAbility.form==='alter-ego' && !mcd.todoFx,
    'Media Coverage — wrDoubling + 신분 부착 + 알터에고 액션 + todoFx 해제');
  assert(MC.identityAttachHas(G, pl, 'wrDoubling')===true, 'Media Coverage 부착 → wrDoubling 감지');
  // WR 더블링 실제 발동 (resolveEncounterCard 경로): Lightning Bolt 피해 2배
  {
    const G2=MC.makeGameState({seed:26,players:[{heroCode:'01001a',deckCodes:Array(20).fill('energy')}],villainCode:'02014',mainScheme:'02017b',encounterCodes:[]});
    MC.setupGame(G2); const p2=G2.players[0]; if(p2.form!=='hero') MC.flipForm(G2,p2,{force:true});
    const mc2=MC.makeInstance(G2,'media-coverage',{}); p2.identityAttachments=[mc2]; mc2.attachedToPlayer=p2.uid;
    const bb=MC.cardDef('hired-gun').boost, h0=p2.hp;
    for(let i=0;i<4;i++)G2.encounterDeck.push(MC.makeInstance(G2,'hired-gun',{}));
    MC.resolveEncounterCard(G2, p2, MC.makeInstance(G2,'lightning-bolt',{}));
    assert(h0-p2.hp===bb*2*2, 'Media Coverage — Lightning Bolt WR 2회 발동 (피해 2배)');
  }
  // 모듈러 조립
  const enc=MC.buildEncounter('riskyBusiness',['running-interference']);
  assert(enc.every(c=>MC.cardDef(c)) && enc.includes('all-tied-up') && enc.includes('media-coverage'),
    'running-interference 모듈러 전부 정의');
}

console.log('\n[test_goblin_mutagen] '+pass+'개 통과 — Mutagen Formula 고블린 하수인');
