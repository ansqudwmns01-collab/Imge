/* test_titanias_fury.js — 타이타니아의 분노(01164) 배신 회귀
   ★ titaniaFury(전장 타이타니아 공격 / 부재 시 회복+surge) + addVillainBoostCard(부스트★).
   사용: node tests/test_titanias_fury.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}

// ① 타이타니아 전장: 히어로 공격 (동적 ATK = HP)
{
  const G = mk(69001); const pl = G.players[0]; pl.form = 'hero';
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion'; t.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(t);
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'titanias-fury', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.hp === hp0 - 6, '타이타니아(HP6→ATK6) 히어로 공격 (' + hp0 + '→' + pl.hp + ')');
  assert(inst.surge !== true, '공격 성공 시 surge 없음');
}

// ② 타이타니아 부재: surge (회복 대상 없음)
{
  const G = mk(69002); const pl = G.players[0]; pl.form = 'hero';
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'titanias-fury', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.hp === hp0, '타이타니아 부재: 히어로 피해 없음');
  assert(inst.surge === true, '타이타니아 부재: surge');
}

// ③ 타이타니아 기절: 공격 불가 → 회복 + surge
{
  const G = mk(69003); const pl = G.players[0]; pl.form = 'hero';
  const t = MC.makeInstance(G, 'titania', {}); t.type = 'minion';
  t.status = { stunned:1, confused:0, tough:0 };
  t.maxHp = MC.cardDef('titania').hp; t.hp = 2; // 피해 입은 상태
  pl.engagedMinions.push(t);
  const hp0 = pl.hp;
  const inst = MC.makeInstance(G, 'titanias-fury', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  assert(pl.hp === hp0, '기절 타이타니아: 히어로 피해 없음');
  assert(t.hp === t.maxHp, '기절 타이타니아: 완전 회복 (' + t.hp + '/' + t.maxHp + ')');
  assert(inst.surge === true, '기절 타이타니아: surge');
}

// ④ 부스트★: 빌런 부스트 카드 +1
{
  const G = mk(69004); const pl = G.players[0]; pl.form = 'hero';
  const b0 = G._extraBoostThisActivation || 0;
  const bc = MC.makeInstance(G, 'titanias-fury', {});
  MC.resolveBoostStar(G, pl, bc, 'attack');
  assert((G._extraBoostThisActivation || 0) === b0 + 1, '부스트★: 빌런 부스트 카드 +1');
}

console.log('══ 타이타니아의 분노 (titaniaFury + 부스트★) 회귀 통과 ══');
