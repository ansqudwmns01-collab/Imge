/* test_yon_rogg.js — 욘-로그(01177) 하수인 회귀
   ★ Forced Response: 공격 후 사이키-마그니트론에 위협 +1 (forcedResponseEffects + placeThreat namedSide).
   사용: node tests/test_yon_rogg.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 필드 확인
{
  const d = MC.cardDef('yon-rogg');
  assert(Array.isArray(d.forcedResponseEffects), 'forcedResponseEffects 배열');
  assert(d.attack === 3 && d.hp === 5, 'ATK 3 / HP 5');
}

// ② forcedResponseEffects 실행 → 사이키-마그니트론 위협 +1
{
  const G = mk(82001); const pl = G.players[0]; pl.form = 'hero';
  const ss = revealSide(G, pl, 'psyche-magnitron');
  const t0 = ss.threat;
  const yon = MC.makeInstance(G, 'yon-rogg', {}); yon.type = 'minion';
  pl.engagedMinions.push(yon);
  // 강제반응 효과 직접 실행
  MC.runEffectList(G, MC.cardDef('yon-rogg').forcedResponseEffects, { player: pl, self: yon });
  assert(ss.threat === t0 + 1, '공격 후 사이키-마그니트론 위협 +1 (' + t0 + '→' + ss.threat + ')');
}

// ③ 사이키-마그니트론이 없으면 위협 배치 불발 (에러 없이)
{
  const G = mk(82002); const pl = G.players[0]; pl.form = 'hero';
  const yon = MC.makeInstance(G, 'yon-rogg', {}); yon.type = 'minion';
  pl.engagedMinions.push(yon);
  const ms0 = G.mainScheme.threat || 0;
  MC.runEffectList(G, MC.cardDef('yon-rogg').forcedResponseEffects, { player: pl, self: yon });
  assert((G.mainScheme.threat || 0) === ms0, '사이드 스킴 없음: 메인에 잘못 배치 안 함');
}

console.log('══ 욘-로그 (Forced Response) 회귀 통과 ══');
