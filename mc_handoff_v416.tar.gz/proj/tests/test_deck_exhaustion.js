/* test_deck_exhaustion.js — 덱 소진 규칙 (RRG 대조) 영구 회귀
   RRG:
   - 플레이어 덱 소진: ① 버림 더미 섞어 새 덱 ② 즉시 조우 카드 1장
   - 뽑기 중 소진: 리셔플 후 지정 수까지 계속 뽑음
   - 밀(덱에서 버리기) 중 소진: 리셔플 후 새 덱에선 안 버림
   - 조우 덱 소진: 리셔플 + 메인 스킴에 가속 토큰 1개
   사용: node tests/test_deck_exhaustion.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

let pass = 0;
function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg); pass++;
}
function mk(){
  const G = MC.makeGameState({ seed:1,
    players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01094', mainScheme:'01097b', encounterCodes: MC.buildEncounter('rhino') });
  MC.setupGame(G); return G;
}

/* 플레이어 덱 소진: 리셔플 + 조우 카드 1장 (onEmptyPlayerDeck) */
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  pl.discard = pl.deck.splice(0);           // 덱 0, 버림 다수
  const pe0 = G.pendingEncounters.length;
  MC.onEmptyPlayerDeck(G, pl);
  assert(pl.deck.length > 0, '플레이어 덱 소진 — 버림 더미 리셔플로 새 덱 생성');
  assert(G.pendingEncounters.length === pe0 + 1, '플레이어 덱 소진 — 조우 카드 1장 딜(RRG)');
}

/* 뽑기 중 소진: 리셔플 후 지정 수까지 계속 뽑음 */
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  pl.discard = pl.deck.splice(0, pl.deck.length - 2);   // 덱 2장, 버림 다수
  pl.hand = [];
  MC.drawCards(G, pl, 5);
  assert(pl.hand.length === 5, '뽑기 중 소진 — 리셔플 후 지정 수(5장)까지 계속 뽑음(RRG)');
}

/* 밀 중 소진: 리셔플 후 새 덱에선 안 밀음 (millAndGrab) */
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  pl.discard = pl.deck.splice(0, pl.deck.length - 2);   // 덱 2장
  MC.runEffectList(G, [{ fx:'millAndGrab', amount:5, keepResource:'nonexistent' }], { player: pl });
  // 원 덱 2장 밀 → 리셔플(버림→덱, 버림 0) → 새 덱에선 안 밀음 → 버림 0
  assert(pl.discard.length === 0, '밀 중 소진(millAndGrab) — 새 덱에선 안 밀음(RRG)');
}

/* 밀 중 소진: discardTopOfDeck 동일 */
{
  const G = mk(); const pl = G.players[0]; pl.form = 'hero';
  pl.discard = pl.deck.splice(0, pl.deck.length - 1);   // 덱 1장
  const done = MC.discardTopOfDeck(G, pl, 4);
  assert(done === 1 && pl.discard.length === 0, '밀 중 소진(discardTopOfDeck) — 원 덱 1장만 밀고 중단(RRG)');
}

/* 조우 덱 소진: 리셔플 + 가속 토큰 1개 */
{
  const G = mk();
  G.encounterDiscard = G.encounterDeck.splice(0);   // 조우 덱 0, 버림에 다수
  const acc0 = G.acceleration;
  const c = MC.drawEncounterCard(G);
  assert(c !== null, '조우 덱 소진 — 버림 더미 리셔플로 카드 공급');
  assert(G.acceleration === acc0 + 1, '조우 덱 소진 — 메인 스킴 가속 토큰 +1(RRG)');
}

console.log('\n[test_deck_exhaustion] ' + pass + '개 통과 — 덱 소진 규칙(RRG) 검증');
