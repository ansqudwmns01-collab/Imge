/* test_bomb_scare.js — 폭탄 위협(01109) Bomb Scare 사이드 스킴 회귀
   ★ 진짜 가속 아이콘(accelIcons:1) — v162 가속 수정으로 전장 사이드 스킴 가속이 실제 반영.
   - 공개 시: 시작 위협 2 + 인원수당 1 (솔로 3, 2인 4)
   - 가속: 폭탄 위협이 전장에 있으면 빌런 페이즈마다 메인 스킴 +1 (라이노 메인 자체는 가속 없음)
   사용: node tests/test_bomb_scare.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed, np){
  const players = [];
  for (let i = 0; i < np; i++) players.push({ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() });
  const G = MC.makeGameState({ seed, players, villainCode:'01094', mainScheme:'01097b', encounterCodes: Array(30).fill('im-tough') });
  MC.setupGame(G);
  return G;
}
function reveal(G){
  const def = MC.cardDef('bomb-threat');
  const inst = MC.makeInstance(G, 'bomb-threat', {});
  inst.threat = (def.baseThreatPerPlayer||0) * G.players.length + (def.baseThreat||0);
  inst.peakThreat = inst.threat; inst.isMain = false;
  G.sideSchemes.push(inst);
  MC.fireCardHook(G, inst, 'whenRevealed', { player: G.players[0] });
  return inst;
}
function threatGain(G){
  const t0 = G.mainScheme.threat;
  G.phase = 'villain'; G.villainStepMode = false; G.vq = [{ op:'threat' }];
  MC.processVillainQueue(G);
  return G.mainScheme.threat - t0;
}

assert(MC.cardDef('bomb-threat').accelIcons === 1, '가속 아이콘(accelIcons:1) 유지 — 진짜 가속');

// 공개 시 위협: 시작 2 + 인원수
assert(reveal(mk(9001,1)).threat === 3, '솔로: 공개 위협 3 (2+1)');
assert(reveal(mk(9002,2)).threat === 4, '2인: 공개 위협 4 (2+2)');
{
  const G = mk(9003, 1);
  reveal(G);
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'bombScareAlert', '공개: 경보 연출');
}

// 진짜 가속: 전장에 폭탄 위협 있으면 빌런 페이즈 메인 +1
assert(threatGain(mk(9010,1)) === 1, '폭탄 위협 없음: 메인 라운드당 +1 (라이노 기본)');
{
  const G = mk(9011, 1);
  const inst = MC.makeInstance(G, 'bomb-threat', {}); inst.threat = 3; inst.isMain = false;
  G.sideSchemes.push(inst);
  assert(threatGain(G) === 2, '폭탄 위협 있음: 메인 라운드당 +2 (기본1+가속1)');
}
// 폭탄 위협 처치 후 가속 사라짐
{
  const G = mk(9012, 1);
  const inst = MC.makeInstance(G, 'bomb-threat', {}); inst.threat = 3; inst.isMain = false;
  G.sideSchemes.push(inst);
  assert(threatGain(G) === 2, '처치 전: 메인 +2');
  MC.removeThreat(G, inst.uid, 99);
  assert(threatGain(G) === 1, '처치 후: 메인 +1 (가속 소멸)');
}

// 완성 연출
{
  const G = mk(9020, 1);
  const inst = reveal(G);
  G.fxCardEffect = null;
  MC.removeThreat(G, inst.uid, 99);
  assert(!G.sideSchemes.includes(inst), '완성: 격퇴');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'bombDefused', '완성: 해체 연출');
}

console.log('══ 폭탄 위협 (진짜 가속 사이드 스킴) 회귀 통과 ══');
