/* test_upgraded_drones.js — 업그레이드 드론(01142) + 울트론 드론 서브시스템 회귀
   ★ 신규 범용: 환경 카드 전장 유지(G.environments), attachTarget 환경 라우팅,
     spawnFacedownDrone(덱 맨 위 뒷면 드론화), droneStats/droneStatBonus,
     recalcDroneStats(피해 보존·상한 하락 즉사), onDefeated isDrone(뒷면 카드 소유자 버림).
   사용: node tests/test_upgraded_drones.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function envIn(G, pl){
  const env = MC.makeInstance(G, 'ultron-drones', {});
  // 공개 파이프라인 경유 (환경 케이스 검증)
  G.pendingEncounters.push({ player: pl.uid, inst: env });
  MC.dispatch ? null : null;
  // 내부 함수 접근 대신 vq 리빌: reveal 스텝 실행
  G.vq.unshift({ op: 'reveal' });
  MC.processVillainQueue ? MC.processVillainQueue(G) : null;
  return env;
}

// ① 환경 공개 → 전장 유지 (버려지지 않음)
{
  const G = mk(15001); const pl = G.players[0];
  const env = MC.makeInstance(G, 'ultron-drones', {});
  G.pendingEncounters.push({ player: pl.uid, inst: env });
  G.vq.push({ op: 'reveal' });
  MC.processVillainQueue(G);
  assert(G.environments.some(e => e.uid === env.uid), '환경 공개: G.environments에 유지');
  assert(!G.encounterDiscard.some(c => c.uid === env.uid), '환경은 버려지지 않음');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'droneHiveDeploy', '환경 공개 연출(droneHiveDeploy)');
}

// ② 드론 스폰: 덱 맨 위 카드 뒷면 드론화 (기본 ATK1/SCH1/HP1) + 처치 시 소유자 버림
{
  const G = mk(15002); const pl = G.players[0];
  G.environments.push(MC.makeInstance(G, 'ultron-drones', {}));
  const deck0 = pl.deck.length, topUid = pl.deck[pl.deck.length - 1].uid;
  const drone = MC.spawnFacedownDrone(G, pl);
  assert(drone && drone.isDrone, '드론 스폰');
  assert(pl.deck.length === deck0 - 1 && drone.facedownCard.uid === topUid, '덱 맨 위 카드가 뒷면으로');
  assert(drone.attack === 1 && drone.scheme === 1 && drone.hp === 1, '기본 스탯 ATK1 SCH1 HP1');
  assert(pl.engagedMinions.includes(drone), '스폰 드론 교전');
  const disc0 = pl.discard.length;
  MC.applyDamage(G, drone, 1, {});
  assert(!pl.engagedMinions.includes(drone), '드론 격파: 전장 이탈');
  assert(pl.discard.length === disc0 + 1 && pl.discard.some(c => c.uid === topUid), '뒷면 카드 → 소유자 버림 더미');
  assert(!G.encounterDiscard.some(c => c.uid === drone.uid), '드론 토큰은 조우 버림에 안 감');
}

// ③ 업그레이드 드론 부착: 각 드론 ATK+1/HP+1 (피해 보존) · 이탈 시 원복 + 상한 하락 즉사
{
  const G = mk(15003); const pl = G.players[0];
  const env = MC.makeInstance(G, 'ultron-drones', {});
  G.environments.push(env);
  const d1 = MC.spawnFacedownDrone(G, pl);
  const d2 = MC.spawnFacedownDrone(G, pl);
  // 부착 (공개 파이프라인 attachTarget 라우팅 경유)
  const up = MC.makeInstance(G, 'upgraded-drones', {});
  G.pendingEncounters.push({ player: pl.uid, inst: up });
  G.vq.push({ op: 'reveal' });
  MC.processVillainQueue(G);
  assert(env.attachments && env.attachments.some(a => a.uid === up.uid), '업그레이드 드론: 환경에 부착');
  assert(d1.attack === 2 && d1.hp === 2 && d1.maxHp === 2, '드론1 ATK2/HP2 (부착 강화)');
  assert(d2.attack === 2 && d2.hp === 2, '드론2도 강화 (각 드론 적용)');
  // d1에 피해 1 → HP 1/2. 부착 해제 → 상한 1, 피해 1 보존 → HP 0 → 즉사
  MC.applyDamage(G, d1, 1, {});
  assert(d1.hp === 1 && pl.engagedMinions.includes(d1), '강화 드론: 피해 1 견딤 (HP 1/2)');
  MC.detachFrom(G, up);
  assert(d2.attack === 1 && d2.hp === 1, '이탈: 드론2 원복 (ATK1/HP1)');
  assert(!pl.engagedMinions.includes(d1), '이탈: 피해 입은 드론1 상한 하락 즉사');
}

// ④ 환경 없으면 부착 불발 → 버림
{
  const G = mk(15004); const pl = G.players[0];
  const up = MC.makeInstance(G, 'upgraded-drones', {});
  G.pendingEncounters.push({ player: pl.uid, inst: up });
  G.vq.push({ op: 'reveal' });
  MC.processVillainQueue(G);
  assert(G.encounterDiscard.some(c => c.uid === up.uid), '환경 부재: 부착 불발 → 버림');
}

// ⑤ 히어로 행동 제거: ⚡🧠💪 각 1 지불 → 버림 (환경 부착물도 hosts에 포함)
{
  const G = mk(15005); const pl = G.players[0]; pl.form = 'hero'; pl.exhausted = false;
  const env = MC.makeInstance(G, 'ultron-drones', {});
  G.environments.push(env);
  const d1 = MC.spawnFacedownDrone(G, pl);
  const up = MC.makeInstance(G, 'upgraded-drones', {});
  MC.attachTo(G, up, env);
  assert(d1.attack === 2, '부착 직후 드론 강화 (attachTo 경유 recalc)');
  const pay = [];
  for (const s of ['relentless-assault','tigra-ally','uppercut']){   // energy, mental, physical
    const c = MC.makeInstance(G, s, {}); c.ownerUid = pl.uid; pl.hand.push(c); pay.push({ kind:'hand', uid:c.uid });
  }
  MC.dispatch(G, { type:'removeEnemyAttachment', player: pl.uid, attachUid: up.uid, payment: pay });
  assert(!env.attachments.some(a => a.uid === up.uid), '히어로 행동: 환경 부착물 제거');
  assert(G.encounterDiscard.some(c => c.uid === up.uid), '제거된 카드 조우 버림으로');
  assert(d1.attack === 1 && d1.hp === 1, '제거 후 드론 원복');
}

// ⑥ 덱 소진 시 스폰 불발 (안전)
{
  const G = mk(15006); const pl = G.players[0];
  G.environments.push(MC.makeInstance(G, 'ultron-drones', {}));
  pl.deck = [];
  const drone = MC.spawnFacedownDrone(G, pl);
  assert(drone === null, '덱 소진: 드론 스폰 안전 불발');
}

console.log('══ 업그레이드 드론 + 드론 서브시스템 회귀 통과 ══');
