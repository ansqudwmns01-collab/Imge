/* test_highway_robbery.js — 노상 강도(01166) 사이드 스킴 회귀
   ★ 신규 storeRandomFromEachHand(손패 보관) + returnStoredCards(처치 시 반환).
   사용: node tests/test_highway_robbery.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 공개: 손패 무작위 1장 보관 + 가속 아이콘
{
  const G = mk(71001); const pl = G.players[0]; pl.form = 'hero';
  while (pl.hand.length < 4) pl.hand.push(MC.makeInstance(G, 'shuri', {}));
  const h0 = pl.hand.length;
  const ss = revealSide(G, pl, 'highway-robbery');
  assert(pl.hand.length === h0 - 1, '손패 1장 보관 (' + h0 + '→' + pl.hand.length + ')');
  assert(ss.storedCards && ss.storedCards.length === 1, '스킴에 1장 보관됨');
  assert(MC.cardDef('highway-robbery').accelIcons === 1, '가속 아이콘 1');
}

// ② 처치(해결): 보관 카드 소유자 손으로 반환
{
  const G = mk(71002); const pl = G.players[0]; pl.form = 'hero';
  while (pl.hand.length < 4) pl.hand.push(MC.makeInstance(G, 'shuri', {}));
  const ss = revealSide(G, pl, 'highway-robbery');
  const stolenUid = ss.storedCards[0].uid;
  const hMid = pl.hand.length;
  // 처치 시 whenCompleted 발화
  MC.fireCardHook(G, ss, 'whenCompleted', { player: pl });
  assert(pl.hand.some(c => c.uid === stolenUid), '보관 카드 손으로 반환');
  assert(pl.hand.length === hMid + 1, '손패 1장 복귀 (' + hMid + '→' + pl.hand.length + ')');
  assert(ss.storedCards.length === 0, '보관함 비워짐');
}

// ③ 반환된 카드는 원 소유자에게 (owner 기록)
{
  const G = mk(71003); const pl = G.players[0]; pl.form = 'hero';
  while (pl.hand.length < 3) pl.hand.push(MC.makeInstance(G, 'shuri', {}));
  const ss = revealSide(G, pl, 'highway-robbery');
  assert(ss.storedCards[0]._storedOwner === pl.uid, '보관 카드에 소유자 기록');
}

console.log('══ 노상 강도 (storeRandomFromEachHand + return) 회귀 통과 ══');
