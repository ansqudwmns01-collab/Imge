/* test_swarm_attack.js — 군집 공격(01147) 배신 회귀
   ★ minionsAttack 공용 인덱스 확장(scope:'activePlayer' + fallback:'spawnDrone') 검증.
   - 교전 드론들이 순차 공격 (활성 플레이어만) · 비-드론은 공격 안 함
   - 공격이 하나도 없으면(드론 없음/전원 기절) 덱 맨 위 카드를 뒷면 드론으로 증원
   사용: node tests/test_swarm_attack.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01001a', deckCodes: MC.PRESET_DECKS.spiderman.cards.slice() }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function spawnDrones(G, pl, n){
  G.environments = G.environments || [];
  if (!G.environments.length) G.environments.push(MC.makeInstance(G, 'ultron-drones', {}));
  const out = [];
  for (let i = 0; i < n; i++) out.push(MC.spawnFacedownDrone(G, pl));
  return out;
}
function fire(G, pl){
  const inst = MC.makeInstance(G, 'swarm-attack', {});
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  return inst;
}

// ① 교전 드론 2명 → 순차 공격 체인 (비-드론 하수인 제외)
{
  const G = mk(19001); const pl = G.players[0]; pl.form = 'hero';
  const [d1, d2] = spawnDrones(G, pl, 2);
  const hydra = MC.makeInstance(G, 'hydra-soldier', {});   // 비-드론
  hydra.engagedWith = pl.uid; pl.engagedMinions.push(hydra);
  fire(G, pl);
  assert(G.pending && G.pending.kind === 'defense', '공개: 첫 드론 방어 pending');
  assert(G.pending.attackerUid === d1.uid, '첫 공격자 = 드론1');
  assert(G.pending.attackChain && G.pending.attackChain.length === 1 &&
         G.pending.attackChain[0].attackerUid === d2.uid, '체인에 드론2 대기 (히드라 병사 제외)');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'droneSwarmAttack', '공격 분기 연출');
  const hp0 = pl.hp;
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(pl.hp === hp0 - (d1.attack||0), '드론1 무방어 피해');
  assert(G.pending && G.pending.attackerUid === d2.uid, '체인: 드론2 공격 pending 연장');
  MC.resolveDefensePending(G, pl.uid, 'none');
  assert(!G.pending, '체인 종료');
}

// ② 드론 없음 → 덱 맨 위 카드 뒷면 드론 증원 (fallback:spawnDrone)
{
  const G = mk(19005); const pl = G.players[0]; pl.form = 'hero';
  const deck0 = pl.deck.length, topUid = pl.deck[pl.deck.length - 1].uid;
  fire(G, pl);
  assert(!G.pending, '드론 없음: 공격 pending 없음');
  const drone = pl.engagedMinions.find(m => m.isDrone);
  assert(drone && drone.facedownCard.uid === topUid, '증원: 덱 맨 위 카드가 뒷면 드론으로');
  assert(pl.deck.length === deck0 - 1, '덱 1장 소모');
  assert(G.fxCardEffect && G.fxCardEffect.vfx === 'droneConversion', '증원 분기 연출');
}

// ③ 교전 드론 전원 기절 → 공격 없음 → 증원
{
  const G = mk(19010); const pl = G.players[0]; pl.form = 'hero';
  const [d1] = spawnDrones(G, pl, 1);
  d1.status.stunned = 1;
  const cntBefore = pl.engagedMinions.length;
  fire(G, pl);
  assert(d1.status.stunned === 0, '기절 소모 (공격 생략)');
  assert(!G.pending, '공격 pending 없음');
  assert(pl.engagedMinions.length === cntBefore + 1, '증원: 드론 1명 추가');
}

// ④ scope 격리: 다른 플레이어 드론은 공격 안 함 — 활성 플레이어 기준 (1인이라 개념 검증)
{
  const G = mk(19015); const pl = G.players[0]; pl.form = 'hero';
  spawnDrones(G, pl, 1);
  fire(G, pl);
  assert(G.pending && G.pending.player === pl.uid, 'scope activePlayer: 활성 플레이어 대상 공격');
}

console.log('══ 군집 공격 (minionsAttack scope/spawnDrone fallback) 회귀 통과 ══');
