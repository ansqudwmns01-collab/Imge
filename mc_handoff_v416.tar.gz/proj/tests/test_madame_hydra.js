/* test_madame_hydra.js — 마담 히드라(01181) 하수인 회귀
   ★ invulnWhileScheme(Legions of Hydra 존재 시 피해 면역) + forcedResponseEffects(위협 +2).
   사용: node tests/test_madame_hydra.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

function assert(cond, msg){
  if (!cond){ console.error('✗ ' + msg); process.exitCode = 1; throw new Error(msg); }
  console.log('✓ ' + msg);
}
function mk(seed){
  const G = MC.makeGameState({ seed, players:[{ heroCode:'01040a', deckCodes:['shuri','panther-claws','wakanda-forever'] }],
    villainCode:'01113', mainScheme:'01097b', encounterCodes:['im-tough','im-tough','im-tough'] });
  MC.setupGame(G);
  return G;
}
function revealSide(G, pl, code){
  const inst = MC.makeInstance(G, code, {});
  G.pendingEncounters.push({ player: pl.uid, inst });
  G.vq.push({ op:'reveal' });
  MC.processVillainQueue(G);
  return inst;
}

// ① 필드 확인
{
  const d = MC.cardDef('madame-hydra');
  assert(d.invulnWhileScheme === 'legions-of-hydra-scheme', 'invulnWhileScheme 플래그');
  assert(Array.isArray(d.forcedResponseEffects), 'forcedResponseEffects 배열');
  assert(d.hp === 6, 'HP 6');
}

// ② Legions of Hydra 존재 시 피해 면역
{
  const G = mk(86001); const pl = G.players[0]; pl.form = 'hero';
  // Legions of Hydra 사이드 스킴 직접 배치(소환 트리거 회피 위해 수동)
  const loh = MC.makeInstance(G, 'legions-of-hydra-scheme', {});
  G.sideSchemes.push(loh);
  const m = MC.makeInstance(G, 'madame-hydra', {}); m.type = 'minion';
  m.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m);
  const hp0 = m.hp;
  MC.applyDamage(G, m, 4, { source: pl });
  assert(m.hp === hp0, 'Legions of Hydra 존재: 피해 면역 (' + hp0 + ' 유지)');
}

// ③ Legions of Hydra 없으면 정상 피해
{
  const G = mk(86002); const pl = G.players[0]; pl.form = 'hero';
  const m = MC.makeInstance(G, 'madame-hydra', {}); m.type = 'minion';
  m.status = { stunned:0, confused:0, tough:0 };
  pl.engagedMinions.push(m);
  const hp0 = m.hp;
  MC.applyDamage(G, m, 3, { source: pl });
  assert(m.hp === hp0 - 3, 'Legions of Hydra 없음: 정상 피해 (' + hp0 + '→' + m.hp + ')');
}

// ④ Forced Response: 공격 후 Legions of Hydra에 위협 +2
{
  const G = mk(86003); const pl = G.players[0]; pl.form = 'hero';
  const loh = MC.makeInstance(G, 'legions-of-hydra-scheme', {});
  loh.threat = 3; G.sideSchemes.push(loh);
  const m = MC.makeInstance(G, 'madame-hydra', {}); m.type = 'minion';
  pl.engagedMinions.push(m);
  MC.runEffectList(G, MC.cardDef('madame-hydra').forcedResponseEffects, { player: pl, self: m });
  assert(loh.threat === 5, '강제반응: Legions of Hydra 위협 +2 (3→' + loh.threat + ')');
}

console.log('══ 마담 히드라 (조건부 면역 + Forced Response) 회귀 통과 ══');
