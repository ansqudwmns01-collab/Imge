/* 자동 생성 파일 — 직접 편집 금지. tools/reassemble.py 로 재생성 */
/* ◇◇ from mc_1_terms.js ◇◇ */
/* ═══════════════════════════════════════════════════════════════
   mc_1_terms.js — 샤드 1/7 : TERMS · GLOSSARY
   편집은 항상 샤드에만. 모놀리스(mc_engine.js)는 reassemble.py로 재생성.
   IIFE는 이 샤드에서 열리고 mc_7_core.js에서 닫힌다.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC = global.MC || {};
MC.VERSION = 'v2026.07.12.172';

/* ── TERMS: 게임 내 모든 용어의 단일 출처. 신규 용어는 grep 후 없을 때만 추가. ──
   한국어 아이덴티티: 이전 빌드(v802) 용어 승계 — 용맹/정의/리더십/보호.
   ※ 한국어판 공식 용어집 확보 시 대조 예정 (PROJECT_STATE 보류항목 T-1) */
const TERMS = {
  // 스탯
  attack:'공격력', defense:'방어력', thwart:'저지력', health:'체력',
  recover:'회복력', handSize:'손패 한도', cost:'비용', threat:'위협',
  // 자원 아이콘
  physical:'물리', mental:'정신', energy:'에너지', wild:'와일드',
  // 성향(aspect) — 이전 빌드 승계
  aggression:'용맹', justice:'정의', leadership:'리더십', protection:'보호', basic:'기본',
  // 플레이어 카드 유형
  hero:'영웅', 'alter-ego':'알터에고', ally:'동료', event:'이벤트',
  support:'지원', upgrade:'업그레이드', resource:'자원 카드',
  // 인카운터 카드 유형
  villain:'빌런', main_scheme:'메인 스킴', side_scheme:'사이드 스킴',
  minion:'하수인', treachery:'배신', attachment:'부착', environment:'환경',
  obligation:'책무', nemesis:'네메시스',
  // 상태 토큰
  stunned:'기절', confused:'혼란', tough:'강인',
  // 페이즈/진행
  playerPhase:'플레이어 페이즈', villainPhase:'빌런 페이즈',
  ready:'준비', exhausted:'소진', firstPlayer:'선 플레이어',
  round:'라운드', setup:'셋업',
  // 키워드 (이전 빌드 승계: guard=수호)
  guard:'수호', retaliate:'보복', piercing:'관통', overkill:'과잉살상',
  quickstrike:'속공', stalwart:'불굴', surge:'쇄도', peril:'위기',
  hinder:'방해', incite:'선동', ranged:'원거리', aerial:'공중',
  toughness:'강인함', restricted:'제한', permanent:'영구', uses:'사용 횟수',
  boost:'증폭', acceleration:'가속', crisis:'위기 아이콘', hazard:'위험 아이콘',
};
function T(key){ return TERMS[key] !== undefined ? TERMS[key] : ('¿'+key+'?'); }

/* ── GLOSSARY: 신규 플레이어용 설명 사전 (UI 툴팁 소스) ── */
const GLOSSARY = {
  tough:'강인: 이 캐릭터가 받을 다음 피해를 모두 무효화하고 강인 토큰을 제거한다.',
  stunned:'기절: 이 캐릭터는 다음 공격을 할 수 없다. 공격 대신 기절 토큰을 제거한다.',
  confused:'혼란: 이 캐릭터는 다음 저지를 할 수 없다. 저지 대신 혼란 토큰을 제거한다.',
  guard:'수호: 수호 하수인이 교전 중이면, 그 하수인을 먼저 처리해야 빌런을 공격할 수 있다.',
  retaliate:'보복 N: 이 캐릭터가 공격받아 피해를 입으면, 공격자에게 피해 N을 준다.',
  piercing:'관통: 이 공격은 강인 토큰을 제거하지 않고 무시한다.',
  overkill:'과잉살상: 하수인을 처치하고 남은 피해를 빌런에게 준다.',
  quickstrike:'속공: 이 적이 플레이에 들어올 때, 즉시 (교전 중인) 영웅을 공격한다.',
  surge:'쇄도: 이 카드 공개 후, 인카운터 카드 1장을 추가로 공개한다.',
  boost:'증폭: 빌런 활성화 시 인카운터 덱에서 뒤집는 카드의 증폭 아이콘만큼 수치가 오른다.',
};
function glossaryFor(key){ return GLOSSARY[key] || null; }

MC.TERMS = TERMS; MC.T = T; MC.GLOSSARY = GLOSSARY; MC.glossaryFor = glossaryFor;


/* ◇◇ from mc_2_effects.js ◇◇ */
/* ═══════════════════════════════════════════════════════════════
   mc_2_effects.js — 샤드 2/7 : EFFECTS 레지스트리 + runEffectList
   즉발 효과만 등록. 트리거형은 mc_3_handlers.js(HANDLERS)로.
   ※ 함정 주의: runEffectList는 EFFECTS만 조회한다.
   등록 규율: 재사용 → 확장 → 신규. 신규 시 "왜 기존 것 불가" 주석 필수.
   ═══════════════════════════════════════════════════════════════ */

const EFFECTS = {};

/* runEffectList(G, list, ctx)
   list: [{fx:'dealDamage', amount:2, target:'chosen'}, ...]
   ctx : {player, card, source, targets, ...} */
function runEffectList(G, list, ctx){
  if (!list) return;
  for (const step of list){
    // 조건부 효과: step.cond가 있으면 condCheck 통과 시에만 실행 (범용 — Aerial 등)
    if (step.cond && !MC.condCheck(G, step.cond, ctx || {})) continue;
    const fn = EFFECTS[step.fx];
    if (!fn) throw new Error('[runEffectList] 미등록 fx: ' + step.fx);
    fn(G, step, ctx || {});
  }
}

/* ── 원시 효과 (Phase 1에서 규칙 파이프라인과 결합해 확장) ── */

// 피해: 강인/보복/과잉살상 상호작용은 applyDamage 파이프라인(mc_6)에서 일괄 처리
/* 순차 다중 대상 피해 (melee=근접전투): p.lines 개수만큼 서로 다른 적에게 각 amount 피해.
   각 라인을 순서대로 해결 (첫 라인 처치로 Guard 돌파/빌런 단계 전환 반영).
   ctx.targets[i]가 각 라인 대상. 각 대상은 서로 달라야 함 (공식 FAQ: another enemy).
   대상이 부족하면(둘째 미지정) 해당 라인은 스킵 (기절 시 첫 라인만 등도 UI에서 처리). */
EFFECTS.dealDamageMulti = function(G, p, ctx){
  const targets = ctx.targets || [];
  const lines = p.lines || 2;
  const amount = p.amount;
  const used = [];
  for (let i = 0; i < lines; i++){
    const t = targets[i];
    if (!t){ MC.log(G, '(근접 전투 ' + (i+1) + '번째 대상 없음 — 라인 스킵)'); continue; }
    // 서로 다른 적 검증 (같은 uid 중복 금지)
    if (used.includes(t.uid)){ MC.log(G, '(근접 전투 — 같은 적 중복 불가, 라인 스킵)'); continue; }
    used.push(t.uid);
    // 대상이 이미 처치됐으면(앞 라인 결과) 스킵
    if (t.hp !== undefined && t.hp <= 0){ MC.log(G, '(대상 이미 처치됨 — 라인 스킵)'); continue; }
    MC.applyDamage(G, t, amount, { source: ctx.card, isAttack: p.isAttack !== false });
  }
};

// 빌런 최대/현재 HP 증감 (불멸의 클로 +10 / 해결 시 -10 등). 감소 시 현재 HP는 상한 클램프만.
// 스킴의 목표 위협치(maxThreat) 증가 (Under Surveillance 06031 — 완료 지연). _targetBuff 누적(UI 표시).
EFFECTS.buffSchemeTarget = function(G, p, ctx){
  const s = (ctx.targets && ctx.targets[0]) || G.mainScheme;
  if (!s) return;
  const amt = p.amount || 0;
  s.maxThreat = Math.max(1, (s.maxThreat || 0) + amt);
  s._targetBuff = (s._targetBuff || 0) + amt;
  MC.log(G, MC.nameOf(s) + ' 목표 위협치 ' + (amt >= 0 ? '+' : '') + amt + ' (완료 ' + s.threat + '/' + s.maxThreat + ')');
};

EFFECTS.buffVillainHp = function(G, p, ctx){
  const v = G.villain;
  if (!v) return;
  const amt = p.amount || 0;
  v.maxHp = Math.max(1, (v.maxHp || v.hp || 0) + amt);
  v._hpBuff = (v._hpBuff || 0) + amt;   // 추가 체력 누적 (UI 표시용 — 불멸의 클로 등)
  if (amt > 0) v.hp = (v.hp || 0) + amt;
  else if (v.hp > v.maxHp) v.hp = v.maxHp;   // 감소 시 최대치 초과분만 감소 (스킴 해결로 죽지 않음)
  MC.log(G, MC.nameOf(v) + ' HP ' + (amt >= 0 ? '+' : '') + amt + ' (현재 ' + v.hp + '/' + v.maxHp + ')');
};

// 대상 하수인을 이 플레이어와 교전 상태로 (Get Over Here! Aerial 교전 등). ctx.targets[0] 또는 ctx.target.
// 컨트롤러 히어로에게 피해 (Battle Fury 06018 등 반응 비용). p.amount.
EFFECTS.selfDamage = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl) return;
  MC.applyDamage(G, pl, p.amount || 1, { source: ctx.self || ctx.card });
};

// 준비된 Weapon 특성 업그레이드 1개 소진 → 다음 기본 공격 ATK 보너스 (Mean Swing 06015).
EFFECTS.exhaustWeapon = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const w = (pl.playArea.upgrades || []).find(c => !c.exhausted && ((MC.cardDef(c.defCode).traits) || []).includes('weapon'));
  if (!w){ MC.log(G, '준비된 무기(Weapon) 없음 — 효과 불발'); return; }
  w.exhausted = true;
  pl.nextBasicAttackBonus = (pl.nextBasicAttackBonus || 0) + (p.attackBonus || 3);
  MC.log(G, MC.nameOf(w) + ' 소진 → 다음 기본 공격 ATK +' + (p.attackBonus || 3));
};

EFFECTS.engageTarget = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const t = (ctx.targets && ctx.targets[0]) || ctx.target;
  if (!t || t.type !== 'minion' || t.hp <= 0) return;
  if (t.engagedWith === pl.uid) return;   // 이미 교전 중
  for (const p2 of G.players){
    const i = (p2.engagedMinions || []).indexOf(t);
    if (i >= 0) p2.engagedMinions.splice(i, 1);
  }
  t.engagedWith = pl.uid;
  pl.engagedMinions.push(t);
  MC.log(G, MC.nameOf(t) + ' — ' + MC.nameOf(pl) + '와 교전 (Get Over Here!)');
};

/* 덱 맨 위 카드 1장 버림 → 그 카드의 인쇄 자원별로 지정된 효과 분기 실행 (와일드=전부).
   Magic Blast·Baron Mordo 등 "자원-효과 매핑" 공통 패턴. branches:{physical:[...],energy:[...],mental:[...]}. */
/* 방어 pending에 "무피해 시 재준비" 플래그 설정 — 필사의 방어. resolveDefensePending이 dmg===0일 때 히어로 ready. */
/* 대상에서 상태 카드(기절/혼란/충격) 1개 제거 — Night Nurse. target 생략 시 시전자 히어로. */
/* 다음 기본 공격 ATK +N (무기 소진 불필요) — Skilled Strike. */
EFFECTS.buffNextBasicAttack = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.nextBasicAttackBonus = (pl.nextBasicAttackBonus || 0) + (p.amount || 2);
  MC.log(G, '다음 기본 공격 ATK +' + (p.amount || 2));
};

/* 다음 기본 공격에 과잉살상(Overkill) 부여 — 헐크 스매시(물리 지불 시). cond로 조건부. */
/* 거인들의 충돌(Clash of the Titans) — 최고 ATK 적이 최고 ATK 히어로/동료를 공격.
   공격이 이뤄지지 않으면(적 없음/ATK 0) 이 배신 카드 surge. */
EFFECTS.clashOfTitans = function(G, p, ctx){
  const enemies = [];
  if (G.villain) enemies.push(G.villain);
  for (const pl of G.players) for (const m of (pl.engagedMinions || [])) enemies.push(m);
  let topEnemy = null, topEnemyAtk = -1;
  for (const e of enemies){ const a = MC.enemyAtk(G, e); if (a > topEnemyAtk){ topEnemyAtk = a; topEnemy = e; } }
  let topChar = null, topCharAtk = -1, topCharPl = null, topIsHero = false;
  for (const pl of G.players){
    if (pl.form === 'hero'){ const a = MC.statOf(G, pl, 'attack'); if (a > topCharAtk){ topCharAtk = a; topChar = pl; topCharPl = pl; topIsHero = true; } }
    for (const al of (pl.playArea.allies || [])){ const a = MC.allyStatOf(G, al, 'attack'); if (a > topCharAtk){ topCharAtk = a; topChar = al; topCharPl = pl; topIsHero = false; } }
  }
  if (topEnemy && topChar && topEnemyAtk > 0){
    MC.log(G, '거인들의 충돌 — ' + MC.nameOf(topEnemy) + '(ATK ' + topEnemyAtk + ') → ' + MC.nameOf(topChar) + '(ATK ' + topCharAtk + ') 공격');
    if (topIsHero){ MC.enemyActivation(G, topEnemy, topCharPl); }
    else { MC.applyDamage(G, topChar, topEnemyAtk, { source: topEnemy, isAttack: true }); }
  } else {
    const self = ctx.self || ctx.card;
    if (self) self.surge = true;
    MC.log(G, '거인들의 충돌 — 공격이 이뤄지지 않음, 급증(surge)');
  }
};

/* 적 공격 유발 (Toe to Toe) — 선택한 적이 히어로를 공격하게 함 + 방어 해소 후 afterEffects(그 적 5피해).
   enemyActivation으로 공격 유발 → 방어 pending에 afterEffects 심음 (해소 후 실행). */
EFFECTS.provokeEnemyAttack = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const enemy = (ctx.targets && ctx.targets[0]);
  if (!enemy){ MC.log(G, '(공격 유발 대상 없음)'); return; }
  MC.log(G, MC.nameOf(enemy) + ' — 도발당해 ' + MC.nameOf(pl) + '을(를) 공격');
  MC.enemyActivation(G, enemy, pl);
  if (G.pending && G.pending.kind === 'defense'){
    G.pending.afterEffects = p.afterEffects || [];   // 방어 해소 후 그 적에 5피해
  } else if (p.afterEffects){
    // 공격이 생략됐으면(기절 등) 즉시 후속 효과
    MC.runEffectList(G, p.afterEffects, { player: pl, targets: [enemy], self: enemy, card: enemy });
  }
};

EFFECTS.setNextAttackOverkill = function(G, p, ctx){
  if (p.cond && !MC.condCheck(G, p.cond, ctx)) return;
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.nextBasicAttackOverkill = true;
  MC.log(G, '다음 기본 공격 — 과잉살상(Overkill) 부여');
};

EFFECTS.removeStatus = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target || 'self', ctx);
  const arr = Array.isArray(tgt) ? tgt : [tgt];
  for (const t of arr){
    if (!t || !t.status) continue;
    for (const st of ['stunned', 'confused', 'tough']){
      if (t.status[st] > 0){ t.status[st] = 0; MC.log(G, MC.nameOf(t) + ' — ' + st + ' 상태 제거'); break; }
    }
  }
};

/* 저지됐다!(foiled) — 직전 빌런/하수인 음모의 부스트 아이콘 위협분 취소.
   음모 부스트는 자동 집계되므로 G._lastSchemeBoost로 추적된 부스트분을 소급 제거. */
/* 다크 디멘션(open-dark-dimension) 발동덱 조작.
   stashInvocation: 발동 덱 맨 위 카드 1장을 이 스킴 아래로 격리(발동덱에서 제외).
   restoreInvocation: 격파 시 격리 카드를 발동 덱에 복귀 + 셔플. */
/* 생각 조종(thoughtcasting): 손패에서 인쇄 비용이 가장 높은 카드 1장 버림 →
   then:'threat'이면 그 비용만큼 메인 스킴 위협 / then:'damage'이면 그 비용만큼 피해. */
EFFECTS.discardHighestCostHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl.hand || !pl.hand.length){ MC.log(G, '(손패 없음 — 생각 조종 효과 없음)'); return; }
  let best = null, bestCost = -1;
  for (const c of pl.hand){
    const cost = MC.cardDef(c.defCode).cost || 0;
    if (cost > bestCost){ bestCost = cost; best = c; }
  }
  if (!best) return;
  const i = pl.hand.indexOf(best);
  pl.hand.splice(i, 1);
  MC.moveToDiscard(G, pl, best, {});
  MC.log(G, '생각 조종 — 최고 비용 카드 ' + MC.nameOf(best) + ' 버림 (비용 ' + bestCost + ')');
  if (bestCost <= 0) return;
  if (p.then === 'threat'){ MC.placeThreat(G, 'main', bestCost); MC.log(G, '메인 스킴 위협 +' + bestCost); }
  else if (p.then === 'damage'){ MC.applyDamage(G, pl, bestCost, { source: ctx.self || ctx.card }); MC.log(G, '히어로 ' + bestCost + ' 피해'); }
};

EFFECTS.stashInvocation = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl.invocationDeck || !pl.invocationDeck.length) MC.invocationReshuffleIfEmpty(G, pl);
  if (pl.invocationDeck && pl.invocationDeck.length){
    const card = pl.invocationDeck.shift();
    const s = ctx.self || ctx.card;
    s.stashedInvocation = s.stashedInvocation || [];
    s.stashedInvocation.push(card.defCode);
    s.stashedOwner = pl.uid;
    MC.log(G, '다크 디멘션 열림 — 발동 카드 ' + MC.nameOf(card) + ' 격리 (발동덱에서 제외)');
  } else MC.log(G, '다크 디멘션 — 격리할 발동 카드 없음');
};
EFFECTS.restoreInvocation = function(G, p, ctx){
  const s = ctx.self || ctx.card;
  if (s.stashedInvocation && s.stashedInvocation.length){
    const pl = G.players.find(x => x.uid === s.stashedOwner) || G.players[G.firstPlayer];
    pl.invocationDeck = pl.invocationDeck || [];
    for (const code of s.stashedInvocation) pl.invocationDeck.push(MC.makeInstance(G, code));
    MC.shuffle(G, pl.invocationDeck);
    MC.log(G, '다크 디멘션 격파 — 발동 카드 ' + s.stashedInvocation.length + '장 발동덱 복귀+셔플');
    s.stashedInvocation = [];
  }
};

EFFECTS.cancelLastSchemeBoost = function(G, p, ctx){
  const lb = G._lastSchemeBoost;
  if (!lb || !lb.boost){ MC.log(G, '저지됐다! — 취소할 음모 부스트 없음'); return; }
  MC.removeThreat(G, lb.schemeRef || 'main', lb.boost);
  MC.log(G, '저지됐다! — 음모 부스트 아이콘 취소 (위협 -' + lb.boost + ')');
  G._lastSchemeBoost = null;
};

EFFECTS.setReadyIfNoDamage = function(G, p, ctx){
  if (G.pending && G.pending.kind === 'defense') G.pending.readyIfNoDamage = true;
};

EFFECTS.discardTopResourceBranch = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl || !pl.deck || !pl.deck.length){ MC.log(G, '(덱 비어있음 — 자원 판정 없음)'); return; }
  const c = pl.deck.pop();
  const icons = (MC.resourceIconsOf ? MC.resourceIconsOf(c) : {}) || {};
  MC.moveToDiscard(G, pl, c, {});
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 버림 (자원 판정)');
  const w = (icons.wild || 0) > 0;
  const br = p.branches || {};
  for (const res of ['physical', 'energy', 'mental']){
    if (((icons[res] || 0) > 0 || w) && br[res]) MC.runEffectList(G, br[res], ctx);
  }
};

EFFECTS.dealDamage = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  // 조건부 피해량 (amountIf: {cond, amount}) — 조건 충족 시 그 값으로 대체 (초음속 펀치=Aerial 시 8)
  let amount = p.amount;
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  if (p.amountFrom === 'ritualX') amount = G._ritualX || 0;
  if (p.amountFrom === 'heroAtk') amount = MC.statOf(G, ctx.player || G.players[G.firstPlayer], 'attack') || 0;   // 헐크 크러싱 블로우: ATK만큼 피해
  if (p.amountFrom === 'xValue') amount = ctx.xValue || 0;   // X 에너지 지불량 = 피해 (라이트닝 스트라이크 06006)
  if (p.amountFrom === 'upgradeCount'){
    const who = ctx.player || G.players[G.firstPlayer];
    amount = (who.playArea.upgrades || []).length;
  }
  // 사이드 스킴 위협 수를 피해량으로 (폭발!=폭탄 위협 위협 수만큼 X 피해)
  if (p.amountFromSchemeThreat){
    const ss = (G.sideSchemes || []).find(s => s.defCode === p.amountFromSchemeThreat);
    amount = ss ? (ss.threat || 0) : 0;
  }
  amount += (ctx.eventDamageBonus || 0);   // Embiggen! 등 이벤트 강화 인터럽트 보너스
  // 조건부 오버킬 (overkillIf: cond) — 결제 자원 등 조건 충족 시 과잉살상 획득 (거침없는 돌진=피지컬 지불)
  const overkill = !!p.overkill || (p.overkillIf && MC.condCheck(G, p.overkillIf, ctx));
  // 조건부 관통 (piercingIf: cond) — 조건 충족 시 강인(Tough) 무시 (라이트닝 스트라이크=Aerial 시)
  const piercing = !!p.piercing || (p.piercingIf && MC.condCheck(G, p.piercingIf, ctx));
  for (const t of tgt){
    const wasEnemy = (t.type === 'villain' || t.type === 'minion');
    MC.applyDamage(G, t, amount, { source: ctx.card, piercing, overkill, isAttack: !!p.isAttack });
    // 격파 시 후속 효과 (onDefeat) — 은밀한 일격(격파 시 위협 제거) 등. 범용 데이터.
    if (p.onDefeat && wasEnemy && ((t.hp !== undefined && t.hp <= 0) || t.defeated)){
      MC.runEffectList(G, Array.isArray(p.onDefeat) ? p.onDefeat : [p.onDefeat], ctx);
    }
  }
};

EFFECTS.heal = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  let amount = p.amount;
  // 조건부 회복량 (amountIf: {cond, amount}) — 멘탈 지불 시 5 등. dealDamage/removeThreat와 동일 패턴.
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  for (const t of tgt) MC.healTarget(G, t, amount);
};

/* 자신을 준비(ready) 상태로 (원투 펀치 등): 소진 해제 → 추가 액션 가능. */
EFFECTS.readySelf = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  pl.exhausted = false;
  MC.log(G, MC.nameOf(pl) + ' 준비 상태로 — 추가 행동 가능');
};

/* 버림 더미에서 특정 특성의 맨 위 카드를 손으로 회수 (스타크 타워: Tech 업그레이드).
   p.trait(필터 특성), p.cardType(선택적 타입 필터). ctx.player 대상(단일플레이=자신). */
/* 덱(+선택적 버림)에서 trait/type 일치 카드 1장을 손에 추가 후 덱 셔플 — Agent Coulson(준비 카드 서치). */
/* 버림 더미에서 동료 1장을 전장에 복귀 + 지정 피해 — Rapid Response(동료 부활). targets 우선, 없으면 최근 동료. */
/* 손패에서 가장 비용 높은 준비(Preparation) 카드 1장 버림 — Burn Notice. 버렸으면 ctx._discardedUpgrade=true (surgeIfNoDiscard 재사용). */
EFFECTS.discardMostExpensivePreparation = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl){ ctx._discardedUpgrade = false; return; }
  let best = -1, bestIdx = -1;
  for (let i = 0; i < pl.hand.length; i++){
    const d = MC.cardDef(pl.hand[i].defCode);
    if (!(d.traits || []).includes('preparation')) continue;
    if ((d.cost || 0) > best){ best = d.cost || 0; bestIdx = i; }
  }
  if (bestIdx >= 0){
    const c = pl.hand.splice(bestIdx, 1)[0];
    MC.moveToDiscard(G, pl, c, {});
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 버림 (가장 비싼 준비 카드)');
    ctx._discardedUpgrade = true;
  } else {
    MC.log(G, '(버릴 준비 카드 없음 → 급증)');
    ctx._discardedUpgrade = false;
  }
};

EFFECTS.reviveAllyFromDiscard = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  let idx = -1;
  if (ctx.targets && ctx.targets[0]){
    idx = pl.discard.findIndex(c => c.uid === ctx.targets[0].uid);
  }
  if (idx < 0){
    for (let i = pl.discard.length - 1; i >= 0; i--){
      if (MC.cardDef(pl.discard[i].defCode).type === 'ally'){ idx = i; break; }
    }
  }
  if (idx < 0){ MC.log(G, '(버림 더미에 복귀할 동료 없음)'); return; }
  const c = pl.discard.splice(idx, 1)[0];
  const inst = MC.makeInstance(G, c.defCode);
  pl.playArea.allies.push(inst);
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(inst) + ' 버림 더미에서 전장 복귀');
  if (p.damage) MC.applyDamage(G, inst, p.damage, { source:{ isPlayer:true }, isAttack:false });
};

/* 닥터 스트레인지 발동 덱 EFFECT 래퍼 — 신분 능력(effect 파이프라인)에서 호출. */
/* 조우덱 맨 위 카드를 확인 → 그 부스트 아이콘 수만큼 지정 스킴에서 위협 제거 — Astral Projection. */
EFFECTS.removeThreatByEncounterBoost = function(G, p, ctx){
  const top = G.encounterDeck && G.encounterDeck[G.encounterDeck.length - 1];
  if (!top){ MC.log(G, '(조우덱 비어있음 — 추가 위협 제거 없음)'); return; }
  const b = (MC.boostOf ? MC.boostOf(G, top, ctx.player) : 0) || 0;
  MC.log(G, '유체이탈 — 조우덱 위 ' + MC.nameOf(top) + ' 확인 (부스트 ' + b + ')');
  if (b > 0) MC.EFFECTS.removeThreat(G, { scheme: p.scheme || 'chosen', amount: b }, ctx);
};

EFFECTS.castInvocation = function(G, p, ctx){
  if (MC.castInvocation) MC.castInvocation(G, ctx.player, { targets: ctx.targets, keepOnTop: p.keepOnTop });
};
EFFECTS.naturalTalent = function(G, p, ctx){
  if (MC.naturalTalent) MC.naturalTalent(G, ctx.player);
};

/* 덱 맨 위 N장에서 조건 일치 카드 1장을 손에 추가 후 셔플 — Brother Voodoo(상단 5장 이벤트 서치). */
EFFECTS.searchTopN = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  const n = p.count || 5;
  const top = pl.deck.slice(-n).reverse();
  for (const c of top){
    const def = MC.cardDef(c.defCode);
    if (p.cardType && def.type !== p.cardType) continue;
    if (p.trait && !(def.traits || []).includes(p.trait)) continue;
    if (p.hero && def.hero !== p.hero) continue;
    const idx = pl.deck.indexOf(c);
    pl.deck.splice(idx, 1);
    pl.hand.push(c);
    if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손에 추가 (덱 상단 ' + n + '장 서치)');
    return;
  }
  if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
  MC.log(G, '(덱 상단 ' + n + '장에 ' + (p.cardType || '카드') + ' 없음)');
};

EFFECTS.searchDeckToHand = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  const pools = p.includeDiscard ? [pl.deck, pl.discard] : [pl.deck];
  for (const pool of pools){
    for (let i = pool.length - 1; i >= 0; i--){
      const c = pool[i];
      const def = MC.cardDef(c.defCode);
      if (p.cardType && def.type !== p.cardType) continue;
      if (p.trait && !(def.traits || []).includes(p.trait)) continue;
      if (p.hero && def.hero !== p.hero) continue;
      pool.splice(i, 1);
      pl.hand.push(c);
      MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손에 추가 (덱/버림 서치: ' + (p.trait || '') + ')');
      if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
      G.fxReveal = { kind:'search', card:{ defCode:c.defCode, name: MC.nameOf(c) }, trait:p.trait };
      return;
    }
  }
  if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
  MC.log(G, '(' + (p.trait || '카드') + ' 없음 — 서치 실패)');
};

/* 버림 더미의 주문(Spell) 카드 1장을 덱에 셔플 — Sanctum Sanctorum. */
EFFECTS.recallSpellToDeck = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  for (let i = pl.discard.length - 1; i >= 0; i--){
    const c = pl.discard[i];
    if (!(MC.cardDef(c.defCode).traits || []).includes('spell')) continue;
    pl.discard.splice(i, 1);
    pl.deck.push(c);
    if (MC.shuffle) MC.shuffle(G, pl.deck);
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 덱에 셔플 (주문 회수)');
    return;
  }
  MC.log(G, '(버림 더미에 주문 카드 없음)');
};

EFFECTS.recallFromDiscard = function(G, p, ctx){
  const pl = (ctx.targets && ctx.targets[0] && ctx.targets[0].hand) ? ctx.targets[0] : ctx.player;
  if (!pl){ MC.log(G, '(회수 대상 플레이어 없음)'); return; }
  // 버림 더미 위에서부터 탐색 (맨 위 = 배열 끝)
  for (let i = pl.discard.length - 1; i >= 0; i--){
    const c = pl.discard[i];
    const def = MC.cardDef(c.defCode);
    if (p.cardType && def.type !== p.cardType) continue;
    const traits = def.traits || [];
    if (p.trait && !traits.includes(p.trait)) continue;
    // 발견 — 손으로 반환
    pl.discard.splice(i, 1);
    pl.hand.push(c);
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손으로 회수 (' + (p.trait||'') + ')');
    G.fxReveal = { kind:'recall', card:{ defCode:c.defCode, name: MC.nameOf(c) }, trait:p.trait };
    return;
  }
  MC.log(G, '(버림 더미에 해당 특성 카드 없음: ' + (p.trait||'') + ')');
};

/* 일시적 트레잇 부여 (로켓 부츠: 이번 페이즈 동안 Aerial). p.trait. */
EFFECTS.grantTrait = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  pl.tempTraits = pl.tempTraits || [];
  const t = String(p.trait).toLowerCase();
  if (!pl.tempTraits.includes(t)){
    pl.tempTraits.push(t);
    MC.log(G, MC.nameOf(pl) + ' — 이번 페이즈 동안 ' + p.trait + ' 획득');
  }
  G.fxReveal = { kind:'trait', trait: t };
};

/* 리펄서 블래스트: 대상 1 피해 + 덱 위 N장 버림 → 버려진 인쇄 에너지 아이콘당 추가 2 피해.
   아이언맨 시그니처. ctx.targets[0] 대상. p.mill(버릴 장수), p.perEnergy(에너지당 피해). */
EFFECTS.repulsorBlast = function(G, p, ctx){
  const pl = ctx.player;
  const target = (ctx.targets && ctx.targets[0]);
  if (!target){ MC.log(G, '(리펄서 블래스트 대상 없음)'); return; }
  const mill = p.mill || 5, perEnergy = p.perEnergy || 2;
  let energy = 0;
  const milledCards = [];   // UI 연출 힌트용 (표시 전용, 상태 결정성 무관)
  for (let i = 0; i < mill; i++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); break; }   // RRG: 밀 중 소진→리셔플+조우카드 후 새 덱에선 안 밀음
    const c = pl.deck.pop();   // 덱 위 = 끝(pop). shift(앞=바닥)는 버그였음 (lookAtTopChoose와 동일 계열)
    if (!c) break;
    const icons = MC.resourceIconsOf(c);
    const eCount = icons.energy || 0;
    if (eCount > 0) energy += eCount;
    pl.discard.push(c);
    milledCards.push({ defCode: c.defCode, name: MC.nameOf(c), energy: eCount });
  }
  const bonus = energy * perEnergy;
  const total = (p.base || 1) + bonus;
  MC.log(G, MC.nameOf(ctx.card) + ' — 덱 ' + milledCards.length + '장 공개 (에너지 ' + energy + ' → 추가 ' + bonus + ')');
  // UI 연출 힌트 (다음 render에서 소비 후 폐기 — 상태 스냅샷/재생에 영향 없음)
  G.fxReveal = { kind:'repulsor', cards: milledCards, energy, perEnergy, base: (p.base||1), total,
                 targetUid: target.uid };
  MC.applyDamage(G, target, total, { source: pl, isAttack: true });
  MC.log(G, MC.nameOf(target) + '에게 리펄서 ' + total + ' 피해');
};

/* 카드 버림 → 버린 수만큼 위협 제거 (법률 업무 등). ctx.discardUids로 버릴 카드 지정.
   p.max 최대 버림 수, p.perCard 카드당 위협 제거량(기본 1). 메인 스킴 대상. */
EFFECTS.discardForThreat = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  let uids = (ctx.discardUids || []).slice(0, p.max || 5);
  let discarded = 0;
  for (const uid of uids){
    const i = pl.hand.findIndex(c => c.uid === uid);
    if (i < 0) continue;
    const c = pl.hand.splice(i, 1)[0];
    pl.discard.push(c);
    discarded++;
  }
  if (discarded <= 0){ MC.log(G, '(버린 카드 없음 — 위협 제거 없음)'); return; }
  const remove = discarded * (p.perCard || 1);
  MC.log(G, MC.nameOf(ctx.card) + ' — 카드 ' + discarded + '장 버림 → 위협 ' + remove + ' 제거');
  MC.removeThreat(G, p.scheme || 'main', remove);
};

/* 누적 피해량 기반 가변 피해 (감마 슬램): 발동자의 누적 피해(maxHp - hp)만큼
   대상에게 피해. p.max 상한. "자기 상태 기반 가변 피해" 패턴. */
EFFECTS.dealDamageSustained = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  let dmg = Math.max(0, (pl.maxHp || 0) - (pl.hp || 0));
  if (p.max) dmg = Math.min(dmg, p.max);
  const tgt = MC.resolveTarget(G, p.target || 'chosen', ctx);
  for (const t of tgt){
    MC.log(G, MC.nameOf(ctx.card || pl) + ' — ' + MC.nameOf(t) + '에게 누적 피해 ' + dmg);
    MC.applyDamage(G, t, dmg, { source: pl, isAttack: true });
  }
};

/* 이중인격(split personality): 라운드 제한 무시 폼 전환 후 인쇄 핸드 크기까지 드로우.
   flipForm(force) + drawUpToHandSize. She-Hulk 전용이지만 범용 효과. */
EFFECTS.splitPersonality = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  MC.flipForm(G, pl, { force: true });
  MC.drawUpToHandSize(G, pl);
  MC.log(G, MC.nameOf(pl) + ' — 이중인격: 폼 전환 후 손패 보충');
};

/* 버림 더미에서 맨 위 특정 특성 업그레이드를 손으로 반환 (스타크 타워: Tech 업그레이드).
   p.trait(한글 특성 키워드, textKo 기반 판정), p.cardType(기본 upgrade). 대상=chosen 플레이어. */
EFFECTS.returnTopTraitUpgrade = function(G, p, ctx){
  // 대상 플레이어: chosen 있으면 그 플레이어, 없으면 발동자
  let targetPl = ctx.player;
  if (ctx.targets && ctx.targets[0] && ctx.targets[0].uid && ctx.targets[0].hand) targetPl = ctx.targets[0];
  else if (ctx.targetPlayer) targetPl = ctx.targetPlayer;
  const trait = p.trait || '기술';
  const cardType = p.cardType || 'upgrade';
  // 버림 더미 맨 위(뒤에서부터)에서 조건 맞는 첫 카드
  for (let i = targetPl.discard.length - 1; i >= 0; i--){
    const c = targetPl.discard[i];
    const def = MC.cardDef(c.defCode);
    if (def.type !== cardType) continue;
    if (!(def.textKo || '').includes(trait)) continue;
    targetPl.discard.splice(i, 1);
    targetPl.hand.push(c);
    MC.log(G, MC.nameOf(targetPl) + ' — 버림 더미에서 ' + MC.nameOf(c) + ' 손으로 반환 (' + trait + ')');
    return;
  }
  MC.log(G, '(버림 더미에 반환할 ' + trait + ' ' + cardType + ' 없음)');
};

/* 카드를 소유자 손으로 반환 (self 대상). 동료/업그레이드 등. 손으로 가면 인스턴스
   상태(HP/소진/카운터)는 새로 플레이 시 makeInstance로 초기화되므로 여기선 이동만. */
EFFECTS.returnToHand = function(G, p, ctx){
  let card = ctx.self || ctx.card;
  // p.card(slug) 지정 시 컨트롤러 플레이 영역에서 해당 카드 탐색 (Hammer Throw → Mjolnir 반환 등).
  if (p && p.card){
    const pl = ctx.player || G.players[G.firstPlayer];
    if (pl) for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies]){
      const found = arr.find(c => c.defCode === p.card);
      if (found){ card = found; break; }
    }
  }
  if (!card) return;
  const owner = G.players.find(x => x.uid === card.ownerUid) || ctx.player;
  if (!owner) return;
  // 플레이 영역에서 제거
  for (const arr of [owner.playArea.allies, owner.playArea.supports, owner.playArea.upgrades]){
    const i = arr.indexOf(card);
    if (i >= 0){ arr.splice(i, 1); break; }
  }
  // 부착물이 있으면 해제
  if (card.attachments && card.attachments.length) MC.releaseAttachments(G, card);
  // 새 인스턴스로 손에 추가 (상태 리셋 — HP 등 원상복구)
  const fresh = MC.makeInstance(G, card.defCode, {});
  fresh.ownerUid = owner.uid;
  owner.hand.push(fresh);
  MC.log(G, MC.nameOf(card) + ' — 소유자 손으로 반환');
};

EFFECTS.draw = function(G, p, ctx){
  const who = MC.resolvePlayers(G, p.who || 'self', ctx);
  for (const pl of who) MC.drawCards(G, pl, p.amount || 1);
};

// 덱 위에서 특정 히어로 시그니처 카드가 나올 때까지 버림 → 그 카드를 손에 (미즈마블 Teen Spirit).
EFFECTS.discardUntilHeroCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const hero = p.hero;
  let milled = 0, found = null;
  while (pl.deck && pl.deck.length){
    const c = pl.deck.shift();
    const d = MC.cardDef(c.defCode) || {};
    if (d.hero === hero){ found = c; break; }
    MC.moveToDiscard(G, pl, c, {}); milled++;
  }
  if (found){
    found.ownerUid = pl.uid; pl.hand.push(found);
    MC.log(G, MC.nameOf(pl) + ' — 덱 ' + milled + '장 버림 후 ' + MC.nameOf(found) + ' 손에 (Teen Spirit)');
  } else {
    MC.log(G, MC.nameOf(pl) + ' — 덱에서 미즈마블 카드 못 찾음 (' + milled + '장 버림)');
  }
};

EFFECTS.discardFromHand = function(G, p, ctx){
  const who = MC.resolvePlayers(G, p.who || 'self', ctx);
  for (const pl of who) MC.discardRandomFromHand(G, pl, p.amount || 1); // Phase 1: 선택 discard로 확장
}

/* 각 히어로 형태 플레이어가 손에서 N장 버림 — 태스크마스터 배반 04106 Hunted by Hydra. 범용. */
EFFECTS.discardFromHandEachHero = function(G, p, ctx){
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated || pl.form !== 'hero') continue;
    MC.runEffectList(G, [{ fx:'discardFromHand', count: p.count || 1, random: p.random }], { player: pl });
  }
};;

/* 손패 전체 강제 버림 (헐크 격노 등) — 공용 forcedDiscard로 VFX 힌트까지 처리. */
EFFECTS.discardHand = function(G, p, ctx){
  const who = MC.resolvePlayers(G, p.who || 'self', ctx);
  for (const pl of who){
    const cards = pl.hand.slice();
    if (cards.length) MC.forcedDiscard(G, pl, cards, { reason: p.reason || '강제 버림' });
  }
};

EFFECTS.placeThreat = function(G, p, ctx){
  // scheme:'self' → 이 카드(사이드 스킴) 자신. perHero → 인원수 비례 추가 위협.
  // scheme:'eachSide' → 전장의 각 사이드 스킴에 amount씩 (프로그램 전송기 01141 부스트★ 등).
  // perDroneInPlay → 전장의 모든 Drone 하수인 수 × 값만큼 추가 (드론 공장 01148).
  let amount = p.amount || 0;
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  if (p.amountFrom === 'ritualX') amount = G._ritualX || 0;
  if (p.perHero) amount += p.perHero * G.players.length;
  if (p.perDroneInPlay){
    let drones = 0;
    for (const pl of G.players)
      drones += pl.engagedMinions.filter(m => m.isDrone || (m.traits||[]).includes('drone')).length;
    amount += p.perDroneInPlay * drones;
    MC.log(G, '전장 Drone ' + drones + '명 × ' + p.perDroneInPlay + ' 위협');
  }
  if (p.scheme === 'eachSide'){
    const sides = (G.sideSchemes || []).slice();
    if (!sides.length){ MC.log(G, '(사이드 스킴 없음 — 위협 배치 불발)'); return; }
    for (const ss of sides) MC.placeThreat(G, ss.uid, amount);
    MC.log(G, '각 사이드 스킴에 위협 +' + amount + ' (' + sides.length + '곳)');
    return;
  }
  if (p.scheme === 'namedSide' && p.slug){   // 특정 사이드 스킴(defCode)에 위협 — 욘-로그 강제반응 등
    const ss = (G.sideSchemes || []).find(s => s.defCode === p.slug);
    if (ss){ MC.placeThreat(G, ss.uid, amount); MC.log(G, MC.nameOf(ss) + '에 위협 +' + amount); }
    else MC.log(G, p.slug + ' 사이드 스킴 없음 — 위협 배치 불발');
    return;
  }
  let ref = p.scheme || 'main';
  if (ref === 'self' && ctx.self) ref = ctx.self.uid;
  MC.placeThreat(G, ref, amount);
}

/* ★ 지연 카운터 비례 위협 (범용): 메인 스킴 delay 카운터 (per)개당 위협 1 배치.
   배치가 0이면 surgeIfNone 시 이 카드에 surge 부여 — 어보밍맨 배반 04085 Stall Tactics.
   추격전(delayPerVillainPhase) 시나리오의 "지연될수록 위협" 패턴에 재사용. */
EFFECTS.placeThreatPerDelayCounters = function(G, p, ctx){
  const delay = (G.mainScheme && G.mainScheme.delayCounters) || 0;
  const per = p.per || 2;
  const amt = Math.floor(delay / per);
  if (amt > 0){
    MC.placeThreat(G, p.scheme || 'main', amt);
    MC.log(G, '지연 카운터 ' + delay + ' → ' + (p.scheme || 'main') + ' 위협 +' + amt);
  } else if (p.surgeIfNone && ctx.self){
    ctx.self.surge = true;
    MC.log(G, '지연 카운터 부족 — 위협 배치 없음 → 급증(surge)');
  }
};;

/* 조우 덱 상위 N장을 확인(look at — 순서 유지, 버리지 않음) → matchType 카드 수 × perMatch 만큼 스킴 위협 제거.
   파라미터: count(볼 장수, 기본3), matchType(카운트 타입, 기본 treachery), perMatch(장당 제거, 기본1), scheme(대상, 기본 ctx.targetScheme||main).
   팔콘 등 "조우덱 훔쳐보고 배신 수만큼 위협 제거" 계열 재사용. 상위 = 덱 끝(pop 방향). */
EFFECTS.peekEncounterRemoveThreat = function(G, p, ctx){
  const n = p.count || 3;
  const deck = G.encounterDeck || [];
  const top = deck.slice(Math.max(0, deck.length - n));   // 상위 N장 (순서 유지 — 확인만)
  const ordered = top.slice().reverse();                  // 표시용: 덱 위(끝) → 아래 순
  let x = 0; const cards = [];
  for (const card of ordered){
    const d = MC.cardDef(card.defCode || card.code);
    const isMatch = !!(d && d.type === (p.matchType || 'treachery'));
    if (isMatch) x++;
    cards.push({ defCode: card.defCode, name: MC.nameOf(card), isMatch });
  }
  MC.log(G, '조우덱 상위 ' + top.length + '장 확인 [' + cards.map(c=>c.name).join(', ') + '] — ' + (p.matchType || 'treachery') + ' ' + x + '장');
  const amount = x * (p.perMatch || 1);
  // UI 공개 힌트 — 플레이어가 확인한 카드를 직접 볼 수 있게 (리펄서와 동일 패턴). 표시 전용.
  G.fxReveal = { kind:'peek', cards, matchType: (p.matchType || 'treachery'),
                 matchCount: x, perMatch: (p.perMatch || 1), threatRemoved: amount,
                 title: (ctx.card ? MC.nameOf(ctx.card) : '조우덱 확인') };
  if (amount > 0) MC.runEffectList(G, [{ fx:'removeThreat', amount, scheme: ctx.targetScheme || p.scheme }], ctx);
  else MC.log(G, '(' + (p.matchType || 'treachery') + ' 없음 — 위협 제거 없음)');
};

/* 하수인 등장 반응 발동(호크아이 등) — flushMinionReactions의 'fire' 선택지에서 호출.
   p: {allyUid, minionUid, amount, counter?, vfx?}. 동료 카운터 1 소진 후 그 하수인에 피해. */
EFFECTS.minionReactionDamage = function(G, p, ctx){
  const ally = MC.findByUid(G, p.allyUid);
  const minion = MC.findByUid(G, p.minionUid);
  if (!ally || !minion || minion.hp <= 0){ MC.log(G, '반응 대상 없음 — 불발'); return; }
  if (p.counter){
    if ((ally.counters || 0) <= 0){ MC.log(G, (p.counter) + ' 카운터 없음 — 불발'); return; }
    ally.counters = (ally.counters || 0) - 1;
  }
  if (p.vfx) G.fxAllyReaction = { allyUid: ally.uid, targetUid: minion.uid, vfx: p.vfx, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  MC.log(G, MC.nameOf(ally) + ' 등장 반응 발동 — ' + MC.nameOf(minion) + '에 ' + p.amount + ' 피해' +
    (p.counter ? ' (' + p.counter + ' 잔여 ' + (ally.counters || 0) + ')' : ''));
  MC.applyDamage(G, minion, p.amount, { source: ally });
};

/* 트레잇 기준 캐릭터 준비 — p.trait(예:'avenger'). ctx.player가 조종하는 히어로(신분이 트레잇 보유)+동료(trait 보유) 준비.
   어벤져스 어셈블 등. p.scope:'controlled'(기본, 조종 캐릭터만) | 'all'(전 플레이어). */
EFFECTS.readyCharactersByTrait = function(G, p, ctx){
  const trait = String(p.trait || '').toLowerCase();
  const players = p.scope === 'all' ? G.players : [ctx.player || G.players[G.firstPlayer]];
  let n = 0;
  for (const pl of players){
    if (!pl || pl.eliminated) continue;
    if (MC.playerHasTrait(G, pl, trait) && pl.exhausted){ pl.exhausted = false; n++; }
    for (const ally of (pl.playArea.allies || [])){
      if (MC.allyHasTrait(G, ally, trait) && ally.exhausted){ ally.exhausted = false; n++; }
    }
  }
  MC.log(G, trait + ' 캐릭터 ' + n + '명 준비(ready)');
};

/* 트레잇 기준 페이즈 임시 스탯 버프 — p.trait, p.stats({thwart:1,attack:1,...}). 전장의 해당 트레잇 캐릭터(전 플레이어) tempStatBonus 가산.
   페이즈 종료 시 자동 소멸(endPlayerPhase에서 tempStatBonus 초기화). */
EFFECTS.buffCharactersByTrait = function(G, p, ctx){
  const trait = String(p.trait || '').toLowerCase();
  const stats = p.stats || {};
  const add = (obj) => { obj.tempStatBonus = obj.tempStatBonus || {}; for (const k in stats) obj.tempStatBonus[k] = (obj.tempStatBonus[k] || 0) + stats[k]; };
  let n = 0;
  for (const pl of G.players){
    if (!pl || pl.eliminated) continue;
    if (MC.playerHasTrait(G, pl, trait)){ add(pl); n++; }
    for (const ally of (pl.playArea.allies || [])){
      if (MC.allyHasTrait(G, ally, trait)){ add(ally); n++; }
    }
  }
  const label = Object.entries(stats).map(([k,v]) => (v>=0?'+':'') + v + ' ' + k).join(', ');
  MC.log(G, '전장의 ' + trait + ' 캐릭터 ' + n + '명 이번 페이즈 ' + label);
};

/* 원하는 수만큼 동료 소진 → 소진 수만큼 드로우 (수적 우위). 준비된 동료 중 플레이어가 임의 다중 선택.
   준비된 동료가 없으면 no-op. 선택은 allyExhaustDraw pending(토글+확정)으로 처리 — 선택 기능 보존. */
/* 손에서 조건 맞는 동료 1명을 전장에 무료 배치 → 선택 pending (deployAlly).
   trait: 요구 특성(avenger 등). costFromCounters: 소스 카운터 수 이하 인쇄비용만. discardSelfAfter: 배치 후 소스 버림.
   퀸젯 등. 배치 가능 동료 없으면 throw(행동 불발) — 소스 소비 방지. 선택 기능 보존. */
/* 이번 페이즈 다음에 플레이하는 카드 비용 감소 (헬리캐리어 일반화). amount: 감소량.
   allyTrait 지정 시 → 그 특성 동료에만 적용(어벤져스 타워: 다음 Avenger 동료). 필터 미매치 카드엔 할인 미소모(유지). */
/* 플레이어 순서로 각자 조우덱 top 1장 버림 → 버린 카드의 부스트 아이콘 수만큼 그 플레이어에게 피해 (히트 스쿼드).
   drawEncounterCard 재사용(pop=top, 리셔플·가속 처리). 부스트 아이콘 = def.boost. */
/* 빌런 활성화 (Crossbones' Assault: 처치 시 크로스본즈가 그 플레이어를 공격). */
EFFECTS.villainActivate = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (G.villain) MC.enemyActivation(G, G.villain, pl);
};

/* 조우덱 top N장(perHero면 1/영웅) 버림 → 버린 카드 부스트 아이콘 합만큼 지정 스킴에 위협 (Cornered Staff).
   self:true면 ctx.self(이 사이드 스킴)에 배치. */
EFFECTS.discardEncounterBoostToScheme = function(G, p, ctx){
  const n = p.perHero ? (G.players ? G.players.length : 1) : (p.amount || 1);
  let boostSum = 0;
  for (let i = 0; i < n; i++){
    const c = MC.drawEncounterCard ? MC.drawEncounterCard(G) : null;
    if (!c) break;
    boostSum += (MC.cardDef(c.defCode).boost || 0);
    if (G.encounterDiscard) G.encounterDiscard.push(c);
  }
  const scheme = p.self ? (ctx.self || ctx.card) : MC.resolveScheme(G, p.scheme || 'main');
  if (scheme && boostSum > 0){
    scheme.threat = (scheme.threat || 0) + boostSum;
    MC.log(G, MC.nameOf(scheme) + ' — 조우덱 버림 부스트 위협 +' + boostSum);
  }
};

EFFECTS.eachPlayerDiscardEncounterBoostDamage = function(G, p, ctx){
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    const card = MC.drawEncounterCard(G);
    if (!card){ MC.log(G, MC.nameOf(pl) + ' — 조우덱 비어 버릴 카드 없음'); continue; }
    const d = MC.cardDef(card.defCode) || {};
    const boostN = (typeof d.boost === 'number') ? d.boost : 0;
    (G.encounterDiscard = G.encounterDiscard || []).push(card);
    MC.log(G, MC.nameOf(pl) + ' — 조우덱 top 버림: ' + MC.nameOf(card) + ' (부스트 ' + boostN + ')');
    if (boostN > 0) MC.applyDamage(G, pl, boostN, { source: ctx.self || ctx.card });
  }
};

/* 활성 플레이어가 조우덱 top N장 버림 → 버린 카드 부스트 아이콘 합만큼 간접 피해.
   countFrom:'villainAtk'면 N = 빌런 ATK (Full Auto 히어로 분기). Machine Gun(1장)도 재사용. */
/* 조우덱 top부터 특정 trait 카드가 나올 때까지 버림 → 그 카드를 공개(resolveEncounterCard).
   무기고 습격: Weapon 부착물이 나올 때까지 버리고 그 무기를 공개(빌런에 부착). */
EFFECTS.discardEncounterUntilTrait = function(G, p, ctx){
  const trait = String(p.trait || '').toLowerCase();
  let found = null;
  for (let guard = 0; guard < 40; guard++){
    const c = MC.drawEncounterCard(G);
    if (!c) break;
    const d = MC.cardDef(c.defCode) || {};
    if ((d.traits || []).map(t => String(t).toLowerCase()).includes(trait)){ found = c; break; }
    (G.encounterDiscard = G.encounterDiscard || []).push(c);
    MC.log(G, '무기고 습격 — ' + MC.nameOf(c) + ' 버림 (' + trait + ' 아님)');
  }
  if (found){
    MC.log(G, '무기고 습격 — ' + MC.nameOf(found) + ' 공개!');
    if (MC.resolveEncounterCard) MC.resolveEncounterCard(G, found, ctx.player || G.players[G.firstPlayer]);
  } else {
    MC.log(G, '무기고 습격 — 조우덱에서 ' + trait + ' 카드를 찾지 못함');
  }
};

EFFECTS.discardEncounterByCountBoostDamage = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let n = p.amount || 1;
  if (p.countFrom === 'villainAtk') n = G.villain ? MC.enemyAtk(G, G.villain) : 0;
  let boostSum = 0;
  for (let i = 0; i < n; i++){
    const card = MC.drawEncounterCard(G);
    if (!card) break;
    boostSum += (MC.cardDef(card.defCode).boost || 0);
    (G.encounterDiscard = G.encounterDiscard || []).push(card);
  }
  if (boostSum > 0) MC.applyDamage(G, pl, boostSum, { source: ctx.self || ctx.card });
  MC.log(G, MC.nameOf(pl) + ' — 조우덱 ' + n + '장 버림, 부스트 ' + boostSum + ' 간접 피해');
};

EFFECTS.reduceNextPlayCost = function(G, p, ctx){
  const target = (ctx.targetPlayer && G.players.find(x => x.uid === ctx.targetPlayer)) || ctx.player;
  target.nextCardDiscount = (target.nextCardDiscount || 0) + (p.amount || 1);
  if (p.allyTrait) target.nextCardDiscountFilter = { type:'ally', trait: String(p.allyTrait).toLowerCase() };
  else target.nextCardDiscountFilter = null;
  MC.log(G, MC.nameOf(target) + ' — 다음 ' + (p.allyTrait ? p.allyTrait + ' 동료' : '카드') + ' 비용 -' + (p.amount || 1) + ' (이번 페이즈)');
};

// 버림 더미의 카드 1장을 덱 맨 아래로 → 카드 1장 드로우 (아미르 칸 Persona 액션).
// p.pick:'first'(임시 자동) — 후보 여러 장이면 이상적으론 선택이나, 우선 가장 오래된 1장.
EFFECTS.recycleDiscardBottomDraw = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (pl.discard && pl.discard.length){
    const card = pl.discard.shift();               // 가장 아래(오래된) 카드
    (pl.deck = pl.deck || []).push(card);          // 덱 맨 아래로
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + '을(를) 덱 맨 아래로 (아미르 칸)');
  } else {
    MC.log(G, MC.nameOf(pl) + ' — 버림 더미 비어있음 (덱 바닥 이동 생략)');
  }
  MC.drawCards(G, pl, 1);
};

EFFECTS.deployAllyFromHand = function(G, p, ctx){
  const pl = ctx.player;
  const src = ctx.card;
  const cap = p.costFromCounters ? (src.counters || 0) : Infinity;
  const trait = p.trait ? String(p.trait).toLowerCase() : null;
  const eligible = (pl.hand || []).filter(c => {
    const d = MC.cardDef(c.defCode);
    if (!d || d.type !== 'ally') return false;
    if (trait && !(d.traits || []).some(t => String(t).toLowerCase() === trait)) return false;
    if ((d.cost || 0) > cap) return false;
    return true;
  });
  if (!eligible.length)
    throw new Error('[deployAllyFromHand] 배치 가능한 동료 없음 (인쇄비용 ' + cap + ' 이하 ' + (p.trait || '') + ' 동료)');
  G.pending = { kind:'deployAlly', player: pl.uid, allyUids: eligible.map(c => c.uid),
                sourceUid: src.uid, discardSource: !!p.discardSelfAfter,
                prompt: p.prompt || '전장에 배치할 동료 선택 (인쇄비용 ' + cap + ' 이하)' };
  MC.log(G, MC.nameOf(src) + ' — 배치할 동료 선택 대기 (후보 ' + eligible.length + ')');
};

EFFECTS.exhaustAlliesForDraw = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const ready = (pl.playArea.allies || []).filter(a => !a.exhausted);
  if (!ready.length){ MC.log(G, '준비된 동료 없음 — 소진/드로우 없음'); return; }
  G.pending = { kind:'allyExhaustDraw', player: pl.uid,
                allyUids: ready.map(a => a.uid), chosen: [],
                prompt: p.prompt || '소진할 동료 선택 (소진한 수만큼 드로우)' };
  MC.log(G, '수적 우위 — 소진할 동료 선택 대기');
};

EFFECTS.removeThreat = function(G, p, ctx){
  // 조건부 제거량 (amountIf: {cond, amount}) — 조건 충족 시 그 값으로 대체
  // (정의를 위해!=멘탈 지불 시 3→4). dealDamage amountIf와 동일 패턴.
  let amount = p.amount;
  if (p.amountFrom === 'lastDamageTaken'){   // You'll Pay for That!: 받은 피해당 위협 제거 (최대 max)
    const plr = ctx.player || G.players[G.firstPlayer];
    amount = Math.min(p.max || 99, plr.lastDamageTaken || 0);
  }
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  amount += (ctx.eventThreatBonus || 0);   // Shrink 등 이벤트 강화 인터럽트 보너스
  // 조건부 광역: allSchemesIf 충족 시 모든 스킴에서 제거 (MK.5 헬멧 Aerial 등)
  if (p.allSchemesIf && MC.condCheck(G, p.allSchemesIf, ctx)){
    MC.removeThreat(G, 'main', amount);
    for (const ss of (G.sideSchemes || []).slice()) MC.removeThreat(G, ss.uid, amount);
    MC.log(G, '(모든 스킴에서 위협 ' + amount + '씩 제거 — Aerial)');
    return;
  }
  // 단일 스킴: ctx.targetScheme(UI 선택) 우선, 없으면 p.scheme 또는 main
  const ref = ctx.targetScheme || p.scheme || 'main';
  // 위기(Crisis): crisis 사이드 스킴이 전장에 있으면 메인 스킴 위협 제거 불가.
  //   단, 저지 효과가 위기 무시(ignoreCrisis)를 명시하면 통과(케이블 화살/위기 회피 등).
  if (ref === 'main' && !p.ignoreCrisis && MC.hasCrisisScheme && MC.hasCrisisScheme(G)){
    MC.log(G, '위기(Crisis) 사이드 스킴 — 메인 스킴 위협 제거 불가 (제거 불발)');
    return;
  }
  MC.removeThreat(G, ref, amount);
};

EFFECTS.applyStatus = function(G, p, ctx){ // stunned | confused | tough
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt){
    // failIfHas: 이미 그 상태면 부여 실패 → failEffect (Hard as Nails: tough 불가 시 3 회복)
    if (p.failIfHas && t.status && t.status[p.status] > 0){
      if (p.failEffect) MC.runEffectList(G, p.failEffect, Object.assign({}, ctx, { targets:[t] }));
    } else {
      MC.setStatus(G, t, p.status, true);
    }
  }
};

/* 라운드 지속 히어로 스탯 버프 (사기 증진 등). p:{ stats:{thwart?,attack?,defense?,...} }.
   대상 = ctx.targetPlayer(멀티 선택) 또는 시전자 본인의 히어로. roundStatBonus에 누적 → 라운드 종료 시 소멸.
   statOf가 roundStatBonus를 합산하므로 신규 집계 코드 불필요 — 데이터로만 표현. */
EFFECTS.roundStatBuff = function(G, p, ctx){
  const target = (ctx.targetPlayer && G.players.find(q => q.uid === ctx.targetPlayer)) || ctx.player;
  target.roundStatBonus = target.roundStatBonus || {};
  const stats = p.stats || {};
  for (const st in stats) target.roundStatBonus[st] = (target.roundStatBonus[st] || 0) + stats[st];
  MC.log(G, MC.nameOf(target) + ' 라운드 버프 ' +
    Object.keys(stats).map(k => k + '+' + stats[k]).join('/') + ' (라운드 종료까지)');
};

EFFECTS.readyTarget = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt) t.exhausted = false;
};

EFFECTS.exhaustTarget = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt) t.exhausted = true;
};

// 특정 카드(defCode/slug 또는 mcode)를 준비(ready) — 호크아이 Quick Draw가 "호크아이의 활"을 준비 등. 소진된 첫 카드 1장.
EFFECTS.readyNamedCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl) return false;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies]){
    const c = arr.find(x => x.exhausted && (x.defCode === p.card || (p.mcode && MC.cardDef(x.defCode) && MC.cardDef(x.defCode).mcode === p.mcode)));
    if (c){ c.exhausted = false; MC.log(G, MC.nameOf(c) + ' 준비'); return true; }
  }
  MC.log(G, '(' + (p.card || p.mcode) + ' 준비할 카드 없음 — 이미 준비되었거나 인플레이 없음)');
  return false;
};

// 특정 카드(defCode/slug)를 비용으로 소진 — 방패 막기가 "캡틴아메리카의 방패"를 소진 등. 준비된 첫 카드 1장.
EFFECTS.exhaustNamedCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl) return false;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies]){
    const c = arr.find(x => x.defCode === p.card && !x.exhausted);
    if (c){ c.exhausted = true; MC.log(G, MC.nameOf(c) + ' 소진 (비용)'); return true; }
  }
  MC.log(G, '(' + p.card + ' 준비된 카드 없음 — 소진 불가)');
  return false;
};

// 통제하는 모든 동료 소진 (멜터 부스트★): ctx.player의 동료 전부 exhausted. 대상 미지정 시 전 플레이어.
EFFECTS.exhaustAllAllies = function(G, p, ctx){
  const players = ctx.player ? [ctx.player] : MC.playersInOrder(G);
  let n = 0;
  for (const pl of players) for (const a of pl.playArea.allies){ if (!a.exhausted){ a.exhausted = true; n++; } }
  if (n) MC.log(G, '멜터 부스트★ — 동료 ' + n + '명 소진');
};

// 통제하는 모든 캐릭터(히어로 자신 + 동료) 소진 — "각 캐릭터를 소진" 배신(소닉 붐 등).
// exhaustAllAllies와 분리: 그건 동료 전용 + 멜터 전용 로그라 히어로 포함 불가. 범용 로그 사용.
EFFECTS.exhaustControlled = function(G, p, ctx){
  const players = ctx.player ? [ctx.player] : MC.playersInOrder(G);
  let n = 0;
  for (const pl of players){
    if (!pl.exhausted){ pl.exhausted = true; n++; }                 // 히어로 자신
    for (const a of pl.playArea.allies){ if (!a.exhausted){ a.exhausted = true; n++; } }  // 동료
  }
  if (n) MC.log(G, MC.nameOf(ctx.self || { name: '효과' }) + ' — 통제 캐릭터 ' + n + '명 소진');
};

// 신분 카드 소진 — Exhaustion(01191). 활성 플레이어의 신분(정체성) 카드를 소진 상태로.
EFFECTS.exhaustIdentity = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.exhausted = true;
  MC.log(G, MC.nameOf(pl) + ' 신분 카드 소진 (Exhaustion)');
};

// 조우덱에서 사이드 스킴이 나올 때까지 버리고 그 사이드 스킴을 전장에 공개 — Masterplan(01192) 폴백.
EFFECTS.discardUntilSideScheme = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let guard = G.encounterDeck.length + G.encounterDiscard.length + 1;
  let found = null;
  while (guard-- > 0){
    const c = MC.drawEncounterCard(G);
    if (!c) break;
    if (c.type === 'side_scheme' || c.type === 'sideScheme'){ found = c; break; }
    G.encounterDiscard.push(c);
    MC.log(G, MC.nameOf(c) + ' 버림 (사이드 스킴 탐색 중)');
  }
  if (!found){ MC.log(G, '조우덱에 사이드 스킴 없음 — 효과 불발'); return; }
  found.threat = found.threat || 0;
  (G.sideSchemes = G.sideSchemes || []).push(found);
  MC.log(G, '사이드 스킴 ' + MC.nameOf(found) + ' 전장 공개 (Masterplan)');
  MC.fireCardHook(G, found, 'whenRevealed', { player: pl });
};

// Shadow of the Past(01190): 셋어사이드된 넴시스 하수인·사이드스킴을 전장에 투입, 나머지는 조우덱에 셔플.
// 하수인이 등장하지 못하면(이미 전장/제거 등) ctx._nemesisMinionEntered=false → 호출부 surge.
EFFECTS.revealNemesisSet = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const aside = pl.nemesisSetAside || [];
  let minionEntered = false;
  const remaining = [];
  for (const card of aside){
    if (card._nemesisRole === 'minion'){
      // 이미 같은 넴시스 하수인이 전장에 있으면 재투입하지 않음 (중복 방지)
      const already = G.players.some(q => (q.engagedMinions || []).some(m => (m.defCode || m.code) === (card.defCode || card.code) && m.hp > 0));
      if (already){ remaining.push(card); continue; }
      card.type = 'minion';
      card.engagedWith = pl.uid;
      card.status = card.status || { stunned:0, confused:0, tough:0 };
      pl.engagedMinions.push(card);
      MC.minionEnteredPlay(G, card, pl);
      (G.revealLog = G.revealLog || []).push({ defCode: card.defCode, name: card.name, type:'minion', player: pl.uid });
      minionEntered = true;
      MC.log(G, '넴시스 하수인 ' + MC.nameOf(card) + ' 전장 투입 (' + pl.uid + '와 교전)');
      MC.fireCardHook(G, card, 'whenRevealed', { player: pl });
    } else if (card._nemesisRole === 'sideScheme'){
      const ss = card;
      ss.threat = ss.threat || 0;
      (G.sideSchemes = G.sideSchemes || []).push(ss);
      MC.log(G, '넴시스 사이드 스킴 ' + MC.nameOf(ss) + ' 전장 공개');
      MC.fireCardHook(G, ss, 'whenRevealed', { player: pl });
    } else {
      remaining.push(card);   // 나머지(배신/부착)는 조우덱으로
    }
  }
  // 나머지를 조우덱에 섞기
  if (remaining.length){
    for (const c of remaining){ c._nemesisRole = undefined; G.encounterDeck.push(c); }
    MC.shuffle(G, G.encounterDeck);
    MC.log(G, '나머지 넴시스 조우 카드 ' + remaining.length + '장 조우덱에 셔플');
  }
  pl.nemesisSetAside = [];
  ctx._nemesisMinionEntered = minionEntered;
  G._nemesisMinionEntered = minionEntered;
};

// 빌런과 활성 플레이어와 교전 중인 각 하수인이 그 플레이어를 공격 — Gang-Up(01189).
// 빌런을 체인 맨 앞에 넣고, 이어서 교전 하수인들을 순서대로 공격시킨다(startMinionAttackChain 재사용).
EFFECTS.villainAndMinionsAttack = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const pairs = [];
  if (G.villain && G.villain.hp > 0) pairs.push({ attackerUid: G.villain.uid, playerUid: pl.uid });
  for (const m of (pl.engagedMinions || [])){
    if (m.hp > 0) pairs.push({ attackerUid: m.uid, playerUid: pl.uid });
  }
  if (pairs.length){
    MC.log(G, MC.nameOf(pl) + '에게 집중 공격 — 빌런 + 교전 하수인 ' + (pairs.length - 1) + '명');
    MC.startMinionAttackChain(G, pairs);
  }
};

// 통제하는 업그레이드 또는 지원 1장 버림 (영구/부착 제외) — Caught Off Guard(01188).
// 공식: 소유 플레이어가 어느 카드를 버릴지 선택. 후보 0=급증 / 1=자동 / 2+=플레이어 선택(pickControlledDiscard).
// 버린 게 없으면(후보 0) surge 판정용 플래그를 false로. 후보 있으면 반드시 1장 버려지므로 선판정 true.
EFFECTS.discardUpgradeOrSupport = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const cands = [];
  const arrs = p.onlyType === 'support' ? [pl.playArea.supports || []]
             : p.onlyType === 'upgrade' ? [pl.playArea.upgrades || []]
             : [pl.playArea.upgrades || [], pl.playArea.supports || []];
  for (const arr of arrs){
    for (const c of arr){
      const d = MC.cardDef(c.defCode || c.code) || {};
      if (!d.permanent && !c.attachedTo && !c.hostUid) cands.push(c);   // 영구·부착물 제외
    }
  }
  if (!cands.length){
    ctx._discardedCard = false; G._discardedUpgradeOrSupport = false;
    MC.log(G, '버릴 업그레이드/지원 없음 — 급증(Surge)');
    return;
  }
  ctx._discardedCard = true; G._discardedUpgradeOrSupport = true;   // 후보 있음 → 반드시 버려짐(급증 없음, 선판정)
  if (cands.length === 1){ MC.discardControlledCard(G, pl, cands[0], 'Caught Off Guard'); return; }
  // 2장 이상 → 무작위 아님 → 플레이어가 직접 선택
  G.pending = { kind:'pickControlledDiscard', player: pl.uid,
                cardUids: cands.map(c => c.uid),
                prompt: p.prompt || '버릴 업그레이드/지원 1장 선택' };
  MC.log(G, MC.nameOf(pl) + ' — 버릴 장비 선택 대기 (' + cands.length + '장 중 1장)');
};

// 통제하는 모든 업그레이드 소진 — 사업 문제(01170) 등. ctx.player 기준.
EFFECTS.exhaustAllUpgrades = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let n = 0;
  for (const up of (pl.playArea.upgrades || [])){ if (!up.exhausted){ up.exhausted = true; n++; } }
  MC.log(G, '통제 업그레이드 ' + n + '개 소진 (의무 해결)');
};

// 선택 배신 범용화 — 플레이어 선택 pending(revealChoice)을 데이터로 세운다.
// 커스텀 핸들러(rev_hydraBomber 등) 없이 effects:[{fx:'offerChoice', prompt, options:[...]}]로 선언.
// options: [{ key, label, effects:[...], payIcons:{energy:1,...} }]. payIcons 지불은 resolveRevealChoice가 처리.
EFFECTS.offerChoice = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const self = ctx.self || ctx.card;
  // 옵션별 availableIf 조건 필터 (예: 신분이 준비 상태일 때만 "소진→제거" 옵션 제공)
  const opts = (p.options || []).filter(o => !o.availableIf || MC.condCheck(G, o.availableIf, { player: pl, card: self, self }));
  G.pending = { kind: 'revealChoice', player: pl.uid,
                selfUid: self ? self.uid : null,
                prompt: p.prompt || '선택하세요', options: opts.length ? opts : (p.options || []) };
  MC.log(G, MC.nameOf(self || { name: '조우 카드' }) + ' 공개 — 선택 대기');
};

// 통제 중인 업그레이드 1장 버림 — p.hero 지정 시 그 영웅 시그니처 업그레이드만(블랙 팬서 의무 등).
// 공식: 소유 플레이어 선택. 후보 0=no-op(호출부 surge) / 1=자동 / 2+=플레이어 선택. 버린 여부를 ctx._discardedUpgrade.
EFFECTS.discardControlledUpgrade = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const ups = pl.playArea.upgrades || [];
  const cands = ups.filter(u => {
    const d = MC.cardDef(u.defCode || u.code);
    return d && (!p.hero || d.hero === p.hero) && (!p.trait || (d.traits || []).includes(p.trait))
             && !d.permanent && !u.attachedTo && !u.hostUid;
  });
  if (!cands.length){ ctx._discardedUpgrade = false; MC.log(G, '버릴 ' + (p.hero || '') + ' 업그레이드 없음'); return; }
  ctx._discardedUpgrade = true;   // 후보 있음 → 반드시 버려짐(선판정)
  if (cands.length === 1){ MC.discardControlledCard(G, pl, cands[0], '의무 해결'); return; }
  G.pending = { kind:'pickControlledDiscard', player: pl.uid,
                cardUids: cands.map(c => c.uid),
                prompt: p.prompt || '버릴 업그레이드 1장 선택' };
  MC.log(G, MC.nameOf(pl) + ' — 버릴 업그레이드 선택 대기 (' + cands.length + '장 중 1장)');
};

// 공용: 통제 중인 카드(업그레이드/지원/동료) 1장을 플레이 영역에서 제거 → 버림 더미로.
MC.discardControlledCard = function(G, pl, card, reason){
  for (const key of ['upgrades', 'supports', 'allies']){
    const arr = pl.playArea[key]; if (!arr) continue;
    const i = arr.indexOf(card);
    if (i >= 0){
      arr.splice(i, 1);
      if (MC.moveToDiscard) MC.moveToDiscard(G, pl, card, {});
      else (pl.discard = pl.discard || []).push(card);
      MC.log(G, MC.nameOf(card) + ' 버림' + (reason ? ' (' + reason + ')' : ''));
      return true;
    }
  }
  return false;
};

// 손패에서 자원 아이콘 가진 카드 후보 (types 지정 시 그 타입 또는 wild, 미지정 시 아무 자원).
MC.resourceCandidates = function(pl, types){
  return (pl.hand || []).filter(c => {
    const ic = MC.resourceIconsOf(c) || {};
    if (!types || !types.length) return Object.values(ic).some(v => v > 0);   // 아무 자원
    return types.some(t => (ic[t] || 0) > 0) || (ic.wild || 0) > 0;
  });
};
// 손패 카드 1장 버림 (제거+버림더미).
MC.discardHandCard = function(G, pl, card){
  const i = (pl.hand || []).indexOf(card); if (i < 0) return false;
  pl.hand.splice(i, 1);
  if (MC.moveToDiscard) MC.moveToDiscard(G, pl, card, {});
  else (pl.discard = pl.discard || []).push(card);
  return true;
};
// 손패 자원 카드 선택 버림 pending 셋업 (다중 플레이어 큐). 후보 0=스킵, ≤필요=자동 전부, >필요=플레이어 선택.
// ctx: { queue:[uid...], perPlayerCount, types|null, prompt, reason }. pending 세우면 true, 전부 자동처리면 false.
MC.setupResourceDiscardPick = function(G, spec){
  const findPl = uid => G.players.find(p => p.uid === uid);
  while (spec.queue.length){
    const uid = spec.queue[0];
    const pl = findPl(uid);
    if (!pl || pl.eliminated){ spec.queue.shift(); continue; }
    const cands = MC.resourceCandidates(pl, spec.types);
    if (!cands.length){                                   // 자원 없음 → 스킵 (if able)
      MC.log(G, MC.nameOf(pl) + ' — 버릴 자원 없음' + (spec.reason ? ' (' + spec.reason + ')' : ''));
      spec.queue.shift(); continue;
    }
    const need = Math.min(spec.perPlayerCount, cands.length);
    if (cands.length <= need){                            // 후보 ≤ 필요 → 전부 자동 (선택 의미 없음)
      for (const c of cands.slice()){ MC.discardHandCard(G, pl, c); MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 버림' + (spec.reason ? ' (' + spec.reason + ')' : '')); }
      spec.queue.shift(); continue;
    }
    G.pending = { kind:'resourceDiscardPick', player: uid, count: need, chosen: 0,
                  types: spec.types || null, queue: spec.queue.slice(1),
                  perPlayerCount: spec.perPlayerCount, prompt: spec.prompt || '버릴 자원 카드 선택', reason: spec.reason };
    return true;
  }
  return false;
};

// 의무(Obligation) 카드 자체 처리 — p.mode:'game'(게임에서 영구 제거) / 'discard'(조우 버림).
// ctx.self가 의무 카드. obligationsOut에서도 제거. p.surgeIfNoDiscard면 직전 버림 실패 시 surge.
/* 알터에고 폼으로 전환 (카드 부여 전환 — 라운드 1회 제한 무시, force). 이미 알터에고면 no-op.
   맨 아웃 오브 타임 등 "알터에고로 전환 가능" 의무. */
/* 형태 강제 변경(토글) — 내면의 악마: 현재 폼의 반대로 뒤집기. */
EFFECTS.changeForm = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  MC.flipForm(G, pl, { force: true });
  MC.log(G, MC.nameOf(pl) + ' — 형태 강제 변경');
};
/* 히어로(신분) 소진 — 내면의 악마(헐크면 소진). */
EFFECTS.exhaustPlayer = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.exhausted = true;
  MC.log(G, MC.nameOf(pl) + ' — 히어로 소진');
};

EFFECTS.flipToAlterEgo = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (pl.form === 'alter-ego'){ MC.log(G, '이미 알터에고 폼'); return; }
  MC.flipForm(G, pl, { force: true });
  MC.log(G, MC.nameOf(pl) + ' — 알터에고 폼으로 전환 (의무)');
};

/* 손패에서 원하는 카드 N장(또는 절반 내림) 선택 버림 → 완료 후 afterEffects 실행. 선택식(discardChoose pending).
   맨 아웃 오브 타임(손패 절반) 등. countHalf:true면 floor(hand/2). N=0이면 즉시 afterEffects. */
EFFECTS.discardChooseFromHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const self = ctx.self || ctx.card;
  const n = p.countHalf ? Math.floor((pl.hand || []).length / 2) : (p.count || 0);
  const after = p.afterEffects || [];
  if (n <= 0){
    MC.log(G, '버릴 카드 없음 — 후속 효과로');
    if (after.length) MC.runEffectList(G, after, { player: pl, self, card: self, targetScheme:'main' });
    return;
  }
  G.pending = { kind:'discardChoose', player: pl.uid, remaining: n, total: n, chosen: [],
                selfUid: self ? self.uid : null, afterEffects: after,
                prompt: p.prompt || ('손패에서 ' + n + '장 선택하여 버리기') };
  MC.log(G, MC.nameOf(pl) + ' — 손패 ' + n + '장 선택 버림 대기');
};

/* 특정 slug 카드를 손 또는 전장(업그레이드)에서 버림 — 오딘의 분노(묠니르 버림). 대상 = ctx.player(의무 소유자). */
/* 각 플레이어 덱 상단 N장 버림 → 버려진 카드의 서로 다른 타입 종류 수만큼 메인 스킴 위협 추가 (속임수 06030). */
EFFECTS.discardTopCountTypes = function(G, p, ctx){
  const n = p.count || 3;
  const types = new Set();
  for (const pl of G.players){
    for (let i = 0; i < n && pl.deck.length; i++){
      const c = pl.deck.pop();
      pl.discard.push(c);
      const d = MC.cardDef(c.defCode);
      if (d && d.type) types.add(d.type);
      MC.log(G, MC.nameOf(pl) + ' 덱 상단 ' + MC.nameOf(c) + ' 버림 (' + (d ? d.type : '?') + ')');
    }
  }
  const count = types.size;
  if (count > 0){ MC.placeThreat(G, 'main', count); MC.log(G, '속임수 — 서로 다른 타입 ' + count + '종 → 메인 스킴 위협 +' + count); }
  else MC.log(G, '속임수 — 버린 카드 없음 (위협 추가 없음)');
};

/* 이 스킴(ctx.self)에 위협 직접 추가 — Killer for Hire(공개 시 +1). */
EFFECTS.addSelfThreat = function(G, p, ctx){
  const s = ctx.self || ctx.card || (G.sideSchemes && G.sideSchemes[G.sideSchemes.length - 1]);
  if (s){ s.threat = (s.threat || 0) + (p.amount || 1); MC.log(G, MC.nameOf(s) + ' 위협 +' + (p.amount || 1) + ' (' + s.threat + ')'); }
};

/* 전장의 특정 트레잇 카드 수만큼 이 스킴(ctx.self)에 위협 추가 — 가족의 불화(Asgard 카드 1장당 +1). */
EFFECTS.countTraitAddThreat = function(G, p, ctx){
  const trait = p.trait;
  let count = 0;
  for (const pl of G.players)
    for (const arr of [pl.playArea.allies || [], pl.playArea.upgrades || [], pl.playArea.supports || []])
      for (const c of arr){ const d = MC.cardDef(c.defCode); if (d && (d.traits || []).includes(trait)) count++; }
  const s = ctx.self || ctx.card || (G.sideSchemes && G.sideSchemes[G.sideSchemes.length - 1]);
  if (s && count > 0){ s.threat = (s.threat || 0) + count; MC.log(G, MC.nameOf(s) + ' — ' + trait + ' 카드 ' + count + '장 → 위협 +' + count + ' (' + s.threat + ')'); }
  else MC.log(G, '(' + trait + ' 카드 없음 — 위협 추가 없음)');
};

EFFECTS.discardNamedCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const slug = p.card;
  let idx = pl.hand.findIndex(c => c.defCode === slug);
  if (idx >= 0){ const c = pl.hand.splice(idx, 1)[0]; MC.moveToDiscard(G, pl, c, {}); MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손에서 버림'); ctx._discardedNamed = true; return; }
  idx = (pl.playArea.upgrades || []).findIndex(c => c.defCode === slug);
  if (idx >= 0){ const c = pl.playArea.upgrades.splice(idx, 1)[0]; MC.moveToDiscard(G, pl, c, {}); MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 전장에서 버림'); ctx._discardedNamed = true; return; }
  MC.log(G, '(' + slug + ' 없음 — 버릴 대상 없음)'); ctx._discardedNamed = false;
};

EFFECTS.resolveObligation = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const pl = ctx.player;
  if (p.surgeIfNoDiscard && ctx._discardedUpgrade === false){
    G.pendingSurge = (G.pendingSurge || 0) + 1;
    MC.log(G, '의무 — 버릴 업그레이드 없음 → 급증(Surge)');
  }
  if (p.mode === 'game'){
    (G.removedFromGame = G.removedFromGame || []).push(self ? (self.defCode || self.code) : null);
    // 조우 영역에서 실제 인스턴스 제거 (게임에서 영구 제거 — 버린더미/덱에 남지 않도록)
    if (self){
      for (const zone of ['encounterDiscard','encounterDeck']){
        const arr = G[zone]; if (!arr) continue;
        const i = arr.indexOf(self); if (i >= 0){ arr.splice(i, 1); break; }
      }
    }
    MC.log(G, '의무 해결 — 게임에서 영구 제거');
  } else {
    // 조우 버린더미로 (이미 있으면 중복 방지)
    if (self && G.encounterDiscard && !G.encounterDiscard.includes(self)) G.encounterDiscard.push(self);
    MC.log(G, '의무 카드 버림');
  }
  if (pl && self) pl.obligationsOut = (pl.obligationsOut || []).filter(u => u !== self.uid);
};

/* ── 페르소나(Persona) 지원 처리 — 미즈마블 네메시스 공통. persona 트레잇 support가 대상. ── */
// 전장 인플레이 페르소나 지원 목록 (모든 플레이어)
function personaSupports(G){
  const out = [];
  for (const pl of G.players)
    for (const s of (pl.playArea.supports || [])){
      const d = MC.cardDef(s.defCode);
      if (d && (d.traits || []).includes('persona')) out.push({ owner: pl, card: s });
    }
  return out;
}
// 페르소나 지원 1장 버림 (home-by-dawn). 버렸으면 ctx._discardedUpgrade=true (resolveObligation surgeIfNoDiscard 재사용).
EFFECTS.discardPersonaSupport = function(G, p, ctx){
  const list = personaSupports(G);
  if (!list.length){ ctx._discardedUpgrade = false; MC.log(G, '버릴 페르소나 지원 없음'); return; }
  const { owner, card } = list[0];
  const arr = owner.playArea.supports;
  const i = arr.indexOf(card); if (i >= 0) arr.splice(i, 1);
  MC.moveToDiscard(G, owner, card, {});
  ctx._discardedUpgrade = true;
  MC.log(G, MC.nameOf(card) + ' — 페르소나 지원 버림 (Home by Dawn)');
};
// 전장의 (동료 + 페르소나 지원) 수만큼 각 플레이어 덱 상단 버림 (generation-why).
EFFECTS.millPerAllyAndPersona = function(G, p, ctx){
  let n = 0;
  for (const pl of G.players){
    n += (pl.playArea.allies || []).length;
    for (const s of (pl.playArea.supports || [])){
      const d = MC.cardDef(s.defCode);
      if (d && (d.traits || []).includes('persona')) n++;
    }
  }
  if (n <= 0){ MC.log(G, '동료·페르소나 없음 — 버릴 카드 없음'); return; }
  for (const pl of G.players){
    for (let i = 0; i < n && pl.deck.length; i++){
      const c = pl.deck.shift();
      MC.moveToDiscard(G, pl, c, {});
    }
    MC.log(G, MC.nameOf(pl) + ' — 덱 상단 ' + n + '장 버림 (Generation Why?)');
  }
};
// 각 페르소나 지원 소진 → 소진 수만큼 빌런 회복. 0장이면 surge (harvest).
EFFECTS.exhaustPersonaHealVillain = function(G, p, ctx){
  const list = personaSupports(G);
  let n = 0;
  for (const { card } of list){ if (!card.exhausted){ card.exhausted = true; n++; } }
  if (n > 0){
    MC.healTarget(G, G.villain, n);
    MC.log(G, '페르소나 지원 ' + n + '개 소진 → 빌런 ' + n + ' 회복 (Harvest)');
  } else {
    G.pendingSurge = (G.pendingSurge || 0) + 1;
    MC.log(G, '소진할 페르소나 지원 없음 → 급증(Surge)');
  }
};

// 교전 중인(또는 활성) 플레이어에게 조우 카드 N장 지급 — 하이드라 솔저 처치 시 등.
EFFECTS.dealEncounterToEngaged = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const n = p.count || 1;
  if (MC.dealEncounterTo) MC.dealEncounterTo(G, pl, n);
  MC.log(G, pl.uid + '에게 조우 카드 ' + n + '장 지급 (하이드라 솔저 처치)');
}

/* 각 플레이어에게 조우 카드 N장씩 배분 — 태스크마스터 II/III When Revealed "deal each player an encounter card". 범용. */
EFFECTS.dealEncounterEachPlayer = function(G, p, ctx){
  const n = p.count || 1;
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    if (MC.dealEncounterTo) MC.dealEncounterTo(G, pl, n);
  }
  MC.log(G, '각 플레이어에게 조우 카드 ' + n + '장씩 배분');
};

/* 각 플레이어가 조우덱/버린더미에서 특정 특성(trait) 또는 코드(code)의 하수인 1명을 찾아 교전 배치.
   그 후 조우덱 셔플 — 하이드라 순찰대(04154) 처치 시 각 플레이어 하이드라 하수인 소환. 범용. */
EFFECTS.searchMinionEachPlayer = function(G, p, ctx){
  let any = false;
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    const m = MC.searchMinionIntoPlay(G, pl, p.trait || null, p.code || null);
    if (m) any = true;
  }
  if (any && MC.shuffle) MC.shuffle(G, G.encounterDeck);
  MC.log(G, '각 플레이어 ' + (p.trait || p.code || '') + ' 하수인 소환 — 조우덱 셔플');
};;

// 특정 named 하수인이 전장에 없으면 조우덱/버림 탐색(없으면 정의로 생성)해 활성 플레이어와 교전 배치 — Legions of Hydra(01180) 등.
EFFECTS.summonNamedMinionIfAbsent = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const code = p.code;
  const present = G.players.some(x => (x.engagedMinions || []).some(m => (m.defCode || m.code) === code && m.hp > 0));
  if (present){ MC.log(G, code + ' 이미 전장에 있음 — 소환 생략'); return; }
  if (MC.searchMinionIntoPlay) MC.searchMinionIntoPlay(G, pl, null, code);
}

// ★ 각 플레이어가 조우덱/버림에서 특정 트레잇 하수인 1명을 탐색해 자신과 교전 배치 (범용).
//   Hydra Patrol(04154) 처치 시 각 플레이어가 Hydra 하수인 소환. p:{ trait?, code? }.
EFFECTS.searchMinionEachPlayer = function(G, p, ctx){
  for (const pl of MC.playersInOrder(G).filter(x => !x.eliminated)){
    if (MC.searchMinionIntoPlay) MC.searchMinionIntoPlay(G, pl, p.trait || null, p.code || null);
  }
  MC.log(G, '각 플레이어 ' + (p.trait || '') + ' 하수인 탐색 소환');
};;

// 전장의 특정 트레잇 적 수 × 배수만큼 이 사이드 스킴(ctx.self)에 위협 — Legions of Hydra: 히드라 적 수 ×2.
EFFECTS.placeThreatPerEnemyTrait = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const trait = (p.trait || '').toLowerCase();
  const mult = p.mult || 1;
  let count = 0;
  if (G.villain && ((MC.cardDef(G.villain.defCode).traits) || []).map(t => t.toLowerCase()).includes(trait)) count++;
  for (const pl of G.players){
    for (const m of (pl.engagedMinions || [])){
      if (m.hp > 0 && ((MC.cardDef(m.defCode).traits) || []).map(t => t.toLowerCase()).includes(trait)) count++;
    }
  }
  const amount = count * mult;
  if (self && amount > 0){ MC.placeThreat(G, self.uid, amount); MC.log(G, trait + ' 적 ' + count + '명 × ' + mult + ' → 위협 +' + amount); }
  else MC.log(G, trait + ' 적 없음 — 추가 위협 없음');
};

// 활성 플레이어 손패에서 자원 아이콘을 가진 카드를 모두 버림 — 욘-로그의 반역(01179).
// 마챔 규칙: 거의 모든 플레이어 카드가 자원 아이콘을 가지므로 사실상 손패 대부분을 버림.
// 버린 카드 수를 ctx._treasonDiscarded에 기록(0이면 호출부에서 surge).
EFFECTS.discardAllResourcesFromHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const keep = [], discarded = [];
  for (const card of (pl.hand || [])){
    const d = MC.cardDef(card.defCode) || {};
    const res = d.resources || {};
    const hasResource = ['physical', 'mental', 'energy', 'wild'].some(t => (res[t] || 0) > 0);
    if (hasResource) discarded.push(card); else keep.push(card);
  }
  pl.hand = keep;
  for (const c of discarded) (pl.discard = pl.discard || []).push(c);
  ctx._treasonDiscarded = discarded.length;
  G._treasonDiscarded = discarded.length;
  MC.log(G, pl.uid + ' 손패 자원 카드 ' + discarded.length + '장 버림 (욘-로그의 반역)');
};

// 각 플레이어 덱 top N장 버림 → 버린 카드의 인쇄 에너지(⚡) 자원 총량만큼 그 플레이어 피해 — 전자기 반발(01174).
EFFECTS.discardTopEnergyDamage = function(G, p, ctx){
  const n = p.count || 5;
  for (const pl of G.players){
    let energy = 0, cnt = 0;
    for (let i = 0; i < n && pl.deck.length; i++){
      const card = pl.deck.pop();
      (pl.discard = pl.discard || []).push(card);
      const d = MC.cardDef(card.defCode) || {};
      energy += ((d.resources || {}).energy || 0);
      cnt++;
    }
    MC.log(G, pl.uid + ' 덱 top ' + cnt + '장 버림 — 에너지 자원 ' + energy);
    if (energy > 0) MC.applyDamage(G, pl, energy, {});
  }
};

// 각 플레이어 손패 무작위 1장 버림 → 버린 카드들의 서로 다른 자원 종류 수만큼 메인 스킴 위협 — 벌처의 계략(01169).
EFFECTS.discardRandomCountResources = function(G, p, ctx){
  const types = new Set();
  for (const pl of G.players){
    if (!pl.hand || !pl.hand.length) continue;
    const idx = Math.floor(MC.rand(G) * pl.hand.length);
    const [card] = pl.hand.splice(idx, 1);
    (pl.discard = pl.discard || []).push(card);
    const d = MC.cardDef(card.defCode) || {};
    const res = d.resources || {};
    for (const t of ['physical', 'mental', 'energy', 'wild']) if (res[t] > 0) types.add(t);
    MC.log(G, pl.uid + ' 손패 1장(' + MC.nameOf(card) + ') 무작위 버림');
  }
  const X = types.size;
  G._vulturePlansX = X;
  if (X > 0) MC.placeThreat(G, 'main', X);
  MC.log(G, '서로 다른 자원 ' + X + '종 → 메인 스킴 위협 +' + X);
};

// 이 활성화가 우호 캐릭터에 피해를 주면 그 캐릭터를 기절 — 급강하 습격(01168) 부스트★. 플래그로 표시.
EFFECTS.setBoostStunOnDamage = function(G, p, ctx){
  G._boostStunOnDamage = true;
  MC.log(G, '급강하 습격 부스트★ — 이 활성화 피해 대상 기절 예약');
};

// 각 플레이어 손패 무작위 1장을 이 사이드 스킴(ctx.self)에 뒷면 보관 — 노상 강도(01166). 소유자 기록.
EFFECTS.storeRandomFromEachHand = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  if (!self) return;
  self.storedCards = self.storedCards || [];
  for (const pl of G.players){
    if (!pl.hand || !pl.hand.length) continue;
    const idx = Math.floor(MC.rand(G) * pl.hand.length);
    const [card] = pl.hand.splice(idx, 1);
    card._storedOwner = pl.uid;
    self.storedCards.push(card);
    MC.log(G, pl.uid + ' 손패 1장(' + MC.nameOf(card) + ') → ' + MC.nameOf(self) + '에 보관');
  }
};

// 보관된 카드를 각 소유자 손으로 반환 — 노상 강도 처치 시.
EFFECTS.returnStoredCards = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const stored = (self && self.storedCards) || [];
  for (const card of stored){
    const pl = G.players.find(x => x.uid === card._storedOwner);
    if (pl){ pl.hand.push(card); MC.log(G, MC.nameOf(card) + ' → ' + pl.uid + ' 손으로 반환'); }
  }
  if (self) self.storedCards = [];
};

// 타이타니아의 분노(01164): 전장의 타이타니아가 활성 플레이어 히어로를 공격(동적 ATK).
//   타이타니아가 없거나 공격 불가(기절)면 → (있으면)완전 회복 + 이 카드 surge.
EFFECTS.titaniaFury = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const self = ctx.self || ctx.card;
  let titania = null;
  for (const p2 of G.players){
    const m = (p2.engagedMinions || []).find(x => (x.defCode || x.code) === 'titania' && x.hp > 0);
    if (m){ titania = m; break; }
  }
  const canAttack = titania && !(titania.status && titania.status.stunned > 0);
  if (canAttack){
    const atk = MC.enemyAtk(G, titania);
    MC.applyDamage(G, pl, atk, { source: titania });
    MC.log(G, '타이타니아가 히어로를 공격 (' + atk + ' 피해)');
  } else {
    if (titania){
      titania.hp = MC.cardDef('titania').hp + (titania.maxHp ? (titania.maxHp - MC.cardDef('titania').hp) : 0);
      titania.hp = titania.maxHp || MC.cardDef('titania').hp;
      MC.log(G, '타이타니아 완전 회복');
    }
    if (self) self.surge = true;
    MC.log(G, '타이타니아 공격 불가 — 급증(Surge)');
  }
};

// 빌런 활성화에 부스트 카드 1장 추가(플래그 G._extraBoostThisActivation). 타이타니아의 분노 부스트★ 등.
EFFECTS.addVillainBoostCard = function(G, p, ctx){
  G._extraBoostThisActivation = (G._extraBoostThisActivation || 0) + (p.amount || 1);
  MC.log(G, '빌런 활성화 부스트 카드 +' + (p.amount || 1));
};

// 인쇄 HP가 가장 높은 하수인에 부착물(ctx.self) 부착 — 유전자 강화(01163). 하수인 없으면 surge.
// attachTo가 def.attachStats({hp,maxHp})를 자동 적용.
EFFECTS.attachToHighestHpMinion = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const selfCode = self && self.defCode;
  let minions = [];
  for (const pl of G.players) minions.push(...(pl.engagedMinions || []));
  // excludeSameAttachment: 이미 같은 종류의 부착물이 붙은 하수인은 제외 (Biomechanical Upgrades 중복 불가).
  if (p.excludeSameAttachment && selfCode){
    minions = minions.filter(m => !(m.attachments || []).some(a => a.defCode === selfCode));
  }
  if (!minions.length){
    if (p.surgeIfNone && self) self.surge = true;
    MC.log(G, '부착 가능한 하수인 없음 — 부착 불발, 급증(Surge)');
    return;
  }
  let best = minions[0], bestHp = (MC.cardDef(best.defCode).hp || 0);
  for (const m of minions){
    const h = MC.cardDef(m.defCode).hp || 0;
    if (h > bestHp){ best = m; bestHp = h; }
  }
  if (self) MC.attachTo(G, self, best);
};

// 메인 스킴 가속 토큰 부여(전역 G.acceleration 누적) — 법률 업무(01160) 등. 빌런 페이즈 위협 상승률 증가.
EFFECTS.addAcceleration = function(G, p, ctx){
  G.acceleration += (p.amount || 1);
  MC.log(G, '가속 토큰 +' + (p.amount || 1) + ' (누적 ' + G.acceleration + ')');
};

// 조우덱 top 1장 버림 + X 계산(부스트 아이콘 수 + p.plus). G._ritualX에 저장 → 이후 amountFrom:'ritualX'로 참조.
// 의식 결투(01159): X = 버린 조우 카드의 부스트 아이콘 + 1.
EFFECTS.discardEncounterComputeX = function(G, p, ctx){
  let boostN = 0;
  if (G.encounterDeck && G.encounterDeck.length){
    const card = G.encounterDeck.shift();
    const d = MC.cardDef(card.defCode || card.code);
    boostN = (d && typeof d.boost === 'number') ? d.boost : 0;
    (G.encounterDiscard = G.encounterDiscard || []).push(card);
    MC.log(G, '조우덱 top 버림 (' + MC.nameOf(card) + ') — 부스트 아이콘 ' + boostN);
  }
  G._ritualX = boostN + (p.plus || 1);
  MC.log(G, '의식 결투 X = ' + G._ritualX);
};

// 적에게 강인함(Tough) 상태 카드 부여 — p.scope:'villain'(빌런만) / 'villainAndEngaged'(빌런+활성 플레이어 교전 하수인).
// 빌런 강화 배신(심장 모양 허브 01158 등)에 사용.
EFFECTS.grantTough = function(G, p, ctx){
  const targets = [];
  if (G.villain && G.villain.hp > 0) targets.push(G.villain);
  if (p.scope === 'villainAndEngaged'){
    const pl = ctx.player || G.players[G.firstPlayer];
    targets.push(...(pl.engagedMinions || []));
  }
  for (const t of targets){ MC.setStatus(G, t, 'tough', true); MC.log(G, MC.nameOf(t) + ' — 강인함(Tough) 부여'); }
};

// 적 1명 선택 → then 효과 실행 (target:'chosen'으로 전달). 범용 인덱스:
//   "적 선택 후 기절/혼란/피해/조준…" 카드에 재사용. scope로 후보 제한(기본: 빌런+교전 하수인).
//   후보가 1명이면 자동 대상 처리, 없으면 무효. p.then은 순수 데이터 effects 배열.
EFFECTS.chooseEnemy = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const enemies = [];
  if (G.villain && G.villain.hp > 0 && p.scope !== 'minion') enemies.push(G.villain);
  if (p.scope !== 'villain'){
    for (const q of G.players) for (const m of q.engagedMinions) if (m.hp > 0) enemies.push(m);
  }
  if (!enemies.length){ MC.log(G, (p.prompt || '대상 적') + ' — 대상 적 없음'); return; }
  if (enemies.length === 1){                                  // 후보 하나면 자동
    MC.runEffectList(G, p.then || [], { player: pl, targets: [enemies[0]] });
    return;
  }
  G.pending = { kind: 'chooseEnemy', player: pl.uid,
                enemyUids: enemies.map(e => e.uid),
                then: p.then || [], prompt: p.prompt || '대상 적을 선택하세요' };
  MC.log(G, (p.prompt || '대상 적 선택') + ' — 선택 대기');
};

/* 덱 위 N장을 보고 K장을 손에 넣고 나머지는 버린다 — 범용 카드 선택(cardPick) pending.
   미래학자(Futurist)·Agatha·헤임달류 "look at top N, choose" 카드에 재사용.
   params: { count:3, keep:1, prompt, disposition:'discard'|'bottom' } (기본 나머지는 버림).
   후보가 keep 이하면 자동으로 전부 손에 넣고 끝(선택 불필요). */
// 조우덱 상위 count장을 보고 discard장 버림, 나머지 되돌림 (하임달 06020 예지).
// pending:encounterScry → UI에서 버릴 카드 선택. 나머지는 원래 위 순서 유지로 되돌림.
EFFECTS.scryEncounter = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const count = p.count || 3, discard = p.discard || 1;
  const revealed = [];
  for (let i = 0; i < count && G.encounterDeck.length; i++) revealed.push(G.encounterDeck.pop());   // 덱 위=끝(pop)
  if (!revealed.length){ MC.log(G, '조우덱이 비어있음 — 예지 대상 없음'); return; }
  if (revealed.length <= discard){   // 후보가 버릴 수 이하 → 전부 버림 (선택 불필요)
    for (const c of revealed) G.encounterDiscard.push(c);
    MC.log(G, MC.nameOf(pl) + ' — 조우덱 ' + revealed.length + '장 전부 버림 (예지)');
    return;
  }
  G.pending = { kind:'encounterScry', player: pl.uid,
                _cards: revealed, cardUids: revealed.map(c => c.uid),
                discard, chosen: [],
                prompt: p.prompt || ('조우덱 상위 ' + revealed.length + '장 — ' + discard + '장 버림') };
  MC.log(G, MC.nameOf(pl) + ' — 조우덱 상위 ' + revealed.length + '장 확인 (예지, ' + discard + '장 버림 선택)');
};

EFFECTS.lookAtTopChoose = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const count = p.count || 3, keep = p.keep || 1;
  const revealed = [];                                  // 덱 위(=끝, pop방향)에서 실제로 뽑아 pending에 보관
  for (let i = 0; i < count && pl.deck.length; i++) revealed.push(pl.deck.pop());
  if (!revealed.length){ MC.log(G, (p.prompt||'카드 선택') + ' — 덱이 비어 대상 없음'); return; }
  if (revealed.length <= keep){                         // 후보가 keep 이하 → 자동 전부 손
    for (const c of revealed) pl.hand.push(c);
    MC.log(G, MC.nameOf(pl) + ' — 덱 위 ' + revealed.length + '장 자동 손에 (선택 불필요)');
    return;
  }
  G.pending = { kind:'cardPick', player: pl.uid,
                cardUids: revealed.map(c => c.uid),
                _cards: revealed,                       // pending 내부 보관(덱에서 이미 분리)
                keep, chosen: [],
                disposition: p.disposition || 'discard',
                prompt: p.prompt || ('카드 ' + keep + '장 선택 (나머지는 버림)') };
  MC.log(G, MC.nameOf(pl) + ' — 덱 위 ' + revealed.length + '장 확인, ' + keep + '장 선택 대기');
};

/* ── 조우/능력 확장 효과 (Phase 3) ── */

// 급증: 이 카드 공개 후 조우 1장 추가 공개. inst에 surge 플래그 세워 기존 배선 재사용.
/* 로그만 출력 (ranged 등 표시용 — 방어 시스템 미배선 키워드 안내). */
EFFECTS.logOnly = function(G, p, ctx){ MC.log(G, p.text || ''); };

/* 실험 무기 덱(Experimental Weapons) top 1장 공개 → 빌런에 부착 (resolveEncounterCard).
   크로스본즈 III / 메인 스킴 2B·3B 공개 시. UI 연출용 G.fxWeaponReveal 힌트 설정. */
EFFECTS.revealExperimentalWeapon = function(G, p, ctx){
  if (!G.experimentalWeaponsDeck || !G.experimentalWeaponsDeck.length){
    MC.log(G, '실험 무기 덱이 비어 공개할 무기 없음');
    return;
  }
  const weapon = G.experimentalWeaponsDeck.shift();
  MC.log(G, '실험 무기 덱 공개 — ' + MC.nameOf(weapon) + '!');
  G.fxWeaponReveal = { defCode: weapon.defCode, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  if (MC.resolveEncounterCard) MC.resolveEncounterCard(G, weapon, ctx.player || G.players[G.firstPlayer]);
};

EFFECTS.surge = function(G, p, ctx){
  if (ctx.self) ctx.self.surge = true;
};

// 빌런 HP 회복 (없으면 급증 등 대체효과는 cond:{type:'healedNone'}로 데이터 분기).
// 실제 회복량을 G._lastHealDone에 기록 → 다음 step에서 healedNone 조건 검사.
// perEngagedDrone: 활성 플레이어와 교전 중인 Drone 하수인 1명당 회복량 (수리 시퀀스 01146).
EFFECTS.healVillain = function(G, p, ctx){
  let amount = p.amount || 0;
  if (p.stageX2) amount = 2 * ((MC.cardDef(G.villain.defCode) || {}).stage || 1);   // Regenerative Healing: 2×스테이지
  if (p.amountFrom === 'boostDiscarded') amount = G._lastBoostDiscarded || 0;         // Shock Therapy: 버린 부스트당 1
  if (p.perEngagedDrone){
    const pl = ctx.player || G.players[G.firstPlayer];
    const drones = pl.engagedMinions.filter(m => m.isDrone || (m.traits||[]).includes('drone')).length;
    amount = p.perEngagedDrone * drones;
    MC.log(G, '교전 드론 ' + drones + '명 × ' + p.perEngagedDrone + ' = 회복 ' + amount);
  }
  G._lastHealDone = MC.healTarget(G, G.villain, amount);
};

// 각 히어로에게 피해 (allPlayers 대상, 신분/조우 카드). 피격 대상 힌트를 남겨 UI가 이펙트 재생.
EFFECTS.damageEachHero = function(G, p, ctx){
  const hit = [];
  let players = MC.resolvePlayers(G, 'all', ctx);
  if (p.heroForm) players = players.filter(pl => pl.form === 'hero');   // 히어로 폼 한정(그린 고블린 I WR)
  let amount = p.amount;
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  for (const pl of players){
    MC.applyDamage(G, pl, amount, { source: ctx.card || ctx.self, indirect: !!p.indirect });
    hit.push(pl.uid);
  }
  // VFX 힌트: 어떤 카드(source)가 각 히어로에게 얼마의 피해를 줬는지 → UI가 대상 위에 이펙트.
  const src = ctx.card || ctx.self;
  G.fxDamageEachHero = { defCode: src && src.defCode, amount: p.amount,
    targetUids: hit, indirect: !!p.indirect, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
};

// 각 히어로에 상태 부여 (혼란/기절)
EFFECTS.statusEachHero = function(G, p, ctx){
  for (const pl of MC.resolvePlayers(G, 'all', ctx)) MC.setStatus(G, pl, p.status, true);
};

// 대상(빌런/부착된 적 등)에 강인함
EFFECTS.toughEnemy = function(G, p, ctx){
  const t = p.target === 'villain' ? G.villain : (ctx.self && ctx.self.attachedTo ? MC.findByUid(G, ctx.self.attachedTo) : G.villain);
  MC.setStatus(G, t, 'tough', true);
};

// 빌런이 활성 플레이어를 공격 — 방어 선언 pending 생성 (기존 방어 머신 재사용).
// 주의: pending을 세우므로 이 효과 뒤 스텝은 resolveDefense 후 재개돼야 함(핸들러에서 단독 사용).
EFFECTS.villainAttacks = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let bonus = p.bonus || 0;
  if (p.bonusFrom === 'villainStage') bonus += (MC.cardDef(G.villain.defCode) || {}).stage || 0;
  if (p.bonusIfTrait && MC.villainTraitsOf(G).includes(String(p.bonusIfTrait.trait).toLowerCase())) bonus += (p.bonusIfTrait.bonus || 1);
  const amt = MC.enemyAtk(G, G.villain) + bonus;
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: amt,
                stunOnHit: !!p.stunOnHit, threatOnDamage: p.threatOnDamage || 0,
                surgeIfDamageGTE: p.surgeIfDamageGTE || 0,
                discardDeckPerDamage: !!p.discardDeckPerDamage };
  // withBoost: 이 공격에 부스트 카드 1장 부여. noBoostIfAlterEgo면 알터에고 폼일 때 생략 (I See You).
  if (p.withBoost && !(p.noBoostIfAlterEgo && pl.form === 'alter-ego')){
    const bc = MC.drawEncounterCard(G);
    if (bc) G.pending.boostCard = bc;
  }
  MC.log(G, MC.nameOf(G.villain) + ' → ' + pl.uid + ' 공격 (피해 ' + amt + ') — 방어 선언 대기');
};

// 빌런 암약(스킴) — 메인 스킴에 빌런 SCH만큼 위협 배치. 조우 카드가 "빌런이 암약한다"를 유발할 때.
// villainAttacks의 짝. p: { scheme:'main', bonus:0 }. 놓은 위협량을 G._lastThreatPlaced에 기록
// → discardTopDeck amountFrom:'lastThreatPlaced'로 연계 (울트론의 분노 알터에고 분기).
EFFECTS.villainSchemes = function(G, p, ctx){
  let bonus = p.bonus || 0;
  if (p.bonusFrom === 'villainStage') bonus += (MC.cardDef(G.villain.defCode) || {}).stage || 0;
  if (p.bonusIfTrait && MC.villainTraitsOf(G).includes(String(p.bonusIfTrait.trait).toLowerCase())) bonus += (p.bonusIfTrait.bonus || 1);
  const amt = (G.villain.scheme || 0) + bonus;
  G._lastThreatPlaced = 0;
  if (amt <= 0){ MC.log(G, MC.nameOf(G.villain) + ' 암약 — 위협 0 (SCH 0)'); return; }
  MC.placeThreat(G, p.scheme || 'main', amt);
  G._lastThreatPlaced = amt;
  MC.log(G, MC.nameOf(G.villain) + ' 암약 — ' + (p.scheme || 'main') + ' 위협 +' + amt);
};

// 덱 맨 위 N장 버림(범용) — p:{ amount 또는 amountFrom:'lastThreatPlaced'|'lastDamageDealt',
//   scope?:'activePlayer'(기본)|'eachPlayer' }. "각 플레이어 덱 맨 위 3장 버림"(침습 AI 01149) 등.
EFFECTS.discardTopDeck = function(G, p, ctx){
  let n = p.amount || 0;
  if (p.amountFrom === 'lastThreatPlaced') n = G._lastThreatPlaced || 0;
  else if (p.amountFrom === 'lastDamageDealt') n = G._lastDamageDealt || 0;
  if (n <= 0){ MC.log(G, '(덱 버림 0장 — 조건값 없음)'); return; }
  const players = p.scope === 'eachPlayer'
    ? MC.playersInOrder(G).filter(pl => !pl.eliminated)
    : [ctx.player || G.players[G.firstPlayer]];
  // checkTrait: 이렇게 버린 카드 중 지정 특성(파워 아이콘 근사: traits의 thwart/attack)을 가진 카드가 있으면 ctx._discardHadTrait 기록 (모방 04105 등 조건 분기용).
  let hadTrait = false;
  for (const pl of players){
    const before = pl.discard.length;
    MC.discardTopOfDeck(G, pl, n);
    if (p.checkTrait){
      const newly = pl.discard.slice(before);
      if (newly.some(c => { const cd = MC.cardDef(c.defCode || c.code); return cd && (cd.traits || []).includes(p.checkTrait); })) hadTrait = true;
    }
  }
  if (p.checkTrait && ctx){ ctx._discardHadTrait = hadTrait; MC.log(G, '버린 카드 중 ' + p.checkTrait + ' 아이콘 ' + (hadTrait ? '있음' : '없음')); }
};

// 하수인 탐색 배치(범용) — 조우덱에서 (특성 일치) 하수인이 나올 때까지 버림 → 첫 플레이어와 교전 배치.
// "The Masters of Evil"(01128) 등 "Discard cards from the encounter deck until a [[X]] minion is discarded.
// Put that minion into play engaged with the first player." 유형을 데이터로. p: { trait?, who? }
// who:'you' → 카드 플레이어(ctx.player)와 교전 (아홉 왕국의 수호자 06003). 기본 → 첫 플레이어(조우 카드).
// (엔진 헬퍼 MC.discardUntilMinionIntoPlay 재사용 — 하수인 부재 시 안전 불발 처리 포함)
// 하수인 배치 성공 여부를 ctx._minionPlaced에 남김 → 후속 효과(위협 제거 등)의 cond:minionPlaced 조건용.
EFFECTS.discardUntilMinion = function(G, p, ctx){
  const pl = (p.who === 'you' && ctx && ctx.player) ? ctx.player : G.players[G.firstPlayer];
  const minion = MC.discardUntilMinionIntoPlay(G, pl, p.trait || null);
  if (ctx) ctx._minionPlaced = !!minion;
};

// 뒷면 드론 스폰(범용) — p:{ scope:'eachPlayer'|'activePlayer'|'firstPlayer', count?:1, fallback? }.
// "각 플레이어(또는 당신/첫 플레이어)가 덱 맨 위 카드를 뒷면 Drone 하수인으로 전장에 놓는다"
// (안드로이드 효율 01144 eachPlayer, 울트론의 명령 01150 firstPlayer×2 등).
// 드론 스탯은 울트론 드론 환경(droneStats)이 있으면 그 값, 없으면 fallback. 스폰 수를 G._lastDroneSpawns에 기록.
EFFECTS.spawnDrone = function(G, p, ctx){
  const fb = p.fallback || { attack:1, scheme:1, hp:1 };
  const count = p.count || 1;
  let n = 0;
  if (p.scope === 'activePlayer' || p.scope === 'firstPlayer'){
    const pl = p.scope === 'firstPlayer'
      ? G.players[G.firstPlayer]
      : ((ctx && ctx.player) || G.players[G.firstPlayer]);
    for (let i = 0; i < count; i++){ if (MC.spawnFacedownDrone(G, pl, fb)) n++; }
  } else {   // eachPlayer (기본)
    for (const pl of MC.playersInOrder(G)){
      if (pl.eliminated) continue;
      for (let i = 0; i < count; i++){ if (MC.spawnFacedownDrone(G, pl, fb)) n++; }
    }
  }
  G._lastDroneSpawns = n;
};

// 하수인 일제 공격(범용) — "각 X 하수인이 교전 중인 히어로를 공격한다. 이 방식으로 공격이
// 없었다면 → (fallback)" (혼돈의 지배 01133, 군집 공격 01147, 하일 히드라 03030 유형).
// p: { trait?, scope?:'allPlayers'|'activePlayer', fallback?:'searchEngage'|'spawnDrone', droneFallback? }.
//   scope 기본 allPlayers(혼돈: 모든 플레이어의 X 하수인) / activePlayer(군집: 공개한 플레이어만).
//   fallback: searchEngage(조우덱+버림 하수인 탐색) / spawnDrone(덱 맨 위 뒷면 드론 스폰).
// 공격 개시 수를 G._lastMinionAttacks에 기록 → cond:{type:'minionsAttacked'}(및 negate)로 분기 연출/대사.
EFFECTS.minionsAttack = function(G, p, ctx){
  const pairs = [];
  const players = p.scope === 'activePlayer'
    ? [(ctx && ctx.player) || G.players[G.firstPlayer]]
    : MC.playersInOrder(G);
  const attackedPlayers = new Set();
  for (const pl of players){
    if (!pl || pl.eliminated) continue;
    for (const m of pl.engagedMinions){
      if (p.trait && !(m.traits || []).includes(p.trait)) continue;
      if (m.hp <= 0) continue;
      pairs.push({ attackerUid: m.uid, playerUid: pl.uid });
      attackedPlayers.add(pl.uid);
    }
  }
  // 헤일 하이드라: 이번에 (해당 특성 하수인에게) 공격받지 않은 각 플레이어는 조우덱/버림에서 그 특성 하수인 탐색→교전 배치.
  //   공격 전에 배치해도 새 하수인은 pairs에 없어 이번 공격엔 미참여 (공식 순서와 결과 동일).
  if (p.reinforceUnattacked){
    for (const pl of players){
      if (!pl || pl.eliminated || attackedPlayers.has(pl.uid)) continue;
      MC.searchMinionIntoPlay(G, pl, p.trait || null);
    }
  }
  const started = pairs.length ? MC.startMinionAttackChain(G, pairs) : false;
  G._lastMinionAttacks = started ? 1 : 0;
  if (!started && !p.reinforceUnattacked){
    const pl = (ctx && ctx.player) || G.players[G.firstPlayer];
    if (p.fallback === 'searchEngage'){
      MC.log(G, '공격한 ' + (p.trait || '') + ' 하수인 없음 — 조우덱/버림에서 증원 탐색');
      MC.searchMinionIntoPlay(G, pl, p.trait || null);
    } else if (p.fallback === 'spawnDrone'){
      MC.log(G, '공격한 Drone 없음 — 덱 맨 위 카드를 뒷면 드론으로 증원');
      MC.spawnFacedownDrone(G, pl, p.droneFallback || { attack:1, scheme:1, hp:1 });
    }
  }
};

// 각 플레이어 선택(범용) — p:{ prompt, options:[{key,label,effects,payIcons?}] }.
// "각 플레이어가 A 또는 B를 선택한다"(공격 받는 중 01151 등). 각 플레이어 순차 선택 pending 체인.
// ctx.self가 이 카드(사이드 스킴 등)면 selfUid로 전달 → 옵션 effects의 scheme:'self'가 이 카드 참조.
EFFECTS.eachPlayerChoice = function(G, p, ctx){
  const queue = MC.playersInOrder(G).filter(pl => !pl.eliminated).map(pl => pl.uid);
  G._pendingEachChoice = { selfUid: ctx.self ? ctx.self.uid : null,
                           prompt: p.prompt, options: p.options || [], queue };
  MC.flushEachChoice(G);
};

// 폼 분기 — 현재 활성 플레이어의 폼(hero/alter)에 따라 다른 effects 배열을 재귀 실행.
// 배신 카드 다수가 "공개 시(히어로)/공개 시(알터에고)" 분기를 가짐 → 커스텀 핸들러 없이 데이터로.
// p: { hero:[...effects], alter:[...effects] }. 해당 폼 브랜치가 없으면 아무것도 안 함.
EFFECTS.formBranch = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const branch = pl.form === 'hero' ? p.hero : p.alter;
  if (branch && branch.length) runEffectList(G, branch, ctx);
};

// 연출 힌트 세팅(범용) — effects 배열 안에서 카드별 전용 연출/대사를 데이터로 지정.
// p: { vfx, quoteKey, quoteKind, target:'villain'|'self' }. UI가 G.fxCardEffect를 읽어 재생.
EFFECTS.playVfx = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const quote = (p.quoteKey && MC.randomQuote) ? MC.randomQuote(p.quoteKey, p.quoteKind || 'attack') : null;
  G.fxCardEffect = { vfx: p.vfx, quote, target: p.target || 'villain',
                     player: pl.uid, cardCode: ctx.card ? ctx.card.defCode : (ctx.self && ctx.self.defCode),
                     seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
};

// 조건부 피해: 지불 아이콘(paidIcons)에 특정 타입이 있으면 피해 (와일드도 충족)
EFFECTS.dealDamageIfPaid = function(G, p, ctx){
  const need = p.resource; // 'physical' 등
  const have = (ctx.paidIcons && ((ctx.paidIcons[need]||0) + (ctx.paidIcons.wild||0))) || 0;
  if (have <= 0) return;
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt) MC.applyDamage(G, t, p.amount, { source: ctx.card });
};

// 덱 위 N장을 버리되, 조건(인쇄 자원 등) 맞는 카드는 손으로 회수.
// p: { amount, keepResource:'mental' } — self 플레이어 대상
EFFECTS.millAndGrab = function(G, p, ctx){
  const pl = ctx.player || ctx.self;
  const n = p.amount || 0;
  for (let i = 0; i < n; i++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); break; }   // RRG: 밀 중 소진→리셔플+조우카드 후 새 덱에선 안 밀음
    const card = pl.deck.pop();
    const def = MC.cardDef(card.defCode);
    const printed = def && def.resources ? (def.resources[p.keepResource] || 0) : 0;
    if (p.keepResource && printed > 0){
      pl.hand.push(card);
      MC.log(G, MC.nameOf(card) + ' 손에 추가 (인쇄 ' + p.keepResource + ')');
    } else {
      MC.moveToDiscard(G, pl, card, {});
      MC.log(G, MC.nameOf(card) + ' 버림');
    }
  }
};

// 전체 피해 방지 (방어 인터럽트 이벤트 — Backflip 등):
// 현재 방어 pending을 피해 0으로 해소하고 빌런 큐 재개.
EFFECTS.preventAll = function(G, p, ctx){
  const pend = G.pending;
  if (!pend || pend.kind !== 'defense'){
    // pending 없이 플레이된 경우(방어 대상 아님) — 조용히 무효
    MC.log(G, '(방어할 공격 없음 — 피해 방지 효과 없음)');
    return;
  }
  MC.log(G, MC.nameOf(ctx.card) + ' — 공격의 모든 피해 방지');
  // 뒷면 부스트 카드가 있으면 공개(무효) 후 버림 (카드 유실 방지)
  if (pend.boostCard){
    MC.log(G, '부스트 카드 공개(무효): ' + (pend.boostCard.name || '?'));
    G.encounterDiscard.push(pend.boostCard);
  }
  G.pending = null;
  MC.processVillainQueue(G); // 방어 해소 후 큐 재개
};

/* 부분 피해 방지: 방어 pending의 피해량을 N만큼 감소 (0 이하면 방어 해소).
   우주 비행(3 방지) 등. p.amount = 방지량. */
EFFECTS.preventAmount = function(G, p, ctx){
  const pend = G.pending;
  if (!pend || pend.kind !== 'defense'){
    MC.log(G, '(방어할 공격 없음 — 피해 방지 효과 없음)');
    return;
  }
  // ★ 룰북: 부스트가 뒷면(미공개)이므로 총피해를 알 수 없다 → 방지량을 누적만 하고
  //   방어 해소 시(부스트 공개 후) 총피해에서 차감. 조기 완결하지 않음.
  const prevent = p.amount || 0;
  pend.prevented = (pend.prevented || 0) + prevent;
  MC.log(G, MC.nameOf(ctx.card) + ' — 피해 ' + prevent + ' 방지 예약 (누적 ' + pend.prevented + ')');
};

/* 부스트 카드의 유효 부스트 값 — 기본 boost + 조건부 아이콘.
   boostBonusIfGoblinEngaged(I See You): 대상 플레이어에 고블린 하수인 교전 시 +N. */
MC.boostOf = function(G, card, pl){
  let b = (card && card.boost) || 0;
  const def = card && MC.cardDef(card.defCode);
  if (def && def.boostBonusIfGoblinEngaged && pl){
    const has = (pl.engagedMinions || []).some(m => ((MC.cardDef(m.defCode) || {}).traits || []).includes('goblin'));
    if (has) b += def.boostBonusIfGoblinEngaged;
  }
  return b;
};

/* 특정 사이드 스킴 공개(범용 데이터판) — 조우덱/버림에서 지정 코드 사이드 스킴을 찾아 공개 + 조우덱 셔플.
   (졸라 II 04110 = Test Subjects 공개 등. 엔진 헬퍼 MC.revealSpecificSideScheme 재사용) p:{ code } */
EFFECTS.revealSideScheme = function(G, p, ctx){
  if (p.code && MC.revealSpecificSideScheme) MC.revealSpecificSideScheme(G, p.code);
};

/* 실험(test) 카운터 배치(범용) — 메인 스킴에 test 카운터 N개를 놓는다.
   (졸라 04116 부스트 / 04121 기술적 강화 등). 3개 도달 시 하수인 소환은 빌런 페이즈 처리(mc_5)에서. p:{ amount } */
EFFECTS.placeTestCounter = function(G, p, ctx){
  const n = p.amount || 1;
  if (!G.mainScheme) return;
  G.mainScheme.testCounters = (G.mainScheme.testCounters || 0) + n;
  MC.log(G, '🧪 실험 카운터 +' + n + ' (누적 ' + G.mainScheme.testCounters + ')');
};

/* 졸라의 뮤테이트(04115) 공개 시 — 조우덱 맨 위에서 [[Tech]] 부착물이 나올 때까지 버리고, 그 부착물을 이 하수인에게 부착. */
EFFECTS.attachTechToSelf = function(G, p, ctx){
  const minion = ctx.card || ctx.self || ctx.minion;
  if (!minion || !G.encounterDeck) return;
  let guard = 0;
  while (G.encounterDeck.length && guard++ < 60){
    if (G.encounterDeck.length === 0){ G.encounterDeck = MC.shuffle(G, (G.encounterDiscard || []).splice(0)); if (!G.encounterDeck.length) break; }
    const c = G.encounterDeck.pop();
    const cd = MC.cardDef(c.defCode || c.code);
    if (cd && cd.type === 'attachment' && (cd.traits || []).includes('tech')){
      minion.attachments = minion.attachments || [];
      minion.attachments.push(c);
      try { if (MC.applyAttachStats) MC.applyAttachStats(G, minion, c); } catch (e) {}
      MC.log(G, MC.nameOf(minion) + '에 ' + MC.nameOf(c) + ' 부착 (조우덱에서 Tech 탐색)');
      return;
    }
    (G.encounterDiscard = G.encounterDiscard || []).push(c);
  }
  MC.log(G, '조우덱에 Tech 부착물 없음 — 부착 불발');
};

/* 졸라의 뮤테이트(04115) 부스트 — 이 하수인을 조우 덱에 섞어 넣는다. (부스트 시점: 아직 전장 밖 → 조우덱 셔플만) */
EFFECTS.shuffleSelfIntoEncounter = function(G, p, ctx){
  const minion = ctx.card || ctx.self;
  if (minion && G.players){
    for (const pl of G.players){
      const idx = (pl.engagedMinions || []).indexOf(minion);
      if (idx >= 0){ pl.engagedMinions.splice(idx, 1); (G.encounterDeck = G.encounterDeck || []).push(minion); break; }
    }
  }
  if (MC.shuffle && G.encounterDeck) MC.shuffle(G, G.encounterDeck);
  MC.log(G, '졸라의 뮤테이트 — 조우 덱에 섞임');
};

/* 광폭 뮤테이트(04116) 부스트 — 메인 스킴의 실험 카운터 1개당 졸라가 이 활성화 동안 SCH +1, ATK +1.
   (G._villainActBonus에 기록 → 빌런 활성화 계산 시 참조. 없으면 로그만 남겨 안전.) */
EFFECTS.berserkTestBonus = function(G, p, ctx){
  const tc = (G.mainScheme && G.mainScheme.testCounters) || 0;
  if (tc > 0){
    G._villainActBonus = { attack: tc, scheme: tc, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    MC.log(G, '광폭 뮤테이트 부스트 — 실험 카운터 ' + tc + ' → 졸라 이 활성화 ATK/SCH +' + tc);
  }
};

MC.EFFECTS = EFFECTS;
MC.runEffectList = runEffectList;


/* ◇◇ from mc_3_handlers.js ◇◇ */
/* ═══════════════════════════════════════════════════════════════
   mc_3_handlers.js — 샤드 3/7 : HANDLERS(트리거/지속) + fireHook
   카드 필드 → 훅 매핑:
     whenPlayed / response / interrupt / forcedResponse / forcedInterrupt
     whenRevealed / whenDefeated / whenCompleted / setup
     villainPhaseStart / playerPhaseStart / endOfPhase / endOfRound
   카드에는 { whenRevealed:'핸들러이름' } 처럼 이름만 둔다.
   ═══════════════════════════════════════════════════════════════ */

const HANDLERS = {};

/* fireHook(G, hookName, ctx)
   플레이 중인 모든 카드 인스턴스에서 hookName 필드를 가진 카드를 찾아
   HANDLERS[card[hookName]] 호출. 순서: 선 플레이어부터 시계방향 → 인카운터측. */
function fireHook(G, hookName, ctx){
  const insts = MC.allInPlay(G); // mc_7_core에서 정의 (선 플레이어 순 정렬)
  for (const inst of insts){
    const hname = inst[hookName];
    if (!hname) continue;
    const fn = HANDLERS[hname];
    if (!fn) throw new Error('[fireHook] 미등록 handler: ' + hname + ' (hook=' + hookName + ')');
    fn(G, Object.assign({ self: inst, hook: hookName }, ctx || {}));
  }
}

/* 단일 카드 대상 훅 호출 (whenRevealed/whenPlayed/whenDefeated 등 자기 자신 트리거).
   훅 이름은 인스턴스 우선, 없으면 카드 정의(cardDef)에서 조회 — whenPlayed 등은
   baseFields라 인스턴스로 복사되지 않고 정의에만 존재. */
function fireCardHook(G, inst, hookName, ctx){
  const raw = (inst && inst[hookName]) ||
              (inst && inst.defCode && MC.cardDef(inst.defCode) && MC.cardDef(inst.defCode)[hookName]);
  if (!raw) return false;
  // 데이터(인덱스) 방식: { useCounter?, cond?, effect:[...] } — 카운터 소비 후 효과 실행 (Iron Fist 등).
  if (typeof raw === 'object'){
    if (raw.useCounter){
      if ((inst.counters || 0) < 1){ MC.log(G, MC.nameOf(inst) + ' — 카운터 없음, 능력 불발'); return false; }
      inst.counters -= 1;
      MC.log(G, MC.nameOf(inst) + ' — 카운터 1 소비 (' + inst.counters + ' 남음)');
    }
    const c2 = Object.assign({ self: inst, hook: hookName }, ctx || {});
    if (!raw.cond || MC.condCheck(G, raw.cond, c2)) MC.runEffectList(G, raw.effect || [], c2);
    return true;
  }
  const fn = HANDLERS[raw];
  if (!fn) throw new Error('[fireCardHook] 미등록 handler: ' + raw);
  fn(G, Object.assign({ self: inst, hook: hookName }, ctx || {}));
  return true;
}

/* 공격 개시 인터럽트: 대상 플레이어의 현재 신분(영웅면)에 걸린 attackInterrupt 훅 발화.
   Spider-Sense처럼 "빌런이 당신을 공격 개시할 때" 트리거되는 능력용.
   신분 카드 정의(cardDef)의 attackInterrupt 이름 → HANDLERS 조회. */
function fireAttackInterrupt(G, pl, attacker){
  if (pl.form !== 'hero') return;              // 영웅면 능력만
  const def = MC.cardDef(pl.heroCode);
  const hname = def && def.attackInterrupt;
  if (!hname) return;
  const fn = HANDLERS[hname];
  if (!fn) throw new Error('[fireAttackInterrupt] 미등록 handler: ' + hname);
  fn(G, { self: pl, hook: 'attackInterrupt', player: pl, attacker });
}

/* 범용 훅 핸들러: 카드 정의의 effects 배열(또는 훅별 <hook>Effects)을 데이터로 실행.
   조우 카드가 커스텀 핸들러 없이 whenRevealed:'runCardEffects' + effects:[...]만 선언하면
   빌런 공격/암약/위협/폼분기 등을 인덱스(EFFECTS)로 처리. ctx.player는 공개한 플레이어. */
HANDLERS.runCardEffects = function(G, ctx){
  const self = ctx.self;
  const def = (self && self.defCode && MC.cardDef(self.defCode)) || self;
  const list = (def && (def[(ctx.hook || '') + 'Effects'] || def.effects)) || null;
  if (!list) return;
  // UI/디스패치가 넘긴 대상 선택값(targetScheme/targetPlayer/choice/targets)을 효과까지 전달.
  MC.runEffectList(G, list, { player: ctx.player, card: self, self,
    targetScheme: ctx.targetScheme, targetPlayer: ctx.targetPlayer,
    choice: ctx.choice, targets: ctx.targets });
};

// 에디슨의 거대 로봇(05028) 무효화: 🧠1 지불 후 이 하수인의 텍스트 박스를 페이즈 끝까지 무효화 (피해 가능해짐).
HANDLERS.nullifyRobot = function(G, ctx){
  const m = ctx.self || ctx.card;
  if (!m) return;
  m.nullifiedThisPhase = true;
  MC.log(G, MC.nameOf(m) + ' — 텍스트 무효화 (이 페이즈 피해 가능)');
};

// 부착물 "공격+피해 후" 강제반응을 데이터로 실행 (소닉 컨버터=피해 대상 기절 등). 범용 인덱스.
//   방어 해소부가 { player, target: dmgTarget, attacker, self: 부착물 } 컨텍스트로 호출.
HANDLERS.runAttachDamagedEffects = function(G, ctx){
  const def = ctx.self && MC.cardDef(ctx.self.defCode);
  if (def && def.attackDamagedEffects)
    MC.runEffectList(G, def.attackDamagedEffects,
      { player: ctx.player, self: ctx.self, card: ctx.self, target: ctx.target, attacker: ctx.attacker });
};

// 페이즈 훅에서 자신에게 카운터 N개 적립 (데이터: counterGainPerPhase, 기본 1). 퀸젯 시간 카운터 등 범용 인덱스.
//   playerPhaseStart 등 훅 필드가 이 핸들러명을 가리키면, fireHook이 전장의 해당 카드마다 호출.
HANDLERS.gainCounterOnPhase = function(G, ctx){
  const self = ctx.self;
  if (!self) return;
  const gain = (MC.cardDef(self.defCode).counterGainPerPhase) || 1;
  self.counters = (self.counters || 0) + gain;
  MC.log(G, MC.nameOf(self) + ' — 카운터 +' + gain + ' (누적 ' + self.counters + ')');
};

// Preemptive Strike(방어 인터럽트): 방어 pending의 부스트 카드를 취소(▲아이콘 제거) + 취소 수만큼 빌런 피해.
HANDLERS.preemptiveStrike = function(G, ctx){
  const p = G.pending;
  if (!p || p.kind !== 'defense'){ MC.log(G, 'Preemptive Strike — 방어 상황이 아님'); return; }
  const pl = ctx.player;
  const bc = p.boostCard;
  if (!bc){ MC.log(G, 'Preemptive Strike — 취소할 부스트 카드 없음'); return; }
  const icons = MC.boostOf(G, bc, pl) || 0;
  // 부스트 카드 취소: pending에서 제거 + 버림 (앞면 공개 없이 취소 → ★효과 미발동)
  p.boostCard = null;
  G.encounterDiscard.push(bc);
  MC.log(G, 'Preemptive Strike — 부스트 카드(' + MC.nameOf(bc) + ') 취소, ▲' + icons + ' 아이콘 제거');
  // 취소한 아이콘 수만큼 빌런에 피해
  if (icons > 0 && G.villain){
    MC.applyDamage(G, G.villain, icons, { source: ctx.self });
    MC.log(G, 'Preemptive Strike — 빌런에 ' + icons + ' 피해');
  }
  G.fxEvent = { vfx:'preemptiveStrike', villainUid: G.villain && G.villain.uid, targetUids: G.villain ? [G.villain.uid] : [] };
};

/* ★ 어보밍맨 II(04077) When Revealed: Super Absorbing Power(04092)가 전장에 있으면
   각 플레이어에게 조우 카드 1장, 없으면 04092를 소환(사이드 스킴 배치)한다.
   04092는 setAside 카드 — 조우덱/버린더미에 없으므로 makeInstance로 직접 생성해 배치. */
HANDLERS.absorbingSummonSuperPower = function(G, ctx){
  const inPlay = (G.sideSchemes || []).some(s => s.defCode === '04092');
  if (inPlay){
    for (const pl of MC.playersInOrder(G))
      MC.runEffectList(G, [{ fx: 'dealEncounterToEngaged', count: 1 }], { player: pl });
    MC.log(G, '초강력 흡수가 이미 전장에 — 각 플레이어 조우 카드 1장');
  } else {
    const def = MC.cardDef('04092');
    const inst = MC.makeInstance(G, '04092', { kind: 'side_scheme', isMain: false });
    inst.threat = (def.baseThreatPerPlayer || 0) * G.players.length + (def.baseThreat || 0);
    inst.peakThreat = inst.threat;
    G.sideSchemes.push(inst);
    MC.log(G, '초강력 흡수(Super Absorbing Power) 소환 — 시작 위협 ' + inst.threat);
    G._superAbsorbSpawn = { defCode: '04092', uid: inst.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  }
};

/* 하이드라에 포획(04107 Captured by Hydra) — 공개 시: 게임 밖에 둔 포로(Captive) 동료 1명을
   이 사이드 스킴 아래에 둔다(억류). 이 스킴을 저지하면 그 동료를 구출해 손에 넣는다. */
HANDLERS.capturedByHydraReveal = function(G, ctx){
  const self = ctx.self || ctx.card;
  const pool = G.setAsideCaptives || [];
  if (!pool.length){ MC.log(G, '억류할 포로 동료가 없음'); return; }
  const idx = Math.floor((MC.rng ? MC.rng(G) : Math.random()) * pool.length);
  const cap = pool.splice(idx, 1)[0];
  self.captiveAlly = cap;   // 이 스킴 아래 (facedown)
  MC.log(G, MC.nameOf(self) + ' — 포로 동료 1명을 억류했다');
  G._captiveHeld = { schemeUid: self.uid, allyCode: cap, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
};
HANDLERS.capturedByHydraDefeat = function(G, ctx){
  const self = ctx.self || ctx.card;
  const pl = ctx.player || G.players[G.firstPlayer];
  if (self.captiveAlly){
    const inst = MC.makeInstance(G, self.captiveAlly, {});
    pl.hand.push(inst);
    MC.log(G, MC.nameOf(pl) + ' — 포로 동료 ' + MC.nameOf(inst) + ' 구출! 손에 넣었다');
    G._captiveRescued = { allyCode: self.captiveAlly, player: pl.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    self.captiveAlly = null;
  }
  self.removeFromGame = true;   // 게임에서 제거 (버림 아님)
};

MC.HANDLERS = HANDLERS;
MC.fireHook = fireHook;
MC.fireCardHook = fireCardHook;
MC.fireAttackInterrupt = fireAttackInterrupt;

/* 기본 공격 후 강제 반응: 발동 플레이어의 플레이 영역 카드(업그레이드/서포트) 중
   afterBasicAttack 핸들러가 있으면 발화 (초인적인 힘 등). 대상=공격받은 적. */
function fireAfterBasicAttack(G, pl, attackedTarget){
  const zones = [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies];
  for (const zone of zones){
    for (const card of zone.slice()){   // slice: 발화 중 버림으로 배열 변형 대비
      const def = MC.cardDef(card.defCode);
      const hname = card.afterBasicAttack || (def && def.afterBasicAttack);
      if (!hname) continue;
      const fn = HANDLERS[hname];
      if (!fn) throw new Error('[fireAfterBasicAttack] 미등록 handler: ' + hname);
      fn(G, { self: card, hook: 'afterBasicAttack', player: pl, target: attackedTarget });
    }
  }
  // 선택 반응 (afterAttackReaction 인덱스) — 조건 충족 카드를 큐에 모아 순차 pending 창 생성.
  MC.queueAfterAttackReactions(G, pl, attackedTarget);
}
/* 공격 후 선택 반응(afterAttackReaction) 큐 생성. Battle Fury(처치 조건)·Jarnbjorn(자원 지불) 등.
   cardDef.afterAttackReaction = { condition?, cost?, needsTarget?, effects, discardSelf?, prompt } */
function queueAfterAttackReactions(G, pl, attackedTarget){
  if (G.pending) return;   // 다른 pending 진행 중이면 스킵(안전)
  const cands = [];
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const rx = MC.cardDef(c.defCode).afterAttackReaction;
      if (!rx) continue;
      if (rx.condition === 'defeatedMinion'){   // 공격으로 하수인 처치 시에만 (Battle Fury)
        if (!attackedTarget || attackedTarget.type !== 'minion' || attackedTarget.hp > 0) continue;
      }
      // 자원 지불(cost)이 필요한데 지불 가능한 손패 자원이 전혀 없으면 후보 제외 (Jarnbjorn)
      cands.push({ cardUid: c.uid, targetUid: attackedTarget && attackedTarget.uid });
    }
  }
  if (!cands.length) return;
  G._afterAttackQueue = cands.slice(1);
  const first = cands[0];
  G.pending = { kind:'afterAttackReaction', player: pl.uid, cardUid: first.cardUid, targetUid: first.targetUid };
}
MC.queueAfterAttackReactions = queueAfterAttackReactions;
MC.fireAfterBasicAttack = fireAfterBasicAttack;

/* ── 범용 사이드 스킴 핸들러 ──
   공개 시 플레이어당 추가 위협 (방어망 01125, 불법 무기 공장 01126 등 다수 재사용).
   기본 1/인 — 다른 양이 필요하면 def.revealThreatPerHero로 지정. */


/* ◇◇ from mc_4_players.js ◇◇ */
/* ═══════════════════════════════════════════════════════════════
   mc_4_players.js — 샤드 4/7 : 플레이어 모델 (1~4인 · 1급 개념)
   각 플레이어: 영웅/알터에고 flip · 손패 · 덱 · 자원 결제 · 플레이 영역
   ※ 4인 지원은 여기서 태어난다. G.hero 같은 단수 모델 금지.
   ═══════════════════════════════════════════════════════════════ */

/* 플레이어 생성. heroCode = 양면 카드의 영웅면 코드 ('01001a' 등) */
function makePlayer(G, seatIdx, heroCode, deckCodes){
  const heroCard = MC.cardDef(heroCode);
  if (!heroCard) throw new Error('[makePlayer] 미등록 영웅: ' + heroCode);
  const aeCard = MC.cardDef(heroCard.backLink);
  const pl = {
    uid: 'P' + seatIdx,
    seat: seatIdx,                 // 0..3
    heroCode, aeCode: heroCard.backLink,
    form: 'alter-ego',             // 게임은 알터에고면으로 시작
    hp: heroCard.hp, maxHp: heroCard.hp,
    exhausted: false,
    status: { stunned:0, confused:0, tough:0 },
    deck: MC.buildDeck(G, deckCodes), // 인스턴스 배열 (셔플은 셋업에서)
    hand: [], discard: [],
    playArea: { allies: [], supports: [], upgrades: [] },
    engagedMinions: [],
    obligationsOut: [],
    nemesisSetAside: [],           // 넴시스 세트 셋어사이드 카드 인스턴스 (Shadow of the Past가 투입)
    usedHeroAbilityThisRound: false,
    usedResourceAbilityThisRound: false,
    usedIdentityActionThisRound: {},   // 폼별(hero/alter-ego) 각각 라운드 1회 추적
    usedThreatPreventThisRound: false,
    formChangedThisRound: false,
    tempTraits: [],
    isPlayer: true, kind: 'identity',
  };
  return pl;
}

function heroFace(G, pl){ return MC.cardDef(pl.form === 'hero' ? pl.heroCode : pl.aeCode); }

/* 최대 HP 재계산: 기본 HP + 플레이 영역 카드의 hpBonus 합 (MK.5 아머 등).
   설치/제거 시 호출 → maxHp 갱신 + 증감 델타만큼 현재 HP 조정 (코어 룰: HP 토큰 증감). */
function recomputeMaxHp(G, pl){
  const face = MC.cardDef(pl.heroCode);   // HP는 앞뒷면 공통(기본 신분 기준)
  let bonus = 0;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const b = MC.cardDef(c.defCode).hpBonus;
      if (b) bonus += b;
    }
  }
  const newMax = (face.hp || 0) + bonus;
  const delta = newMax - pl.maxHp;
  pl.maxHp = newMax;
  if (delta > 0) pl.hp += delta;               // 최대 증가분만큼 현재도 증가
  if (pl.hp > pl.maxHp) pl.hp = pl.maxHp;       // 최대 감소 시 현재 상한 클램프
  if (pl.hp < 0) pl.hp = 0;
}
MC.recomputeMaxHp = recomputeMaxHp;
function statOf(G, pl, stat){ // attack/thwart/defense/recover/handSize + 플레이 영역 카드의 패시브 수정치
  const face = heroFace(G, pl);
  let base = face[stat] !== undefined ? face[stat] : 0;
  base += passiveStatMod(G, pl, stat);
  // 임시 스탯 버프 (선두에서 이끌기 등 — 페이즈 종료까지 히어로 +1). pl.tempStatBonus 합산.
  if (pl.tempStatBonus && pl.tempStatBonus[stat]) base += pl.tempStatBonus[stat];
  // 라운드 지속 스탯 버프 (사기 증진 등 — 라운드 종료까지 +1, 빌런 페이즈 DEF 포함). pl.roundStatBonus 합산.
  if (pl.roundStatBonus && pl.roundStatBonus[stat]) base += pl.roundStatBonus[stat];
  // 신분 동적 손패 (아이언맨: Tech 업그레이드 1개당 +1, 상한 max)
  if (stat === 'handSize'){
    const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    const dh = MC.cardDef(faceCode) && MC.cardDef(faceCode).dynamicHandSize;
    if (dh && dh.perTrait){
      let cnt = 0;
      for (const c of pl.playArea.upgrades){
        const cdef = MC.cardDef(c.defCode);
        if (dh.cardType && cdef.type !== dh.cardType) continue;
        if ((cdef.traits || []).includes(dh.perTrait)) cnt++;
      }
      base += cnt;
      if (dh.max !== undefined && base > dh.max) base = dh.max;
    }
  }
  return base;
}

/* 플레이 영역 카드(support/upgrade)가 부여하는 지속 스탯 수정치 합산.
   cardDef.statMod = { stat:'defense', amount:1, cond?, amountIf?:{cond, amount} }
   조건부: amountIf가 있고 cond 충족 시 그 값으로 대체(헬멧: Aerial이면 +2 대신). 범용. */
function passiveStatMod(G, pl, stat){
  let total = 0;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const sm = MC.cardDef(c.defCode).statMod;
      if (!sm) continue;
      const mods = Array.isArray(sm) ? sm : [sm];
      for (const m of mods){
        if (m.stat !== stat) continue;
        // 기본 조건(cond) 불충족이면 스킵
        if (m.cond && !MC.condCheck(G, m.cond, { player: pl })) continue;
        // 조건부 대체값(amountIf): 충족 시 그 값, 아니면 기본 amount
        if (m.amountIf && MC.condCheck(G, m.amountIf.cond, { player: pl })) total += m.amountIf.amount;
        else total += (m.amount || 0);
      }
    }
  }
  return total;
}

/* 영웅 ↔ 알터에고 flip — 라운드당 1회 (코어 룰) */
function flipForm(G, pl, opt){
  opt = opt || {};
  if (!opt.force && pl.formChangedThisRound) throw new Error('[flipForm] 이번 라운드에 이미 형태 변경');
  // 신분 부착(All Tied Up): 형태 변경 불가 (force 포함 — 공식 "cannot change form").
  if (identityAttachHas(G, pl, 'identityCannotFlip'))
    throw new Error('[flipForm] ' + MC.nameOf(pl) + ' — 신분에 부착된 카드로 형태 변경 불가');
  // 왕좌 찬탈(01156) 등: 특정 사이드 스킴이 전장에 있는 동안 히어로→알터에고 전환 봉쇄.
  //   force 전환(이중인격 등)도 막는다(공식: "cannot flip"). 알터에고→히어로 복귀는 허용.
  if (pl.form === 'hero'){
    const blocker = (G.sideSchemes || []).find(s => {
      const d = MC.cardDef(s.defCode);
      return d && d.blocksAlterEgoFlip;
    });
    if (blocker) throw new Error('[flipForm] ' + MC.nameOf(blocker) + ' — 알터에고 형태로 전환 불가');
  }
  if (!opt.force) pl.formChangedThisRound = true;   // 강제 전환(이중인격)은 라운드 제한 미소모
  pl.form = (pl.form === 'hero') ? 'alter-ego' : 'hero';
  MC.log(G, pl.uid + ' → ' + MC.T(pl.form) + ' 형태');
  MC.fireHook(G, 'onFormChange', { player: pl });
  // 업그레이드/서포트 onFormChangeDiscard (끝없는 분노: 폼 변경 후 버림)
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr.slice()){
      if (MC.cardDef(c.defCode).onFormChangeDiscard){
        const i = arr.indexOf(c); if (i >= 0) arr.splice(i, 1);
        MC.moveToDiscard(G, pl, c, {});
        MC.log(G, MC.nameOf(c) + ' — 폼 변경으로 버림');
      }
    }
  }
  // 신분(identity) 카드 자체의 onFormChange 능력 (She-Hulk 히어로 파워 등) — 새 폼 기준
  const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
  const fdef = MC.cardDef(faceCode);
  if (fdef && fdef.onFormChange && MC.HANDLERS[fdef.onFormChange]){
    MC.HANDLERS[fdef.onFormChange](G, { self: fdef, player: pl, hook: 'onFormChange', newForm: pl.form });
  }
  // 태스크마스터: 히어로 폼으로 전환한 후 빌런 강제 반응 (조우덱 top 버리고 부스트 아이콘만큼 피해). 데이터 기반.
  if (pl.form === 'hero' && G.villain){
    const vd = MC.cardDef(G.villain.defCode);
    if (vd && vd.onHeroFormResponse) MC.runEffectList(G, vd.onHeroFormResponse, { player: pl });
  }
}

/* ── 자원 결제: 요소(element) 모델 ──
   element = { kind:'hand', uid }                 손패 카드를 자원으로 버림
           | { kind:'ability', id:'scientist' }   신분 자원 능력 (라운드 제한 등)
   특수 규칙:
   - doubleForAspect: 대상 카드 성향 일치 시 이 카드의 자원 생성량 2배 (예: 수호의 힘)
   - 신분 자원 능력은 RESOURCE_ABILITIES 레지스트리로 정의 */
const RESOURCE_ABILITIES = {
  scientist: { name:'과학자', form:'alter-ego', icons:{ mental:1 }, oncePerRound:true },
};

function resourceIconsOf(inst){
  const r = inst.resources || {};
  return { physical:r.physical||0, mental:r.mental||0, energy:r.energy||0, wild:r.wild||0 };
}
/* 요소 1개의 유효 아이콘 계산 (대상 카드 문맥 반영) */
function elementIcons(G, pl, el, targetCard){
  if (el.kind === 'hand'){
    const inst = pl.hand.find(c => c.uid === el.uid);
    if (!inst) throw new Error('[payment] 손패에 없음: ' + el.uid);
    const icons = resourceIconsOf(inst);
    const def = MC.cardDef(inst.defCode);
    if (def && def.doubleForAspect && targetCard && targetCard.aspect === def.doubleForAspect)
      for (const k in icons) icons[k] *= 2;
    return { icons, inst };
  }
  if (el.kind === 'ability'){
    const ab = RESOURCE_ABILITIES[el.id];
    if (!ab) throw new Error('[payment] 미등록 자원 능력: ' + el.id);
    const face = MC.heroFace(G, pl);
    const fdef = MC.cardDef(pl.form === 'hero' ? pl.heroCode : pl.aeCode);
    if (!fdef || fdef.resourceAbility !== el.id) throw new Error('[payment] 현재 신분에 없는 능력: ' + ab.name);
    if (ab.form && pl.form !== ab.form) throw new Error('[payment] ' + ab.name + '은(는) ' + MC.T(ab.form) + ' 전용');
    if (ab.oncePerRound && pl.usedResourceAbilityThisRound) throw new Error('[payment] ' + ab.name + ' 이번 라운드 사용됨');
    return { icons: Object.assign({ physical:0, mental:0, energy:0, wild:0 }, ab.icons), ability: ab };
  }
  if (el.kind === 'card'){
    // 카드 자원 생성 (웹 슈터 등): 플레이 영역의 카드가 resourceGenerator로 자원을 냄.
    // 소진/카운터 조건은 executePayment에서 실제 차감. 여기선 아이콘만 계산(무변이).
    let inst = null;
    for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
      { const c = arr.find(x => x.uid === el.uid); if (c){ inst = c; break; } }
    if (!inst) throw new Error('[payment] 플레이 영역에 없음: ' + el.uid);
    const def = MC.cardDef(inst.defCode);
    const rg = def.resourceGenerator;
    if (!rg) throw new Error('[payment] 자원 생성 능력 없음: ' + inst.defCode);
    if (rg.form && pl.form !== rg.form) throw new Error('[payment] ' + MC.T(rg.form) + ' 전용 자원');
    if (rg.exhaust && inst.exhausted) throw new Error('[payment] 이미 소진됨: ' + MC.nameOf(inst));
    if (rg.counter && (inst.counters||0) < rg.counter) throw new Error('[payment] 카운터 부족: ' + MC.nameOf(inst));
    // 동적 자원: 버림 더미 맨 위 카드의 자원 (페퍼 포츠). 버림 더미 비면 자원 없음.
    if (rg.fromDiscardTop){
      const top = pl.discard[pl.discard.length - 1];
      if (!top) throw new Error('[payment] 버림 더미가 비어 자원 생성 불가: ' + MC.nameOf(inst));
      const topIcons = MC.resourceIconsOf(top);
      return { icons: Object.assign({ physical:0, mental:0, energy:0, wild:0 }, topIcons), gen: inst };
    }
    return { icons: Object.assign({ physical:0, mental:0, energy:0, wild:0 }, rg.icons), gen: inst };
  }
  throw new Error('[payment] 미지원 요소: ' + el.kind);
}
/* 검증 전용 — 무변이. 합계/아이콘 반환 */
function computePayment(G, pl, elements, targetCard){
  let sum = 0;
  const icons = { physical:0, mental:0, energy:0, wild:0 };
  const seen = new Set();
  for (const el of elements){
    const key = el.kind + ':' + (el.uid || el.id);
    if (seen.has(key)) throw new Error('[payment] 요소 중복: ' + key);
    seen.add(key);
    const { icons: ic } = elementIcons(G, pl, el, targetCard);
    for (const k in icons){ icons[k] += ic[k]; sum += ic[k]; }
  }
  return { sum, icons };
}
function validatePayment(G, pl, elements, cost, targetCard, requires){
  const { sum, icons } = computePayment(G, pl, elements, targetCard);
  if (sum < cost) throw new Error('[payment] 자원 부족: ' + sum + '/' + cost);
  if (requires){
    const have = (icons[requires.type]||0) + icons.wild;
    if (have < requires.count) throw new Error('[payment] 자원 유형 불충족: ' + MC.T(requires.type));
  }
  return { sum, icons };
}
/* 실행 — 검증 후에만 호출 */
function executePayment(G, pl, elements){
  for (const el of elements){
    if (el.kind === 'hand'){
      MC.moveToDiscard(G, pl, MC.fromHand(pl, el.uid), { asResource:true });
    } else if (el.kind === 'ability'){
      const ab = RESOURCE_ABILITIES[el.id];
      if (ab.oncePerRound) pl.usedResourceAbilityThisRound = true;
      MC.log(G, pl.uid + ' 자원 능력: ' + ab.name);
    } else if (el.kind === 'card'){
      // 카드 자원 생성: 소진 + 카운터 차감. 카운터가 0이 되면 카드 버림.
      let inst = null, srcArr = null;
      for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
        { const c = arr.find(x => x.uid === el.uid); if (c){ inst = c; srcArr = arr; break; } }
      if (!inst) throw new Error('[payment] 자원 생성 카드 없음: ' + el.uid);
      const rg = MC.cardDef(inst.defCode).resourceGenerator;
      if (rg.exhaust) inst.exhausted = true;
      if (rg.discard){   // 리소스풀: 버림으로 자원 생성 (자기 자신을 버림 더미로)
        if (inst.attachedTo) MC.detachFrom(G, inst);
        const i = srcArr.indexOf(inst); if (i >= 0) srcArr.splice(i, 1);
        MC.moveToDiscard(G, pl, inst, {});
        MC.log(G, MC.nameOf(inst) + ' — 버림으로 자원 생성');
      }
      if (rg.counter){
        inst.counters = (inst.counters||0) - rg.counter;
        MC.log(G, MC.nameOf(inst) + ' 자원 생성 (카운터 ' + inst.counters + ' 남음)');
        if (inst.counters <= 0){
          // 부착물이면 해제 후 버림 / 아니면 영역에서 제거 후 버림
          if (inst.attachedTo) MC.detachFrom(G, inst);
          const i = srcArr.indexOf(inst); if (i>=0) srcArr.splice(i,1);
          MC.moveToDiscard(G, pl, inst, {});
          MC.log(G, MC.nameOf(inst) + ' — 카운터 소진, 버림');
        }
      } else {
        MC.log(G, MC.nameOf(inst) + ' 자원 생성');
      }
    }
  }
}
/* (구형 호환) paymentTotal: 손패 인스턴스 배열 합계 */
function paymentTotal(insts){
  let sum = 0, icons = { physical:0, mental:0, energy:0, wild:0 };
  for (const i of insts){
    const r = resourceIconsOf(i);
    for (const k in icons){ icons[k] += r[k]; sum += r[k]; }
  }
  return { sum, icons };
}

/* 손패/덱 유틸 */
function drawCards(G, pl, n){
  for (let k=0;k<n;k++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); if (pl.deck.length===0) break; }
    pl.hand.push(pl.deck.pop());
  }
}
/* 공용 강제 버림 — 지정 카드들을 손패에서 버림 + VFX 힌트(G.fxForcedDiscard) 설정.
   헐크 격노(손패 전체) / 무작위 버림 / 브루스 배너 등 모든 강제 버림이 재사용. */
MC.forcedDiscard = function(G, pl, cards, opt){
  opt = opt || {};
  const codes = [];
  for (const c of cards){
    const i = pl.hand.indexOf(c);
    if (i >= 0){ pl.hand.splice(i, 1); MC.moveToDiscard(G, pl, c, {}); codes.push(c.defCode); }
  }
  if (codes.length){
    G.fxForcedDiscard = { playerUid: pl.uid, count: codes.length, cards: codes, reason: opt.reason || '', seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    MC.log(G, MC.nameOf(pl) + ' — 카드 ' + codes.length + '장 강제 버림' + (opt.reason ? ' (' + opt.reason + ')' : ''));
  }
  return codes.length;
};
function discardRandomFromHand(G, pl, n){
  const picked = [];
  for (let k=0;k<n && (pl.hand.length - picked.length) > 0;k++){
    const avail = pl.hand.filter(c => picked.indexOf(c) < 0);
    if (!avail.length) break;
    picked.push(avail[Math.floor(MC.rand(G) * avail.length)]);
  }
  MC.forcedDiscard(G, pl, picked, { reason: '무작위 버림' });
}
/* 플레이어 페이즈 종료 정리: 손패 보충 + 전체 준비 (코어: 버림선택→보충→준비) */
function drawUpToHandSize(G, pl){
  const hs = MC.statOf(G, pl, 'handSize') || 5;
  if (pl.hand.length < hs) drawCards(G, pl, hs - pl.hand.length);
}
function readyAllFor(G, pl){
  // 신분 부착(All Tied Up)이 준비를 막으면 신분(exhausted)은 준비하지 않는다.
  if (!identityAttachHas(G, pl, 'identityCannotReady')) pl.exhausted = false;
  for (const arr of [pl.playArea.allies, pl.playArea.supports, pl.playArea.upgrades])
    for (const c of arr) c.exhausted = false;
}
/* 플레이어 신분에 부착된 카드 중 지정 플래그를 가진 것이 있는가 (All Tied Up 등). */
function identityAttachHas(G, pl, flag){
  for (const a of (pl.identityAttachments || [])){
    const d = MC.cardDef(a.defCode);
    if (d && d[flag]) return true;
  }
  return false;
}
MC.identityAttachHas = identityAttachHas;

/* 플레이어 덱 소진: 인카운터 1장 받은 뒤 버림 더미를 섞어 새 덱 (코어 룰) */
function onEmptyPlayerDeck(G, pl){
  MC.log(G, pl.uid + ' 덱 소진 → 리셔플 + 인카운터 카드 1장');
  pl.deck = MC.shuffle(G, pl.discard.splice(0));   // RRG: ① 버림 더미를 섞어 새 덱
  MC.dealEncounterTo(G, pl, 1);                     // RRG: ② 즉시 조우 카드 1장
}

/* 덱 맨 위 N장을 버림 더미로 (밀링) — 울트론의 분노 등 "덱 맨 위 카드를 버린다" 후속 효과.
   RRG: 밀 중 덱 소진 시 onEmptyPlayerDeck(인카운터+리셔플) 후 중단 — 새로 섞인 덱에선 밀지 않음. 실제 버린 수 반환. */
function discardTopOfDeck(G, pl, n){
  let done = 0;
  for (let i = 0; i < n; i++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); break; }
    pl.discard.push(pl.deck.pop());
    done++;
  }
  if (done) MC.log(G, pl.uid + ' 덱 맨 위 ' + done + '장 버림');
  return done;
}
MC.discardTopOfDeck = discardTopOfDeck;

MC.makePlayer = makePlayer;
MC.heroFace = heroFace; MC.statOf = statOf; MC.flipForm = flipForm;

/* 동료의 유효 스탯 계산 (attack/thwart) — 기본 스탯 + 카드 def의 dynamicStat 보너스.
   cardDef.dynamicStat = { stat:'thwart', per:'sideScheme' } 형태.
   per='sideScheme': 전장의 사이드 스킴 개수만큼 +1 (제시카 존스). 범용 확장 가능. */
function allyStatOf(G, ally, stat){
  let base = ally[stat] || 0;
  const def = MC.cardDef(ally.defCode);
  const ds = def && def.dynamicStat;
  if (ds && ds.stat === stat){
    if (ds.per === 'sideScheme') base += (G.sideSchemes || []).length;
    else if (ds.per === 'damageOnSelf') base += Math.max(0, (ally.maxHp || (def && def.hp) || 0) - (ally.hp || 0));   // 쉬헐크: 피해 토큰당 +1 ATK
  }
  // 임시 스탯 버프 (비전=페이즈 종료까지 +2 등). tempStatBonus[stat] 합산.
  if (ally.tempStatBonus && ally.tempStatBonus[stat]) base += ally.tempStatBonus[stat];
  // 라운드 지속 스탯 버프 (라운드 종료까지). roundStatBonus[stat] 합산.
  if (ally.roundStatBonus && ally.roundStatBonus[stat]) base += ally.roundStatBonus[stat];
  return base;
}
MC.allyStatOf = allyStatOf;

/* 플레이어의 동료 한도 계산 (기본 3 + 플레이 영역 카드의 allyLimitBonus 합산).
   트리스켈리온 등이 동료 한도를 늘림. */
function allyLimitOf(G, pl){
  let limit = 3;
  for (const arr of [pl.playArea.supports, pl.playArea.upgrades]){
    for (const c of arr){
      const def = MC.cardDef(c.defCode);
      if (def && def.allyLimitBonus){
        // 조건부 한도(어벤져스 타워): 당신의 모든 동료가 특정 특성을 가질 때만 보너스 적용.
        //   동료 0명이면 공허참(vacuously true)으로 적용.
        if (def.allyLimitCondAllTrait){
          const t = String(def.allyLimitCondAllTrait).toLowerCase();
          const allMatch = (pl.playArea.allies || []).every(a => MC.allyHasTrait(G, a, t));
          if (allMatch) limit += def.allyLimitBonus;
        } else {
          limit += def.allyLimitBonus;
        }
      }
    }
  }
  return limit;
}
MC.allyLimitOf = allyLimitOf;
MC.RESOURCE_ABILITIES = RESOURCE_ABILITIES;
MC.resourceIconsOf = resourceIconsOf; MC.paymentTotal = paymentTotal;
MC.elementIcons = elementIcons; MC.computePayment = computePayment;
/* payIconsSatisfied(icons, req) — 지불된 아이콘 집계(icons: {energy,mental,physical,wild,...})가
   요구(req: {energy:1,mental:1,physical:1})를 충족하는지. 부족분은 wild로 메움(유연 배정).
   소닉 붐 "자원 3종 지불" 등 다중 타입 요구 선택지 검증에 범용 사용. */
function payIconsSatisfied(icons, req){
  let wild = icons.wild || 0;
  for (const t in req){
    if (t === 'total') continue;   // 합계 요구는 아래에서 처리
    const have = icons[t] || 0;
    if (have >= req[t]) continue;
    const need = req[t] - have;
    if (wild >= need) wild -= need; else return false;
  }
  if (req.total){   // "아무 타입 N개" — 전체 아이콘 합계
    const sum = (icons.energy||0) + (icons.mental||0) + (icons.physical||0) + (icons.wild||0);
    if (sum < req.total) return false;
  }
  return true;
}
MC.payIconsSatisfied = payIconsSatisfied;
/* canPayDifferentTypes(icons, n) — 지불 아이콘 집계가 서로 다른 타입 n개를 구성할 수 있는가.
   (레드 대거 "서로 다른 종류의 자원 2개"). Wild는 어느 타입으로든 배정 가능. */
function canPayDifferentTypes(icons, n){
  let distinct = 0;
  for (const t of ['physical','mental','energy']) if ((icons[t]||0) >= 1) distinct++;
  const wild = icons.wild || 0;
  return (distinct + wild) >= n;   // 서로 다른 비-와일드 타입 + 와일드(각각 다른 타입 대체)
}
MC.canPayDifferentTypes = canPayDifferentTypes;
MC.validatePayment = validatePayment; MC.executePayment = executePayment;
MC.drawCards = drawCards; MC.discardRandomFromHand = discardRandomFromHand;
MC.onEmptyPlayerDeck = onEmptyPlayerDeck;
MC.readyAllFor = readyAllFor; MC.drawUpToHandSize = drawUpToHandSize;


/* ◇◇ from mc_5_encounter.js ◇◇ */
/* ═══════════════════════════════════════════════════════════════
   mc_5_encounter.js — 샤드 5/7 : 인카운터덱 · 빌런 페이즈 (스텝 큐)
   ★ 설계: 빌런 페이즈는 스텝 큐(G.vq)로 진행. 사람 결정이 필요한 지점
     (방어 선언)에서 G.pending을 세우고 멈춘다. 결정은 액션(resolveDefense)
     으로 들어와 pending을 해소하고 큐를 재개한다.
     → 결정이 곧 액션이므로 재생(replay) 동기화가 그대로 성립.
   빌런 페이즈(코어 룰): ①위협 배치 ②빌런+하수인 활성화 ③인카운터 배분
     ④공개/해결 ⑤선 플레이어 이동·라운드 종료
   ═══════════════════════════════════════════════════════════════ */

function drawEncounterCard(G){
  if (G.encounterDeck.length === 0){
    G.encounterDeck = MC.shuffle(G, G.encounterDiscard.splice(0));
    G.acceleration += 1;
    MC.log(G, '인카운터덱 리셔플 — 가속 토큰 +1 (누적 ' + G.acceleration + ')');
    if (G.encounterDeck.length === 0) return null;
  }
  return G.encounterDeck.pop();
}

function dealEncounterTo(G, pl, n){
  for (let k=0;k<n;k++){
    const c = drawEncounterCard(G);
    if (c) G.pendingEncounters.push({ player: pl.uid, uid: c.uid, inst: c });
  }
}

/* 부스트★ 효과: 부스트로 공개된 카드에 boostStarEffect(또는 boostStarPutIntoPlay)가 있으면 발동.
   - putIntoPlay: 그 카드(하수인)를 부스트 뽑은 플레이어와 교전 상태로 전장 배치 (무기 밀매상).
     이 경우 카드는 버려지지 않고 전장에 남는다 → true 반환(호출측이 버림 스킵).
   - 그 외 이름: EFFECTS 파이프라인 실행 (im-tough=toughEnemy 등). 카드는 정상 버림.
   actKind: 'attack'|'scheme' — 이 부스트가 어떤 활성화에 뒤집혔는지.
   boostStarOnScheme: 암약 활성화 부스트일 때만 발동하는 효과 배열 (프로그램 전송기 01141 등
   "★강제 반응: 울트론이 암약한 후 → …" 유형). boostStarOnDamage(공격+피해 조건부)의 짝.
   반환: true면 카드가 전장에 배치됨(버리지 말 것), false면 일반 버림 진행. */
function resolveBoostStar(G, pl, boostCard, actKind){
  const def = MC.cardDef(boostCard.defCode);
  G._lastBoostStar = null;   // UI 힌트: 이번 부스트★로 무슨 일이 일어났는지 (minion 배치/효과)
  if (!def) return false;
  // 하수인 전장 배치형 (boost_star + minion): 부스트로 뽑히면 교전 등장
  if (def.boostStarPutIntoPlay && def.type === 'minion'){
    boostCard.engagedWith = pl.uid;
    pl.engagedMinions.push(boostCard);
    boostCard.status = boostCard.status || { stunned:0, confused:0, tough: def.toughness ? 1 : 0 };
    MC.minionEnteredPlay(G, boostCard, pl);
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★: ' + pl.uid + '와(과) 교전 상태로 전장 등장');
    (G.revealLog = G.revealLog || []).push({ defCode: boostCard.defCode, name: boostCard.name, type: 'minion', player: pl.uid, fromBoostStar: true });
    G._lastBoostStar = { kind: 'minion' };
    return true;
  }
  // 부스트★ 사이드 스킴 전장 배치 (Goblin Nation): 위협 셋업 후 사이드 스킴으로 등장.
  if (def.boostStarPutIntoPlay && def.type === 'side_scheme'){
    boostCard.threat = (def.baseThreatPerPlayer || 0) * G.players.length + (def.baseThreat || 0);
    boostCard.peakThreat = boostCard.threat;
    boostCard.isMain = false;
    G.sideSchemes.push(boostCard);
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★: 사이드 스킴으로 전장 등장 (위협 ' + boostCard.threat + ')');
    (G.revealLog = G.revealLog || []).push({ defCode: boostCard.defCode, name: boostCard.name, type: 'side_scheme', player: pl.uid, fromBoostStar: true });
    G._lastBoostStar = { kind: 'side_scheme' };
    return true;
  }
  // 효과형 (toughEnemy=villain, discardBooster=player 등)
  if (def.boostStarEffect && MC.EFFECTS[def.boostStarEffect]){
    MC.runEffectList(G, [{ fx: def.boostStarEffect }], { player: pl, self: boostCard, card: boostCard });
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★ 효과: ' + def.boostStarEffect);
    G._lastBoostStar = { kind: 'effect', effect: def.boostStarEffect };
  }
  // 파라미터형 무조건 발동 (boostStarEffects: effects 배열) — 활성화 종류 무관.
  // boostStarEffect(단일 fx명, 파라미터 없음)로 표현 못 하는 데이터 효과용 (수리 시퀀스 회복/드론 등).
  if (def.boostStarEffects){
    MC.runEffectList(G, def.boostStarEffects, { player: pl, self: boostCard, card: boostCard });
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★ 효과 발동');
    G._lastBoostStar = { kind: 'effects' };
  }
  // 암약 조건부 (boostStarOnScheme): 이 부스트가 암약(스킴) 활성화에 뒤집혔을 때만 발동
  if (def.boostStarOnScheme && actKind === 'scheme'){
    MC.runEffectList(G, def.boostStarOnScheme, { player: pl, self: boostCard, card: boostCard });
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★(암약) 효과 발동');
    G._lastBoostStar = { kind: 'effect', effect: 'boostStarOnScheme' };
  }
  // 선택형 부스트★ (boostStarChoice): 부스트로 뒤집힌 플레이어가 선택 (안드로이드 효율 등).
  // 부스트 공개는 방어/암약 해소 도중이라 즉시 pending을 세우면 흐름이 깨진다 →
  // deferred로 적재하고, 해당 활성화(공격·암약)가 끝난 시점에 flushDeferredBoostChoice가 처리.
  if (def.boostStarChoice){
    G._deferredBoostChoice = { playerUid: pl.uid, selfName: MC.nameOf(boostCard),
                               choiceDef: def.boostStarChoice };
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★ 선택 예약 (활성화 종료 후 처리)');
    G._lastBoostStar = { kind: 'choice' };
  }
  // 부스트★ 셔플백 (Goblin Knight): 이 카드를 버리지 않고 조우덱에 셔플백.
  if (def.boostStarShuffleBack){
    G.encounterDeck.push(boostCard);
    MC.shuffle(G, G.encounterDeck);
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★: 조우덱에 셔플백');
    G._lastBoostStar = { kind: 'shuffleBack' };
    return true;   // 버리지 않음
  }
  return false;
}
MC.resolveBoostStar = resolveBoostStar;

// 적(빌런/하수인)의 유효 공격력 — 동적 ATK + 패시브 집계. 타이타니아(01162) atkEqualsHp: ATK = 현재 HP.
// 패시브(enemyAtkPassive): Goblin Nation 등 "고블린 적 +1 ATK" 지속 효과를 중앙 집계.
function enemyAtk(G, enemy){
  if (!enemy) return 0;
  const d = MC.cardDef(enemy.defCode);
  let atk = (d && d.atkEqualsHp) ? Math.max(0, enemy.hp || 0) : (enemy.attack || 0);
  if (MC.enemyAtkPassive) atk += MC.enemyAtkPassive(G, enemy);
  return Math.max(0, atk);
}
MC.enemyAtk = enemyAtk;

/* 하수인/빌런 ATK 패시브 집계 — Taskmaster(교전 플레이어의 통제 업그레이드 1장당 +1) 등. 중앙 인덱스. */
MC.enemyAtkPassive = function(G, enemy){
  const d = MC.cardDef(enemy.defCode);
  let bonus = 0;
  if (d && d.minionStatScale && d.minionStatScale.atk){
    const pl = G.players.find(p => p.uid === enemy.engagedWith);
    if (pl) bonus += (pl.playArea.upgrades || []).length * d.minionStatScale.atk;
  }
  // 얼티밋 바이오-서번트(04114): 자신에게 붙은 부착물 1개당 ATK +N.
  if (d && d.minionStatScale && d.minionStatScale.perSelfAttachment){
    bonus += (enemy.attachments || []).length * d.minionStatScale.perSelfAttachment;
  }
  return bonus;
};
/* 하수인 암약(SCH) 패시브 집계 — Taskmaster 통제 업그레이드 스케일. */
MC.enemySchemePassive = function(G, enemy){
  const d = MC.cardDef(enemy.defCode);
  let bonus = 0;
  if (d && d.minionStatScale && d.minionStatScale.sch){
    const pl = G.players.find(p => p.uid === enemy.engagedWith);
    if (pl) bonus += (pl.playArea.upgrades || []).length * d.minionStatScale.sch;
  }
  return bonus;
};

/* 지연된 부스트★ 선택 처리 — 공격/암약 활성화가 끝난 뒤 호출.
   choiceDef: { prompt, resourcePayIcons, droneFallback } 형태.
   자원 지불이 가능하면 선택 pending(revealChoice)을 세우고, 불가능하면 자동으로 드론 스폰
   (공식: "spend a resource OR put a drone" — 자원을 못 내면 드론만 남음).
   pending을 세우면 true 반환 → 호출측은 큐를 멈춘다(processVillainQueue가 감지). */
function flushDeferredBoostChoice(G){
  const d = G._deferredBoostChoice;
  if (!d) return false;
  G._deferredBoostChoice = null;
  const pl = G.players.find(p => p.uid === d.playerUid);
  if (!pl || pl.eliminated) return false;
  const cd = d.choiceDef;
  const pay = cd.resourcePayIcons || { energy: 1 };
  // 활성 플레이어가 요구 자원을 낼 수 있는지(손패 아이콘 + 와일드) 판정
  let canPay = false;
  const needType = Object.keys(pay)[0];
  const needN = pay[needType] || 1;
  let avail = 0;
  for (const c of pl.hand){
    const r = c.resources || {};
    avail += (r[needType] || 0) + (r.wild || 0);
  }
  canPay = avail >= needN;
  const droneEffects = [{ fx: 'spawnDrone', scope: 'activePlayer',
                          fallback: cd.droneFallback || { attack:1, scheme:1, hp:1 } }];
  if (!canPay){
    // 자원 불가 → 자동 드론 (선택 없음)
    MC.log(G, d.selfName + ' — 부스트★: 지불할 자원 없음 → 드론 자동 등장');
    MC.runEffectList(G, droneEffects, { player: pl, self: null });
    if (cd.vfx) G.fxCardEffect = { vfx: cd.vfx, quote: cd.quoteAuto || null };
    return false;
  }
  // 선택 pending — resolveRevealChoice가 payIcons/effects 처리
  G.pending = { kind: 'revealChoice', player: pl.uid, selfUid: null,
    prompt: cd.prompt || '자원을 지불하거나 드론을 등장시키세요',
    options: [
      { key: 'resource', label: cd.resourceLabel || '자원 1 지불 (회피)', payIcons: pay, effects: [] },
      { key: 'drone', label: cd.droneLabel || '뒷면 드론 등장', effects: droneEffects },
    ] };
  MC.log(G, d.selfName + ' — 부스트★ 선택 대기 (' + pl.uid + ')');
  return true;
}
MC.flushDeferredBoostChoice = flushDeferredBoostChoice;

/* 강제 위협 선택 체인 (노라드 습격 01138b) — 대기 중인 각 플레이어에게 순차로 선택 pending을 세운다.
   메인 스킴 def.forcedThreatChoice의 options(위협2 / 드론)를 revealChoice로. 한 명 해소 후
   resolveRevealChoice가 다시 이 함수를 호출해 다음 플레이어로 이어간다. pending 세우면 true. */
function flushThreatChoice(G){
  const q = G._pendingThreatChoice;
  if (!q || !q.length) return false;
  const msDef = MC.cardDef(G.mainScheme.defCode);
  const cd = msDef && msDef.forcedThreatChoice;
  if (!cd){ G._pendingThreatChoice = null; return false; }
  let pl = null;
  while (q.length){
    const uid = q.shift();
    const cand = G.players.find(p => p.uid === uid);
    if (cand && !cand.eliminated){ pl = cand; break; }
  }
  if (!pl){ G._pendingThreatChoice = null; return false; }
  G.pending = { kind:'revealChoice', player: pl.uid, selfUid: G.mainScheme.uid,
    prompt: cd.prompt || '선택하세요', options: cd.options || [] };
  MC.log(G, MC.nameOf(G.mainScheme) + ' — 강제 반응: ' + pl.uid + ' 선택 대기');
  return true;
}
MC.flushThreatChoice = flushThreatChoice;

/* 각 플레이어 선택 체인(범용) — whenRevealed 등에서 "각 플레이어가 A or B를 선택" (공격 받는 중 01151,
   충격파 폭발류). G._pendingEachChoice = { selfUid, prompt, options, queue:[uids] }.
   한 명 해소 후 resolveRevealChoice가 다시 호출해 다음 플레이어로. pending 세우면 true. */
function flushEachChoice(G){
  const st = G._pendingEachChoice;
  if (!st || !st.queue || !st.queue.length){ G._pendingEachChoice = null; return false; }
  let pl = null;
  while (st.queue.length){
    const uid = st.queue.shift();
    const cand = G.players.find(p => p.uid === uid);
    if (cand && !cand.eliminated){ pl = cand; break; }
  }
  if (!pl){ G._pendingEachChoice = null; return false; }
  G.pending = { kind:'revealChoice', player: pl.uid, selfUid: st.selfUid || null,
    prompt: st.prompt || '선택하세요', options: st.options || [] };
  MC.log(G, '강제 선택 — ' + pl.uid + ' 선택 대기');
  return true;
}
MC.flushEachChoice = flushEachChoice;

/* ── 위협 ── */
function placeThreat(G, schemeRef, amount){
  if (amount <= 0) return;
  const s = MC.resolveScheme(G, schemeRef);
  // 이벤트 인터럽트로 예약된 위협→피해 대체 (큰 힘에는 큰 책임): 예약량만큼 위협 차감.
  // (히어로 피해는 이벤트 플레이 시점에 이미 적용됨)
  if (G.preventNextThreat && G.preventNextThreat > 0){
    const conv = Math.min(G.preventNextThreat, amount);
    amount -= conv;
    G.preventNextThreat -= conv;
    MC.log(G, '큰 힘에는 큰 책임 — 위협 ' + conv + ' 피해로 대체 (배치 취소)');
    if (amount <= 0){ if (G.preventNextThreat <= 0) delete G.preventNextThreat; return; }
    if (G.preventNextThreat <= 0) delete G.preventNextThreat;
  }
  // 신분 위협 방지 인터럽트 (제니퍼 왈터스 "I Object!": 알터에고, 라운드 1회, 1 방지)
  for (const pl of G.players){
    if (pl.eliminated) continue;
    const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    const def = MC.cardDef(faceCode);
    const tp = def && def.threatPrevent;
    if (!tp) continue;
    if (tp.form && pl.form !== tp.form) continue;
    if (tp.oncePerRound && pl.usedThreatPreventThisRound) continue;
    const prevent = Math.min(tp.amount || 1, amount);
    amount -= prevent;
    if (tp.oncePerRound) pl.usedThreatPreventThisRound = true;
    MC.log(G, MC.nameOf(pl) + ' — ' + (tp.name||'위협 방지') + ': 위협 ' + prevent + ' 방지');
    if (amount <= 0){ MC.log(G, MC.nameOf(s) + ' 위협 전량 방지됨'); return; }
  }
  // 플레이 영역 준비(Preparation) 위협 방지 — Counterintelligence(메인 스킴 위협 놓일 때 버림 → 3 방지 + Widowmaker).
  // 중앙 집계 인덱스 확장: upgrade의 threatPrevent{discardSelf:true} 스캔. 빌런 페이즈 흐름 보호 위해 Widowmaker는 빌런 직접 피해.
  if (s.isMain){
    for (const pl of G.players){
      if (pl.eliminated || amount <= 0) continue;
      if (pl.form !== 'hero') continue;
      for (const c of (pl.playArea.upgrades || []).slice()){
        if (amount <= 0) break;
        const cdef = MC.cardDef(c.defCode);
        const tp2 = cdef && cdef.threatPrevent;
        if (!tp2 || tp2.discardSelf !== true) continue;
        const prevent = Math.min(tp2.amount || 3, amount);
        amount -= prevent;
        MC.triggerPreparation(G, pl, c);
        if (G._widowmaker){ const w = G._widowmaker; G._widowmaker = null; if (G.villain) MC.applyDamage(G, G.villain, w.damage, { source:{ isPlayer:true }, isAttack:false }); }
        MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ': 메인 위협 ' + prevent + ' 방지');
        if (amount <= 0){ MC.log(G, MC.nameOf(s) + ' 위협 전량 방지됨'); return; }
      }
    }
  }
  s.threat += amount;
  // 사이드스킴 최대 위협 추적 (UI 위협바의 분모 — "남은 저지량" 표시용)
  if (!s.isMain) s.peakThreat = Math.max(s.peakThreat || 0, s.threat);
  MC.log(G, MC.nameOf(s) + ' 위협 +' + amount + ' (' + s.threat + '/' + (s.maxThreat||'∞') + ')');
  if (s.isMain && s.threat >= s.maxThreat) MC.onMainSchemeThreshold(G, s);
}
function removeThreat(G, schemeRef, amount){
  const s = MC.resolveScheme(G, schemeRef);
  // 파멸의 카운트다운(01139b) 등: 이 스킴에서는 위협을 제거할 수 없다.
  const sdef = MC.cardDef(s.defCode);
  if (sdef && sdef.threatCannotRemove){
    let blocked = true;
    // 조건부: {whileMinionInPlay:'abomination'} — 그 하수인이 전장에 있을 때만 제거 불가 (Total Destruction).
    if (typeof sdef.threatCannotRemove === 'object' && sdef.threatCannotRemove.whileMinionInPlay){
      const code = sdef.threatCannotRemove.whileMinionInPlay;
      blocked = G.players.some(pl => (pl.engagedMinions || []).some(m => m.defCode === code));
    }
    if (blocked){
      MC.log(G, MC.nameOf(s) + ' — 위협을 제거할 수 없다 (제거 불가 스킴)');
      return;
    }
  }
  const before = s.threat;
  s.threat = Math.max(0, s.threat - amount);
  MC.log(G, MC.nameOf(s) + ' 위협 -' + (before - s.threat) + ' (' + s.threat + ')');
  if (!s.isMain && s.threat === 0) MC.onSideSchemeCleared(G, s);
}
function resolveScheme(G, ref){
  if (ref === 'main' || !ref) return G.mainScheme;
  const ss = G.sideSchemes.find(s => s.uid === ref || s.code === ref);
  if (!ss) throw new Error('[resolveScheme] 스킴 없음: ' + ref);
  return ss;
}
function onSideSchemeCleared(G, s){
  G.sideSchemes = G.sideSchemes.filter(x => x !== s);
  MC.fireCardHook(G, s, 'whenCompleted', {}); // 사이드 스킴 "격퇴 시" 훅
  G.encounterDiscard.push(s);
  MC.log(G, MC.nameOf(s) + ' 격퇴');
}
function onMainSchemeThreshold(G, s){
  const def = MC.cardDef(s.defCode);
  if (def.nextStage) MC.advanceMainScheme(G);
  else MC.setGameOver(G, 'loss', '메인 스킴 완성', 'schemeComplete');
}
function advanceMainScheme(G){
  const old = G.mainScheme;
  MC.fireCardHook(G, old, 'whenCompleted', {});
  const next = MC.cardDef(old.defCode).nextStage;
  const ms = MC.makeInstance(G, next, { isMain: true });
  const def = MC.cardDef(next);
  const n = G.players.length;
  ms.threat = (def.baseThreatPerPlayer||0) * n + (def.baseThreat||0);
  ms.maxThreat = (def.maxThreatPerPlayer||0) * n + (def.maxThreat||0);
  G.mainScheme = ms;
  MC.log(G, '메인 스킴 전환 → ' + MC.nameOf(ms) + ' (' + ms.threat + '/' + ms.maxThreat + ')');
  // 공식 룰: 새 단계가 공개되면 그 면의 "공개 시" 효과 해결 (클로 01117 등)
  MC.fireCardHook(G, ms, 'whenRevealed', { player: G.players[G.firstPlayer] });
}

/* ── 공용 조우 헬퍼 (재사용 인덱스) ──
   revealSpecificSideScheme: 특정 사이드 스킴을 조우덱/버림에서 찾아 공개 + 조우덱 셔플.
     (클로 II "불멸의 클로", 지하 유통망 셋업 "방어망" 등이 이름으로 참조)
   discardUntilMinionIntoPlay: 조우덱에서 하수인이 나올 때까지 버림 →
     지정 플레이어(기본: 첫 플레이어)와 교전 상태로 "전장 배치"(put into play — 공개 아님,
     whenRevealed 미발화, 부스트★ 배치와 동일 규칙). traitFilter로 특성 제한 가능
     (마스터즈 오브 이블 01128 재사용 대비). */
function revealSpecificSideScheme(G, defCode){
  let inst = null;
  let i = G.encounterDeck.findIndex(c => c.defCode === defCode);
  if (i >= 0) inst = G.encounterDeck.splice(i, 1)[0];
  else {
    i = G.encounterDiscard.findIndex(c => c.defCode === defCode);
    if (i >= 0) inst = G.encounterDiscard.splice(i, 1)[0];
  }
  if (!inst){
    /* 조우덱 구성에 포함되지 않은 빌런 전용 사이드스킴(예: 불멸의 클로)은
       카드가 직접 이름으로 참조하므로 새 인스턴스를 생성해 공개한다. */
    inst = MC.makeInstance(G, defCode, {});
    if (!inst){ MC.log(G, '[' + defCode + '] 정의 없음 — 공개 불발'); return null; }
  }
  const pl = G.players[G.firstPlayer];
  resolveEncounterCard(G, pl, inst);
  MC.shuffle(G, G.encounterDeck);
  MC.log(G, MC.nameOf(inst) + ' 공개 — 조우덱 셔플');
  return inst;
}
function discardUntilMinionIntoPlay(G, pl, traitFilter){
  pl = pl || G.players[G.firstPlayer];
  let minion = null;
  let guard = G.encounterDeck.length + G.encounterDiscard.length + 1; // 하수인 부재 시 무한 방지
  while (guard-- > 0){
    const c = drawEncounterCard(G);
    if (!c) break;
    const ok = c.type === 'minion' && (!traitFilter || (c.traits || []).includes(traitFilter));
    if (ok){ minion = c; break; }
    G.encounterDiscard.push(c);
    MC.log(G, MC.nameOf(c) + ' 버림 (하수인 탐색 중)');
  }
  if (!minion){ MC.log(G, '조우덱에 ' + (traitFilter ? traitFilter + ' ' : '') + '하수인 없음 — 효과 불발'); return null; }
  minion.engagedWith = pl.uid;
  pl.engagedMinions.push(minion);
  MC.minionEnteredPlay(G, minion, pl);
  (G.revealLog = G.revealLog || []).push({ defCode: minion.defCode, name: minion.name, type: 'minion', player: pl.uid });
  MC.log(G, MC.nameOf(minion) + ' — 전장 배치 (' + pl.uid + '와 교전)');
  return minion;
}

/* 하수인 탐색 배치(덱+버림) — 조우덱과 버림 더미에서 (특성 일치) 하수인 1명을 찾아
   pl과 교전 상태로 전장에 놓고 조우덱 셔플. "search the encounter deck and discard pile
   for a [[X]] minion and put it into play engaged with you" (혼돈의 지배 01133 등) 범용. */
function searchMinionIntoPlay(G, pl, traitFilter, codeFilter){
  pl = pl || G.players[G.firstPlayer];
  const match = c => c.type === 'minion'
    && (!traitFilter || (c.traits || []).includes(traitFilter))
    && (!codeFilter || (c.defCode || c.code) === codeFilter);
  let minion = null;
  for (const src of [G.encounterDeck, G.encounterDiscard]){
    const i = src.findIndex(match);
    if (i >= 0){ minion = src.splice(i, 1)[0]; break; }
  }
  if (!minion && codeFilter){
    // 조우덱/버림에 없으면 정의로부터 생성(모듈러 셋업 미포함 시 대비) — 마담 히드라 등 named 소환.
    minion = MC.makeInstance(G, codeFilter, {});
    minion.type = 'minion';
    MC.log(G, MC.nameOf(minion) + ' — 정의로부터 소환');
  }
  if (!minion){
    MC.log(G, '조우덱/버림에 ' + (traitFilter ? traitFilter + ' ' : '') + '하수인 없음 — 탐색 불발');
    return null;
  }
  minion.engagedWith = pl.uid;
  pl.engagedMinions.push(minion);
  MC.minionEnteredPlay(G, minion, pl);
  (G.revealLog = G.revealLog || []).push({ defCode: minion.defCode, name: minion.name, type: 'minion', player: pl.uid });
  MC.shuffle(G, G.encounterDeck);
  MC.log(G, MC.nameOf(minion) + ' 탐색 — 전장 배치 (' + pl.uid + '와 교전) · 조우덱 셔플');
  return minion;
}

/* 하수인 연쇄 공격 체인(범용) — pairs: [{attackerUid, playerUid}, ...] 를 순서대로 처리.
   "각 X 하수인이 교전 중인 히어로를 공격한다" (혼돈의 지배 01133, 하일 히드라 03030 유형).
   기절 하수인은 공식 룰대로 기절 소모 후 공격 생략(공격 미개시로 집계). 죽은/사라진 공격자는 스킵.
   첫 유효 공격자에 대한 방어 pending을 세우고 남은 쌍을 pending.attackChain에 실어
   resolveDefensePending이 해소 후 다음 공격을 이어간다. 공격을 1개라도 개시하면 true. */
function startMinionAttackChain(G, pairs){
  const chain = (pairs || []).slice();
  while (chain.length){
    const { attackerUid, playerUid } = chain.shift();
    const attacker = MC.findByUid(G, attackerUid);
    const pl = G.players.find(x => x.uid === playerUid);
    if (!attacker || attacker.hp <= 0 || !pl || pl.eliminated) continue;
    if (attacker.status && attacker.status.stunned > 0){
      attacker.status.stunned--;
      MC.log(G, MC.nameOf(attacker) + ' 기절 소모 — 공격 생략');
      continue;
    }
    G.pending = {
      kind: 'defense',
      player: pl.uid,
      attackerUid: attacker.uid,
      amount: MC.enemyAtk(G, attacker),
      prevented: 0,
      piercing: !!attacker.piercing,
      attackChain: chain.length ? chain : undefined,
    };
    MC.log(G, MC.nameOf(attacker) + ' → ' + pl.uid + ' 공격 (피해 ' + (attacker.attack||0) + ') — 방어 선언 대기');
    return true;
  }
  return false;
}

/* ── 울트론 드론 서브시스템 (범용 환경 기반) ──
   드론 스탯은 droneStats를 가진 환경 카드(울트론 드론 01140)가 정의하고,
   환경 부착물의 droneStatBonus(업그레이드 드론 01142: ATK+1 HP+1)가 가산된다. */
function droneBaseStats(G){
  for (const e of (G.environments || [])){
    const d = MC.cardDef(e.defCode);
    if (!d || !d.droneStats) continue;
    const base = Object.assign({}, d.droneStats);
    for (const a of (e.attachments || [])){
      const ad = MC.cardDef(a.defCode);
      const b = ad && ad.droneStatBonus;
      if (b) for (const k in b) base[k] = (base[k] || 0) + b[k];
    }
    // 울트론 III(01136) droneBuffVillain: 빌런 지속 능력이 모든 드론에 ATK/HP 보너스.
    if (G.villain){
      const vb = MC.cardDef(G.villain.defCode).droneBuffVillain;
      if (vb) for (const k in vb) base[k] = (base[k] || 0) + vb[k];
    }
    return base;
  }
  // 환경이 없어도 빌런 지속 버프는 유효 (fallback 스탯에 얹기 위해 null 대신 버프만 반환하지 않음 —
  // 환경 없으면 배신/사이드스킴의 fallback이 스탯을 정하고, 그 위에 버프는 recalc 시 재적용).
  return null;
}

/* 뒷면 드론 스폰: pl 덱 맨 위 카드를 뒷면으로 뒤집어 드론 하수인으로 전장 배치 (교전).
   공식 울트론: 플레이어 덱 카드가 곧 드론 군단 — 처치 시 뒷면 카드는 소유자 버림 더미로. */
function spawnFacedownDrone(G, pl, fallbackStats){
  pl = pl || G.players[G.firstPlayer];
  const stats = droneBaseStats(G) || fallbackStats || null;
  if (!stats){ MC.log(G, '드론 환경 없음 — 드론 스폰 불발'); return null; }
  if (!pl.deck.length){ MC.log(G, pl.uid + ' 덱 소진 — 드론 스폰 불발'); return null; }
  const facedown = pl.deck.pop();
  const drone = MC.makeInstance(G, 'facedown-drone', {});
  drone.isDrone = true;
  drone.droneOwner = pl.uid;
  drone.facedownCard = facedown;
  drone.attack = stats.attack || 0;
  drone.scheme = stats.scheme || 0;
  drone.hp = drone.maxHp = stats.hp || 1;
  drone.engagedWith = pl.uid;
  pl.engagedMinions.push(drone);
  MC.minionEnteredPlay(G, drone, pl);
  (G.revealLog = G.revealLog || []).push({ defCode: 'facedown-drone', name: drone.name, type: 'minion', player: pl.uid });
  MC.log(G, MC.nameOf(drone) + ' 기동 — ' + pl.uid + ' 덱 맨 위 카드가 뒷면 드론으로 (' + pl.uid + '와 교전)');
  return drone;
}

/* 드론 스탯 재계산: 환경 부착물(업그레이드 드론) 부착/이탈 시 전장의 모든 뒷면 드론에 반영.
   HP는 받은 피해를 보존한 채 상한만 조정 — 상한 하락으로 HP 0 이하가 되면 즉시 격파. */
function recalcDroneStats(G){
  const stats = droneBaseStats(G);
  if (!stats) return;
  for (const pl of G.players){
    for (const m of pl.engagedMinions.slice()){
      if (!m.isDrone) continue;
      const dmg = (m.maxHp || 1) - (m.hp || 0);
      m.attack = stats.attack || 0;
      m.scheme = stats.scheme || 0;
      m.maxHp = stats.hp || 1;
      m.hp = m.maxHp - dmg;
      MC.log(G, MC.nameOf(m) + ' 스탯 갱신 — ATK ' + m.attack + ' · HP ' + m.hp + '/' + m.maxHp);
      if (m.hp <= 0) MC.onDefeated(G, m, {});
    }
  }
}

/* ── 빌런 페이즈: 스텝 큐 ── */
function startVillainPhase(G){
  G.phase = 'villain';
  G.revealLog = [];   // 이번 빌런 페이즈에 공개된 조우/부스트 카드 기록 (UI 확인용)
  for (const pl of G.players) pl._missionPrepUsed = false;   // 나타샤 Mission Prep 페이즈당 1회 리셋
  MC.fireHook(G, 'villainPhaseStart', {});
  G.vq = [{ op:'threat' }];
  for (const pl of MC.playersInOrder(G)) G.vq.push({ op:'activations', player: pl.uid });
  G.vq.push({ op:'dealEnc' }, { op:'reveal' }, { op:'endRound' });
  processVillainQueue(G);
}

/* 빌런 페이즈 스텝 1개만 실행 (단계별 진행 모드 — UI가 연출과 함께 순차 호출).
   결정성: dispatch된 villainStep 액션으로만 호출됨. */
function villainStepOnce(G){
  if (G.over) throw new Error('[villainStep] 게임 종료됨');
  if (G.phase !== 'villain') throw new Error('[villainStep] 빌런 페이즈 아님');
  if (G.pending) throw new Error('[villainStep] 대기 중인 결정 해소 필요');
  if (!G.vq.length) throw new Error('[villainStep] 남은 스텝 없음');
  execStep(G, G.vq.shift());
}

function processVillainQueue(G){
  if (G.villainStepMode) return;   // 단계별 진행 모드: UI가 villainStep으로 하나씩 실행
  while (G.vq.length && !G.over && !G.pending){
    const step = G.vq.shift();
    execStep(G, step);
    // 하수인 등장 반응(호크아이 등) — 스텝 중 하수인이 등장했으면 다음 스텝(활성화 등) 전에 선택 물어봄
    if (!G.pending && flushMinionReactions(G)) return;
  }
}

function execStep(G, step){
  switch (step.op){
    case 'threat': {
      // 공식 룰: 빌런 페이즈 1단계 메인 스킴 위협 = ①기본 상승(escalation, 인원수당 1) + ②가속.
      // ② 가속 = 전장의 사이드 스킴 가속 아이콘 합 + 누적 가속 토큰(덱 리셔플 등).
      //   ※ 메인 스킴의 accelIcons는 공식 escalation_threat(=기본 상승률)를 잘못 매핑한 값이라
      //      기본 상승(baseGain)에 이미 포함됨 → 여기서 다시 더하지 않는다(이중 계산 방지).
      const baseGain = G.players.length;                         // escalation: 인원수당 1 (표준)
      let accelIcons = 0;
      for (const s of (G.sideSchemes || [])){
        const sd = MC.cardDef(s.defCode);
        if (sd && sd.accelIcons) accelIcons += (sd.accelIcons === true ? 1 : sd.accelIcons);
      }
      const accelGain = accelIcons + G.acceleration;             // 가속 아이콘 + 누적 토큰
      // 동적 가속: 메인 스킴 def.accelFrom (뮤타젠 구름 2B = 전장 고블린 적 수)
      let dynAccel = 0;
      const msDef0 = MC.cardDef(G.mainScheme.defCode);
      if (msDef0 && msDef0.accelFrom === 'goblinEnemies' && MC.goblinEnemyCount) dynAccel = MC.goblinEnemyCount(G);
      const total = baseGain + accelGain + dynAccel;
      MC.log(G, '메인 스킴 위협: 기본 +' + baseGain + (accelGain>0 ? ' · 가속 +' + accelGain : '') + (dynAccel>0 ? ' · 고블린 +' + dynAccel : '') + ' = +' + total);
      placeThreat(G, 'main', total);
      // 노라드 습격(01138b) 강제반응: 빌런 페이즈 위협 후 각 플레이어 선택(위협2 or 드론).
      const msDef = MC.cardDef(G.mainScheme.defCode);
      // 어보밍맨 None Shall Pass: 빌런 페이즈 1단계 후 지연(delay) 카운터 +1 — 크로스본즈 도주 진행(추격 타이머).
      if (msDef && msDef.delayPerVillainPhase){
        G.mainScheme.delayCounters = (G.mainScheme.delayCounters || 0) + 1;
        MC.log(G, '⏱ 지연 카운터 +1 (누적 ' + G.mainScheme.delayCounters + ') — 크로스본즈가 멀어진다!');
      }
      // 졸라 섬/미친 박사(04112b/04113b): 빌런 페이즈 1단계 후 실험 카운터 +1. 3개 이상이면 조우덱에서 하수인이 나올 때까지 버리고 그 하수인을 첫 플레이어와 교전 배치 + 실험 카운터 3 제거.
      if (msDef && msDef.testPerVillainPhase){
        G.mainScheme.testCounters = (G.mainScheme.testCounters || 0) + 1;
        MC.log(G, '🧪 실험 카운터 +1 (누적 ' + G.mainScheme.testCounters + ') — 졸라의 실험이 진행된다');
        if (G.mainScheme.testCounters >= 3){
          const pl = G.players[G.firstPlayer];
          const m = MC.discardUntilMinionIntoPlay ? MC.discardUntilMinionIntoPlay(G, pl, null) : null;
          if (m){
            G.mainScheme.testCounters -= 3;
            MC.log(G, '🧪 실험 카운터 3 도달 → 하수인 소환, 실험 카운터 3 제거 (잔여 ' + G.mainScheme.testCounters + ')');
          }
        }
      }
      if (msDef && msDef.forcedThreatChoice){
        G._pendingThreatChoice = MC.playersInOrder(G).filter(p => !p.eliminated).map(p => p.uid);
        if (flushThreatChoice(G)) return;   // 첫 플레이어 선택 pending — 큐 정지
      }
      break;
    }
    case 'activations': { // 실행 시점에 라이브 조회로 확장 (교전 하수인 변동 대응)
      const pl = G.players.find(p => p.uid === step.player);
      if (!pl || pl.eliminated) break;
      const acts = [{ op:'act', enemyUid: G.villain.uid, player: pl.uid }];
      for (const m of pl.engagedMinions) acts.push({ op:'act', enemyUid: m.uid, player: pl.uid });
      G.vq.unshift(...acts);
      break;
    }
    case 'act': {
      const pl = G.players.find(p => p.uid === step.player);
      const enemy = MC.findByUid(G, step.enemyUid);
      if (!pl || pl.eliminated || !enemy || enemy.hp <= 0) break;
      enemyActivation(G, enemy, pl);
      break;
    }
    case 'dealEnc': {
      for (const pl of MC.playersInOrder(G)) dealEncounterTo(G, pl, 1);
      // 위험(Hazard): 전장의 hazard 사이드 스킴 1장당 빌런 페이즈에 조우 카드 +1 (범용).
      const order = MC.playersInOrder(G);
      let hz = 0;
      for (const s of (G.sideSchemes || [])){
        const sd = MC.cardDef(s.defCode);
        if (sd && sd.hazard){ dealEncounterTo(G, order[hz % order.length], 1); hz++; }
      }
      if (hz > 0) MC.log(G, '위험(Hazard) — 조우 카드 +' + hz);
      break;
    }
    case 'reveal':
      revealPendingEncounters(G);
      break;
    case 'resumeReveal': {
      // 인터럽트 정지점 해소 후 그 조우 카드의 처리를 재개 (interruptChecked=true라 재체크 안 함)
      const pl = G.players.find(p => p.uid === step.player);
      const inst = MC.findByUid(G, step.uid);
      if (pl && inst) resolveEncounterCard(G, pl, inst);
      break;
    }
    case 'endRound':
      G.villainStepMode = false;   // 단계별 진행 모드 종료
      MC.fireHook(G, 'endOfPhase', { phase:'villain' });
      MC.rotateFirstPlayer(G);
      MC.fireHook(G, 'endOfRound', {});
      G.round++;
      for (const pl of G.players){
        pl.usedHeroAbilityThisRound = false;
        pl.usedResourceAbilityThisRound = false;
        pl.usedIdentityActionThisRound = {};
        pl.usedIdentityActionThisPhase = {};   // 페이즈당 1회 신분 액션 (호크아이 Weapon of Choice)
        pl.usedIdentityEngageThisPhase = {};   // 페이즈당 1회 신분 교전 반응 (토르 Have at thee!)
        pl.usedLivingLegendThisRound = false;
        pl.usedThreatPreventThisRound = false;
        pl.formChangedThisRound = false;
        pl.eventsUsedThisRound = {};
        pl._missionPrepUsed = false;   // 나타샤 Mission Prep — 다음 라운드 hero 페이즈용 리셋
        // 라운드 지속 스탯 버프(사기 증진 등) — 라운드 종료 시 소멸. 히어로 + 동료 모두.
        if (pl.roundStatBonus) pl.roundStatBonus = {};
        for (const a of pl.playArea.allies) if (a.roundStatBonus) a.roundStatBonus = {};
        // 카드별 라운드당 1회 능력 리셋 (비전 등)
        for (const arr of [pl.playArea.allies, pl.playArea.supports, pl.playArea.upgrades])
          for (const c of arr) if (c.usedAbilityThisRound) c.usedAbilityThisRound = false;
        // 에디슨의 거대 로봇(05028) 무효화(nullifiedThisPhase) 리셋 — 무효화는 페이즈 한정
        for (const m of (pl.engagedMinions || [])) if (m.nullifiedThisPhase) m.nullifiedThisPhase = false;
        // ★ 준비(ready)는 여기서 하지 않는다 (공식 RRG). 준비/드로우는 플레이어 페이즈 종료(endPlayerPhase)에서만 일어난다.
        //   → 빌런 페이즈에 방어 등으로 소진한 카드는 다음 플레이어 페이즈 내내 소진 상태로 남아야 함 (방어의 대가).
      }
      G.phase = 'player';
      MC.fireHook(G, 'playerPhaseStart', {});
      break;
    default: throw new Error('[execStep] 미등록 스텝: ' + step.op);
  }
}

/* 적(하수인/빌런)의 부착물 중 공격 인터럽트(attachAttackInterrupt)를 가진 것을 발화.
   부착물이 공격을 "대체"하면 true 반환 → 호출측(enemyActivation)은 활성화를 중단한다.
   범용: webbed-up처럼 "부착된 적이 공격할 때" 발동하는 부착물에 재사용. */
function fireAttachAttackInterrupt(G, enemy, pl){
  const atts = (enemy.attachments || []).slice();
  for (const att of atts){
    const def = MC.cardDef(att.defCode);
    const hname = def && def.attachAttackInterrupt;
    if (!hname) continue;
    const fn = MC.HANDLERS[hname];
    if (!fn) throw new Error('[fireAttachAttackInterrupt] 미등록 handler: ' + hname);
    const res = fn(G, { self: att, enemy, player: pl, attachment: att });
    if (res === true) return true;   // 공격 대체됨 — 활성화 중단
  }
  return false;
}
function enemyActivation(G, enemy, pl){
  const isVillain = enemy.kind === 'villain';
  // ★ 공식 RRG 2.4.5: 알터에고 폼 상대로는 빌런·하수인 모두 암약(스킴).
  //   히어로 폼 상대로만 공격.
  if (pl.form === 'hero'){
    if (enemy.status.stunned > 0){
      enemy.status.stunned--;
      MC.log(G, MC.nameOf(enemy) + ' 기절 소모 — 공격 생략');
      return;
    }
    // 부착물 기반 공격 인터럽트 (webbed-up 등): 부착물이 공격을 대체하면 활성화 중단
    if (fireAttachAttackInterrupt(G, enemy, pl)) return;
    // ★ 노먼 오스본 attackToCounter: 공격하려 할 때 → 공격 대신 악명 카운터 +N 배치.
    //   실제 공격 미발동 → 방어 pending·부스트·공격 트리거 전부 미발생 (룰북 준수).
    if (isVillain){
      const vd = MC.cardDef(enemy.defCode);
      if (vd && vd.attackToCounter && MC.goblinAddCounter){
        const amt = vd.attackToCounter.amount || 1;
        MC.log(G, MC.nameOf(enemy) + ' — 공격 대신 악명 카운터 +' + amt);
        G.fxGoblinCounter = { targetUid: enemy.uid, op:'add', amount: amt, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        MC.goblinAddCounter(G, amt);
        return;
      }
    }
    // 울트론 II 강제 개입(01135): 공격 시 뒷면 드론 스폰 (그 후 ATK가 교전 드론 수만큼 증가).
    if (isVillain && MC.cardDef(enemy.defCode).villainAttackSpawnDrone){
      MC.log(G, MC.nameOf(enemy) + ' — 강제 개입: 공격과 함께 드론 증원');
      MC.spawnFacedownDrone(G, pl, { attack:1, scheme:1, hp:1 });
    }
    // ★ 룰북 순서: 부스트 카드는 뒷면으로 배분 — 방어 선언 후에 공개·적용
    let boostCard = null;
    let extraBoostCards = null;
    if (isVillain){
      boostCard = drawEncounterCard(G);
      // 강제 난입(공격 추가 부스트): 클로 villainAttackExtraBoost + 부착물(Hysteria grantsExtraBoost) 집계
      const vdef = MC.cardDef(enemy.defCode);
      const extra = MC.villainExtraBoost ? MC.villainExtraBoost(G, 'attack') : (vdef.villainAttackExtraBoost || 0);
      if (extra > 0){
        extraBoostCards = [];
        for (let i = 0; i < extra; i++){
          const bc = drawEncounterCard(G);
          if (bc) extraBoostCards.push(bc);
        }
        if (extraBoostCards.length)
          MC.log(G, MC.nameOf(enemy) + ' — 강제 난입: 부스트 카드 ' + extraBoostCards.length + '장 추가');
      }
    }
    // 빌런 부착물 공격 시 강제 인터럽트 (크로스본즈의 기관총: 탄약 소모 + 조우덱 부스트 피해)
    if (isVillain){
      for (const att of (enemy.attachments || [])){
        const ad = MC.cardDef(att.defCode);
        if (ad && ad.attackForcedInterrupt){
          if (ad.useCounter){ if ((att.counters || 0) < ad.useCounter) continue; att.counters -= ad.useCounter; }
          MC.runEffectList(G, ad.attackForcedInterrupt, { player: pl, self: att, card: att });
        }
      }
    }
    // 방어 선언 대기 (amount = 기본 ATK만. 부스트는 pending에 뒷면 보관)
    // 울트론 II(01135) attackBonusPerDrone: 교전 중인 Drone 수만큼 이 공격의 ATK 증가 (드론 스폰 후 계산).
    let atkAmount = MC.enemyAtk(G, enemy);
    if (isVillain && MC.cardDef(enemy.defCode).attackBonusPerDrone){
      const drones = pl.engagedMinions.filter(m => m.isDrone || (m.traits||[]).includes('drone')).length;
      if (drones > 0){
        atkAmount += drones;
        MC.log(G, MC.nameOf(enemy) + ' — 교전 드론 ' + drones + '명, 이 공격 ATK +' + drones + ' = ' + atkAmount);
      }
    }
    G.pending = {
      kind: 'defense',
      player: pl.uid,
      attackerUid: enemy.uid,
      amount: atkAmount,
      prevented: 0,
      piercing: !!enemy.piercing || (isVillain && ((MC.cardDef(enemy.defCode).piercingWhileWeapon && (enemy.attachments || []).some(a => (MC.cardDef(a.defCode).traits || []).includes('weapon'))) || (enemy.attachments || []).some(a => MC.cardDef(a.defCode).grantsPiercing))),   // 크로스본즈 Weapon 관통 / Combat Knife grantsPiercing
      boostCard: boostCard || undefined,   // 직렬화 안전 (인스턴스 = 순수 데이터)
      extraBoostCards: (extraBoostCards && extraBoostCards.length) ? extraBoostCards : undefined,
    };
    // 뮤타젠 그린 고블린 강제반응: 공격이 피해를 입히면 메인 스킴에 위협 배치 (attackThreatOnDamage)
    if (isVillain){
      const vdef2 = MC.cardDef(enemy.defCode);
      if (vdef2 && vdef2.attackThreatOnDamage) G.pending.threatOnDamage = vdef2.attackThreatOnDamage;
    }
    // 강제 난입 (회오리바람 forcedAttackEachHero): 공격이 다른 모든 히어로에게도 순차 적용.
    // pending.alsoAttack에 남은 히어로 uid들을 담아, 방어 해소 후 체인으로 다음 방어 pending 생성.
    if (!isVillain){
      const fi = MC.cardDef(enemy.defCode).forcedInterrupt;
      if (fi === 'fi_attackEachHero'){
        const others = MC.playersInOrder(G).filter(p => p.uid !== pl.uid && !p.eliminated && p.form === 'hero');
        if (others.length) G.pending.alsoAttack = others.map(p => p.uid);
      }
      // 데이터 방식 forcedInterrupt({effect}) — 바론 모르도: 공격 시 대상 덱 버림 → 자원별 효과.
      else if (fi && fi.effect){
        MC.log(G, MC.nameOf(enemy) + ' — 강제 인터럽트 발동');
        MC.runEffectList(G, fi.effect, { player: pl, self: enemy, card: enemy });
      }
      // 멜터 지속 효과: 교전 영웅은 가능하면 동료로 반드시 방어 (forceAllyDefend).
      // 준비된 동료가 있으면 pending에 mustDefendWithAlly 마커 → UI가 신분/무방어 옵션 차단.
      if (MC.cardDef(enemy.defCode).forceAllyDefend){
        const hasReadyAlly = pl.playArea.allies.some(a => !a.exhausted);
        if (hasReadyAlly) G.pending.mustDefendWithAlly = true;
      }
    }
    // 하수인 공격 연출·대사 힌트 (UI가 vfx.attack + attack 대사 재생). 빌런은 별도 처리.
    if (!isVillain){
      G.fxMinionAttack = { defCode: enemy.defCode, attackerUid: enemy.uid,
                           targetUid: pl.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
    MC.log(G, MC.nameOf(enemy) + ' → ' + pl.uid + ' 공격 (피해 ' + G.pending.amount +
      (boostCard ? ' + 부스트 ?' : '') + ') — 방어 선언 대기');
    // 부착물 공격 보정 (돌진 등): 과잉살상 부여 + 공격 종료 후 버림 예약 (강제 개입)
    for (const att of (enemy.attachments || [])){
      const adef = MC.cardDef(att.defCode);
      if (!adef) continue;
      if (adef.grantOverkillOnAttack){
        G.pending.overkill = true;
        MC.log(G, MC.nameOf(att) + ' — 이 공격은 과잉살상을 얻습니다');
      }
      if (adef.discardAfterAttack)
        (G.pending.discardAfterAttack = G.pending.discardAfterAttack || []).push(att.uid);
    }
    // 공격 개시 인터럽트 (Spider-Sense 등): 대상 플레이어의 신분 카드 훅 발화
    MC.fireAttackInterrupt(G, pl, enemy);
  } else {
    if (enemy.status.confused > 0){
      enemy.status.confused--;
      MC.log(G, MC.nameOf(enemy) + ' 혼란 소모 — 스킴 생략');
      return;
    }
    // ★ 그린 고블린 schemeToCounter: 스킴하려 할 때 → 스킴 대신 광기 카운터 -N 제거.
    //   실제 스킴 미발동 → 위협·부스트·스킴 트리거 전부 미발생 (룰북 준수).
    if (isVillain){
      const vd = MC.cardDef(enemy.defCode);
      if (vd && vd.schemeToCounter && MC.goblinRemoveCounter){
        const amt = vd.schemeToCounter.amount || 1;
        MC.log(G, MC.nameOf(enemy) + ' — 스킴 대신 광기 카운터 -' + amt);
        G.fxGoblinCounter = { targetUid: enemy.uid, op:'remove', amount: amt, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        MC.goblinRemoveCounter(G, amt);
        return;
      }
    }
    let boost = 0, boostCard = null;
    const extraSchemeBoosts = [];
    if (isVillain){
      boostCard = drawEncounterCard(G);
      boost = boostCard ? MC.boostOf(G, boostCard, pl) : 0;
      if (boostCard){
        (G.revealLog = G.revealLog || []).push({ defCode: boostCard.defCode, name: boostCard.name, type: 'boost', boost, player: pl.uid });
        MC.log(G, '부스트 카드: ' + MC.nameOf(boostCard) + ' (부스트 +' + boost + ')');
      }
      // 추가 부스트(스킴): 부착물 Hysteria(grantsExtraBoost) — 공개·아이콘 합산
      const extraS = MC.villainExtraBoost ? MC.villainExtraBoost(G, 'scheme') : 0;
      for (let i = 0; i < extraS; i++){
        const bc = drawEncounterCard(G);
        if (!bc) break;
        const b2 = MC.boostOf(G, bc, pl);
        boost += b2;
        extraSchemeBoosts.push(bc);
        (G.revealLog = G.revealLog || []).push({ defCode: bc.defCode, name: bc.name, type: 'boost', boost: b2, player: pl.uid, extra: true });
        MC.log(G, '추가 부스트 카드(스킴): ' + MC.nameOf(bc) + ' (+' + b2 + ')');
      }
    }
    placeThreat(G, 'main', (enemy.scheme || 0) + (MC.enemySchemePassive ? MC.enemySchemePassive(G, enemy) : 0) + boost);
    // 저지됐다!(foiled)용: 이번 음모의 부스트 아이콘 위협분 추적 → 손패 인터럽트로 소급 취소 가능.
    if (boost > 0) G._lastSchemeBoost = { schemeRef: 'main', boost: boost };
    // 추가 부스트 카드들 부스트★ 처리 + 버림
    for (const bc of extraSchemeBoosts){
      const placedE = MC.resolveBoostStar(G, pl, bc, 'scheme');
      if (!placedE) G.encounterDiscard.push(bc);
    }
    if (boostCard){
      const placed = MC.resolveBoostStar(G, pl, boostCard, 'scheme');
      if (!placed) G.encounterDiscard.push(boostCard);
      // UI 힌트: 스킴 부스트 공개 시퀀스 (무엇을 뽑았고 무슨 옵션이 발동했는지)
      G.fxBoostReveal = { kind: 'scheme', attackerName: MC.nameOf(enemy),
        base: enemy.scheme || 0, boostTotal: boost,
        events: [{ defCode: boostCard.defCode, name: boostCard.name,
          boost, extra: false, star: G._lastBoostStar || undefined }],
        seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
    // ★ 빌런 활성화 후 특성 분기 (04078 어보밍맨 III): 스킴 활성화 완료 후 발동.
    if (isVillain && MC.villainActivateResponse) MC.villainActivateResponse(G, pl);
    // 지연된 부스트★ 선택(안드로이드 효율 등): 암약 처리 종료 후 여기서 pending을 세운다.
    // (pending이 서면 enemyActivation 반환 → processVillainQueue가 큐를 멈춘다.)
    flushDeferredBoostChoice(G);
  }
}

/* 무피해 방어 후 반응 중앙 스캔 — 히어로 방어로 피해 0일 때 발동.
   업그레이드의 afterDefendNoDamage 필드({exhaustSelf?, discardSelf?, effect}) 스캔.
   침착함(unflappable: 드로우+버림) / 무시 못할 존재(hard-to-ignore: 위협 제거+소진) 등 재사용. */
MC.scanAfterDefendNoDamage = function(G, pl){
  const ups = (pl.playArea.upgrades || []).slice();
  for (const u of ups){
    const d = MC.cardDef(u.defCode);
    const h = d && d.afterDefendNoDamage;
    if (!h) continue;
    if (h.exhaustSelf){ if (u.exhausted) continue; u.exhausted = true; }
    MC.log(G, MC.nameOf(u) + ' — 무피해 방어 반응 발동');
    MC.runEffectList(G, h.effect || [], { player: pl, self: u, card: u });
    if (h.discardSelf){
      const i = pl.playArea.upgrades.indexOf(u);
      if (i >= 0) pl.playArea.upgrades.splice(i, 1);
      MC.moveToDiscard(G, pl, u, {});
    }
  }
};

/* 방어 선언 해소 — 액션 resolveDefense에서 호출.
   defender: 'none' | 'identity' | 동료 uid */
function resolveDefensePending(G, playerUid, defender){
  const p = G.pending;
  if (!p || p.kind !== 'defense') throw new Error('[resolveDefense] 대기 중인 방어 없음');
  if (p.player !== playerUid) throw new Error('[resolveDefense] 방어 주체 불일치: ' + playerUid);
  const pl = G.players.find(x => x.uid === playerUid);
  const attacker = MC.findByUid(G, p.attackerUid);
  // 멜터 지속 효과: mustDefendWithAlly면 준비된 동료가 있는 한 신분/무방어 선택 불가 (동료로 방어 강제)
  if (p.mustDefendWithAlly && (defender === 'identity' || defender === 'none')){
    const hasReadyAlly = pl.playArea.allies.some(a => !a.exhausted);
    if (hasReadyAlly) throw new Error('[resolveDefense] 멜터 — 가능하면 동료로 방어해야 함');
  }
  // ★ 룰북 순서: 방어 선언이 확정된 "후" 부스트 카드 공개 + 아이콘 적용
  //   (검증 실패 시 throw로 공개 전에 중단되도록, 검증 먼저)
  if (defender === 'identity'){
    if (pl.form !== 'hero') throw new Error('[resolveDefense] 알터에고는 신분 방어 불가');
    if (pl.exhausted) throw new Error('[resolveDefense] 소진 상태로 방어 불가');
  } else if (defender !== 'none'){
    const ally0 = pl.playArea.allies.find(a => a.uid === defender);
    if (!ally0) throw new Error('[resolveDefense] 동료 없음: ' + defender);
    if (ally0.exhausted) throw new Error('[resolveDefense] 소진된 동료로 방어 불가');
  }
  let boost = 0;
  const boostEvents = [];   // UI 부스트 공개 시퀀스용 (무엇을 뽑았고 무슨 옵션이 발동했는지)
  if (p.boostCard){
    boost = MC.boostOf(G, p.boostCard, pl);
    (G.revealLog = G.revealLog || []).push({ defCode: p.boostCard.defCode, name: p.boostCard.name, type: 'boost', boost, player: playerUid });
    MC.log(G, '부스트 카드 공개: ' + MC.nameOf(p.boostCard) + ' (+' + boost + ')');
    // 부스트★ 효과 (무기 밀매상 전장 배치 등): 배치되면 버리지 않음
    const placed = MC.resolveBoostStar(G, pl, p.boostCard, 'attack');
    if (!placed) G.encounterDiscard.push(p.boostCard);
    boostEvents.push({ defCode: p.boostCard.defCode, name: p.boostCard.name,
      boost: MC.boostOf(G, p.boostCard, pl), extra: false, star: G._lastBoostStar || undefined });
  }
  // 클로 강제 난입 추가 부스트 카드(들): 각각 공개·아이콘 합산·부스트★·버림
  if (p.extraBoostCards){
    for (const bc of p.extraBoostCards){
      const b2 = MC.boostOf(G, bc, pl);
      boost += b2;
      (G.revealLog = G.revealLog || []).push({ defCode: bc.defCode, name: bc.name, type: 'boost', boost: b2, player: playerUid, extra: true });
      MC.log(G, '추가 부스트 카드 공개: ' + MC.nameOf(bc) + ' (+' + b2 + ')');
      const placed2 = MC.resolveBoostStar(G, pl, bc, 'attack');
      if (!placed2) G.encounterDiscard.push(bc);
      boostEvents.push({ defCode: bc.defCode, name: bc.name,
        boost: b2, extra: true, star: G._lastBoostStar || undefined });
    }
  }
  // UI 힌트: 부스트 공개 시퀀스 오버레이 (플립 애니메이션 + 발동 옵션 표시)
  if (boostEvents.length){
    G.fxBoostReveal = { kind: 'attack', attackerName: attacker ? MC.nameOf(attacker) : '적',
      base: p.amount || 0, boostTotal: boost, events: boostEvents,
      seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  }
  const total = Math.max(0, (p.amount || 0) + boost - (p.prevented || 0));
  const pierce = !!p.piercing;
  if (p.prevented) MC.log(G, '피해 방지 적용: -' + p.prevented);
  // 실제로 피해를 입은 대상·피해량 추적 (빌런 부착물 "공격 후" 강제반응용 — 소닉 컨버터 등)
  let dmgTarget = null, dmgDone = 0;
  let defenderChar = null;   // 이 공격에서 "공격받은" 캐릭터 (보복 주체) — 방어자 기준
  if (defender === 'none'){
    defenderChar = pl;
    if (total > 0){ MC.applyDamage(G, pl, total, { source: attacker, isAttack: true, piercing: pierce, noRetaliate: true }); dmgTarget = pl; dmgDone = total; }
    else MC.log(G, '피해 전량 방지 — 무피해');
  } else if (defender === 'identity'){
    pl.exhausted = true;
    const def = MC.statOf(G, pl, 'defense') || 0;
    const dmg = Math.max(0, total - def);
    defenderChar = pl;
    MC.log(G, pl.uid + ' 방어 선언 (DEF ' + def + ')');
    if (dmg > 0){ MC.applyDamage(G, pl, dmg, { source: attacker, isAttack: true, defended: true, piercing: pierce, noRetaliate: true }); dmgTarget = pl; dmgDone = dmg; }
    else {
      if (p.readyIfNoDamage){ pl.exhausted = false; MC.log(G, '필사의 방어 — 무피해, 히어로 재준비'); }
      MC.scanAfterDefendNoDamage(G, pl);
    }
  } else {
    const ally = pl.playArea.allies.find(a => a.uid === defender);
    ally.exhausted = true;
    defenderChar = ally;
    MC.log(G, MC.nameOf(ally) + ' 동료 방어');
    const allyHpBefore = ally.hp;
    const allyHadTough = !!(ally.status && ally.status.tough > 0);
    if (total > 0){ MC.applyDamage(G, ally, total, { source: attacker, isAttack: true, defended: true, piercing: pierce, noRetaliate: true }); dmgTarget = ally; dmgDone = allyHadTough ? 0 : total; }
    // 과잉살상(빌런 공격 — 돌진 등): 동료 초과 피해를 그 동료의 컨트롤러에게.
    // 강인으로 전량 무효된 경우 초과 없음 (단 관통 시엔 강인 무시라 초과 발생)
    if (p.overkill && (pierce || !allyHadTough) && total > allyHpBefore){
      const excess = total - allyHpBefore;
      MC.log(G, '과잉살상 — 동료 초과 피해 ' + excess + ' → ' + pl.uid);
      MC.applyDamage(G, pl, excess, { source: attacker, isAttack: true, piercing: pierce });
    }
  }
  // ★ 보복(Retaliate): 공격받은 캐릭터가 살아남았으면 피해량과 무관하게 공격자에게 발동
  //   (공식 룰: 트리거는 "공격받음" — 방어로 0피해·강인 흡수여도 발동). applyDamage엔 noRetaliate로
  //   위임을 막고 여기서 일괄 처리 → 중복 발동 없음. (BP 신분 방어 시 역습 미발동 버그 수정)
  if (defenderChar && attacker) MC.triggerRetaliate(G, defenderChar, attacker);
  // 카운터 펀치 등 "방어 후 반응"을 위한 힌트: 히어로가 방어한 경우(identity) 그 공격자 기록.
  // (동료 방어는 "your hero defends"가 아니므로 제외)
  if (defender === 'identity' && attacker){
    pl.justDefendedAgainst = attacker.uid;
  } else {
    delete pl.justDefendedAgainst;
  }
  // "공격 종료 후 이 카드를 버립니다" (discardAfterAttack — 돌진): 스탯 원복 후 조우 버림
  if (p.discardAfterAttack && attacker){
    for (const auid of p.discardAfterAttack){
      const att = (attacker.attachments || []).find(a => a.uid === auid);
      if (!att) continue;
      MC.detachFrom(G, att);
      G.encounterDiscard.push(att);
      MC.log(G, MC.nameOf(att) + ' — 공격 종료, 버림');
      G.fxAttachSpent = { defCode: att.defCode, targetUid: attacker.uid,
                          seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
  }
  // 히어로가 이 공격으로 받은 피해 기록 (You'll Pay for That!: 받은 피해당 위협 제거)
  if (dmgTarget === pl) pl.lastDamageTaken = dmgDone;
  // 공격이 피해를 입혔을 때 메인 스킴 위협 배치 (클로의 복수 히어로 분기 등, threatOnDamage)
  if (p.threatOnDamage && dmgDone > 0){
    MC.placeThreat(G, 'main', p.threatOnDamage);
    MC.log(G, '피해 발생 — 메인 스킴 위협 +' + p.threatOnDamage);
  }
  // 이 공격이 임계 이상 피해를 입히면 조우 카드 1장 추가 공개(surge) — Overconfidence 히어로 분기.
  if (p.surgeIfDamageGTE && dmgDone >= p.surgeIfDamageGTE){
    MC.log(G, '공격 피해 ' + dmgDone + ' ≥ ' + p.surgeIfDamageGTE + ' — 급증(surge): 조우 카드 1장 추가');
    dealEncounterTo(G, pl, 1);
  }
  // 공격이 준 피해 1당 활성 플레이어 덱 맨 위 카드 1장 버림 (울트론의 분노 히어로 분기, discardDeckPerDamage)
  if (p.discardDeckPerDamage && dmgDone > 0){
    G._lastDamageDealt = dmgDone;
    MC.discardTopOfDeck(G, pl, dmgDone);
  }
  // 공격이 피해를 입혔을 때 그 대상 기절 (쇄도 등 stunOnHit 배신/공격 · 또는 공격자 def의 stunOnDamage=Scorpion). 범용.
  const attackerStunsOnDamage = attacker && (MC.cardDef(attacker.defCode) || {}).stunOnDamage;
  if ((p.stunOnHit || attackerStunsOnDamage) && dmgTarget && dmgDone > 0){
    MC.setStatus(G, dmgTarget, 'stunned', true);
    MC.log(G, MC.nameOf(dmgTarget) + ' — 공격 피해로 기절');
  }
  // 부스트 카드의 "피해 시" 부스트★ 효과 (소닉 붐: 이 활성화가 피해를 주면 히어로 소진).
  // 즉시 실행되는 boostStarEffect와 달리, 공격이 실제 피해를 준 후에만 발동 (범용, 데이터 effects).
  if (dmgDone > 0){
    for (const ev of boostEvents){
      const bdef = MC.cardDef(ev.defCode);
      if (bdef && bdef.boostStarOnDamage){
        MC.runEffectList(G, bdef.boostStarOnDamage, { player: pl, self: dmgTarget, card: bdef });
        MC.log(G, MC.nameOf(bdef) + ' 부스트★ — 피해 발생으로 효과 발동');
      }
    }
  }
  // 공격자(빌런/하수인) 부착물의 "공격+피해 후" 강제반응 (attackDamagedResponse).
  // 공식 "After [attacker] attacks and damages a character" — 실제 피해가 든 경우만.
  // 소닉 컨버터(01118): 데미지 입힌 캐릭터를 기절. 대상은 dmgTarget(히어로 또는 방어 동료).
  if (attacker && dmgTarget && dmgDone > 0){
    for (const att of (attacker.attachments || [])){
      const adef = MC.cardDef(att.defCode);
      const h = adef && adef.attackDamagedResponse;
      if (h && MC.HANDLERS[h]) MC.HANDLERS[h](G, { player: pl, target: dmgTarget, attacker, self: att });
    }
    // 공격자 자신의 "공격+피해 후" 효과 (attackDamagedEffects) — Tombstone: 자원 버림.
    const selfDef = MC.cardDef(attacker.defCode);
    if (selfDef && selfDef.attackDamagedEffects){
      MC.runEffectList(G, selfDef.attackDamagedEffects, { player: pl, self: attacker, card: attacker, target: dmgTarget, attacker });
    }
  }
  // 빌런 부착물의 "공격 후" 강제반응 (attackResponseEffects) — 피해 여부 무관 (Pumpkin Bombs).
  //   공식 "After the villain attacks you" — 방어 대상 플레이어(pl)에게 발화. 부착물 버림 등으로
  //   attachments가 변하므로 복사본을 순회한다.
  if (attacker && attacker.kind === 'villain'){
    for (const att of [...(attacker.attachments || [])]){
      const adef = MC.cardDef(att.defCode);
      if (adef && adef.attackResponseEffects){
        MC.runEffectList(G, adef.attackResponseEffects, { player: pl, self: att, card: att, target: pl });
      }
    }
  }
  // 하수인 공격 후 강제 반응 (forcedResponse): 라디오액티브 맨 = 공격 후 손패 무작위 1장 버림.
  // 공식 "After ... attacks you" — 피해 여부 무관, 방어 대상 플레이어에게 발화. (빌런은 제외)
  if (attacker && attacker.kind !== 'villain' && attacker.type === 'minion'){
    const adef = MC.cardDef(attacker.defCode);
    const fr = adef && adef.forcedResponse;
    if (fr && MC.HANDLERS[fr]){
      MC.HANDLERS[fr](G, { player: pl, self: attacker, card: attacker, attacker });
    }
    // 데이터 기반 강제 반응: def.forcedResponseEffects 배열을 runEffectList로 실행 (욘-로그 01177 등).
    if (adef && adef.forcedResponseEffects){
      MC.runEffectList(G, adef.forcedResponseEffects, { player: pl, self: attacker, card: attacker, attacker });
    }
  }
  // 하수인 무방어 공격 후 강제 반응 (하이드라 화염병: 통제 서포트 버림). afterUndefendedAttack.
  if (defender === 'none' && attacker){
    const aud = MC.cardDef(attacker.defCode);
    if (aud && aud.afterUndefendedAttack){
      MC.runEffectList(G, aud.afterUndefendedAttack, { player: pl, self: attacker, card: attacker });
    }
  }
  // ★ 어보밍맨 환경 미방어 반응 (범용 인덱스): 빌런이 미방어 공격한 후 전장 환경 카드들의
  //   envUndefendedResponse를 발동. 메인 스킴 지연(delay) 카운터 5+면 값 2배(delayScale).
  //   환경 4종(숲=간접피해/언덕=위협/바위=빌런회복/시설=자원버림)이 값·타입만 다른 변형이므로 데이터로 표현.
  if (defender === 'none' && attacker && attacker.kind === 'villain'){
    const delay = (G.mainScheme && G.mainScheme.delayCounters) || 0;
    for (const env of (G.environments || [])){
      const r = MC.cardDef(env.defCode).envUndefendedResponse;
      if (!r) continue;
      const amt = (r.delayScale && delay >= 5) ? r.delayScale : (r.amount || 1);
      const en = MC.nameOf(env);
      if (r.type === 'damage'){
        MC.applyDamage(G, pl, amt, { source: attacker, indirect: true });
        MC.log(G, en + ' — 미방어 반응: ' + pl.uid + ' 간접 피해 ' + amt);
      } else if (r.type === 'threat'){
        MC.placeThreat(G, 'main', amt);
        MC.log(G, en + ' — 미방어 반응: 메인 스킴 위협 +' + amt);
      } else if (r.type === 'healVillain'){
        MC.runEffectList(G, [{ fx: 'healVillain', amount: amt }], { player: pl, self: attacker, card: attacker });
        MC.log(G, en + ' — 미방어 반응: 어보밍맨 회복 ' + amt);
      } else if (r.type === 'discardResource'){
        MC.runEffectList(G, [{ fx: 'discardFromHand', count: amt, random: true }], { player: pl });
        MC.log(G, en + ' — 미방어 반응: ' + pl.uid + ' 손에서 자원 ' + amt + ' 버림');
      }
      G._environmentReaction = { defCode: env.defCode, type: r.type, amount: amt, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
  }
  // ★ 빌런 활성화 후 특성 분기 (04078 어보밍맨 III): 공격 활성화 완료 후 발동 (방어 여부 무관).
  if (attacker && attacker.kind === 'villain' && MC.villainActivateResponse){
    MC.villainActivateResponse(G, pl);
  }
  // Toe to Toe 등: 방어 해소 후 예약 효과 (공격자 대상 5피해). pending.afterEffects.
  if (p.afterEffects && attacker){
    MC.runEffectList(G, p.afterEffects, { player: pl, targets: [attacker], self: attacker, card: attacker });
  }
  // 강제 난입 체인 (회오리바람): alsoAttack에 남은 히어로가 있으면 그 다음 히어로에 대한
  // 새 방어 pending을 세운다 (동일 공격 순차 적용). 남은 대상 없으면 정상 종료.
  const chain = p.alsoAttack;
  if (chain && chain.length && attacker && attacker.hp > 0){
    const nextUid = chain[0];
    const nextPl = G.players.find(x => x.uid === nextUid);
    if (nextPl && !nextPl.eliminated && nextPl.form === 'hero'){
      G.pending = {
        kind: 'defense',
        player: nextUid,
        attackerUid: attacker.uid,
        amount: MC.enemyAtk(G, attacker),
        prevented: 0,
        piercing: !!attacker.piercing,
        alsoAttack: chain.slice(1),
      };
      MC.log(G, MC.nameOf(attacker) + ' 강제 난입 — ' + nextUid + '에게도 공격');
      return;   // 큐 재개 없이 다음 방어 대기
    }
  }
  // 하수인 연쇄 공격 체인 (혼돈의 지배 등): attackChain에 남은 (공격자,대상) 쌍이 있으면
  // 다음 하수인의 방어 pending을 세운다 (startMinionAttackChain이 기절/사망 스킵 포함 처리).
  if (p.attackChain && p.attackChain.length){
    if (startMinionAttackChain(G, p.attackChain)) return;   // 다음 공격 대기 (큐 재개 없이)
  }
  // 공격+피해 후 효과(attackDamagedEffects 등)가 선택 pending을 세웠으면 유지 + 큐 재개 보류.
  //   (Tombstone 자원 버림 선택 등 — 플레이어 해소 후 UI가 큐를 재개한다.)
  if (G.pending && G.pending !== p) return;
  G.pending = null;
  // 빌런 공격 후 강제 반응 선택 (울트론 I 01134: 메인 위협1 or 드론). 방어·피해 종료 후 선택 pending.
  if (attacker && attacker.kind === 'villain'){
    const vdef = MC.cardDef(attacker.defCode);
    if (vdef && vdef.forcedAttackChoice){
      G.pending = { kind:'revealChoice', player: pl.uid, selfUid: attacker.uid,
        prompt: vdef.forcedAttackChoice.prompt || '선택하세요',
        options: vdef.forcedAttackChoice.options || [] };
      MC.log(G, MC.nameOf(attacker) + ' — 공격 후 강제 반응: 선택 대기');
      return;   // 선택 해소까지 큐 재개 보류
    }
  }
  // 지연된 부스트★ 선택(안드로이드 효율 등): 이 공격의 부스트로 뒤집혔다면 여기서 pending을 세운다.
  // (방어·체인·피해가 모두 끝난 뒤라 흐름을 깨지 않는다. pending이 서면 큐 재개를 건너뛴다.)
  if (flushDeferredBoostChoice(G)) return;
  processVillainQueue(G); // 큐 재개
}

/* ── 인카운터 공개 ── */
function revealPendingEncounters(G){
  while (G.pendingEncounters.length){
    const { player, inst } = G.pendingEncounters.shift();
    const pl = G.players.find(p => p.uid === player);
    MC.log(G, pl.uid + ' 인카운터 공개: ' + MC.nameOf(inst));
    resolveEncounterCard(G, pl, inst);
    if (G.over) return;
    if (inst.surge) dealEncounterTo(G, pl, 1);
    // 공개 처리 중 결정 대기(방어/선택 등)가 서면 남은 공개를 중단하고 해소 후 재개.
    // (배신의 villainAttacks/minionsAttack 등이 세운 pending을 다음 공개가 덮어쓰는 것 방지)
    if (G.pending){
      if (!G.vq.length || G.vq[0].op !== 'reveal') G.vq.unshift({ op:'reveal' });
      return;
    }
  }
}
function resolveEncounterCard(G, pl, inst){
  // 인터럽트 정지점: 이 카드 공개에 대응할 인터럽트 카드가 있으면 멈춘다.
  // (아직 인터럽트를 검토하지 않은 경우에만 — 재진입 시 inst.interruptChecked로 스킵)
  if (!inst.interruptChecked){
    inst.interruptChecked = true;
    if (checkRevealInterrupt(G, pl, inst)){
      G.revealing = inst;   // 공개 진행 중 카드 (uid로 findByUid가 찾도록 — 아래 참조)
      return;
    }
  }
  // 공개 기록 (UI 확인용 — 중복 방지)
  if (!inst._logged){
    inst._logged = true;
    (G.revealLog = G.revealLog || []).push({ defCode: inst.defCode, name: inst.name, type: inst.type, player: pl.uid });
  }
  switch (inst.type){
    case 'minion':
      inst.engagedWith = pl.uid; pl.engagedMinions.push(inst);
      // 하수인 등장 반응 (호크아이 화살 등): 중앙 헬퍼가 힌트 기록 + 등장 반응 발동.
      MC.minionEnteredPlay(G, inst, pl);
      fireRevealWithInterrupt(G, pl, inst);
      // whenRevealed가 플레이어 선택 대기(revealChoice)를 세웠으면 공개 루프 정지 → 선택 후 재개
      if (G.pending && G.pending.kind === 'revealChoice'){
        G.vq.unshift({ op:'reveal' });
        return;
      }
      const idef = MC.cardDef(inst.defCode);
      if ((inst.quickstrike || (idef && idef.quickstrike)) && pl.form === 'hero'){
        // 속공: 즉시 공격 → 방어 대기 (공개 루프는 pending 해소 후 재개 필요)
        G.pending = { kind:'defense', player: pl.uid, attackerUid: inst.uid,
                      amount: MC.enemyAtk(G, inst) };
        G.vq.unshift({ op:'reveal' }); // 남은 공개를 큐로 되돌림
        return;
      }
      break;
    case 'treachery':
      fireRevealWithInterrupt(G, pl, inst);
      G.encounterDiscard.push(inst);
      break;
    case 'side_scheme': {
      const def = MC.cardDef(inst.defCode);
      inst.threat = (def.baseThreatPerPlayer||0) * G.players.length + (def.baseThreat||0);
      inst.peakThreat = inst.threat;   // 위협바 분모 (남은 저지량 표시)
      inst.isMain = false;
      G.sideSchemes.push(inst);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    }
    case 'attachment': {
      // 부착 대상 라우팅: attachTarget이 환경 슬러그면 그 환경에 부착 (업그레이드 드론 01142 등).
      // 대상 환경이 전장에 없으면 부착 불발 → 버림. 기본은 빌런.
      const adef = MC.cardDef(inst.defCode);
      const at = adef && adef.attachTarget;
      let host = G.villain;
      if (at === 'identity'){
        // 신분 부착 (All Tied Up / Media Coverage): 공개한 플레이어의 신분 카드에 부착.
        (pl.identityAttachments = pl.identityAttachments || []).push(inst);
        inst.attachedToPlayer = pl.uid;
        MC.log(G, MC.nameOf(inst) + ' — ' + MC.nameOf(pl) + '의 신분에 부착');
        fireRevealWithInterrupt(G, pl, inst);
        break;
      }
      if (at === 'minionMostHp'){
        // 졸라 부착(04117-119): 동일 부착물이 없는, 남은 HP가 가장 많은 하수인. 없으면 surge 후 버림.
        const minions = [];
        for (const pl2 of G.players) for (const m of (pl2.engagedMinions || [])) if (m.hp > 0) minions.push(m);
        const cands = minions.filter(m => !((m.attachments || []).some(x => x.defCode === inst.defCode)));
        let best = null;
        for (const m of cands){ if (!best || (m.hp || 0) > (best.hp || 0)) best = m; }
        if (!best){
          inst.surge = true;
          MC.log(G, MC.nameOf(inst) + ' — 부착 대상 하수인 없음 · surge');
          G.encounterDiscard.push(inst);
          break;
        }
        host = best;
        if (adef.grantsMinionGuard){ host.grantedGuard = true; host.guard = true; }
        MC.log(G, MC.nameOf(inst) + ' — 최다 잔여 HP 하수인 ' + MC.nameOf(host) + '에 부착' + (adef.grantsMinionGuard ? ' (호위 부여)' : ''));
        MC.attachTo(G, inst, host);
        fireRevealWithInterrupt(G, pl, inst);
        break;
      }
      if (at === 'highestHpEnemy'){
        // 최고 인쇄 HP 적(빌런+하수인) 중 동일 부착물이 없는 대상. 없으면 surge 후 버림.
        const enemies = [G.villain];
        for (const pl2 of G.players) for (const m of (pl2.engagedMinions || [])) enemies.push(m);
        const cands = enemies.filter(e => e && !((e.attachments || []).some(x => x.defCode === inst.defCode)));
        let best = null;
        for (const e of cands){ if (!best || (e.maxHp || 0) > (best.maxHp || 0)) best = e; }
        if (!best){
          inst.surge = true;
          MC.log(G, MC.nameOf(inst) + ' — 부착 대상 없음 · surge');
          G.encounterDiscard.push(inst);
          break;
        }
        host = best;
        MC.log(G, MC.nameOf(inst) + ' — 최고 HP 적 ' + MC.nameOf(host) + '에 부착');
      } else if (at && at !== 'villain'){
        host = (G.environments || []).find(e => e.defCode === at) || null;
        if (!host){
          MC.log(G, MC.nameOf(inst) + ' — 부착 대상(' + at + ') 없음 · 버림');
          G.encounterDiscard.push(inst);
          break;
        }
      }
      MC.attachTo(G, inst, host);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    }
    case 'environment':
      // 환경 카드: 전장에 유지 (버리지 않음). 드론 스탯 정의(droneStats) 등 지속 효과의 호스트.
      G.environments = G.environments || [];
      // 어보밍맨 None Shall Pass: 환경 1개만 유지 — 새 환경 등장 시 기존 환경 버림 (지형이 계속 바뀌는 추격전).
      { const _msD = MC.cardDef(G.mainScheme.defCode);
        if (_msD && _msD.singleEnvironment && G.environments.length){
          for (const old of G.environments){ MC.log(G, MC.nameOf(old) + ' — 지형이 바뀌며 사라짐'); G.encounterDiscard.push(old); }
          G.environments = [];
          G._environmentChanged = true;   // UI 전환 애니메이션 힌트
        } }
      G.environments.push(inst);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    case 'obligation':
      // 의무: 조우 버린더미에 먼저 놓아 findByUid가 공개 중 카드를 찾게 한 뒤 whenRevealed 발동.
      // whenRevealed(offerChoice→택1)의 resolveObligation이 최종 처리:
      //   mode:'game' → 버린더미에서 splice + 게임 제거 / mode:'discard' → 그대로 유지.
      if (!G.encounterDiscard.includes(inst)) G.encounterDiscard.push(inst);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    default:
      fireRevealWithInterrupt(G, pl, inst);
      G.encounterDiscard.push(inst);
  }
}

/* whenRevealed 발화 — 단, 대응 가능한 인터럽트 카드가 있으면 정지점(pending)을 띄운다.
   inst.revealCancelled가 서 있으면(인터럽트로 취소됨) whenRevealed를 발화하지 않는다.
   범용: 각 인터럽트 카드는 cardDef.interruptOn = { encounterType:'treachery'|... } 로 선언. */
function fireRevealWithInterrupt(G, pl, inst){
  if (inst.revealCancelled) {              // 이미 인터럽트로 취소됨
    MC.log(G, MC.nameOf(inst) + ' — "공개 시" 효과 취소됨');
    return;
  }
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  // Media Coverage(신분 부착): 이 플레이어가 공개한 카드의 "공개 시"를 1회 추가 발동.
  //   첫 발동이 pending(선택/방어)을 세우지 않은 경우에만 재발동 (pending 클로버·재귀 방지).
  if (!inst._wrDoubled && MC.identityAttachHas && MC.identityAttachHas(G, pl, 'wrDoubling')){
    const d = MC.cardDef(inst.defCode);
    if (d && d.whenRevealed && !G.pending && !G.over){
      inst._wrDoubled = true;
      MC.log(G, MC.nameOf(inst) + ' — Media Coverage: "공개 시" 1회 추가 발동');
      MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
    }
  }
}

/* 조우 카드에 대응할 수 있는 인터럽트 카드를 가진 플레이어가 있는지 검사.
   있으면 pending:{kind:'revealInterrupt'}를 띄우고 true 반환(호출측은 멈춤). */
function checkRevealInterrupt(G, pl, inst){
  const opts = collectRevealInterrupts(G, inst);
  if (!opts.length) return false;
  G.pending = { kind:'revealInterrupt', player: pl.uid, targetUid: inst.uid,
                encounterType: inst.type };
  MC.log(G, MC.nameOf(inst) + ' 공개 — 인터럽트 대응 가능');
  return true;
}

/* 인터럽트 해소: 카드를 사용하거나(취소) 패스한다. 그 후 공개 재개.
   use=false면 패스(원래 whenRevealed 발화). */
function resolveRevealInterrupt(G, playerUid, cardUid, payment){
  const p = G.pending;
  if (!p || p.kind !== 'revealInterrupt') throw new Error('[interrupt] 대기 중인 인터럽트 없음');
  const inst = G.revealing;
  const owner = G.players.find(x => x.uid === p.player); // 조우 카드를 공개한 플레이어
  G.pending = null;

  if (cardUid){
    // 손패 인터럽트 이벤트 vs 플레이 영역 동료/서포트 인터럽트 구분
    const handUser = G.players.find(x => x.hand.some(c => c.uid === cardUid));
    if (handUser){
      // ── 손패 인터럽트 이벤트 (Backflip류 아님, Enhanced Spider-Sense류) ──
      const card = handUser.hand.find(c => c.uid === cardUid);
      const def = MC.cardDef(card.defCode);
      const els = payment || [];
      MC.validatePayment(G, handUser, els, card.cost||0, card);
      handUser.hand.splice(handUser.hand.indexOf(card), 1);
      MC.executePayment(G, handUser, els);
      MC.log(G, handUser.uid + ' 인터럽트: ' + MC.nameOf(card));
      const eff = def.interruptEffect || 'cancelReveal';
      if (eff === 'cancelReveal'){
        inst.revealCancelled = true;
      } else if (MC.HANDLERS[eff]){
        // 커스텀 인터럽트 핸들러 (get-behind-me 등): 취소 여부·추가 효과를 핸들러가 결정.
        // 기본적으로 취소 플래그를 세우고, 핸들러가 추가 효과(빌런 공격 등)를 처리.
        inst.revealCancelled = true;
        MC.HANDLERS[eff](G, { player: handUser, card, targetInst: inst, self: card });
      } else {
        MC.runEffectList(G, def.effects || [], { player: handUser, card, targetInst: inst });
      }
      MC.moveToDiscard(G, handUser, card, {});
    } else {
      // ── 플레이 영역 동료/서포트/준비 인터럽트 (Black Widow류): 소진/버림 + 자원 지불 → 취소 + 추가 효과 ──
      let user = null, srcCard = null;
      for (const pl of G.players)
        for (const arr of [pl.playArea.allies, pl.playArea.supports, pl.playArea.upgrades]){
          const c = arr.find(x => x.uid === cardUid);
          if (c){ user = pl; srcCard = c; break; }
        }
      if (!user) throw new Error('[interrupt] 인터럽트 카드 없음: ' + cardUid);
      const def = MC.cardDef(srcCard.defCode);
      const io = def.interruptOn;
      if (srcCard.exhausted) throw new Error('[interrupt] 이미 소진됨: ' + MC.nameOf(srcCard));
      // 자원 지불 (io.pay = {type, count})
      if (io.pay){
        const els = payment || [];
        MC.validatePayment(G, user, els, io.pay.count || 0, srcCard, { type: io.pay.type, count: io.pay.count });
        MC.executePayment(G, user, els);
      }
      // 효과: 취소 (기본)
      inst.revealCancelled = true;
      // 준비(Preparation) 카드는 발동 시 버려짐 + Widowmaker; 그 외(동료/서포트)는 소진.
      if (io.discardSelf || (def.traits || []).includes('preparation')){
        MC.triggerPreparation(G, user, srcCard);
        if (G._widowmaker && MC.offerWidowmaker) MC.offerWidowmaker(G);
      } else {
        srcCard.exhausted = true;
      }
      MC.log(G, user.uid + ' 인터럽트: ' + MC.nameOf(srcCard));
      // 추가 효과: 조우덱에서 1장 더 공개 (io.thenReveal)
      if (io.thenReveal) G._pendingExtraReveal = (G._pendingExtraReveal||0) + io.thenReveal;
    }
  }
  // 공개 재개 (interruptChecked=true라 다시 멈추지 않음)
  const rInst = G.revealing;
  G.revealing = null;
  resolveEncounterCard(G, owner, rInst);
  // 추가 공개 (Black Widow: 취소 후 조우덱에서 1장 더)
  while (G._pendingExtraReveal > 0){
    G._pendingExtraReveal--;
    MC.dealEncounterTo(G, owner, 1);
    revealPendingEncounters(G);
    if (G.pending) return; // 추가 공개 중 또 인터럽트/방어 대기 발생하면 멈춤
  }
  processVillainQueue(G);
}

/* 대응 가능한 인터럽트 목록. cardDef.interruptOn.encounterType 매칭.
   반환 항목: { player, cardUid, source:'hand'|'ally', needsPay, form } */
function collectRevealInterrupts(G, inst){
  const out = [];
  const matches = (io) => io && (io.encounterType === inst.type || io.encounterType === 'any');
  for (const p of G.players){
    // ① 손패의 인터럽트 이벤트 (히어로 폼 전용 — Hero Interrupt)
    if (p.form === 'hero'){
      for (const c of p.hand){
        const def = MC.cardDef(c.defCode);
        if (matches(def && def.interruptOn))
          out.push({ player: p.uid, cardUid: c.uid, source:'hand' });
      }
    }
    // ② 플레이 영역 동료/서포트의 인터럽트 (소진 + 자원 지불형, 폼 무관)
    for (const arr of [p.playArea.allies, p.playArea.supports]){
      for (const c of arr){
        const def = MC.cardDef(c.defCode);
        const io = def && def.interruptOn;
        if (matches(io) && !c.exhausted){
          // 폼 제약이 있으면 확인 (없으면 모든 폼)
          if (io.form && p.form !== io.form) continue;
          out.push({ player: p.uid, cardUid: c.uid, source:'ally', needsPay: io.pay });
        }
      }
    }
    // ③ 플레이 영역 업그레이드의 준비(Preparation) 인터럽트 — 그래플링 훅 (히어로 폼, 발동 시 버림 + Widowmaker)
    if (p.form === 'hero'){
      for (const c of p.playArea.upgrades){
        const def = MC.cardDef(c.defCode);
        const io = def && def.interruptOn;
        if (matches(io) && !c.exhausted){
          if (io.form && p.form !== io.form) continue;
          out.push({ player: p.uid, cardUid: c.uid, source:'preparation', needsPay: io.pay });
        }
      }
    }
  }
  return out;
}
/* 부착: 부착물 inst를 대상 target에 건다. 양방향 링크(attachedTo ↔ attachments).
   범용 — 하수인/빌런/정체성/스킴 어디든 대상 가능. */
function attachTo(G, inst, target){
  target.attachments = target.attachments || [];
  target.attachments.push(inst);
  inst.attachedTo = target.uid;
  MC.log(G, MC.nameOf(inst) + ' → ' + MC.nameOf(target) + '에 부착');
  // 부착 스탯 보정 (attachStats: {attack:+3} 등 — 돌진). 이탈 시 detachFrom이 원복.
  // 적용량을 inst.appliedStats에 기록해 원복이 정의 변경과 무관하게 정확하도록.
  const adef = MC.cardDef(inst.defCode);
  if (adef && adef.attachStats){
    inst.appliedStats = {};
    for (const k in adef.attachStats){
      target[k] = (target[k] || 0) + adef.attachStats[k];
      inst.appliedStats[k] = adef.attachStats[k];
      MC.log(G, MC.nameOf(target) + ' ' + k + ' ' + (adef.attachStats[k] >= 0 ? '+' : '') + adef.attachStats[k] + ' (' + MC.nameOf(inst) + ')');
    }
  }
  // HP 부여 부착물 (명예 어벤져 등 hpBonus): 대상이 HP 인스턴스(동료/하수인 등)면 maxHp+hp 동시 증가.
  //   히어로(pl) 부착은 recomputeMaxHp가 별도 처리 → 여기선 카드 인스턴스(type+maxHp 존재)만.
  if (adef && adef.hpBonus && target.type && target.maxHp !== undefined){
    target.maxHp += adef.hpBonus;
    target.hp = (target.hp || 0) + adef.hpBonus;
    inst.appliedHpBonus = adef.hpBonus;
    MC.log(G, MC.nameOf(target) + ' HP +' + adef.hpBonus + ' (' + MC.nameOf(inst) + ')');
  }
  // 드론 스탯 보정 부착물 (업그레이드 드론): 전장의 뒷면 드론 스탯 재계산
  if (adef && adef.droneStatBonus) recalcDroneStats(G);
}

/* 부착 해제: 대상에서 부착물 링크 제거 (인스턴스 자체 정리는 호출측 책임). */
function detachFrom(G, inst){
  if (!inst.attachedTo) return null;
  const target = MC.findByUid(G, inst.attachedTo);
  if (target && target.attachments)
    target.attachments = target.attachments.filter(a => a.uid !== inst.uid);
  // 부착 스탯 원복 (attachStats 적용분)
  if (inst.appliedStats && target){
    for (const k in inst.appliedStats) target[k] = (target[k] || 0) - inst.appliedStats[k];
  }
  delete inst.appliedStats;
  // HP 부여 원복 (동료 hpBonus): maxHp 감소 + hp 상한 클램프
  if (inst.appliedHpBonus && target && target.maxHp !== undefined){
    target.maxHp -= inst.appliedHpBonus;
    if (target.hp > target.maxHp) target.hp = target.maxHp;
    if (target.hp < 0) target.hp = 0;
  }
  delete inst.appliedHpBonus;
  inst.attachedTo = null;
  // 드론 스탯 보정 부착물 이탈: 뒷면 드론 스탯 재계산 (HP 상한 하락 즉사 포함)
  const ddef = MC.cardDef(inst.defCode);
  if (ddef && ddef.droneStatBonus) recalcDroneStats(G);
  return target;
}

/* 대상이 격파/제거될 때 그 부착물들을 처리한다.
   각 부착물의 whenAttachedDefeated 훅을 발화한 뒤, 소유에 따라 정리:
   플레이어 카드(side:'player') → 소유자 버림 / 인카운터 카드 → 조우 버림. */
function releaseAttachments(G, target){
  const atts = (target.attachments || []).slice();
  for (const att of atts){
    const def = MC.cardDef(att.defCode);
    // 부착 대상이 격파될 때 발동하는 훅 (spider-tracer 등)
    MC.fireCardHook(G, att, 'whenAttachedDefeated', { target, attachment: att });
    att.attachedTo = null;
    delete att.appliedStats;   // 대상 격파 — 스탯 원복 불필요, 잔여 기록만 정리 (재공개 시 오염 방지)
    if (def.side === 'player'){
      const owner = G.players.find(p => p.uid === att.ownerUid);
      if (owner){
        for (const arr of [owner.playArea.upgrades, owner.playArea.supports])
          { const i = arr.indexOf(att); if (i>=0) arr.splice(i,1); }
        MC.moveToDiscard(G, owner, att, {});
      }
    } else {
      G.encounterDiscard.push(att);
    }
  }
  target.attachments = [];
}

MC.drawEncounterCard = drawEncounterCard; MC.dealEncounterTo = dealEncounterTo;
MC.placeThreat = placeThreat; MC.removeThreat = removeThreat; MC.resolveScheme = resolveScheme;
MC.onSideSchemeCleared = onSideSchemeCleared;
MC.onMainSchemeThreshold = onMainSchemeThreshold; MC.advanceMainScheme = advanceMainScheme;
MC.startVillainPhase = startVillainPhase; MC.processVillainQueue = processVillainQueue;
MC.villainStepOnce = villainStepOnce;
MC.enemyActivation = enemyActivation; MC.resolveDefensePending = resolveDefensePending;
MC.revealPendingEncounters = revealPendingEncounters; MC.resolveEncounterCard = resolveEncounterCard;
MC.resolveRevealInterrupt = resolveRevealInterrupt; MC.collectRevealInterrupts = collectRevealInterrupts;
MC.attachTo = attachTo; MC.detachFrom = detachFrom; MC.releaseAttachments = releaseAttachments;
MC.revealSpecificSideScheme = revealSpecificSideScheme;
MC.discardUntilMinionIntoPlay = discardUntilMinionIntoPlay;
MC.searchMinionIntoPlay = searchMinionIntoPlay;
MC.startMinionAttackChain = startMinionAttackChain;
MC.spawnFacedownDrone = spawnFacedownDrone;
MC.recalcDroneStats = recalcDroneStats;
MC.droneBaseStats = droneBaseStats;


/* ◇◇ from mc_6_keywords.js ◇◇ */
/* ═══════════════════════════════════════════════════════════════
   mc_6_keywords.js — 샤드 6/7 : 피해 파이프라인 · 상태 · condCheck
   강인/관통/보복/과잉살상 상호작용은 반드시 이 파이프라인 한 곳에서.
   (넷러너의 effectiveStrength 파이프라인에 해당)
   ═══════════════════════════════════════════════════════════════ */

/* applyDamage(G, target, amount, opt)
   opt: { source, piercing, overkill, isVillainAttack } */
function applyDamage(G, target, amount, opt){
  opt = opt || {};
  if (amount <= 0) return 0;
  // 0) 울트론 III(01136) invulnWhileDrone: 전장에 Drone 하수인이 하나라도 있으면 빌런은 피해를 받지 않음.
  if (target.kind === 'villain'){
    const vdef = MC.cardDef(target.defCode);
    if (vdef && vdef.invulnWhileDrone){
      const anyDrone = G.players.some(p => p.engagedMinions.some(m => m.isDrone || (m.traits||[]).includes('drone')));
      if (anyDrone){
        MC.log(G, MC.nameOf(target) + ' — 전장에 드론이 있어 피해 무효 (무적)');
        G.fxUltronInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.5) 킬몽거(01157) immuneToUpgradeDamage: 특정 영웅의 업그레이드가 주는 피해를 받지 않음.
  if (opt.source){
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.immuneToUpgradeDamage){
      const sd = MC.cardDef(opt.source.defCode || opt.source.code);
      if (sd && sd.type === 'upgrade' && sd.hero === tdef.immuneToUpgradeDamage){
        MC.log(G, MC.nameOf(target) + ' — ' + tdef.immuneToUpgradeDamage + ' 업그레이드 피해 면역');
        G.fxKillmongerImmune = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.6) 마담 히드라(01181) invulnWhileScheme: 특정 사이드 스킴이 전장에 있는 동안 피해 면역.
  {
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.invulnWhileScheme){
      const present = (G.sideSchemes || []).some(s => s.defCode === tdef.invulnWhileScheme);
      if (present){
        MC.log(G, MC.nameOf(target) + ' — ' + tdef.invulnWhileScheme + ' 존재 중 피해 면역');
        G.fxSchemeInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.68) 크로스본즈의 아머(04065): 빌런이 피해를 받을 때 → 아머가 대신 흡수(여기 배치). 5+ 누적 시 아머 파괴.
  if (target.kind === 'villain'){
    const armor = (target.attachments || []).find(a => MC.cardDef(a.defCode) && MC.cardDef(a.defCode).absorbsVillainDamage);
    if (armor){
      armor.absorbedDamage = (armor.absorbedDamage || 0) + amount;
      MC.log(G, MC.nameOf(target) + ' 피해 ' + amount + ' → ' + MC.nameOf(armor) + ' 흡수 (누적 ' + armor.absorbedDamage + ')');
      if (armor.absorbedDamage >= 5){
        const i = target.attachments.indexOf(armor);
        if (i >= 0) target.attachments.splice(i, 1);
        try { if (MC.detachFrom) MC.detachFrom(G, armor); } catch (e) {}
        (G.encounterDiscard = G.encounterDiscard || []).push(armor);
        MC.log(G, MC.nameOf(armor) + ' — 5 이상 피해 누적, 파괴');
      }
      return 0;
    }
  }
  // 0.69) 사진 반사(04104): 태스크마스터가 피해를 받을 때 → 그 피해를 방지하고, 같은 양을 공격한 플레이어의 신분에 대신 준다. 그 후 이 부착을 버린다.
  if (target.kind === 'villain'){
    const reflect = (target.attachments || []).find(a => { const cd = MC.cardDef(a.defCode); return cd && cd.villainDamageReflect; });
    if (reflect && opt.source){
      // 공격자 플레이어 판별: source가 플레이어 객체거나, source.playerUid/owner로 소급
      let pl = null;
      if (opt.source.uid && (G.players || []).some(p => p.uid === opt.source.uid)) pl = G.players.find(p => p.uid === opt.source.uid);
      else if (opt.source.playerUid) pl = G.players.find(p => p.uid === opt.source.playerUid);
      else if (opt.source.isPlayer && G.players.length === 1) pl = G.players[0];
      if (pl && !pl.eliminated){
        MC.log(G, MC.nameOf(target) + ' — 사진 반사: 피해 ' + amount + ' 방지 → ' + MC.nameOf(pl) + '의 신분에 반사');
        G._photoReflect = { targetUid: target.uid, playerUid: pl.uid, amount, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        // 부착 버림 (반사 처리 전에 제거하여 반사 피해가 다시 이 부착을 타지 않도록)
        const i = target.attachments.indexOf(reflect);
        if (i >= 0) target.attachments.splice(i, 1);
        try { if (MC.detachFrom) MC.detachFrom(G, reflect); } catch (e) {}
        (G.encounterDiscard = G.encounterDiscard || []).push(reflect);
        MC.applyDamage(G, pl, amount, { source: reflect, isAttack: false });
        return 0;
      }
    }
  }
  // 0.65) 토마스 에디슨(05027) invulnWhileOtherMinion: 자신과 같은 플레이어와 교전 중인 다른 하수인이 있으면 피해 면역.
  {
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.invulnWhileOtherMinion && target.kind === 'minion'){
      const hasOther = G.players.some(pl =>
        (pl.engagedMinions || []).includes(target) &&
        pl.engagedMinions.some(m => m !== target && m.hp > 0));
      if (hasOther){
        MC.log(G, MC.nameOf(target) + ' — 다른 하수인과 함께 있어 피해 면역');
        G.fxMinionInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.66) 에디슨의 거대 로봇(05028) invulnUnlessNullified: 기본 피해 면역. 무효화 액션(nullifiedThisPhase)이면 피해 가능.
  {
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.invulnUnlessNullified && target.kind === 'minion' && !target.nullifiedThisPhase){
      MC.log(G, MC.nameOf(target) + ' — 피해 면역 (무효화 필요)');
      G.fxRobotInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
      return 0;
    }
  }
  // 0.7) 노먼 오스본 damageToCounter: 빌런이 피해를 받게 될 때 → 피해 대신 그만큼
  //      악명 카운터를 제거한다 (0 도달 시 goblinRemoveCounter가 폼전환 발동).
  if (target.kind === 'villain'){
    const vdef = MC.cardDef(target.defCode);
    if (vdef && vdef.damageToCounter && MC.goblinRemoveCounter){
      MC.log(G, MC.nameOf(target) + ' — 피해 ' + amount + ' 대신 악명 카운터 제거');
      G.fxGoblinCounter = { targetUid: target.uid, op:'remove', amount, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
      MC.goblinRemoveCounter(G, amount);
      return 0;   // 빌런 본체 무피해
    }
  }
  // 1) 강인: 관통이 아니면 피해 전부 무효 + 토큰 제거
  if (target.status && target.status.tough > 0 && !opt.piercing){
    target.status.tough--;
    MC.log(G, MC.nameOf(target) + ' 강인 — 피해 무효');
    return 0;
  }
  // 1.5) 라이노 장갑 슈트: 빌런에 부착된 armor-suit이 있으면 피해를 슈트에 쌓음.
  //      5 이상 쌓이면 슈트 파괴 (다음 피해부터 빌런 본체가 받음). 강제 개입.
  if (target.attachments && target.attachments.length){
    const suit = target.attachments.find(a => a.defCode === 'rhino-suit' && !a._destroyed);
    if (suit){
      suit.damageHere = (suit.damageHere || 0) + amount;
      MC.log(G, '장갑 라이노 슈트 — 피해 ' + amount + ' 흡수 (누적 ' + suit.damageHere + ')');
      if (suit.damageHere >= 5){
        suit._destroyed = true;
        const i = target.attachments.indexOf(suit);
        if (i >= 0) target.attachments.splice(i, 1);
        if (G.encounterDiscard) G.encounterDiscard.push(suit);
        MC.log(G, '장갑 라이노 슈트 — 5 피해 누적, 파괴됨');
        G.fxSuitBreak = { targetUid: target.uid };
      }
      return 0;   // 슈트가 전부 흡수 (빌런 본체 무피해)
    }
  }
  // 2) 피해 적용
  target.hp -= amount;
  MC.log(G, MC.nameOf(target) + ' 피해 ' + amount + ' (HP ' + target.hp + '/' + target.maxHp + ')');
  // 3) 보복 (공격에 의한 피해일 때, 공격자에게) — 공식 룰: 트리거는 "공격받음"(피해량 무관),
  //    단 공격에서 살아남아야 함. 방어로 0피해·강인 흡수인 경우는 공격 해소부(resolveDefense 등)가
  //    triggerRetaliate를 직접 호출하므로, 여기선 실제 피해가 간 공격에 한해 발동(noRetaliate로 억제 가능).
  if (!opt.isRetaliate && !opt.noRetaliate)
    MC.triggerRetaliate(G, target, opt.source);
  // 4) 처치 판정
  if (target.hp <= 0){
    // 히어로 패배 방지 (캡틴아메리카의 헬멧 등): 플레이 영역 업그레이드가 "패배당할 때 HP를 N으로" 하고 자신을 버림.
    if (!opt.isRetaliate && target.playArea && target.playArea.upgrades){
      const prot = target.playArea.upgrades.find(c => {
        const cd = MC.cardDef(c.defCode); return cd && cd.preventDefeatToHp !== undefined;
      });
      if (prot){
        const cd = MC.cardDef(prot.defCode);
        target.hp = cd.preventDefeatToHp;
        const i = target.playArea.upgrades.indexOf(prot);
        if (i >= 0) target.playArea.upgrades.splice(i, 1);
        if (prot.attachments && prot.attachments.length) MC.releaseAttachments(G, prot);
        MC.moveToDiscard(G, target, prot, {});
        MC.log(G, MC.nameOf(target) + ' — ' + MC.nameOf(prot) + ' 난입: 패배 대신 HP ' + target.hp + '로, 카드 버림');
        G.fxHelmetSave = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return amount;
      }
    }
    // 부착물 부활(reviveOnDefeat): 부착 하수인이 처치될 뻔하면 HP 전량 회복 후 그 부착물만 버림 (Biomechanical Upgrades 01185).
    if (!opt.isRetaliate && target.attachments && target.attachments.length){
      const rev = target.attachments.find(a => { const ad = MC.cardDef(a.defCode); return ad && ad.reviveOnDefeat; });
      if (rev){
        target.hp = target.maxHp;
        MC.detachFrom(G, rev, target);
        (G.encounterDiscard = G.encounterDiscard || []).push(rev);
        MC.log(G, MC.nameOf(target) + ' — ' + MC.nameOf(rev) + ' 강제 난입: HP 전량 회복 후 부착물 버림 (처치 방지)');
        G.fxBiomechRevive = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        MC.fireCardHook(G, rev, 'onRevive', { target });
        return amount;
      }
    }
    // 과잉살상(overkill): 하수인 처치 시 초과 피해를 빌런에게 전달 (opt.overkill일 때).
    // 초과 = 처치 후 남은 음수 HP의 절댓값. 빌런에게는 overkill을 전파하지 않음(중복 방지).
    let excess = 0;
    if (opt.overkill && target.type === 'minion') excess = -target.hp;
    MC.onDefeated(G, target, opt);
    if (excess > 0 && G.villain && G.villain.hp > 0){
      MC.log(G, '과잉살상 — 초과 피해 ' + excess + ' → 빌런');
      applyDamage(G, G.villain, excess, { source: opt.source, piercing: opt.piercing });
    }
  } else if (!opt.isRetaliate && target.attachments && target.attachments.length){
    // 비브라늄 갑옷(01152) 강제반응: 빌런이 피해를 받은 후(생존 시) 강인(Tough) 카드 부여.
    for (const att of target.attachments){
      const adef = MC.cardDef(att.defCode);
      if (adef && adef.grantsToughOnDamage){
        MC.setStatus(G, target, 'tough', true);
        MC.log(G, MC.nameOf(target) + ' — ' + MC.nameOf(att) + ': 피해 후 강인(Tough) 부여');
        G.fxArmorRetough = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq||0)+1) };
        break;
      }
    }
  }
  return amount;
}

function healTarget(G, target, amount){
  const before = target.hp;
  target.hp = Math.min(target.maxHp, target.hp + amount);
  const healed = target.hp - before;
  MC.log(G, MC.nameOf(target) + ' 회복 ' + healed + ' (HP ' + target.hp + ')');
  return healed;
}

function setStatus(G, target, status, on){
  target.status = target.status || { stunned:0, confused:0, tough:0 };
  if (on) target.status[status]++;
  else target.status[status] = Math.max(0, target.status[status]-1);
}

function onDefeated(G, target, opt){
  MC.log(G, MC.nameOf(target) + ' 격파됨');
  // 히어로가 공격으로 적(하수인 또는 빌런단계)을 처치한 경우 추적 (chase-them-down 반응용).
  // opt.source가 히어로 신분(isPlayer/heroCode)이고 공격(isAttack)일 때 플레이어에 플래그.
  if (opt && opt.isAttack && opt.source && (opt.source.isPlayer || opt.source.heroCode) &&
      (target.type === 'minion' || target.kind === 'villain')){
    opt.source.justDefeatedEnemyByAttack = true;
  }
  // 히어로 본인이 하수인을 처치한 경우 추적 (심문실 반응용 — 공격/이벤트 등 수단 무관,
  // 단 하수인만. 동료·지원 소스는 제외. FAQ: "당신"=정체성/업그레이드/자원카드/이벤트).
  if (opt && opt.source && target.type === 'minion'){
    const src = opt.source;
    const owner = src.isPlayer ? src : (src.heroCode ? G.players.find(p => p.heroCode === src.heroCode) : null);
    if (owner){
      owner.justDefeatedMinionByHero = true;
      // 영광 카운터 축적 (Hall of Heroes 06017): 하수인 처치 시 gloryOnMinionDefeat 지원 카드에 +1.
      for (const c of (owner.playArea.supports || [])){
        if (MC.cardDef(c.defCode).gloryOnMinionDefeat){
          c.counters = (c.counters || 0) + 1;
          MC.log(G, MC.nameOf(c) + ' — 영광 카운터 +1 (총 ' + c.counters + ')');
        }
      }
    }
  }
  MC.fireCardHook(G, target, 'whenDefeated', { by: opt.source });
  // 부착물 처리: 대상이 사라지기 전에 whenAttachedDefeated 발화 + 부착물 정리
  if (target.attachments && target.attachments.length) MC.releaseAttachments(G, target);
  if (target.kind === 'villain'){
    // 코어 룰: 게임당 2스테이지. 최종 스테이지 번호(G.villainFinalStageNum)에 도달한 단계를 처치하면 승리.
    //   일반: I 처치 → II 진행, II(최종) 처치 → 승리 / 전문가: II 처치 → III 진행, III(최종) 처치 → 승리.
    const vdef = MC.cardDef(target.defCode);
    const finalNum = G.villainFinalStageNum || Infinity;
    const isFinal = !vdef.nextStage || (vdef.stage || 1) >= finalNum;
    if (!isFinal) MC.advanceVillainStage(G);
    else MC.setGameOver(G, 'win', '빌런 격파');
  } else if (target.isPlayer){
    MC.onPlayerDefeated(G, target);
  } else if (target.type === 'minion'){
    // 로키(06028) 격파 인터럽트: 조우덱 top 1장 버림 → 배신(Treachery)이면 전체 회복하여 부활 (격파 취소)
    const mdef = MC.cardDef(target.defCode);
    if (mdef.reviveOnTreachery && !opt._noRevive && (G.encounterDeck || []).length){
      const top = G.encounterDeck.pop();
      G.encounterDiscard.push(top);
      const isTreach = MC.cardDef(top.defCode).type === 'treachery';
      MC.log(G, MC.nameOf(target) + ' 격파 인터럽트 — 조우덱 상단 ' + MC.nameOf(top) + ' 버림' + (isTreach ? ' (배신!)' : ''));
      if (isTreach){
        target.hp = target.maxHp;
        MC.log(G, MC.nameOf(target) + ' — 배신 카드로 전체 회복하여 부활!');
        G.fxRevive = { uid: target.uid, quoteKey: target.defCode };
        return;   // 격파 취소 (조우 버림 안 함, 전장 유지)
      }
    }
    // 과잉살상: 잉여 피해 → 빌런 (opt.overkill일 때) — Phase 1에서 잉여 계산 연결
    const pl = G.players.find(p => p.uid === target.engagedWith);
    if (pl) pl.engagedMinions = pl.engagedMinions.filter(m => m !== target);
    if (target.isDrone){
      // 울트론 드론 환경 강제 반응: 드론 처치 시 뒷면 카드는 소유자의 버림 더미로 (토큰은 소멸)
      const owner = G.players.find(p => p.uid === target.droneOwner) || pl;
      if (owner && target.facedownCard){
        owner.discard.push(target.facedownCard);
        MC.log(G, '드론의 뒷면 카드(' + MC.nameOf(target.facedownCard) + ') → ' + owner.uid + ' 버림 더미로');
      }
    } else {
      G.encounterDiscard.push(target);
    }
  } else if (target.type === 'ally'){
    const pl = G.players.find(p => p.uid === target.ownerUid);
    if (pl){
      pl.playArea.allies = pl.playArea.allies.filter(a => a !== target);
      const di = MC.cardDef(target.defCode).defeatInterrupt;
      if (di && di.shuffleIntoDeck){
        // 클레아: 격파 시 버림 대신 소유자 덱에 셔플.
        pl.deck.push(target);
        if (MC.shuffle) MC.shuffle(G, pl.deck);
        MC.log(G, MC.nameOf(target) + ' 격파 — 소유자 덱에 셔플');
        return;
      }
      if (di && !G.pending){
        // 처치 인터럽트(레드 대거): 서로 다른 자원 2개 지불 → 적에 피해 + 손 반환. 미지불 시 버림.
        G.pending = { kind:'allyDefeatInterrupt', player: pl.uid, ally: target,
          allyUid: target.uid, damage: di.damage || 0, differentTypes: di.differentTypes || 2,
          vfx: di.vfx || null, chosenPay: [], targetUid: null,
          prompt: di.prompt || (MC.nameOf(target) + ' 처치 — 서로 다른 자원 2개를 지불하면 적에게 피해를 주고 손으로 되돌립니다') };
        MC.log(G, MC.nameOf(target) + ' 처치 — 인터럽트 대기 (자원 지불 선택)');
        return;
      }
      MC.moveToDiscard(G, pl, target, {});
      MC.maybeOfferRapidResponse(G, pl, target);   // 처치된 동료를 버린더미에서 되살림 (히어로 반응)
    }
  }
}

/* 빌런 단계 전환 (코어 룰): 다음 단계로 교체, HP는 새 단계 만점(잉여 피해 이월 없음),
   부착물/상태 토큰은 유지 */
function advanceVillainStage(G){
  const old = G.villain;
  const next = MC.cardDef(old.defCode).nextStage;
  const v = MC.makeInstance(G, next, { kind:'villain' });
  const def = MC.cardDef(next);
  const per = def.hpPerPlayer !== undefined ? def.hpPerPlayer : def.hp;
  v.hp = v.maxHp = per * G.players.length;
  v.attachments = old.attachments || [];
  v.status = old.status;
  G.villain = v;
  MC.log(G, '빌런 단계 전환 → ' + MC.nameOf(v) + ' 단계 ' + (MC.cardDef(next).stage||'?') +
    ' (HP ' + v.hp + ', ATK ' + v.attack + ')');
  // 새 단계의 When Revealed 발화 (라이노 II=사이드스킴 공개, III=Toughness+전체기절)
  MC.fireCardHook(G, v, 'whenRevealed', { villain: v });
}

/* 하수인 등장 힌트 + 아군 동료의 하수인 등장 반응(호크아이 화살 등)을 선택 큐에 등록.
   onMinionEnterDamage {counter?, amount} 보유 동료마다 반응 후보를 G._pendingMinionReactions에 push.
   실제 발동/대상은 flushMinionReactions가 revealChoice(발동/넘김) 선택으로 물어봄 → 카드 선택 기능 보존. */
function minionEnteredPlay(G, minion, pl){
  if (!minion) return;
  G.minionJustEntered = minion.uid;
  // 신분 "하수인 교전 후" 반응 (토르 06001a Have at thee! — 페이즈당 1회 카드 2장 드로우).
  // 교전 플레이어(pl)의 현재 폼 신분 def에 onMinionEngage가 있으면 발동. 범용 인덱스.
  if (pl && !pl.eliminated){
    const idef = MC.cardDef(pl.form === 'hero' ? pl.heroCode : pl.aeCode);
    const eng = idef && idef.onMinionEngage;
    if (eng && (!eng.form || pl.form === eng.form)){
      pl.usedIdentityEngageThisPhase = pl.usedIdentityEngageThisPhase || {};
      if (!(eng.oncePerPhase && pl.usedIdentityEngageThisPhase[pl.form])){
        if (eng.drawCards) MC.drawCards(G, pl, eng.drawCards);
        if (eng.effect) MC.runEffectList(G, Array.isArray(eng.effect) ? eng.effect : [eng.effect], { player: pl });
        if (eng.oncePerPhase) pl.usedIdentityEngageThisPhase[pl.form] = true;
        MC.log(G, MC.nameOf(pl) + ' — ' + (eng.name || '신분 반응') + ' 발동');
        if (eng.vfx) G._identityEngageVfx = { vfx: eng.vfx, playerUid: pl.uid };
      }
    }
  }
  for (const p of (G.players || [])){
    for (const ally of (p.playArea.allies || [])){
      const ad = MC.cardDef(ally.defCode);
      if (!ad || !ad.onMinionEnterDamage) continue;
      const spec = ad.onMinionEnterDamage;
      if (spec.counter && (ally.counters || 0) <= 0) continue;   // 카운터 없으면 발동 불가 → 후보 제외
      (G._pendingMinionReactions = G._pendingMinionReactions || []).push({
        allyUid: ally.uid, minionUid: minion.uid, amount: spec.amount, counter: spec.counter,
        vfx: (ad.vfx && ad.vfx.reaction) || null });
    }
  }
  // 태스크마스터 훈련소(04108): 전장에 있으면 하수인이 등장할 때 강인(tough) 상태 부여
  if ((G.sideSchemes || []).some(s => s.defCode === '04108')){
    MC.setStatus(G, minion, 'tough', true);
    MC.log(G, MC.nameOf(minion) + ' — 태스크마스터 훈련소: 강인(tough) 부여');
  }
}
MC.minionEnteredPlay = minionEnteredPlay;

/* 하수인 등장 반응 선택 큐 flush — 다음 유효 반응 1건을 revealChoice(발동/넘김)로 물어봄.
   flushThreatChoice/flushEachChoice와 동일 패턴. pending 세우면 true. resolveRevealChoice·dispatch·빌런큐에서 체인 호출. */
function flushMinionReactions(G){
  const q = G._pendingMinionReactions;
  if (!q || !q.length){ G._pendingMinionReactions = null; return false; }
  while (q.length){
    const r = q.shift();
    const ally = MC.findByUid(G, r.allyUid);
    const minion = MC.findByUid(G, r.minionUid);
    if (!ally || !minion || minion.hp <= 0) continue;               // 하수인 이미 처치됨 → 스킵
    if (r.counter && (ally.counters || 0) <= 0) continue;           // 카운터 소진됨 → 스킵
    const owner = G.players.find(p => (p.playArea.allies || []).some(a => a.uid === ally.uid));
    if (!owner || owner.eliminated) continue;
    G.pending = { kind:'revealChoice', player: owner.uid, selfUid: ally.uid,
      prompt: MC.nameOf(ally) + ' — 반응: ' + MC.nameOf(minion) + '에게 ' + r.amount + ' 피해를 줄까요?' +
              (r.counter ? ' (' + r.counter + ' 카운터 ' + (ally.counters || 0) + '개)' : ''),
      options: [
        { key:'fire', label: r.amount + ' 피해 발동' + (r.counter ? ' (' + r.counter + ' 1 소진)' : ''),
          effects:[{ fx:'minionReactionDamage', allyUid: ally.uid, minionUid: minion.uid, amount: r.amount, counter: r.counter, vfx: r.vfx }] },
        { key:'skip', label:'넘김' }
      ] };
    MC.log(G, MC.nameOf(ally) + ' 등장 반응 — ' + owner.uid + ' 선택 대기');
    return true;
  }
  G._pendingMinionReactions = null;
  return false;
}
MC.flushMinionReactions = flushMinionReactions;

function onPlayerDefeated(G, pl){
  pl.eliminated = true;
  MC.log(G, pl.uid + ' 탈락');
  if (G.players.every(p => p.eliminated)) MC.setGameOver(G, 'loss', '전원 탈락', 'heroDefeat');
}

/* 수호: 교전 중인 수호 하수인이 있으면 빌런 공격/저지 불가 */
function hasGuardEngaged(G, pl){
  return pl.engagedMinions.some(m => m.guard && m.hp > 0);
}
/* 순찰(Patrol): 교전 중이면 메인 스킴에서 위협 제거 불가 (가드=빌런 공격 불가와 구분) */
function hasPatrolEngaged(G, pl){
  return pl.engagedMinions.some(m => m.patrol && m.hp > 0);
}
/* 교전 중 저지 불가(whileEngagedCannotThwart): 이 필드를 가진 하수인이 교전 중이면 그 플레이어는 저지(basic thwart) 불가.
   바론 제모(03028) 등. 순찰(Patrol=메인만)과 달리 모든 스킴 저지 차단. 범용 데이터 필드. */
function hasCannotThwartEngaged(G, pl){
  return pl.engagedMinions.some(m => {
    if (m.hp <= 0) return false;
    const d = MC.cardDef(m.defCode);
    return (m.whileEngagedCannotThwart || (d && d.whileEngagedCannotThwart));
  });
}
/* 위기(Crisis): 전장에 crisis 아이콘 사이드 스킴이 하나라도 있으면 메인 스킴 위협 제거 불가.
   군중 통제(01108) 등. 범용 — 저지/카드 능력 모두 이 헬퍼로 판정. */
function hasCrisisScheme(G){
  return (G.sideSchemes || []).some(s => {
    const d = MC.cardDef(s.defCode);
    return d && d.crisis && s.threat > 0;
  });
}

/* 플레이어가 특정 트레잇을 보유하는지 판정. 신분(영웅/알터에고) 트레잇 +
   플레이 영역 카드가 부여하는 트레잇(cardDef.grantsTrait). 범용 — Aerial/Armor 등. */
function playerHasTrait(G, pl, trait){
  const t = String(trait).toLowerCase();
  // 신분 트레잇 (현재 폼)
  const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
  const fdef = MC.cardDef(faceCode);
  if (fdef && (fdef.traits||[]).some(x => String(x).toLowerCase() === t)) return true;
  // 플레이 영역 카드가 부여하는 트레잇 (grantsTrait: 'aerial' | ['aerial', ...])
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const g = MC.cardDef(c.defCode).grantsTrait;
      if (!g) continue;
      const list = Array.isArray(g) ? g : [g];
      if (list.some(x => String(x).toLowerCase() === t)) return true;
    }
  }
  // 일시적 트레잇 (로켓 부츠 등 — 이번 페이즈 동안 부여, 페이즈 종료 시 리셋)
  if (pl.tempTraits && pl.tempTraits.some(x => String(x).toLowerCase() === t)) return true;
  return false;
}

/* ── condCheck: 조건 판정 단일 창구 ── */
function condCheck(G, cond, ctx){
  if (!cond) return true;
  const r = condCheckRaw(G, cond, ctx);
  return cond.negate ? !r : r;   // 범용 반전 — 어떤 조건이든 negate:true로 뒤집어 재사용
}
function condCheckRaw(G, cond, ctx){
  const pl = ctx && ctx.player;
  switch (cond.type){
    case 'isHeroForm':      return pl && pl.form === 'hero';
    case 'isAlterEgoForm':  return pl && pl.form !== 'hero';
    case 'identityReady':   return pl && !pl.exhausted;   // 신분(히어로/알터에고)이 준비 상태 — 소진 비용 지불 가능 여부
    case 'isAlterEgoForm':  return pl && pl.form === 'alter-ego';
    case 'justBasicAttacked': return pl && !!pl.justBasicAttacked;   // 방금 기본 공격함 (원투 펀치)
    case 'justDefeatedEnemyByAttack': return pl && !!pl.justDefeatedEnemyByAttack;   // 방금 공격으로 적 처치 (추적하라!)
    case 'justDefeatedMinionByHero': return pl && !!pl.justDefeatedMinionByHero;   // 방금 히어로 본인이 하수인 처치 (심문실)
    case 'minionJustEntered': return !!G.minionJustEntered;   // 방금 하수인이 전장에 등장 (호크아이)
    case 'minionPlaced':    return !!(ctx && ctx._minionPlaced);   // 직전 효과로 하수인 배치 성공 (아홉 왕국의 수호자 → 순차)
    case 'discardHadTrait': return !!(ctx && ctx._discardHadTrait);   // 직전 discardTopDeck에서 지정 아이콘(thwart/attack) 카드를 버렸는지 (모방 04105)
    case 'hasReadyWeapon':  return pl && (pl.playArea.upgrades || []).some(c => !c.exhausted && ((MC.cardDef(c.defCode).traits) || []).includes('weapon'));   // 준비된 무기 업그레이드 존재 (Mean Swing)
    case 'justDefended': return pl && !!pl.justDefendedAgainst;   // 방금 히어로가 방어함 (카운터 펀치)
    case 'hasStatus':       return ctx.target && ctx.target.status && ctx.target.status[cond.status] > 0;
    case 'threatGTE':       return MC.resolveScheme(G, cond.scheme||'main').threat >= cond.value;
    case 'minionsInPlay':   return G.players.some(p => p.engagedMinions.length > 0);
    case 'playerCountGTE':  return G.players.length >= cond.value;
    case 'hasTrait':        return pl && playerHasTrait(G, pl, cond.trait);
    case 'isIdentity': {    // 현재 신분(폼) 카드가 특정 코드인지 (캐롤 댄버스 등 특정 영웅 판정)
      if (!pl) return false;
      const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
      const codes = Array.isArray(cond.code) ? cond.code : [cond.code];
      return codes.includes(faceCode);
    }
    case 'notIdentity': {   // isIdentity의 부정 (상호배타 조건부 효과용)
      if (!pl) return true;
      const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
      const codes = Array.isArray(cond.code) ? cond.code : [cond.code];
      return !codes.includes(faceCode);
    }
    case 'paidWith': {      // 결제에 특정 자원 아이콘을 썼는지 (와일드도 충족) — 키커 효과용
      const need = cond.resource;
      const have = (ctx.paidIcons && ((ctx.paidIcons[need]||0) + (ctx.paidIcons.wild||0))) || 0;
      return have >= (cond.count || 1);
    }
    case 'hasCardInPlay': {  // 특정 카드(slug)가 플레이 영역에 존재(소진 무관) — 방패 던지기(방패 반환) 조건 등
      if (!pl) return false;
      for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
        if (arr.some(c => c.defCode === cond.card)) return true;
      return false;
    }
    case 'hasReadyCard': {  // 특정 카드(slug)가 플레이 영역에 준비(비소진) 상태로 존재 — 방패 막기 조건 등
      if (!pl) return false;
      for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
        if (arr.some(c => c.defCode === cond.card && !c.exhausted)) return true;
      return false;
    }
    case 'targetStatus': {  // 대상(villain/self/target)이 특정 상태(tough/confused/stunned)인지 — 범용 재사용
      const t = cond.target === 'villain' ? G.villain
              : cond.target === 'self' ? pl
              : ctx.target;
      return !!(t && t.status && (t.status[cond.status] || 0) > 0);
    }
    case 'villainHasWeapon':   // 빌런에 Weapon 부착물이 있는지 (무기 마스터 급증 조건)
      return !!(G.villain && (G.villain.attachments || []).some(a => (MC.cardDef(a.defCode).traits || []).includes('weapon')));
    case 'villainHasTrait':    // 빌런이 특정 특성을 (흡수 포함) 갖는지 — 어보밍맨 환경 특성 분기. trait 하나 또는 배열(any)
      { const need = Array.isArray(cond.trait) ? cond.trait : [cond.trait];
        const has = MC.villainTraitsOf(G);
        return need.some(t => has.includes(String(t).toLowerCase())); }
    case 'delayGTE':           // 메인 스킴 지연(delay) 카운터가 기준 이상 — 어보밍맨 배반/환경 delay 스케일
      return ((G.mainScheme && G.mainScheme.delayCounters) || 0) >= (cond.amount || 0);
    case 'healedNone':      return (G._lastHealDone || 0) === 0;   // 직전 healVillain이 하나도 회복 못함 (음파 조작 급증)
    case 'minionsAttacked': return (G._lastMinionAttacks || 0) > 0;   // 직전 minionsAttack이 공격을 1회 이상 개시함 (혼돈의 지배 분기 연출)
    case 'schemeInPlay':    // 특정 사이드 스킴(slug)이 전장에 위협을 남긴 채 존재하는지 (폭발!=폭탄 위협 연계)
      return (G.sideSchemes || []).some(s => s.defCode === cond.slug && (s.threat || 0) > 0);
    case 'enemyInPlay':     // 특정 하수인/빌런(slug)이 전장에 살아있는지 (급강하 습격=벌처 전장 시 급증)
      return G.players.some(p => (p.engagedMinions || []).some(m => (m.defCode || m.code) === cond.slug && m.hp > 0))
          || (G.villain && (G.villain.defCode || G.villain.code) === cond.slug && G.villain.hp > 0);
    case 'treasonDiscardedNone': return (G._treasonDiscarded || 0) === 0;   // 욘-로그의 반역: 버린 자원 카드가 없으면 급증
    case 'discardedUpgradeOrSupportNone': return G._discardedUpgradeOrSupport === false;   // Caught Off Guard: 버린 업그레이드/지원 없으면 급증
    case 'nemesisMinionNotEntered': return G._nemesisMinionEntered === false;   // Shadow of the Past: 넴시스 하수인 미등장 시 급증
    case 'noSideSchemesInPlay': return !(G.sideSchemes && G.sideSchemes.length);   // Masterplan: 전장에 사이드 스킴 없을 때
    case 'anySideSchemeInPlay': return !!(G.sideSchemes && G.sideSchemes.length);   // Masterplan: 전장에 사이드 스킴 있을 때
    default: throw new Error('[condCheck] 미등록 조건: ' + cond.type);
  }
}

/* 보복 집계 인덱스 (passiveStatMod 대칭): 한 캐릭터의 총 보복을 모든 소스에서 합산.
   ① 인스턴스 retaliate (적 기본 + attachStats.retaliate가 attachTo로 적용된 분)
   ② 히어로 신분 인쇄 보복 (블랙팬서 등, 히어로 폼만)
   ③ 히어로 비부착 업그레이드/서포트의 grantsRetaliate (캡틴아메리카의 방패 등)
   새 보복 소스는 이 함수에만 추가하면 트리거·표시 전체에 일괄 적용됨. */
function passiveRetaliate(G, ch){
  if (!ch) return 0;
  let r = ch.retaliate || 0;
  if (ch.form === 'hero' && ch.heroCode){
    const fdef = MC.cardDef(ch.heroCode);
    if (fdef && fdef.retaliate) r += fdef.retaliate;
  }
  if (ch.form === 'hero' && ch.playArea){
    for (const arr of [ch.playArea.upgrades, ch.playArea.supports])
      for (const c of arr){ const cd = MC.cardDef(c.defCode); if (cd && cd.grantsRetaliate) r += cd.grantsRetaliate; }
  }
  return r;
}
MC.passiveRetaliate = passiveRetaliate;

/* 보복(Retaliate): 캐릭터가 공격받으면 발동 — 공식 룰: 트리거는 "공격받음"이라 피해량 무관
   (방어로 0피해·강인 흡수여도 발동). 단 그 공격에서 살아남아야(hp>0) 보복 피해를 준다.
   보복 피해는 재보복하지 않음(isRetaliate). 공격 해소부(applyDamage/resolveDefense 등)에서 호출. */
function triggerRetaliate(G, attacked, attacker){
  if (!attacked || !attacker || attacker.hp === undefined) return;
  if (attacked.hp <= 0) return;                      // 공격에서 살아남아야 함
  const retal = passiveRetaliate(G, attacked);       // 집계 인덱스로 총 보복 산출
  if (retal <= 0) return;
  // 연출 힌트 (히어로 신분 보복 / 부착물 부여 보복 / 업그레이드 부여 보복)
  if (attacked.form === 'hero' && attacked.heroCode){
    const fdef = MC.cardDef(attacked.heroCode);
    const rvfx = fdef && fdef.vfx && fdef.vfx.retaliate;
    if (rvfx) G.fxRetaliate = { targetUid: attacker.uid, heroUid: attacked.uid, vfx: rvfx };
  }
  if (!G.fxRetaliate && attacked.form === 'hero' && attacked.playArea){  // 업그레이드 부여 보복(캡틴아메리카의 방패)
    for (const arr of [attacked.playArea.upgrades, attacked.playArea.supports]){
      const c = arr.find(x => { const cd = MC.cardDef(x.defCode); return cd && cd.grantsRetaliate && cd.vfx && cd.vfx.retaliate; });
      if (c){ const cd = MC.cardDef(c.defCode); G.fxRetaliate = { targetUid: attacker.uid, heroUid: attacked.uid, vfx: cd.vfx.retaliate, defCode: c.defCode }; break; }
    }
  }
  if (!G.fxRetaliate && attacked.attachments){
    for (const att of attacked.attachments){
      const adef = MC.cardDef(att.defCode);
      const grantsRetal = adef && ((adef.attachStats && adef.attachStats.retaliate) || adef.retaliate);
      const rvfx = grantsRetal && adef.vfx && adef.vfx.retaliate;
      if (rvfx){ G.fxRetaliate = { targetUid: attacker.uid, heroUid: attacked.uid, vfx: rvfx, defCode: att.defCode }; break; }
    }
  }
  MC.log(G, MC.nameOf(attacked) + ' 보복 — ' + MC.nameOf(attacker) + '에게 ' + retal + ' 피해');
  applyDamage(G, attacker, retal, { source: attacked, isRetaliate: true });
}
MC.triggerRetaliate = triggerRetaliate;

MC.applyDamage = applyDamage; MC.healTarget = healTarget; MC.setStatus = setStatus;MC.onDefeated = onDefeated; MC.advanceVillainStage = advanceVillainStage;
MC.onPlayerDefeated = onPlayerDefeated; MC.condCheck = condCheck;
MC.hasGuardEngaged = hasGuardEngaged; MC.hasPatrolEngaged = hasPatrolEngaged; MC.hasCannotThwartEngaged = hasCannotThwartEngaged; MC.hasCrisisScheme = hasCrisisScheme; MC.playerHasTrait = playerHasTrait;

/* 동료(ally 인스턴스)가 특정 트레잇을 갖는지 — 인쇄 트레잇 + 부착물이 부여하는 트레잇(grantsTrait) 집계.
   명예 어벤져(Avenger 부여) 등. 인플레이 동료 트레잇 판정은 반드시 이 함수로(직접 cardDef.traits 조회 금지). */
function allyHasTrait(G, ally, trait){
  const t = String(trait).toLowerCase();
  const def = MC.cardDef(ally.defCode);
  if (def && (def.traits || []).some(x => String(x).toLowerCase() === t)) return true;
  for (const at of (ally.attachments || [])){
    const g = MC.cardDef(at.defCode).grantsTrait;
    if (!g) continue;
    const list = Array.isArray(g) ? g : [g];
    if (list.some(x => String(x).toLowerCase() === t)) return true;
  }
  return false;
}
MC.allyHasTrait = allyHasTrait;

/* ── 빌런 특성 집계 (환경 특성 흡수) ── 어보밍맨 전용 시스템.
   빌런 인쇄 트레잇 + (gainsEnvironmentTraits면) 전장 환경 트레잇 + grantsElementTraits 사이드스킴 + 부착물 트레잇.
   어보밍맨의 특성별 분기(traitBranch)·표시(UI)는 반드시 이 함수로 판정. 소문자 통일. */
function villainTraitsOf(G){
  const v = G.villain; if (!v) return [];
  const def = MC.cardDef(v.defCode);
  const traits = (def.traits || []).map(t => String(t).toLowerCase());
  const add = t => { const lt = String(t).toLowerCase(); if (!traits.includes(lt)) traits.push(lt); };
  if (def.gainsEnvironmentTraits){
    for (const e of (G.environments || []))
      for (const t of (MC.cardDef(e.defCode).traits || [])) add(t);
    for (const s of (G.sideSchemes || [])){
      const sd = MC.cardDef(s.defCode);
      if (sd.grantsElementTraits) for (const t of sd.grantsElementTraits) add(t);
    }
  }
  for (const a of (v.attachments || []))
    for (const t of (MC.cardDef(a.defCode).traits || [])) add(t);
  return traits;
}
MC.villainTraitsOf = villainTraitsOf;

/* ★ 빌런 활성화 후 특성 분기 반응 (범용 인덱스) — 어보밍맨 III(04078) Forced Response.
   빌런이 공격/스킴으로 활성화한 후, 흡수한 특성에 따라 데이터 분기(villainActivateResponse)를 발동.
   각 분기는 독립(공식: Ice/Stone과 Metal/Wood 조건이 별개로 체크됨 — 두 특성 동시 보유 시 둘 다 발동).
   값·특성·타입만 다른 변형이므로 데이터로 표현. 다른 빌런의 "활성화 후 특성별 효과"에 재사용 가능. */
function villainActivateResponse(G, pl){
  const v = G.villain; if (!v || !pl) return;
  const resp = MC.cardDef(v.defCode).villainActivateResponse;
  if (!resp) return;
  const traits = villainTraitsOf(G);
  for (const b of (Array.isArray(resp) ? resp : [resp])){
    if (!(b.traits || []).some(t => traits.includes(String(t).toLowerCase()))) continue;
    if (b.type === 'threat'){
      MC.placeThreat(G, b.scheme || 'main', b.amount || 1);
      MC.log(G, MC.nameOf(v) + ' — 활성화 반응(' + b.traits.join('/') + '): 메인 스킴 위협 +' + (b.amount || 1));
    } else if (b.type === 'damage'){
      MC.applyDamage(G, pl, b.amount || 1, { source: v, indirect: true });
      MC.log(G, MC.nameOf(v) + ' — 활성화 반응(' + b.traits.join('/') + '): ' + pl.uid + ' 간접 피해 ' + (b.amount || 1));
    }
  }
}
MC.villainActivateResponse = villainActivateResponse;


/* ◇◇ from mc_7_core.js ◇◇ */
/* ═══════════════════════════════════════════════════════════════
   mc_7_core.js — 샤드 7/7 : 게임 상태 · 시드 RNG · 액션 디스패치
   baseFields · 카드 레지스트리/인스턴스 · 플레이어 액션 · 승패
   ★ 멀티플레이 계약: 엔진 100% 결정적. 같은 (seed+액션 로그)=같은 상태.
     RNG는 반드시 "액션 실행 내부"에서만 소모 (MC.rand(G)). Math.random 금지.
   ★ 액션 규율: 검증 먼저, 변이 나중. 검증 실패 throw 시 상태 무변이·로그 미기록.
   IIFE는 mc_1_terms.js에서 열림 → 여기서 닫는다.
   ═══════════════════════════════════════════════════════════════ */

/* ── 시드 RNG (mulberry32) ── */
function rand(G){
  let t = (G.rngState += 0x6D2B79F5);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
function shuffle(G, arr){
  for (let i = arr.length - 1; i > 0; i--){
    const j = Math.floor(rand(G) * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/* ── 카드 레지스트리 ── */
const CARDS = {};
const baseFields = [
  'code','name','nameEn','type','side','faction','aspect','traits','unique',
  'cost','resources','attack','thwart','defense','recover','handSize','hp','scheme',
  'atkCost','thwCost',
  'boost','baseThreat','baseThreatPerPlayer','maxThreat','maxThreatPerPlayer','backLink','experimentalWeaponsDeck','piercingWhileWeapon',
  'gainsEnvironmentTraits','grantsElementTraits','delayPerVillainPhase','testPerVillainPhase','singleEnvironment','surge','onDefeat','envUndefendedResponse','villainActivateResponse','onHeroFormResponse','setupText','captive','villainDamageReflect','removeAfterReflect',
  'toughness','retaliate','guard','patrol','stalwart','piercing','overkill',
  'invulnWhileOtherMinion','invulnUnlessNullified','minionAbility',
  'ranged','aerial','quickstrike','surge','peril','hazard','accelIcons','accelFrom','crisis','whileEngagedCannotThwart',
  'hinder','incite',
  'uses','permanent','restricted','grantsArrowRanged','costReduction','gloryOnMinionDefeat',
  'whenPlayed','response','interrupt','forcedResponse','forcedInterrupt','attackInterrupt','afterBasicAttack','afterAttack','afterThwart','attackDamagedResponse',
  'interruptOn','interruptEffect','activatedAbility','activatedAbilities','whenAttachedDefeated','attachTarget','attachStats','grantsExtraBoost','absorbsVillainDamage','piercingWhileWeapon','removeAbility','attackDamagedEffects','grantsPiercing','quickstrike','keywords','afterUndefendedAttack',
  'attachAttackInterrupt','attackInitiateInterrupt','maxPerTarget','maxPerPlayer','playableFromDiscard','grantsMinionGuard',
  'resourceGenerator','statMod','grantsTrait','defenseInterrupt','defenseInterruptEvent','counterAbility','playForm','playCondition','dynamicHandSize','dynamicStat','allyLimitBonus','onFormChange','identityAction','onMinionEngage','afterEventResponse','afterAttackReaction','eventBoost','defeatInterrupt','rapidResponse','threatPrevent','hpBonus','onSetup','forcedThreatChoice','threatCannotRemove','special','eventScheme','resourceAbility','livingLegend','uiFlow','reviveOnTreachery','boostStarOnDamage','afterPlayTrait','preparationTrigger','needsEnemyTarget','minionStatScale','invocationSpecial','entersWithCounters','entersWithCountersPerHero','attackForcedInterrupt','useCounter','afterDefendNoDamage','onTurnEnd','onFormChangeDiscard',
  'form','altForm','pairedEnv','noAttack','noScheme','attackToCounter','schemeToCounter','damageToCounter','attackThreatOnDamage',   // 양면 폼전환 빌런(그린 고블린 Risky Business)
  'whenRevealed','whenDefeated','whenCompleted','setup',
  'villainPhaseStart','playerPhaseStart','endOfPhase','endOfRound','onFormChange',
  'effects','whenRevealedByForm','whenRevealedByPlayerForm','boostStarEffect','whenRevealedEffects','whenCompletedEffects','attackResponseEffects','whenDefeatedEffects','attackDamagedEffects',
]; // 텍스트/이미지류(textKo·image·flavor 등)는 정의 전용 — cardDef()로 조회
/* 능력 등록 창구: 마이그레이션된 데이터 정의에 effects/훅을 부착 (todoFx 해제) */
/* defineCardFx(code, fields): code는 문자열 또는 문자열 배열.
   중복/리프린트 카드(같은 효과, 다른 slug)는 배열로 한 번에 정의 → fx 통합(단일 소스). */
function defineCardFx(code, fields){
  const codes = Array.isArray(code) ? code : [code];
  for (const c of codes){
    const def = CARDS[c];
    if (!def) throw new Error('[defineCardFx] 미등록 카드: ' + c);
    Object.assign(def, fields);
    delete def.todoFx;
  }
}
/* aliasCardFx(aliasCode, sourceCode): 이미 정의된 source의 fx/능력 필드를 alias로 복사.
   다른 파일에 정의된 리프린트를 통합할 때 사용(카드 고유 식별 필드는 유지). */
const FX_ALIAS_SKIP = new Set(['code','name','nameEn','mcode','image','flavor','hero','aspect','copies','deckLimit','unique','cost','resources','attack','thwart','hp','scheme','atkCost','thwCost','traits','type','side','boost']);
function aliasCardFx(aliasCode, sourceCode){
  const src = CARDS[sourceCode], dst = CARDS[aliasCode];
  if (!src) throw new Error('[aliasCardFx] 원본 미등록: ' + sourceCode);
  if (!dst) throw new Error('[aliasCardFx] 별칭 미등록: ' + aliasCode);
  for (const k in src){ if (!FX_ALIAS_SKIP.has(k)) dst[k] = src[k]; }
  delete dst.todoFx;
}
function registerCards(map){
  for (const code in map){
    if (CARDS[code]) throw new Error('[registerCards] 중복 코드: ' + code);
    CARDS[code] = map[code];
  }
}
function cardDef(code){ return CARDS[code] || null; }
function makeInstance(G, code, extra){
  const def = cardDef(code);
  if (!def) throw new Error('[makeInstance] 미등록 카드: ' + code);
  const inst = { uid: 'c' + (G.uidSeq++), defCode: code };
  for (const f of baseFields) if (def[f] !== undefined) inst[f] = JSON.parse(JSON.stringify(def[f]));
  if (inst.hp !== undefined) inst.maxHp = inst.hp;
  inst.status = { stunned:0, confused:0, tough: def.toughness ? 1 : 0 };
  inst.exhausted = false;
  // 카운터(uses): 카드가 uses 개 카운터를 갖고 등장 (웹 슈터 등). 0이 되면 버림.
  if (def.uses !== undefined) inst.counters = def.uses;
  // 등장 시 카운터(entersWithCounters): 동료 등이 카운터를 갖고 등장 (호크아이 화살 등). 0이 돼도 버리지 않음.
  if (def.entersWithCountersPerHero !== undefined) inst.counters = def.entersWithCountersPerHero * (G.players ? G.players.length : 1);
  else if (def.entersWithCounters !== undefined) inst.counters = def.entersWithCounters;
  return Object.assign(inst, extra || {});
}
function buildDeck(G, codes){ return codes.map(c => makeInstance(G, c)); }

/* ── 게임 상태 ── */
function makeGameState(opt){
  const G = {
    version: MC.VERSION,
    rngState: opt.seed >>> 0, seed: opt.seed >>> 0,
    uidSeq: 1,
    round: 1, phase: 'setup', over: null,
    firstPlayer: 0, acceleration: 0,
    players: [],
    villain: null, mainScheme: null, sideSchemes: [], environments: [],
    encounterDeck: [], encounterDiscard: [], pendingEncounters: [],
    vq: [], pending: null,
    actionLog: [], gameLog: [],
    difficulty: opt.difficulty || 'normal',
  };
  opt.players.forEach((p, i) => G.players.push(MC.makePlayer(G, i, p.heroCode, p.deckCodes)));
  if (opt.villainCode){
    G.villain = makeInstance(G, opt.villainCode, { kind:'villain' });
    const def = cardDef(opt.villainCode);
    const per = def.hpPerPlayer !== undefined ? def.hpPerPlayer : def.hp;
    G.villain.hp = G.villain.maxHp = per * G.players.length;
    // 코어 룰: 빌런은 게임당 정확히 2스테이지만 플레이 (일반=I·II, 전문가=II·III — UI가 시작 단계 결정).
    //   최종 스테이지 번호 = 시작 스테이지 +1 (다음 단계 있을 때). Risky Business 노먼↔고블린 플립은
    //   면마다 defCode가 다르므로(02002a/02002b) 정확한 코드가 아닌 "스테이지 번호"로 최종 판정.
    G.villainFinalStageNum = def.nextStage ? ((def.stage || 1) + 1) : (def.stage || 1);
  }
  if (opt.mainScheme){
    const def = cardDef(opt.mainScheme);
    const ms = makeInstance(G, opt.mainScheme, { isMain: true });
    const n = G.players.length;
    ms.threat = (def.baseThreatPerPlayer||0) * n + (def.baseThreat||0);
    ms.maxThreat = (def.maxThreatPerPlayer||0) * n + (def.maxThreat||0);
    G.mainScheme = ms;
  }
  if (opt.encounterCodes) G.encounterDeck = shuffle(G, buildDeck(G, opt.encounterCodes));
  return G;
}
function setupGame(G){
  // 넴시스 세트 셋어사이드: 각 플레이어의 넴시스 하수인·사이드스킴·나머지 카드를 pl.nemesisSetAside에 준비.
  // Shadow of the Past(01190)가 이 버킷에서 카드를 꺼내 전장/조우덱에 투입. obligation은 별도(조우덱 셔플).
  for (const pl of G.players){
    const key = MC.NEMESIS_BY_HERO && (MC.NEMESIS_BY_HERO[pl.heroCode] || MC.NEMESIS_BY_HERO[pl.aeCode]);
    const set = key && MC.NEMESIS_SETS && MC.NEMESIS_SETS[key];
    if (!set) continue;
    const aside = [];
    if (set.minion){ const m = makeInstance(G, set.minion); m.type = 'minion'; m._nemesisRole = 'minion'; m._nemesisOwner = pl.uid; aside.push(m); }
    if (set.sideScheme){ const s = makeInstance(G, set.sideScheme); s._nemesisRole = 'sideScheme'; s._nemesisOwner = pl.uid; aside.push(s); }
    for (const [slug, qty] of (set.rest || [])){
      for (let i = 0; i < qty; i++){ const c = makeInstance(G, slug); c._nemesisRole = 'rest'; c._nemesisOwner = pl.uid; aside.push(c); }
    }
    pl.nemesisSetAside = aside;
  }
  // 의무(obligation) 카드: 각 플레이어의 영웅 의무를 조우덱에 셔플 (공개 시 whenRevealed 발동).
  // 영웅 slug ↔ 신분 코드 역매핑(MC.HEROES art/aeArt) → hero 필드가 일치하는 obligation 검색.
  {
    const codeToSlug = {};
    for (const slug in (MC.HEROES || {})){
      const hh = MC.HEROES[slug];
      if (hh.art) codeToSlug[hh.art] = slug;
      if (hh.aeArt) codeToSlug[hh.aeArt] = slug;
    }
    let added = false;
    for (const pl of G.players){
      const slug = codeToSlug[pl.heroCode] || codeToSlug[pl.aeCode];
      if (!slug) continue;
      let obCode = null;
      for (const code in MC.CARDS){
        const d = MC.CARDS[code];
        if (d.type === 'obligation' && d.hero === slug){ obCode = code; break; }
      }
      if (!obCode) continue;
      const ob = makeInstance(G, obCode);
      ob._obligationOwner = pl.uid;
      (pl.obligationsOut = pl.obligationsOut || []).push(ob.uid);
      (G.encounterDeck = G.encounterDeck || []).push(ob);
      added = true;
    }
    if (added) shuffle(G, G.encounterDeck);
  }
  for (const pl of G.players){
    shuffle(G, pl.deck);
    MC.drawCards(G, pl, MC.statOf(G, pl, 'handSize') || 6);
  }
  // 닥터 스트레인지: 발동 덱(Invocation Deck) 셋업 — 신비 카드 5종 각 1장을 별도 덱으로 셔플.
  // 스티븐 스트레인지 셋업 능력: 이 발동 덱과 함께 게임 시작. Spell Mastery/Natural Talent가 참조.
  for (const pl of G.players){
    if (pl.heroCode === '09001a' || pl.aeCode === '09001b'){
      const invCards = ['crimson-bands-of-cyttorak','images-of-ikonn','seven-rings-of-raggadorr','vapors-of-valtorr','winds-of-watoomb'];
      pl.invocationDeck = invCards.filter(s => MC.cardDef(s)).map(s => makeInstance(G, s));
      shuffle(G, pl.invocationDeck);
      pl.invocationDiscard = [];
      MC.log(G, MC.nameOf(pl) + ' — 발동 덱(Invocation) ' + pl.invocationDeck.length + '장 구성');
    }
  }
  // 크로스본즈 시나리오: 실험 무기 덱(Experimental Weapons) 셋업 — 빌런 def.experimentalWeaponsDeck를 별도 덱으로 셔플.
  // 크로스본즈 III / 메인 스킴 공개 시 top이 공개되어 빌런에 부착된다 (발동 덱과 유사한 전용 덱).
  {
    const vdef = G.villain && MC.cardDef(G.villain.defCode);
    const wCodes = (vdef && vdef.experimentalWeaponsDeck) || null;
    if (wCodes && wCodes.length){
      G.experimentalWeaponsDeck = wCodes.filter(s => MC.cardDef(s)).map(s => makeInstance(G, s));
      shuffle(G, G.experimentalWeaponsDeck);
      G.experimentalWeaponsDiscard = [];
      MC.log(G, '실험 무기 덱(Experimental Weapons) ' + G.experimentalWeaponsDeck.length + '장 구성');
    }
  }
  // 시나리오 키 저장 (캠페인 코믹스 트리거용) — villainStart로 SCENARIOS 역참조.
  G.scenarioKey = null;
  for (const k in MC.SCENARIOS){
    if (MC.SCENARIOS[k].villainStart === (G.villain && G.villain.defCode)){ G.scenarioKey = k; break; }
  }
  // 신분 셋업 능력 (티찰라 Foresight 등) — 초기 드로우 후, 양면 신분 def의 onSetup 발화
  for (const pl of G.players){
    for (const code of [pl.heroCode, pl.aeCode]){
      const fdef = MC.cardDef(code);
      if (fdef && fdef.onSetup && MC.HANDLERS[fdef.onSetup]){
        MC.HANDLERS[fdef.onSetup](G, { self: fdef, player: pl, hook: 'onSetup' });
      }
    }
  }
  // 메인 스킴 셋업 지시(1A면 Setup — 클로 "방어망 공개" 등): 진행면 def의 onSetup 참조
  if (G.mainScheme){
    const msDef = MC.cardDef(G.mainScheme.defCode);
    if (msDef && msDef.onSetup && MC.HANDLERS[msDef.onSetup]){
      MC.HANDLERS[msDef.onSetup](G, { self: G.mainScheme, hook: 'onSetup' });
    }
    // 공식 룰: 셋업 후 1B면이 공개되며 "공개 시" 효과 해결 (클로 01116b 등)
    MC.fireCardHook(G, G.mainScheme, 'whenRevealed', { player: G.players[G.firstPlayer] });
  }
  MC.fireHook(G, 'setup', {});
  G.phase = 'player';
  log(G, '셋업 완료 — ' + G.players.length + '인 게임 시작');
}

/* ── 액션 디스패치 ──
   검증 throw 시 로그 미기록 (실행 성공 후 기록). 원격은 수신 액션을 동일 dispatch. */
const ACTIONS = {};
function dispatch(G, action){
  const fn = ACTIONS[action.type];
  if (!fn) throw new Error('[dispatch] 미등록 액션: ' + action.type);
  if (G.fxReveal) delete G.fxReveal;   // 이전 액션의 UI 연출 힌트 소거 (표시 전용, 재생 결정성 유지)
  if (G.fxHeroPower) delete G.fxHeroPower;
  if (G.fxIdentityAction) delete G.fxIdentityAction;
  if (G.fxRetaliate) delete G.fxRetaliate;
  if (G.fxWakandaSeq) delete G.fxWakandaSeq;
  if (G.fxHulk) delete G.fxHulk;
  if (G.fxTigra) delete G.fxTigra;
  if (G.fxDaredevil) delete G.fxDaredevil;
  if (G.fxHawkeye) delete G.fxHawkeye;
  if (G.fxVision) delete G.fxVision;
  if (G.fxMakeCall) delete G.fxMakeCall;
  if (G.fxEvent) delete G.fxEvent;
  fn(G, action);
  // 하수인 등장 반응(호크아이 등) — 액션 해소 후 대기 반응이 있으면 선택 pending 세움 (선택 기능 보존)
  if (!G.pending && G._pendingMinionReactions && G._pendingMinionReactions.length && MC.flushMinionReactions)
    MC.flushMinionReactions(G);
  G.actionLog.push(action);
  return G;
}

/* ── 공용 검증 ── */
function assertPlayerTurnable(G, pl){
  if (G.over) throw new Error('게임 종료됨');
  if (G.pending) throw new Error('대기 중인 결정(' + G.pending.kind + ') 해소 필요');
  if (G.phase !== 'player') throw new Error('플레이어 페이즈 아님');
  if (pl.eliminated) throw new Error('탈락한 플레이어');
}

/* ═══ 플레이어 액션 ═══ */

/* 카드 플레이: { player, cardUid, payment:[요소...], targets? }
   구형 호환: paymentUids(손패 uid 배열)도 허용 → 요소로 변환 */
/* 카드 플레이 비용 할인 계산 (순수) — 엔진과 UI가 공유.
   반환 { discount, nextDisc, ll }:
   - nextDisc: 헬리캐리어 등 nextCardDiscount 적용 몫(필터 매치 시)
   - ll: 리빙 레전드(Cap 03001b 배선) 매 라운드 첫 동료 -1
   - discount: 합계. 부수효과 없음(플래그·리셋은 호출측 담당). */
MC.playDiscountOf = function(G, pl, card){
  const cdef = MC.cardDef(card.defCode) || {};
  let nextDisc = pl.nextCardDiscount || 0;
  if (nextDisc > 0 && pl.nextCardDiscountFilter){
    const f = pl.nextCardDiscountFilter;
    let match = true;
    if (f.type && cdef.type !== f.type) match = false;
    if (f.trait && !((cdef.traits || []).some(t => String(t).toLowerCase() === f.trait))) match = false;
    if (!match) nextDisc = 0;
  }
  let ll = 0;
  if (((card.type || cdef.type) === 'ally') && !pl.usedLivingLegendThisRound){
    const aeDef = MC.cardDef(pl.aeCode);
    if (aeDef && aeDef.livingLegend) ll = 1;
  }
  // 카드 자체 동적 할인 (cardDef.costReduction) — 헤라클레스: 교전 하수인 1명당 -1 등.
  let cardDisc = 0;
  const cr = cdef.costReduction;
  if (cr){
    if (cr.per === 'engagedMinion') cardDisc = (pl.engagedMinions || []).length * (cr.amount || 1);
    else if (cr.per === 'upgrade') cardDisc = (pl.playArea.upgrades || []).length * (cr.amount || 1);
    else if (cr.per === 'preparationCard') cardDisc = (pl.playArea.upgrades || []).filter(c => (MC.cardDef(c.defCode).traits || []).includes('preparation')).length * (cr.amount || 1);
    if (cr.max !== undefined) cardDisc = Math.min(cardDisc, cr.max);
  }
  // 아이언맨(iron-man-ally 09039): 인플레이 시 아이언맨에 부착하는 업그레이드 비용 -1.
  // 시뮬 costOf는 부착 대상 확정 전 계산되므로, 아이언맨에 부착 가능한 업그레이드
  // (attachTarget ally/character)에 적용 — Voltron 덱의 아이언맨 강화 의도 반영.
  let ironManDisc = 0;
  if (((card.type || cdef.type) === 'upgrade')){
    const at = cdef.attachTarget;
    if ((at === 'ally' || at === 'character') &&
        (pl.playArea.allies || []).some(a => a.defCode === 'iron-man-ally')){
      ironManDisc = 1;
    }
  }
  return { discount: nextDisc + ll + cardDisc + ironManDisc, nextDisc, ll, cardDisc, ironManDisc };
};
/* 카드의 실제 플레이 비용 (할인 반영). UI 지불/자동선택이 이 값을 사용해야 함. */
MC.playCostOf = function(G, pl, card){
  return Math.max(0, (card.cost || 0) - MC.playDiscountOf(G, pl, card).discount);
};

ACTIONS.playCard = function(G, a){
  const pl = playerByUid(G, a.player);
  // 카드 소스: 손패(기본) / 버린더미(playableFromDiscard — 록조) / 화살통 부착(fromQuiver — 호크아이)
  const fromDiscard = !!a.fromDiscard;
  const fromQuiver = a.fromQuiver || null;   // 화살통(Quiver) uid — 부착된 화살을 손처럼 플레이
  let srcArr;
  if (fromDiscard) srcArr = pl.discard;
  else if (fromQuiver){
    const q = pl.playArea.upgrades.find(u => u.uid === fromQuiver);
    srcArr = (q && q.attachedArrows) || [];
  } else srcArr = pl.hand;
  const idx0 = srcArr.findIndex(c => c.uid === a.cardUid);
  const cardPeek = idx0 >= 0 ? srcArr[idx0] : null;
  const peekDef = cardPeek && MC.cardDef(cardPeek.defCode);
  // 버린더미 플레이는 해당 카드에 playableFromDiscard 플래그가 있어야 함 ("당신의 턴 동안 버린더미에서 플레이 가능")
  if (fromDiscard && !(peekDef && peekDef.playableFromDiscard))
    throw new Error('[playCard] 버린더미에서 플레이 불가: ' + (cardPeek ? cardPeek.name : a.cardUid));
  // 방어 인터럽트 이벤트(Backflip 등)는 방어 pending 상태에서 플레이 가능 — 일반 턴 제약 우회
  const isDefenseInterrupt = peekDef && peekDef.type === 'event' &&
    ((peekDef.traits || []).includes('defense') || peekDef.defenseInterruptEvent) &&
    (peekDef.effects || []).some(e => e.fx === 'preventAll' || e.fx === 'preventAmount') &&
    G.pending && G.pending.kind === 'defense' && G.pending.player === pl.uid;
  if (!isDefenseInterrupt) assertPlayerTurnable(G, pl);
  else if (G.over || pl.eliminated) throw new Error('[playCard] 플레이 불가 상태');
  const idx = srcArr.findIndex(c => c.uid === a.cardUid);
  if (idx < 0) throw new Error('[playCard] ' + (fromDiscard ? '버린더미' : fromQuiver ? '화살통' : '손패') + '에 없음: ' + a.cardUid);
  const card = srcArr[idx];
  if (card.type === 'resource') throw new Error('[playCard] 자원 카드는 결제로만 사용');
  // 폼 제한 (playForm): 특정 형태에서만 플레이 가능한 카드 (법률 업무=alter-ego 등)
  const playForm = MC.cardDef(card.defCode).playForm;
  if (playForm && pl.form !== playForm)
    throw new Error('[playCard] ' + MC.T(playForm) + ' 형태에서만 플레이 가능: ' + card.name);
  // 플레이 조건 (playCondition): 반응(Response) 등 상황 제약 (원투 펀치=방금 기본 공격)
  const playCond = MC.cardDef(card.defCode).playCondition;
  if (playCond && !MC.condCheck(G, playCond, { player: pl }))
    throw new Error('[playCard] 플레이 조건 불충족: ' + card.name);
  const elements = a.payment || (a.paymentUids || []).map(u => ({ kind:'hand', uid:u }));
  if (elements.some(el => el.kind==='hand' && el.uid === a.cardUid))
    throw new Error('[playCard] 자기 자신으로 결제 불가');
  // 검증 (무변이)
  // 비용 할인 (nextCardDiscount + 리빙 레전드) — UI와 공유하는 순수 계산 함수(playDiscountOf) 사용.
  const baseCost = card.cost || 0;
  const dd = MC.playDiscountOf(G, pl, card);
  const nextDisc = dd.nextDisc;   // nextCardDiscount 적용 몫 (아래 소모 리셋용)
  if (dd.ll) pl._livingLegendPending = true;   // 리빙 레전드 적용 → 실제 플레이 확정 시 소모
  const effectiveCost = Math.max(0, baseCost - dd.discount);
  MC.validatePayment(G, pl, elements, effectiveCost, card);
  // 라운드 1회 제한 (어벤져스 어셈블 등 maxPerRound) — defCode 기준 플레이어별 추적.
  {
    const cdef0 = MC.cardDef(card.defCode);
    if (cdef0 && cdef0.maxPerRound){
      const used = (pl.eventsUsedThisRound || {})[card.defCode] || 0;
      if (used >= cdef0.maxPerRound)
        throw new Error('[playCard] ' + card.name + ' — 라운드당 최대 ' + cdef0.maxPerRound + '회');
    }
  }
  // 유니크 검증 (전 플레이어 플레이 영역)
  if (card.unique){
    for (const p2 of G.players)
      for (const arr of [p2.playArea.allies, p2.playArea.supports, p2.playArea.upgrades])
        if (arr.some(c => c.defCode === card.defCode)) throw new Error('[playCard] 유니크 중복: ' + card.name);
  }
  // 지불 자원 아이콘 — 결제 실행 전에 계산 (실행 후엔 손패에서 사라져 계산 불가)
  const paidIcons = MC.computePayment(G, pl, elements, card).icons;
  // ── 변이 시작 ──
  srcArr.splice(idx, 1);
  MC.executePayment(G, pl, elements);
  if (nextDisc > 0){ pl.nextCardDiscount = 0; pl.nextCardDiscountFilter = null; MC.log(G, MC.nameOf(card) + ' 비용 할인 -' + nextDisc + ' 적용'); }
  if (pl._livingLegendPending){ pl.usedLivingLegendThisRound = true; pl._livingLegendPending = false; MC.log(G, MC.nameOf(pl) + ' — 리빙 레전드: 이번 라운드 첫 동료 비용 감소 사용'); }
  log(G, pl.uid + ' 플레이: ' + MC.nameOf(card) + ' (비용 ' + effectiveCost + ')');
  const ctx = { player: pl, card, paidIcons,
                discardUids: a.discardUids || [],
                threatAmount: a.threatAmount || 0,
                targetPlayer: a.targetPlayer,
                targetScheme: a.targetScheme,
                recallUid: a.recallUid,
                discardAllyUid: a.discardAllyUid,
                choice: a.choice,
                discardUids: a.discardUids || [],
                targets: (a.targets||[]).map(u => findByUid(G, u)) };
  switch (card.type){
    case 'ally':   card.ownerUid = pl.uid;
      if (pl.playArea.allies.length >= MC.allyLimitOf(G, pl))
        throw new Error('[playCard] 동료 한도 초과 (최대 ' + MC.allyLimitOf(G, pl) + '명)');
      // 버린더미에서 재플레이(록조 등): 카드가 인플레이를 떠났었으므로 모든 토큰/피해/부착이 제거된 상태로 새로 등장.
      if (fromDiscard){
        const cd2 = MC.cardDef(card.defCode);
        card.damage = 0; card.hp = card.maxHp || (cd2 && cd2.hp) || 0;
        card.exhausted = false;
        card.status = { stunned:0, confused:0, tough: (cd2 && cd2.toughness) ? 1 : 0 };
        card.attachments = [];
      }
      pl.playArea.allies.push(card); break;
    case 'support':card.ownerUid = pl.uid; pl.playArea.supports.push(card); break;
    case 'upgrade':{
      card.ownerUid = pl.uid;
      const at = MC.cardDef(card.defCode).attachTarget;
      // 적/스킴/동료 부착 업그레이드(spider-tracer, enraged 등): 대상에 부착 (upgrades 영역엔 두지 않음)
      if (at === 'minion' || at === 'enemy' || at === 'sideScheme' || at === 'mainScheme' || at === 'ally'){
        const tgt = ctx.targets[0];
        if (!tgt) throw new Error('[playCard] 부착 대상 필요: ' + card.name);
        // 대상당 최대 장수 제약 (webbed-up, enraged 등)
        const maxPer = MC.cardDef(card.defCode).maxPerTarget;
        if (maxPer){
          const same = (tgt.attachments||[]).filter(a => a.defCode === card.defCode).length;
          if (same >= maxPer) throw new Error('[playCard] ' + card.name + ' — 대상당 최대 ' + maxPer + '장');
        }
        MC.attachTo(G, card, tgt);
      } else if (at === 'character'){
        // 우호 캐릭터(히어로 또는 동료) 선택 부착 (명예 어벤져). 임시로 upgrades에 보관 → 선택 시 확정.
        pl.playArea.upgrades.push(card);
        const maxPer = MC.cardDef(card.defCode).maxPerTarget;
        const allyCands = (pl.playArea.allies || []).filter(al => {
          if (!maxPer) return true;
          return (al.attachments || []).filter(x => x.defCode === card.defCode).length < maxPer;
        }).map(al => al.uid);
        // 히어로도 maxPerTarget 검사 (pl.attachments)
        const heroOk = !maxPer || ((pl.attachments || []).filter(x => x.defCode === card.defCode).length < maxPer);
        G.pending = { kind:'attachCharacter', player: pl.uid, cardUid: card.uid,
                      heroTarget: heroOk, allyUids: allyCands,
                      prompt: MC.nameOf(card) + ' — 부착할 우호 캐릭터 선택' };
      } else {
        // 히어로/무부착 업그레이드: 소유자 플레이 영역에 배치
        pl.playArea.upgrades.push(card);
        if (at === 'hero') MC.attachTo(G, card, pl); // 정체성 부착(역참조용)
      }
      break;
    }
    case 'event':
      { const cdef = MC.cardDef(card.defCode);
        if (cdef && cdef.maxPerRound){
          pl.eventsUsedThisRound = pl.eventsUsedThisRound || {};
          pl.eventsUsedThisRound[card.defCode] = (pl.eventsUsedThisRound[card.defCode] || 0) + 1;
        }
        // 이벤트 부스트 인터럽트(Embiggen!/Shrink 등): 준비된 부스터가 있으면 선택 pending으로 이벤트 해결 보류.
        const boosters = MC.readyEventBoosters(G, pl, card);
        if (boosters.length){
          G.pending = { kind:'eventBoostChoice', player: pl.uid, eventCard: card,
            targetUids: (ctx.targets || []).map(t => t && t.uid).filter(Boolean),
            targetScheme: ctx.targetScheme || null, discardUids: ctx.discardUids || [],
            boosterUids: boosters.map(b => b.uid), chosen: [],
            prompt: '이벤트 강화 — 소진해서 강화할 카드를 선택하세요 (선택 안 하려면 건너뛰기)' };
          MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 강화 인터럽트 대기');
          return;   // 부스트 선택 후 resolveEventPlay가 이벤트를 해결(whenPlayed 포함)
        }
        MC.resolveEventPlay(G, pl, card, ctx);
        return;
      }
    default: throw new Error('[playCard] 미지원 유형: ' + card.type);
  }
  MC.fireCardHook(G, card, 'whenPlayed', ctx);
  if (MC.maybeOfferMissionPrep) MC.maybeOfferMissionPrep(G, pl, card);   // 나타샤 Mission Prep: Preparation 카드 플레이 후 드로우
};

/* 이벤트 해결 로직 (effects + special + vfx + 버림 + Morphogenetics 응답 + whenPlayed).
   ctx.eventDamageBonus / ctx.eventThreatBonus = Embiggen!/Shrink 인터럽트로 얹힌 보너스. */
MC.resolveEventPlay = function(G, pl, card, ctx){
  // 카운터 스펠(counterspell) 강제 인터럽트: 히어로에 부착돼 있으면 이 이벤트를 취소+버림, 그 후 자신도 버림.
  const csIdx = (pl.identityAttachments || []).findIndex(a => a.defCode === 'counterspell');
  if (csIdx >= 0){
    const cs = pl.identityAttachments.splice(csIdx, 1)[0];
    MC.log(G, '카운터 스펠 — ' + MC.nameOf(card) + ' 효과 취소 + 버림');
    MC.moveToDiscard(G, pl, card, {});    // 이벤트 취소 (효과 미발동) → 버림
    G.encounterDiscard.push(cs);          // 카운터 스펠 자신도 버림
    MC.log(G, '카운터 스펠 소진 — 조우 버린더미로');
    return;
  }
  const cdef = MC.cardDef(card.defCode);
  const evFx = card.effects || (cdef && cdef.effects);
  if (evFx) MC.runEffectList(G, evFx, ctx);
  const sp = cdef && cdef.special;
  if (sp && MC.HANDLERS[sp]) MC.HANDLERS[sp](G, ctx);
  const evVfx = cdef && cdef.vfx && cdef.vfx.event;
  if (evVfx){
    const targetUids = (ctx.targets || []).map(t => t && t.uid).filter(Boolean);
    G.fxEvent = { vfx: evVfx, targetUids,
      villainUid: (G.villain && G.villain.uid) || null,
      scheme: ctx.targetScheme || (cdef.eventScheme ? 'main' : null) };
  }
  MC.moveToDiscard(G, pl, card, {});
  MC.maybeOfferMorphResponse(G, pl, card);   // 미즈마블 Morphogenetics: 이벤트 플레이 후 소진→손 반환 응답
  MC.fireCardHook(G, card, 'whenPlayed', ctx);
};

/* 준비된 이벤트 부스터 목록 — 히어로 폼 + 미소진 + 이벤트 트레잇이 eventBoost.trait와 일치하는 업그레이드. */
MC.readyEventBoosters = function(G, pl, card){
  if (pl.form !== 'hero') return [];
  const traits = (MC.cardDef(card.defCode).traits || []);
  const out = [];
  for (const up of (pl.playArea.upgrades || [])){
    const d = MC.cardDef(up.defCode) || {};
    if (d.eventBoost && !up.exhausted && traits.includes(d.eventBoost.trait)) out.push(up);
  }
  return out;
};

/* Morphogenetics 응답 해소: { player, accept } — accept면 신분 소진 + 그 이벤트를 버림더미→손. */
/* 레드 대거 처치 인터럽트 해소: { player, decline?, payment?, targetUid? }
   decline이거나 지불 없으면 → 동료 버림. 지불(서로 다른 자원 2개)+대상 지정 시 → 적 피해 + 손 반환. */
ACTIONS.resolveAllyDefeatInterrupt = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'allyDefeatInterrupt') throw new Error('[resolveAllyDefeatInterrupt] 대기 없음');
  const pl = playerByUid(G, p.player);
  const ally = p.ally;
  if (a.decline || !a.payment || !a.payment.length){
    G.pending = null;
    MC.moveToDiscard(G, pl, ally, {});
    MC.log(G, MC.nameOf(ally) + ' — 인터럽트 미사용, 버림');
    return;
  }
  // 지불 검증: 서로 다른 타입 differentTypes개
  const { icons } = MC.computePayment(G, pl, a.payment, null);
  if (!MC.canPayDifferentTypes(icons, p.differentTypes || 2))
    throw new Error('[resolveAllyDefeatInterrupt] 서로 다른 자원 ' + (p.differentTypes||2) + '개 필요');
  const tgt = findByUid(G, a.targetUid);
  if (!tgt) throw new Error('[resolveAllyDefeatInterrupt] 대상 없음');
  MC.executePayment(G, pl, a.payment);
  // 적에게 피해
  if (p.damage) MC.applyDamage(G, tgt, p.damage, { source: ally });
  if (p.vfx) G.fxHeroPower = { hero:'ms-marvel', vfx: p.vfx, targetUid: tgt.uid };
  // 동료를 소유자 손으로 반환 (피해/상태 초기화)
  ally.damage = 0; ally.exhausted = false; ally.status = {};
  if (ally.attachments) ally.attachments = [];
  pl.hand.push(ally);
  MC.log(G, MC.nameOf(ally) + ' — 서로 다른 자원 ' + (p.differentTypes||2) + '개 지불 → '
    + MC.nameOf(tgt) + '에 ' + p.damage + ' 피해 + 손으로 반환');
  G.pending = null;
};

/* 브루노 저장 해소: { player, cardUid } — 손패 1장을 브루노에 엎어서 보관. */
/* 동료 공격개시 인터럽트(Nova): 적이 당신을 공격할 때 자원 지불 → 공격자에 피해.
   { player, cardUid, payment } — 방어 pending 유지(반복 가능). 공격자 처치 시 공격 무효화. */
/* Rapid Response: 동료 처치 후, 소유자가 히어로 폼이고 전장에 Rapid Response 업그레이드가 있으면
   되살림 제안 pending. 동료는 이미 pl.discard에 있음. */
MC.maybeOfferRapidResponse = function(G, pl, ally){
  if (G.pending) return;
  if (pl.form !== 'hero') return;
  const rr = (pl.playArea.upgrades || []).find(u => MC.cardDef(u.defCode).rapidResponse);
  if (!rr) return;
  if (!pl.discard.some(c => c.uid === ally.uid)) return;   // 되살릴 동료가 버린더미에 있어야
  G.pending = { kind:'rapidResponse', player: pl.uid, rapidUid: rr.uid, allyUid: ally.uid,
    prompt: MC.nameOf(rr) + ' — ' + MC.nameOf(ally) + '을(를) 전장으로 되살릴까? (Rapid Response 버림 + 그 동료에 1 피해)' };
  MC.log(G, MC.nameOf(rr) + ' 반응 대기 (' + MC.nameOf(ally) + ' 되살림)');
};

/* Rapid Response 해소: { player, accept } — accept면 Rapid Response 버림 + 동료를 전장에 준비 상태로 배치 + 1피해 + 등장효과 재발동. */
ACTIONS.resolveRapidResponse = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'rapidResponse') throw new Error('[resolveRapidResponse] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (!a.accept){ G.pending = null; MC.log(G, 'Rapid Response 미사용'); return; }
  // 비용: Rapid Response 버림
  const rrIdx = pl.playArea.upgrades.findIndex(u => u.uid === p.rapidUid);
  if (rrIdx >= 0){
    const [rr] = pl.playArea.upgrades.splice(rrIdx, 1);
    if (rr.attachedTo) MC.detachFrom(G, rr);
    MC.moveToDiscard(G, pl, rr, {});
  }
  // 동료를 버린더미 → 전장 (준비, 만피)
  const ai = pl.discard.findIndex(c => c.uid === p.allyUid);
  if (ai >= 0 && pl.playArea.allies.length < MC.allyLimitOf(G, pl)){
    const [ally] = pl.discard.splice(ai, 1);
    ally.damage = 0; ally.exhausted = false; ally.status = {}; ally.attachments = [];
    ally.hp = ally.maxHp; ally.ownerUid = pl.uid;
    pl.playArea.allies.push(ally);
    MC.log(G, 'Rapid Response — ' + MC.nameOf(ally) + ' 전장으로 되살림');
    G.fxHeroPower = { hero: null, vfx:'rapidResponse', targetUid: ally.uid };
    // 등장 효과 재발동 (닉 퓨리 드로우 3 등)
    MC.fireCardHook(G, ally, 'whenPlayed', { player: pl, self: ally, card: ally });
    // 그 동료에 1 피해 (되살림 대가)
    MC.applyDamage(G, ally, 1, {});
  }
  G.pending = null;
};

/* 팀워크(teamworkAlly) 해소 — 동료 1명 소진 → 그 동료의 ATK/THW를 다음 기본 공격/저지 보너스로 프리로드. */
ACTIONS.resolveTeamworkAlly = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'teamworkAlly') throw new Error('[resolveTeamworkAlly] 대기 없음');
  const pl = playerByUid(G, p.player);
  const ally = (pl.playArea.allies || []).find(x => x.uid === a.uid);
  if (!ally) throw new Error('[resolveTeamworkAlly] 동료 없음: ' + a.uid);
  ally.exhausted = true;
  const atk = MC.allyStatOf(G, ally, 'attack'), thw = MC.allyStatOf(G, ally, 'thwart');
  pl.nextBasicAttackBonus = (pl.nextBasicAttackBonus || 0) + atk;
  pl.nextBasicThwartBonus = (pl.nextBasicThwartBonus || 0) + thw;
  MC.log(G, MC.nameOf(pl) + ' 팀워크 — ' + MC.nameOf(ally) + ' 소진 → 다음 기본 공격 +' + atk + ' / 기본 저지 +' + thw);
  G.pending = null;
};

/* 조우덱 예지(encounterScry) 해소 — 하임달 등. a.mode: 'toggle'(버릴 카드 선택) | 'confirm'(확정).
   confirm 시 chosen 카드를 조우 버림 더미로, 나머지는 원래 위 순서 유지로 조우덱에 되돌림. */
ACTIONS.resolveEncounterScry = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'encounterScry') throw new Error('[resolveEncounterScry] 대기 없음');
  if (a.mode === 'toggle'){
    const i = p.chosen.indexOf(a.uid);
    if (i >= 0) p.chosen.splice(i, 1);
    else if (p.chosen.length < p.discard) p.chosen.push(a.uid);
    return;
  }
  if (a.mode === 'confirm'){
    if (p.chosen.length !== p.discard) throw new Error('[resolveEncounterScry] 버릴 카드 ' + p.discard + '장 선택 필요');
    for (const uid of p.chosen){
      const c = p._cards.find(x => x.uid === uid);
      if (c) G.encounterDiscard.push(c);
    }
    const remaining = p._cards.filter(c => !p.chosen.includes(c.uid));
    // revealed는 pop 순서(위→아래). 되돌릴 때 역순 push → 원래 위 순서 복원.
    for (let i = remaining.length - 1; i >= 0; i--) G.encounterDeck.push(remaining[i]);
    MC.log(G, '조우덱 예지 — ' + p.chosen.length + '장 버림, ' + remaining.length + '장 조우덱 상단으로 되돌림');
    G.pending = null;
  }
};

/* 공격 후 선택 반응(afterAttackReaction) 해소 — Battle Fury·Jarnbjorn 등.
   a.mode: 'skip'(넘김) | 'activate'(발동). activate 시 cost 지불(a.payment) + effects + discardSelf. */
ACTIONS.resolveAfterAttackReaction = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'afterAttackReaction') throw new Error('[resolveAfterAttackReaction] 대기 없음');
  const pl = playerByUid(G, p.player);
  const card = MC.findByUid(G, p.cardUid);
  const rx = card && MC.cardDef(card.defCode).afterAttackReaction;
  const advance = () => {
    G.pending = null;
    if (G._afterAttackQueue && G._afterAttackQueue.length){
      const next = G._afterAttackQueue.shift();
      const nc = MC.findByUid(G, next.cardUid);
      if (nc) G.pending = { kind:'afterAttackReaction', player: pl.uid, cardUid: next.cardUid, targetUid: next.targetUid };
      else if (G._afterAttackQueue.length) ACTIONS.resolveAfterAttackReaction(G, { mode:'skip', player: pl.uid });
    }
  };
  if (a.mode === 'skip' || !rx){ MC.log(G, '(공격 후 반응 넘김)'); advance(); return; }
  // 자원 지불 (cost) — Jarnbjorn: {physical:1}. a.payment(결제 요소)로 아이콘 충족 검증.
  if (rx.cost){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els);
    if (!MC.payIconsSatisfied(icons, rx.cost)) throw new Error('[resolveAfterAttackReaction] 자원 부족');
    MC.executePayment(G, pl, els);
  }
  // 대상 (needsTarget) — a.targets
  const targets = (a.targets || []).map(u => MC.findByUid(G, u)).filter(Boolean);
  const ctx = { player: pl, card, self: card, targets };
  MC.log(G, MC.nameOf(card) + ' — 공격 후 반응 발동');
  if (rx.effects) MC.runEffectList(G, rx.effects, ctx);
  // 자기 버림 (discardSelf) — Battle Fury
  if (rx.discardSelf){
    for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
      const i = arr.indexOf(card);
      if (i >= 0){ arr.splice(i, 1); break; }
    }
    MC.moveToDiscard(G, pl, card, {});
  }
  advance();
};

ACTIONS.useAllyAttackInterrupt = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'defense') throw new Error('[useAllyAttackInterrupt] 방어 상황 아님');
  const pl = playerByUid(G, a.player);
  if (pl.uid !== p.player) throw new Error('[useAllyAttackInterrupt] 방어 대상 아님');
  const ally = (pl.playArea.allies || []).find(x => x.uid === a.cardUid);
  if (!ally) throw new Error('[useAllyAttackInterrupt] 동료 없음');
  const ai = MC.cardDef(ally.defCode).attackInitiateInterrupt;
  if (!ai) throw new Error('[useAllyAttackInterrupt] 인터럽트 능력 없음');
  const attacker = findByUid(G, p.attackerUid);
  if (!attacker) throw new Error('[useAllyAttackInterrupt] 공격자 없음');
  // 비용 지불 (payIcons)
  const els = a.payment || [];
  const { icons } = MC.computePayment(G, pl, els, ally);
  if (ai.cost && !MC.payIconsSatisfied(icons, ai.cost))
    throw new Error('[useAllyAttackInterrupt] 자원 지불 불충족: ' + JSON.stringify(ai.cost));
  MC.executePayment(G, pl, els);
  MC.applyDamage(G, attacker, ai.damage || 0, { source: ally });
  G.fxHeroPower = { hero: MC.cardDef(ally.defCode).hero || null, vfx: ai.vfx || 'impact', targetUid: attacker.uid };
  MC.log(G, MC.nameOf(ally) + ' — 공격개시 인터럽트: ' + MC.nameOf(attacker) + '에 ' + (ai.damage||0) + ' 피해');
  // 공격자가 처치되면(HP 0 이하) 이 공격 무효화 (방어 pending 해제)
  if (attacker.hp <= 0){
    MC.log(G, MC.nameOf(attacker) + ' 처치 — 공격 무효화');
    G.pending = null;
  }
};

ACTIONS.resolveBrunoStore = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'brunoStorePick') throw new Error('[resolveBrunoStore] 대기 없음');
  const pl = playerByUid(G, p.player);
  const bruno = findByUid(G, p.brunoUid);
  const idx = pl.hand.findIndex(c => c.uid === a.cardUid);
  if (idx < 0) throw new Error('[resolveBrunoStore] 손패에 없음: ' + a.cardUid);
  const [c] = pl.hand.splice(idx, 1);
  bruno.stored = bruno.stored || [];
  bruno.stored.push(c);
  MC.log(G, MC.nameOf(bruno) + '에 카드 1장 엎어서 보관 (보관 ' + bruno.stored.length + '장)');
  G.fxHeroPower = { hero:'ms-marvel', vfx:'brunoPlace', targetUid: bruno.uid };
  G.pending = null;
};

/* 브루노 회수 해소: { player, cardUids } — 보관 카드 최대 3장을 손으로. */
ACTIONS.resolveBrunoRetrieve = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'brunoRetrievePick') throw new Error('[resolveBrunoRetrieve] 대기 없음');
  const pl = playerByUid(G, p.player);
  const bruno = findByUid(G, p.brunoUid);
  const want = (a.cardUids || []).filter(u => (p.storedUids || []).includes(u)).slice(0, p.max || 3);
  bruno.stored = bruno.stored || [];
  for (const uid of want){
    const i = bruno.stored.findIndex(c => c.uid === uid);
    if (i < 0) continue;
    const [c] = bruno.stored.splice(i, 1);
    c.ownerUid = pl.uid; pl.hand.push(c);
  }
  MC.log(G, MC.nameOf(bruno) + ' — 보관 카드 ' + want.length + '장 회수 (보관 ' + bruno.stored.length + '장 남음)');
  G.fxHeroPower = { hero:'ms-marvel', vfx:'brunoPlace', targetUid: bruno.uid };
  G.pending = null;
};

ACTIONS.resolveEventBoost = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'eventBoostChoice') throw new Error('[resolveEventBoost] 대기 없음');
  const pl = playerByUid(G, p.player);
  const chosen = (a.boosterUids || []).filter(u => (p.boosterUids || []).includes(u));
  let dmgBonus = 0, thrBonus = 0;
  for (const uid of chosen){
    const up = (pl.playArea.upgrades || []).find(x => x.uid === uid);
    if (!up || up.exhausted) continue;
    const eb = (MC.cardDef(up.defCode) || {}).eventBoost;
    if (!eb) continue;
    up.exhausted = true;
    if (eb.stat === 'damage') dmgBonus += (eb.amount || 0);
    else if (eb.stat === 'threat') thrBonus += (eb.amount || 0);
    MC.log(G, MC.nameOf(up) + ' 소진 → ' + MC.nameOf(p.eventCard) + ' 강화 (+' + (eb.amount||0) + ' ' + eb.stat + ')');
    G.fxHeroPower = { hero:'ms-marvel', vfx: eb.vfx || 'embiggen', targetUid: (G.villain && G.villain.uid) || pl.uid };
  }
  // ctx 재구성 후 이벤트 해결 (보너스 반영)
  const card = p.eventCard;
  const ctx = { player: pl, self: card, card,
    targets: (p.targetUids || []).map(u => findByUid(G, u)).filter(Boolean),
    targetScheme: p.targetScheme || null, discardUids: p.discardUids || [],
    eventDamageBonus: dmgBonus, eventThreatBonus: thrBonus };
  G.pending = null;
  MC.resolveEventPlay(G, pl, card, ctx);
};

/* 공개 인터럽트 해소: { player, cardUid?, payment? } — cardUid 없으면 패스 */
ACTIONS.resolveRevealInterrupt = function(G, a){
  MC.resolveRevealInterrupt(G, a.player, a.cardUid || null, a.payment || []);
};

/* ═══ 닥터 스트레인지 Invocation(발동 덱) 시스템 ═══
   발동 덱이 비면 버림 더미를 셔플해 재구성. */
MC.invocationReshuffleIfEmpty = function(G, pl){
  if ((!pl.invocationDeck || !pl.invocationDeck.length) && pl.invocationDiscard && pl.invocationDiscard.length){
    pl.invocationDeck = MC.shuffle(G, pl.invocationDiscard.splice(0));
    MC.log(G, MC.nameOf(pl) + ' — 발동 덱 재셔플 (' + pl.invocationDeck.length + '장)');
  }
};
/* 천부적 재능(Natural Talent): 발동 덱 맨 위 카드 1장을 버림 (효과 없음). */
MC.naturalTalent = function(G, pl){
  MC.invocationReshuffleIfEmpty(G, pl);
  if (!pl.invocationDeck || !pl.invocationDeck.length) return false;
  const top = pl.invocationDeck.shift();
  (pl.invocationDiscard = pl.invocationDiscard || []).push(top);
  MC.log(G, MC.nameOf(pl) + ' — 천부적 재능: ' + MC.nameOf(top) + ' 발동 덱에서 버림');
  G._invocationVfx = { kind:'discard', playerUid: pl.uid, card:{ defCode: top.defCode, name: MC.nameOf(top) } };
  return true;
};
/* 발동 덱 맨 위 카드의 Special 능력 해결. opt.keepOnTop(대가): 앞면 유지 / 기본(Spell Mastery): 버림.
   대상이 필요한 Special은 opt.targets 또는 빌런 기본. */
MC.castInvocation = function(G, pl, opt){
  opt = opt || {};
  MC.invocationReshuffleIfEmpty(G, pl);
  if (!pl.invocationDeck || !pl.invocationDeck.length) return false;
  const top = pl.invocationDeck[0];
  const def = MC.cardDef(top.defCode);
  const targets = (opt.targets && opt.targets.length) ? opt.targets : (G.villain ? [G.villain] : []);
  if (def.invocationSpecial) MC.runEffectList(G, def.invocationSpecial, { player: pl, self: top, targets });
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(top) + ' 발동!');
  G._invocationVfx = { kind:'cast', playerUid: pl.uid, card:{ defCode: top.defCode, name: MC.nameOf(top) } };
  if (!opt.keepOnTop){
    pl.invocationDeck.shift();
    (pl.invocationDiscard = pl.invocationDiscard || []).push(top);
  }
  return true;
};

/* 나타샤 Mission Prep: alter-ego 폼에서 Preparation 카드 플레이 후 → 카드 1장 드로우 (페이즈당 1회). */
MC.maybeOfferMissionPrep = function(G, pl, card){
  const hdef = MC.cardDef(pl.aeCode);
  const mp = hdef && hdef.afterPlayTrait;
  if (!mp) return;
  if (pl.form !== (mp.form || 'alter-ego')) return;
  const cdef = MC.cardDef(card.defCode);
  if (!cdef || !(cdef.traits || []).includes(mp.trait)) return;
  if (mp.oncePerPhase && pl._missionPrepUsed) return;
  pl._missionPrepUsed = true;
  MC.runEffectList(G, mp.effect || [{ fx:'draw', amount:1 }], { player: pl });
  MC.log(G, MC.nameOf(pl) + ' — 임무 준비(Mission Prep): 카드 1장 드로우');
};

/* 블랙위도우 Preparation 발동 헬퍼: 준비 카드를 버림 + Widowmaker 발동(히어로 폼이면 적 1명에 피해 선택).
   각 Preparation 카드(Widow's Bite·Grappling Hook 등)가 자신의 Interrupt/Response 조건 충족 시 이 헬퍼를 호출. */
MC.triggerPreparation = function(G, pl, card, opt){
  opt = opt || {};
  if (opt.discard !== false && card){
    const arr = pl.playArea.upgrades;
    const i = arr.indexOf(card); if (i >= 0) arr.splice(i, 1);
    MC.moveToDiscard(G, pl, card, {});
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 발동(버림)');
  }
  const hdef = MC.cardDef(pl.heroCode);
  if (pl.form === 'hero' && hdef && hdef.preparationTrigger){
    const dmg = hdef.preparationTrigger.damage || 1;
    const enemies = [];
    if (G.villain) enemies.push(G.villain.uid);
    for (const p of G.players) for (const m of (p.engagedMinions || [])) enemies.push(m.uid);
    if (enemies.length){
      G._widowmaker = { player: pl.uid, enemyUids: enemies, damage: dmg };
      MC.log(G, MC.nameOf(pl) + ' — 와이도우메이커 준비(적 1명에 ' + dmg + ' 피해)');
    }
  }
};

/* Widowmaker 발동: 적이 1명이면 자동 피해, 여럿이면 선택 pending. */
MC.offerWidowmaker = function(G){
  const w = G._widowmaker;
  if (!w) return;
  G._widowmaker = null;
  const enemies = (w.enemyUids || []).filter(u => MC.findByUid(G, u));
  if (!enemies.length) return;
  if (enemies.length === 1){
    const t = MC.findByUid(G, enemies[0]);
    MC.applyDamage(G, t, w.damage, { source: { isPlayer: true }, isAttack: false });
    MC.log(G, '와이도우메이커 — ' + MC.nameOf(t) + '에 ' + w.damage + ' 피해');
  } else {
    G.pending = { kind:'widowmaker', player: w.player, enemyUids: enemies, damage: w.damage,
      prompt:'와이도우메이커 — ' + w.damage + ' 피해를 줄 적을 선택하세요' };
  }
};
ACTIONS.resolveWidowmaker = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'widowmaker') throw new Error('[resolveWidowmaker] 대기 없음');
  if (!p.enemyUids.includes(a.uid)) throw new Error('[resolveWidowmaker] 잘못된 대상');
  const t = MC.findByUid(G, a.uid);
  MC.applyDamage(G, t, p.damage, { source: { isPlayer: true }, isAttack: false });
  MC.log(G, '와이도우메이커 — ' + MC.nameOf(t) + '에 ' + p.damage + ' 피해');
  G.pending = null;
};

/* 미즈마블 Morphogenetics: 히어로 신분의 afterEventResponse 조건 충족 시 morphResponse pending 세움.
   조건 — 히어로 폼 + 신분 미소진 + 방금 버린 이벤트가 지정 트레잇(공격/저지/방어) 보유. */
MC.maybeOfferMorphResponse = function(G, pl, event){
  if (G.pending) return;   // 방어 등 다른 대기가 있으면 응답 제안 보류 (중첩 금지)
  if (!pl || pl.form !== 'hero' || pl.exhausted) return;
  const hdef = MC.cardDef(pl.heroCode);
  const resp = hdef && hdef.afterEventResponse;
  if (!resp) return;
  const evd = MC.cardDef(event.defCode) || {};
  const traits = evd.traits || [];
  if (!(resp.traits || []).some(t => traits.includes(t))) return;
  G.pending = { kind:'morphResponse', player: pl.uid, eventUid: event.uid,
    vfx: resp.vfx || null,
    prompt: resp.prompt || (MC.nameOf(pl) + ' 소진 → 이 이벤트를 손으로 되돌릴까?') };
  MC.log(G, MC.nameOf(pl) + ' — Morphogenetics 응답 대기 (' + MC.nameOf(event) + ')');
};

/* Morphogenetics 응답 해소: { player, accept } — accept면 신분 소진 + 그 이벤트를 버림더미→손. */
ACTIONS.resolveMorphResponse = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'morphResponse') throw new Error('[resolveMorphResponse] 대기 없음');
  const pl = playerByUid(G, p.player);
  G.pending = null;
  if (!a.accept){ MC.log(G, MC.nameOf(pl) + ' — Morphogenetics 패스'); return; }
  if (pl.exhausted) throw new Error('[resolveMorphResponse] 신분이 이미 소진됨');
  const i = (pl.discard || []).findIndex(c => c.uid === p.eventUid);
  if (i < 0){ MC.log(G, '이벤트를 버림 더미에서 찾을 수 없음'); return; }
  const [ev] = pl.discard.splice(i, 1);
  ev.ownerUid = pl.uid; pl.hand.push(ev);
  pl.exhausted = true;
  G.fxHeroPower = { hero:'ms-marvel', vfx: p.vfx || 'embiggen', targetUid: pl.uid };
  MC.log(G, MC.nameOf(pl) + ' 소진 → ' + MC.nameOf(ev) + ' 손으로 반환 (Morphogenetics)');
};

/* 카드 활성 능력 사용: { player, cardUid, targets? }
   cardDef.activatedAbility = { form?, exhaust?, effect } — 소진/폼 조건 검증 후 효과 실행.
   범용: 소진 능력을 가진 support/upgrade/ally(메이 숙모, 헬리캐리어 등)에 재사용. */
ACTIONS.useCardAbility = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  // 카드 탐색 (모든 플레이 영역)
  let card = null;
  for (const arr of [pl.playArea.supports, pl.playArea.upgrades, pl.playArea.allies])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; break; } }
  // 조우 부착물의 히어로 행동 (강화된 상아 뿔 등): 빌런 부착물도 탐색
  if (!card && G.villain){
    const c = (G.villain.attachments || []).find(x => x.uid === a.cardUid);
    if (c) card = c;
  }
  // 신분 부착물의 행동 (All Tied Up/Media Coverage): 플레이어 신분 부착도 탐색
  if (!card){
    for (const pl2 of G.players){
      const c = (pl2.identityAttachments || []).find(x => x.uid === a.cardUid);
      if (c){ card = c; break; }
    }
  }
  // 하수인의 히어로 행동 (에디슨의 거대 로봇 무효화 등): 모든 플레이어 교전 하수인 탐색
  if (!card){
    for (const pl2 of G.players){
      const c = (pl2.engagedMinions || []).find(x => x.uid === a.cardUid);
      if (c){ card = c; break; }
    }
  }
  if (!card) throw new Error('[useCardAbility] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  // 능력 2개 이상 카드(브루노 등): activatedAbilities 배열 + abilityIndex로 선택. 단일은 activatedAbility.
  const ab = def.activatedAbilities
    ? def.activatedAbilities[a.abilityIndex || 0]
    : def.activatedAbility;
  if (!ab) throw new Error('[useCardAbility] 활성 능력 없음: ' + card.defCode);
  if (ab.form && pl.form !== ab.form)
    throw new Error('[useCardAbility] ' + ab.form + ' 형태에서만 사용 가능');
  // 반응 조건 검사 (심문실=하수인 처치 후 등)
  if (ab.playCondition && !MC.condCheck(G, ab.playCondition, { player: pl, card }))
    throw new Error('[useCardAbility] 발동 조건 미충족: ' + card.defCode);
  // 라운드당 1회 제한 (비전 등)
  if (ab.oncePerRound && card.usedAbilityThisRound)
    throw new Error('[useCardAbility] 이번 라운드 이미 사용: ' + card.defCode);
  if (ab.exhaust && card.exhausted) throw new Error('[useCardAbility] 이미 소진됨');
  // 추가 코스트: 자신에게 피해 (selfDamage:N) — 집중된 분노 등
  if (ab.selfDamage){
    const dmgTarget = ab.selfDamageTarget === 'card' ? card : pl;
    MC.applyDamage(G, dmgTarget, ab.selfDamage, { source: card, isCost: true });
  }
  // 추가 코스트: 다중 타입 자원 지불 (payIcons:{mental:1,physical:1}) — All Tied Up 등
  if (ab.payIcons){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els, card);
    if (!MC.payIconsSatisfied(icons, ab.payIcons))
      throw new Error('[useCardAbility] 자원 지불 불충족: ' + JSON.stringify(ab.payIcons));
    MC.executePayment(G, pl, els);
  }
  // 추가 코스트: 자원 지불 (payCost:{type, count}) — 결제 요소 a.payment
  if (ab.payCost){
    const els = a.payment || [];
    let paid = 0;
    for (const el of els){
      if (el.kind !== 'hand') throw new Error('[useCardAbility] 손패 자원만 지불 가능');
      const c = pl.hand.find(x => x.uid === el.uid);
      if (!c) throw new Error('[useCardAbility] 손패에 없음: ' + el.uid);
      const icons = MC.resourceIconsOf(c);
      paid += (icons[ab.payCost.type] || 0) + (icons.wild || 0);
    }
    if (paid < (ab.payCost.count || 1))
      throw new Error('[useCardAbility] ' + MC.T(ab.payCost.type) + ' 자원 ' + (ab.payCost.count||1) + ' 필요 (지불 ' + paid + ')');
    MC.executePayment(G, pl, els);
  }
  // 추가 코스트: 손에서 카드 N장 버림 (a.discardUids로 지정)
  if (ab.discardCost){
    const uids = a.discardUids || [];
    if (uids.length !== ab.discardCost)
      throw new Error('[useCardAbility] 버릴 카드 ' + ab.discardCost + '장 선택 필요');
    for (const u of uids){
      const ci = pl.hand.findIndex(c => c.uid === u);
      if (ci < 0) throw new Error('[useCardAbility] 손패에 없음: ' + u);
    }
    // 검증 후 실제 버림
    for (const u of uids){
      const c = pl.hand.find(x => x.uid === u);
      pl.hand.splice(pl.hand.indexOf(c), 1);
      MC.moveToDiscard(G, pl, c, {});
    }
  }
  // 소진
  if (ab.exhaust) card.exhausted = true;
  // 카운터 소비 (useCounter:N) — Tac Team 등 Uses 기반. 소진 시 버림.
  if (ab.useCounter){
    if ((card.counters || 0) < ab.useCounter)
      throw new Error('[useCardAbility] 카운터 부족: ' + MC.nameOf(card));
    card.counters -= ab.useCounter;
    MC.log(G, MC.nameOf(card) + ' 카운터 ' + ab.useCounter + ' 소비 (' + card.counters + ' 남음)');
  }
  // 효과 실행
  const ctx = { player: pl, card, self: card,
                targetScheme: a.targetScheme,
                targetPlayer: a.targetPlayer,
                targets: (a.targets||[]).map(u => findByUid(G, u)) };
  log(G, pl.uid + ' 카드 능력: ' + MC.nameOf(card));
  if (ab.effect) MC.runEffectList(G, Array.isArray(ab.effect) ? ab.effect : [ab.effect], ctx);
  // special 핸들러 (호크아이 화살 등 — effect로 표현 어려운 로직)
  if (ab.special && MC.HANDLERS[ab.special]) MC.HANDLERS[ab.special](G, { ...ctx, choice: a.choice });
  if (ab.oncePerRound) card.usedAbilityThisRound = true;
  // Preparation 발동(블랙위도우): 카드를 버리고 Widowmaker 트리거(히어로 폼이면 적 1명에 피해 대기).
  if (ab.preparation){
    MC.triggerPreparation(G, pl, card);
    if (G._widowmaker) MC.offerWidowmaker(G);
  }
  // 카운터 소진 시 버림 (모든 카운터 소진 → discard). keepOnEmpty면 유지 (Hall of Heroes 등 영구 지원).
  if (ab.useCounter && !ab.keepOnEmpty && (card.counters || 0) <= 0){
    for (const arr of [pl.playArea.supports, pl.playArea.upgrades, pl.playArea.allies]){
      const i = arr.indexOf(card);
      if (i >= 0){ arr.splice(i, 1); break; }
    }
    MC.moveToDiscard(G, pl, card, {});
    MC.log(G, MC.nameOf(card) + ' — 카운터 소진, 버림');
  }
};

/* 방어 인터럽트: 방어 pending 시 플레이 영역의 defenseInterrupt 카드 발동.
   피해 N 방지 후 필요 시 자체 버림. { player, cardUid } */
ACTIONS.useDefenseInterrupt = function(G, a){
  const pl = playerByUid(G, a.player);
  if (!G.pending || G.pending.kind !== 'defense' || G.pending.player !== pl.uid)
    throw new Error('[useDefenseInterrupt] 방어 상황이 아님');
  let card = null;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; break; } }
  if (!card) throw new Error('[useDefenseInterrupt] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  const di = def.defenseInterrupt;
  if (!di) throw new Error('[useDefenseInterrupt] 방어 인터럽트 없음: ' + card.defCode);
  const p = G.pending;
  // 같은 공격에 같은 카드는 1회만 (Energy Barrier RRG: 조건당 1회)
  p.usedInterrupts = p.usedInterrupts || [];
  if (p.usedInterrupts.includes(card.uid)) throw new Error('[useDefenseInterrupt] 이 공격에 이미 사용됨');
  // 반영 카운터 소비 (Energy Barrier)
  if (di.counter){
    if ((card.counters || 0) < di.counter) throw new Error('[useDefenseInterrupt] 카운터 부족: ' + MC.nameOf(card));
    card.counters -= di.counter;
  }
  // 자원 지불 (Mockingbird: 아무 자원 1) — 실패 시 롤백 없이 throw
  if (di.payAny){
    const els = a.payment || [];
    const { sum } = MC.computePayment(G, pl, els, card);
    if (sum < di.payAny) throw new Error('[useDefenseInterrupt] 자원 부족 (' + sum + '/' + di.payAny + ')');
    MC.executePayment(G, pl, els);
  }
  log(G, pl.uid + ' 방어 인터럽트: ' + MC.nameOf(card));
  // 피해 방지 (부분 prevent:N 또는 전체 preventAll)
  if (di.preventAll) MC.EFFECTS.preventAll(G, {}, { player: pl, card });
  else if (di.prevent) MC.EFFECTS.preventAmount(G, { amount: di.prevent }, { player: pl, card });
  // 무피해 시 히어로 재준비 플래그 (필사의 방어) — 방어 해소 시 dmg===0이면 ready.
  if (di.readyIfNoDamage) p.readyIfNoDamage = true;
  // 적에게 피해 (Energy Barrier: 카운터당 1피해)
  if (di.damageEnemy){
    const atk = MC.findByUid(G, p.attackerUid);
    if (atk){
      MC.applyDamage(G, atk, di.damageEnemy, { source: card });
      MC.log(G, MC.nameOf(card) + ' — ' + MC.nameOf(atk) + '에 ' + di.damageEnemy + ' 피해');
      if (atk.hp <= 0){ MC.log(G, MC.nameOf(atk) + ' 처치 — 공격 무효화'); G.pending = null; }
    }
  }
  if (di.vfx) G.fxHeroPower = { hero: def.hero || null, vfx: di.vfx, targetUid: p.attackerUid };
  if (G.pending) p.usedInterrupts.push(card.uid);
  // 손 반환 (Mockingbird: 인터럽트 후 소유자 손으로) — returnToHand가 인플레이 제거+상태 리셋
  if (di.returnToHand){
    MC.EFFECTS.returnToHand(G, {}, { player: pl, card, self: card });
  }
  // 자체 버림 (discardSelf 또는 카운터 소진)
  else if (di.discardSelf || (di.counter && (card.counters || 0) <= 0)){
    const arr = pl.playArea.upgrades.includes(card) ? pl.playArea.upgrades
              : pl.playArea.supports.includes(card) ? pl.playArea.supports
              : pl.playArea.allies;
    const i = arr.indexOf(card);
    if (i >= 0) arr.splice(i, 1);
    if (card.attachedTo) MC.detachFrom(G, card);
    MC.moveToDiscard(G, pl, card, {});
    MC.log(G, MC.nameOf(card) + (di.counter ? ' — 카운터 소진, 버림' : ' — 사용 후 버림'));
  }
  // 준비(Preparation) 방어 인터럽트 발동 → Widowmaker (방어 흐름 중이라 빌런 직접 피해로 처리)
  if (di.preparation){
    const hdefW = MC.cardDef(pl.heroCode);
    if (pl.form === 'hero' && hdefW && hdefW.preparationTrigger && G.villain){
      MC.applyDamage(G, G.villain, hdefW.preparationTrigger.damage || 1, { source:{ isPlayer:true }, isAttack:false });
      MC.log(G, '와이도우메이커 — 빌런에 ' + (hdefW.preparationTrigger.damage||1) + ' 피해');
    }
  }
};

/* 기본 공격: { player, targetUid } */
ACTIONS.basicAttack = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'hero') throw new Error('[basicAttack] 영웅 형태 아님');
  if (pl.exhausted) throw new Error('[basicAttack] 소진됨');
  if (pl.status.stunned > 0){ // 기절: 공격 대신 토큰 제거 (활성화 소모)
    pl.exhausted = true; pl.status.stunned--;
    log(G, pl.uid + ' 기절 해제에 활성화 소모');
    return;
  }
  const target = findByUid(G, a.targetUid);
  if (!target || target.hp === undefined) throw new Error('[basicAttack] 유효하지 않은 대상');
  if (target.kind === 'villain' && MC.hasGuardEngaged(G, pl))
    throw new Error('[basicAttack] 수호 하수인 교전 중 — 빌런 공격 불가');
  pl.exhausted = true;
  pl.justBasicAttacked = true;   // 반응 트리거용 (원투 펀치 등) — 다음 액션에서 해제
  const atkTarget = target;
  // Mean Swing 등 "이번 기본 공격 한정" 보너스 (무기 소진 → +3 ATK). 공격 직후 리셋.
  const atkVal = MC.statOf(G, pl, 'attack') + (pl.nextBasicAttackBonus || 0);
  pl.nextBasicAttackBonus = 0;
  const basicOverkill = !!pl.nextBasicAttackOverkill;   // 헐크 스매시: 물리 지불 시 이번 기본 공격 과잉살상
  pl.nextBasicAttackOverkill = false;
  pl.nextBasicThwartBonus = 0;   // Teamwork 1회용: 공격에 썼으면 저지 보너스도 소멸
  MC.applyDamage(G, target, atkVal, { source: pl, isAttack: true, noRetaliate: true, overkill: basicOverkill });
  // ★ 보복: 공격받은 대상(부착물 등으로 retaliate 보유)이 살아남았으면 피해량 무관하게 발동
  //   (강인 흡수·0피해여도). RRG 순서: 공격 해소 후 보복 → 그 다음 강제 반응(afterBasicAttack).
  MC.triggerRetaliate(G, atkTarget, pl);
  // 기본 공격 후 강제 반응 (초인적인 힘 등): 플레이 영역 카드의 afterBasicAttack 훅
  MC.fireAfterBasicAttack(G, pl, atkTarget);
};

/* 신분 액션 (라운드 1회): 캡틴마블 Rechannel·캐롤 Commander·토니 Futurist 등.
   신분 카드 def.identityAction = { form, oncePerRound, payEnergy, selfHeal, effect }.
   { player, targets? } — effect는 EFFECTS 파이프라인. */
ACTIONS.useIdentityAction = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
  const def = MC.cardDef(faceCode);
  const ia = def && def.identityAction;
  if (!ia) throw new Error('[useIdentityAction] 신분 액션 없음: ' + faceCode);
  if (ia.form && pl.form !== ia.form) throw new Error('[useIdentityAction] ' + MC.T(ia.form) + ' 형태 전용');
  if (ia.oncePerRound && pl.usedIdentityActionThisRound[pl.form]) throw new Error('[useIdentityAction] 이번 라운드 이미 사용 (' + MC.T(pl.form) + ')');
  // 페이즈당 1회 제한 (호크아이 Weapon of Choice 등). usedIdentityActionThisPhase[form].
  pl.usedIdentityActionThisPhase = pl.usedIdentityActionThisPhase || {};
  if (ia.oncePerPhase && pl.usedIdentityActionThisPhase[pl.form]) throw new Error('[useIdentityAction] 이번 페이즈 이미 사용 (' + MC.T(pl.form) + ')');
  // 비용: 히어로 자신 소진 (호크아이 Quick Draw: "Exhaust Hawkeye"). 준비 상태여야 사용 가능.
  if (ia.exhaustSelf){
    if (pl.exhausted) throw new Error('[useIdentityAction] 이미 소진됨 — 소진 비용 지불 불가');
  }
  // 비용: 아무 자원 N개 지불 (호크아이 Weapon of Choice: 아무 자원 1). payEnergy와 배타.
  if (ia.payAny){
    const els = a.payment || [];
    const { sum } = MC.computePayment(G, pl, els, null);
    if (sum < ia.payAny) throw new Error('[useIdentityAction] 자원 부족 (' + sum + '/' + ia.payAny + ')');
    MC.executePayment(G, pl, els, null);
  }
  // 비용: 에너지 자원 지불 (a.payment 요소로)
  if (ia.payEnergy){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els, null);
    if ((icons.energy||0) + (icons.wild||0) < ia.payEnergy)
      throw new Error('[useIdentityAction] 에너지 자원 부족');
    MC.executePayment(G, pl, els, null);
  }
  // 비용: 자기 회복 조건 (Rechannel: 1 피해 회복 — 피해 없으면 사용 불가)
  if (ia.selfHeal){
    if (pl.hp >= (MC.heroFace(G, pl).hp || pl.hp)) throw new Error('[useIdentityAction] 회복할 피해 없음');
    MC.healTarget(G, pl, ia.selfHeal);
  }
  // 비용: 손패 버림 (캡틴아메리카 "하루 종일도 가능해!": 손패 1장 버림 → 준비).
  // a.discard = 버릴 손패 카드 uid 배열. 지정 없으면 임의로 첫 N장 버림(UI 미지정 대비).
  if (ia.discardCost){
    const need = ia.discardCost;
    if (pl.hand.length < need) throw new Error('[useIdentityAction] 버릴 손패 부족 (' + pl.hand.length + '/' + need + ')');
    const uids = (a.discard || []).slice(0, need);
    const chosen = [];
    for (const u of uids){ const c = MC.fromHand(pl, u); if (c) chosen.push(c); }
    while (chosen.length < need && pl.hand.length) chosen.push(pl.hand.shift());
    for (const c of chosen) MC.moveToDiscard(G, pl, c, {});
    MC.log(G, MC.nameOf(pl) + ' — 손패 ' + chosen.length + '장 버림 (액션 비용)');
  }
  // 효과 실행
  if (ia.effect) MC.runEffectList(G, ia.effect, { player: pl, card: def, targets: (a.targets||[]).map(uid => findByUid(G, uid)).filter(Boolean) });
  // 히어로 자신 소진 (Quick Draw): 효과 해결 후 소진 (활 준비 → 호크아이 소진)
  if (ia.exhaustSelf) pl.exhausted = true;
  if (ia.oncePerRound) pl.usedIdentityActionThisRound[pl.form] = true;
  if (ia.oncePerPhase) pl.usedIdentityActionThisPhase[pl.form] = true;
  MC.log(G, MC.nameOf(pl) + ' 신분 액션: ' + (ia.name || def.name));
  G.fxIdentityAction = { face: faceCode, vfx: ia.vfx };
};

/* 기본 저지: { player, scheme } */
ACTIONS.basicThwart = function(G, a){
  const pl = playerByUid(G, a.player);
  pl.justBasicAttacked = false;   // 다른 기본 행동 → 반응 기회 소멸
  pl.justDefeatedEnemyByAttack = false;
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'hero') throw new Error('[basicThwart] 영웅 형태 아님');
  if (pl.exhausted) throw new Error('[basicThwart] 소진됨');
  if (pl.status.confused > 0){
    pl.exhausted = true; pl.status.confused--;
    log(G, pl.uid + ' 혼란 해제에 활성화 소모');
    return;
  }
  // ★ 룰 정정: 가드(Guard)는 "빌런 공격 불가"만 제한. 메인 스킴 저지 제한은 순찰(Patrol) 키워드.
  if ((a.scheme === 'main' || !a.scheme) && MC.hasPatrolEngaged(G, pl))
    throw new Error('[basicThwart] 순찰 하수인 교전 중 — 메인 스킴 저지 불가');
  // 교전 중 저지 불가(바론 제모 등): 모든 스킴 저지 차단
  if (MC.hasCannotThwartEngaged(G, pl))
    throw new Error('[basicThwart] 저지 불가 하수인 교전 중 (바론 제모 등) — 저지할 수 없음');
  // 위기(Crisis): crisis 사이드 스킴이 전장에 있으면 메인 스킴 위협 제거 불가
  if ((a.scheme === 'main' || !a.scheme) && MC.hasCrisisScheme(G))
    throw new Error('[basicThwart] 위기(Crisis) 사이드 스킴 — 먼저 처치해야 메인 스킴 저지 가능');
  pl.exhausted = true;
  const thwVal = MC.statOf(G, pl, 'thwart') + (pl.nextBasicThwartBonus || 0);
  pl.nextBasicThwartBonus = 0;
  pl.nextBasicAttackBonus = 0;   // Teamwork 1회용: 저지에 썼으면 공격 보너스도 소멸
  MC.removeThreat(G, a.scheme || 'main', thwVal);
};

/* 기본 회복: { player } */
ACTIONS.basicRecover = function(G, a){
  const pl = playerByUid(G, a.player);
  pl.justBasicAttacked = false;
  pl.justDefeatedEnemyByAttack = false;
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'alter-ego') throw new Error('[basicRecover] 알터에고 형태 아님');
  if (pl.exhausted) throw new Error('[basicRecover] 소진됨');
  pl.exhausted = true;
  MC.healTarget(G, pl, MC.statOf(G, pl, 'recover'));
};

/* 동료 공격/저지: { player, allyUid, targetUid|scheme } — 후유증 피해(atkCost/thwCost) */
/* 동료 공격 실행 코어 (추가 비용 지불 후 재사용) — 피해+보복+afterAttack+consequential. */
function performAllyAttack(G, pl, ally, target){
  ally.exhausted = true;
  MC.applyDamage(G, target, MC.allyStatOf(G, ally, 'attack'), { source: ally, isAttack: true, noRetaliate: true });
  // ★ 보복: 공격받은 대상이 살아남았으면 피해량 무관하게 동료에게 발동 (강인 흡수·0피해여도)
  MC.triggerRetaliate(G, target, ally);
  // 동료 공격 후 강제 반응 (헐크/타이그라 등) — 공격 대상/공격자 전달.
  // ★ atkCost(consequential 자기 피해) 적용 *전*에 발화 (타이그라 FAQ: 회복이 자기 피해보다 먼저).
  MC.fireCardHook(G, ally, 'afterAttack', { player: pl, attacker: ally, target });
  if (ally.atkCost) MC.applyDamage(G, ally, ally.atkCost, { isConsequential: true });
}
MC.performAllyAttack = performAllyAttack;

ACTIONS.allyAttack = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  const ally = pl.playArea.allies.find(x => x.uid === a.allyUid);
  if (!ally) throw new Error('[allyAttack] 동료 없음');
  if (ally.exhausted) throw new Error('[allyAttack] 동료 소진됨');
  if (ally.status.stunned > 0){ ally.exhausted = true; ally.status.stunned--; log(G, MC.nameOf(ally)+' 기절 해제'); return; }
  const target = findByUid(G, a.targetUid);
  if (!target || target.hp === undefined) throw new Error('[allyAttack] 유효하지 않은 대상');
  if (target.kind === 'villain' && MC.hasGuardEngaged(G, pl))
    throw new Error('[allyAttack] 수호 하수인 교전 중 — 빌런 공격 불가');
  // 공격 추가 비용 (원더맨 등): attackExtraCost.discardFromHand N장 — 어느 카드 버릴지 플레이어 선택.
  const adef = MC.cardDef(ally.defCode);
  const need = adef && adef.attackExtraCost && adef.attackExtraCost.discardFromHand;
  if (need){
    if ((pl.hand || []).length < need)
      throw new Error('[allyAttack] 손패 부족 — ' + MC.nameOf(ally) + ' 공격 불가 (추가 비용 ' + need + '장 버림)');
    G.pending = { kind:'handDiscardCost', player: pl.uid, allyUid: ally.uid, targetUid: target.uid,
                  count: need, chosen: [],
                  prompt: MC.nameOf(ally) + ' 공격 추가 비용 — 손패에서 ' + need + '장 버리기' };
    log(G, MC.nameOf(ally) + ' 공격 추가 비용 — 버릴 카드 ' + need + '장 선택 대기');
    return;
  }
  performAllyAttack(G, pl, ally, target);
};

/* 동료 공격 추가 비용(손패 버림) 해소 — a.uid 손패 카드 버림, count 채우면 실제 공격 실행. */
/* 동료 소진→드로우 다중선택 해소 — a.mode:'toggle'(a.uid 선택/해제) | 'confirm'(소진+드로우 실행). */
/* 동료 배치 선택 해소 — a.uid 동료를 손에서 전장에 무료 배치 → (discardSource면) 소스 버림 → 등장 반응 발화. */
/* 우호 캐릭터 부착 선택 해소 — a.target:'hero' 또는 동료 uid. 명예 어벤져 등 attachTarget:'character'. */
/* 손패 선택 버림 해소 — a.uid 카드를 버림. remaining 소진 시 afterEffects 실행. */
ACTIONS.resolveDiscardChoose = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'discardChoose') throw new Error('[resolveDiscardChoose] 대기 없음');
  const pl = playerByUid(G, p.player);
  const idx = pl.hand.findIndex(c => c.uid === a.uid);
  if (idx < 0) throw new Error('[resolveDiscardChoose] 손패에 없음');
  const card = pl.hand[idx];
  pl.hand.splice(idx, 1);
  MC.moveToDiscard(G, pl, card, {});
  p.chosen.push(a.uid);
  p.remaining -= 1;
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 버림 (' + p.remaining + '장 남음)');
  if (p.remaining <= 0){
    const self = MC.findByUid(G, p.selfUid);
    const after = p.afterEffects || [];
    G.pending = null;
    if (after.length) MC.runEffectList(G, after, { player: pl, self, card: self, targetScheme:'main' });
  }
};
// 통제 카드 선택 버림 해소 (Caught Off Guard·의무 등 — 후보 2장 이상일 때 플레이어가 고른 카드).
// 손패 자원 카드 선택 버림 해소 (Tombstone·Power Drain — 무작위 아닌 자원 버림).
ACTIONS.resolveResourceDiscardPick = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'resourceDiscardPick') throw new Error('[resolveResourceDiscardPick] 대기 없음');
  const pl = playerByUid(G, p.player);
  const card = (pl.hand || []).find(c => c.uid === a.uid);
  if (!card) throw new Error('[resolveResourceDiscardPick] 손패에 없음');
  // 자원 필터 검증
  const ic = MC.resourceIconsOf(card) || {};
  const ok = (!p.types || !p.types.length) ? Object.values(ic).some(v => v > 0)
           : (p.types.some(t => (ic[t] || 0) > 0) || (ic.wild || 0) > 0);
  if (!ok) throw new Error('[resolveResourceDiscardPick] 자원 카드 아님');
  MC.discardHandCard(G, pl, card);
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 버림' + (p.reason ? ' (' + p.reason + ')' : ''));
  p.chosen += 1;
  if (p.chosen >= p.count){
    // 이 플레이어 완료 → 큐의 다음 플레이어로 (또는 pending 해제)
    const spec = { queue: p.queue || [], perPlayerCount: p.perPlayerCount, types: p.types, prompt: p.prompt, reason: p.reason };
    G.pending = null;
    MC.setupResourceDiscardPick(G, spec);
  }
};
ACTIONS.resolvePickControlledDiscard = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'pickControlledDiscard') throw new Error('[resolvePickControlledDiscard] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (!(p.cardUids || []).includes(a.uid)) throw new Error('[resolvePickControlledDiscard] 선택 불가 카드');
  const card = MC.findByUid(G, a.uid);
  if (!card) throw new Error('[resolvePickControlledDiscard] 카드 없음');
  MC.discardControlledCard(G, pl, card, '선택 버림');
  G.pending = null;
};
ACTIONS.resolveAttachCharacter = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'attachCharacter') throw new Error('[resolveAttachCharacter] 대기 없음');
  const pl = playerByUid(G, p.player);
  const card = pl.playArea.upgrades.find(c => c.uid === p.cardUid);
  if (!card) throw new Error('[resolveAttachCharacter] 카드 없음');
  if (a.target === 'hero'){
    if (!p.heroTarget) throw new Error('[resolveAttachCharacter] 히어로 부착 불가');
    MC.attachTo(G, card, pl);              // 히어로(정체성) 부착
    if (MC.cardDef(card.defCode).hpBonus) MC.recomputeMaxHp(G, pl);   // 히어로 HP는 recompute로
  } else {
    const ally = (pl.playArea.allies || []).find(x => x.uid === a.target);
    if (!ally || !(p.allyUids || []).includes(a.target)) throw new Error('[resolveAttachCharacter] 선택 불가 동료');
    // upgrades 임시 보관에서 빼서 동료에 부착 (attachTo가 hpBonus/트레잇 처리)
    pl.playArea.upgrades.splice(pl.playArea.upgrades.indexOf(card), 1);
    MC.attachTo(G, card, ally);
  }
  G.pending = null;
};
ACTIONS.resolveDeployAlly = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'deployAlly') throw new Error('[resolveDeployAlly] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (!(p.allyUids || []).includes(a.uid)) throw new Error('[resolveDeployAlly] 선택 불가 동료');
  const ally = pl.hand.find(c => c.uid === a.uid);
  if (!ally) throw new Error('[resolveDeployAlly] 손패에 없음');
  if (pl.playArea.allies.length >= MC.allyLimitOf(G, pl))
    throw new Error('[resolveDeployAlly] 동료 한도 초과 (최대 ' + MC.allyLimitOf(G, pl) + '명)');
  // 손에서 제거 → 전장 무료 배치
  pl.hand.splice(pl.hand.indexOf(ally), 1);
  ally.ownerUid = pl.uid;
  pl.playArea.allies.push(ally);
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(ally) + ' 전장 배치 (무료)');
  // "그 후 소스 버림" (퀸젯) — 등장 반응 전에 처리
  if (p.discardSource){
    const src = MC.findByUid(G, p.sourceUid);
    if (src){
      for (const arr of [pl.playArea.supports, pl.playArea.upgrades, pl.playArea.allies]){
        const i = arr.indexOf(src);
        if (i >= 0){ arr.splice(i, 1); break; }
      }
      MC.moveToDiscard(G, pl, src, {});
      MC.log(G, MC.nameOf(src) + ' 버림');
    }
  }
  G.pending = null;   // deployAlly 해소
  // 등장 반응 발화 (whenPlayed 훅 — 팔콘/스쿼럴걸 등). 새 pending을 세울 수 있음(그대로 유지).
  MC.fireCardHook(G, ally, 'whenPlayed', { player: pl });
};
ACTIONS.resolveAllyExhaustDraw = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'allyExhaustDraw') throw new Error('[resolveAllyExhaustDraw] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (a.mode === 'toggle'){
    if (!(p.allyUids || []).includes(a.uid)) throw new Error('[resolveAllyExhaustDraw] 선택 불가 동료');
    const i = p.chosen.indexOf(a.uid);
    if (i >= 0) p.chosen.splice(i, 1); else p.chosen.push(a.uid);
    return;                                              // pending 유지 (계속 토글)
  }
  // confirm: 선택된 동료 소진 + 그 수만큼 드로우 (0명이면 드로우 0)
  let n = 0;
  for (const uid of p.chosen){
    const ally = pl.playArea.allies.find(x => x.uid === uid);
    if (ally && !ally.exhausted){ ally.exhausted = true; n++; }
  }
  G.pending = null;
  if (n > 0){ MC.drawCards(G, pl, n); MC.log(G, MC.nameOf(pl) + ' — 동료 ' + n + '명 소진 → ' + n + '장 드로우'); }
  else MC.log(G, MC.nameOf(pl) + ' — 소진한 동료 없음 (드로우 0)');
};
ACTIONS.resolveHandDiscardCost = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'handDiscardCost') throw new Error('[resolveHandDiscardCost] 대기 없음');
  const pl = playerByUid(G, p.player);
  const idx = (pl.hand || []).findIndex(c => c.uid === a.uid);
  if (idx < 0) throw new Error('[resolveHandDiscardCost] 손패에 없는 카드: ' + a.uid);
  const [card] = pl.hand.splice(idx, 1);
  MC.moveToDiscard(G, pl, card, {});
  p.chosen.push(a.uid);
  log(G, MC.nameOf(card) + ' 버림 (공격 추가 비용 ' + p.chosen.length + '/' + p.count + ')');
  if (p.chosen.length < p.count) return;                 // 더 버려야 함 — pending 유지
  const ally = pl.playArea.allies.find(x => x.uid === p.allyUid);
  const target = findByUid(G, p.targetUid);
  G.pending = null;
  if (!ally || ally.exhausted){ log(G, '공격자 동료 없음/소진 — 공격 불발'); return; }
  if (!target || target.hp === undefined || target.hp <= 0){ log(G, '공격 대상 없음 — 비용만 지불'); return; }
  if (target.kind === 'villain' && MC.hasGuardEngaged(G, pl)){ log(G, '수호 하수인 교전 — 빌런 공격 불가 (비용만 지불)'); return; }
  performAllyAttack(G, pl, ally, target);
};
ACTIONS.allyThwart = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  const ally = pl.playArea.allies.find(x => x.uid === a.allyUid);
  if (!ally) throw new Error('[allyThwart] 동료 없음');
  if (ally.exhausted) throw new Error('[allyThwart] 동료 소진됨');
  if (ally.status.confused > 0){ ally.exhausted = true; ally.status.confused--; log(G, MC.nameOf(ally)+' 혼란 해제'); return; }
  if ((a.scheme === 'main' || !a.scheme) && MC.hasPatrolEngaged(G, pl))
    throw new Error('[allyThwart] 순찰 하수인 교전 중 — 메인 스킴 저지 불가');
  if ((a.scheme === 'main' || !a.scheme) && MC.hasCrisisScheme(G))
    throw new Error('[allyThwart] 위기(Crisis) 사이드 스킴 — 먼저 처치해야 메인 스킴 저지 가능');
  ally.exhausted = true;
  MC.removeThreat(G, a.scheme || 'main', MC.allyStatOf(G, ally, 'thwart'));
  // 저지 후 강제 반응 (데어데블 등) — 대상 스킴/타깃 전달.
  // ★ thwCost(consequential 자기 피해) 적용 *전*에 발화 (타이그라 FAQ 준용: 데어데블도
  //   마지막 저지에서 피해를 줄 수 있음 = 조건 판정이 자기 피해보다 먼저).
  const pingTargets = (a.pingTargets || a.targets || []).map(u => findByUid(G, u)).filter(Boolean);
  MC.fireCardHook(G, ally, 'afterThwart', { player: pl, thwarter: ally, scheme: a.scheme || 'main', targets: pingTargets });
  if (ally.thwCost) MC.applyDamage(G, ally, ally.thwCost, { isConsequential: true });
};

/* 형태 변경 */
ACTIONS.flipForm = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  MC.flipForm(G, pl);
};

/* 방어 선언 해소: { player, defender:'none'|'identity'|allyUid } */
ACTIONS.resolveDefense = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  MC.resolveDefensePending(G, a.player, a.defender);
};

/* 조우 카드 공개 선택 해소 (하이드라 폭파범 등): { player, option } — option은 pending.options의 키.
   선택된 옵션의 effects를 실행하고 pending 해제 → 공개 큐 재개. */
/* 적 대상 선택 해소 (chooseEnemy pending) — 선택한 적에게 then 효과 실행. 범용. */
/* 적 부착물 제거 (히어로 행동): removeAbility.payIcons 자원 지불 → detach + 버림. 범용.
   소닉 컨버터(⚡🧠💪 각 1) 등. { player, attachUid, payment } */
ACTIONS.removeEnemyAttachment = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const pl = playerByUid(G, a.player);
  if (pl.form !== 'hero') throw new Error('[removeAttach] 히어로 행동은 영웅 형태에서만');
  // 부착물 찾기 (빌런 + 모든 교전 하수인)
  let att = null;
  const hosts = [G.villain, ...(G.environments || [])];
  for (const q of G.players) for (const m of q.engagedMinions) hosts.push(m);
  for (const host of hosts){ const f = (host.attachments||[]).find(x => x.uid === a.attachUid); if (f){ att = f; break; } }
  if (!att) throw new Error('[removeAttach] 부착물 없음');
  const def = MC.cardDef(att.defCode);
  if (!def || !def.removeAbility) throw new Error('[removeAttach] 제거 능력 없음');
  // 소진 비용 (프로그램 전송기: "히어로 소진 + 🧠🧠 지불"). 소진 비용이 없으면 소진 상태여도 제거 가능.
  if (def.removeAbility.exhaustHero && pl.exhausted) throw new Error('[removeAttach] 소진됨 (히어로 소진 비용 필요)');
  const els = a.payment || [];
  const { icons } = MC.computePayment(G, pl, els, att);
  if (!MC.payIconsSatisfied(icons, def.removeAbility.payIcons))
    throw new Error('[removeAttach] 자원 지불 불충족: ' + JSON.stringify(def.removeAbility.payIcons));
  MC.executePayment(G, pl, els);
  if (def.removeAbility.exhaustHero){ pl.exhausted = true; MC.log(G, pl.uid + ' 히어로 소진 (제거 비용)'); }
  MC.detachFrom(G, att);
  G.encounterDiscard.push(att);
  MC.log(G, MC.nameOf(att) + ' — 히어로 행동으로 제거');
};

ACTIONS.resolveChooseEnemy = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'chooseEnemy') throw new Error('[resolveChooseEnemy] 대기 중인 적 선택 없음');
  if (!(p.enemyUids || []).includes(a.uid)) throw new Error('[resolveChooseEnemy] 유효하지 않은 대상: ' + a.uid);
  const enemy = MC.findByUid(G, a.uid);
  const pl = playerByUid(G, p.player);
  const then = p.then || [];
  G.pending = null;
  MC.log(G, MC.nameOf(enemy) + ' — 대상 선택됨');
  MC.runEffectList(G, then, { player: pl, targets: [enemy] });
};

/* 와칸다 포에버! 순서 선택 해소: 플레이어가 탭한 BP 업그레이드를 해결. 남은 게 없으면 시퀀스 종료. */
ACTIONS.resolveWakandaStep = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'wakandaOrder') throw new Error('[resolveWakandaStep] 와칸다 순서 대기 없음');
  if (!(p.remaining || []).includes(a.uid)) throw new Error('[resolveWakandaStep] 유효하지 않은 업그레이드: ' + a.uid);
  const pl = playerByUid(G, p.player);
  const inst = MC.findByUid(G, a.uid);
  p.remaining = p.remaining.filter(u => u !== a.uid);
  const final = p.remaining.length === 0;
  MC.resolveWakandaUpgrade(G, pl, inst, final);
  (p.resolved = p.resolved || []).push(a.uid);
  if (final){ G.pending = null; MC.log(G, '와칸다 포에버! — 시퀀스 완료'); }
};

/* 범용 카드 선택 해소 — cardPick pending에서 a.uid 카드를 선택.
   keep장 다 고르면: 고른 카드 손에, 나머지는 disposition('discard'|'bottom')대로. */
ACTIONS.resolveCardPick = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'cardPick') throw new Error('[resolveCardPick] 카드 선택 대기 없음');
  if (!(p.cardUids || []).includes(a.uid)) throw new Error('[resolveCardPick] 유효하지 않은 카드: ' + a.uid);
  if ((p.chosen || []).includes(a.uid)) throw new Error('[resolveCardPick] 이미 선택한 카드');
  const pl = playerByUid(G, p.player);
  p.chosen.push(a.uid);
  if (p.chosen.length < p.keep) return;                 // 아직 더 골라야 함 — pending 유지
  // keep장 다 고름 → 처리
  const chosenSet = new Set(p.chosen);
  const toHand = p._cards.filter(c => chosenSet.has(c.uid));
  const rest   = p._cards.filter(c => !chosenSet.has(c.uid));
  for (const c of toHand) pl.hand.push(c);
  if (p.disposition === 'bottom'){ for (const c of rest) pl.deck.push(c); }
  else { for (const c of rest) MC.moveToDiscard(G, pl, c, {}); }
  MC.log(G, MC.nameOf(pl) + ' — ' + toHand.length + '장 손에 넣고 ' + rest.length + '장 '
           + (p.disposition === 'bottom' ? '덱 아래로' : '버림'));
  G.pending = null;
};

ACTIONS.resolveRevealChoice = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'revealChoice') throw new Error('[resolveRevealChoice] 대기 중인 선택 없음');
  const opt = (p.options || []).find(o => o.key === a.option);
  if (!opt) throw new Error('[resolveRevealChoice] 유효하지 않은 선택: ' + a.option);
  const pl = playerByUid(G, p.player);
  const self = MC.findByUid(G, p.selfUid);
  // 자원 지불 선택지(payIcons: 다중 타입 요구, wild 유연 배정) — 소닉 붐 "자원 3종 지불" 등.
  if (opt.payIcons){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els, self);
    if (!MC.payIconsSatisfied(icons, opt.payIcons))
      throw new Error('[resolveRevealChoice] 자원 지불 불충족: ' + JSON.stringify(opt.payIcons));
    MC.executePayment(G, pl, els);
    MC.log(G, MC.nameOf(self || {name:'조우 카드'}) + ' — 자원 지불로 회피');
  }
  G.pending = null;
  MC.log(G, MC.nameOf(self || {name:'조우 카드'}) + ' — 선택: ' + opt.label);
  MC.runEffectList(G, opt.effects || [], { player: pl, self, card: self, targetScheme: 'main' });
  // 강제 위협 선택 체인(노라드 습격 01138b): 남은 플레이어가 있으면 다음 선택 pending으로 이어감.
  if (G._pendingThreatChoice && G._pendingThreatChoice.length && MC.flushThreatChoice){
    MC.flushThreatChoice(G);
  }
  // 각 플레이어 선택 체인(공격 받는 중 01151 등): 남은 플레이어가 있으면 다음으로 이어감.
  else if (G._pendingEachChoice && G._pendingEachChoice.queue && G._pendingEachChoice.queue.length && MC.flushEachChoice){
    MC.flushEachChoice(G);
  }
  // 하수인 등장 반응 체인(호크아이 화살 등): 남은 반응 후보가 있으면 다음 선택으로 이어감.
  else if (G._pendingMinionReactions && G._pendingMinionReactions.length && MC.flushMinionReactions){
    MC.flushMinionReactions(G);
  }
  // Wicked Ambitions 고블린 선택 체인: 버린 고블린마다 [피해3 / 배치] 선택을 순차 제시.
  else if (G._pendingWickedGoblins && MC.flushWickedGoblin){
    MC.flushWickedGoblin(G);
  }
  // pending 해제 완료 — 공개 큐 재개는 UI가 villainStep 재호출로 처리 (방어 해소와 동일 패턴)
};

/* 플레이어 페이즈 종료 (코어: 버림선택→손패 보충→전원 준비→빌런 페이즈) */
ACTIONS.endPlayerPhase = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  if (G.pending) throw new Error('대기 중인 결정 해소 필요');
  if (G.phase !== 'player') throw new Error('플레이어 페이즈 아님');
  MC.fireHook(G, 'endOfPhase', { phase:'player' });
  // ★ 공식 RRG: 플레이어 페이즈 종료 시 모든 카드 준비 + 핸드 크기까지 드로우
  //   → 그 후 빌런 페이즈 진행 (사용자 룰북·이전 빌드 기준)
  for (const pl of MC.playersInOrder(G)){
    MC.readyAllFor(G, pl);
    // 신분 턴 종료 훅 (헐크 격노: 손패 전체 강제 버림) — 손패 보충 전에 발동.
    const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    const onTurnEnd = MC.cardDef(faceCode) && MC.cardDef(faceCode).onTurnEnd;
    if (onTurnEnd) MC.runEffectList(G, onTurnEnd, { player: pl });
    MC.drawUpToHandSize(G, pl);
    pl.tempTraits = [];   // 일시적 트레잇(로켓 부츠 Aerial 등) — 페이즈 종료 시 소멸
    pl.nextCardDiscount = 0;   // 비용 할인(헬리캐리어) — 페이즈 종료 시 소멸
    pl.nextCardDiscountFilter = null;   // 할인 필터(어벤져스 타워) — 페이즈 종료 시 소멸
    if (pl.tempStatBonus) pl.tempStatBonus = {};   // 히어로 임시 버프(선두에서 이끌기 등) 소멸
    // 동료 임시 스탯 버프(비전 +2 등) — 페이즈 종료 시 소멸
    for (const a of pl.playArea.allies) if (a.tempStatBonus) a.tempStatBonus = {};
  }
  // 단계별 진행 모드 (UI가 villainStep으로 하나씩 실행 — 연출 동기화)
  if (a.stepwise) G.villainStepMode = true;
  MC.startVillainPhase(G);
};

/* 빌런 페이즈 스텝 1개 실행 (단계별 진행 모드) */
ACTIONS.villainStep = function(G, a){
  MC.villainStepOnce(G);
};

/* 카운터 충전: 자원 지불 요소만큼 카운터 축적 (에너지 채널 등).
   { player, cardUid, payment } — payment로 지불한 자원 아이콘 수 = 추가 카운터 */
ACTIONS.counterCharge = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  let card = null;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; break; } }
  if (!card) throw new Error('[counterCharge] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  const ca = def.counterAbility;
  if (!ca || !ca.charge) throw new Error('[counterCharge] 충전 능력 없음');
  const els = a.payment || [];
  if (!els.length) throw new Error('[counterCharge] 충전할 자원을 선택하세요');
  // 지불 자원의 해당 타입 아이콘 수를 카운터로 (에너지 자원 X개 → 카운터 X개)
  const need = ca.charge.resource; // 'energy'
  let gained = 0;
  for (const el of els){
    if (el.kind !== 'hand') throw new Error('[counterCharge] 손패 자원만 충전 가능');
    const c = pl.hand.find(x => x.uid === el.uid);
    if (!c) throw new Error('[counterCharge] 손패에 없음');
    const icons = MC.resourceIconsOf(c);
    gained += (icons[need] || 0) + (icons.wild || 0);
  }
  if (gained <= 0) throw new Error('[counterCharge] ' + MC.T(need) + ' 자원이 필요합니다');
  // 자원 카드 버림 (결제)
  MC.executePayment(G, pl, els);
  card.counters = (card.counters || 0) + gained;
  log(G, MC.nameOf(card) + ' 충전 — 카운터 +' + gained + ' (누적 ' + card.counters + ')');
};

/* 카운터 발사: 카드 버림 + 카운터당 피해 (에너지 채널 등).
   { player, cardUid, targetUid } */
ACTIONS.counterFire = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'hero') throw new Error('[counterFire] 영웅 형태에서만');
  let card = null, srcArr = null;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; srcArr = arr; break; } }
  if (!card) throw new Error('[counterFire] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  const ca = def.counterAbility;
  if (!ca || !ca.fire) throw new Error('[counterFire] 발사 능력 없음');
  const counters = card.counters || 0;
  if (counters < (ca.fire.minCounters || 1)) throw new Error('[counterFire] 카운터 부족 (최소 ' + (ca.fire.minCounters||1) + ')');
  const target = findByUid(G, a.targetUid);
  if (!target) throw new Error('[counterFire] 대상 없음');
  let dmg = counters * (ca.fire.perCounter || 1);
  if (ca.fire.max) dmg = Math.min(dmg, ca.fire.max);
  // 카드 버림 (발사)
  if (ca.fire.discardSelf){
    const i = srcArr.indexOf(card);
    if (i >= 0) srcArr.splice(i, 1);
    MC.moveToDiscard(G, pl, card, {});
  }
  log(G, MC.nameOf(card) + ' 발사 — ' + MC.nameOf(target) + '에게 ' + dmg + ' 피해 (카운터 ' + counters + ')');
  MC.applyDamage(G, target, dmg, { source: pl, isAttack: true });
};

/* 개발용 */
ACTIONS.drawCard = function(G, a){ MC.drawCards(G, playerByUid(G, a.player), a.amount||1); };

/* ── 공용 조회/유틸 ── */
function playerByUid(G, uid){ const p = G.players.find(p=>p.uid===uid); if(!p) throw new Error('플레이어 없음: '+uid); return p; }
function playersInOrder(G){
  const n = G.players.length, out = [];
  for (let i=0;i<n;i++){ const p = G.players[(G.firstPlayer+i)%n]; if (!p.eliminated) out.push(p); }
  return out;
}
function rotateFirstPlayer(G){
  G.firstPlayer = (G.firstPlayer + 1) % G.players.length;
  log(G, '선 플레이어 → ' + G.players[G.firstPlayer].uid);
}
function allInPlay(G){
  const out = [];
  for (const pl of playersInOrder(G)){
    out.push(pl);
    out.push(...pl.playArea.allies, ...pl.playArea.supports, ...pl.playArea.upgrades, ...pl.engagedMinions);
  }
  if (G.villain) out.push(G.villain, ...(G.villain.attachments||[]));
  if (G.mainScheme) out.push(G.mainScheme);
  out.push(...G.sideSchemes);
  // 환경 카드 + 환경 부착물 (울트론 드론 환경 + 업그레이드 드론 등)
  for (const e of (G.environments || [])){ out.push(e); out.push(...(e.attachments || [])); }
  return out;
}
function findByUid(G, uid){ // 라이브 조회 — 스냅샷 stale 참조 방지 (플레이북 §6)
  if (!uid) return null;
  return allInPlay(G).find(x => x.uid === uid) ||
         G.players.flatMap(p=>p.hand.concat(p.discard, p.deck)).find(x=>x.uid===uid) ||
         // 조우 영역 + 공개 진행 중 카드 (의무/배신 공개 처리 중 self 참조 — resolveObligation 등)
         (G.revealing && G.revealing.uid === uid ? G.revealing : null) ||
         (G.encounterDeck||[]).find(x=>x.uid===uid) ||
         (G.encounterDiscard||[]).find(x=>x.uid===uid) ||
         (G.pendingEncounters||[]).map(pe=>pe.inst).find(x=>x&&x.uid===uid) || null;
}
function resolveTarget(G, sel, ctx){
  if (!sel || sel === 'self') return [ctx.player || ctx.self];
  if (sel === 'card' || sel === 'thisCard') return [ctx.card || ctx.self].filter(Boolean);  // 플레이된 카드/동료 자신 (루크 케이지 Tough 등)
  if (sel === 'villain') return [G.villain];
  if (sel === 'chosen') return ctx.targets || [];
  if (sel === 'target') return ctx.target ? [ctx.target] : [];   // 단일 대상(부착물 강제반응의 피해 대상 등)
  if (sel === 'engagedPlayer'){   // 이 하수인(ctx.self)과 교전 중인 플레이어 (고블린 솔저 처치 시 등)
    const self = ctx.self || ctx.card;
    const uid = self && self.engagedWith;
    const pl = uid && G.players.find(p => p.uid === uid);
    return pl ? [pl] : [];
  }
  if (sel === 'firstPlayer') return [playersInOrder(G)[0]];   // 첫 플레이어 (폭발! X 피해 등)
  if (sel === 'allPlayers') return playersInOrder(G);
  if (sel === 'allFriendly'){   // 모든 우호 캐릭터: 각 플레이어 히어로 + 그 플레이어의 동료 (충격파 폭발 01154)
    const out = [];
    for (const pl of playersInOrder(G)){
      if (pl.eliminated) continue;
      out.push(pl);
      out.push(...(pl.playArea ? pl.playArea.allies : []));
    }
    return out;
  }
  if (sel === 'controlled'){   // 활성 플레이어가 통제하는 캐릭터: 그 히어로 + 동료 (충격파 폭발 부스트★)
    const pl = ctx.player || playersInOrder(G)[0];
    const out = [pl];
    out.push(...(pl.playArea ? pl.playArea.allies : []));
    return out;
  }
  if (sel === 'allEnemies'){   // 빌런 + 모든 교전 하수인 (광역기)
    const out = [];
    if (G.villain) out.push(G.villain);
    for (const pl of G.players) for (const m of pl.engagedMinions) out.push(m);
    return out;
  }
  if (sel === 'villainAndMyMinions'){   // 빌런 + 이 플레이어와 교전한 하수인만 (라이트닝 스트라이크 06006)
    const pl = ctx.player || playersInOrder(G)[0];
    const out = [];
    if (G.villain) out.push(G.villain);
    for (const m of (pl.engagedMinions || [])) out.push(m);
    return out;
  }
  throw new Error('[resolveTarget] 미등록 대상: ' + sel);
}
function resolvePlayers(G, sel, ctx){
  if (sel === 'self') return [ctx.player];
  if (sel === 'all') return playersInOrder(G);
  if (sel === 'firstPlayer') return [G.players[G.firstPlayer]];
  throw new Error('[resolvePlayers] 미등록 대상: ' + sel);
}
function fromHand(pl, uid){
  const i = pl.hand.findIndex(c=>c.uid===uid);
  if (i<0) throw new Error('[fromHand] 손패에 없음: '+uid);
  return pl.hand.splice(i,1)[0];
}
function moveToDiscard(G, pl, inst, opt){
  // 보관소가 있는 카드(브루노)가 버려지면 보관된 카드도 소유자 버림 더미로.
  if (inst.stored && inst.stored.length){
    for (const c of inst.stored.splice(0)) pl.discard.push(c);
  }
  pl.discard.push(inst);
  // HP 보너스 카드(MK.5 아머 등)가 버려지면 최대 HP 재계산
  if (MC.cardDef(inst.defCode) && MC.cardDef(inst.defCode).hpBonus) MC.recomputeMaxHp(G, pl);
}
function nameOf(t){ return t.name || t.uid || '?'; }
function setGameOver(G, result, reason, cause){
  // cause: 패배 사유 카테고리 ('heroDefeat' = 히어로 체력 0/전원 탈락, 'schemeComplete' = 메인 스킴 달성).
  // 플레이어 패배 시, 빌런 테마에 맞는 승리 대사를 골라 G.over.villainQuote로 노출 (UI가 표시).
  G.over = { result, reason, cause: cause || null, round: G.round };
  if (result === 'loss' && G.villain && cause){
    const key = G.villain.quoteKey || (MC.cardDef(G.villain.defCode) || {}).quoteKey;
    if (key && MC.hasQuote && MC.hasQuote(key, cause) && MC.randomQuote){
      G.over.villainQuote = MC.randomQuote(key, cause);
      G.over.villainName = MC.nameOf(G.villain);
    }
  }
  log(G, '게임 종료: ' + (result==='win'?'승리':'패배') + ' — ' + reason);
}
function log(G, msg){ G.gameLog.push('[R'+G.round+'/'+G.phase+'] '+msg); }

/* ── 직렬화 ── */
function serialize(G){ return JSON.stringify(G); } // 상태에 라이브 참조 보관 금지 원칙 (uid 참조만)
function deserialize(json){ return JSON.parse(json); }

MC.rand = rand; MC.shuffle = shuffle;
MC.CARDS = CARDS; MC.baseFields = baseFields;
MC.registerCards = registerCards; MC.defineCardFx = defineCardFx; MC.aliasCardFx = aliasCardFx; MC.cardDef = cardDef;
MC.makeInstance = makeInstance; MC.buildDeck = buildDeck;
MC.makeGameState = makeGameState; MC.setupGame = setupGame;
MC.ACTIONS = ACTIONS; MC.dispatch = dispatch;
MC.playerByUid = playerByUid; MC.playersInOrder = playersInOrder;
MC.rotateFirstPlayer = rotateFirstPlayer; MC.allInPlay = allInPlay; MC.findByUid = findByUid;
MC.resolveTarget = resolveTarget; MC.resolvePlayers = resolvePlayers;
MC.fromHand = fromHand; MC.moveToDiscard = moveToDiscard; MC.nameOf = nameOf;
MC.setGameOver = setGameOver; MC.log = log;
MC.serialize = serialize; MC.deserialize = deserialize;

})(typeof window !== 'undefined' ? window : globalThis);
