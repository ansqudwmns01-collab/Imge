/* ═══════════════════════════════════════════════════════════════
   mc_ui.js — 코믹스 테마 UI (메뉴 6종 · 팀 구성 · 덱빌더 · 저장)
   화면: title / team / villain / builder / import / (게임 보드)
   모드: solo(1인) · hotseat(1~4 슬롯) · multi(준비 중)
   저장: localStorage — 덱(mc_decks_v1) · 진행 게임(mc_save_v1)
   모든 게임 조작은 MC.dispatch 경유. UI는 상태를 읽기만 한다.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
const IMG_BASE = 'https://marvelcdb.com/bundles/cards/';
let G = null;

/* 시그니처 동료(def.hero 소속)의 영웅별 전용 소환 연출 매핑.
   등록 안 된 영웅은 공용 allyEnter로 폴백. 새 영웅 추가 시 여기에 한 줄. */
const HERO_ALLY_SUMMON = {
  'captain-marvel': 'starSummon',   // 캡틴 마블: 할라 스타(별) 소환
  'she-hulk': 'gammaEnter',         // She-Hulk: 감마 파워 등장
};

/* 시그니처 장비(support/upgrade, def.hero 소속)의 영웅별 전용 설치 연출 매핑.
   등록 안 된 영웅은 공용 install로 폴백. 새 영웅 추가 시 여기에 한 줄. */
const HERO_CARD_INSTALL = {
  'captain-marvel': 'starInstall',  // 캡틴 마블: 별 에너지로 장비 장착
  'she-hulk': 'gammaInstall',       // She-Hulk: 감마 에너지로 강화
  'iron-man': 'arcInstall',         // 아이언맨: 아크 원자로 에너지로 장착
  'thor': 'asgardInstall',          // 토르: 아스가르드 룬 원 + 번개로 장착
  'captain-america': 'shieldInstall', // 캡틴아메리카: 성조기 방패 방어막 각인
  'ms-marvel': 'embiggenInstall',   // 미즈마블: 신축 확대 파동으로 장착
  'black-widow-hero': 'spyInstall', // 블랙위도우: 스파이 장비 홀로그램 인터페이스 + 붉은 스캔
  'doctor-strange': 'runeInstall',  // 닥터 스트레인지: 황금 신비 룬 원(만다라) 소환
};

/* ── 빌런 페이즈 단계별 진행 ──
   엔진은 stepwise 모드에서 큐를 자동으로 비우지 않는다. UI가 villainStep 액션을
   딜레이·연출과 함께 하나씩 dispatch. 결정성: 모든 진행이 dispatch된 액션. */
const UI_VER = 'v2026.07.10.129';   // ★ 빌드 버전 스탬프 — 산출 시 갱신 (화면 표시용)
let villainTimer = null;
let revealQueue = [];      // 공개 카드 확인 대기열 (한 장씩 모달로)
let fxRevealShowing = null; // 덱 공개 시퀀스(리펄서 등) 표시 중
let boostRevealShowing = null; // 부스트 카드 공개 시퀀스(플립) 표시 중
let boostRevealSeqPrev = 0;    // 부스트 공개 seq 추적
let envReactionSeqPrev = 0;    // 어보밍맨 환경 미방어 반응 seq 추적
let superAbsorbSeqPrev = 0;    // 초강력 흡수 소환 seq 추적
let revealShowing = null;  // 현재 확인 중인 공개 항목
let resultsShown = false;   // 결과창 표시 여부 (승/패 공용)
let suitBreakShown = false; // 라이노 슈트 파괴 연출 1회 표시 플래그
let attachSpentSeq = 0;     // 공격 종료 부착물 소모(fxAttachSpent) 마지막 재생 seq
let minionAttackSeq = 0;    // 하수인 공격(fxMinionAttack) 마지막 재생 seq
let damageEachHeroSeq = 0;  // 각 히어로 피해(fxDamageEachHero) 마지막 재생 seq
let goblinFlipSeq = 0;      // 그린 고블린 폼 전환(fxGoblinFlip) 마지막 재생 seq
let forcedDiscardSeq = 0;   // 강제 버림(fxForcedDiscard) 마지막 재생 seq — 헐크 격노 등 공용
let weaponRevealSeq = 0;    // 실험 무기 덱 공개(fxWeaponReveal) 마지막 재생 seq — 크로스본즈
let comicIntroShown = false, comicDefeatShown = false;   // 캠페인 코믹스 표시 여부 (중복 방지)

/* ── 빌런 페이즈 연출 순차 큐 (중구난방 방지) ──
   빌런 페이즈(스텝 모드)에는 모든 연출(playVfx)을 큐에 넣어 하나씩 순서대로 재생한다.
   여러 감지 블록이 각자 setTimeout으로 동시에 쏘던 것을 직렬화 → 겹침/난무 제거.
   스텝 진행(maybeStepVillain)은 큐가 빌 때까지 대기. 공개 모달 중엔 큐도 정지. */
let fxq = [];               // { name, ctx, dur }
let fxqActive = false;
const _playVfxRaw = MC.playVfx;
// 연출별 길이 추정(ms) — 긴 연출은 개별 지정, 기본 850
const FX_DUR = {
  onDefeat: 1100, stageChange: 2200, phaseBanner: 1200,
  sonicEmerge: 1500, wallBreak: 1400, ultronEntrance: 1500,
  rhinoRampage: 1600, rhinoCollapse: 1600, barBreak: 500,
};
function fxPump(){
  if (fxqActive) return;
  if (revealShowing || boostRevealShowing || fxRevealShowing) return;  // 공개 모달 중엔 대기
  if (!fxq.length){
    // 큐가 비었으면 빌런 페이즈 스텝 진행 재개
    if (G && G.phase === 'villain' && G.villainStepMode && !G.pending) maybeStepVillain();
    return;
  }
  fxqActive = true;
  const it = fxq.shift();
  try { _playVfxRaw.call(MC, it.name, it.ctx); } catch(e){}
  setTimeout(() => { fxqActive = false; fxPump(); }, it.dur);
}
// playVfx 래핑: 빌런 페이즈(스텝 모드)에는 순차 큐로, 그 외엔 즉시 재생(현행 동작 유지)
MC.playVfx = function(name, ctx){
  if (G && G.phase === 'villain' && G.villainStepMode){
    fxq.push({ name, ctx, dur: FX_DUR[name] || 850 });
    fxPump();
    return;
  }
  return _playVfxRaw.call(MC, name, ctx);
};
function stepInfo(step){
  switch (step.op){
    case 'threat':      return { label:'⚡ 위협 배치', delay: 700 };
    case 'activations': return { label:'⚔ 적 활성화 준비', delay: 350 };
    case 'act': {
      const en = MC.findByUid(G, step.enemyUid);
      return { label:'⚔ ' + (en ? en.name : '적') + ' 활성화', delay: 950 };
    }
    case 'dealEnc':     return { label:'🃏 조우 카드 배분', delay: 700 };
    case 'reveal':      return { label:'👁 조우 카드 공개', delay: 850 };
    case 'resumeReveal':return { label:'👁 조우 카드 공개 (재개)', delay: 600 };
    case 'endRound':    return { label:'🔄 라운드 정리', delay: 650 };
    default:            return { label:'…', delay: 500 };
  }
}
function showStepStrip(text){
  let el = document.getElementById('stepstrip');
  if (!el){ el = document.createElement('div'); el.id = 'stepstrip'; document.body.appendChild(el); }
  el.textContent = text;
}
function hideStepStrip(){
  const el = document.getElementById('stepstrip');
  if (el) el.remove();
}
function maybeStepVillain(){
  if (villainTimer) return;
  if (fxqActive || fxq.length) return;   // 연출 순차 재생 중 — 큐 비면 fxPump가 다시 호출
  if (revealShowing || revealQueue.length || boostRevealShowing) return;   // 공개 확인 중 — 사람이 볼 시간
  if (!G || G.over || G.phase !== 'villain' || !G.villainStepMode || G.pending) return;
  if (!G.vq || !G.vq.length) return;
  const info = stepInfo(G.vq[0]);
  showStepStrip(info.label);
  villainTimer = setTimeout(() => {
    villainTimer = null;
    if (!G || G.over || G.phase !== 'villain' || G.pending || !G.vq.length){ hideStepStrip(); return; }
    const ok = act({ type:'villainStep' });
    if (!ok){ hideStepStrip(); return; }
    // (공개 카드 오버레이는 act 훅에서 revealLog diff로 자동 재생 — 일원화)
    if (G.phase === 'player'){
      hideStepStrip();
      MC.playVfx('phaseBanner', { text:'HERO PHASE!', sub:'플레이어 페이즈', color:'blue' });
    } else if (G.pending){
      hideStepStrip();  // 방어/인터럽트 대기 — 해소 후 act 훅이 재개
    } else {
      maybeStepVillain();
    }
  }, info.delay);
}
let sel = { mode:null, cardUid:null, player:null };
let pay = null;
let novaPay = null;   // 노바 등 공격개시 인터럽트 결제(방어창 중 로컬 상태)

/* ── 로스터/메타: MC.HEROES(생성기)에서 동적 구성 ── */
const HERO_META = MC.HEROES;                       // key → {name, alterName, art, aeArt}
const HERO_KEYS = Object.keys(MC.HEROES).sort((a,b)=>MC.HEROES[a].name.localeCompare(MC.HEROES[b].name,'ko'));
/* marvelcdb 코드 → 슬러그 역매핑 (가져오기용) */
const MCODE2SLUG = (() => {
  const m = {};
  for (const code in MC.CARDS){
    const d = MC.CARDS[code];
    if (d.mcode) m[d.mcode] = code;
  }
  return m;
})();
const VILLAIN_ROSTER = [
  { key:'rhino', ready:true, art:'01094' },
  { key:'klaw', ready:true, art:'01113' }, { key:'ultron', ready:true, art:'01134' },
  { key:'riskyBusiness', ready:true, art:'02001b' },
  { key:'mutagenFormula', ready:true, art:'02014' },
  { key:'crossbones', ready:true, art:'04058' },
  { key:'absorbing-man', ready:true, art:'04076' },
  { key:'taskmaster', ready:true, art:'04093' },
  { key:'zola', ready:true, art:'04109' },
];
const VILLAIN_META = {
  'rhino':  { name:'라이노', sub:'침입!' },
  'klaw':   { name:'클로', sub:'무기 밀매' },
  'ultron': { name:'울트론', sub:'섬멸 계획' },
  'riskyBusiness':  { name:'그린 고블린', sub:'위험한 거래' },
  'mutagenFormula': { name:'그린 고블린', sub:'뮤타젠 포뮬러' },
  'crossbones': { name:'크로스본즈', sub:'마운트 아테나 공격' },
  // 레드 스컬 캠페인 나머지 시나리오 (준비 중 — 이름/체인 표시용, VILLAIN_ROSTER에는 없어 단독 선택 불가)
  'absorbing-man': { name:'어보밍맨', sub:'누구도 지나갈 수 없다' },
  'taskmaster':    { name:'태스크마스터', sub:'영웅 사냥' },
  'zola':          { name:'아르님 졸라', sub:'졸라 박사의 섬' },
  'red-skull':     { name:'레드 스컬', sub:'최종전 · 준비 중' },
};
const CAMPAIGNS = {
  core: { name:'코어 세트 캠페인', villains:['rhino','klaw','ultron'],
          desc:'라이노 → 클로 → 울트론을 차례로 저지하라!' },
  'rise-of-red-skull': {
    name:'레드 스컬의 부상',
    villains:['crossbones','absorbing-man','taskmaster','zola','red-skull'],
    desc:'크로스본즈 → 어보밍맨 → 태스크마스터 → 졸라 → 레드 스컬. 하이드라의 음모를 저지하라! (크로스본즈·어보밍맨·태스크마스터 플레이 가능, 졸라·레드 스컬 준비 중)',
    // ── 시나리오 시트: 룰북 코믹스 페이지 순서·연결. 각 시나리오의 격파 코믹스가 다음 시나리오 인트로를 겸함(스토리 연결). ──
    sheet: [
      { key:'crossbones',    order:1, name:'크로스본즈',   intro:[4],     defeat:[6],     ready:true  },
      { key:'absorbing-man', order:2, name:'어보밍맨',     intro:[6],     defeat:[8,9],   ready:true  },
      { key:'taskmaster',    order:3, name:'태스크마스터', intro:[8,9],   defeat:[11],    ready:true  },
      { key:'zola',          order:4, name:'아르님 졸라',   intro:[11],    defeat:[13,14], ready:true  },
      { key:'red-skull',     order:5, name:'레드 스컬',    intro:[13,14], defeat:[16],    ready:false },
    ],
  },
};
const ASPECTS = [
  ['aggression','용맹'], ['justice','정의'], ['leadership','리더십'], ['protection','보호'],
];

/* ── 앱 상태 ── */
const APP = {
  screen:'title', mode:'solo',
  slots:[{ heroKey:'spiderman', deckId:'preset' }],
  scenarioKey:'rhino', villainTab:'villain', campaign:null, difficulty:'standard',
  villainRandom:false,     // true면 전투 개시 시 준비된 빌런 중 무작위 확정(scenarioKey에 현재 미리보기)
  modularMode:'default',   // 'default'(빌런 권장) | 'random'(랜덤) | 'custom'(직접 선택)
  modularPick:[],          // custom 모드에서 선택된 모듈러 세트 키 배열
  modularRandomN:1,        // random 모드에서 뽑을 세트 수
  modularRandomKeys:null,  // random 모드에서 실제 뽑힌 키(전투 개시 시 확정)
  builder:null, importText:'', importResult:null,
  importTab:'number', importNo:'', importBusy:false,
  heroPick:null,       // {kind:'slot', i} | {kind:'builder'}
  slotPick:null,       // 저장 대기 덱 객체
};

/* ── 저장소 ── */
function store(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} }
function load(k){ try { return JSON.parse(localStorage.getItem(k)); } catch(e){ return null; } }
const DECK_SLOTS = 10;
function loadSlots(){
  let sl = load('mc_deckslots_v1');
  if (!sl){
    sl = new Array(DECK_SLOTS).fill(null);
    const legacy = load('mc_decks_v1') || [];     // 구버전 마이그레이션
    legacy.slice(0, DECK_SLOTS).forEach((d,i)=>{ sl[i]=d; });
  }
  while (sl.length < DECK_SLOTS) sl.push(null);
  return sl;
}
function saveSlots(sl){ store('mc_deckslots_v1', sl); }
function loadDecks(){ return loadSlots().filter(Boolean); }
function saveGame(){ if (G) try { localStorage.setItem('mc_save_v1', MC.serialize(G)); } catch(e){} }
function loadSave(){ try { const s = localStorage.getItem('mc_save_v1'); return s ? MC.deserialize(s) : null; } catch(e){ return null; } }
function hasSave(){ try { return !!localStorage.getItem('mc_save_v1'); } catch(e){ return false; } }

/* ── 공용 ── */
function $(id){ return document.getElementById(id); }
function esc(s){ return String(s).replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function toast(msg, isErr){
  const t = $('toast');
  t.textContent = msg; t.className = 'toast show' + (isErr?' err':'');
  clearTimeout(t._tm); t._tm = setTimeout(()=>{ t.className='toast'; }, 2600);
}
function act(a, opt){
  opt = opt || {};
  let ok = true;
  const wasExh = collectExhausted();
  const barsPrev = barSnapshot();
  const hpPrev = collectHp();
  const defeatablesPrev = collectDefeatables();
  const attachmentsPrev = collectAttachments();
  const statusesPrev = collectStatuses();
  const installedPrev = collectInstalled();
  const pendingPrev = G && G.pending ? 1 : 0;
  const overPrev = G && G.over ? 1 : 0;
  const revealLenPrev = G && G.revealLog ? G.revealLog.length : 0;
  const logLenPrev = G && G.gameLog ? G.gameLog.length : 0;
  // 빌런 위치·이미지 선캡처 (최종 격파 연출용 — 격파 후 DOM 변형 대비)
  const villainSnapEl = G && G.villain && document.querySelector(`[data-vuid="${G.villain.uid}"]`);
  const villainSnap = G && G.villain ? {
    rect: villainSnapEl && villainSnapEl.getBoundingClientRect(),
    imgUrl: imgUrl(G.villain.defCode),
    defCode: G.villain.defCode,
    quoteKey: MC.cardDef(G.villain.defCode).quoteKey,
  } : null;
  const villainStagePrev = G && G.villain ? MC.cardDef(G.villain.defCode).stage : null;
  try { MC.dispatch(G, a); saveGame(); }
  catch(e){ toast(e.message, true); ok = false; }
  render();
  animateBars(barsPrev);
  if (ok){
    // 소진 → 준비 전환 감지: 차단바 파열
    const nowExh = collectExhausted();
    let idx = 0;
    for (const uid in wasExh){
      if (nowExh[uid]) continue;
      const el = document.querySelector(`[data-vuid="${uid}"]`);
      if (el) MC.playVfx('barBreak', { el, delayIdx: idx++ });
    }
    // 처치 감지: 스냅샷에 있던 대상이 사라졌으면 그 자리에 KO 연출
    const aliveNow = collectAliveUids();
    const villainStageNow = G.villain ? MC.cardDef(G.villain.defCode).stage : null;
    let koIdx = 0;
    for (const uid in defeatablesPrev){
      const snap = defeatablesPrev[uid];
      // 빌런은 uid 유지된 채 단계만 바뀌므로(격파) 단계 변화로 판정
      const gone = snap.isVillain
        ? (villainStagePrev !== villainStageNow)
        : !aliveNow.has(uid);
      if (!gone) continue;
      const label = snap.isVillain ? 'STAGE DOWN!' : 'K.O.!';
      const delay = koIdx++ * 90;
      setTimeout(() => MC.playVfx('onDefeat', { rect: snap.rect, imgUrl: snap.imgUrl, label }), delay);
      // 하수인 패배 대사 (defeat): K.O. 버스트 직후 그 자리에 말풍선 (defCode = 대사 키)
      if (!snap.isVillain && snap.defCode && MC.hasQuote(snap.defCode, 'defeat')){
        const q = MC.randomQuote(snap.defCode, 'defeat');
        setTimeout(() => MC.speechBubbleAt(snap.rect, q, { duration: 2200 }), delay + 350);
      }
      // 빌런 스테이지 전환: KO 버스트 뒤 전용 전환 UI (새 스테이지 + 변경점 + 대사)
      if (snap.isVillain && G.villain){
        const ndef = MC.cardDef(G.villain.defCode);
        const quote = MC.randomQuote(ndef.quoteKey, 'stageUp');
        // 빌런 테마 전용 단계 전환 연출 (예: 라이노=rhinoRampage 감마 강화). 정의에 있으면 재생.
        const stageVfx = ndef.vfx && ndef.vfx.stageChange;
        if (stageVfx){
          const vzone = document.querySelector('.villain-zone');
          setTimeout(() => MC.playVfx(stageVfx, { el: vzone && vzone.querySelector('.card-art') }), delay + 400);
        }
        setTimeout(() => MC.playVfx('stageChange', {
          imgUrl: imgUrl(G.villain.defCode), name: G.villain.name,
          stageOld: villainStagePrev, stageNew: villainStageNow,
          hp: G.villain.hp, maxHp: G.villain.maxHp,
          atk: G.villain.attack, sch: G.villain.scheme, quote,
        }), delay + 650);
      }
    }
    // 상태이상 부여 감지: confused/tough 증가 시 공용 연출 (앞으로 광범위 재사용)
    const statusesNow = collectStatuses();
    let stIdx = 0;
    for (const uid in statusesNow){
      const now = statusesNow[uid], prev = statusesPrev[uid] || { confused:0, tough:0, stunned:0 };
      const el = document.querySelector(`[data-vuid="${uid}"]`);
      if (!el) continue;
      if (now.confused > prev.confused)
        setTimeout(() => MC.playVfx('confuse', { el }), stIdx++ * 120);
      if (now.tough > prev.tough)
        setTimeout(() => MC.playVfx('toughGain', { el }), stIdx++ * 120);
    }
    // 부착 해제 감지: 스냅샷에 있던 부착물이 사라졌으면 detach 연출(거미줄 찢김 등)
    const attachNow = collectAttachments();
    let atIdx = 0;
    for (const uid in attachmentsPrev){
      if (attachNow[uid]) continue;                 // 아직 부착 중
      const snap = attachmentsPrev[uid];
      if (!snap.detachVfx) continue;                // detach 연출 없는 부착물은 스킵
      const rect = snap.rect;
      setTimeout(() => MC.playVfx(snap.detachVfx, { toRect: rect, targetEl: null }), atIdx++ * 90);
    }
    // 신규 부착물 등장 감지: 전용 install 연출 + 부착 대사 (예: 라이노 슈트=suitArmor)
    for (const uid in attachNow){
      if (attachmentsPrev[uid]) continue;           // 기존 부착물
      const snap = attachNow[uid];
      const adef = MC.cardDef(snap.defCode);
      const installVfx = adef.vfx && adef.vfx.install;
      if (!installVfx) continue;
      const el = document.querySelector(`[data-vuid="${uid}"]`);
      // 부착 host(빌런/하수인/동료)의 카드아트를 host로 — 동료 부착물이 빌런에 잘못 재생되던 문제 방지
      const hostEl = (snap.hostUid && document.querySelector(`[data-vuid="${snap.hostUid}"] .card-art`))
                   || document.querySelector('.villain-zone .card-art');
      const quote = adef.quoteKey ? MC.randomQuote(adef.quoteKey, 'attach') : null;
      setTimeout(() => MC.playVfx(installVfx, { el: (el && el.querySelector('.card-art')) || hostEl, quote }), atIdx++ * 90);
    }
    // 라이노 슈트 파괴 감지: G.fxSuitBreak 힌트 → suitBreak 연출 + 대사
    if (G.fxSuitBreak && !suitBreakShown){
      suitBreakShown = true;
      const quote = MC.randomQuote('rhino-suit', 'suitBreak');
      const hostEl = document.querySelector('.villain-zone .card-art');
      setTimeout(() => MC.playVfx('suitBreak', { el: hostEl, quote }), 200);
    } else if (!G.fxSuitBreak){
      suitBreakShown = false;
    }
    // 공격 종료 부착물 소모 감지 (돌진 등): G.fxAttachSpent 힌트 → 카드별 vfx.spent 연출 + spent 대사
    if (G.fxAttachSpent && G.fxAttachSpent.seq !== attachSpentSeq){
      attachSpentSeq = G.fxAttachSpent.seq;
      const sdef = MC.cardDef(G.fxAttachSpent.defCode);
      const spentVfx = sdef && sdef.vfx && sdef.vfx.spent;
      if (spentVfx){
        const quote = sdef.quoteKey ? MC.randomQuote(sdef.quoteKey, 'spent') : null;
        const hostEl = document.querySelector('.villain-zone .card-art');
        setTimeout(() => MC.playVfx(spentVfx, { el: hostEl, quote }), 250);
      }
    }
    // 하수인 공격 감지 (fxMinionAttack): 공격 이펙트(vfx.attack) + attack 대사 버블.
    // defCode 자체를 quoteKey로 사용 (하수인은 카드 code = 대사 키). 방어 선언 전에 재생.
    if (G.fxMinionAttack && G.fxMinionAttack.seq !== minionAttackSeq){
      minionAttackSeq = G.fxMinionAttack.seq;
      const fm = G.fxMinionAttack;
      const mdef = MC.cardDef(fm.defCode);
      const atkEl = document.querySelector(`[data-vuid="${fm.attackerUid}"]`);
      const tgtEl = document.querySelector(`[data-vuid="${fm.targetUid}"]`);
      const atkVfx = mdef && mdef.vfx && mdef.vfx.attack;
      const quote = MC.hasQuote(fm.defCode, 'attack') ? MC.randomQuote(fm.defCode, 'attack') : null;
      if (atkVfx && atkEl){
        const fromRect = atkEl.getBoundingClientRect();
        const toRect = tgtEl && tgtEl.getBoundingClientRect();
        setTimeout(() => MC.playVfx(atkVfx, { el: atkEl, fromRect, toRect, targetEl: tgtEl, quote }), 120);
      } else if (quote && atkEl){
        setTimeout(() => MC.speechBubble(atkEl, quote, { duration: 2400 }), 120);
      }
    }
    // 실험 무기 덱 공개 감지 (fxWeaponReveal): 크로스본즈 III·메인스킴 공개 시 무기 공개 연출.
    if (G.fxWeaponReveal && G.fxWeaponReveal.seq !== weaponRevealSeq){
      weaponRevealSeq = G.fxWeaponReveal.seq;
      const wr = G.fxWeaponReveal;
      const wdef = MC.cardDef(wr.defCode);
      const delay = (revealShowing || revealQueue.length || boostRevealShowing) ? 900 : 200;
      setTimeout(() => MC.playVfx('weaponReveal', { name: wdef ? wdef.name : '무기' }), delay);
    }
    // 강제 버림 감지 (fxForcedDiscard): 헐크 격노(손패 전체)·무작위 버림 등 공용 연출.
    if (G.fxForcedDiscard && G.fxForcedDiscard.seq !== forcedDiscardSeq){
      forcedDiscardSeq = G.fxForcedDiscard.seq;
      const fd = G.fxForcedDiscard;
      const delay = (revealShowing || revealQueue.length || boostRevealShowing) ? 900 : 120;
      setTimeout(() => MC.playVfx('forcedDiscard', { count: fd.count, reason: fd.reason || '강제 버림!' }), delay);
    }
    // 그린 고블린 폼 전환 감지 (fxGoblinFlip): 노먼↔고블린 변신 연출 + 새 면 등장 대사
    if (G.fxGoblinFlip && G.fxGoblinFlip.seq !== goblinFlipSeq){
      goblinFlipSeq = G.fxGoblinFlip.seq;
      const ff = G.fxGoblinFlip;
      const vzone = document.querySelector('.villain-zone');
      const cardEl = vzone && vzone.querySelector('.card-art');
      const delay = (revealShowing || revealQueue.length || boostRevealShowing) ? 900 : 150;
      setTimeout(() => MC.playVfx('goblinTransform', { el: cardEl, cardEl, dir: ff.dir, quote: ff.quote }), delay);
    }
    // 각 히어로 피해 감지 (fxDamageEachHero): 쇼커 공개 시 등 "각 히어로에게 N 피해".
    // 하수인이면 그 하수인의 vfx.attack(공격 이펙트)을 각 피격 히어로 위에 재생, 아니면 범용 피해.
    // 공개 모달이 떠 있으면 모달 닫힌 뒤 재생되도록 지연 (revealQueue 처리와 조화).
    if (G.fxDamageEachHero && G.fxDamageEachHero.seq !== damageEachHeroSeq){
      damageEachHeroSeq = G.fxDamageEachHero.seq;
      const fd = G.fxDamageEachHero;
      const src = fd.defCode ? MC.cardDef(fd.defCode) : null;
      const isMinion = src && src.type === 'minion';
      const atkVfx = src && src.vfx && src.vfx.attack;
      const baseDelay = (revealShowing || revealQueue.length || boostRevealShowing) ? 900 : 200;
      (fd.targetUids || []).forEach((uid, i) => {
        const tgtEl = document.querySelector(`[data-vuid="${uid}"]`);
        if (!tgtEl) return;
        const delay = baseDelay + i * 160;
        setTimeout(() => {
          const r = tgtEl.getBoundingClientRect();
          if (isMinion && atkVfx){
            // 하수인 등장 피해: 공격 이펙트를 대상 위에 (fromRect 없이 대상 중심)
            MC.playVfx(atkVfx, { el: tgtEl, fromRect: r, toRect: r, targetEl: tgtEl });
          } else {
            // 범용 피해 연출: 임팩트 버스트 + 흔들림
            MC.playVfx('impactHit', { targetEl: tgtEl, rect: r, amount: fd.amount });
          }
        }, delay);
      });
      // 등장 대사 버블 (enter는 모달에서 이미 표시하므로 여기선 attack 톤)
    }
    // 신규 설치 감지: 공용 = install, 캐릭터 전용 = 소유 영웅의 cardInstall 연출
    const installedNow = [];
    for (const pl of G.players){
      for (const c of pl.playArea.allies) installedNow.push({ inst:c, type:'ally', pl });
      for (const c of pl.playArea.supports) installedNow.push({ inst:c, type:'support', pl });
      for (const c of pl.playArea.upgrades) installedNow.push({ inst:c, type:'upgrade', pl });
    }
    let insIdx = 0;
    for (const { inst, type, pl } of installedNow){
      if (installedPrev.has(inst.uid)) continue;
      const def = MC.cardDef(inst.defCode);
      const el = document.querySelector(`[data-vuid="${inst.uid}"]`);
      if (!el) continue;
      if (type === 'ally'){
        // 시그니처 동료(def.hero 소속): 영웅별 전용 소환 연출 매핑. 일반 동료: 공용 allyEnter.
        const heroOwner = def && def.hero;
        const sigVfx = heroOwner && HERO_ALLY_SUMMON[heroOwner];
        setTimeout(() => MC.playVfx(sigVfx || 'allyEnter', { el }), insIdx++ * 80);
        continue;
      }
      // 설치 연출 우선순위: ① 카드 자체 vfx.install ② 영웅별 매핑 ③ 공용 install
      const cardInstallVfx = def && def.vfx && def.vfx.install;
      const heroInstallVfx = def && def.hero && HERO_CARD_INSTALL[def.hero];
      const chosen = cardInstallVfx || heroInstallVfx || 'install';
      const insDelay = insIdx++ * 80;
      setTimeout(() => MC.playVfx(chosen, { el, label: type==='upgrade'?'EQUIP!':'DEPLOY!' }), insDelay);
      // 어스팩트 색상 오라 (카드가 어느 어스팩트인지 즉시 각인 — 공격=빨강/정의=노랑/
      // 리더십=파랑/보호=초록/기본=회색). 설치 연출과 함께 재생.
      const aspect = def && def.aspect;
      if (aspect) setTimeout(() => MC.playVfx('aspectAura', { el, aspect }), insDelay + 60);
    }
    // 공격 개시 인터럽트 연출 (Spider-Sense 등): 새 방어 pending이 생기고
    // 대상 신분(영웅면)에 attackInterrupt 연출이 걸려 있으면 재생
    if (!pendingPrev && G.pending && G.pending.kind === 'defense'){
      const dp = G.players.find(x => x.uid === G.pending.player);
      if (dp && dp.form === 'hero'){
        const hdef = MC.cardDef(dp.heroCode);
        const hookName = hdef && hdef.attackInterrupt;
        const vfxName = hdef && hdef.vfx && hookName && hdef.vfx[hookName];
        const el = document.querySelector(`[data-vuid="${dp.uid}"]`);
        if (vfxName && el) MC.playVfx(vfxName, { el });
      }
    }
    // HP 감소 감지: 피격 리액션 (사라지지 않은 카드만 — 처치와 중복 방지)
    if (!opt.suppressHit){
      const hpNow = collectHp();
      for (const uid in hpPrev){
        if (!(uid in hpNow)) continue;
        if (defeatablesPrev[uid] && !aliveNow.has(uid)) continue; // 처치된 건 KO로
        const drop = hpPrev[uid] - hpNow[uid];
        if (drop > 0){
          const el = document.querySelector(`[data-vuid="${uid}"]`);
          if (el) MC.playVfx('onHit', { el, big: drop >= 3 });
        }
      }
    }
    // 보복(Retaliate) 연출 — 블랙팬서 등 신분 보복: 공격자에게 키네틱 반격 (onHit 뒤 시간차)
    if (G && G.fxRetaliate && G.fxRetaliate.vfx){
      const fr = G.fxRetaliate;
      const rel = document.querySelector(`[data-vuid="${fr.targetUid}"]`);
      if (rel) setTimeout(() => MC.playVfx(fr.vfx, { el: rel }), 300);
    }
    // 와칸다 포에버 시퀀스 — 각 업그레이드에 순차 발동 연출 (일반/최종 강화 분리)
    // + 효과별 전용 연출: 단검 비행·발톱 강타·전술 홀로그램·키네틱 이동
    if (G && G.fxWakandaSeq && G.fxWakandaSeq.steps){
      const q = uid => document.querySelector(`[data-vuid="${uid}"]`);
      G.fxWakandaSeq.steps.forEach((st, i) => {
        setTimeout(() => {
          const sel = q(st.uid);
          if (sel) MC.playVfx(st.final ? 'specialGlowFinal' : 'specialGlow', { el: sel });
          setTimeout(() => {
            if (st.defCode === 'energy-daggers' && st.targets){
              const tEls = st.targets.map(q).filter(Boolean);
              if (sel && tEls.length) MC.playVfx('energyDaggers', { el: sel, targets: tEls, big: st.final });
            } else if (st.defCode === 'panther-claws' && st.target){
              const t = q(st.target);
              if (t) MC.playVfx('claws', { el: t, big: st.final });
            } else if (st.defCode === 'tactical-genius-bp' && st.schemeUid){
              const t = q(st.schemeUid);
              if (t) MC.playVfx('tacticalHolo', { el: t, big: st.final });
            } else if (st.defCode === 'vibranium-suit' && st.target){
              const t = q(st.target);
              if (t) MC.playVfx('kineticTransfer', { from: q(st.heroUid), to: t, big: st.final });
            }
          }, 280);
        }, 650 + i * 950);
      });
    }
    // 헐크 강제 반응 — 감마 스매시 (자원별 후속 효과는 로그로 표시)
    if (G && G.fxHulk && G.fxHulk.hulkUid){
      const hEl = document.querySelector(`[data-vuid="${G.fxHulk.hulkUid}"]`);
      if (hEl) setTimeout(() => MC.playVfx('gammaSmash', { el: hEl }), 200);
    }
    // 타이그라 — 야수 도약 + (사냥감 처치 시) 회복 반짝임
    if (G && G.fxTigra && G.fxTigra.tigraUid){
      const tEl = document.querySelector(`[data-vuid="${G.fxTigra.tigraUid}"]`);
      if (tEl) setTimeout(() => MC.playVfx('tigraPounce', { el: tEl, healed: true }), 200);
    }
    // 데어데블 — 저지 후 레이더 파동 (반응 피해)
    if (G && G.fxDaredevil && G.fxDaredevil.ddUid){
      const dEl = document.querySelector(`[data-vuid="${G.fxDaredevil.ddUid}"]`);
      if (dEl) setTimeout(() => MC.playVfx('radarSense', { el: dEl }), 200);
    }
    // 호크아이 — 화살 명중 (하수인 대상)
    if (G && G.fxHawkeye && G.fxHawkeye.targetUid){
      const tEl = document.querySelector(`[data-vuid="${G.fxHawkeye.targetUid}"]`);
      if (tEl) setTimeout(() => MC.playVfx('aggressionSlash', { el: tEl, word:'화살!' }), 200);
    }
    // 이벤트 전용 연출 (공격 슬래시 / 오버킬 관통 / 위협 제거 등) — 대상/스킴 위치에서 재생
    if (G && G.fxEvent && G.fxEvent.vfx){
      const fe = G.fxEvent;
      const q = uid => document.querySelector(`[data-vuid="${uid}"]`);
      setTimeout(() => {
        if (fe.vfx === 'threatDrain'){
          const schemeUid = fe.scheme === 'main' ? (G.mainScheme && G.mainScheme.uid) : fe.scheme;
          const sEl = schemeUid && q(schemeUid);
          if (sEl) MC.playVfx('threatDrain', { el: sEl });
        } else if (fe.vfx === 'overkillPierce'){
          const tEl = fe.targetUids[0] && q(fe.targetUids[0]);
          const vEl = fe.villainUid && q(fe.villainUid);
          if (tEl) MC.playVfx('overkillPierce', { el: tEl, villainEl: vEl });
        } else {
          // aggressionSlash 등 대상 위치 연출 — 각 대상에 순차
          (fe.targetUids || []).forEach((uid, i) => {
            const tEl = q(uid);
            if (tEl) setTimeout(() => MC.playVfx(fe.vfx, { el: tEl }), i * 140);
          });
        }
      }, 180);
    }
  }
  // 덱 공개 효과(리펄서 블래스트 / 조우덱 확인 등) → 세련된 공개 시퀀스 오버레이
  if (ok && G && G.fxReveal && (G.fxReveal.kind === 'repulsor' || G.fxReveal.kind === 'peek')){
    fxRevealShowing = G.fxReveal;
    setTimeout(() => render(), 30);   // 렌더 후 애니메이션 진입
  }
  // 부스트 카드 공개 → 전용 플립 시퀀스 오버레이 (무엇을 뽑았고 무슨 옵션이 발동했는지)
  if (ok && G && G.fxBoostReveal && G.fxBoostReveal.seq !== boostRevealSeqPrev){
    boostRevealSeqPrev = G.fxBoostReveal.seq;
    boostRevealShowing = G.fxBoostReveal;
    setTimeout(() => render(), 30);
  }
  // 어보밍맨 환경 미방어 반응 → 전장 환경 카드 위에서 원소별 반응 연출
  if (ok && G && G._environmentReaction && G._environmentReaction.seq !== envReactionSeqPrev){
    envReactionSeqPrev = G._environmentReaction.seq;
    const er = G._environmentReaction;
    setTimeout(() => {
      const env = (G.environments||[]).find(e => e.defCode === er.defCode) || (G.environments||[])[0];
      const el = env && document.querySelector(`[data-vuid="${env.uid}"]`);
      if (el) MC.playVfx('environmentReact', { el, reactType: er.type, amount: er.amount, defCode: er.defCode });
    }, 60);
  }
  // 초강력 흡수(04092) 소환 → 빌런이 4원소를 흡수하는 대연출
  if (ok && G && G._superAbsorbSpawn && G._superAbsorbSpawn.seq !== superAbsorbSeqPrev){
    superAbsorbSeqPrev = G._superAbsorbSpawn.seq;
    setTimeout(() => {
      const vEl = G.villain && document.querySelector(`[data-vuid="${G.villain.uid}"]`);
      if (vEl) MC.playVfx('superAbsorbSpawn', { el: vEl });
    }, 60);
  }
  // 새로 공개된 조우/부스트 카드 → 확인 큐 (한 장씩 모달, 계속 버튼으로 진행)
  // ※ 부스트(type==='boost')는 전용 시퀀스 오버레이가 담당 — 범용 모달 큐에서 제외
  if (ok && G && G.revealLog && G.revealLog.length > revealLenPrev){
    const newLogs = G.gameLog.slice(logLenPrev);
    G.revealLog.slice(revealLenPrev).forEach(r => {
      if (r.type === 'boost') return;
      if (r.fromBoostStar) return;   // 부스트★로 배치된 하수인 — 부스트 공개 오버레이가 순서대로 안내(별도 모달 억제)
      revealQueue.push({ r, logs: newLogs });
    });
    pumpRevealQueue();
  }
  // 게임 종료 전환 감지: 승리 → 빌런 최종 격파 대연출 → 결과창 / 패배 → 결과창
  if (ok && !overPrev && G && G.over){
    hideStepStrip();
    if (G.over.result === 'win' && villainSnap){
      const quote = MC.randomQuote(villainSnap.quoteKey, 'defeat');
      // 빌런 테마 전용 패배 연출 (예: 라이노=rhinoCollapse 갑옷 붕괴). 정의에 있으면 먼저 재생.
      const vdef = villainSnap.defCode && MC.cardDef(villainSnap.defCode);
      const defeatVfx = vdef && vdef.vfx && vdef.vfx.defeat;
      if (defeatVfx) MC.playVfx(defeatVfx, { rect: villainSnap.rect, imgUrl: villainSnap.imgUrl });
      MC.playVfx('villainDefeat', {
        rect: villainSnap.rect, imgUrl: villainSnap.imgUrl, quote,
        onDone: () => { resultsShown = true; render(); runCountups(); },
      });
    } else {
      setTimeout(() => { resultsShown = true; render(); runCountups(); }, 700);
    }
  }
  // 빌런 페이즈 단계별 진행 재개 (방어/인터럽트 해소 후에도 자동 계속)
  if (ok && G && G.villainStepMode && G.phase === 'villain' && !G.pending) maybeStepVillain();
  return ok;
}
function imgUrl(code){
  const def = MC.cardDef(code);
  return (def && def.image) ? def.image : (IMG_BASE + code + '.png');
}
function cardArt(code, name, w, badges, mag, vuid){
  return `<div class="card-art" ${vuid?`data-vuid="${vuid}"`:''} style="width:${w}px">
    <img src="${imgUrl(code)}" loading="lazy" alt=""
      onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
    <div class="fallback" style="display:none;height:${Math.round(w*1.4)}px">${esc(name)}</div>
    ${badges||''}
    ${mag?`<span class="mag-badge" onclick="event.stopPropagation();UI.info('${code}')">🔍</span>`:''}</div>`;
}
/* 소진 차단바 (대각선 위험 스트라이프) */
function exhBar(){
  return `<div class="exh-dim"></div><div class="exh-bar"><span>소진!</span></div>`;
}
/* 지속형 강인(Tough) 배리어 badge — tough 상태 캐릭터를 감싸는 투명 방어막.
   tough 개수 n이 2 이상이면 겹수 배지도 표시 (여러 강인 대비). */
function toughBarrier(status){
  const n = (status && status.tough) || 0;
  if (n <= 0) return '';
  return `<div class="tough-barrier"></div>` +
         (n > 1 ? `<span class="tough-count" title="강인 ${n}겹">🛡${n}</span>` : '');
}
/* 설치된 지원/업그레이드 uid 집합 (신규 설치 감지용) */
function collectInstalled(){
  const s = new Set();
  if (!G) return s;
  for (const pl of G.players){
    for (const c of pl.playArea.allies) s.add(c.uid);      // ★ 동료 누락 시 매 액션마다 allyEnter 재발동 버그
    for (const c of pl.playArea.supports) s.add(c.uid);
    for (const c of pl.playArea.upgrades) s.add(c.uid);
  }
  return s;
}
/* 상태이상 스냅샷 (uid → {confused, tough, stunned}) — 상태 부여 diff 연출용 */
function collectStatuses(){
  const m = {};
  if (!G) return m;
  const grab = (inst) => { const s = inst.status||{}; m[inst.uid] = { confused:s.confused||0, tough:s.tough||0, stunned:s.stunned||0 }; };
  if (G.villain) grab(G.villain);
  for (const pl of G.players){
    for (const mn of pl.engagedMinions) grab(mn);
    for (const al of pl.playArea.allies) grab(al);   // 동료 상태(기절/혼란/강인) — 미스캔 시 상태 연출 누락
  }
  return m;
}
/* 부착물 스냅샷: 적(빌런/하수인)에 붙은 부착물 uid → { rect(적 위치), defCode, detachVfx } */
function collectAttachments(){
  const m = {};
  if (!G) return m;
  const scan = (host) => {
    const el = document.querySelector(`[data-vuid="${host.uid}"]`);
    const rect = el && el.getBoundingClientRect();
    for (const att of (host.attachments||[])){
      const def = MC.cardDef(att.defCode);
      const dv = def.vfx && def.vfx.detach;
      if (rect) m[att.uid] = { rect, defCode: att.defCode, detachVfx: dv, hostUid: host.uid };
    }
  };
  if (G.villain) scan(G.villain);
  for (const pl of G.players){
    for (const mn of pl.engagedMinions) scan(mn);
    for (const al of pl.playArea.allies) scan(al);   // 동료 부착물(격분/감화 등) — 미스캔 시 설치/해제 연출 누락
  }
  return m;
}
/* 처치 대상 스냅샷: 살아있는 적/동료의 화면 좌표·이미지 (디스패치 전 캡처) */
function collectDefeatables(){
  const m = {};
  if (!G) return m;
  const add = (inst, label) => {
    const el = document.querySelector(`[data-vuid="${inst.uid}"]`);
    const rect = el && el.getBoundingClientRect();
    if (rect) m[inst.uid] = { rect, imgUrl: imgUrl(inst.defCode), label, defCode: inst.defCode,
      isVillain: label === 'villain' };
  };
  if (G.villain) add(G.villain, 'villain');
  for (const pl of G.players){
    for (const mn of pl.engagedMinions) add(mn, 'minion');
    for (const al of pl.playArea.allies) add(al, 'ally');
  }
  return m;
}
/* 현재 생존 uid 집합 (스냅샷 대상과 동일 범위) */
function collectAliveUids(){
  const s = new Set();
  if (!G) return s;
  if (G.villain) s.add(G.villain.uid);
  for (const pl of G.players){
    for (const mn of pl.engagedMinions) s.add(mn.uid);
    for (const al of pl.playArea.allies) s.add(al.uid);
  }
  return s;
}
/* HP 원시값 스냅샷 (uid → hp) — 피격/회복 diff용 */
function collectHp(){
  const m = {};
  if (!G) return m;
  if (G.villain) m[G.villain.uid] = G.villain.hp;
  for (const pl of G.players){
    m[pl.uid] = pl.hp;
    for (const arr of [pl.playArea.allies, pl.engagedMinions])
      for (const c of arr) m[c.uid] = c.hp;
  }
  for (const mn of (G.villain && G.villain.attachments ? [] : [])) {}
  return m;
}
/* 소진 상태 스냅샷 (uid → true) — 준비 회복 diff용 */
function collectExhausted(){
  const m = {};
  if (!G) return m;
  for (const pl of G.players){
    if (pl.exhausted) m[pl.uid] = true;
    for (const arr of [pl.playArea.allies, pl.playArea.supports, pl.playArea.upgrades])
      for (const c of arr) if (c.exhausted) m[c.uid] = true;
  }
  return m;
}
function todoBadge(code){
  const def = MC.cardDef(code);
  return (def && def.todoFx) ? '<span class="badge todo">수동</span>' : '';
}
/* 카운터 배지 — 실제 카운터를 보유 중이거나(uses/충전/등장카운터), 충전형 카운터 카드(counterAbility)면 항상 표시.
   에너지 채널(충전 전 0), 퀸젯(시간), 호크아이(화살), 웹 슈터(사용) 등 카운터 확인용. */
function counterBadge(inst, def){
  const d = def || MC.cardDef(inst.defCode) || {};
  const has = inst.counters !== undefined || d.counterAbility || d.uses !== undefined || d.entersWithCounters !== undefined || d.counterGainPerPhase !== undefined;
  if (!has) return '';
  const n = inst.counters || 0;
  return `<span class="badge atb" title="카운터 ${n}">◉ ${n}</span>`;
}
const RES_ICON = { physical:'💪', mental:'🧠', energy:'⚡', wild:'🌟' };
function resIcons(c){
  if (!c.resources) return '';
  let s = '';
  for (const k in c.resources) s += (RES_ICON[k]||'?').repeat(c.resources[k]);
  return s;
}

/* ── 덱 유틸 ── */
function heroSignatureCards(heroKey){
  const out = [];
  for (const code in MC.CARDS){
    const d = MC.CARDS[code];
    if (d.hero === heroKey && d.side === 'player' &&
        ['ally','event','support','upgrade','resource'].includes(d.type)) out.push(d);
  }
  return out;
}
function expandCounts(counts){
  const list = [];
  for (const code in counts) for (let i=0;i<counts[code];i++) list.push(code);
  return list;
}
function deckOptionsFor(heroKey){
  const opts = [];
  if (MC.PRESET_DECKS[heroKey]) opts.push({ id:'preset', name:'프리셋 — ' + MC.PRESET_DECKS[heroKey].name });
  loadSlots().forEach((d,i)=>{
    if (d && d.heroKey === heroKey) opts.push({ id:'slot:'+i, name:'['+(i+1)+'] '+d.name+' ('+d.total+'장)' });
  });
  return opts;
}
function resolveDeck(heroKey, deckId){
  if (deckId && deckId.startsWith('slot:')){
    const d = loadSlots()[+deckId.slice(5)];
    if (d) return expandCounts(d.counts);
  }
  if (MC.PRESET_DECKS[heroKey]) return MC.PRESET_DECKS[heroKey].cards.slice();
  return null;
}

/* ── 게임 시작 ── */
function startGame(){
  comicIntroShown = false; comicDefeatShown = false;   // 새 게임: 코믹스 재표시 허용
  const scen = MC.SCENARIOS[APP.scenarioKey];
  if (!scen){ toast('이 빌런은 아직 준비 중!', true); return; }
  const playerDefs = [];
  for (const sl of APP.slots){
    const deck = resolveDeck(sl.heroKey, sl.deckId);
    if (!deck || !deck.length){
      toast(HERO_META[sl.heroKey].name + ' 덱이 없어요 — 덱빌더나 가져오기로 만들어 주세요!', true);
      return;
    }
    playerDefs.push({ heroCode: HERO_META[sl.heroKey].art, deckCodes: deck });
  }
  // 난이도: 전문가는 빌런 2단계부터 (코어 룰). 다음 단계가 없으면 1단계 유지
  const vNext = MC.cardDef(scen.villainStart).nextStage;
  const vStart = (APP.difficulty === 'expert' && vNext) ? vNext : scen.villainStart;
  // 모듈러 세트 결정: default(빌런 권장) / random(무작위) / custom(직접 선택)
  let modularKeys;
  if (APP.modularMode === 'custom'){
    modularKeys = (APP.modularPick || []).slice();
  } else if (APP.modularMode === 'random'){
    // 전투 개시 시 한 번 확정한 키가 있으면 재사용, 없으면 새로 뽑음
    modularKeys = APP.modularRandomKeys || MC.randomModularKeys(APP.modularRandomN || 1);
    APP.modularRandomKeys = modularKeys.slice();
  } else {
    modularKeys = (scen.defaultModular || []).slice();
  }
  const encounterCodes = MC.buildEncounter(APP.scenarioKey, modularKeys, APP.difficulty);
  G = MC.makeGameState({
    seed: (Date.now() ^ (Math.random()*0xFFFFFFFF)) >>> 0,
    players: playerDefs,
    villainCode: vStart, mainScheme: scen.mainScheme,
    encounterCodes: encounterCodes,
    startEnvironment: scen.startEnvironment,   // 시나리오 셋업 환경 (그린 고블린 Criminal Enterprise 등)
    difficulty: APP.difficulty,
  });
  MC.setupGame(G);
  // 태스크마스터 셋업: 포로(Captive) 동료를 게임 밖에 두고(set aside), Hydra Patrol 사이드 스킴을 공개
  if (scen.captiveAllies && scen.captiveAllies.length){
    G.setAsideCaptives = scen.captiveAllies.slice();
    MC.log(G, '포로 동료 ' + G.setAsideCaptives.length + '명을 게임 밖에 둔다 (구출 대기)');
  }
  if (scen.setupRevealSideScheme && MC.revealSpecificSideScheme){
    MC.revealSpecificSideScheme(G, scen.setupRevealSideScheme);
  }
  // 졸라 셋업: 각 플레이어가 조우덱에서 얼티밋 바이오-서번트 1장을 찾아 자신과 교전 상태로 배치, 그 후 조우덱 재셔플
  if (scen.setupEngageMinion){
    for (const pl of G.players){
      const idx = G.encounterDeck.findIndex(c => (c.defCode || c.code) === scen.setupEngageMinion);
      if (idx >= 0){
        const m = G.encounterDeck.splice(idx, 1)[0];
        m.engagedWith = pl.uid;
        pl.engagedMinions = pl.engagedMinions || [];
        pl.engagedMinions.push(m);
        if (MC.minionEnteredPlay) MC.minionEnteredPlay(G, m, pl);
        (G.revealLog = G.revealLog || []).push({ defCode: m.defCode, name: m.name, type: 'minion', player: pl.uid });
        MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(m) + ' 교전 배치 (셋업)');
      }
    }
    if (MC.shuffle) MC.shuffle(G, G.encounterDeck);
  }
  // 어보밍맨 셋업: 조우덱에서 환경이 나올 때까지 버리고, 첫 환경 1장을 전장에 배치 후 나머지 재셔플
  if (scen.setupRevealEnvironment && G.environments.length === 0){
    const envIdx = G.encounterDeck.findIndex(c => (MC.cardDef(c.defCode)||{}).type === 'environment');
    if (envIdx >= 0){
      const env = G.encounterDeck.splice(envIdx, 1)[0];
      G.environments.push(env);
      if (MC.shuffle) MC.shuffle(G, G.encounterDeck);
      MC.log(G, '🌐 시작 환경 공개: ' + MC.nameOf(env));
    }
  }
  G.campaign = APP.campaign || null;   // 캠페인 모드에서만 코믹스 표시 (단독 빌런은 X)
  sel = { mode:null, cardUid:null, player:null };
  pay = null;
  resultsShown = false;
  saveGame();
  render();
  setTimeout(() => MC.playVillainEntrance(G), 60); // 렌더 후 등장 연출 (표현 계층 — 상태 무변경)
}

/* ═══ 메뉴 화면 ═══ */
function menuShell(inner, cls){
  return `<div class="menu-wrap halftone ${cls||''}"><div class="menu-inner popin">${inner}</div></div>` + menuOverlays();
}

function renderTitle(){
  const cont = hasSave();
  $('app').innerHTML = menuShell(`
    <div class="title-hero speedlines">
      <div class="title-marvel">MARVEL</div>
      <div class="title-champ">CHAMPIONS</div>
      <div class="burst" style="top:-6px;right:6%;transform:rotate(14deg) scale(1.05)">POW!</div>
      <div class="burst yellow" style="bottom:-16px;left:4%;transform:rotate(-10deg) scale(.8)">BAM!</div>
    </div>
    <div class="menu-grid">
      <button class="menu-big red" onclick="UI.startSolo()">
        <span class="mb-title">게임 시작</span><span class="mb-sub">솔로 · 1인</span></button>
      <button class="menu-big blue" onclick="UI.startMode('hotseat')">
        <span class="mb-title">핫시트</span><span class="mb-sub">한 기기 · 최대 4인</span></button>
      <button class="menu-big purple" onclick="UI.multiSoon()">
        <span class="mb-title">멀티플레이</span><span class="mb-sub">각자 화면</span>
        <span class="pick-tag red" style="top:-12px;right:-8px">준비 중!</span></button>
      <button class="menu-big green" onclick="UI.openBuilder()">
        <span class="mb-title">덱빌더</span><span class="mb-sub">나만의 덱 구성</span></button>
      <button class="menu-big yellow" onclick="UI.go('import')">
        <span class="mb-title">덱 가져오기</span><span class="mb-sub">텍스트 목록 붙여넣기</span></button>
      <button class="menu-big ink" ${cont?'':'disabled'} onclick="UI.continueGame()">
        <span class="mb-title">이어하기</span><span class="mb-sub">${cont?'저장된 전투 재개':'저장 없음'}</span></button>
    </div>
    <div class="note" style="text-align:center">엔진 ${MC.VERSION} · 카드 ${Object.keys(MC.CARDS).length}장 · 내 덱 ${loadDecks().length}/${DECK_SLOTS}</div>`);
}

function slotHTML(sl, i){
  const m = HERO_META[sl.heroKey];
  const opts = deckOptionsFor(sl.heroKey);
  const optHTML = opts.length
    ? opts.map(o => `<option value="${o.id}" ${sl.deckId===o.id?'selected':''}>${esc(o.name)}</option>`).join('')
    : `<option value="">(덱 없음 — 덱빌더로 제작)</option>`;
  return `<div class="comic-panel slot ${i%2?'tilt-r':'tilt-l'}">
    <div class="slot-head"><span class="caption-box" style="font-size:12px">HERO ${i+1}</span>
      ${APP.slots.length>1?`<button class="comic-btn sm ghost" onclick="UI.slotRemove(${i})">✕</button>`:''}</div>
    <div class="zrow" style="align-items:center">
      <div style="width:86px;cursor:pointer" onclick="UI.heroPickOpen('slot',${i})" title="영웅 변경">
        ${cardArt(m.art, m.name, 86)}</div>
      <div style="flex:1;min-width:170px">
        <b style="font-size:17px">${esc(m.name)}</b>
        <button class="comic-btn sm ghost" style="margin-left:8px" onclick="UI.heroPickOpen('slot',${i})">영웅 변경</button>
        <div style="margin-top:8px"><select class="comic-select" onchange="UI.slotDeck(${i}, this.value)">${optHTML}</select></div>
        <div class="mini-note">${MC.PRESET_DECKS[sl.heroKey]?'프리셋 또는 내 덱 선택':'이 영웅은 덱빌더/가져오기 덱이 필요합니다'}</div>
      </div>
    </div></div>`;
}
/* 영웅 픽커 오버레이 (31종 그리드) */
function heroPickerHTML(){
  if (!APP.heroPick) return '';
  const cur = APP.heroPick.kind==='slot' ? APP.slots[APP.heroPick.i].heroKey : (APP.builder&&APP.builder.heroKey);
  const tiles = HERO_KEYS.map(k => {
    const m = HERO_META[k];
    const sigN = heroSignatureCards(k).reduce((a,d)=>a+(d.copies||1),0);
    return `<div class="pick-card ${cur===k?'on':''}" onclick="UI.heroPickChoose('${k}')">
      <img src="${imgUrl(m.art)}" loading="lazy" onerror="this.style.opacity=.2">
      <div class="pick-name" style="font-size:13px">${esc(m.name)}</div>
      <div class="mini-note">시그니처 ${sigN}장${MC.PRESET_DECKS[k]?' · 프리셋':''}</div></div>`;
  }).join('');
  return `<div class="overlay" onclick="UI.heroPickClose()">
    <div class="overlay-card" style="max-width:640px;background:var(--paper)" onclick="event.stopPropagation()">
      <span class="caption-box">영웅 선택 (${HERO_KEYS.length})</span>
      <div class="pick-grid" style="max-height:62vh;overflow-y:auto;padding:6px">${tiles}</div>
      <button class="comic-btn ghost" onclick="UI.heroPickClose()">닫기</button></div></div>`;
}
/* 덱 저장 슬롯 픽커 (10칸) */
function slotPickerHTML(){
  if (!APP.slotPick) return '';
  const sl = loadSlots();
  const rows = sl.map((d,i) => `
    <div class="slotrow ${d?'used':''}" onclick="UI.slotWrite(${i})">
      <span class="slotno latin">${i+1}</span>
      ${d ? `<span><b>${esc(d.name)}</b> <span class="mini-note">${esc(HERO_META[d.heroKey]?HERO_META[d.heroKey].name:d.heroKey)} · ${d.total}장</span></span>
             <button class="comic-btn sm ghost" onclick="event.stopPropagation();UI.slotDelete(${i})">삭제</button>`
           : `<span class="mini-note">비어 있음</span><span></span>`}
    </div>`).join('');
  return `<div class="overlay" onclick="UI.slotPickClose()">
    <div class="overlay-card" style="max-width:480px;background:var(--paper)" onclick="event.stopPropagation()">
      <span class="caption-box">저장 슬롯 선택 — "${esc(APP.slotPick.name)}"</span>
      <div class="slotlist">${rows}</div>
      <button class="comic-btn ghost" onclick="UI.slotPickClose()">취소</button></div></div>`;
}
function renderTeam(){
  const slots = APP.slots.map(slotHTML).join('');
  const canAdd = APP.mode === 'hotseat' && APP.slots.length < 4;
  $('app').innerHTML = menuShell(`
    <div class="steprow"><span class="caption-box">STEP 1 — 팀 구성</span>
      <span class="caption-box" style="background:#fff">${APP.mode==='solo'?'솔로':'핫시트 '+APP.slots.length+'인'}</span></div>
    ${slots}
    ${canAdd?`<button class="comic-btn ghost dashed" onclick="UI.slotAdd()">＋ 영웅 추가 (${APP.slots.length}/4)</button>`:''}
    <div class="nav-row">
      <button class="comic-btn ghost" onclick="UI.go('title')">◀ 메인</button>
      <button class="comic-btn blue" onclick="UI.go('villain')">빌런 선택 ▶</button>
    </div>`);
}

/* 모듈러 인카운터 세트 선택 패널 — 빌런 + (권장/랜덤/직접) 모듈러 조합 */
function renderModularPanel(){
  const scen = MC.SCENARIOS[APP.scenarioKey] || {};
  const sets = MC.MODULAR_SETS || {};
  const keys = Object.keys(sets);
  const setName = k => (sets[k] ? sets[k].name : k);
  const mode = APP.modularMode || 'default';
  const defList = (scen.defaultModular || []).map(setName).join(', ') || '없음';

  // 모드 3버튼
  const modeBtns = `
    <div class="diff-btns" style="margin-bottom:8px">
      <button class="comic-btn sm ${mode==='default'?'blue':'ghost'}" onclick="UI.modularMode('default')">
        권장 <span class="mini-note">${esc(defList)}</span></button>
      <button class="comic-btn sm ${mode==='random'?'blue':'ghost'}" onclick="UI.modularMode('random')">
        랜덤 <span class="mini-note">무작위 세트로 매번 다른 전투</span></button>
      <button class="comic-btn sm ${mode==='custom'?'blue':'ghost'}" onclick="UI.modularMode('custom')">
        직접 선택 <span class="mini-note">원하는 세트 조합</span></button>
    </div>`;

  // 모드별 상세
  let detail = '';
  if (mode === 'random'){
    const n = APP.modularRandomN || 1;
    const picked = APP.modularRandomKeys;
    detail = `
      <div style="text-align:center;margin-top:4px">
        <span class="mini-note">뽑을 세트 수:</span>
        <div class="diff-btns" style="justify-content:center;margin-top:4px">
          ${[1,2,3].map(i => `<button class="comic-btn sm ${n===i?'red':'ghost'}"
              onclick="UI.modularRandomN(${i})" ${i>keys.length?'disabled':''}>${i}세트</button>`).join('')}
        </div>
        <button class="comic-btn sm ghost" style="margin-top:8px" onclick="UI.rerollModular()">🎲 다시 뽑기</button>
        ${picked && picked.length ? `<div class="mini-note" style="margin-top:6px">
          현재 뽑힘: <b style="color:var(--c-red)">${picked.map(k=>esc(setName(k))).join(' + ')}</b></div>`
          : `<div class="mini-note" style="margin-top:6px">전투 개시 시 무작위로 결정돼요</div>`}
      </div>`;
  } else if (mode === 'custom'){
    const pick = APP.modularPick || [];
    detail = `
      <div class="pick-grid" style="grid-template-columns:repeat(2,1fr);gap:6px;margin-top:4px">
        ${keys.map(k => {
          const on = pick.includes(k);
          const cnt = (sets[k].cards || []).length;
          return `<div class="pick-card ${on?'on':''}" style="padding:8px;min-height:0"
              onclick="UI.toggleModular('${k}')">
            <div class="pick-name" style="font-size:14px">${on?'✔ ':''}${esc(sets[k].name)}</div>
            <div class="mini-note">${esc(sets[k].nameEn||'')} · ${cnt}장</div></div>`;
        }).join('')}
      </div>
      <div class="mini-note" style="text-align:center;margin-top:6px">
        ${pick.length ? '선택: <b style="color:var(--c-red)">'+pick.map(k=>esc(setName(k))).join(' + ')+'</b>'
                      : '세트를 하나 이상 골라 주세요 (빈 채로 두면 빌런 전용 조우만 사용)'}</div>`;
  }

  return `<div class="comic-panel diff-panel">
    <span class="caption-box" style="font-size:13px">모듈러 인카운터 세트</span>
    ${modeBtns}${detail}</div>`;
}

function renderVillain(){
  const tabV = APP.villainTab === 'villain';
  const readyVillains = VILLAIN_ROSTER.filter(v => v.ready);
  const randomTile = `<div class="pick-card ${APP.villainRandom?'on':''}" onclick="UI.pickRandomVillain()" title="준비된 빌런 중 무작위 — 다시 누르면 재추첨">
      <span class="pick-tag">🎲 랜덤</span>
      <div style="height:96px;display:flex;align-items:center;justify-content:center;font-size:52px">🎲</div>
      <div class="pick-name">랜덤 빌런</div>
      <div class="mini-note">${APP.villainRandom ? '선택됨: ' + esc(VILLAIN_META[APP.scenarioKey].name) + ' (다시=재추첨)' : '준비된 빌런 중 무작위 (' + readyVillains.length + '종)'}</div></div>`;
  const villains = randomTile + VILLAIN_ROSTER.map(v => {
    const m = VILLAIN_META[v.key];
    const on = !APP.campaign && !APP.villainRandom && APP.scenarioKey === v.key;
    return `<div class="pick-card ${on?'on':''} ${v.ready?'':'locked'}"
        onclick="${v.ready?`UI.pickVillain('${v.key}')`:''}">
      ${v.ready?`<span class="pick-tag">준비 완료</span>`:`<span class="pick-tag red">준비 중</span>`}
      <img src="${imgUrl(v.art)}" loading="lazy" onerror="this.style.opacity=.2">
      <div class="pick-name">${esc(m.name)}</div>
      <div class="mini-note">${esc(m.sub)}</div></div>`;
  }).join('');
  const camps = Object.entries(CAMPAIGNS).map(([k,c]) => {
    const on = APP.campaign === k;
    const chain = c.villains.map(vk => {
      const ready = (VILLAIN_ROSTER.find(v=>v.key===vk)||{}).ready;
      return `<span class="chain ${ready?'':'off'}">${esc(VILLAIN_META[vk].name)}</span>`;
    }).join('<span class="chain-arrow">➜</span>');
    return `<div class="comic-panel camp ${on?'campon':''}" onclick="UI.pickCampaign('${k}')">
      <b style="font-size:17px">${esc(c.name)}</b>
      <div style="margin:8px 0">${chain}</div>
      <div class="mini-note">${esc(c.desc)} (준비 중 빌런은 순서가 오면 잠금 해제 예정)</div></div>`;
  }).join('');
  const pickName = APP.campaign ? CAMPAIGNS[APP.campaign].name + ' — 1차전: ' + VILLAIN_META[APP.scenarioKey].name
                                : (APP.villainRandom ? '🎲 랜덤 — ' + VILLAIN_META[APP.scenarioKey].name : VILLAIN_META[APP.scenarioKey].name);
  $('app').innerHTML = menuShell(`
    <div class="steprow"><span class="caption-box">STEP 2 — 상대</span>
      <button class="comic-btn sm red" style="margin-left:auto" onclick="UI.randomizeAll()" title="빌런 + 모듈 전부 무작위 (다시 누르면 재추첨)">🎲 전부 랜덤</button>
      <div class="burst" style="position:static;transform:rotate(8deg);width:70px;height:70px;font-size:15px">VS!</div></div>
    <div class="tabrow">
      <button class="comic-btn sm ${tabV?'blue':'ghost'}" onclick="UI.villainTab('villain')">개별 빌런</button>
      <button class="comic-btn sm ${!tabV?'blue':'ghost'}" onclick="UI.villainTab('campaign')">시나리오</button>
    </div>
    ${tabV ? `<div class="comic-panel tilt-l"><div class="pick-grid">${villains}</div></div>` : camps}
    <div class="comic-panel diff-panel">
      <span class="caption-box" style="font-size:13px">난이도</span>
      <div class="diff-btns">
        <button class="comic-btn sm ${APP.difficulty==='standard'?'blue':'ghost'}" onclick="UI.setDifficulty('standard')">
          표준 <span class="mini-note">빌런 1·2단계 — 입문 권장</span></button>
        <button class="comic-btn sm ${APP.difficulty==='expert'?'red':'ghost'}" onclick="UI.setDifficulty('expert')">
          전문가 <span class="mini-note">빌런 2·3단계 — 1단계 스킵, 더 강함</span></button>
      </div></div>
    ${renderModularPanel()}
    <div class="comic-panel" style="text-align:center">
      <b>${APP.slots.map(s=>esc(HERO_META[s.heroKey].name)).join(' + ')}</b>
      &nbsp;<span class="latin" style="color:var(--c-red);font-size:20px">VS</span>&nbsp;
      <b style="color:var(--c-red)">${esc(pickName)}</b></div>
    <div class="nav-row">
      <button class="comic-btn ghost" onclick="UI.go('team')">◀ 팀</button>
      <button class="comic-btn red" style="font-size:21px;padding:12px 34px" onclick="UI.launch()">전투 개시!</button>
    </div>`);
}

/* ═══ 덱빌더 ═══ */
function builderPool(){
  const b = APP.builder;
  const q = (b.search || '').trim().toLowerCase();
  const match = (d) => {
    if (!q) return true;
    return (d.name && d.name.toLowerCase().includes(q))
        || (d.nameEn && d.nameEn.toLowerCase().includes(q))
        || (d.textKo && d.textKo.toLowerCase().includes(q))
        || (d.traits && d.traits.some(t => t.toLowerCase().includes(q)));
  };
  const pool = { sig:[], aspect:[], basic:[] };
  for (const code in MC.CARDS){
    const d = MC.CARDS[code];
    if (d.side !== 'player' || !['ally','event','support','upgrade','resource'].includes(d.type)) continue;
    if (!match(d)) continue;
    if (d.hero){ if (d.hero === b.heroKey) pool.sig.push(d); continue; }
    if (d.aspect === b.aspect) pool.aspect.push(d);
    else if (d.aspect === 'basic') pool.basic.push(d);
  }
  const by = (a,b2)=> (a.cost||0)-(b2.cost||0) || a.name.localeCompare(b2.name);
  pool.aspect.sort(by); pool.basic.sort(by); pool.sig.sort(by);
  return pool;
}
function builderTotals(){
  const b = APP.builder;
  let sig = 0;
  for (const d of heroSignatureCards(b.heroKey)) sig += (d.copies || 1);
  let picked = 0;
  for (const c in b.counts) picked += b.counts[c];
  return { sig, picked, total: sig + picked };
}
function poolTile(d, locked){
  const b = APP.builder;
  const n = locked ? (d.copies||1) : (b.counts[d.code]||0);
  const lim = locked ? (d.copies||1) : (d.deckLimit || 3);
  return `<div class="pool-tile ${n>0?'has':''} ${locked?'lock':''}">
    ${cardArt(d.code, d.name, 74, (d.cost!==undefined?`<span class="badge cost">${d.cost}</span>`:'')+`<span class="badge res">${resIcons(d)}</span>`, true)}
    <div class="pool-ctl">
      ${locked ? `<span class="pool-n">×${n}</span>`
      : `<button onclick="UI.bDec('${d.code}')">−</button><span class="pool-n">${n}/${lim}</span><button onclick="UI.bInc('${d.code}')">＋</button>`}
    </div></div>`;
}
function builderPoolInner(){
  const b = APP.builder;
  const pool = builderPool();
  const t = builderTotals();
  const empty = !pool.sig.length && !pool.aspect.length && !pool.basic.length;
  if (empty) return `<div class="comic-panel"><div class="mini-note" style="text-align:center;padding:18px">🔍 "${esc(b.search)}"에 맞는 카드가 없어요.</div></div>`;
  const sec = (title, arr, locked) => arr.length
    ? `<div class="pool-sec">${title}</div><div class="pool-grid">${arr.map(d=>poolTile(d,locked)).join('')}</div>` : '';
  return `<div class="comic-panel">
      ${sec(`영웅 필수 세트 (${t.sig}장 자동 포함)`, pool.sig, true)}
      ${sec(`${esc(ASPECTS.find(a=>a[0]===b.aspect)[1])} 성향`, pool.aspect, false)}
      ${sec('기본', pool.basic, false)}</div>`;
}
function renderBuilder(){
  const b = APP.builder;
  if (b.search === undefined) b.search = '';
  const t = builderTotals();
  const ok = t.total >= 40 && t.total <= 50;
  const aspTabs = ASPECTS.map(([k,name]) =>
    `<button class="comic-btn sm ${b.aspect===k?'blue':'ghost'}" onclick="UI.bAspect('${k}')">${name}</button>`).join('');
  $('app').innerHTML = menuShell(`
    <div class="steprow"><span class="caption-box">덱빌더 — ${esc(HERO_META[b.heroKey].name)}</span>
      <span class="caption-box" id="builder-count" style="background:${ok?'var(--c-green)':'#fff'};color:${ok?'#fff':'var(--ink)'}">
        ${t.total} / 40~50장</span></div>
    <div class="tabrow">${aspTabs}</div>
    <div class="builder-search">
      <span class="bs-icon">🔍</span>
      <input id="builder-search-input" class="comic-select" type="text" inputmode="search"
        placeholder="카드 이름·효과·특성 검색…" value="${esc(b.search)}"
        oninput="UI.bSearch(this.value)">
      <button id="bs-clear" class="bs-clear" style="visibility:${b.search?'visible':'hidden'}"
        onclick="UI.bSearchClear()" title="지우기">✕</button>
    </div>
    <div id="builder-pool">${builderPoolInner()}</div>
    <div class="nav-row">
      <button class="comic-btn ghost" onclick="UI.go('title')">◀ 메인</button>
      <button class="comic-btn green" ${ok?'':'disabled'} onclick="UI.bSave()">덱 저장</button>
    </div>
    <div class="mini-note" style="text-align:center">카드의 🔍를 누르면 크게 볼 수 있어요 · '수동' 배지 카드도 덱에 넣을 수 있습니다 (룰 텍스트 보고 수동 처리)</div>`);
}

/* ═══ 덱 가져오기 ═══ */
function normalizeName(s){ return s.toLowerCase().replace(/[^a-z0-9가-힣]+/g,'-').replace(/^-|-$/g,''); }
function parseImport(text){
  const nameMap = {};
  for (const code in MC.CARDS){
    const d = MC.CARDS[code];
    if (d.side !== 'player') continue;
    nameMap[normalizeName(d.name)] = code;
    if (d.nameEn) nameMap[normalizeName(d.nameEn)] = code;
  }
  const counts = {}, unknown = [];
  for (let line of text.split(/\n/)){
    line = line.trim();
    if (!line || line.startsWith('#') || line.startsWith('//')) continue;
    let n = 1, name = line;
    let m = line.match(/^(\d+)\s*[xX×]?\s+(.+)$/);      // "3 tackle" / "3x tackle"
    if (m){ n = +m[1]; name = m[2]; }
    else if ((m = line.match(/^(.+?)\s*[xX×]\s*(\d+)$/))){ name = m[1]; n = +m[2]; } // "tackle x3"
    const key = normalizeName(name);
    const code = MC.CARDS[key] ? key : nameMap[key];
    if (!code){ unknown.push(name); continue; }
    counts[code] = (counts[code]||0) + n;
  }
  let heroKey = null;
  for (const c in counts){ const h = MC.CARDS[c].hero; if (h){ heroKey = h; break; } }
  return { counts, unknown, heroKey: heroKey || 'spiderman' };
}
/* marvelcdb 코드 정규화: a/b 접미사 제거 + 5자리 패딩 (이전 빌드 방식 승계) */
function normMcode(raw){
  let c = String(raw||'').replace(/[ab]$/i,'');
  while (c.length < 5) c = '0' + c;
  return c;
}
function importFromMarvelCDBData(data){
  const counts = {}, unknown = [];
  const slots = data.slots || {};
  for (const raw in slots){
    const mc = normMcode(raw);
    const slug = MCODE2SLUG[mc];
    const d = slug && MC.CARDS[slug];
    if (!d || d.side !== 'player'){ 
      // 신분 카드가 slots에 섞여 오는 경우가 있음 — 신분/미지 코드는 미인식으로
      if (!(d && (d.type==='hero'||d.type==='alter-ego'))) unknown.push(raw);
      continue;
    }
    counts[slug] = (counts[slug]||0) + slots[raw];
  }
  // 영웅: hero_code(접미사 포함) → 신분 코드 직접 대조
  let heroKey = null;
  const hc = data.hero_code || data.investigator_code || '';
  for (const k of HERO_KEYS){
    if (HERO_META[k].art === hc || HERO_META[k].art.replace(/[ab]$/,'') === normMcode(hc)){ heroKey = k; break; }
  }
  if (!heroKey){ // slots의 시그니처 카드에서 추정
    for (const c in counts){ const h = MC.CARDS[c].hero; if (h){ heroKey = h; break; } }
  }
  return { counts, unknown, heroKey: heroKey || 'spiderman', name: data.name || null };
}
function renderImport(){
  const r = APP.importResult;
  const tabN = APP.importTab === 'number';
  let resultHTML = '';
  if (r){
    const total = Object.values(r.counts).reduce((a,b)=>a+b,0);
    resultHTML = `<div class="comic-panel tilt-r popin">
      <b>인식 결과:</b> ${r.name?('"'+esc(r.name)+'" — '):''}${Object.keys(r.counts).length}종 ${total}장 ·
      영웅: <b>${esc(HERO_META[r.heroKey]?HERO_META[r.heroKey].name:r.heroKey)}</b>
      ${r.unknown.length?`<div class="mini-note" style="color:var(--c-red)">미인식 ${r.unknown.length}건: ${esc(r.unknown.slice(0,6).join(', '))}${r.unknown.length>6?'…':''}</div>`:''}
      <div class="btnrow"><button class="comic-btn green sm" onclick="UI.impSave()">이 덱 저장 ▶ 슬롯 선택</button></div></div>`;
  }
  $('app').innerHTML = menuShell(`
    <div class="steprow"><span class="caption-box">덱 가져오기</span></div>
    <div class="tabrow">
      <button class="comic-btn sm ${tabN?'blue':'ghost'}" onclick="UI.impTab('number')">MarvelCDB 번호</button>
      <button class="comic-btn sm ${!tabN?'blue':'ghost'}" onclick="UI.impTab('text')">텍스트 목록</button>
    </div>
    ${tabN ? `<div class="comic-panel">
      <div class="speech" style="margin-bottom:10px">marvelcdb.com 덱리스트 <b>번호</b>만 치면 끝! (URL 통째로 붙여도 OK)</div>
      <div class="zrow" style="align-items:center">
        <input id="imp-no" class="comic-select" style="flex:1;min-width:140px;font-size:16px"
          placeholder="예: 61398" value="${esc(APP.importNo)}">
        <button class="comic-btn blue" ${APP.importBusy?'disabled':''} onclick="UI.impFetch()">${APP.importBusy?'불러오는 중…':'가져오기!'}</button>
      </div>
      <div class="mini-note">공개(published) 덱리스트만 가능 · 인터넷 연결 필요</div>
    </div>`
    : `<div class="comic-panel">
      <div class="speech" style="margin-bottom:10px">한 줄에 한 장! <b>"3x 태클"</b>, <b>"tackle x3"</b>, <b>"swinging-web-kick"</b> 다 알아들어요.</div>
      <textarea id="imp-text" class="comic-textarea" rows="9" placeholder="3x 태클\n3 선제 타격\nswinging-web-kick x3\n...">${esc(APP.importText)}</textarea>
      <div class="btnrow"><button class="comic-btn blue sm" onclick="UI.impParse()">해석!</button></div>
    </div>`}
    ${resultHTML}
    <div class="nav-row"><button class="comic-btn ghost" onclick="UI.go('title')">◀ 메인</button><span></span></div>`);
}

function menuOverlays(){ return heroPickerHTML() + slotPickerHTML(); }
function renderMenu(){
  switch (APP.screen){
    case 'title': return renderTitle();
    case 'team': return renderTeam();
    case 'villain': return renderVillain();
    case 'builder': return renderBuilder();
    case 'import': return renderImport();
    default: return renderTitle();
  }
}
/* ═══ 게임 보드 (기존 유지 + 코믹 톤) ═══ */
function elValue(pl, el, target){
  try { const { icons } = MC.elementIcons(G, pl, el, target);
    return icons.physical+icons.mental+icons.energy+icons.wild; }
  catch(e){ return null; }
}
function iconStr(icons){
  let s=''; for (const k of ['physical','mental','energy','wild']) s += (RES_ICON[k]||'').repeat(icons[k]||0);
  return s || '—';
}
/* 카드가 원하는 키커 자원 집합 반환 (effects의 cond:paidWith). 지불 시 추가 효과 유발.
   예: 광자 폭발 → {energy}. 없으면 빈 Set. */
function kickerResources(cardDef){
  const s = new Set();
  const effs = (cardDef && cardDef.effects) || [];
  for (const e of effs){
    if (e.cond && e.cond.type === 'paidWith' && e.cond.resource) s.add(e.cond.resource);
  }
  return s;
}
/* 결제 후보 카드가 "특별"한지 판정 (불타는 테두리 대상):
   ① 자원 생성 카드(resourceGenerator) ② 지금 카드의 키커 자원을 인쇄한 카드 */
function isHotPayCard(cand, kickerSet){
  if (cand.gen) return true;                       // 자원 생성 카드
  if (cand.inst && kickerSet.size){
    const r = MC.cardDef(cand.inst.defCode).resources || {};
    for (const k of kickerSet) if (r[k] || r.wild) return true;  // 키커 자원 or 와일드
  }
  return false;
}
function payCandidates(pl, target){
  const out = [];
  for (const c of pl.hand){
    if (c.uid === pay.cardUid) continue;
    out.push({ el:{kind:'hand',uid:c.uid}, inst:c });
  }
  const fdef = MC.cardDef(pl.form==='hero' ? pl.heroCode : pl.aeCode);
  if (fdef && fdef.resourceAbility){
    out.push({ el:{kind:'ability',id:fdef.resourceAbility}, ability:MC.RESOURCE_ABILITIES[fdef.resourceAbility] });
  }
  // 자원 생성 카드 (웹 슈터 등): 조건(폼/소진/카운터) 충족 시 후보로 노출
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
    for (const c of arr){
      const rg = MC.cardDef(c.defCode).resourceGenerator;
      if (!rg) continue;
      const usable = (!rg.form || pl.form === rg.form) && (!rg.exhaust || !c.exhausted) &&
                     (!rg.counter || (c.counters||0) >= rg.counter);
      out.push({ el:{kind:'card',uid:c.uid}, gen:c, rg, usable });
    }
  return out;
}
function autoSelect(pl, target, cost){
  const cands = payCandidates(pl, target)
    .filter(c => c.el.kind !== 'card')  // 자원 생성 카드는 자동 선택 제외(카운터 절약 — 수동만)
    .map(c => ({ ...c, v: elValue(pl, c.el, target) }))
    .filter(c => c.v !== null && c.v > 0);
  if (cost <= 0) return [];
  const MAXS = cost + 4;
  const best = new Array(MAXS+1).fill(null);
  best[0] = { count:0, picks:[] };
  for (const c of cands){
    for (let sSum = MAXS; sSum >= 0; sSum--){
      if (!best[sSum]) continue;
      const ns = Math.min(MAXS, sSum + c.v);
      const cand = { count: best[sSum].count+1, picks: best[sSum].picks.concat([c.el]) };
      if (!best[ns] || cand.count < best[ns].count) best[ns] = cand;
    }
  }
  for (let sSum = cost; sSum <= MAXS; sSum++) if (best[sSum]) return best[sSum].picks;
  return null;
}
function openPay(playerUid, cardUid, fromDiscard){ pay = { player: playerUid, cardUid, elements: [], fromDiscard: !!fromDiscard }; render(); }
function payPopupHTML(){
  if (!pay) return '';
  const pl = G.players.find(p=>p.uid===pay.player);
  // 공격 후 반응 자원 지불 팝업 (Jarnbjorn 등): 특정 타입 자원 N개 지불 → 반응 발동.
  if (pay.aarReaction){
    const need = pay.payCost.type, count = pay.payCost.count || 1;
    const selKeys = new Set(pay.elements.map(el => el.kind+':'+(el.uid||el.id)));
    let paid = 0, tiles = '';
    for (const c of pl.hand){
      const icons = MC.resourceIconsOf(c);
      const val = (icons[need]||0) + (icons.wild||0);
      if (val <= 0) continue;
      const key = 'hand:'+c.uid;
      const on = selKeys.has(key);
      if (on) paid += val;
      tiles += `<div class="pay-tile ${on?'on':''}" onclick="UI.payToggle('${key}')">
        ${cardArt(c.defCode, c.name, 64)}
        <div class="pay-v">${iconStr(MC.resourceIconsOf(c))} <span>= ${val}</span></div></div>`;
    }
    const okPay = paid >= count;
    return `<div class="overlay"><div class="overlay-card paypop" onclick="event.stopPropagation()">
      <div class="zrow"><div style="flex:1">
        <b>${esc(pay.aarName || '공격 후 반응')}</b>
        <div class="statline">${MC.T(need)} 자원 <b>${count}</b> 필요 · 지불 <b style="color:${okPay?'var(--green)':'var(--red)'}">${paid}</b></div>
      </div></div>
      <div class="pay-grid">${tiles || '<div class="note">'+MC.T(need)+' 자원이 손에 없습니다</div>'}</div>
      <div class="btnrow">
        <button class="btn primary" ${okPay?'':'disabled'} onclick="UI.payConfirm()">발동</button>
        <button class="btn" onclick="UI.payCancel()">취소</button>
      </div></div></div>`;
  }
  // 능력 자원 지불 팝업 (초인법 사무소 등): 특정 타입 자원 N개 지불
  if (pay.abilityPay){
    const card = [...pl.playArea.supports, ...pl.playArea.upgrades, ...pl.playArea.allies].find(c=>c.uid===pay.cardUid);
    if (!card){ pay = null; return ''; }
    const need = pay.payCost.type, count = pay.payCost.count || 1;
    const selKeys = new Set(pay.elements.map(el => el.kind+':'+(el.uid||el.id)));
    let paid = 0, tiles = '';
    for (const c of pl.hand){
      const icons = MC.resourceIconsOf(c);
      const val = (icons[need]||0) + (icons.wild||0);
      if (val <= 0) continue;
      const key = 'hand:'+c.uid;
      const on = selKeys.has(key);
      if (on) paid += val;
      tiles += `<div class="pay-tile ${on?'on':''}" onclick="UI.payToggle('${key}')">
        ${cardArt(c.defCode, c.name, 64)}
        <div class="pay-v">${iconStr(MC.resourceIconsOf(c))} <span>= ${val}</span></div></div>`;
    }
    const okPay = paid >= count;
    return `<div class="overlay"><div class="overlay-card paypop" onclick="event.stopPropagation()">
      <div class="zrow"><div style="flex:1">
        <b>${esc(card.name)}</b> 능력 사용
        <div class="statline">${MC.T(need)} 자원 <b>${count}</b> 필요 · 지불 <b style="color:${okPay?'var(--green)':'var(--red)'}">${paid}</b></div>
      </div></div>
      <div class="pay-grid">${tiles || '<div class="note">'+MC.T(need)+' 자원이 손에 없습니다</div>'}</div>
      <div class="btnrow">
        <button class="btn primary" ${okPay?'':'disabled'} onclick="UI.payConfirm()">사용</button>
        <button class="btn" onclick="UI.payCancel()">취소</button>
      </div></div></div>`;
  }
  // 카운터 충전 팝업 (에너지 채널 등): 플레이 영역 카드, cost 없이 에너지 자원만 선택
  if (pay.counterCharge){
    const chargeCard = [...pl.playArea.upgrades, ...pl.playArea.supports].find(c=>c.uid===pay.cardUid);
    if (!chargeCard){ pay = null; return ''; }
    const cdef = MC.cardDef(chargeCard.defCode);
    const need = cdef.counterAbility.charge.resource;
    const selKeys = new Set(pay.elements.map(el => el.kind+':'+(el.uid||el.id)));
    // 에너지 아이콘을 가진 손패 카드만 후보
    let gained = 0, tiles = '';
    for (const c of pl.hand){
      if (c.type === 'resource' && false) continue;
      const icons = MC.resourceIconsOf(c);
      const val = (icons[need]||0) + (icons.wild||0);
      if (val <= 0) continue;
      const key = 'hand:'+c.uid;
      const on = selKeys.has(key);
      if (on) gained += val;
      tiles += `<div class="pay-tile hot ${on?'on':''}" onclick="UI.payToggle('${key}')">
        ${cardArt(c.defCode, c.name, 64)}
        <div class="pay-v">${iconStr(MC.resourceIconsOf(c))} <span>= +${val}</span></div></div>`;
    }
    return `<div class="overlay"><div class="overlay-card paypop" onclick="event.stopPropagation()">
        <div class="zrow"><div style="flex:1">
          <b>${esc(chargeCard.name)}</b> 충전
          <div class="statline">${MC.T(need)} 자원을 카운터로 · 현재 <b>${chargeCard.counters||0}</b> + <b style="color:var(--green)">${gained}</b> = <b>${(chargeCard.counters||0)+gained}</b></div>
        </div></div>
        <div class="pay-grid">${tiles || '<div class="note">충전할 '+MC.T(need)+' 자원이 손에 없습니다</div>'}</div>
        <div class="btnrow">
          <button class="btn primary" ${gained>0?'':'disabled'} onclick="UI.payConfirm()">충전 (+${gained})</button>
          <button class="btn" onclick="UI.payCancel()">취소</button>
        </div></div></div>`;
  }
  const card = pl && (pay.fromDiscard ? pl.discard : pl.hand).find(c=>c.uid===pay.cardUid);
  if (!card){ pay = null; return ''; }
  const cost = MC.playCostOf(G, pl, card);   // 할인(리빙 레전드/nextCardDiscount) 반영
  let sum = 0, err = null;
  try { sum = MC.computePayment(G, pl, pay.elements, card).sum; }
  catch(e){ err = e.message; }
  const ok = !err && sum >= cost;
  const excess = ok ? sum - cost : 0;
  const cands = payCandidates(pl, card);
  const kickerSet = kickerResources(MC.cardDef(card.defCode));
  const selKeys = new Set(pay.elements.map(el => el.kind+':'+(el.uid||el.id)));
  let tiles = '';
  for (const c of cands){
    const key = c.el.kind+':'+(c.el.uid||c.el.id);
    const on = selKeys.has(key);
    const v = elValue(pl, c.el, card);
    const disabled = v === null;
    const hot = isHotPayCard(c, kickerSet) ? ' hot' : '';
    if (c.inst){
      const def = MC.cardDef(c.inst.defCode);
      const dbl = def && def.doubleForAspect && card.aspect === def.doubleForAspect;
      tiles += `<div class="pay-tile${hot} ${on?'on':''}" onclick="UI.payToggle('${key}')">
        ${cardArt(c.inst.defCode, c.inst.name, 64)}
        <div class="pay-v">${iconStr(MC.resourceIconsOf(c.inst))}${dbl?' <b class="x2">×2</b>':''} <span>= ${v}</span></div></div>`;
    } else if (c.gen){
      // 자원 생성 카드 (웹 슈터 등)
      const cn = c.gen.counters !== undefined ? ` · 🕸${c.gen.counters}` : '';
      // 동적 자원(페퍼 포츠): 버림 더미 맨 위 카드의 자원을 표시 + 그 카드 미리보기
      const fromTop = c.rg.fromDiscardTop;
      const topCard = fromTop ? pl.discard[pl.discard.length - 1] : null;
      const genIcons = fromTop ? (topCard ? MC.resourceIconsOf(topCard) : {}) : c.rg.icons;
      const genV = fromTop ? (topCard ? MC.paymentTotal([topCard]).sum : 0) : v;
      tiles += `<div class="pay-tile gen${hot} ${on?'on':''} ${c.usable && (!fromTop || topCard)?'':'off'}"
          onclick="${c.usable && (!fromTop || topCard)?`UI.payToggle('${key}')`:''}">
        ${cardArt(c.gen.defCode, c.gen.name, 64)}
        <div class="pay-v">${iconStr(genIcons)} <span>= ${c.usable?(fromTop&&!topCard?'없음':genV):'불가'}</span></div>
        ${fromTop
          ? (topCard
              ? `<div class="pay-frombin" title="버림 더미 맨 위 — 이 카드의 자원을 생성">
                   <img src="${imgUrl(topCard.defCode)}" alt="" onerror="this.style.display='none'">
                   <span>♻ ${esc(topCard.name)}</span></div>`
              : `<div class="note">버림 더미 비어있음</div>`)
          : `<div class="note">소진${cn}</div>`}</div>`;
    } else {
      tiles += `<div class="pay-tile ability ${on?'on':''} ${disabled?'off':''}"
          onclick="${disabled?'':`UI.payToggle('${key}')`}">
        <div class="pay-ab">🧬 ${esc(c.ability.name)}</div>
        <div class="pay-v">${iconStr(c.ability.icons)} <span>= ${disabled?'사용 불가':'1'}</span></div>
        <div class="note">${c.ability.oncePerRound?'라운드 1회':''} · ${MC.T(c.ability.form||'')} </div></div>`;
    }
  }
  return `<div class="overlay"><div class="overlay-card paypop" onclick="event.stopPropagation()">
    <div class="zrow">
      ${cardArt(card.defCode, card.name, 92)}
      <div style="flex:1">
        <b>${esc(card.name)}</b>
        <div class="statline">비용 <b>${cost}</b> — 선택 <b style="color:${ok?'var(--green)':'var(--red)'}">${err?'?':sum}</b>
          ${excess>0?`<span class="note"> (초과 ${excess} 소멸)</span>`:''}</div>
        ${err?`<div class="note" style="color:var(--red)">${esc(err)}</div>`:''}
      </div>
    </div>
    <div class="pay-grid">${tiles}</div>
    <div class="btnrow">
      <button class="btn gold" onclick="UI.payAuto()">⚙ 자동 선택</button>
      <button class="btn primary" ${ok?'':'disabled'} onclick="UI.payConfirm()">플레이 (${cost})</button>
      <button class="btn" onclick="UI.payCancel()">취소</button>
    </div></div></div>`;
}

function tokens(st, extra){
  let h = '';
  if (st){
    if (st.stunned)  h += `<span class="token token-stunned">기절×${st.stunned}</span>`;
    if (st.confused) h += `<span class="token token-confused">혼란×${st.confused}</span>`;
    if (st.tough)    h += `<span class="token token-tough">강인×${st.tough}</span>`;
  }
  return h + (extra||'');
}
function comicBar(label, val, max, color, opt){
  opt = opt || {};
  const pct = Math.max(0, Math.min(100, max>0 ? val/max*100 : 0));
  const low = opt.lowIsBad !== false && pct <= 30;
  const bonusBadge = (opt.bonus && opt.bonus > 0)
    ? `<span class="cbar-bonus" title="추가 체력 +${opt.bonus} (부착물·업그레이드 보너스)">+${opt.bonus}</span>` : '';
  return `<div class="cbar ${low?'low':''} ${opt.mini?'mini':''}">
    <span class="cbar-tag" style="background:${color}">${esc(label)}</span>
    <div class="cbar-track">
      <div class="cbar-fill" ${opt.key?`data-barkey="${opt.key}"`:''} style="width:${pct}%;--cb:${color}"></div>
      <span class="cbar-num latin">${val}<i>/${max}</i></span>
      ${bonusBadge}
    </div></div>`;
}
function hpBar(hp, maxHp, color, key, bonus){ return comicBar('HP', hp, maxHp, color, { key, bonus }); }

/* ── 바 부드러운 전환 (FLIP): 렌더 전 값 스냅샷 → 렌더 후 이전값에서 새값으로 이어 애니 ── */
function barSnapshot(){
  const m = {};
  if (!G) return m;
  if (G.villain) m['hp:'+G.villain.uid] = G.villain.maxHp>0 ? G.villain.hp/G.villain.maxHp*100 : 0;
  if (G.mainScheme) m['threat:main'] = G.mainScheme.maxThreat>0 ? G.mainScheme.threat/G.mainScheme.maxThreat*100 : 0;
  for (const ss of (G.sideSchemes || [])){
    const peak = Math.max(ss.peakThreat || ss.threat, ss.threat, 1);
    m['threat:'+ss.uid] = ss.threat / peak * 100;
  }
  for (const pl of G.players){
    m['hp:'+pl.uid] = pl.maxHp>0 ? pl.hp/pl.maxHp*100 : 0;
    for (const mn of pl.engagedMinions) m['hp:'+mn.uid] = mn.maxHp>0 ? mn.hp/mn.maxHp*100 : 0;
    for (const a of pl.playArea.allies) m['hp:'+a.uid] = a.maxHp>0 ? a.hp/a.maxHp*100 : 0;
  }
  return m;
}
function animateBars(prev){
  document.querySelectorAll('[data-barkey]').forEach(el => {
    const key = el.getAttribute('data-barkey');
    if (!(key in prev)) return;
    const target = el.style.width;
    const from = Math.max(0, Math.min(100, prev[key])) + '%';
    if (from === target) return;
    el.style.transition = 'none';
    el.style.width = from;
    void el.offsetWidth;                 // 리플로우 강제
    el.style.transition = '';            // CSS 전환 복원 (.6s)
    el.style.width = target;
  });
}
function heroLabel(pl){ return pl.uid + ' ' + MC.heroFace(G, pl).name; }

/* 스킴 효과 아이콘 칩: 가속/위기/위험 */
function schemeIconChips(inst){
  const def = MC.cardDef(inst.defCode) || {};
  let h = '';
  // 진짜 가속 = 전장의 사이드 스킴 가속 아이콘 합. (메인 스킴 accelIcons는 escalation 오매핑이라 제외)
  let sideAccel = 0;
  for (const s of (G.sideSchemes || [])){
    const sd = MC.cardDef(s.defCode);
    if (sd && sd.accelIcons) sideAccel += (sd.accelIcons === true ? 1 : sd.accelIcons);
  }
  // 메인 스킴: 다음 빌런 페이즈 위협 상승 예상치 (기본 인원수 + 가속 아이콘/토큰)
  if (inst.isMain){
    const baseGain = G.players.length;
    const accelGain = sideAccel + (G.acceleration||0);
    h += `<span class="token token-threatgain" title="빌런 페이즈마다 메인 스킴에 놓이는 위협">📈 다음 +${baseGain+accelGain} <small>(기본 ${baseGain}${accelGain>0?' + 가속 '+accelGain:''})</small></span>`;
  }
  // 가속 아이콘 배지: 사이드 스킴에만 표시 (메인 스킴 accelIcons는 오매핑이므로 배지 없음)
  if (!inst.isMain && def.accelIcons){
    const a = def.accelIcons === true ? 1 : def.accelIcons;
    h += `<span class="token token-accel" title="가속 아이콘: 이 스킴이 있는 동안 빌런 페이즈마다 메인 스킴 위협 +${a}">⚡ 가속×${a}</span>`;
  }
  if (G.acceleration && inst.isMain) h += `<span class="token token-accel" title="가속 토큰: 인카운터덱 소진 때마다 누적">⚡ 토큰×${G.acceleration}</span>`;
  if (def.crisis) h += `<span class="token token-crisis" title="위기: 이 스킴이 있는 동안 메인 스킴 위협 제거 불가">✛ 위기</span>`;
  if (def.hazard) h += `<span class="token token-hazard" title="위험: 빌런 페이즈에 조우 카드 +1장">☣ 위험</span>`;
  // 보관 카드(노상 강도 01166 등): 이 스킴에 강탈되어 뒷면 보관된 카드 수. 처치 시 소유자에게 반환.
  if (!inst.isMain && inst.storedCards && inst.storedCards.length){
    const names = inst.storedCards.map(c => (c._storedOwner || '?')).join(', ');
    h += `<span class="token token-stored" title="이 스킴에 강탈·보관된 카드 (처치 시 소유자에게 반환) — 소유: ${esc(names)}">🃏 보관×${inst.storedCards.length}</span>`;
  }
  return h;
}
/* 동적 결과창: 승/패 공용. 행들이 순차 등장 + 숫자 카운트업. */
function resultsHTML(){
  if (!G || !G.over || !resultsShown) return '';
  const win = G.over.result === 'win';
  const vdef = G.villain ? MC.cardDef(G.villain.defCode) : null;
  const heroRows = G.players.map(pl => {
    const face = MC.cardDef(pl.heroCode);
    return `<div class="results-row"><span class="rk">${esc(face?face.name:pl.uid)} 남은 HP</span>
      <span class="rv"><span data-countup="${pl.hp}">0</span>/${pl.maxHp}</span></div>`;
  }).join('');
  return `<div class="results-overlay">
    <div class="results-box ${win?'win':'lose'}">
      <div class="results-title">${win?'VICTORY!':'DEFEAT...'}</div>
      <div class="results-sub">${esc(G.over.reason)} — ${win?'임무 완수!':'다음 기회에...'}</div>
      ${(!win && G.over.villainQuote) ? `<div class="results-villainquote">
        <span class="rvq-name">${esc(G.over.villainName || (G.villain?G.villain.name:'빌런'))}</span>
        <span class="rvq-text">“${esc(G.over.villainQuote)}”</span></div>` : ''}
      <div class="results-row"><span class="rk">빌런</span>
        <span class="rv gold">${esc(G.villain?G.villain.name:'?')}${vdef&&vdef.stage?' (단계 '+vdef.stage+')':''}</span></div>
      <div class="results-row"><span class="rk">진행 라운드</span>
        <span class="rv"><span data-countup="${G.over.round}">0</span> R</span></div>
      ${heroRows}
      <div class="results-row"><span class="rk">전투 기록</span>
        <span class="rv"><span data-countup="${G.gameLog.length}">0</span>줄</span></div>
      <div class="results-btns">
        <button class="btn primary big" onclick="UI.toMenuFromResults()">메인 메뉴</button>
        <button class="btn" onclick="UI.closeResults()">필드 보기</button>
      </div>
    </div></div>`;
}
/* 숫자 카운트업: [data-countup] 요소를 0 → 목표값으로 (결과창 등장 시 1회) */
function runCountups(){
  document.querySelectorAll('[data-countup]').forEach(el => {
    const target = parseInt(el.getAttribute('data-countup')) || 0;
    const dur = 850, t0 = performance.now();
    const step = (t) => {
      const p = Math.min(1, (t - t0) / dur);
      el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));   // easeOutCubic
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
}

/* 공개 확인 큐: 한 장씩 모달로 보여주고 "계속"으로 진행. 급증 연쇄도 순서대로. */
function pumpRevealQueue(){
  // 부스트 공개/덱 공개 모달이 떠 있는 동안엔 대기 — ★효과가 만든 공개가 부스트 공개보다 먼저 뜨는 것 방지.
  if (revealShowing || boostRevealShowing || fxRevealShowing || !revealQueue.length){ return; }
  revealShowing = revealQueue.shift();
  render();
}
/* 카드 텍스트 공용 파서 — textKo에서 표시용 본문/플레이버를 추출.
   돋보기(info)와 조우 공개 모달(revealModalHTML)이 동일 규칙을 쓰도록 통일.
   제거: ※각주 · 타입/코스트/자원 메타줄 · 스탯줄 · 시작위협 메타줄.
   분리: 따옴표 인용(플레이버) → flavorText. 영어 def.flavor는 몰입 위해 억제(한국어만). */
function parseCardText(def){
  const flavorLines = [], bodyLines = [];
  for (const raw of (def.textKo || '').split('\n')){
    const t = raw.trim();
    if (!t){ bodyLines.push(''); continue; }
    if (t.startsWith('※')) break;   // ※ 주석(개발/구현 노트)은 항상 텍스트 끝 → 이후 전부 제외 (하위 항목 포함)
    // 견고화: ※ 없이 새어나온 개발/구현 노트 라인 차단 (구현 키워드 포함 시).
    if (/(window\.|_currentBoostCard|applyMinion|applyBoostStar|encounterDiscard|putIntoPlay|함수의|분기로|시뮬 처리|공식:|원본:)/.test(t)) continue;
    if (/^(동료|이벤트|지원|업그레이드|자원|사이드 ?스킴|보조 ?모의|하수인|부착|메인 ?스킴|주요 ?스킴|배신|영웅|알터에고)[.\s(]/.test(t)
        && /(Cost|비용|유니크|시작 위협|Side Scheme|Minion|Attachment|부스트|▲)/.test(t)) continue;
    if (/^ATK\s*\d+\s*\/\s*THW/.test(t)) continue;
    if (/^시작 위협\s*[:：]/.test(t)) continue;
    const fl = t.match(/^[*_]?["\u201C](.+?)["\u201D][*_]?$/);
    if (fl){ flavorLines.push(fl[1]); continue; }
    bodyLines.push(raw);
  }
  const effectText = bodyLines.join('\n')
    .replace(/\*\*(.+?)\*\*/g,'$1').replace(/(?<!\w)_(.+?)_(?!\w)/g,'$1').replace(/\*(.+?)\*/g,'$1')
    .replace(/\n{3,}/g,'\n\n').trim();
  const flavorText = flavorLines.length ? flavorLines.join(' ')
    : (def.flavor && /[가-힣]/.test(def.flavor) ? def.flavor : '');   // 영어 flavor 억제
  return { effectText, flavorText };
}

/* 조우 카드 공개 모달(revealModalHTML) — 시네마틱 개편.
   타입별 테마(배반=보라·번개 / 하수인=적·검 / 사이드 스킴=청록·지도 / 부착=주황·사슬)로
   배경·테두리·배지 컬러가 바뀌고, 카드는 조우덱 뒷면→앞면 3D 플립으로 등장.
   하수인은 ATK/SCH/HP 스탯 미리보기 + 등장 대사 말풍선, 사이드 스킴은 시작 위협 표시.
   하단 진행 도트(현재+남은)로 몇 장 남았는지 한눈에. */
const RVX_THEME = {
  treachery:  { label:'배반',        icon:'⚡', cls:'rvx-tre' },
  minion:     { label:'하수인',      icon:'⚔', cls:'rvx-min' },
  sideScheme: { label:'사이드 스킴', icon:'🗺', cls:'rvx-sch' },
  attachment: { label:'부착',        icon:'🔗', cls:'rvx-att' },
  obligation: { label:'의무',        icon:'📜', cls:'rvx-obl' },
  environment:{ label:'환경',        icon:'🌐', cls:'rvx-env' },
};
function revealModalHTML(){
  if (!revealShowing) return '';
  const { r, logs } = revealShowing;
  const def = MC.cardDef(r.defCode) || {};
  // DB 타입(언더스코어)을 UI 테마 키(카멜케이스)로 정규화 — side_scheme→sideScheme, main_scheme→mainScheme
  const rtype = ({ side_scheme:'sideScheme', main_scheme:'mainScheme' })[r.type] || r.type;
  const t = RVX_THEME[rtype] || { label: rtype || '조우', icon:'👁', cls:'rvx-enc' };
  const parsed = parseCardText(def);
  const txt = parsed.effectText ? esc(parsed.effectText).replace(/\n/g, '<br>') : '';
  // 공개 대사 말풍선: 하수인=enter, 배신·사이드스킴=reveal. quoteKey 우선, 없으면 defCode.
  //   (배신 중 효과 연출로 대사를 내는 카드는 reveal kind가 없어 여기선 생략 — 이중 출력 방지)
  const qKey = def.quoteKey || r.defCode;
  const qKind = rtype === 'minion' ? 'enter' : 'reveal';
  const enterQuote = MC.hasQuote(qKey, qKind) ? MC.randomQuote(qKey, qKind) : null;
  // 타입별 핵심 수치 미리보기: 하수인=스탯 / 사이드 스킴=시작 위협
  let statsHtml = '';
  if (rtype === 'minion'){
    statsHtml = `<div class="rvx-stats">
      <span class="rvx-stat s-atk">⚔ ATK ${def.attack ?? '—'}</span>
      <span class="rvx-stat s-sch">🗺 SCH ${def.scheme ?? '—'}</span>
      <span class="rvx-stat s-hp">❤ HP ${def.hp ?? '—'}</span></div>`;
  } else if (rtype === 'sideScheme'){
    const n = (def.baseThreatPerPlayer || 0) * (G ? G.players.length : 1) + (def.baseThreat || 0);
    if (n) statsHtml = `<div class="rvx-stats"><span class="rvx-stat s-thr">☠ 시작 위협 ${n}</span></div>`;
  }
  // 진행 도트: 현재(●) + 남은 카드(○, 최대 7 + 초과 표기)
  const remaining = revealQueue.length;
  const dots = `<span class="on"></span>${'<span></span>'.repeat(Math.min(remaining, 7))}${remaining>7?`<i>+${remaining-7}</i>`:''}`;
  return `<div class="reveal-modal ${t.cls}">
    <div class="rvx-head"><span class="rvx-headicon">${t.icon}</span>조우 카드 공개 — ${t.label}</div>
    <div class="rvx-box">
      <div class="rvx-flip">
        <div class="rvx-back"><span>👁</span></div>
        <div class="rvx-front">${cardArt(r.defCode, r.name, 208)}</div>
      </div>
      <div class="rvx-body">
        <div class="rvx-name">${esc(r.name)}</div>
        ${statsHtml}
        ${enterQuote ? `<div class="rvx-quote">${esc(enterQuote)}</div>` : ''}
        ${parsed.flavorText ? `<div class="rvx-flavor">${esc(parsed.flavorText)}</div>` : ''}
        ${txt ? `<div class="rvx-text">${txt}</div>` : ''}
        <div class="rvx-btns">
          <button class="btn primary big" onclick="UI.revealContinue()">계속 ▶${remaining?` (남은 ${remaining})`:''}</button>
          ${remaining?`<button class="btn" onclick="UI.revealSkipAll()">전부 넘기기 ⏩</button>`:''}
        </div>
      </div>
    </div>
    <div class="rvx-dots">${dots}</div>
  </div>`;
}

/* 덱 공개 시퀀스(리펄서 블래스트 등): 공개된 덱 카드를 부채꼴로 펼치고
   에너지 카드는 발광 + 피해 카운트업. 세련된 "무엇을 뽑았나" 표현. */
function fxRevealHTML(){
  if (!fxRevealShowing) return '';
  const fx = fxRevealShowing;
  const n = fx.cards.length;
  // 조우덱 확인(peek — 팔콘 등): 확인한 카드 부채꼴 표시, 매치(배신) 강조 + 위협 제거량.
  if (fx.kind === 'peek'){
    const cards = fx.cards.map((c, i) => {
      const rot = (i - (n-1)/2) * 9, dx = (i - (n-1)/2) * 84;
      return `<div class="fxr-card ${c.isMatch?'energy':''}" style="--rot:${rot}deg;--dx:${dx}px;--i:${i}">
        ${cardArt(c.defCode, c.name, 116)}
        ${c.isMatch?`<span class="fxr-etag">✔ ${esc(fx.matchType==='treachery'?'배신':fx.matchType)}</span>`:''}
      </div>`;
    }).join('');
    return `<div class="fx-reveal-modal">
      <div class="fxr-head">${esc(fx.title)} — 조우덱 상위 ${n}장 확인</div>
      <div class="fxr-fan">${cards}</div>
      <div class="fxr-calc">
        <span class="fxr-formula">${esc(fx.matchType==='treachery'?'배신':fx.matchType)} ${fx.matchCount}장 × ${fx.perMatch}</span>
        <span class="fxr-total">위협 제거 <b data-countup="${fx.threatRemoved}">0</b></span>
      </div>
      <button class="btn primary big" onclick="UI.fxRevealDone()">확인 ▶</button>
    </div>`;
  }
  const cards = fx.cards.map((c, i) => {
    const rot = (i - (n-1)/2) * 9;        // 부채꼴 각도
    const dx = (i - (n-1)/2) * 84;        // 가로 간격
    const isE = c.energy > 0;
    return `<div class="fxr-card ${isE?'energy':''}" style="--rot:${rot}deg;--dx:${dx}px;--i:${i}">
      ${cardArt(c.defCode, c.name, 116)}
      ${isE?`<span class="fxr-etag">⚡×${c.energy}</span>`:''}
    </div>`;
  }).join('');
  return `<div class="fx-reveal-modal">
    <div class="fxr-head">리펄서 블래스트 — 덱 ${n}장 방출</div>
    <div class="fxr-fan">${cards}</div>
    <div class="fxr-calc">
      <span class="fxr-formula">기본 ${fx.base} <b>+</b> ⚡${fx.energy} × ${fx.perEnergy}</span>
      <span class="fxr-total">피해 <b data-countup="${fx.total}">0</b></span>
    </div>
    <button class="btn primary big" onclick="UI.fxRevealDone()">확인 ▶</button>
  </div>`;
}

/* 부스트 공개 시퀀스(boostRevealHTML): 빌런/하수인 활성화의 부스트 카드를
   뒷면→앞면 순차 플립으로 보여줌. 각 카드에 ①기본/강제난입 배지 ②부스트 아이콘(▲) 개수
   ③부스트★ 발동 옵션(전장 배치/효과 이름)을 명시. 하단에 피해/위협 합산 공식.
   확인 버튼으로 닫음 (노출시간은 사용자가 제어 + 플립 스태거로 순차 가독). */
const BOOST_STAR_LABELS = {   // 부스트★ 효과 → 한국어 라벨 (미등록은 effect id 표기)
  toughEnemy: '빌런이 강인함 획득',
  discardBooster: '손패 무작위 1장 버림',
  exhaustAllAllies: '통제하는 모든 동료 소진',
  damageEachHeroBoost: '각 히어로에게 1 피해',
};
function boostRevealHTML(){
  if (!boostRevealShowing) return '';
  const fx = boostRevealShowing;
  const isAtk = fx.kind === 'attack';
  const total = (fx.base || 0) + (fx.boostTotal || 0);
  const n = fx.events.length;
  const cards = fx.events.map((ev, i) => {
    const icons = ev.boost > 0 ? '▲'.repeat(Math.min(ev.boost, 5)) : '—';
    let starHtml = '';
    if (ev.star){
      const label = ev.star.kind === 'minion'
        ? '전장에 교전 상태로 등장!'
        : (BOOST_STAR_LABELS[ev.star.effect] || ev.star.effect);
      starHtml = `<div class="bxr-star">★ ${esc(label)}</div>`;
    }
    return `<div class="bxr-card ${ev.extra?'extra':''}" style="--i:${i}">
      <div class="bxr-badge">${ev.extra ? '⚡ 강제 난입 — 추가 부스트' : '부스트 카드'}</div>
      <div class="bxr-flip">
        <div class="bxr-back"><span>🂠</span></div>
        <div class="bxr-front">${cardArt(ev.defCode, ev.name, 168)}</div>
      </div>
      <div class="bxr-name">${esc(ev.name)}</div>
      <div class="bxr-icons ${ev.boost>0?'':'zero'}">${icons}<b>+${ev.boost}</b></div>
      ${starHtml}
    </div>`;
  }).join('');
  const formula = isAtk
    ? `기본 피해 ${fx.base} <b>+</b> 부스트 ▲${fx.boostTotal} <b>=</b> <span class="bxr-total">총 피해 ${total}</span>`
    : `기본 위협 ${fx.base} <b>+</b> 부스트 ▲${fx.boostTotal} <b>=</b> <span class="bxr-total">위협 +${total}</span>`;
  return `<div class="boost-reveal-modal">
    <div class="bxr-head">${esc(fx.attackerName || '적')}의 ${isAtk ? '공격' : '암약(스킴)'} — 부스트 공개${n>1?` ×${n}`:''}</div>
    <div class="bxr-row">${cards}</div>
    <div class="bxr-calc">${formula}</div>
    <button class="btn primary big" onclick="UI.boostRevealDone()">확인 ▶</button>
  </div>`;
}

/* ── 빌런 페이즈 전용 사이드 패널 (넷러너 런 트래커 스타일) ──
   우측 빈 공간에 고정: ① 단계 타임라인(완료✓/진행중/대기) ② 공개 카드 컴팩트
   목록(썸네일+이름+타입+한글 텍스트 2줄, 클릭=확대). 본문을 밀지 않는다. */
let vpanelOpen = true;
function vpanelHTML(){
  if (!G) return '';
  const log = G.revealLog || [];
  const inVillain = G.phase === 'villain';
  if (!vpanelOpen)
    return `<button id="vpanel-tab" onclick="UI.toggleVPanel()" title="빌런 페이즈 패널 열기">👁 ${log.length}</button>`;
  // 단계 타임라인
  const stepDefs = [
    { icon:'⚡', label:'위협 배치' },
    { icon:'⚔', label:'적 활성화' },
    { icon:'🃏', label:'조우 배분' },
    { icon:'👁', label:'조우 공개' },
    { icon:'🔄', label:'라운드 정리' },
  ];
  const opIdx = { threat:0, activations:1, act:1, dealEnc:2, reveal:3, resumeReveal:3, endRound:4 };
  let cur = -1;
  if (inVillain && G.vq && G.vq.length){ const v = opIdx[G.vq[0].op]; cur = v === undefined ? 0 : v; }
  else if (inVillain) cur = 4;
  const steps = stepDefs.map((sd, i) => {
    const st = !inVillain ? 'idle' : (i < cur ? 'done' : i === cur ? 'active' : 'todo');
    return `<div class="vp-step ${st}"><span class="vp-ic">${sd.icon}</span>${sd.label}${st==='done' ? ' <b class="vp-ck">✓</b>' : ''}</div>`;
  }).join('');
  // 공개 카드 목록
  const typeInfo = {
    treachery:{label:'배반',cls:'rv-t-tre'}, minion:{label:'하수인',cls:'rv-t-min'},
    sideScheme:{label:'사이드 스킴',cls:'rv-t-sch'}, attachment:{label:'부착',cls:'rv-t-att'},
    boost:{label:'부스트',cls:'rv-t-boo'},
  };
  const rows = log.length ? log.map(r => {
    const def = MC.cardDef(r.defCode) || {};
    const ti = typeInfo[r.type] || { label:r.type, cls:'' };
    const txt = (def.textKo || '').split('\n').filter(Boolean).slice(0, 3).join(' · ');
    return `<div class="vp-row ${r.type==='boost'?'vp-boost':''}">
      <img src="${imgUrl(r.defCode)}" alt="" onerror="this.style.display='none'"
        onclick="event.stopPropagation();UI.info('${r.defCode}')" title="클릭하면 크게 보기">
      <div class="vp-body">
        <div class="vp-name">${esc(r.name)} <span class="rvp-type ${ti.cls}">${ti.label}${r.type==='boost' ? ' +'+(r.boost||0) : ''}</span></div>
        ${txt ? `<div class="vp-text">${txt}</div>` : ''}
      </div></div>`;
  }).join('') : '<div class="vp-empty">아직 공개된 카드 없음</div>';
  return `<div id="vpanel">
    <div class="vp-head" onclick="UI.toggleVPanel()" title="접기">
      <b>${inVillain ? '⚔ 빌런 페이즈' : '👁 라운드 기록'}</b><span class="vp-min">−</span>
    </div>
    <div class="vp-steps">${steps}</div>
    <div class="vp-sec">공개 카드 <b>${log.length}</b></div>
    <div class="vp-list">${rows}</div>
  </div>`;
}
function todoBadgeChip(code){
  const def = MC.cardDef(code);
  return (def && def.todoFx) ? `<span class="token token-todo" title="카드 능력 수동 처리 — 🔍로 룰 확인">✋ 수동</span>` : '';
}

/* 실험(test) 카운터 배지 — 졸라의 실험 진행도. 3개 도달 시 하수인 소환 임계값. */
function testChip(ms){
  const t = (ms && ms.testCounters) || 0;
  if (t <= 0) return '';
  const danger = t >= 3;
  const bg = danger ? 'var(--c-red)' : '#16a34a';
  return `<span class="token test-chip${danger?' test-danger':''}" title="실험 카운터: 아르님 졸라의 실험 진행도. 빌런 페이즈마다 1씩 쌓이며, 3개 이상이면 조우덱에서 하수인이 소환되고 카운터 3개가 제거됩니다." style="background:${bg};color:#fff;font-weight:900;font-size:12px;padding:2px 9px;display:inline-flex;align-items:center;gap:4px">🧪 실험 ${t}${danger?' ⚠':''}</span>`;
}

/* 지연(delay) 카운터 배지 — 어보밍맨 추격 진행도. 5+면 위험(환경·배반 효과 2배 임계값). */
function delayChip(ms){
  const d = (ms && ms.delayCounters) || 0;
  if (d <= 0) return '';
  const danger = d >= 5;
  const bg = danger ? 'var(--c-red)' : '#3b82f6';
  return `<span class="token delay-chip${danger?' delay-danger':''}" title="지연 카운터: 어보밍맨의 추격 진행도. 5개 이상이면 환경·배반 효과가 2배가 됩니다.&#10;누구도 지나갈 수 없다 — 빌런 페이즈마다 1씩 쌓입니다." style="background:${bg};color:#fff;font-weight:900;font-size:12px;padding:2px 9px;display:inline-flex;align-items:center;gap:4px">⏱ 지연 ${d}${danger?' ⚠':''}</span>`;
}

/* 어보밍맨 환경 원소 정보 — 특성별 아이콘/색/이름. 다른 환경은 null. */
function envElementInfo(code){
  const map = {
    '04080': { icon:'🌲', color:'#16a34a', name:'수목', trait:'wood' },
    '04081': { icon:'❄️', color:'#38bdf8', name:'냉기', trait:'ice' },
    '04082': { icon:'🪨', color:'#a8a29e', name:'암석', trait:'stone' },
    '04083': { icon:'⚙️', color:'#71717a', name:'강철', trait:'metal' },
  };
  return map[code] || null;
}

/* 부착 배지: 부착물이 있으면 카드 우상단에 📎N 표시 (여러 장 대응) */
function attachBadge(inst){
  const n = (inst.attachments || []).length;
  return n ? `<span class="badge atb" title="부착 ${n}장">📎${n}</span>` : '';
}

/* 활성 능력 카드 조회: 플레이 영역 + 빌런 조우 부착물 (상아 뿔 등 히어로 행동) */
function findAbilityCardUI(pl, cardUid){
  if (!pl) return null;
  let c = [...pl.playArea.supports, ...pl.playArea.upgrades, ...pl.playArea.allies].find(x=>x.uid===cardUid);
  if (!c && G.villain) c = (G.villain.attachments||[]).find(x=>x.uid===cardUid);
  // 교전 하수인의 히어로 행동 (에디슨의 거대 로봇 무효화 등) — 모든 플레이어
  if (!c) for (const p of G.players){ const m = (p.engagedMinions||[]).find(x=>x.uid===cardUid); if (m){ c = m; break; } }
  return c;
}

/* 부착물 효과 요약 배지 추출 — def의 여러 효과 필드를 사람이 읽는 짧은 라벨로. */
function attachEffectSummary(adef){
  const parts = [];
  if (adef.attack) parts.push('공격 +' + adef.attack);
  if (adef.atkBonus) parts.push('공격 +' + adef.atkBonus);
  if (adef.hpBonus) parts.push('체력 +' + adef.hpBonus);
  if (adef.attachStats){
    const s = adef.attachStats;
    if (s.retaliate) parts.push('반격 ' + s.retaliate);
    if (s.attack) parts.push('공격 +' + s.attack);
    if (s.hp || s.maxHp) parts.push('체력 +' + (s.hp || s.maxHp));
    if (s.defense) parts.push('방어 +' + s.defense);
  }
  if (adef.statMod){
    const m = adef.statMod;
    if (m.attack) parts.push('공격 +' + m.attack);
    if (m.thwart) parts.push('저지 +' + m.thwart);
    if (m.defense) parts.push('방어 +' + m.defense);
    if (m.stat && m.amount) parts.push(m.stat + ' +' + m.amount);
  }
  if (adef.damageReduction) parts.push('피해 -' + adef.damageReduction);
  if (adef.grantsRetaliate) parts.push('반격 ' + adef.grantsRetaliate);
  return parts;
}

/* 부착물 목록 칩: 카드 아래에 부착물 이름 + 효과 요약 + 상세/제거 버튼. 여러 장이면 모두 나열.
   조우 부착물에 히어로 행동(activatedAbility)이 있으면 히어로별 제거 버튼 표시 (상아 뿔 등). */
function attachChips(inst){
  const atts = inst.attachments || [];
  if (!atts.length) return '';
  return `<div class="attach-strip">${atts.map(a=>{
    const adef = MC.cardDef(a.defCode) || {};
    const player = adef.side === 'player';
    const fx = attachEffectSummary(adef);
    const fxBadges = fx.map(f=>`<span class="attach-fx">${esc(f)}</span>`).join('');
    let btns = '';
    if (!player && adef.activatedAbility){
      const ab = adef.activatedAbility;
      const eligible = G.players.filter(p => !p.eliminated && (!ab.form || p.form === ab.form));
      const payHint = ab.payCost ? `${MC.T(ab.payCost.type)}×${ab.payCost.count||1}` : '';
      btns = eligible.map(p =>
        `<button class="btn tiny attach-remove" onclick="event.stopPropagation();UI.useCardAbility('${p.uid}','${a.uid}')"
          title="이 부착물 제거${payHint?' — '+payHint+' 지출':''}${G.players.length>1?' ('+p.uid+')':''}">🗑 제거${payHint?' '+payHint:''}</button>`).join('');
    }
    return `<div class="attach-chip2 ${player?'att-player':'att-enc'}">
      <div class="attach-chip2-main" onclick="event.stopPropagation();UI.info('${a.defCode}')" title="부착 카드 — 탭하여 상세 보기">
        <span class="attach-chip2-ico">📎</span>
        <span class="attach-chip2-name">${esc(a.name)}</span>
        ${fxBadges}
        <span class="attach-chip2-zoom">🔍</span>
      </div>
      ${btns}
    </div>`;
  }).join('')}</div>`;
}

/* 파일(덱/버림 더미) — 플레이매트 슬롯 스타일 */
function pileHTML(label, count, opt){
  opt = opt || {};
  const inner = opt.topCode
    ? `<img src="${imgUrl(opt.topCode)}" loading="lazy">`
    : (count > 0 ? `<div class="pile-back${opt.backClass?' '+opt.backClass:''}"><span>${opt.backGlyph||'MC'}</span></div>` : '');
  return `<div class="pile ${count===0?'empty':''}${opt.className?' '+opt.className:''}" ${opt.onclick?`onclick="${opt.onclick}"`:''}
      title="${esc(label)}${opt.onclick?' — 탭하여 열람':''}">
    ${inner}
    <span class="pile-count">${count}</span>
    <span class="mat-label">${esc(label)}</span></div>`;
}
/* 빈 카드 슬롯 (플레이매트 아웃라인) */
function slotPH(label, w){
  return `<div class="slotph" style="width:${w||76}px;height:${Math.round((w||76)*1.4)}px">
    <span>${esc(label)}</span></div>`;
}
let pileView = null; // {title, cards:[inst...]}
function pileViewHTML(){
  if (!pileView) return '';
  const cards = pileView.cards;
  return `<div class="overlay" onclick="UI.pileClose()">
    <div class="overlay-card" style="max-width:620px" onclick="event.stopPropagation()">
      <div class="zone-title"><span>${esc(pileView.title)} (${cards.length})</span></div>
      ${cards.length ? `<div class="pile-grid">${cards.slice().reverse().map(c => {
        // 자기 버린더미 + playableFromDiscard 카드(록조 등) → 플레이 버튼. 플레이어 턴·히어로/알터에고 무관(자기 턴이면).
        const pl2 = pileView.playerUid ? G.players.find(p=>p.uid===pileView.playerUid) : null;
        const cd = MC.cardDef(c.defCode);
        const canPlay = pl2 && cd && cd.playableFromDiscard && !G.over && !G.pending &&
                        G.phase === 'player' && !pl2.eliminated;
        return `<div class="mini-card" onclick="UI.info('${c.defCode}')">${cardArt(c.defCode, c.name, 76)}` +
          (canPlay ? `<button class="btn tiny gold" style="margin-top:4px;width:100%" onclick="event.stopPropagation();UI.playFromDiscard('${pl2.uid}','${c.uid}')">플레이</button>` : '') +
          `</div>`;
      }).join('')}</div>`
      : '<div class="note">비어 있음</div>'}
      <button class="btn" onclick="UI.pileClose()">닫기</button></div></div>`;
}

function render(){
  if (!G){ renderMenu(); return; }
  const v = G.villain, ms = G.mainScheme;
  const vdef = MC.cardDef(v.defCode);
  // 캠페인 코믹스 자동 트리거 — 캠페인 모드에서만, 게임 시작 시 인트로 / 빌런 격파(승리) 시 격파 코믹스.
  if (G.scenarioKey && G.campaign){
    const _sc = MC.SCENARIOS[G.scenarioKey];
    if (_sc){
      if (!comicIntroShown && !G.over && (G.round || 1) <= 1 && (_sc.comicIntro || []).length){
        comicIntroShown = true;
        setTimeout(() => UI.showComic(G.scenarioKey, 'intro'), 500);
      }
      if (!comicDefeatShown && G.over && G.over.result === 'win' && (_sc.comicDefeat || []).length){
        comicDefeatShown = true;
        setTimeout(() => UI.showComic(G.scenarioKey, 'defeat'), 900);
      }
    }
  }
  let h = '<div class="layout"><div class="board-inner">';

  h += `<div class="topbar" title="빌드 ${UI_VER}">
    <span class="latin" style="font-size:16px;color:var(--c-yellow)">ROUND ${G.round}</span>
    <span class="buildver" title="빌드 버전">${UI_VER}</span>
    <span>${G.phase==='player'?'플레이어 페이즈':'빌런 페이즈'} · 가속 ${G.acceleration}</span>
    ${!G.over ? `<button class="btn" style="background:#7c3aed;border-color:#a78bfa" onclick="UI.debugWin()" title="테스트용: 빌런 즉시 격파">⏭ 테스트승리</button>` : ''}
    <button class="btn" onclick="UI.reset()">메인으로</button></div>`;

  if (G.over)
    h += `<div class="gameover ${G.over.result}">${G.over.result==='win'?'⚔ VICTORY!':'☠ DEFEAT'} — ${esc(G.over.reason)} (R${G.over.round})
      <button class="btn gold" style="margin-left:10px" onclick="UI.openResults()">결과 보기</button>${
        (G.over.result==='win' && G.campaign) ? `<button class="btn" style="margin-left:8px;background:linear-gradient(135deg,#22c55e,#16a34a);border-color:#7fffd4;color:#04120a;font-weight:700" onclick="UI.nextScenario()">다음 시나리오 ⏭</button>` : ''
      }</div>`;

  /* ═ 빌런 매트: [조우덱] [빌런] [메인 스킴] [조우 버림] ═ */
  const tpct = Math.min(100, ms.threat/ms.maxThreat*100);
  const enemyPick = G.pending && G.pending.kind === 'chooseEnemy';
  const vTargeting = enemyPick ? (G.pending.enemyUids||[]).includes(v.uid)
                    : (sel.mode==='attack'||sel.mode==='target'||sel.mode==='counterFire'||sel.mode==='abilityTarget');
  h += `<div class="mat villain-zone" onclick="UI.zoneTap('villain')">
    <div class="mat-row">
      ${pileHTML('조우덱', G.encounterDeck.length)}
      ${(G.experimentalWeaponsDeck && G.experimentalWeaponsDeck.length !== undefined) ? pileHTML('⚙ 실험무기', G.experimentalWeaponsDeck.length, { className:'pile-weapon', backClass:'weap-back', backGlyph:'⚙', onclick:"UI.pileOpen('weapon')" }) : ''}
      <div class="mat-slot ${vTargeting?'targetable':''}" ${vTargeting?`onclick="event.stopPropagation();UI.pickTarget('${v.uid}')"`:''}>
        ${cardArt(v.defCode, v.name, 104,
          edgeStats([{label:'ATK',val:v.attack||0,cls:'atk'},{label:'SCH',val:v.scheme||0,cls:'sch'}]) + edgeStatus(v.status) + toughBarrier(v.status),
          true, v.uid)}
        <span class="mat-label">빌런 ${vdef.stage}단계${G.difficulty==='expert'?' · <b style="color:var(--c-red)">전문가</b>':''}</span>
      </div>
      <div class="mat-main" style="flex:1;min-width:200px">
        <div class="vname"><b>${esc(v.name)}</b><span>ATK ${v.attack} · SCH ${v.scheme}</span></div>
        ${hpBar(v.hp, v.maxHp, 'var(--c-red)', 'hp:'+v.uid, v._hpBuff)}
        <div class="chips">${tokens(v.status)}</div>
        <div class="scheme-strip${sel && sel.mode === 'schemePick' ? ' scheme-pickable' : ''}" data-vuid="${ms.uid}" ${sel && sel.mode === 'schemePick' ? `onclick="UI.schemeTap('main')"` : ''}>
          <div class="s-head">
            <span>메인 스킴 — ${esc(ms.name)} <span class="stagechip">${esc(MC.cardDef(ms.defCode).stage||'1B')}</span></span>
            <span class="s-btns">
              ${MC.cardDef('01097a')?`<button class="btn tiny" onclick="event.stopPropagation();UI.info('${ms.defCode.replace(/b$/,'a')}')">1A 셋업</button>`:''}
              <span class="token mag-token" onclick="event.stopPropagation();UI.info('${ms.defCode}')">🔍</span>
            </span></div>
          ${comicBar('위협', ms.threat, ms.maxThreat, 'var(--gold)', {lowIsBad:false, key:'threat:main', bonus:ms._targetBuff})}
          <div class="chips" style="margin-top:6px">${schemeIconChips(ms)}${todoBadgeChip(ms.defCode)}${delayChip(ms)}${testChip(ms)}</div>
          ${(ms.attachments||[]).length ? attachChips(ms) : ''}
        </div>

        ${(v.attachments||[]).length ? attachChips(v) : ''}
      </div>
      ${pileHTML('조우 버림', G.encounterDiscard.length, { onclick:"UI.pileOpen('enc')" })}
    </div>
    ${G.sideSchemes.length ? `<div class="mat-row side-row">${G.sideSchemes.map(ss=>{
      const pick = sel && sel.mode === 'schemePick';
      const peak = Math.max(ss.peakThreat || ss.threat, ss.threat, 1);
      return `
      <div class="mat-slot${pick?' scheme-pickable':''}" ${pick?`onclick="UI.schemeTap('${ss.uid}')"`:''}>
        ${cardArt(ss.defCode, ss.name, 86, edgeStats([{label:'위협',val:ss.threat,cls:'sch'}]), true, ss.uid)}
        ${comicBar('위협', ss.threat, peak, 'var(--gold)', {lowIsBad:false, mini:true, key:'threat:'+ss.uid})}
        <div class="chips">${schemeIconChips(ss)}${todoBadgeChip(ss.defCode)}</div>
        <span class="mat-label">사이드 스킴${pick?' — 탭하여 저지':''}</span></div>`;}).join('')}</div>` : ''}
    ${(G.environments||[]).length ? `<div class="mat-row env-row">${G.environments.map(env=>{
      const hasCtr = env.counters !== undefined;
      const ctrLabel = ({'criminal-enterprise':'악명','state-of-madness':'광기'})[env.defCode] || '카운터';
      const elem = envElementInfo(env.defCode);
      const absorbed = elem && G.villain && (MC.villainTraitsOf(G)||[]).includes(elem.trait);
      return `
      <div class="mat-slot"${elem?` style="border-radius:10px;box-shadow:0 0 0 2px ${elem.color},0 0 18px ${elem.color}55"`:''}>
        ${cardArt(env.defCode, env.name, 86, hasCtr ? edgeStats([{label:ctrLabel,val:env.counters,cls:'sch'}]) : '', true, env.uid)}
        ${elem ? `<div class="chips" style="margin-top:4px;justify-content:center;flex-direction:column;gap:3px">
            <span class="token" style="background:${elem.color};color:#fff;font-weight:900;font-size:12px;padding:2px 10px">${elem.icon} ${elem.name} 지형</span>
            ${absorbed?`<span class="token" title="어보밍맨이 이 지형의 특성을 흡수해 능력을 얻고 있습니다" style="background:#111;color:${elem.color};border:1px solid ${elem.color};font-size:10px;font-weight:800;padding:1px 8px">🟢 어보밍맨 흡수 중</span>`:''}
          </div>` : ''}
        ${hasCtr ? `<div class="chips" style="margin-top:4px;justify-content:center"><span class="token" style="background:var(--green);color:#0a0a0a;font-weight:900;font-size:15px;padding:2px 10px">${ctrLabel} ${env.counters}</span></div>` : ''}
        <span class="mat-label">🌐 환경 — ${esc(env.name)}</span></div>`;}).join('')}</div>` : ''}
    ${sel && sel.mode === 'schemePick' ? `<div class="zone pending-zone">
      <div class="zone-title"><span>🎯 저지 대상 선택</span><span>메인 스킴 또는 사이드 스킴을 탭</span></div>
      <div class="btnrow"><button class="btn danger" onclick="UI.cancelSchemePick()">취소</button></div></div>` : ''}
  </div>`;

  if (G.pending && G.pending.kind === 'revealInterrupt'){
    const p = G.pending;
    const owner = G.players.find(x=>x.uid===p.player);
    const revCard = G.revealing;
    const opts = MC.collectRevealInterrupts(G, revCard || { type: p.encounterType });
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>⚡ 인터럽트 — ${esc(revCard?revCard.name:'조우 카드')} 공개</span><span>"공개 시" 효과 취소 가능</span></div>
      <div class="btnrow">
        ${opts.map(o=>{
          const pl2 = G.players.find(x=>x.uid===o.player);
          const c = pl2.hand.find(h=>h.uid===o.cardUid) ||
                    pl2.playArea.allies.find(h=>h.uid===o.cardUid) ||
                    pl2.playArea.supports.find(h=>h.uid===o.cardUid);
          if (!c) return '';
          const payHint = o.needsPay ? ` (${MC.T(o.needsPay.type)} ${o.needsPay.count})` : '';
          return `<button class="btn" style="background:var(--c-blue)" onclick="UI.useInterrupt('${o.player}','${o.cardUid}')">${esc(c.name)} 사용${payHint}</button>`;
        }).join('')}
        <button class="btn danger" onclick="UI.passInterrupt()">패스 (효과 발동)</button>
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'defense'){
    const p = G.pending;
    const pl = G.players.find(x=>x.uid===p.player);
    const atk = MC.findByUid(G, p.attackerUid);
    // 손패의 방어 인터럽트 이벤트(Backflip=전체 방지 / Preemptive Strike=부스트 취소 등)
    const defEvents = pl.hand.filter(c => c.type==='event' &&
      (MC.cardDef(c.defCode).traits||[]).includes('defense') &&
      ((MC.cardDef(c.defCode).effects||[]).some(e=>e.fx==='preventAll') || MC.cardDef(c.defCode).defenseInterruptEvent));
    // 플레이 영역의 방어 인터럽트 카드(우주 비행 등) — 부분 피해 방지
    const defInterrupts = [];
    for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
      for (const c of arr){ const di = MC.cardDef(c.defCode).defenseInterrupt; if (di) defInterrupts.push({ c, di }); }
    const boostChip = p.boostCard
      ? `<span class="boost-facedown" title="부스트 카드 — 방어 선언 후 공개됩니다">🂠 부스트 ?</span>` : '';
    const prevChip = p.prevented ? `<span class="prev-chip">방지 예약 −${p.prevented}</span>` : '';
    const forceAlly = !!p.mustDefendWithAlly && pl.playArea.allies.some(a=>!a.exhausted);
    const forceChip = forceAlly ? `<span class="prev-chip" style="background:var(--c-red,#c33)">동료 방어 강제</span>` : '';
    // 공격개시 인터럽트 동료(노바 등): 자원 지불 → 공격자 피해 (반복 가능, 소진 안 함)
    const atkIntAllies = (pl.playArea.allies || []).filter(a => MC.cardDef(a.defCode).attackInitiateInterrupt);
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>⚠ 방어 선언 — ${heroLabel(pl)}</span>
        <span>${esc(atk?atk.name:'?')}의 공격 · 피해 ${p.amount}${p.boostCard?' <b class="bq">+ ?</b>':''} ${boostChip}${prevChip}${forceChip}</span></div>
      <div class="btnrow">
        <button class="btn primary" ${(pl.exhausted||forceAlly)?'disabled':''} onclick="UI.def('identity')">신분 방어 (DEF ${MC.statOf(G,pl,'defense')||0})</button>
        ${pl.playArea.allies.filter(a=>!a.exhausted).map(a=>
          `<button class="btn gold" onclick="UI.def('${a.uid}')">${esc(a.name)} 방어 (HP ${a.hp})</button>`).join('')}
        ${atkIntAllies.map(a=>{ const ai=MC.cardDef(a.defCode).attackInitiateInterrupt;
          return `<button class="btn" style="background:var(--c-orange,#e8820c)" onclick="UI.startAllyAttackInterrupt('${pl.uid}','${a.uid}')">${esc(a.name)}: ⚡→${ai.damage}피해</button>`;}).join('')}
        ${defEvents.map(c=>{ const dd=MC.cardDef(c.defCode);
          const lbl = dd.defenseInterruptEvent ? '부스트 취소 + 빌런 피해' : '모든 피해 방지';
          return `<button class="btn" style="background:var(--c-blue)" onclick="UI.playDefenseEvent('${pl.uid}','${c.uid}')">${esc(c.name)} (${lbl})</button>`;}).join('')}
        ${defInterrupts.map(({c,di})=>{
          const label = di.counter
            ? `반영 ${c.counters||0} · 피해 ${di.prevent} 방지 + 적 ${di.damageEnemy||0}피해`
            : `피해 ${di.prevent} 방지`;
          const disabled = (di.counter && (c.counters||0) < di.counter) || (p.usedInterrupts||[]).includes(c.uid);
          return `<button class="btn" style="background:var(--c-purple,#7a5cff)" ${disabled?'disabled':''} onclick="UI.useDefenseInterrupt('${pl.uid}','${c.uid}')">${esc(c.name)} (${label})</button>`;}).join('')}
        <button class="btn danger" ${forceAlly?'disabled':''} onclick="UI.def('none')">방어 안 함 (피해 ${p.amount}${p.boostCard?'+?':''})</button>
      </div></div>`;
  }

  if (novaPay){
    const owner = G.players.find(x=>x.uid===novaPay.player);
    const ally = owner && (owner.playArea.allies||[]).find(a=>a.uid===novaPay.cardUid);
    const ai = ally && MC.cardDef(ally.defCode).attackInitiateInterrupt;
    // ⚡ 지불 후보: 손패 에너지/와일드 자원 + 에너지/와일드 생성 카드
    const chosen = novaPay.elements || [];
    const handCands = (owner.hand||[]).filter(c=>{ const r=MC.resourceIconsOf(c); return (r.energy||0)+(r.wild||0)>0; });
    const cards = handCands.map(c=>{
      const on = chosen.some(e=>e.kind==='hand'&&e.uid===c.uid);
      return `<div class="cardpick-item ${on?'picked':''}" onclick="UI.toggleNovaPay('${c.uid}')" title="자원으로 지불">
        ${cardArt(c.defCode, MC.cardDef(c.defCode)?.name||c.defCode, 100)}
        <div class="cardpick-name">${esc(MC.cardDef(c.defCode)?.name||c.defCode)}</div></div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>⚡ ${esc(ally?ally.name:'노바')} — ${ai?ai.damage:2}피해</span><span>에너지 자원 1개를 선택해 지불하세요</span></div>
      <div class="cardpick-row">${cards || '<span>에너지 자원 없음</span>'}</div>
      <div class="btnrow">
        <button class="btn primary" onclick="UI.confirmNovaPay()">발동 (⚡→${ai?ai.damage:2}피해)</button>
        <button class="btn" onclick="UI.cancelNovaPay()">취소</button>
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'revealChoice'){
    const p = G.pending;
    const self = MC.findByUid(G, p.selfUid);
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>💣 ${esc(self ? self.name : '조우 카드')} — 선택</span>
        <span>${esc(p.prompt || '효과를 선택하세요')}</span></div>
      <div class="btnrow">
        ${(p.options||[]).map(o=>
          `<button class="btn primary" onclick="UI.revealChoice('${o.key}')">${esc(o.label)}</button>`).join('')}
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'morphResponse'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const ev = owner ? (owner.discard || []).find(c => c.uid === p.eventUid) : null;
    const evName = ev ? (MC.cardDef(ev.defCode)?.name || ev.defCode) : '이벤트';
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>🤸 모포제네틱스 — ${esc(evName)}</span>
        <span>${esc(p.prompt || '미즈마블을 소진하고 이벤트를 손으로 되돌릴까?')}</span></div>
      <div class="btnrow">
        <button class="btn primary" onclick="UI.resolveMorphResponse(true)">소진 → 손으로 반환</button>
        <button class="btn" onclick="UI.resolveMorphResponse(false)">패스</button>
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'eventBoostChoice'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const evName = p.eventCard ? (MC.cardDef(p.eventCard.defCode)?.name || p.eventCard.defCode) : '이벤트';
    const chosen = p.chosen || [];
    const cards = (p.boosterUids || []).map(uid => {
      const up = (owner.playArea.upgrades || []).find(x => x.uid === uid); if (!up) return '';
      const d = MC.cardDef(up.defCode) || {};
      const eb = d.eventBoost || {};
      const on = chosen.includes(uid);
      return `<div class="cardpick-item ${on?'picked':''}" onclick="UI.toggleEventBoost('${uid}')" title="탭하면 강화 선택/해제">
        ${cardArt(up.defCode, d.name || up.defCode, 120)}
        <div class="cardpick-name">${esc(d.name || up.defCode)} (+${eb.amount||0} ${eb.stat==='threat'?'위협제거':'피해'})</div></div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>💪 ${esc(evName)} 강화</span>
        <span>${esc(p.prompt || '강화할 카드를 탭하세요')}</span></div>
      <div class="cardpick-row">${cards}</div>
      <div class="btnrow">
        <button class="btn primary" onclick="UI.confirmEventBoost()">확정 (${chosen.length}장 강화)</button>
        <button class="btn" onclick="UI.skipEventBoost()">건너뛰기</button>
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'allyDefeatInterrupt'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const enemies = [];
    if (G.villain) enemies.push(G.villain);
    for (const m of (G.engagedMinions || [])) if (m.engagedWith === owner.uid || !m.engagedWith) enemies.push(m);
    const enemyBtns = enemies.map(e =>
      `<button class="btn ${p.targetUid===e.uid?'primary':''}" onclick="UI.pickAllyDefeatTarget('${e.uid}')">${esc(MC.cardDef(e.defCode)?.name||e.defCode)} (HP ${e.hp})</button>`
    ).join('');
    const chosen = p.chosenPay || [];
    const resCards = (owner.hand || []).filter(c => {
      const r = MC.resourceIconsOf(c); return (r.physical+r.mental+r.energy+r.wild) > 0;
    }).map(c => {
      const r = MC.resourceIconsOf(c);
      const label = ['physical','mental','energy','wild'].filter(t=>r[t]).map(t=>({physical:'💪',mental:'🧠',energy:'⚡',wild:'🌟'}[t])+(r[t]>1?r[t]:'')).join('');
      const on = chosen.includes(c.uid);
      return `<div class="cardpick-item ${on?'picked':''}" onclick="UI.toggleAllyDefeatPay('${c.uid}')" title="자원으로 지불 선택/해제">
        ${cardArt(c.defCode, MC.cardDef(c.defCode)?.name||c.defCode, 110)}
        <div class="cardpick-name">${esc(MC.cardDef(c.defCode)?.name||c.defCode)} ${label}</div></div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>🗡️ 레드 대거 — 처치 인터럽트</span><span>${esc(p.prompt||'')}</span></div>
      <div class="btnrow" style="flex-wrap:wrap">${enemyBtns || '<span>대상 적 없음</span>'}</div>
      <div class="cardpick-row">${resCards || '<span>지불할 자원이 없습니다</span>'}</div>
      <div class="btnrow">
        <button class="btn primary" onclick="UI.confirmAllyDefeatInterrupt()">지불 → 피해 + 손 반환</button>
        <button class="btn" onclick="UI.declineAllyDefeatInterrupt()">포기 (버림)</button>
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'rapidResponse'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const ally = (owner.discard || []).find(c => c.uid === p.allyUid);
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>⚡ Rapid Response</span><span>${esc(p.prompt||'')}</span></div>
      <div class="btnrow">
        <button class="btn primary" onclick="UI.resolveRapidResponse(true)">되살림 (${esc(ally?ally.name:'동료')} 전장으로 + 1피해)</button>
        <button class="btn" onclick="UI.resolveRapidResponse(false)">사용 안 함</button>
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'brunoStorePick'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const cards = (owner.hand || []).map(c =>
      `<div class="cardpick-item" onclick="UI.resolveBrunoStore('${c.uid}')" title="엎어서 보관">
        ${cardArt(c.defCode, MC.cardDef(c.defCode)?.name||c.defCode, 110)}
        <div class="cardpick-name">${esc(MC.cardDef(c.defCode)?.name||c.defCode)}</div></div>`).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>📦 브루노 — 보관</span><span>${esc(p.prompt||'')}</span></div>
      <div class="cardpick-row">${cards || '<span>손패 없음</span>'}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'brunoRetrievePick'){
    const p = G.pending;
    const bruno = MC.findByUid(G, p.brunoUid);
    const stored = (bruno && bruno.stored) || [];
    const chosen = p.chosen || [];
    const cards = stored.map(c => {
      const on = chosen.includes(c.uid);
      return `<div class="cardpick-item ${on?'picked':''}" onclick="UI.toggleBrunoRetrieve('${c.uid}')" title="회수 선택/해제">
        ${cardArt(c.defCode, MC.cardDef(c.defCode)?.name||c.defCode, 110)}
        <div class="cardpick-name">${esc(MC.cardDef(c.defCode)?.name||c.defCode)}</div></div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>📦 브루노 — 회수 (최대 ${p.max||3})</span><span>${esc(p.prompt||'')}</span></div>
      <div class="cardpick-row">${cards || '<span>보관 카드 없음</span>'}</div>
      <div class="btnrow"><button class="btn primary" onclick="UI.confirmBrunoRetrieve()">회수 (${chosen.length}장)</button></div></div>`;
  }

  if (G.pending && G.pending.kind === 'chooseEnemy'){
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>🎯 대상 선택</span>
        <span>${esc(G.pending.prompt || '대상 적을 선택하세요')} — 강조된 적을 탭하세요</span></div>
    </div>`;
  }

  if (G.pending && G.pending.kind === 'cardPick'){
    const p = G.pending;
    const need = p.keep - (p.chosen || []).length;
    const cards = (p._cards || []).map(c => {
      const picked = (p.chosen || []).includes(c.uid);
      const def = MC.cardDef(c.defCode) || {};
      return `<div class="cardpick-item ${picked?'picked':''}" onclick="UI.resolveCardPick('${c.uid}')" title="탭하면 손에 넣기">
        ${cardArt(c.defCode, def.name || c.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || c.defCode)}</div>
        ${picked?'<div class="cardpick-badge">✓ 손에</div>':''}
      </div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>🔮 ${esc(p.prompt || '카드 선택')}</span>
        <span>손에 넣을 카드를 탭하세요 (남은 선택 ${need}장 · 나머지는 ${p.disposition==='bottom'?'덱 아래로':'버림'})</span></div>
      <div class="cardpick-row">${cards}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'handDiscardCost'){
    const p = G.pending;
    const need = p.count - (p.chosen || []).length;
    const owner = G.players.find(x => x.uid === p.player);
    const cards = ((owner && owner.hand) || []).map(c => {
      const def = MC.cardDef(c.defCode) || {};
      return `<div class="cardpick-item" onclick="UI.resolveHandDiscardCost('${c.uid}')" title="탭하면 버리기">
        ${cardArt(c.defCode, def.name || c.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || c.defCode)}</div>
      </div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>🗑️ ${esc(p.prompt || '카드 버리기')}</span>
        <span>버릴 카드를 탭하세요 (남은 ${need}장)</span></div>
      <div class="cardpick-row">${cards}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'discardChoose'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const cards = (owner.hand || []).map(c => {
      const def = MC.cardDef(c.defCode) || {};
      return `<div class="cardpick-item" onclick="UI.resolveDiscardChoose('${c.uid}')" title="탭하면 버림">
        ${cardArt(c.defCode, def.name || c.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || c.defCode)}</div></div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>🗑️ ${esc(p.prompt || '카드 버리기')}</span>
        <span>버릴 카드를 탭하세요 (${p.remaining}장 남음)</span></div>
      <div class="cardpick-row">${cards}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'resourceDiscardPick'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const cands = MC.resourceCandidates(owner, p.types);
    const cards = cands.map(c => {
      const def = MC.cardDef(c.defCode) || {};
      return `<div class="cardpick-item" onclick="UI.resolveResourceDiscardPick('${c.uid}')" title="탭하면 버림">
        ${cardArt(c.defCode, def.name || c.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || c.defCode)}</div></div>`;
    }).join('');
    const left = p.count - p.chosen;
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>🗑️ ${esc(p.prompt || '자원 버리기')}</span>
        <span>버릴 자원 카드를 탭하세요 (${left}장 남음 · 본인 선택)</span></div>
      <div class="cardpick-row">${cards}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'pickControlledDiscard'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const pool = [...(owner.playArea.upgrades || []), ...(owner.playArea.supports || [])];
    const cards = (p.cardUids || []).map(uid => {
      const c = pool.find(x => x.uid === uid); if (!c) return '';
      const def = MC.cardDef(c.defCode) || {};
      return `<div class="cardpick-item" onclick="UI.resolvePickControlledDiscard('${c.uid}')" title="탭하면 버림">
        ${cardArt(c.defCode, def.name || c.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || c.defCode)}</div></div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>🗑️ ${esc(p.prompt || '버릴 카드 선택')}</span>
        <span>버릴 장비를 직접 탭하세요 (본인 선택)</span></div>
      <div class="cardpick-row">${cards}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'attachCharacter'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    let items = '';
    if (p.heroTarget){
      const hd = MC.cardDef(owner.form === 'hero' ? owner.heroCode : owner.aeCode) || {};
      items += `<div class="cardpick-item" onclick="UI.resolveAttachCharacter('hero')" title="히어로에 부착">
        ${cardArt(owner.form === 'hero' ? owner.heroCode : owner.aeCode, hd.name || '히어로', 130)}
        <div class="cardpick-name">${esc(hd.name || '히어로')}</div></div>`;
    }
    items += (p.allyUids || []).map(uid => (owner.playArea.allies || []).find(a => a.uid === uid)).filter(Boolean).map(al => {
      const def = MC.cardDef(al.defCode) || {};
      return `<div class="cardpick-item" onclick="UI.resolveAttachCharacter('${al.uid}')" title="동료에 부착">
        ${cardArt(al.defCode, def.name || al.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || al.defCode)}</div></div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>🎖️ ${esc(p.prompt || '부착 대상 선택')}</span>
        <span>부착할 우호 캐릭터를 탭하세요</span></div>
      <div class="cardpick-row">${items}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'deployAlly'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const cards = (p.allyUids || []).map(uid => (owner.hand || []).find(c => c.uid === uid)).filter(Boolean).map(c => {
      const def = MC.cardDef(c.defCode) || {};
      return `<div class="cardpick-item" onclick="UI.resolveDeployAlly('${c.uid}')" title="탭하면 전장에 배치">
        ${cardArt(c.defCode, def.name || c.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || c.defCode)} <span style="opacity:.7">(${def.cost||0})</span></div>
      </div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>✈️ ${esc(p.prompt || '동료 배치 선택')}</span>
        <span>배치할 동료를 탭하세요 (무료 전개)</span></div>
      <div class="cardpick-row">${cards}</div></div>`;
  }

  if (G.pending && G.pending.kind === 'widowmaker'){
    const p = G.pending;
    const enemies = (p.enemyUids||[]).map(u=>MC.findByUid(G,u)).filter(Boolean);
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>🕷️ 와이도우메이커</span><span>${esc(p.prompt||'적 1명 선택')}</span></div>
      <div class="btnrow">
        ${enemies.map(e=>`<button class="btn" style="background:var(--c-red)" onclick="UI.pickWidowmaker('${e.uid}')">${esc(MC.nameOf(e))} <span class="latin">(${e.hp}HP)</span></button>`).join('')}
      </div></div>`;
  }
  if (G.pending && G.pending.kind === 'teamworkAlly'){
    const p = G.pending;
    const pl = G.players.find(x=>x.uid===p.player);
    const allies = (p.allyUids||[]).map(uid => (pl.playArea.allies||[]).find(a=>a.uid===uid)).filter(Boolean);
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>🤝 팀워크</span><span>${esc(p.prompt||'소진할 동료 선택')}</span></div>
      <div class="btnrow">
        ${allies.map(a=>`<button class="btn" style="background:var(--c-blue)" onclick="UI.pickTeamworkAlly('${a.uid}')">${esc(a.name)} <span class="latin">(ATK ${MC.allyStatOf(G,a,'attack')} / THW ${MC.allyStatOf(G,a,'thwart')})</span></button>`).join('')}
      </div></div>`;
  }
  if (G.pending && G.pending.kind === 'encounterScry'){
    const p = G.pending;
    const picked = new Set(p.chosen || []);
    const cards = (p._cards || []).map(c => {
      const def = MC.cardDef(c.defCode) || {};
      const sel = picked.has(c.uid);
      return `<div class="cardpick-item ${sel?'picked':''}" onclick="UI.toggleEncounterScry('${c.uid}')" title="탭하면 버림 선택">
        ${cardArt(c.defCode, def.name || c.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || c.defCode)}</div>
        ${sel?'<div class="cardpick-badge">✗ 버림</div>':''}
      </div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>👁️ ${esc(p.prompt || '조우덱 예지')}</span>
        <span>버릴 카드를 탭하세요 (${(p.chosen||[]).length}/${p.discard}) · 나머지는 상단에 되돌아갑니다</span></div>
      <div class="cardpick-row">${cards}</div>
      <div class="btnrow" style="margin-top:8px">
        <button class="btn primary" ${(p.chosen||[]).length===p.discard?'':'disabled'} onclick="UI.confirmEncounterScry()">확정 — ${(p.chosen||[]).length}장 버림</button>
      </div>
    </div>`;
  }
  if (G.pending && G.pending.kind === 'afterAttackReaction'){
    const p = G.pending;
    const card = MC.findByUid(G, p.cardUid);
    const rx = card && MC.cardDef(card.defCode).afterAttackReaction;
    if (rx){
      const def = MC.cardDef(card.defCode) || {};
      const costStr = rx.cost ? Object.entries(rx.cost).map(([k,v]) => (RES_ICON[k]||'?').repeat(v)).join('') : '';
      h += `<div class="zone pending-zone">
        <div class="zone-title"><span>⚔️ ${esc(rx.prompt || (def.name||'') + ' — 공격 후 반응')}</span>
          ${costStr ? `<span>비용: ${costStr}${rx.needsTarget ? ' · 대상 선택' : ''}</span>` : (rx.needsTarget ? '<span>대상 선택</span>' : '')}</div>
        <div class="btnrow" style="margin-top:8px">
          <button class="btn primary" onclick="UI.activateAfterAttackReaction()">발동${costStr ? ` (${costStr})` : ''}</button>
          <button class="btn" onclick="UI.skipAfterAttackReaction()">넘김</button>
        </div>
      </div>`;
    }
  }
  if (G.pending && G.pending.kind === 'allyExhaustDraw'){
    const p = G.pending;
    const owner = G.players.find(x => x.uid === p.player);
    const allies = (p.allyUids || []).map(uid => (owner.playArea.allies || []).find(a => a.uid === uid)).filter(Boolean);
    const picked = new Set(p.chosen || []);
    const cards = allies.map(a => {
      const def = MC.cardDef(a.defCode) || {};
      const sel = picked.has(a.uid);
      return `<div class="cardpick-item ${sel?'picked':''}" onclick="UI.toggleAllyExhaustDraw('${a.uid}')" title="탭하면 소진 선택">
        ${cardArt(a.defCode, def.name || a.defCode, 130)}
        <div class="cardpick-name">${esc(def.name || a.defCode)}</div>
        ${sel?'<div class="cardpick-badge">✓ 소진</div>':''}
      </div>`;
    }).join('');
    h += `<div class="zone pending-zone cardpick-zone">
      <div class="zone-title"><span>💪 ${esc(p.prompt || '동료 소진 선택')}</span>
        <span>소진할 동료를 탭하세요 (선택 ${(p.chosen||[]).length}명 → ${(p.chosen||[]).length}장 드로우)</span></div>
      <div class="cardpick-row">${cards}</div>
      <div class="btnrow" style="margin-top:8px">
        <button class="btn primary" onclick="UI.confirmAllyExhaustDraw()">확정 — ${(p.chosen||[]).length}명 소진, ${(p.chosen||[]).length}장 드로우</button>
      </div></div>`;
  }

  if (G.pending && G.pending.kind === 'wakandaOrder'){
    const done = G.pending.total - (G.pending.remaining || []).length;
    h += `<div class="zone pending-zone">
      <div class="zone-title"><span>⚔ 와칸다 포에버! — 순서 선택</span>
        <span>발동할 BP 업그레이드를 원하는 순서로 탭하세요 (${done}/${G.pending.total})</span></div>
    </div>`;
  }

  for (const pl of G.players) h += playerZone(pl);

  if (!G.over && !G.pending && G.phase === 'player')
    h += `<div class="global-row sticky-actions"><button class="btn danger big" onclick="UI.endPhase()">페이즈 종료 → 빌런 페이즈</button></div>`;

  h += `<details class="log-drawer"><summary>전투 로그 (${G.gameLog.length})</summary>
    <div class="log-zone" id="logzone">${G.gameLog.slice(-60).map(l=>'<div>'+esc(l)+'</div>').join('')}</div></details>`;
  h += '</div>';                                       // board-inner 닫기
  h += `<aside class="side-col">${vpanelHTML()}</aside>`;  // 우측 도크 컬럼
  h += '</div>';                                       // layout 닫기
  h += payPopupHTML() + pileViewHTML() + resultsHTML() + revealModalHTML() + fxRevealHTML() + boostRevealHTML();
  if (fxRevealShowing) setTimeout(runCountups, 700);
  $('app').innerHTML = h;
  const lg = $('logzone'); if (lg) lg.scrollTop = lg.scrollHeight;
}

/* ── 카드 엣지 배지: 우측상단=스탯(코믹 슬랩), 우측하단=상태 토큰 ──
   모든 캐릭터 카드(신분/빌런/하수인/동료) 공용. statOf 실시간 값, 보정 시 금색 +N. */
function edgeStats(list){
  const chips = list.map(c => {
    const mod = c.mod || 0;
    return `<span class="estat ${c.cls}${mod!==0?' boosted':''}" title="${c.title||c.label}${mod?` (기본 ${c.val-mod} ${mod>0?'+':''}${mod})`:''}">
      <i>${c.label}</i><b>${c.val}</b>${mod>0?`<u>+${mod}</u>`:''}</span>`;
  }).join('');
  return `<div class="edge-stats">${chips}</div>`;
}
function edgeStatus(st){
  if (!st) return '';
  const t = [];
  if (st.tough)    t.push(`<span class="etok tough" title="강인 ${st.tough}">🛡${st.tough>1?st.tough:''}</span>`);
  if (st.stunned)  t.push(`<span class="etok stun" title="기절 ${st.stunned}">😵${st.stunned>1?st.stunned:''}</span>`);
  if (st.confused) t.push(`<span class="etok conf" title="혼란 ${st.confused}">💫${st.confused>1?st.confused:''}</span>`);
  return t.length ? `<div class="edge-status">${t.join('')}</div>` : '';
}
function idEdge(pl){
  const face = MC.heroFace(G, pl);
  const list = pl.form === 'hero'
    ? [['ATK','attack','atk'],['THW','thwart','thw'],['DEF','defense','def']]
    : [['REC','recover','rec']];
  return edgeStats(list.map(([label,stat,cls]) => {
    const val = MC.statOf(G, pl, stat) || 0;
    const base = face[stat] !== undefined ? face[stat] : 0;
    return { label, val, mod: val - base, cls };
  })) + edgeStatus(pl.status);
}

function playerZone(pl){
  const face = MC.heroFace(G, pl);
  const isHero = pl.form === 'hero';
  const isFirst = G.players[G.firstPlayer] === pl;
  const faceCode = isHero ? pl.heroCode : pl.aeCode;
  let h = `<div class="mat hero-zone" style="${pl.eliminated?'opacity:.4':''}">
    <div class="mat-head">
      <span><b>${esc(face.name)}</b> <span class="uid">${pl.uid}</span>
        ${isFirst?'<span class="token token-first">선</span>':''}
        ${isHero?'<span class="formchip hero">영웅</span>':'<span class="formchip ae">알터에고</span>'}</span>
      <span class="stats">${isHero
        ? 'ATK '+MC.statOf(G,pl,'attack')+' · THW '+MC.statOf(G,pl,'thwart')+' · DEF '+MC.statOf(G,pl,'defense')
        : 'REC '+MC.statOf(G,pl,'recover')}</span>
    </div>
    <div class="mat-row">
      ${pileHTML('덱', pl.deck.length)}
      ${(pl.invocationDeck && Array.isArray(pl.invocationDeck)) ? pileHTML('✦ 발동', pl.invocationDeck.length + (pl.invocationDiscard ? 0 : 0), { className:'pile-invocation', backClass:'inv-back', backGlyph:'✦', onclick:"UI.pileOpen('invocation','"+pl.uid+"')" }) : ''}
      <div class="mat-slot id-slot${MC.playerHasTrait(G, pl, 'aerial') ? ' aerial-float' : ''}" onclick="UI.flip('${pl.uid}')" title="탭하여 형태 변경">
        ${cardArt(faceCode, face.name, 104, (pl.exhausted?exhBar():'') + idEdge(pl) + toughBarrier(pl.status), true, pl.uid)}
        <span class="mat-label">신분 · 탭=전환</span>
        ${(() => {
          const iaDef = MC.cardDef(faceCode).identityAction;
          if (!iaDef || (iaDef.form && pl.form !== iaDef.form)) return '';
          const used = iaDef.oncePerRound && pl.usedIdentityActionThisRound[pl.form];
          return `<button class="btn id-action ${used?'':'gold'}" ${used?'disabled':''}
            onclick="event.stopPropagation();UI.useIdentityAction('${pl.uid}')" title="${esc(iaDef.name||'신분 액션')}">
            ⚡ ${esc(iaDef.name||'능력')}${used?' (사용됨)':''}</button>`;
        })()}
      </div>
      <div class="mat-main" style="flex:1;min-width:170px">
        ${hpBar(pl.hp, pl.maxHp, isHero?'var(--c-blue)':'var(--c-green)', 'hp:'+pl.uid, Math.max(0, pl.maxHp - ((MC.cardDef(pl.heroCode)||{}).hp||0)))}
        <div class="chips">${tokens(pl.status)}</div>
        <div class="btnrow">
          ${isHero ? `
            <button class="btn primary" onclick="UI.attackMenu('${pl.uid}')">기본 공격</button>
            <button class="btn primary" onclick="UI.thwart('${pl.uid}')">기본 저지</button>`
          : `<button class="btn primary" onclick="UI.recover('${pl.uid}')">기본 회복 +${MC.statOf(G,pl,'recover')}</button>`}
        </div>
      </div>
      ${pileHTML('버림', pl.discard.length, { onclick:`UI.pileOpen('${pl.uid}')` })}
    </div>`;

  /* 교전 하수인 (있을 때만) */
  if (pl.engagedMinions.length){
    const enemyPickM = G.pending && G.pending.kind === 'chooseEnemy';
    const targeting = enemyPickM ? false
                    : (sel.mode==='attack'||sel.mode==='target'||sel.mode==='counterFire'||sel.mode==='abilityTarget');
    h += `<div class="mat-sec">교전 하수인</div>
      <div class="mat-row wrap">${pl.engagedMinions.map(m=>`
        <div class="mat-slot ${targeting || (enemyPickM && (G.pending.enemyUids||[]).includes(m.uid)) ?'targetable':''}" onclick="UI.pickTarget('${m.uid}')">
          ${cardArt(m.defCode, m.name, 80,
            `${m.guard?'<span class="badge cost">수호</span>':''}` +
            attachBadge(m) + todoBadge(m.defCode) +
            edgeStats([{label:'ATK',val:m.attack||0,cls:'atk'},{label:'SCH',val:m.scheme||0,cls:'sch'},{label:'HP',val:m.hp,cls:'hp'}]) + edgeStatus(m.status) + toughBarrier(m.status), true, m.uid)}
          ${comicBar('HP', m.hp, m.maxHp||m.hp, 'var(--c-red)', {key:'hp:'+m.uid, mini:true, bonus:m._hpBuff})}
          ${attachChips(m)}
          ${(()=>{
            const mdef = MC.cardDef(m.defCode);
            const mab = mdef && mdef.activatedAbility;
            if (!mab) return '';
            const canUse = (!mab.form || pl.form === mab.form) && G.phase==='player' && !G.pending && !G.over && !pl.eliminated;
            return `<div class="slot-btns"><button class="btn tiny ${canUse?'gold':''}" ${canUse?'':'disabled'}
              onclick="event.stopPropagation();UI.useCardAbility('${pl.uid}','${m.uid}')"
              title="히어로 행동 — ${esc(mab.label||'능력')}">${esc(mab.label||'능력')}</button></div>`;
          })()}
        </div>`).join('')}</div>`;
  }

  /* 동료/지원 슬롯: 플레이매트처럼 빈 슬롯 아웃라인 표시 */
  const allies = pl.playArea.allies;
  const others = pl.playArea.supports.concat(pl.playArea.upgrades);
  h += `<div class="mat-sec">플레이 영역</div><div class="mat-row wrap">`;
  for (const a of allies){
    const aDef = MC.cardDef(a.defCode);
    const aAbil = aDef.activatedAbility;
    const aCanUse = aAbil && !a.exhausted && (!aAbil.form || pl.form === aAbil.form) &&
                    (!aAbil.playCondition || MC.condCheck(G, aAbil.playCondition, { player: pl, card: a })) &&
                    (!aAbil.oncePerRound || !a.usedAbilityThisRound);
    // 동료 유효 스탯 (임시 버프 tempStatBonus 포함) — allyStatOf로 계산, 버프량 mod 표시
    const aAtk = MC.allyStatOf(G, a, 'attack'), aThw = MC.allyStatOf(G, a, 'thwart');
    const aAtkMod = aAtk - (a.attack||0), aThwMod = aThw - (a.thwart||0);
    // 조건부 능력이 지금 발동 가능하면 노란 테두리 하이라이트
    const aReady = aCanUse && aAbil.playCondition ? ' ability-ready' : '';
    h += `<div class="mat-slot${aReady}${a.exhausted?' exhausted':''}">${cardArt(a.defCode, a.name, 80,
        (a.exhausted?exhBar():'') + todoBadge(a.defCode) + counterBadge(a, aDef) +
        edgeStats([{label:'ATK',val:aAtk,mod:aAtkMod,cls:'atk'},{label:'THW',val:aThw,mod:aThwMod,cls:'thw'},{label:'HP',val:a.hp,cls:'hp'}]) + edgeStatus(a.status) + toughBarrier(a.status), true, a.uid)}
      ${comicBar('HP', a.hp, a.maxHp||a.hp, 'var(--c-green)', {key:'hp:'+a.uid, mini:true})}
      <div class="slot-btns">
        <button class="btn" onclick="UI.allyAct('${pl.uid}','${a.uid}','attack')">⚔${aAtk}</button>
        <button class="btn" onclick="UI.allyAct('${pl.uid}','${a.uid}','thwart')">🛡${aThw}</button>
        ${aAbil?`<button class="btn ${aCanUse?'gold':''}" ${aCanUse?'':'disabled'} onclick="event.stopPropagation();UI.useCardAbility('${pl.uid}','${a.uid}')" title="특수 능력">★</button>`:''}
      </div></div>`;
  }
  for (let k=allies.length;k<MC.allyLimitOf(G, pl);k++) h += slotPH('동료', 80);
  for (const c of others){
    const cdef = MC.cardDef(c.defCode);
    const ab = cdef.activatedAbility;
    const ca = cdef.counterAbility;
    // 반응 조건(playCondition) 검사 — 심문실(하수인 처치 후) 등. 조건 미충족 시 발동 불가.
    const condOk = !ab || !ab.playCondition || MC.condCheck(G, ab.playCondition, { player: pl, card: c });
    const canUse = ab && !c.exhausted && (!ab.form || pl.form === ab.form) &&
                   !G.pending && G.phase === 'player' && condOk;
    // 조건부 능력이 지금 발동 가능하면 카드에 노란 테두리 하이라이트
    const abReady = canUse && ab.playCondition ? ' ability-ready' : '';
    const abLabel = ab ? (ab.form==='alter-ego'?'알터에고 능력':'능력') : '';
    const canCharge = ca && ca.charge && !G.pending && G.phase === 'player';
    const canFire = ca && ca.fire && pl.form === 'hero' && (c.counters||0) >= (ca.fire.minCounters||1) &&
                    !G.pending && G.phase === 'player';
    let btns = '';
    if (cdef.activatedAbilities){
      cdef.activatedAbilities.forEach((ability, ai) => {
        const cu = !c.exhausted && (!ability.form || pl.form === ability.form) &&
                   !G.pending && G.phase === 'player';
        const lbl = ability.label || (ability.form === 'alter-ego' ? '알터에고 능력' : '능력');
        btns += `<button class="btn" ${cu?'':'disabled'} onclick="event.stopPropagation();UI.useCardAbility('${pl.uid}','${c.uid}',${ai})">${esc(lbl)}</button>`;
      });
    } else if (ab) btns += `<button class="btn ${canUse&&ab.playCondition?'gold':''}" ${canUse?'':'disabled'} onclick="event.stopPropagation();UI.useCardAbility('${pl.uid}','${c.uid}')">${abLabel}</button>`;
    if (ca && ca.charge) btns += `<button class="btn" ${canCharge?'':'disabled'} onclick="event.stopPropagation();UI.counterCharge('${pl.uid}','${c.uid}')">⚡충전</button>`;
    if (ca && ca.fire) btns += `<button class="btn danger" ${canFire?'':'disabled'} onclick="event.stopPropagation();UI.counterFire('${pl.uid}','${c.uid}')">💥발사 (${(c.counters||0)*(ca.fire.perCounter||1)>ca.fire.max?ca.fire.max:(c.counters||0)*(ca.fire.perCounter||1)})</button>`;
    // 와칸다 포에버! 순서 선택: 이 업그레이드가 미해결 대상이면 탭하여 발동
    const wakandaPick = G.pending && G.pending.kind === 'wakandaOrder' &&
                        (G.pending.remaining || []).includes(c.uid);
    h += `<div class="mat-slot${abReady}${c.exhausted?' exhausted':''}${wakandaPick?' scheme-pickable':''}"${wakandaPick?` onclick="UI.wakandaTap('${c.uid}')"`:''}>
      <div onclick="${wakandaPick?`UI.wakandaTap('${c.uid}')`:`UI.info('${c.defCode}')`}">${cardArt(c.defCode, c.name, 80,
        (c.exhausted?exhBar():'') + counterBadge(c, cdef) + todoBadge(c.defCode), true, c.uid)}</div>
      ${btns ? `<div class="slot-btns">${btns}</div>` : ''}
    </div>`;
  }
  if (!others.length) h += slotPH('지원/업글', 80);
  h += `</div>`;

  /* 손패 스트립 */
  const edSel = (sel.mode === 'eventDiscard' || sel.mode === 'stDiscard') && sel.player === pl.uid;
  h += `<div class="mat-sec">손패 ${pl.hand.length} · 덱 ${pl.deck.length}${edSel?` · <span style="color:var(--c-yellow)">버림 선택 ${sel.picks.length}/${sel.max}</span>`:''}</div>
    <div class="hand-row">${pl.hand.map(c=>{
      const pf = MC.cardDef(c.defCode).playForm;
      const locked = pf && pl.form !== pf;
      const cls = (pay && pay.cardUid===c.uid?'selmain':'') +
                  (edSel && sel.picks.includes(c.uid)?' seldiscard':'') +
                  (edSel && c.uid===sel.cardUid?' isself':'') +
                  (locked?' formlock':'');
      return `<div class="hand-card ${cls}" onclick="UI.tapCard('${pl.uid}','${c.uid}')"
        ondblclick="UI.info('${c.defCode}')">
        ${cardArt(c.defCode, c.name, 96,
          (c.cost!==undefined?(()=>{ const eff=MC.playCostOf(G,pl,c); return eff!==c.cost
            ? `<span class="badge cost" style="background:var(--green);color:#0a1a0a" title="할인 적용 (원가 ${c.cost})">${eff}</span>`
            : `<span class="badge cost">${c.cost}</span>`; })():'') +
          `<span class="badge res">${resIcons(c)}</span>` + todoBadge(c.defCode) +
          (locked?`<span class="badge formlock-b" title="${pf==='hero'?'히어로':'알터에고'} 형태 전용">🔒${pf==='hero'?'영웅':'알터'}</span>`:''), true)}
      </div>`;
    }).join('')}</div>`;
  if (edSel && sel.mode === 'eventDiscard'){
    h += `<div class="btnrow" style="margin-top:8px">
      <button class="btn primary" onclick="UI.confirmEventDiscard()">확정 — ${sel.picks.length}장 버림 (위협 ${sel.picks.length*sel.perCard} 제거)</button>
      <button class="btn" onclick="UI.cancelEventDiscard()">취소</button>
    </div>`;
  }
  if (edSel && sel.mode === 'stDiscard'){
    const isSpendX = sel.flow === 'spendXEnergy';
    h += `<div class="btnrow" style="margin-top:8px">
      <button class="btn primary" onclick="UI.confirmShieldTossDiscard()">${
        isSpendX
          ? `확정 — ⚡에너지 ${sel.picks.length} 지불 → 빌런+교전 하수인에 각 ${sel.picks.length} 피해`
          : `확정 — ${sel.picks.length}장 버림 → 적 ${sel.picks.length}명 선택`
      }</button>
      <button class="btn" onclick="UI.cancelEventDiscard()">취소</button>
    </div>`;
  }

  h += '</div>';
  return h;
}

/* ═══ 상호작용 ═══ */
const UI = {
  /* 메뉴 */
  go(screen){ APP.screen = screen; APP.importResult = null; render(); },
  startSolo(){ APP.mode = 'solo'; APP.slots = [APP.slots[0] || { heroKey:'spiderman', deckId:'preset' }]; APP.screen = 'team'; render(); },
  startMode(m){ APP.mode = m; APP.screen = 'team'; render(); },
  multiSoon(){ toast('멀티플레이(각자 화면)는 통신 시스템 구축 중! 곧 온다.'); },
  continueGame(){
    MC.clearVfx && MC.clearVfx();
    const g = loadSave();
    if (!g){ toast('저장된 게임이 없어요', true); return; }
    if (g.version !== MC.VERSION) toast('이전 버전 저장 — 호환되지 않으면 새 게임을 시작하세요');
    G = g; sel = { mode:null, cardUid:null, player:null }; pay = null; resultsShown = false; render();
    // 빌런 페이즈 단계 진행 중 저장이었다면 재개
    if (G.villainStepMode && G.phase === 'villain' && !G.pending) maybeStepVillain();
  },
  slotAdd(){ if (APP.slots.length < 4){ APP.slots.push({ heroKey:'spiderman', deckId:'preset' }); render(); } },
  slotRemove(i){ APP.slots.splice(i,1); render(); },
  heroPickOpen(kind,i){ APP.heroPick = { kind, i }; render(); },
  heroPickClose(){ APP.heroPick = null; render(); },
  heroPickChoose(k){
    const hp = APP.heroPick;
    APP.heroPick = null;
    if (!hp) return;
    if (hp.kind === 'slot'){
      APP.slots[hp.i].heroKey = k;
      APP.slots[hp.i].deckId = (deckOptionsFor(k)[0]||{id:''}).id;
    } else if (hp.kind === 'builder'){
      APP.builder = { heroKey:k, aspect:'protection', counts:{}, search:'' };
      APP.screen = 'builder';
    }
    render();
  },
  slotPickClose(){ APP.slotPick = null; render(); },
  slotWrite(i){
    const sl = loadSlots();
    if (sl[i] && !confirm('슬롯 '+(i+1)+' "'+sl[i].name+'" 을(를) 덮어쓸까?')) return;
    sl[i] = APP.slotPick;
    saveSlots(sl);
    APP.slotPick = null;
    toast('슬롯 '+(i+1)+' 저장 완료! 팀 구성에서 선택하세요');
    APP.screen = 'title'; render();
  },
  slotDelete(i){
    const sl = loadSlots();
    if (!sl[i]) return;
    if (!confirm('"'+sl[i].name+'" 삭제?')) return;
    sl[i] = null; saveSlots(sl); render();
  },
  slotDeck(i,v){ APP.slots[i].deckId = v; },
  villainTab(t){ APP.villainTab = t; render(); },
  setDifficulty(d){ APP.difficulty = d; render(); },
  // ── 테스트용: 즉시 승리 (빌런 강제 격파 → 격파 코믹스/캠페인 진행 확인용) ──
  debugWin(){
    if (!G || G.over) return;
    MC.setGameOver(G, 'win', '테스트: 즉시 승리');
    saveGame();
    render();   // 캠페인 모드면 격파 코믹스 자동 트리거
  },
  // ── 캠페인 다음 시나리오로 진행 (시트 순서 기준) ──
  nextScenario(){
    const camp = (G && G.campaign) ? CAMPAIGNS[G.campaign] : null;
    if (!camp || !camp.sheet){ toast('캠페인 모드가 아니야', true); return; }
    const cur = camp.sheet.findIndex(s => s.key === G.scenarioKey);
    const nx = camp.sheet[cur + 1];
    if (!nx){ toast('🎉 캠페인 완료! 레드 스컬을 물리쳤다!'); return; }
    if (!nx.ready || !MC.SCENARIOS[nx.key]){ toast('⏭ ' + nx.name + ' 시나리오는 아직 준비 중이야'); return; }
    // 같은 히어로/덱/난이도로 다음 시나리오 시작 (캠페인 유지)
    APP.scenarioKey = nx.key;
    document.getElementById('comic-overlay') && (document.getElementById('comic-overlay').style.display = 'none');
    startGame();
  },
  modularMode(m){
    APP.modularMode = m;
    if (m === 'random' && !APP.modularRandomKeys){
      APP.modularRandomKeys = MC.randomModularKeys(APP.modularRandomN || 1);
    }
    render();
  },
  modularRandomN(n){
    APP.modularRandomN = n;
    APP.modularRandomKeys = MC.randomModularKeys(n);   // 개수 변경 시 새로 뽑음
    render();
  },
  rerollModular(){
    APP.modularRandomKeys = MC.randomModularKeys(APP.modularRandomN || 1);
    render();
  },
  toggleModular(k){
    const arr = APP.modularPick || (APP.modularPick = []);
    const i = arr.indexOf(k);
    if (i >= 0) arr.splice(i, 1); else arr.push(k);
    render();
  },
  useIdentityAction(playerUid){
    const pl = G.players.find(p=>p.uid===playerUid);
    const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    const ia = MC.cardDef(faceCode).identityAction;
    if (!ia) return;
    const idEl = document.querySelector(`[data-vuid="${playerUid}"]`);
    const playFx = () => { if (ia.vfx && idEl) MC.playVfx(ia.vfx, { el: idEl, toRect: idEl.getBoundingClientRect() }); };
    if (ia.payEnergy){
      // 에너지 결제 팝업 (identityPay 모드)
      pay = { player: playerUid, cardUid: faceCode, elements: [], identityPay: true, payEnergy: ia.payEnergy, iaVfx: ia.vfx };
      render(); return;
    }
    const ok = act({ type:'useIdentityAction', player: playerUid });
    if (ok) setTimeout(playFx, 60);
    render();
  },
  revealContinue(){
    revealShowing = null;
    if (revealQueue.length){ pumpRevealQueue(); return; }
    render();
    fxPump();
    if (G && G.phase === 'villain' && G.villainStepMode && !G.pending) maybeStepVillain();
  },
  fxRevealDone(){ fxRevealShowing = null; if (G) delete G.fxReveal; render(); pumpRevealQueue(); },
  boostRevealDone(){ boostRevealShowing = null; if (G) delete G.fxBoostReveal; render(); pumpRevealQueue(); fxPump(); if (G && G.villainStepMode) maybeStepVillain(); },
  revealSkipAll(){
    revealQueue = []; revealShowing = null; render();
    fxPump();
    if (G && G.phase === 'villain' && G.villainStepMode && !G.pending) maybeStepVillain();
  },
  pickVillain(k){ APP.campaign = null; APP.villainRandom = false; APP.scenarioKey = k; APP.modularRandomKeys = null; render(); },
  pickRandomVillain(){
    const ready = VILLAIN_ROSTER.filter(v => v.ready);
    if (!ready.length) return;
    APP.campaign = null;
    APP.villainRandom = true;
    APP.scenarioKey = ready[Math.floor(Math.random() * ready.length)].key;   // 미리보기 겸 확정값(다시 누르면 재추첨)
    APP.modularRandomKeys = null;   // 모듈 랜덤 모드면 새 빌런 기준으로 재추첨되도록
    render();
  },
  randomizeAll(){
    // 빌런 + 모듈 동시 랜덤 (다시 누르면 전부 재추첨)
    const ready = VILLAIN_ROSTER.filter(v => v.ready);
    if (ready.length){
      APP.campaign = null;
      APP.villainRandom = true;
      APP.scenarioKey = ready[Math.floor(Math.random() * ready.length)].key;
    }
    APP.modularMode = 'random';
    APP.modularRandomKeys = MC.randomModularKeys(APP.modularRandomN || 1);
    render();
  },
  pickCampaign(k){
    APP.campaign = k;
    APP.scenarioKey = CAMPAIGNS[k].villains.find(vk => (VILLAIN_ROSTER.find(v=>v.key===vk)||{}).ready) || CAMPAIGNS[k].villains[0];
    render();
  },
  launch(){ startGame(); },
  reset(){ if (G && !G.over && !confirm('진행 중인 게임을 두고 메인으로? (이어하기로 재개 가능)')) return;
    MC.clearVfx && MC.clearVfx();
    G = null; APP.screen='title'; render(); },

  /* 덱빌더 */
  openBuilder(){ APP.heroPick = { kind:'builder' }; render(); },
  bSearch(v){
    const b = APP.builder;
    b.search = v;
    // 카드 풀 영역만 교체 → 검색 입력 포커스/커서 유지
    const poolEl = document.getElementById('builder-pool');
    if (poolEl) poolEl.innerHTML = builderPoolInner();
    const clr = document.getElementById('bs-clear');
    if (clr) clr.style.visibility = v ? 'visible' : 'hidden';
  },
  bSearchClear(){
    APP.builder.search = '';
    render();
    const inp = document.getElementById('builder-search-input');
    if (inp) inp.focus();
  },
  bAspect(a){
    const b = APP.builder;
    if (a !== b.aspect && Object.keys(b.counts).some(c => MC.CARDS[c].aspect === b.aspect)){
      if (!confirm('성향을 바꾸면 담아둔 ' + ASPECTS.find(x=>x[0]===b.aspect)[1] + ' 카드가 비워집니다. 계속?')) return;
      for (const c in b.counts) if (MC.CARDS[c].aspect === b.aspect) delete b.counts[c];
    }
    b.aspect = a; render();
  },
  bInc(code){
    const b = APP.builder, d = MC.CARDS[code];
    const lim = d.deckLimit || 3;
    if ((b.counts[code]||0) >= lim){ toast('덱 한도 ' + lim + '장', true); return; }
    if (builderTotals().total >= 50){ toast('덱 최대 50장', true); return; }
    b.counts[code] = (b.counts[code]||0) + 1; render();
  },
  bDec(code){
    const b = APP.builder;
    if (!b.counts[code]) return;
    b.counts[code]--; if (!b.counts[code]) delete b.counts[code];
    render();
  },
  bSave(){
    const b = APP.builder;
    const name = prompt('덱 이름:', HERO_META[b.heroKey].name + ' 커스텀');
    if (!name) return;
    const counts = Object.assign({}, b.counts);
    for (const d of heroSignatureCards(b.heroKey)) counts[d.code] = (d.copies || 1);
    APP.slotPick = { id:'d'+Date.now(), name, heroKey:b.heroKey, aspect:b.aspect, counts, total:builderTotals().total };
    render();
  },

  /* 가져오기 */
  impParse(){
    APP.importText = $('imp-text').value;
    APP.importResult = parseImport(APP.importText);
    render();
  },
  impTab(t){ APP.importTab = t; APP.importResult = null; render(); },
  async impFetch(){
    APP.importNo = ($('imp-no')||{value:APP.importNo}).value;
    const id = String(APP.importNo).replace(/[^0-9]/g,'');
    if (!id){ toast('덱리스트 번호를 입력하세요', true); return; }
    APP.importBusy = true; APP.importResult = null; render();
    try {
      const res = await fetch('https://marvelcdb.com/api/public/decklist/' + id + '.json');
      if (!res.ok) throw new Error('덱리스트 #' + id + ' 불러오기 실패 (HTTP ' + res.status + ')');
      const data = await res.json();
      APP.importResult = importFromMarvelCDBData(data);
      toast('가져오기 성공!');
    } catch(e){
      toast(e.message || '가져오기 실패 — 인터넷/번호 확인', true);
    }
    APP.importBusy = false; render();
  },
  impSave(){
    const r = APP.importResult;
    if (!r || !Object.keys(r.counts).length){ toast('먼저 가져오거나 해석하세요', true); return; }
    const name = prompt('덱 이름:', r.name || '가져온 덱');
    if (!name) return;
    const total = Object.values(r.counts).reduce((a,b)=>a+b,0);
    APP.slotPick = { id:'d'+Date.now(), name, heroKey:r.heroKey, aspect:null, counts:r.counts, total };
    render();
  },

  /* 게임 */
  a: act,
  recover(playerUid){
    if (G.pending){ toast('방어 선언부터 해결하세요', true); return; }
    const amt = MC.statOf(G, G.players.find(p=>p.uid===playerUid), 'recover');
    // 회복은 HP 증가라 피격 트리거 대상 아님 (opt로 억제 — 액션 객체는 오염 없이 순수 유지)
    const ok = act({ type:'basicRecover', player: playerUid }, { suppressHit:true });
    if (ok){
      const el = document.querySelector(`[data-vuid="${playerUid}"]`);
      if (el) MC.playVfx('recover', { el, amount: amt });
    }
  },
  thwart(playerUid, scheme){
    if (G.pending){ toast('방어 선언부터 해결하세요', true); return; }
    // 대상 미지정 + 사이드스킴 존재 → 스킴 선택 모드 (메인/사이드 탭)
    if (!scheme && G.sideSchemes.length){
      if (sel && sel.mode === 'schemePick'){ sel = { mode:null }; render(); return; }  // 재탭=취소
      sel = { mode:'schemePick', purpose:'basicThwart', player: playerUid };
      toast('저지할 스킴을 탭하세요 (메인 또는 사이드)'); render(); return;
    }
    UI._doThwart(playerUid, scheme || 'main');
  },
  _doThwart(playerUid, scheme){
    if ((scheme === 'main' || !scheme) && MC.hasCrisisScheme(G)){
      toast('위기(Crisis) 사이드 스킴을 먼저 처치해야 메인 스킴을 저지할 수 있어요', true);
      return;
    }
    const fromEl = document.querySelector(`[data-vuid="${playerUid}"]`);
    const schemeUid = scheme === 'main' ? (G.mainScheme && G.mainScheme.uid) : scheme;
    const toEl = document.querySelector(`[data-vuid="${schemeUid}"]`);
    const fromRect = fromEl && fromEl.getBoundingClientRect();
    const toRect = toEl && toEl.getBoundingClientRect();
    const ok = act({ type:'basicThwart', player: playerUid, scheme });
    if (ok){
      const pl = G.players.find(p=>p.uid===playerUid);
      const fdef = pl && MC.cardDef(pl.heroCode);
      const vfxName = fdef && fdef.vfx && fdef.vfx.basicThwart;
      if (vfxName && fromRect && toRect) MC.playVfx(vfxName, { fromRect, toRect });
    }
  },
  /* 스킴 선택 모드 해소: 메인('main') 또는 사이드스킴 uid 탭 */
  schemeTap(ref){
    if (!sel || sel.mode !== 'schemePick') return;
    const s = sel; sel = { mode:null };
    if (s.purpose === 'basicThwart'){ UI._doThwart(s.player, ref); return; }
    if (s.purpose === 'allyThwart'){ UI._doAllyThwart(s.player, s.allyUid, ref); return; }
    if (s.purpose === 'event'){
      const pl = G.players.find(p=>p.uid===s.player);
      const card = pl && pl.hand.find(c=>c.uid===s.cardUid);
      const cdef = card && MC.cardDef(card.defCode);
      const fromEl = document.querySelector(`[data-vuid="${s.player}"]`);
      const schemeUid = ref === 'main' ? (G.mainScheme && G.mainScheme.uid) : ref;
      const toEl = document.querySelector(`[data-vuid="${schemeUid}"]`);
      const fromRect = fromEl && fromEl.getBoundingClientRect();
      const toRect = toEl && toEl.getBoundingClientRect();
      const ok = act({ type:'playCard', player: s.player, cardUid: s.cardUid,
                       payment: s.payment, targetScheme: ref });
      const vfxName = cdef && cdef.vfx && (cdef.vfx.basicThwart || cdef.vfx.event);
      if (ok && vfxName && fromRect && toRect) MC.playVfx(vfxName, { fromRect, toRect });
      render(); return;
    }
    render();
  },
  cancelSchemePick(){ sel = { mode:null }; render(); },
  /* 와칸다 포에버! 순서 선택: 탭한 BP 업그레이드를 발동 + 연출 재생. 남으면 계속 선택. */
  wakandaTap(uid){
    if (!(G.pending && G.pending.kind === 'wakandaOrder')) return;
    const el = document.querySelector(`[data-vuid="${uid}"]`);
    const ok = act({ type:'resolveWakandaStep', uid });
    if (ok && G.fxWakandaSeq && G.fxWakandaSeq.steps){
      G.fxWakandaSeq.steps.forEach(st => {
        const stDef = MC.cardDef(st.defCode);
        const sv = stDef && stDef.vfx && stDef.vfx.special;
        if (sv && el) MC.playVfx(sv, { el, cardEl: el, big: st.final });
      });
    }
    render();
  },
  flip(playerUid){
    if (G.pending){ toast('방어 선언부터 해결하세요', true); return; }
    const pl = G.players.find(p=>p.uid===playerUid);
    const el = document.querySelector(`[data-vuid="${playerUid}"]`);
    const fdef = pl && MC.cardDef(pl.heroCode);
    const vfxName = fdef && fdef.vfx && fdef.vfx.formChange;
    if (!el || !vfxName){ act({ type:'flipForm', player: playerUid }); return; } // 폴백
    // 렌더 지연 디스패치: 상태만 바꾸고 연출이 끝나면 렌더
    try { MC.dispatch(G, { type:'flipForm', player: playerUid }); saveGame(); }
    catch(e){ toast(e.message, true); render(); return; }
    const newFace = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    // 신분 히어로 파워 연출 (She-Hulk 변신 2피해=gammaSlam 등): 대상 위에서
    const hp = G.fxHeroPower;
    MC.playVfx(vfxName, { el, newImgUrl: imgUrl(newFace), onDone: () => {
      render();
      if (hp && hp.vfx){
        const tel = document.querySelector(`[data-vuid="${hp.targetUid}"]`);
        if (tel) setTimeout(() => MC.playVfx(hp.vfx, { el: tel, toRect: tel.getBoundingClientRect() }), 120);
      }
    }});
  },
  useInterrupt(playerUid, cardUid){
    const pl = G.players.find(p=>p.uid===playerUid);
    const card = pl.hand.find(c=>c.uid===cardUid) ||
                 pl.playArea.allies.find(c=>c.uid===cardUid) ||
                 pl.playArea.supports.find(c=>c.uid===cardUid);
    if (!card) return;
    const def = MC.cardDef(card.defCode);
    const io = def.interruptOn || {};
    // 자원 지불 필요 여부: 손패 이벤트=cost / 동료·서포트=interruptOn.pay
    const needPay = (pl.hand.includes(card) ? (def.cost || 0) : (io.pay ? io.pay.count : 0)) > 0;
    if (needPay){
      const req = io.pay ? { type: io.pay.type, count: io.pay.count } : null;
      pay = { player: playerUid, cardUid, elements: [], interrupt: true, interruptReq: req,
              interruptCost: pl.hand.includes(card) ? (def.cost||0) : (io.pay?io.pay.count:0) };
      render(); return;
    }
    this._fireInterrupt(playerUid, cardUid, []);
  },
  passInterrupt(){
    const p = G.pending;
    act({ type:'resolveRevealInterrupt', player: p.player }); // cardUid 없음 = 패스
  },
  _fireInterrupt(playerUid, cardUid, elements){
    const pl = G.players.find(p=>p.uid===playerUid);
    const card = pl.hand.find(c=>c.uid===cardUid) ||
                 pl.playArea.allies.find(c=>c.uid===cardUid) ||
                 pl.playArea.supports.find(c=>c.uid===cardUid);
    const def = card && MC.cardDef(card.defCode);
    const vfxName = def && def.vfx && def.vfx.interrupt;
    const heroEl = document.querySelector(`[data-vuid="${playerUid}"]`);
    const owner = G.pending && G.pending.player;
    const ok = act({ type:'resolveRevealInterrupt', player: owner, cardUid, payment: elements });
    if (ok && vfxName && heroEl) MC.playVfx(vfxName, { el: heroEl, targetEl: null });
  },
  useCardAbility(playerUid, cardUid, abilityIndex){
    const pl = G.players.find(p=>p.uid===playerUid);
    const card = findAbilityCardUI(pl, cardUid);
    if (!card) return;
    const def = MC.cardDef(card.defCode);
    const ab = def.activatedAbilities ? def.activatedAbilities[abilityIndex||0] : def.activatedAbility;
    // 카드 버림 코스트가 있으면 버릴 카드 선택 모드로
    if (ab && ab.discardCost){
      if (pl.hand.length < ab.discardCost){ toast('버릴 카드가 부족합니다', true); return; }
      sel = { mode:'abilityDiscard', player: playerUid, cardUid, need: ab.discardCost, picks: [], abilityIndex };
      toast(`능력 비용: 버릴 카드 ${ab.discardCost}장을 손에서 탭`); render(); return;
    }
    // 자원 지불 코스트가 있으면 자원 선택 팝업으로 (초인법 사무소 등)
    if (ab && ab.payCost){
      pay = { player: playerUid, cardUid, elements: [], abilityPay: true, payCost: ab.payCost, abilityIndex };
      render(); return;
    }
    // 대상 지정이 필요한 능력(동력 건틀릿 등): 적 선택 모드로
    if (ab && ab.needsTarget){
      sel = { mode:'abilityTarget', player: playerUid, cardUid, abilityIndex };
      toast('대상을 선택하세요 (적을 탭)'); render(); return;
    }
    this._fireCardAbility(playerUid, cardUid, [], abilityIndex);
  },
  _fireCardAbility(playerUid, cardUid, discardUids, abilityIndex){
    const pl = G.players.find(p=>p.uid===playerUid);
    const card = findAbilityCardUI(pl, cardUid);
    if (!card) return;
    const def = MC.cardDef(card.defCode);
    const vfxRecover = def.vfx && def.vfx.recover;
    const el = document.querySelector(`[data-vuid="${cardUid}"]`);
    const ab = def.activatedAbilities ? def.activatedAbilities[abilityIndex||0] : def.activatedAbility;
    const healEl = (ab && ab.effect && (Array.isArray(ab.effect)?ab.effect:[ab.effect]).some(e=>e.fx==='heal' && e.target==='self'))
      ? document.querySelector(`[data-vuid="${playerUid}"]`) : el;
    const ok = act({ type:'useCardAbility', player: playerUid, cardUid, discardUids, abilityIndex: abilityIndex||0 });
    if (ok && vfxRecover && healEl) MC.playVfx(vfxRecover, { el: healEl, amount: 4 });
    // 활성 능력 연출 (워 머신=warMachineBarrage 등): 카드 스코프
    // 조건부 연출: Aerial 등 상태에 따라 다른 연출 (MK.5 헬멧: 단일 vs 광역)
    const vfxAerial = def.vfx && def.vfx.abilityAerial;
    const useAerial = vfxAerial && MC.playerHasTrait(G, pl, 'aerial');
    const vfxAbility = useAerial ? vfxAerial : (def.vfx && def.vfx.ability);
    if (ok && vfxAbility && el) MC.playVfx(vfxAbility, { el });
  },
  toggleVPanel(){ vpanelOpen = !vpanelOpen; render(); },
  openResults(){ resultsShown = true; render(); runCountups(); },
  closeResults(){ resultsShown = false; render(); },
  toMenuFromResults(){ resultsShown = false; UI.reset(); },
  confirmEventDiscard(){
    if (!sel || sel.mode !== 'eventDiscard') return;
    const picks = sel.picks.slice(), pUid = sel.player, cUid = sel.cardUid, payment = sel.payment;
    const fromEl = document.querySelector(`[data-vuid="${pUid}"]`);
    const cdef = MC.cardDef((G.players.find(p=>p.uid===pUid).hand.find(c=>c.uid===cUid)||{}).defCode);
    const vfxName = cdef && cdef.vfx && cdef.vfx.basicThwart;
    sel = { mode:null };
    const ok = act({ type:'playCard', player: pUid, cardUid: cUid, payment, discardUids: picks });
    if (ok && vfxName && fromEl) MC.playVfx(vfxName, { el: fromEl });
    render();
  },
  cancelEventDiscard(){ sel = { mode:null }; render(); },
  confirmShieldTossDiscard(){
    if (!sel || sel.mode !== 'stDiscard') return;
    const picks = sel.picks.slice(), pUid = sel.player, cUid = sel.cardUid, payment = sel.payment;
    if (sel.flow === 'spendXEnergy'){   // 에너지 X 지불 → 확정 → 바로 AoE 효과 (타겟 선택 없음)
      sel = { mode:null };
      act({ type:'playCard', player: pUid, cardUid: cUid, payment, discardUids: picks });
      render(); return;
    }
    if (picks.length === 0){   // X=0 → 버림/피해 없이 플레이(방패 반환만)
      sel = { mode:null };
      act({ type:'playCard', player: pUid, cardUid: cUid, payment, discardUids: [], targets: [] });
      render(); return;
    }
    sel = { mode:'stTarget', player: pUid, cardUid: cUid, payment, discardUids: picks, need: picks.length, targets: [] };
    toast(`적 ${picks.length}명을 선택하세요 (각 4 피해) — 서로 다른 적`); render();
  },
  endPhase(){
    if (!G || G.over || G.pending || G.phase !== 'player') return;
    MC.playVfx('phaseBanner', { text:'VILLAIN PHASE!', sub:'빌런 페이즈', color:'red' });
    // 배너가 지나간 뒤 단계 진행 시작
    setTimeout(() => {
      const ok = act({ type:'endPlayerPhase', stepwise: true });
      if (ok) maybeStepVillain();
    }, 750);
  },
  counterCharge(playerUid, cardUid){
    // 에너지 자원 선택 팝업 (충전 — 지불 요소만큼 카운터)
    pay = { player: playerUid, cardUid, elements: [], counterCharge: true };
    render();
  },
  counterFire(playerUid, cardUid){
    // 발사 — 대상 선택 모드
    sel = { mode:'counterFire', player: playerUid, cardUid };
    toast('발사할 대상(적)을 선택하세요');
    render();
  },
  useDefenseInterrupt(playerUid, cardUid){
    // 방어 pending 중 플레이 영역 방어 인터럽트 카드(우주 비행 등) 발동 — 부분 피해 방지 + 자체 버림
    act({ type:'useDefenseInterrupt', player: playerUid, cardUid });
  },
  playDefenseEvent(playerUid, cardUid){
    // 방어 pending 중 Backflip 등 방어 이벤트 플레이 → 결제 팝업 (방어 플래그)
    pay = { player: playerUid, cardUid, elements: [], defenseInterrupt: true };
    render();
  },
  def(defender){
    const p = G.pending;
    const attackerUid = p && p.attackerUid;
    const attacker = attackerUid && MC.findByUid(G, attackerUid);
    const adef = attacker && MC.cardDef(attacker.defCode);
    const vfxName = adef && adef.vfx && adef.vfx.enemyAttack;
    // 임팩트 대상: 신분/무방어 = 플레이어 카드, 동료 방어 = 그 동료 카드
    const targetVuid = (defender==='identity'||defender==='none') ? p.player : defender;
    const toEl = document.querySelector(`[data-vuid="${targetVuid}"]`);
    const toRect = toEl && toEl.getBoundingClientRect();
    const ok = act({ type:'resolveDefense', player: p.player, defender });
    if (ok && vfxName && toRect) MC.playVfx(vfxName, { attackerUid, toRect });
  },
  /* 조우 카드 공개 선택 해소 (하이드라 폭파범 등): 선택지 실행 + 테마 이펙트 */
  resolveMorphResponse(accept){
    const p = G.pending;
    if (!p || p.kind !== 'morphResponse') return;
    act({ type:'resolveMorphResponse', player: p.player, accept: !!accept });
  },
  toggleEventBoost(uid){
    const p = G.pending;
    if (!p || p.kind !== 'eventBoostChoice') return;
    p.chosen = p.chosen || [];
    const i = p.chosen.indexOf(uid);
    if (i >= 0) p.chosen.splice(i, 1); else p.chosen.push(uid);
    render();
  },
  confirmEventBoost(){
    const p = G.pending;
    if (!p || p.kind !== 'eventBoostChoice') return;
    act({ type:'resolveEventBoost', player: p.player, boosterUids: p.chosen || [] });
  },
  skipEventBoost(){
    const p = G.pending;
    if (!p || p.kind !== 'eventBoostChoice') return;
    act({ type:'resolveEventBoost', player: p.player, boosterUids: [] });
  },
  pickAllyDefeatTarget(uid){
    const p = G.pending;
    if (!p || p.kind !== 'allyDefeatInterrupt') return;
    p.targetUid = uid; render();
  },
  toggleAllyDefeatPay(uid){
    const p = G.pending;
    if (!p || p.kind !== 'allyDefeatInterrupt') return;
    p.chosenPay = p.chosenPay || [];
    const i = p.chosenPay.indexOf(uid);
    if (i >= 0) p.chosenPay.splice(i, 1); else p.chosenPay.push(uid);
    render();
  },
  confirmAllyDefeatInterrupt(){
    const p = G.pending;
    if (!p || p.kind !== 'allyDefeatInterrupt') return;
    if (!p.targetUid){ alert('피해를 줄 적을 선택하세요'); return; }
    if (!(p.chosenPay||[]).length){ alert('서로 다른 자원 2개를 선택하세요'); return; }
    act({ type:'resolveAllyDefeatInterrupt', player: p.player,
      payment: (p.chosenPay||[]).map(uid => ({ kind:'hand', uid })), targetUid: p.targetUid });
  },
  declineAllyDefeatInterrupt(){
    const p = G.pending;
    if (!p || p.kind !== 'allyDefeatInterrupt') return;
    act({ type:'resolveAllyDefeatInterrupt', player: p.player, decline: true });
  },
  resolveBrunoStore(cardUid){
    const p = G.pending;
    if (!p || p.kind !== 'brunoStorePick') return;
    act({ type:'resolveBrunoStore', player: p.player, cardUid });
  },
  toggleBrunoRetrieve(uid){
    const p = G.pending;
    if (!p || p.kind !== 'brunoRetrievePick') return;
    p.chosen = p.chosen || [];
    const i = p.chosen.indexOf(uid);
    if (i >= 0) p.chosen.splice(i, 1);
    else if (p.chosen.length < (p.max || 3)) p.chosen.push(uid);
    render();
  },
  confirmBrunoRetrieve(){
    const p = G.pending;
    if (!p || p.kind !== 'brunoRetrievePick') return;
    act({ type:'resolveBrunoRetrieve', player: p.player, cardUids: p.chosen || [] });
  },
  startAllyAttackInterrupt(playerUid, cardUid){
    if (!G.pending || G.pending.kind !== 'defense') return;
    novaPay = { player: playerUid, cardUid, attackerUid: G.pending.attackerUid, elements: [] };
    render();
  },
  toggleNovaPay(uid){
    if (!novaPay) return;
    const i = novaPay.elements.findIndex(e => e.kind==='hand' && e.uid===uid);
    if (i >= 0) novaPay.elements.splice(i, 1);
    else novaPay.elements.push({ kind:'hand', uid });
    render();
  },
  confirmNovaPay(){
    if (!novaPay) return;
    const a = { type:'useAllyAttackInterrupt', player: novaPay.player, cardUid: novaPay.cardUid, payment: novaPay.elements };
    const atkEl = document.querySelector(`[data-vuid="${novaPay.attackerUid}"]`);
    novaPay = null;
    const ok = act(a);
    if (ok && atkEl) MC.playVfx('novaBlast', { el: atkEl });
  },
  cancelNovaPay(){ novaPay = null; render(); },
  resolveRapidResponse(accept){
    const p = G.pending;
    if (!p || p.kind !== 'rapidResponse') return;
    const allyEl = () => document.querySelector(`[data-vuid="${p.allyUid}"]`);
    const ok = act({ type:'resolveRapidResponse', player: p.player, accept: !!accept });
    if (ok && accept){ const el = allyEl(); if (el) MC.playVfx('rapidResponse', { el }); }
  },
  revealChoice(option){
    const p = G.pending;
    if (!p || p.kind !== 'revealChoice') return;
    const self = MC.findByUid(G, p.selfUid);
    const playerUid = p.player;
    const sdef = self && MC.cardDef(self.defCode);
    const atkVfx = sdef && sdef.vfx && sdef.vfx.attack;
    const selfEl = document.querySelector(`[data-vuid="${p.selfUid}"]`);
    const tgtEl = document.querySelector(`[data-vuid="${playerUid}"]`);
    const ok = act({ type:'resolveRevealChoice', player: playerUid, option });
    if (ok){
      // 피해 선택 시 폭탄 이펙트를 교전 플레이어 위에 재생
      if (option === 'damage' && atkVfx && tgtEl){
        const r = tgtEl.getBoundingClientRect();
        const sr = selfEl && selfEl.getBoundingClientRect();
        MC.playVfx(atkVfx, { el: tgtEl, fromRect: sr || r, toRect: r, targetEl: tgtEl });
      }
      // 위협 선택 시 메인 스킴에 위협 상승 연출 (범용 위협 이펙트가 있으면)
    }
  },
  /* 범용 카드 선택 해소 (미래학자 등): 탭한 카드를 손에 넣고, 다 고르면 나머지 처리 */
  resolveCardPick(uid){
    const p = G.pending;
    if (!p || p.kind !== 'cardPick') return;
    if (!(p.cardUids||[]).includes(uid) || (p.chosen||[]).includes(uid)) return;
    act({ type:'resolveCardPick', player: p.player, uid });
  },
  resolveHandDiscardCost(uid){
    const p = G.pending;
    if (!p || p.kind !== 'handDiscardCost') return;
    act({ type:'resolveHandDiscardCost', player: p.player, uid });
  },
  toggleAllyExhaustDraw(uid){
    const p = G.pending;
    if (!p || p.kind !== 'allyExhaustDraw') return;
    act({ type:'resolveAllyExhaustDraw', player: p.player, mode:'toggle', uid });
  },
  resolveDeployAlly(uid){
    const p = G.pending;
    if (!p || p.kind !== 'deployAlly') return;
    act({ type:'resolveDeployAlly', player: p.player, uid });
  },
  resolveAttachCharacter(target){
    const p = G.pending;
    if (!p || p.kind !== 'attachCharacter') return;
    act({ type:'resolveAttachCharacter', player: p.player, target });
  },
  resolveDiscardChoose(uid){
    const p = G.pending;
    if (!p || p.kind !== 'discardChoose') return;
    act({ type:'resolveDiscardChoose', player: p.player, uid });
  },
  resolvePickControlledDiscard(uid){
    const p = G.pending;
    if (!p || p.kind !== 'pickControlledDiscard') return;
    act({ type:'resolvePickControlledDiscard', player: p.player, uid });
  },
  resolveResourceDiscardPick(uid){
    const p = G.pending;
    if (!p || p.kind !== 'resourceDiscardPick') return;
    act({ type:'resolveResourceDiscardPick', player: p.player, uid });
  },
  confirmAllyExhaustDraw(){
    const p = G.pending;
    if (!p || p.kind !== 'allyExhaustDraw') return;
    act({ type:'resolveAllyExhaustDraw', player: p.player, mode:'confirm' });
  },
  skipAfterAttackReaction(){
    const p = G.pending;
    if (!p || p.kind !== 'afterAttackReaction') return;
    act({ type:'resolveAfterAttackReaction', player: p.player, mode:'skip' });
  },
  toggleEncounterScry(uid){
    const p = G.pending;
    if (!p || p.kind !== 'encounterScry') return;
    act({ type:'resolveEncounterScry', player: p.player, mode:'toggle', uid });
  },
  pickTeamworkAlly(uid){
    const p = G.pending;
    if (!p || p.kind !== 'teamworkAlly') return;
    act({ type:'resolveTeamworkAlly', player: p.player, uid });
  },
  pickWidowmaker(uid){
    const p = G.pending;
    if (!p || p.kind !== 'widowmaker') return;
    act({ type:'resolveWidowmaker', player: p.player, uid });
  },
  confirmEncounterScry(){
    const p = G.pending;
    if (!p || p.kind !== 'encounterScry') return;
    act({ type:'resolveEncounterScry', player: p.player, mode:'confirm' });
  },
  activateAfterAttackReaction(){
    const p = G.pending;
    if (!p || p.kind !== 'afterAttackReaction') return;
    const card = MC.findByUid(G, p.cardUid);
    const rx = card && MC.cardDef(card.defCode).afterAttackReaction;
    if (!rx) return;
    // 대상·자원 불필요 (Battle Fury) → 바로 발동
    if (!rx.cost && !rx.needsTarget){
      act({ type:'resolveAfterAttackReaction', player: p.player, mode:'activate' });
      return;
    }
    // 대상/자원 필요 (Jarnbjorn) → 대상 선택 모드 진입 (자원은 대상 확정 후 결제 팝업)
    sel = { mode:'aarTarget', player: p.player, cardUid: p.cardUid, cost: rx.cost || null,
            needsTarget: !!rx.needsTarget, targets: [] };
    toast(rx.needsTarget ? '대상(적)을 선택하세요' : '자원을 지불하세요');
    render();
  },
  tapCard(playerUid, uid){
    // 이벤트 버림 선택 모드 (법률 업무 등 — 가변, 최대 N장, 확정 버튼)
    if (sel.mode === 'eventDiscard' && sel.player === playerUid){
      if (uid === sel.cardUid) return;  // 자기 자신은 못 버림
      const i = sel.picks.indexOf(uid);
      if (i >= 0) sel.picks.splice(i, 1);
      else if (sel.picks.length < sel.max) sel.picks.push(uid);
      render(); return;
    }
    // 방패 던지기 버림 선택 (X장 → 확정 시 X명 적 선택으로 전환)
    if (sel.mode === 'stDiscard' && sel.player === playerUid){
      if (uid === sel.cardUid) return;
      // spendXEnergy: 에너지(또는 와일드) 자원 아이콘 카드만 지불 가능
      if (sel.flow === 'spendXEnergy'){
        const hc = pl.hand.find(c => c.uid === uid);
        const ic = hc ? MC.resourceIconsOf(hc) : null;
        if (!ic || (ic.energy || 0) + (ic.wild || 0) <= 0){ toast('⚡에너지 자원 카드만 지불할 수 있습니다'); return; }
      }
      const i = sel.picks.indexOf(uid);
      if (i >= 0) sel.picks.splice(i, 1);
      else if (sel.picks.length < sel.max) sel.picks.push(uid);
      render(); return;
    }
    // 능력 비용: 버릴 카드 선택 모드
    if (sel.mode === 'abilityDiscard' && sel.player === playerUid){
      const i = sel.picks.indexOf(uid);
      if (i >= 0) sel.picks.splice(i, 1);        // 선택 해제
      else if (sel.picks.length < sel.need) sel.picks.push(uid);
      // 필요 수 채우면 실행
      if (sel.picks.length === sel.need){
        const picks = sel.picks.slice(), pUid = sel.player, cUid = sel.cardUid;
        sel = { mode:null };
        UI._fireCardAbility(pUid, cUid, picks);
        return;
      }
      render(); return;
    }
    if (G.pending){ toast('방어 선언부터 해결하세요', true); return; }
    const pl = G.players.find(p=>p.uid===playerUid);
    const c = pl.hand.find(x=>x.uid===uid);
    if (c && c.type === 'resource'){ toast('자원 카드는 다른 카드의 결제에 사용하세요'); return; }
    openPay(playerUid, uid);
  },
  payToggle(key){
    const i = pay.elements.findIndex(el => (el.kind+':'+(el.uid||el.id)) === key);
    if (i >= 0) pay.elements.splice(i,1);
    else {
      const kind = key.slice(0, key.indexOf(':')), id = key.slice(key.indexOf(':')+1);
      pay.elements.push(kind==='hand' ? {kind:'hand',uid:id} : kind==='card' ? {kind:'card',uid:id} : {kind:'ability',id});
    }
    render();
  },
  payAuto(){
    const pl = G.players.find(p=>p.uid===pay.player);
    const card = pl.hand.find(c=>c.uid===pay.cardUid);
    const picks = autoSelect(pl, card, MC.playCostOf(G, pl, card));
    if (!picks){ toast('자원이 부족합니다', true); return; }
    pay.elements = picks; render();
  },
  payCancel(){ pay = null; render(); },
  payConfirm(){
    if (pay.aarReaction){
      // 공격 후 반응 자원 지불 완료 (Jarnbjorn) → 반응 발동 (대상 + 결제)
      const playerUid = pay.player, els = pay.elements, targets = pay.aarTargets || [];
      pay = null;
      act({ type:'resolveAfterAttackReaction', player: playerUid, mode:'activate', targets, payment: els });
      render(); return;
    }
    if (pay.identityPay){
      // 신분 액션 에너지 지불 (캡틴 마블 Rechannel 등)
      const playerUid = pay.player, els = pay.elements, iaVfx = pay.iaVfx;
      const idEl = document.querySelector(`[data-vuid="${playerUid}"]`);
      pay = null;
      const ok = act({ type:'useIdentityAction', player: playerUid, payment: els });
      if (ok && iaVfx && idEl) setTimeout(() => MC.playVfx(iaVfx, { el: idEl, toRect: idEl.getBoundingClientRect() }), 60);
      render(); return;
    }
    if (pay.abilityPay){
      // 능력 자원 지불 (초인법 사무소 등 — 조우 부착물 상아 뿔 포함)
      const playerUid = pay.player, cardUid = pay.cardUid, els = pay.elements;
      const el = document.querySelector(`[data-vuid="${cardUid}"]`);
      const idEl = document.querySelector(`[data-vuid="${playerUid}"]`);
      const abCard = findAbilityCardUI(G.players.find(p=>p.uid===playerUid), cardUid);
      const def = abCard && MC.cardDef(abCard.defCode);
      const vfxAbility = def && def.vfx && def.vfx.ability;
      pay = null;
      const ok = act({ type:'useCardAbility', player: playerUid, cardUid, payment: els });
      // 능력 연출 (초인법 사무소=legalWork 등): 신분 카드 스코프
      if (ok && vfxAbility && idEl) MC.playVfx(vfxAbility, { el: idEl });
      render(); return;
    }
    if (pay.counterCharge){
      // 에너지 채널 충전 — 플레이 영역 카드, 지불 요소만큼 카운터
      const playerUid = pay.player, cardUid = pay.cardUid, els = pay.elements;
      pay = null;
      act({ type:'counterCharge', player: playerUid, cardUid, payment: els });
      render(); return;
    }
    const pl = G.players.find(p=>p.uid===pay.player);
    const card = (pay.fromDiscard ? pl.discard : pl.hand).find(c=>c.uid===pay.cardUid);
    if (pay.interrupt){
      const playerUid = pay.player, cardUid = pay.cardUid, els = pay.elements;
      pay = null;
      UI._fireInterrupt(playerUid, cardUid, els);
      return;
    }
    const at = MC.cardDef(card.defCode).attachTarget;
    const needsEnemyTarget = at === 'minion' || at === 'enemy';
    // 카드 버림 선택 이벤트 (법률 업무 등): 결제 후 버림 카드 선택 모드로
    const dft = card.effects && card.effects.find(e => e.fx === 'discardForThreat');
    if (dft){
      sel = { mode:'eventDiscard', player: pay.player, cardUid: pay.cardUid, payment: pay.elements,
              max: dft.max || 5, picks: [], perCard: dft.perCard || 1 };
      pay = null;
      toast(`버릴 카드를 선택하세요 (최대 ${dft.max||5}장) — 버린 수만큼 위협 제거`); render(); return;
    }
    // 다중 선택 흐름 (방패 던지기): X장 버림 → X명 적 선택
    const uiFlow = MC.cardDef(card.defCode).uiFlow;
    if (uiFlow === 'discardThenMultiTarget'){
      const maxDiscard = pl.hand.filter(c => c.uid !== pay.cardUid).length;
      sel = { mode:'stDiscard', player: pay.player, cardUid: pay.cardUid, payment: pay.elements,
              picks: [], max: maxDiscard, flow:'discardThenMultiTarget' };
      pay = null;
      toast('버릴 카드를 선택하세요 (버린 수 = 공격할 적 수) — 확정을 누르세요'); render(); return;
    }
    if (uiFlow === 'spendXEnergy'){
      // 에너지(또는 와일드) 자원 아이콘을 가진 손패 카드만 지불 가능 (X = 지불 수 = 피해량)
      const maxE = pl.hand.filter(c => {
        if (c.uid === pay.cardUid) return false;
        const ic = MC.resourceIconsOf(c); return (ic.energy || 0) + (ic.wild || 0) > 0;
      }).length;
      sel = { mode:'stDiscard', flow:'spendXEnergy', player: pay.player, cardUid: pay.cardUid,
              payment: pay.elements, picks: [], max: maxE };
      pay = null;
      toast('지불할 ⚡에너지 자원 카드를 선택하세요 (X = 피해량) — 확정을 누르세요'); render(); return;
    }
    if (needsEnemyTarget || (card.effects && card.effects.some(e=>e.target==='chosen'))){
      sel = { mode:'target', cardUid: pay.cardUid, cardDefCode: card.defCode, player: pay.player, payment: pay.elements,
              attachMode: needsEnemyTarget };
      pay = null;
      toast(needsEnemyTarget ? '부착 대상: 하수인을 탭' : '대상 선택: 빌런 카드 또는 하수인을 탭'); render(); return;
    }
    // 저지 이벤트 스킴 선택: removeThreat가 스킴 미지정이고 사이드스킴이 있으면 대상 탭
    const needsScheme = G.sideSchemes.length > 0 && card.effects &&
      card.effects.some(e => e.fx === 'removeThreat' && !e.scheme && !e.allSchemes);
    if (needsScheme){
      sel = { mode:'schemePick', purpose:'event', player: pay.player, cardUid: pay.cardUid, payment: pay.elements };
      pay = null;
      toast('저지할 스킴을 탭하세요 (메인 또는 사이드)'); render(); return;
    }
    const a = { type:'playCard', player: pay.player, cardUid: pay.cardUid, payment: pay.elements, fromDiscard: pay.fromDiscard };
    // 메인 스킴 부착 업그레이드(Under Surveillance 06031 등): 메인 스킴은 단일이라 자동 타겟
    if (at === 'mainScheme' && G.mainScheme) a.targets = [G.mainScheme.uid];
    // 자원 생성 카드(페퍼 포츠 등)가 결제에 쓰였으면 그 카드의 resource 연출 재생 준비
    const genVfxList = (pay.elements||[]).filter(el => el.kind === 'card').map(el => {
      const gc = [...G.players.find(p=>p.uid===pay.player).playArea.supports,
                  ...G.players.find(p=>p.uid===pay.player).playArea.upgrades,
                  ...G.players.find(p=>p.uid===pay.player).playArea.allies].find(c=>c.uid===el.uid);
      const gdef = gc && MC.cardDef(gc.defCode);
      return gdef && gdef.vfx && gdef.vfx.resource ? { uid: el.uid, vfx: gdef.vfx.resource } : null;
    }).filter(Boolean);
    const wasDefenseInterrupt = pay.defenseInterrupt;
    const defCode = card.defCode;
    // 이중인격 등 폼 전환 이벤트: 렌더 지연 디스패치 (formFlip 패턴 — 상태 먼저, 연출 후 렌더)
    const isFormFlipFx = card.effects && card.effects.some(e => e.fx === 'splitPersonality');
    const vfxFormChange = MC.cardDef(defCode).vfx && MC.cardDef(defCode).vfx.formChange;
    if (isFormFlipFx && vfxFormChange){
      const pUid = pay.player;
      const idEl = document.querySelector(`[data-vuid="${pUid}"]`);
      pay = null;
      try { MC.dispatch(G, a); saveGame(); }
      catch(e){ toast(e.message, true); render(); return; }
      const pl2 = G.players.find(p=>p.uid===pUid);
      const newFace = pl2.form === 'hero' ? pl2.heroCode : pl2.aeCode;
      if (idEl) MC.playVfx(vfxFormChange, { el: idEl, newImgUrl: imgUrl(newFace), onDone: () => render() });
      else render();
      return;
    }
    const vfxDef = MC.cardDef(defCode).vfx && MC.cardDef(defCode).vfx.defense;
    const vfxAtk = MC.cardDef(defCode).vfx && (MC.cardDef(defCode).vfx.basicAttack || MC.cardDef(defCode).vfx.play || MC.cardDef(defCode).vfx.basicThwart);
    const isAoE = card.effects && card.effects.some(e => e.target === 'allEnemies');
    const isSelfFx = card.effects && card.effects.some(e => e.fx === 'readySelf' || e.fx === 'discardForThreat');
    const cardEl = document.querySelector(`[data-vuid="${pay.player}"]`);
    const fromRect = cardEl && cardEl.getBoundingClientRect();
    const genVfxEls = genVfxList.map(g => ({ vfx: g.vfx, el: document.querySelector(`[data-vuid="${g.uid}"]`) })).filter(g => g.el);
    pay = null;
    const ok = act(a);
    // 자원 생성 카드(페퍼 포츠 등) 연출: 결제에 쓰인 카드 위에서 재생
    if (ok) genVfxEls.forEach((g, i) => setTimeout(() => MC.playVfx(g.vfx, { el: g.el }), i * 120));
    // 방어 인터럽트 연출 (Backflip 등): 플레이어 신분 카드 위에서 재생
    if (ok && wasDefenseInterrupt && vfxDef && cardEl) MC.playVfx(vfxDef, { el: cardEl });
    // 광역 공격 이벤트 연출 (짓밟기 등): 발동자 위치 기준 전역 연출
    if (ok && isAoE && vfxAtk && fromRect) MC.playVfx(vfxAtk, { fromRect });
    // 자기 대상 이벤트 연출 (원투 펀치 등): 발동자 카드 위에서 재생
    else if (ok && isSelfFx && vfxAtk && cardEl) MC.playVfx(vfxAtk, { el: cardEl });
  },
  pickTarget(uid){
    // 적 대상 선택 (chooseEnemy pending) — 선택한 적에게 then 효과 실행. 범용.
    if (G.pending && G.pending.kind === 'chooseEnemy'){
      if (!(G.pending.enemyUids||[]).includes(uid)) return;
      const toEl = document.querySelector(`[data-vuid="${uid}"]`);
      const toRect = toEl && toEl.getBoundingClientRect();
      const ok = act({ type:'resolveChooseEnemy', uid });
      if (ok && G.fxCardEffect && G.fxCardEffect.vfx){
        MC.playVfx(G.fxCardEffect.vfx, { toEl, toRect, el: toEl, quote: G.fxCardEffect.quote });
        G.fxCardEffect = null;
      }
      render(); return;
    }
    if (sel.mode === 'stTarget'){
      // 방패 던지기: 서로 다른 적 X명 수집 → X번째에 playCard 디스패치
      if (sel.targets.includes(uid)){ toast('이미 선택한 적입니다', true); return; }
      sel.targets.push(uid);
      if (sel.targets.length >= sel.need){
        const pUid = sel.player, cUid = sel.cardUid, payment = sel.payment;
        const disc = sel.discardUids.slice(), tgts = sel.targets.slice();
        const cdef = MC.cardDef((G.players.find(p=>p.uid===pUid).hand.find(c=>c.uid===cUid)||{}).defCode);
        const vfxName = cdef && cdef.vfx && cdef.vfx.event;
        const fromEl = document.querySelector(`[data-vuid="${pUid}"]`);
        sel = { mode:null };
        const ok = act({ type:'playCard', player: pUid, cardUid: cUid, payment, discardUids: disc, targets: tgts });
        if (ok && vfxName){
          tgts.forEach(tu => { const te = document.querySelector(`[data-vuid="${tu}"]`); const tr = te && te.getBoundingClientRect(); const fr = fromEl && fromEl.getBoundingClientRect(); if (tr) MC.playVfx(vfxName, { fromRect: fr, toRect: tr, targetEl: te }); });
        }
        render();
      } else {
        toast(`적 ${sel.need - sel.targets.length}명 더 선택`); render();
      }
      return;
    }
    if (sel.mode === 'abilityTarget'){
      // 대상 지정 활성 능력 (동력 건틀릿 등): 선택한 적에게 능력 발동 + 조건부 연출
      const playerUid = sel.player, cardUid = sel.cardUid;
      const pl = G.players.find(p=>p.uid===playerUid);
      const def = MC.cardDef([...pl.playArea.upgrades, ...pl.playArea.supports, ...pl.playArea.allies].find(c=>c.uid===cardUid).defCode);
      const el = document.querySelector(`[data-vuid="${cardUid}"]`);
      const toEl = document.querySelector(`[data-vuid="${uid}"]`);
      const fromRect = el && el.getBoundingClientRect();
      const toRect = toEl && toEl.getBoundingClientRect();
      sel = { mode:null, cardUid:null, player:null };
      const ok = act({ type:'useCardAbility', player: playerUid, cardUid, payment: [], targets:[uid] });
      if (ok){
        const vfxAerial = def.vfx && def.vfx.abilityAerial;
        const useAerial = vfxAerial && MC.playerHasTrait(G, pl, 'aerial');
        const vfxName = useAerial ? vfxAerial : (def.vfx && def.vfx.ability);
        if (vfxName && fromRect && toRect) MC.playVfx(vfxName, { fromRect, toRect, el });
      }
      render(); return;
    }
    if (sel.mode === 'counterFire'){
      const fromEl = document.querySelector(`[data-vuid="${sel.player}"]`);
      const toEl = document.querySelector(`[data-vuid="${uid}"]`);
      const fromRect = fromEl && fromEl.getBoundingClientRect();
      const toRect = toEl && toEl.getBoundingClientRect();
      const cardUid = sel.cardUid, pUid = sel.player;
      const cdef = MC.cardDef((G.players.find(p=>p.uid===pUid).playArea.upgrades
        .concat(G.players.find(p=>p.uid===pUid).playArea.supports)
        .find(c=>c.uid===cardUid)||{}).defCode);
      const vfxName = cdef && cdef.vfx && cdef.vfx.fire;
      const ok = act({ type:'counterFire', player: pUid, cardUid, targetUid: uid });
      sel = { mode:null, cardUid:null, player:null };
      if (ok && vfxName && fromRect && toRect) MC.playVfx(vfxName, { fromRect, toRect, targetEl: toEl });
      render(); return;
    }
    if (sel.mode === 'aarTarget'){
      // 공격 후 반응 대상(적) 선택 (Jarnbjorn) → 자원 지불 팝업 or 바로 발동
      const player = sel.player, cardUid = sel.cardUid, cost = sel.cost;
      const targets = [uid];
      const card = MC.findByUid(G, cardUid);
      if (cost){
        const ctype = Object.keys(cost)[0];
        pay = { player, aarReaction: true, payCost: { type: ctype, count: cost[ctype] },
                aarTargets: targets, aarName: ((card && MC.cardDef(card.defCode).name) || '') + ' — 반응', elements: [] };
        sel = { mode:null };
        toast(MC.T(ctype) + ' 자원을 지불하세요'); render(); return;
      }
      act({ type:'resolveAfterAttackReaction', player, mode:'activate', targets });
      sel = { mode:null }; render(); return;
    }
    if (sel.mode === 'target'){
      const pl = G.players.find(p=>p.uid===sel.player);
      const cardDef = MC.cardDef(sel.cardDefCode);
      const isAttach = sel.attachMode;
      // 공격 이벤트 → basicAttack 연출 / 부착 → install(attachPlace) 연출
      // 조건부 연출: Aerial 등 상태에 따라 다른 연출(초음속 펀치: 지상 4 / 비행 8)
      const vfxAerial = cardDef.vfx && cardDef.vfx.basicAttackAerial;
      const hasAerial = vfxAerial && MC.playerHasTrait(G, pl, 'aerial');
      const vfxName = isAttach
        ? (cardDef.vfx && cardDef.vfx.install)
        : (hasAerial ? vfxAerial : (cardDef.vfx && cardDef.vfx.basicAttack));
      const fromEl = document.querySelector(`[data-vuid="${sel.player}"]`);
      const toEl = document.querySelector(`[data-vuid="${uid}"]`);
      const fromRect = fromEl && fromEl.getBoundingClientRect();
      const toRect = toEl && toEl.getBoundingClientRect();
      const targetEl = toEl;
      const cardDefCode = sel.cardDefCode;
      const ok = act({ type:'playCard', player: sel.player, cardUid: sel.cardUid, payment: sel.payment, targets:[uid] });
      sel = { mode:null, cardUid:null, player:null };
      if (ok && vfxName){
        if (isAttach && toRect) MC.playVfx(vfxName, { toRect, targetEl, imgUrl: imgUrl(cardDefCode) });
        else if (fromRect && toRect) MC.playVfx(vfxName, { fromRect, toRect, targetEl });
      }
      render(); return;
    }
    if (sel.mode === 'attack'){
      // 동료 공격: sel.allyUid가 있으면 그 동료가 선택한 대상(빌런/하수인)을 공격
      if (sel.allyUid){
        const playerUid = sel.player, allyUid = sel.allyUid;
        const pl2 = G.players.find(p=>p.uid===playerUid);
        const ally = pl2 && pl2.playArea.allies.find(a=>a.uid===allyUid);
        const adef = ally && MC.cardDef(ally.defCode);
        const fromEl = document.querySelector(`[data-vuid="${allyUid}"]`);
        const toEl = document.querySelector(`[data-vuid="${uid}"]`);
        const fromRect = fromEl && fromEl.getBoundingClientRect();
        const toRect = toEl && toEl.getBoundingClientRect();
        sel = { mode:null, cardUid:null, player:null };
        const ok = act({ type:'allyAttack', player:playerUid, allyUid, targetUid: uid });
        if (ok && !G.pending){
          const vfxName = (adef && adef.vfx && adef.vfx.basicAttack) || 'strike';
          if (vfxName) MC.playVfx(vfxName, { el: toEl, targetEl: toEl, toRect, fromRect });
        }
        render(); return;
      }
      const atkPlayer = sel.player;
      // 연출 좌표 선캡처 (대상 처치로 DOM이 사라져도 임팩트 위치 유지)
      const fromEl = document.querySelector(`[data-vuid="${atkPlayer}"]`);
      const toEl = document.querySelector(`[data-vuid="${uid}"]`);
      const fromRect = fromEl && fromEl.getBoundingClientRect();
      const toRect = toEl && toEl.getBoundingClientRect();
      // 강제 반응 카드(초인적인 힘 등) 발동 감지: 공격 전 플레이 영역 스냅샷
      const preAtk = G.players.find(p=>p.uid===atkPlayer);
      const forcedBefore = preAtk ? preAtk.playArea.upgrades
        .filter(c => (MC.cardDef(c.defCode).afterBasicAttack))
        .map(c => ({ uid:c.uid, vfx: MC.cardDef(c.defCode).vfx && MC.cardDef(c.defCode).vfx.basicAttack })) : [];
      const ok = act({ type:'basicAttack', player: atkPlayer, targetUid: uid });
      sel = { mode:null, cardUid:null, player:null };
      if (ok){
        const pl = G.players.find(p=>p.uid===atkPlayer);
        const fdef = pl && MC.cardDef(pl.heroCode);
        // 전용 기본공격 연출이 있으면 사용, 없으면 범용 strike 폴백 (모든 영웅 최소 타격 연출 보장)
        const vfxName = (fdef && fdef.vfx && fdef.vfx.basicAttack) || 'strike';
        // ※ 연출마다 앵커가 el(대상 위) / fromRect·toRect(궤적) 로 제각각 → 대상 요소·좌표를 모두 전달
        if (vfxName) MC.playVfx(vfxName, { el: toEl, targetEl: toEl, toRect, fromRect });
        // 강제 반응으로 버려진 카드의 연출(초인적인 힘=superStrength)을 대상 위에 재생
        const fired = forcedBefore.find(f => !pl.playArea.upgrades.some(c=>c.uid===f.uid) && f.vfx);
        if (fired && toRect) setTimeout(() => MC.playVfx(fired.vfx, { el: fromEl, toRect }), 260);
      }
      render(); return;
    }
  },
  attackMenu(playerUid){
    if (G.pending){ toast('방어 선언부터 해결하세요', true); return; }
    sel = { mode:'attack', cardUid:null, player: playerUid };
    toast('공격 대상: 빌런 카드 또는 하수인을 탭'); render();
  },
  allyAct(playerUid, allyUid, kind){
    const pl = G.players.find(p=>p.uid===playerUid);
    const ally = pl && pl.playArea.allies.find(a=>a.uid===allyUid);
    const adef = ally && MC.cardDef(ally.defCode);
    // 연출 좌표 선캡처 (대상 소멸 대응)
    const fromEl = document.querySelector(`[data-vuid="${allyUid}"]`);
    if (kind === 'attack'){
      // 대상 선택 모드 진입 (빌런 또는 교전 하수인 탭) — 히어로 기본공격과 동일 UX.
      //   엔진 allyAttack이 수호 하수인 교전 시 빌런 공격 차단 등 규칙 검증.
      sel = { mode:'attack', allyUid, player: playerUid };
      toast('동료 공격 대상: 빌런 카드 또는 하수인을 탭'); render(); return;
    } else {
      // 사이드스킴 존재 시 스킴 선택 모드 (메인/사이드 탭)
      if (G.sideSchemes.length){
        sel = { mode:'schemePick', purpose:'allyThwart', player: playerUid, allyUid };
        toast('동료가 저지할 스킴을 탭하세요'); render(); return;
      }
      UI._doAllyThwart(playerUid, allyUid, 'main');
    }
  },
  _doAllyThwart(playerUid, allyUid, scheme){
    if ((scheme === 'main' || !scheme) && MC.hasCrisisScheme(G)){
      toast('위기(Crisis) 사이드 스킴을 먼저 처치해야 메인 스킴을 저지할 수 있어요', true);
      return;
    }
    const pl = G.players.find(p=>p.uid===playerUid);
    const ally = pl && pl.playArea.allies.find(a=>a.uid===allyUid);
    const adef = ally && MC.cardDef(ally.defCode);
    const fromEl = document.querySelector(`[data-vuid="${allyUid}"]`);
    const schemeUid = scheme === 'main' ? (G.mainScheme && G.mainScheme.uid) : scheme;
    const toEl = document.querySelector(`[data-vuid="${schemeUid}"]`);
    const fromRect = fromEl && fromEl.getBoundingClientRect();
    const toRect = toEl && toEl.getBoundingClientRect();
    const ok = act({ type:'allyThwart', player:playerUid, allyUid, scheme });
    const vfxName = adef && adef.vfx && adef.vfx.basicThwart;
    if (ok && vfxName && fromRect && toRect) MC.playVfx(vfxName, { fromRect, toRect });
  },
  info(defCode){
    const def = MC.cardDef(defCode);
    if (!def) return;
    // 돋보기 표시 = 효과 텍스트 + 플레이버만 (공용 parseCardText — 공개 모달과 동일 규칙).
    const { effectText, flavorText } = parseCardText(def);
    // 양면 전환: 메인 스킴 a↔b, 신분 hero↔alter-ego
    let otherCode = null, otherLabel = null;
    if (def.type === 'main_scheme'){
      const cand = /a$/.test(defCode) ? defCode.replace(/a$/,'b') : defCode.replace(/b$/,'a');
      if (cand !== defCode && MC.cardDef(cand)){
        otherCode = cand;
        otherLabel = (MC.cardDef(cand).stage || (/a$/.test(cand)?'1A':'1B')) + '면 보기';
      }
    } else if (def.backLink && MC.cardDef(def.backLink)){
      otherCode = def.backLink;
      otherLabel = MC.cardDef(def.backLink).type === 'hero' ? '영웅면 보기' : '알터에고면 보기';
    }
    document.querySelectorAll('.overlay.infobox').forEach(e=>e.remove()); // 면 전환 시 중첩 방지
    const ov = document.createElement('div');
    ov.className = 'overlay infobox';
    ov.onclick = () => ov.remove();
    ov.innerHTML = `<div class="overlay-card" onclick="event.stopPropagation()">
      <img src="${imgUrl(defCode)}" onerror="this.style.display='none'">
      <div class="overlay-text"><b style="font-size:17px">${esc(def.name)}</b>
        ${def.stage!==undefined?`<span class="stagechip">${esc(def.stage)}</span>`:''}
        ${def.nameEn?`<span class="note"> ${esc(def.nameEn)}</span>`:''}
        ${def.todoFx?' <span class="badge todo" style="position:static">능력 수동 처리</span>':''}
        <div class="statline">${[
          def.cost!==undefined?'비용 '+def.cost:'',
          def.attack!==undefined?'ATK '+def.attack:'',
          def.thwart!==undefined?'THW '+def.thwart:'',
          def.defense!==undefined?'DEF '+def.defense:'',
          def.hp!==undefined?'HP '+def.hp:'',
          def.boost!==undefined?'증폭 '+def.boost:'',
        ].filter(Boolean).join(' · ')}</div>
        ${effectText?`<pre>${esc(effectText)}</pre>`:'<pre>(룰 텍스트 없음)</pre>'}
        ${flavorText?`<div class="flavor">"${esc(flavorText)}"</div>`:''}</div>
      <div class="btnrow">
        ${otherCode?`<button class="btn gold" onclick="event.stopPropagation();UI.info('${otherCode}')">↔ ${esc(otherLabel)}</button>`:''}
        <button class="btn" onclick="this.closest('.overlay').remove()">닫기</button>
      </div></div>`;
    document.body.appendChild(ov);
  },
  pileOpen(which, playerUid){
    if (which === 'enc') pileView = { title:'조우 버림 더미', cards: G.encounterDiscard };
    else if (which === 'invocation'){
      const pl = G.players.find(p=>p.uid===playerUid);
      if (!pl || !pl.invocationDeck) return;
      // 발동 덱은 공식상 뒷면(순서 비공개)이나, 구성 확인용으로 발동 덱 + 발동 버림을 함께 표시.
      const cards = pl.invocationDeck.concat(pl.invocationDiscard || []);
      pileView = { title: MC.heroFace(G,pl).name + ' 발동 덱 ✦ (' + pl.invocationDeck.length + '장 · 버림 ' + (pl.invocationDiscard||[]).length + ')', cards, playerUid: pl.uid, invocation:true };
    }
    else if (which === 'weapon'){
      if (!G.experimentalWeaponsDeck) return;
      // 실험 무기 덱(뒷면·비공개)이나 구성 확인용으로 남은 덱 + 이미 나온 무기를 함께 표시.
      const cards = G.experimentalWeaponsDeck.concat(G.experimentalWeaponsDiscard || []);
      pileView = { title: '실험 무기 덱 ⚙ (' + G.experimentalWeaponsDeck.length + '장 남음 · 사용 ' + (G.experimentalWeaponsDiscard||[]).length + ')', cards, weapon:true };
    }
    else {
      const pl = G.players.find(p=>p.uid===which);
      if (!pl) return;
      pileView = { title: MC.heroFace(G,pl).name + ' 버림 더미', cards: pl.discard, playerUid: pl.uid };
    }
    render();
  },
  pileClose(){ pileView = null; render(); },
  // 캠페인 코믹스 오버레이 — 룰북 PDF의 지정 페이지를 PDF.js로 렌더 + 한글 장면 요약 캡션.
  // 원본 이미지는 링크 참조(재현 아님), 캡션은 장면 설명 요약.
  async showComic(scenarioKey, phase){
    const sc = MC.SCENARIOS[scenarioKey];
    if (!sc || !sc.rulebookPdf) return;
    const pages = phase === 'defeat' ? (sc.comicDefeat || []) : (sc.comicIntro || []);
    const caps  = phase === 'defeat' ? (sc.comicDefeatCaptions || []) : (sc.comicIntroCaptions || []);
    if (!pages.length) return;
    const ov = document.getElementById('comic-overlay');
    if (!ov) return;
    ov.style.display = 'flex';
    ov.innerHTML = '<div class="comic-loading">코믹스를 불러오는 중…</div>';
    const lib = window.pdfjsLib;
    if (!lib){ ov.innerHTML = '<div class="comic-loading">PDF.js를 불러오지 못했어요 (오프라인일 수 있어요).<br><button class="btn" onclick="document.getElementById(\'comic-overlay\').style.display=\'none\'">닫기</button></div>'; return; }
    try { lib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'; } catch(e){}
    let pdf;
    try { pdf = await lib.getDocument(sc.rulebookPdf).promise; }
    catch(e){ ov.innerHTML = '<div class="comic-loading">룰북 PDF를 불러오지 못했어요.<br><button class="btn" onclick="document.getElementById(\'comic-overlay\').style.display=\'none\'">닫기</button></div>'; return; }
    let idx = 0;
    async function renderIdx(){
      let canvas;
      try {
        const page = await pdf.getPage(pages[idx]);
        const vp = page.getViewport({ scale: 1.6 });
        canvas = document.createElement('canvas');
        canvas.className = 'comic-canvas';
        canvas.width = vp.width; canvas.height = vp.height;
        await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
      } catch(e){ ov.style.display = 'none'; return; }
      ov.innerHTML = '';
      const stage = document.createElement('div'); stage.className = 'comic-stage';
      stage.appendChild(canvas);
      if (caps[idx]){ const cap = document.createElement('div'); cap.className = 'comic-caption'; cap.innerHTML = caps[idx]; stage.appendChild(cap); }
      const nav = document.createElement('div'); nav.className = 'comic-nav';
      if (pages.length > 1){ const pn = document.createElement('span'); pn.className = 'comic-pageno'; pn.textContent = (idx+1) + ' / ' + pages.length; nav.appendChild(pn); }
      const mainBtn = document.createElement('button'); mainBtn.className = 'btn';
      mainBtn.textContent = idx < pages.length - 1 ? '다음 ▶' : '닫기';
      mainBtn.onclick = () => { if (idx < pages.length - 1){ idx++; renderIdx(); } else ov.style.display = 'none'; };
      nav.appendChild(mainBtn);
      if (idx === 0 && pages.length > 1){ const sk = document.createElement('button'); sk.className = 'btn ghost'; sk.textContent = '건너뛰기'; sk.onclick = () => { ov.style.display = 'none'; }; nav.appendChild(sk); }
      stage.appendChild(nav);
      ov.appendChild(stage);
    }
    renderIdx();
  },
  // 버린더미에서 플레이 (록조 등 playableFromDiscard): pileView 닫고 결제 팝업(fromDiscard) 오픈
  playFromDiscard(playerUid, cardUid){
    pileView = null;
    openPay(playerUid, cardUid, true);
  },
  zoneTap(which){
    if (which === 'villain' && G.pending && G.pending.kind === 'chooseEnemy' && (G.pending.enemyUids||[]).includes(G.villain.uid)){ UI.pickTarget(G.villain.uid); return; }
    if (which === 'villain' && (sel.mode==='attack'||sel.mode==='target'||sel.mode==='counterFire'||sel.mode==='abilityTarget')) UI.pickTarget(G.villain.uid);
  },
};
global.UI = UI;

document.addEventListener('DOMContentLoaded', render);
})(typeof window !== 'undefined' ? window : globalThis);
