/* ═══════════════════════════════════════════════════════════════
   mc_7_core.js — 샤드 7/7 : 게임 상태 · 시드 RNG · 액션 디스패치
   baseFields · 카드 레지스트리/인스턴스 · 플레이어 액션 · 승패
   ★ 멀티플레이 계약: 엔진 100% 결정적. 같은 (seed+액션 로그)=같은 상태.
     RNG는 반드시 "액션 실행 내부"에서만 소모 (MC.rand(G)). Math.random 금지.
   ★ 액션 규율: 검증 먼저, 변이 나중. 검증 실패 throw 시 상태 무변이·로그 미기록.
   IIFE는 mc_1_terms.js에서 열림 → 여기서 닫는다.
   ═══════════════════════════════════════════════════════════════ */

/* ── 시드 RNG (mulberry32) ── */
function rand(G){
  let t = (G.rngState += 0x6D2B79F5);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
function shuffle(G, arr){
  for (let i = arr.length - 1; i > 0; i--){
    const j = Math.floor(rand(G) * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/* ── 카드 레지스트리 ── */
const CARDS = {};
const baseFields = [
  'code','name','nameEn','type','side','faction','aspect','traits','unique',
  'cost','resources','attack','thwart','defense','recover','handSize','hp','scheme',
  'atkCost','thwCost',
  'boost','baseThreat','baseThreatPerPlayer','maxThreat','maxThreatPerPlayer','backLink','experimentalWeaponsDeck','piercingWhileWeapon',
  'gainsEnvironmentTraits','grantsElementTraits','delayPerVillainPhase','testPerVillainPhase','singleEnvironment','surge','onDefeat','envUndefendedResponse','villainActivateResponse','onHeroFormResponse','setupText','captive','villainDamageReflect','removeAfterReflect',
  'toughness','retaliate','guard','patrol','stalwart','piercing','overkill',
  'invulnWhileOtherMinion','invulnUnlessNullified','minionAbility',
  'ranged','aerial','quickstrike','surge','peril','hazard','accelIcons','accelFrom','crisis','whileEngagedCannotThwart',
  'hinder','incite',
  'uses','permanent','restricted','grantsArrowRanged','costReduction','gloryOnMinionDefeat',
  'whenPlayed','response','interrupt','forcedResponse','forcedInterrupt','attackInterrupt','afterBasicAttack','afterAttack','afterThwart','attackDamagedResponse',
  'interruptOn','interruptEffect','activatedAbility','activatedAbilities','whenAttachedDefeated','attachTarget','attachStats','grantsExtraBoost','absorbsVillainDamage','piercingWhileWeapon','removeAbility','attackDamagedEffects','grantsPiercing','quickstrike','keywords','afterUndefendedAttack',
  'attachAttackInterrupt','attackInitiateInterrupt','maxPerTarget','maxPerPlayer','playableFromDiscard','grantsMinionGuard',
  'resourceGenerator','statMod','grantsTrait','defenseInterrupt','defenseInterruptEvent','counterAbility','playForm','playCondition','dynamicHandSize','dynamicStat','allyLimitBonus','onFormChange','identityAction','onMinionEngage','afterEventResponse','afterAttackReaction','eventBoost','defeatInterrupt','rapidResponse','threatPrevent','hpBonus','onSetup','forcedThreatChoice','threatCannotRemove','special','eventScheme','resourceAbility','livingLegend','uiFlow','reviveOnTreachery','boostStarOnDamage','afterPlayTrait','preparationTrigger','needsEnemyTarget','minionStatScale','invocationSpecial','entersWithCounters','entersWithCountersPerHero','attackForcedInterrupt','useCounter','afterDefendNoDamage','onTurnEnd','onFormChangeDiscard',
  'form','altForm','pairedEnv','noAttack','noScheme','attackToCounter','schemeToCounter','damageToCounter','attackThreatOnDamage',   // 양면 폼전환 빌런(그린 고블린 Risky Business)
  'whenRevealed','whenDefeated','whenCompleted','setup',
  'villainPhaseStart','playerPhaseStart','endOfPhase','endOfRound','onFormChange',
  'effects','whenRevealedByForm','whenRevealedByPlayerForm','boostStarEffect','whenRevealedEffects','whenCompletedEffects','attackResponseEffects','whenDefeatedEffects','attackDamagedEffects',
]; // 텍스트/이미지류(textKo·image·flavor 등)는 정의 전용 — cardDef()로 조회
/* 능력 등록 창구: 마이그레이션된 데이터 정의에 effects/훅을 부착 (todoFx 해제) */
/* defineCardFx(code, fields): code는 문자열 또는 문자열 배열.
   중복/리프린트 카드(같은 효과, 다른 slug)는 배열로 한 번에 정의 → fx 통합(단일 소스). */
function defineCardFx(code, fields){
  const codes = Array.isArray(code) ? code : [code];
  for (const c of codes){
    const def = CARDS[c];
    if (!def) throw new Error('[defineCardFx] 미등록 카드: ' + c);
    Object.assign(def, fields);
    delete def.todoFx;
  }
}
/* aliasCardFx(aliasCode, sourceCode): 이미 정의된 source의 fx/능력 필드를 alias로 복사.
   다른 파일에 정의된 리프린트를 통합할 때 사용(카드 고유 식별 필드는 유지). */
const FX_ALIAS_SKIP = new Set(['code','name','nameEn','mcode','image','flavor','hero','aspect','copies','deckLimit','unique','cost','resources','attack','thwart','hp','scheme','atkCost','thwCost','traits','type','side','boost']);
function aliasCardFx(aliasCode, sourceCode){
  const src = CARDS[sourceCode], dst = CARDS[aliasCode];
  if (!src) throw new Error('[aliasCardFx] 원본 미등록: ' + sourceCode);
  if (!dst) throw new Error('[aliasCardFx] 별칭 미등록: ' + aliasCode);
  for (const k in src){ if (!FX_ALIAS_SKIP.has(k)) dst[k] = src[k]; }
  delete dst.todoFx;
}
function registerCards(map){
  for (const code in map){
    if (CARDS[code]) throw new Error('[registerCards] 중복 코드: ' + code);
    CARDS[code] = map[code];
  }
}
function cardDef(code){ return CARDS[code] || null; }
function makeInstance(G, code, extra){
  const def = cardDef(code);
  if (!def) throw new Error('[makeInstance] 미등록 카드: ' + code);
  const inst = { uid: 'c' + (G.uidSeq++), defCode: code };
  for (const f of baseFields) if (def[f] !== undefined) inst[f] = JSON.parse(JSON.stringify(def[f]));
  if (inst.hp !== undefined) inst.maxHp = inst.hp;
  inst.status = { stunned:0, confused:0, tough: def.toughness ? 1 : 0 };
  inst.exhausted = false;
  // 카운터(uses): 카드가 uses 개 카운터를 갖고 등장 (웹 슈터 등). 0이 되면 버림.
  if (def.uses !== undefined) inst.counters = def.uses;
  // 등장 시 카운터(entersWithCounters): 동료 등이 카운터를 갖고 등장 (호크아이 화살 등). 0이 돼도 버리지 않음.
  if (def.entersWithCountersPerHero !== undefined) inst.counters = def.entersWithCountersPerHero * (G.players ? G.players.length : 1);
  else if (def.entersWithCounters !== undefined) inst.counters = def.entersWithCounters;
  return Object.assign(inst, extra || {});
}
function buildDeck(G, codes){ return codes.map(c => makeInstance(G, c)); }

/* ── 게임 상태 ── */
function makeGameState(opt){
  const G = {
    version: MC.VERSION,
    rngState: opt.seed >>> 0, seed: opt.seed >>> 0,
    uidSeq: 1,
    round: 1, phase: 'setup', over: null,
    firstPlayer: 0, acceleration: 0,
    players: [],
    villain: null, mainScheme: null, sideSchemes: [], environments: [],
    encounterDeck: [], encounterDiscard: [], pendingEncounters: [],
    vq: [], pending: null,
    actionLog: [], gameLog: [],
    difficulty: opt.difficulty || 'normal',
  };
  opt.players.forEach((p, i) => G.players.push(MC.makePlayer(G, i, p.heroCode, p.deckCodes)));
  if (opt.villainCode){
    G.villain = makeInstance(G, opt.villainCode, { kind:'villain' });
    const def = cardDef(opt.villainCode);
    const per = def.hpPerPlayer !== undefined ? def.hpPerPlayer : def.hp;
    G.villain.hp = G.villain.maxHp = per * G.players.length;
    // 코어 룰: 빌런은 게임당 정확히 2스테이지만 플레이 (일반=I·II, 전문가=II·III — UI가 시작 단계 결정).
    //   최종 스테이지 번호 = 시작 스테이지 +1 (다음 단계 있을 때). Risky Business 노먼↔고블린 플립은
    //   면마다 defCode가 다르므로(02002a/02002b) 정확한 코드가 아닌 "스테이지 번호"로 최종 판정.
    G.villainFinalStageNum = def.nextStage ? ((def.stage || 1) + 1) : (def.stage || 1);
  }
  if (opt.mainScheme){
    const def = cardDef(opt.mainScheme);
    const ms = makeInstance(G, opt.mainScheme, { isMain: true });
    const n = G.players.length;
    ms.threat = (def.baseThreatPerPlayer||0) * n + (def.baseThreat||0);
    ms.maxThreat = (def.maxThreatPerPlayer||0) * n + (def.maxThreat||0);
    G.mainScheme = ms;
  }
  if (opt.encounterCodes) G.encounterDeck = shuffle(G, buildDeck(G, opt.encounterCodes));
  return G;
}
function setupGame(G){
  // 넴시스 세트 셋어사이드: 각 플레이어의 넴시스 하수인·사이드스킴·나머지 카드를 pl.nemesisSetAside에 준비.
  // Shadow of the Past(01190)가 이 버킷에서 카드를 꺼내 전장/조우덱에 투입. obligation은 별도(조우덱 셔플).
  for (const pl of G.players){
    const key = MC.NEMESIS_BY_HERO && (MC.NEMESIS_BY_HERO[pl.heroCode] || MC.NEMESIS_BY_HERO[pl.aeCode]);
    const set = key && MC.NEMESIS_SETS && MC.NEMESIS_SETS[key];
    if (!set) continue;
    const aside = [];
    if (set.minion){ const m = makeInstance(G, set.minion); m.type = 'minion'; m._nemesisRole = 'minion'; m._nemesisOwner = pl.uid; aside.push(m); }
    if (set.sideScheme){ const s = makeInstance(G, set.sideScheme); s._nemesisRole = 'sideScheme'; s._nemesisOwner = pl.uid; aside.push(s); }
    for (const [slug, qty] of (set.rest || [])){
      for (let i = 0; i < qty; i++){ const c = makeInstance(G, slug); c._nemesisRole = 'rest'; c._nemesisOwner = pl.uid; aside.push(c); }
    }
    pl.nemesisSetAside = aside;
  }
  // 의무(obligation) 카드: 각 플레이어의 영웅 의무를 조우덱에 셔플 (공개 시 whenRevealed 발동).
  // 영웅 slug ↔ 신분 코드 역매핑(MC.HEROES art/aeArt) → hero 필드가 일치하는 obligation 검색.
  {
    const codeToSlug = {};
    for (const slug in (MC.HEROES || {})){
      const hh = MC.HEROES[slug];
      if (hh.art) codeToSlug[hh.art] = slug;
      if (hh.aeArt) codeToSlug[hh.aeArt] = slug;
    }
    let added = false;
    for (const pl of G.players){
      const slug = codeToSlug[pl.heroCode] || codeToSlug[pl.aeCode];
      if (!slug) continue;
      let obCode = null;
      for (const code in MC.CARDS){
        const d = MC.CARDS[code];
        if (d.type === 'obligation' && d.hero === slug){ obCode = code; break; }
      }
      if (!obCode) continue;
      const ob = makeInstance(G, obCode);
      ob._obligationOwner = pl.uid;
      (pl.obligationsOut = pl.obligationsOut || []).push(ob.uid);
      (G.encounterDeck = G.encounterDeck || []).push(ob);
      added = true;
    }
    if (added) shuffle(G, G.encounterDeck);
  }
  for (const pl of G.players){
    shuffle(G, pl.deck);
    MC.drawCards(G, pl, MC.statOf(G, pl, 'handSize') || 6);
  }
  // 닥터 스트레인지: 발동 덱(Invocation Deck) 셋업 — 신비 카드 5종 각 1장을 별도 덱으로 셔플.
  // 스티븐 스트레인지 셋업 능력: 이 발동 덱과 함께 게임 시작. Spell Mastery/Natural Talent가 참조.
  for (const pl of G.players){
    if (pl.heroCode === '09001a' || pl.aeCode === '09001b'){
      const invCards = ['crimson-bands-of-cyttorak','images-of-ikonn','seven-rings-of-raggadorr','vapors-of-valtorr','winds-of-watoomb'];
      pl.invocationDeck = invCards.filter(s => MC.cardDef(s)).map(s => makeInstance(G, s));
      shuffle(G, pl.invocationDeck);
      pl.invocationDiscard = [];
      MC.log(G, MC.nameOf(pl) + ' — 발동 덱(Invocation) ' + pl.invocationDeck.length + '장 구성');
    }
  }
  // 크로스본즈 시나리오: 실험 무기 덱(Experimental Weapons) 셋업 — 빌런 def.experimentalWeaponsDeck를 별도 덱으로 셔플.
  // 크로스본즈 III / 메인 스킴 공개 시 top이 공개되어 빌런에 부착된다 (발동 덱과 유사한 전용 덱).
  {
    const vdef = G.villain && MC.cardDef(G.villain.defCode);
    const wCodes = (vdef && vdef.experimentalWeaponsDeck) || null;
    if (wCodes && wCodes.length){
      G.experimentalWeaponsDeck = wCodes.filter(s => MC.cardDef(s)).map(s => makeInstance(G, s));
      shuffle(G, G.experimentalWeaponsDeck);
      G.experimentalWeaponsDiscard = [];
      MC.log(G, '실험 무기 덱(Experimental Weapons) ' + G.experimentalWeaponsDeck.length + '장 구성');
    }
  }
  // 시나리오 키 저장 (캠페인 코믹스 트리거용) — villainStart로 SCENARIOS 역참조.
  G.scenarioKey = null;
  for (const k in MC.SCENARIOS){
    if (MC.SCENARIOS[k].villainStart === (G.villain && G.villain.defCode)){ G.scenarioKey = k; break; }
  }
  // 신분 셋업 능력 (티찰라 Foresight 등) — 초기 드로우 후, 양면 신분 def의 onSetup 발화
  for (const pl of G.players){
    for (const code of [pl.heroCode, pl.aeCode]){
      const fdef = MC.cardDef(code);
      if (fdef && fdef.onSetup && MC.HANDLERS[fdef.onSetup]){
        MC.HANDLERS[fdef.onSetup](G, { self: fdef, player: pl, hook: 'onSetup' });
      }
    }
  }
  // 메인 스킴 셋업 지시(1A면 Setup — 클로 "방어망 공개" 등): 진행면 def의 onSetup 참조
  if (G.mainScheme){
    const msDef = MC.cardDef(G.mainScheme.defCode);
    if (msDef && msDef.onSetup && MC.HANDLERS[msDef.onSetup]){
      MC.HANDLERS[msDef.onSetup](G, { self: G.mainScheme, hook: 'onSetup' });
    }
    // 공식 룰: 셋업 후 1B면이 공개되며 "공개 시" 효과 해결 (클로 01116b 등)
    MC.fireCardHook(G, G.mainScheme, 'whenRevealed', { player: G.players[G.firstPlayer] });
  }
  MC.fireHook(G, 'setup', {});
  G.phase = 'player';
  log(G, '셋업 완료 — ' + G.players.length + '인 게임 시작');
}

/* ── 액션 디스패치 ──
   검증 throw 시 로그 미기록 (실행 성공 후 기록). 원격은 수신 액션을 동일 dispatch. */
const ACTIONS = {};
function dispatch(G, action){
  const fn = ACTIONS[action.type];
  if (!fn) throw new Error('[dispatch] 미등록 액션: ' + action.type);
  if (G.fxReveal) delete G.fxReveal;   // 이전 액션의 UI 연출 힌트 소거 (표시 전용, 재생 결정성 유지)
  if (G.fxHeroPower) delete G.fxHeroPower;
  if (G.fxIdentityAction) delete G.fxIdentityAction;
  if (G.fxRetaliate) delete G.fxRetaliate;
  if (G.fxWakandaSeq) delete G.fxWakandaSeq;
  if (G.fxHulk) delete G.fxHulk;
  if (G.fxTigra) delete G.fxTigra;
  if (G.fxDaredevil) delete G.fxDaredevil;
  if (G.fxHawkeye) delete G.fxHawkeye;
  if (G.fxVision) delete G.fxVision;
  if (G.fxMakeCall) delete G.fxMakeCall;
  if (G.fxEvent) delete G.fxEvent;
  fn(G, action);
  // 하수인 등장 반응(호크아이 등) — 액션 해소 후 대기 반응이 있으면 선택 pending 세움 (선택 기능 보존)
  if (!G.pending && G._pendingMinionReactions && G._pendingMinionReactions.length && MC.flushMinionReactions)
    MC.flushMinionReactions(G);
  G.actionLog.push(action);
  return G;
}

/* ── 공용 검증 ── */
function assertPlayerTurnable(G, pl){
  if (G.over) throw new Error('게임 종료됨');
  if (G.pending) throw new Error('대기 중인 결정(' + G.pending.kind + ') 해소 필요');
  if (G.phase !== 'player') throw new Error('플레이어 페이즈 아님');
  if (pl.eliminated) throw new Error('탈락한 플레이어');
}

/* ═══ 플레이어 액션 ═══ */

/* 카드 플레이: { player, cardUid, payment:[요소...], targets? }
   구형 호환: paymentUids(손패 uid 배열)도 허용 → 요소로 변환 */
/* 카드 플레이 비용 할인 계산 (순수) — 엔진과 UI가 공유.
   반환 { discount, nextDisc, ll }:
   - nextDisc: 헬리캐리어 등 nextCardDiscount 적용 몫(필터 매치 시)
   - ll: 리빙 레전드(Cap 03001b 배선) 매 라운드 첫 동료 -1
   - discount: 합계. 부수효과 없음(플래그·리셋은 호출측 담당). */
MC.playDiscountOf = function(G, pl, card){
  const cdef = MC.cardDef(card.defCode) || {};
  let nextDisc = pl.nextCardDiscount || 0;
  if (nextDisc > 0 && pl.nextCardDiscountFilter){
    const f = pl.nextCardDiscountFilter;
    let match = true;
    if (f.type && cdef.type !== f.type) match = false;
    if (f.trait && !((cdef.traits || []).some(t => String(t).toLowerCase() === f.trait))) match = false;
    if (!match) nextDisc = 0;
  }
  let ll = 0;
  if (((card.type || cdef.type) === 'ally') && !pl.usedLivingLegendThisRound){
    const aeDef = MC.cardDef(pl.aeCode);
    if (aeDef && aeDef.livingLegend) ll = 1;
  }
  // 카드 자체 동적 할인 (cardDef.costReduction) — 헤라클레스: 교전 하수인 1명당 -1 등.
  let cardDisc = 0;
  const cr = cdef.costReduction;
  if (cr){
    if (cr.per === 'engagedMinion') cardDisc = (pl.engagedMinions || []).length * (cr.amount || 1);
    else if (cr.per === 'upgrade') cardDisc = (pl.playArea.upgrades || []).length * (cr.amount || 1);
    else if (cr.per === 'preparationCard') cardDisc = (pl.playArea.upgrades || []).filter(c => (MC.cardDef(c.defCode).traits || []).includes('preparation')).length * (cr.amount || 1);
    if (cr.max !== undefined) cardDisc = Math.min(cardDisc, cr.max);
  }
  // 아이언맨(iron-man-ally 09039): 인플레이 시 아이언맨에 부착하는 업그레이드 비용 -1.
  // 시뮬 costOf는 부착 대상 확정 전 계산되므로, 아이언맨에 부착 가능한 업그레이드
  // (attachTarget ally/character)에 적용 — Voltron 덱의 아이언맨 강화 의도 반영.
  let ironManDisc = 0;
  if (((card.type || cdef.type) === 'upgrade')){
    const at = cdef.attachTarget;
    if ((at === 'ally' || at === 'character') &&
        (pl.playArea.allies || []).some(a => a.defCode === 'iron-man-ally')){
      ironManDisc = 1;
    }
  }
  return { discount: nextDisc + ll + cardDisc + ironManDisc, nextDisc, ll, cardDisc, ironManDisc };
};
/* 카드의 실제 플레이 비용 (할인 반영). UI 지불/자동선택이 이 값을 사용해야 함. */
MC.playCostOf = function(G, pl, card){
  return Math.max(0, (card.cost || 0) - MC.playDiscountOf(G, pl, card).discount);
};

ACTIONS.playCard = function(G, a){
  const pl = playerByUid(G, a.player);
  // 카드 소스: 손패(기본) / 버린더미(playableFromDiscard — 록조) / 화살통 부착(fromQuiver — 호크아이)
  const fromDiscard = !!a.fromDiscard;
  const fromQuiver = a.fromQuiver || null;   // 화살통(Quiver) uid — 부착된 화살을 손처럼 플레이
  let srcArr;
  if (fromDiscard) srcArr = pl.discard;
  else if (fromQuiver){
    const q = pl.playArea.upgrades.find(u => u.uid === fromQuiver);
    srcArr = (q && q.attachedArrows) || [];
  } else srcArr = pl.hand;
  const idx0 = srcArr.findIndex(c => c.uid === a.cardUid);
  const cardPeek = idx0 >= 0 ? srcArr[idx0] : null;
  const peekDef = cardPeek && MC.cardDef(cardPeek.defCode);
  // 버린더미 플레이는 해당 카드에 playableFromDiscard 플래그가 있어야 함 ("당신의 턴 동안 버린더미에서 플레이 가능")
  if (fromDiscard && !(peekDef && peekDef.playableFromDiscard))
    throw new Error('[playCard] 버린더미에서 플레이 불가: ' + (cardPeek ? cardPeek.name : a.cardUid));
  // 방어 인터럽트 이벤트(Backflip 등)는 방어 pending 상태에서 플레이 가능 — 일반 턴 제약 우회
  const isDefenseInterrupt = peekDef && peekDef.type === 'event' &&
    ((peekDef.traits || []).includes('defense') || peekDef.defenseInterruptEvent) &&
    (peekDef.effects || []).some(e => e.fx === 'preventAll' || e.fx === 'preventAmount') &&
    G.pending && G.pending.kind === 'defense' && G.pending.player === pl.uid;
  if (!isDefenseInterrupt) assertPlayerTurnable(G, pl);
  else if (G.over || pl.eliminated) throw new Error('[playCard] 플레이 불가 상태');
  const idx = srcArr.findIndex(c => c.uid === a.cardUid);
  if (idx < 0) throw new Error('[playCard] ' + (fromDiscard ? '버린더미' : fromQuiver ? '화살통' : '손패') + '에 없음: ' + a.cardUid);
  const card = srcArr[idx];
  if (card.type === 'resource') throw new Error('[playCard] 자원 카드는 결제로만 사용');
  // 폼 제한 (playForm): 특정 형태에서만 플레이 가능한 카드 (법률 업무=alter-ego 등)
  const playForm = MC.cardDef(card.defCode).playForm;
  if (playForm && pl.form !== playForm)
    throw new Error('[playCard] ' + MC.T(playForm) + ' 형태에서만 플레이 가능: ' + card.name);
  // 플레이 조건 (playCondition): 반응(Response) 등 상황 제약 (원투 펀치=방금 기본 공격)
  const playCond = MC.cardDef(card.defCode).playCondition;
  if (playCond && !MC.condCheck(G, playCond, { player: pl }))
    throw new Error('[playCard] 플레이 조건 불충족: ' + card.name);
  const elements = a.payment || (a.paymentUids || []).map(u => ({ kind:'hand', uid:u }));
  if (elements.some(el => el.kind==='hand' && el.uid === a.cardUid))
    throw new Error('[playCard] 자기 자신으로 결제 불가');
  // 검증 (무변이)
  // 비용 할인 (nextCardDiscount + 리빙 레전드) — UI와 공유하는 순수 계산 함수(playDiscountOf) 사용.
  const baseCost = card.cost || 0;
  const dd = MC.playDiscountOf(G, pl, card);
  const nextDisc = dd.nextDisc;   // nextCardDiscount 적용 몫 (아래 소모 리셋용)
  if (dd.ll) pl._livingLegendPending = true;   // 리빙 레전드 적용 → 실제 플레이 확정 시 소모
  const effectiveCost = Math.max(0, baseCost - dd.discount);
  MC.validatePayment(G, pl, elements, effectiveCost, card);
  // 라운드 1회 제한 (어벤져스 어셈블 등 maxPerRound) — defCode 기준 플레이어별 추적.
  {
    const cdef0 = MC.cardDef(card.defCode);
    if (cdef0 && cdef0.maxPerRound){
      const used = (pl.eventsUsedThisRound || {})[card.defCode] || 0;
      if (used >= cdef0.maxPerRound)
        throw new Error('[playCard] ' + card.name + ' — 라운드당 최대 ' + cdef0.maxPerRound + '회');
    }
  }
  // 유니크 검증 (전 플레이어 플레이 영역)
  if (card.unique){
    for (const p2 of G.players)
      for (const arr of [p2.playArea.allies, p2.playArea.supports, p2.playArea.upgrades])
        if (arr.some(c => c.defCode === card.defCode)) throw new Error('[playCard] 유니크 중복: ' + card.name);
  }
  // 지불 자원 아이콘 — 결제 실행 전에 계산 (실행 후엔 손패에서 사라져 계산 불가)
  const paidIcons = MC.computePayment(G, pl, elements, card).icons;
  // ── 변이 시작 ──
  srcArr.splice(idx, 1);
  MC.executePayment(G, pl, elements);
  if (nextDisc > 0){ pl.nextCardDiscount = 0; pl.nextCardDiscountFilter = null; MC.log(G, MC.nameOf(card) + ' 비용 할인 -' + nextDisc + ' 적용'); }
  if (pl._livingLegendPending){ pl.usedLivingLegendThisRound = true; pl._livingLegendPending = false; MC.log(G, MC.nameOf(pl) + ' — 리빙 레전드: 이번 라운드 첫 동료 비용 감소 사용'); }
  log(G, pl.uid + ' 플레이: ' + MC.nameOf(card) + ' (비용 ' + effectiveCost + ')');
  const ctx = { player: pl, card, paidIcons,
                discardUids: a.discardUids || [],
                threatAmount: a.threatAmount || 0,
                targetPlayer: a.targetPlayer,
                targetScheme: a.targetScheme,
                recallUid: a.recallUid,
                discardAllyUid: a.discardAllyUid,
                choice: a.choice,
                discardUids: a.discardUids || [],
                targets: (a.targets||[]).map(u => findByUid(G, u)) };
  switch (card.type){
    case 'ally':   card.ownerUid = pl.uid;
      if (pl.playArea.allies.length >= MC.allyLimitOf(G, pl))
        throw new Error('[playCard] 동료 한도 초과 (최대 ' + MC.allyLimitOf(G, pl) + '명)');
      // 버린더미에서 재플레이(록조 등): 카드가 인플레이를 떠났었으므로 모든 토큰/피해/부착이 제거된 상태로 새로 등장.
      if (fromDiscard){
        const cd2 = MC.cardDef(card.defCode);
        card.damage = 0; card.hp = card.maxHp || (cd2 && cd2.hp) || 0;
        card.exhausted = false;
        card.status = { stunned:0, confused:0, tough: (cd2 && cd2.toughness) ? 1 : 0 };
        card.attachments = [];
      }
      pl.playArea.allies.push(card); break;
    case 'support':card.ownerUid = pl.uid; pl.playArea.supports.push(card); break;
    case 'upgrade':{
      card.ownerUid = pl.uid;
      const at = MC.cardDef(card.defCode).attachTarget;
      // 적/스킴/동료 부착 업그레이드(spider-tracer, enraged 등): 대상에 부착 (upgrades 영역엔 두지 않음)
      if (at === 'minion' || at === 'enemy' || at === 'sideScheme' || at === 'mainScheme' || at === 'ally'){
        const tgt = ctx.targets[0];
        if (!tgt) throw new Error('[playCard] 부착 대상 필요: ' + card.name);
        // 대상당 최대 장수 제약 (webbed-up, enraged 등)
        const maxPer = MC.cardDef(card.defCode).maxPerTarget;
        if (maxPer){
          const same = (tgt.attachments||[]).filter(a => a.defCode === card.defCode).length;
          if (same >= maxPer) throw new Error('[playCard] ' + card.name + ' — 대상당 최대 ' + maxPer + '장');
        }
        MC.attachTo(G, card, tgt);
      } else if (at === 'character'){
        // 우호 캐릭터(히어로 또는 동료) 선택 부착 (명예 어벤져). 임시로 upgrades에 보관 → 선택 시 확정.
        pl.playArea.upgrades.push(card);
        const maxPer = MC.cardDef(card.defCode).maxPerTarget;
        const allyCands = (pl.playArea.allies || []).filter(al => {
          if (!maxPer) return true;
          return (al.attachments || []).filter(x => x.defCode === card.defCode).length < maxPer;
        }).map(al => al.uid);
        // 히어로도 maxPerTarget 검사 (pl.attachments)
        const heroOk = !maxPer || ((pl.attachments || []).filter(x => x.defCode === card.defCode).length < maxPer);
        G.pending = { kind:'attachCharacter', player: pl.uid, cardUid: card.uid,
                      heroTarget: heroOk, allyUids: allyCands,
                      prompt: MC.nameOf(card) + ' — 부착할 우호 캐릭터 선택' };
      } else {
        // 히어로/무부착 업그레이드: 소유자 플레이 영역에 배치
        pl.playArea.upgrades.push(card);
        if (at === 'hero') MC.attachTo(G, card, pl); // 정체성 부착(역참조용)
      }
      break;
    }
    case 'event':
      { const cdef = MC.cardDef(card.defCode);
        if (cdef && cdef.maxPerRound){
          pl.eventsUsedThisRound = pl.eventsUsedThisRound || {};
          pl.eventsUsedThisRound[card.defCode] = (pl.eventsUsedThisRound[card.defCode] || 0) + 1;
        }
        // 이벤트 부스트 인터럽트(Embiggen!/Shrink 등): 준비된 부스터가 있으면 선택 pending으로 이벤트 해결 보류.
        const boosters = MC.readyEventBoosters(G, pl, card);
        if (boosters.length){
          G.pending = { kind:'eventBoostChoice', player: pl.uid, eventCard: card,
            targetUids: (ctx.targets || []).map(t => t && t.uid).filter(Boolean),
            targetScheme: ctx.targetScheme || null, discardUids: ctx.discardUids || [],
            boosterUids: boosters.map(b => b.uid), chosen: [],
            prompt: '이벤트 강화 — 소진해서 강화할 카드를 선택하세요 (선택 안 하려면 건너뛰기)' };
          MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 강화 인터럽트 대기');
          return;   // 부스트 선택 후 resolveEventPlay가 이벤트를 해결(whenPlayed 포함)
        }
        MC.resolveEventPlay(G, pl, card, ctx);
        return;
      }
    default: throw new Error('[playCard] 미지원 유형: ' + card.type);
  }
  MC.fireCardHook(G, card, 'whenPlayed', ctx);
  if (MC.maybeOfferMissionPrep) MC.maybeOfferMissionPrep(G, pl, card);   // 나타샤 Mission Prep: Preparation 카드 플레이 후 드로우
};

/* 이벤트 해결 로직 (effects + special + vfx + 버림 + Morphogenetics 응답 + whenPlayed).
   ctx.eventDamageBonus / ctx.eventThreatBonus = Embiggen!/Shrink 인터럽트로 얹힌 보너스. */
MC.resolveEventPlay = function(G, pl, card, ctx){
  // 카운터 스펠(counterspell) 강제 인터럽트: 히어로에 부착돼 있으면 이 이벤트를 취소+버림, 그 후 자신도 버림.
  const csIdx = (pl.identityAttachments || []).findIndex(a => a.defCode === 'counterspell');
  if (csIdx >= 0){
    const cs = pl.identityAttachments.splice(csIdx, 1)[0];
    MC.log(G, '카운터 스펠 — ' + MC.nameOf(card) + ' 효과 취소 + 버림');
    MC.moveToDiscard(G, pl, card, {});    // 이벤트 취소 (효과 미발동) → 버림
    G.encounterDiscard.push(cs);          // 카운터 스펠 자신도 버림
    MC.log(G, '카운터 스펠 소진 — 조우 버린더미로');
    return;
  }
  const cdef = MC.cardDef(card.defCode);
  const evFx = card.effects || (cdef && cdef.effects);
  if (evFx) MC.runEffectList(G, evFx, ctx);
  const sp = cdef && cdef.special;
  if (sp && MC.HANDLERS[sp]) MC.HANDLERS[sp](G, ctx);
  const evVfx = cdef && cdef.vfx && cdef.vfx.event;
  if (evVfx){
    const targetUids = (ctx.targets || []).map(t => t && t.uid).filter(Boolean);
    G.fxEvent = { vfx: evVfx, targetUids,
      villainUid: (G.villain && G.villain.uid) || null,
      scheme: ctx.targetScheme || (cdef.eventScheme ? 'main' : null) };
  }
  MC.moveToDiscard(G, pl, card, {});
  MC.maybeOfferMorphResponse(G, pl, card);   // 미즈마블 Morphogenetics: 이벤트 플레이 후 소진→손 반환 응답
  MC.fireCardHook(G, card, 'whenPlayed', ctx);
};

/* 준비된 이벤트 부스터 목록 — 히어로 폼 + 미소진 + 이벤트 트레잇이 eventBoost.trait와 일치하는 업그레이드. */
MC.readyEventBoosters = function(G, pl, card){
  if (pl.form !== 'hero') return [];
  const traits = (MC.cardDef(card.defCode).traits || []);
  const out = [];
  for (const up of (pl.playArea.upgrades || [])){
    const d = MC.cardDef(up.defCode) || {};
    if (d.eventBoost && !up.exhausted && traits.includes(d.eventBoost.trait)) out.push(up);
  }
  return out;
};

/* Morphogenetics 응답 해소: { player, accept } — accept면 신분 소진 + 그 이벤트를 버림더미→손. */
/* 레드 대거 처치 인터럽트 해소: { player, decline?, payment?, targetUid? }
   decline이거나 지불 없으면 → 동료 버림. 지불(서로 다른 자원 2개)+대상 지정 시 → 적 피해 + 손 반환. */
ACTIONS.resolveAllyDefeatInterrupt = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'allyDefeatInterrupt') throw new Error('[resolveAllyDefeatInterrupt] 대기 없음');
  const pl = playerByUid(G, p.player);
  const ally = p.ally;
  if (a.decline || !a.payment || !a.payment.length){
    G.pending = null;
    MC.moveToDiscard(G, pl, ally, {});
    MC.log(G, MC.nameOf(ally) + ' — 인터럽트 미사용, 버림');
    return;
  }
  // 지불 검증: 서로 다른 타입 differentTypes개
  const { icons } = MC.computePayment(G, pl, a.payment, null);
  if (!MC.canPayDifferentTypes(icons, p.differentTypes || 2))
    throw new Error('[resolveAllyDefeatInterrupt] 서로 다른 자원 ' + (p.differentTypes||2) + '개 필요');
  const tgt = findByUid(G, a.targetUid);
  if (!tgt) throw new Error('[resolveAllyDefeatInterrupt] 대상 없음');
  MC.executePayment(G, pl, a.payment);
  // 적에게 피해
  if (p.damage) MC.applyDamage(G, tgt, p.damage, { source: ally });
  if (p.vfx) G.fxHeroPower = { hero:'ms-marvel', vfx: p.vfx, targetUid: tgt.uid };
  // 동료를 소유자 손으로 반환 (피해/상태 초기화)
  ally.damage = 0; ally.exhausted = false; ally.status = {};
  if (ally.attachments) ally.attachments = [];
  pl.hand.push(ally);
  MC.log(G, MC.nameOf(ally) + ' — 서로 다른 자원 ' + (p.differentTypes||2) + '개 지불 → '
    + MC.nameOf(tgt) + '에 ' + p.damage + ' 피해 + 손으로 반환');
  G.pending = null;
};

/* 브루노 저장 해소: { player, cardUid } — 손패 1장을 브루노에 엎어서 보관. */
/* 동료 공격개시 인터럽트(Nova): 적이 당신을 공격할 때 자원 지불 → 공격자에 피해.
   { player, cardUid, payment } — 방어 pending 유지(반복 가능). 공격자 처치 시 공격 무효화. */
/* Rapid Response: 동료 처치 후, 소유자가 히어로 폼이고 전장에 Rapid Response 업그레이드가 있으면
   되살림 제안 pending. 동료는 이미 pl.discard에 있음. */
MC.maybeOfferRapidResponse = function(G, pl, ally){
  if (G.pending) return;
  if (pl.form !== 'hero') return;
  const rr = (pl.playArea.upgrades || []).find(u => MC.cardDef(u.defCode).rapidResponse);
  if (!rr) return;
  if (!pl.discard.some(c => c.uid === ally.uid)) return;   // 되살릴 동료가 버린더미에 있어야
  G.pending = { kind:'rapidResponse', player: pl.uid, rapidUid: rr.uid, allyUid: ally.uid,
    prompt: MC.nameOf(rr) + ' — ' + MC.nameOf(ally) + '을(를) 전장으로 되살릴까? (Rapid Response 버림 + 그 동료에 1 피해)' };
  MC.log(G, MC.nameOf(rr) + ' 반응 대기 (' + MC.nameOf(ally) + ' 되살림)');
};

/* Rapid Response 해소: { player, accept } — accept면 Rapid Response 버림 + 동료를 전장에 준비 상태로 배치 + 1피해 + 등장효과 재발동. */
ACTIONS.resolveRapidResponse = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'rapidResponse') throw new Error('[resolveRapidResponse] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (!a.accept){ G.pending = null; MC.log(G, 'Rapid Response 미사용'); return; }
  // 비용: Rapid Response 버림
  const rrIdx = pl.playArea.upgrades.findIndex(u => u.uid === p.rapidUid);
  if (rrIdx >= 0){
    const [rr] = pl.playArea.upgrades.splice(rrIdx, 1);
    if (rr.attachedTo) MC.detachFrom(G, rr);
    MC.moveToDiscard(G, pl, rr, {});
  }
  // 동료를 버린더미 → 전장 (준비, 만피)
  const ai = pl.discard.findIndex(c => c.uid === p.allyUid);
  if (ai >= 0 && pl.playArea.allies.length < MC.allyLimitOf(G, pl)){
    const [ally] = pl.discard.splice(ai, 1);
    ally.damage = 0; ally.exhausted = false; ally.status = {}; ally.attachments = [];
    ally.hp = ally.maxHp; ally.ownerUid = pl.uid;
    pl.playArea.allies.push(ally);
    MC.log(G, 'Rapid Response — ' + MC.nameOf(ally) + ' 전장으로 되살림');
    G.fxHeroPower = { hero: null, vfx:'rapidResponse', targetUid: ally.uid };
    // 등장 효과 재발동 (닉 퓨리 드로우 3 등)
    MC.fireCardHook(G, ally, 'whenPlayed', { player: pl, self: ally, card: ally });
    // 그 동료에 1 피해 (되살림 대가)
    MC.applyDamage(G, ally, 1, {});
  }
  G.pending = null;
};

/* 팀워크(teamworkAlly) 해소 — 동료 1명 소진 → 그 동료의 ATK/THW를 다음 기본 공격/저지 보너스로 프리로드. */
ACTIONS.resolveTeamworkAlly = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'teamworkAlly') throw new Error('[resolveTeamworkAlly] 대기 없음');
  const pl = playerByUid(G, p.player);
  const ally = (pl.playArea.allies || []).find(x => x.uid === a.uid);
  if (!ally) throw new Error('[resolveTeamworkAlly] 동료 없음: ' + a.uid);
  ally.exhausted = true;
  const atk = MC.allyStatOf(G, ally, 'attack'), thw = MC.allyStatOf(G, ally, 'thwart');
  pl.nextBasicAttackBonus = (pl.nextBasicAttackBonus || 0) + atk;
  pl.nextBasicThwartBonus = (pl.nextBasicThwartBonus || 0) + thw;
  MC.log(G, MC.nameOf(pl) + ' 팀워크 — ' + MC.nameOf(ally) + ' 소진 → 다음 기본 공격 +' + atk + ' / 기본 저지 +' + thw);
  G.pending = null;
};

/* 조우덱 예지(encounterScry) 해소 — 하임달 등. a.mode: 'toggle'(버릴 카드 선택) | 'confirm'(확정).
   confirm 시 chosen 카드를 조우 버림 더미로, 나머지는 원래 위 순서 유지로 조우덱에 되돌림. */
ACTIONS.resolveEncounterScry = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'encounterScry') throw new Error('[resolveEncounterScry] 대기 없음');
  if (a.mode === 'toggle'){
    const i = p.chosen.indexOf(a.uid);
    if (i >= 0) p.chosen.splice(i, 1);
    else if (p.chosen.length < p.discard) p.chosen.push(a.uid);
    return;
  }
  if (a.mode === 'confirm'){
    if (p.chosen.length !== p.discard) throw new Error('[resolveEncounterScry] 버릴 카드 ' + p.discard + '장 선택 필요');
    for (const uid of p.chosen){
      const c = p._cards.find(x => x.uid === uid);
      if (c) G.encounterDiscard.push(c);
    }
    const remaining = p._cards.filter(c => !p.chosen.includes(c.uid));
    // revealed는 pop 순서(위→아래). 되돌릴 때 역순 push → 원래 위 순서 복원.
    for (let i = remaining.length - 1; i >= 0; i--) G.encounterDeck.push(remaining[i]);
    MC.log(G, '조우덱 예지 — ' + p.chosen.length + '장 버림, ' + remaining.length + '장 조우덱 상단으로 되돌림');
    G.pending = null;
  }
};

/* 공격 후 선택 반응(afterAttackReaction) 해소 — Battle Fury·Jarnbjorn 등.
   a.mode: 'skip'(넘김) | 'activate'(발동). activate 시 cost 지불(a.payment) + effects + discardSelf. */
ACTIONS.resolveAfterAttackReaction = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'afterAttackReaction') throw new Error('[resolveAfterAttackReaction] 대기 없음');
  const pl = playerByUid(G, p.player);
  const card = MC.findByUid(G, p.cardUid);
  const rx = card && MC.cardDef(card.defCode).afterAttackReaction;
  const advance = () => {
    G.pending = null;
    if (G._afterAttackQueue && G._afterAttackQueue.length){
      const next = G._afterAttackQueue.shift();
      const nc = MC.findByUid(G, next.cardUid);
      if (nc) G.pending = { kind:'afterAttackReaction', player: pl.uid, cardUid: next.cardUid, targetUid: next.targetUid };
      else if (G._afterAttackQueue.length) ACTIONS.resolveAfterAttackReaction(G, { mode:'skip', player: pl.uid });
    }
  };
  if (a.mode === 'skip' || !rx){ MC.log(G, '(공격 후 반응 넘김)'); advance(); return; }
  // 자원 지불 (cost) — Jarnbjorn: {physical:1}. a.payment(결제 요소)로 아이콘 충족 검증.
  if (rx.cost){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els);
    if (!MC.payIconsSatisfied(icons, rx.cost)) throw new Error('[resolveAfterAttackReaction] 자원 부족');
    MC.executePayment(G, pl, els);
  }
  // 대상 (needsTarget) — a.targets
  const targets = (a.targets || []).map(u => MC.findByUid(G, u)).filter(Boolean);
  const ctx = { player: pl, card, self: card, targets };
  MC.log(G, MC.nameOf(card) + ' — 공격 후 반응 발동');
  if (rx.effects) MC.runEffectList(G, rx.effects, ctx);
  // 자기 버림 (discardSelf) — Battle Fury
  if (rx.discardSelf){
    for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
      const i = arr.indexOf(card);
      if (i >= 0){ arr.splice(i, 1); break; }
    }
    MC.moveToDiscard(G, pl, card, {});
  }
  advance();
};

ACTIONS.useAllyAttackInterrupt = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'defense') throw new Error('[useAllyAttackInterrupt] 방어 상황 아님');
  const pl = playerByUid(G, a.player);
  if (pl.uid !== p.player) throw new Error('[useAllyAttackInterrupt] 방어 대상 아님');
  const ally = (pl.playArea.allies || []).find(x => x.uid === a.cardUid);
  if (!ally) throw new Error('[useAllyAttackInterrupt] 동료 없음');
  const ai = MC.cardDef(ally.defCode).attackInitiateInterrupt;
  if (!ai) throw new Error('[useAllyAttackInterrupt] 인터럽트 능력 없음');
  const attacker = findByUid(G, p.attackerUid);
  if (!attacker) throw new Error('[useAllyAttackInterrupt] 공격자 없음');
  // 비용 지불 (payIcons)
  const els = a.payment || [];
  const { icons } = MC.computePayment(G, pl, els, ally);
  if (ai.cost && !MC.payIconsSatisfied(icons, ai.cost))
    throw new Error('[useAllyAttackInterrupt] 자원 지불 불충족: ' + JSON.stringify(ai.cost));
  MC.executePayment(G, pl, els);
  MC.applyDamage(G, attacker, ai.damage || 0, { source: ally });
  G.fxHeroPower = { hero: MC.cardDef(ally.defCode).hero || null, vfx: ai.vfx || 'impact', targetUid: attacker.uid };
  MC.log(G, MC.nameOf(ally) + ' — 공격개시 인터럽트: ' + MC.nameOf(attacker) + '에 ' + (ai.damage||0) + ' 피해');
  // 공격자가 처치되면(HP 0 이하) 이 공격 무효화 (방어 pending 해제)
  if (attacker.hp <= 0){
    MC.log(G, MC.nameOf(attacker) + ' 처치 — 공격 무효화');
    G.pending = null;
  }
};

ACTIONS.resolveBrunoStore = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'brunoStorePick') throw new Error('[resolveBrunoStore] 대기 없음');
  const pl = playerByUid(G, p.player);
  const bruno = findByUid(G, p.brunoUid);
  const idx = pl.hand.findIndex(c => c.uid === a.cardUid);
  if (idx < 0) throw new Error('[resolveBrunoStore] 손패에 없음: ' + a.cardUid);
  const [c] = pl.hand.splice(idx, 1);
  bruno.stored = bruno.stored || [];
  bruno.stored.push(c);
  MC.log(G, MC.nameOf(bruno) + '에 카드 1장 엎어서 보관 (보관 ' + bruno.stored.length + '장)');
  G.fxHeroPower = { hero:'ms-marvel', vfx:'brunoPlace', targetUid: bruno.uid };
  G.pending = null;
};

/* 브루노 회수 해소: { player, cardUids } — 보관 카드 최대 3장을 손으로. */
ACTIONS.resolveBrunoRetrieve = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'brunoRetrievePick') throw new Error('[resolveBrunoRetrieve] 대기 없음');
  const pl = playerByUid(G, p.player);
  const bruno = findByUid(G, p.brunoUid);
  const want = (a.cardUids || []).filter(u => (p.storedUids || []).includes(u)).slice(0, p.max || 3);
  bruno.stored = bruno.stored || [];
  for (const uid of want){
    const i = bruno.stored.findIndex(c => c.uid === uid);
    if (i < 0) continue;
    const [c] = bruno.stored.splice(i, 1);
    c.ownerUid = pl.uid; pl.hand.push(c);
  }
  MC.log(G, MC.nameOf(bruno) + ' — 보관 카드 ' + want.length + '장 회수 (보관 ' + bruno.stored.length + '장 남음)');
  G.fxHeroPower = { hero:'ms-marvel', vfx:'brunoPlace', targetUid: bruno.uid };
  G.pending = null;
};

ACTIONS.resolveEventBoost = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'eventBoostChoice') throw new Error('[resolveEventBoost] 대기 없음');
  const pl = playerByUid(G, p.player);
  const chosen = (a.boosterUids || []).filter(u => (p.boosterUids || []).includes(u));
  let dmgBonus = 0, thrBonus = 0;
  for (const uid of chosen){
    const up = (pl.playArea.upgrades || []).find(x => x.uid === uid);
    if (!up || up.exhausted) continue;
    const eb = (MC.cardDef(up.defCode) || {}).eventBoost;
    if (!eb) continue;
    up.exhausted = true;
    if (eb.stat === 'damage') dmgBonus += (eb.amount || 0);
    else if (eb.stat === 'threat') thrBonus += (eb.amount || 0);
    MC.log(G, MC.nameOf(up) + ' 소진 → ' + MC.nameOf(p.eventCard) + ' 강화 (+' + (eb.amount||0) + ' ' + eb.stat + ')');
    G.fxHeroPower = { hero:'ms-marvel', vfx: eb.vfx || 'embiggen', targetUid: (G.villain && G.villain.uid) || pl.uid };
  }
  // ctx 재구성 후 이벤트 해결 (보너스 반영)
  const card = p.eventCard;
  const ctx = { player: pl, self: card, card,
    targets: (p.targetUids || []).map(u => findByUid(G, u)).filter(Boolean),
    targetScheme: p.targetScheme || null, discardUids: p.discardUids || [],
    eventDamageBonus: dmgBonus, eventThreatBonus: thrBonus };
  G.pending = null;
  MC.resolveEventPlay(G, pl, card, ctx);
};

/* 공개 인터럽트 해소: { player, cardUid?, payment? } — cardUid 없으면 패스 */
ACTIONS.resolveRevealInterrupt = function(G, a){
  MC.resolveRevealInterrupt(G, a.player, a.cardUid || null, a.payment || []);
};

/* ═══ 닥터 스트레인지 Invocation(발동 덱) 시스템 ═══
   발동 덱이 비면 버림 더미를 셔플해 재구성. */
MC.invocationReshuffleIfEmpty = function(G, pl){
  if ((!pl.invocationDeck || !pl.invocationDeck.length) && pl.invocationDiscard && pl.invocationDiscard.length){
    pl.invocationDeck = MC.shuffle(G, pl.invocationDiscard.splice(0));
    MC.log(G, MC.nameOf(pl) + ' — 발동 덱 재셔플 (' + pl.invocationDeck.length + '장)');
  }
};
/* 천부적 재능(Natural Talent): 발동 덱 맨 위 카드 1장을 버림 (효과 없음). */
MC.naturalTalent = function(G, pl){
  MC.invocationReshuffleIfEmpty(G, pl);
  if (!pl.invocationDeck || !pl.invocationDeck.length) return false;
  const top = pl.invocationDeck.shift();
  (pl.invocationDiscard = pl.invocationDiscard || []).push(top);
  MC.log(G, MC.nameOf(pl) + ' — 천부적 재능: ' + MC.nameOf(top) + ' 발동 덱에서 버림');
  G._invocationVfx = { kind:'discard', playerUid: pl.uid, card:{ defCode: top.defCode, name: MC.nameOf(top) } };
  return true;
};
/* 발동 덱 맨 위 카드의 Special 능력 해결. opt.keepOnTop(대가): 앞면 유지 / 기본(Spell Mastery): 버림.
   대상이 필요한 Special은 opt.targets 또는 빌런 기본. */
MC.castInvocation = function(G, pl, opt){
  opt = opt || {};
  MC.invocationReshuffleIfEmpty(G, pl);
  if (!pl.invocationDeck || !pl.invocationDeck.length) return false;
  const top = pl.invocationDeck[0];
  const def = MC.cardDef(top.defCode);
  const targets = (opt.targets && opt.targets.length) ? opt.targets : (G.villain ? [G.villain] : []);
  if (def.invocationSpecial) MC.runEffectList(G, def.invocationSpecial, { player: pl, self: top, targets });
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(top) + ' 발동!');
  G._invocationVfx = { kind:'cast', playerUid: pl.uid, card:{ defCode: top.defCode, name: MC.nameOf(top) } };
  if (!opt.keepOnTop){
    pl.invocationDeck.shift();
    (pl.invocationDiscard = pl.invocationDiscard || []).push(top);
  }
  return true;
};

/* 나타샤 Mission Prep: alter-ego 폼에서 Preparation 카드 플레이 후 → 카드 1장 드로우 (페이즈당 1회). */
MC.maybeOfferMissionPrep = function(G, pl, card){
  const hdef = MC.cardDef(pl.aeCode);
  const mp = hdef && hdef.afterPlayTrait;
  if (!mp) return;
  if (pl.form !== (mp.form || 'alter-ego')) return;
  const cdef = MC.cardDef(card.defCode);
  if (!cdef || !(cdef.traits || []).includes(mp.trait)) return;
  if (mp.oncePerPhase && pl._missionPrepUsed) return;
  pl._missionPrepUsed = true;
  MC.runEffectList(G, mp.effect || [{ fx:'draw', amount:1 }], { player: pl });
  MC.log(G, MC.nameOf(pl) + ' — 임무 준비(Mission Prep): 카드 1장 드로우');
};

/* 블랙위도우 Preparation 발동 헬퍼: 준비 카드를 버림 + Widowmaker 발동(히어로 폼이면 적 1명에 피해 선택).
   각 Preparation 카드(Widow's Bite·Grappling Hook 등)가 자신의 Interrupt/Response 조건 충족 시 이 헬퍼를 호출. */
MC.triggerPreparation = function(G, pl, card, opt){
  opt = opt || {};
  if (opt.discard !== false && card){
    const arr = pl.playArea.upgrades;
    const i = arr.indexOf(card); if (i >= 0) arr.splice(i, 1);
    MC.moveToDiscard(G, pl, card, {});
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 발동(버림)');
  }
  const hdef = MC.cardDef(pl.heroCode);
  if (pl.form === 'hero' && hdef && hdef.preparationTrigger){
    const dmg = hdef.preparationTrigger.damage || 1;
    const enemies = [];
    if (G.villain) enemies.push(G.villain.uid);
    for (const p of G.players) for (const m of (p.engagedMinions || [])) enemies.push(m.uid);
    if (enemies.length){
      G._widowmaker = { player: pl.uid, enemyUids: enemies, damage: dmg };
      MC.log(G, MC.nameOf(pl) + ' — 와이도우메이커 준비(적 1명에 ' + dmg + ' 피해)');
    }
  }
};

/* Widowmaker 발동: 적이 1명이면 자동 피해, 여럿이면 선택 pending. */
MC.offerWidowmaker = function(G){
  const w = G._widowmaker;
  if (!w) return;
  G._widowmaker = null;
  const enemies = (w.enemyUids || []).filter(u => MC.findByUid(G, u));
  if (!enemies.length) return;
  if (enemies.length === 1){
    const t = MC.findByUid(G, enemies[0]);
    MC.applyDamage(G, t, w.damage, { source: { isPlayer: true }, isAttack: false });
    MC.log(G, '와이도우메이커 — ' + MC.nameOf(t) + '에 ' + w.damage + ' 피해');
  } else {
    G.pending = { kind:'widowmaker', player: w.player, enemyUids: enemies, damage: w.damage,
      prompt:'와이도우메이커 — ' + w.damage + ' 피해를 줄 적을 선택하세요' };
  }
};
ACTIONS.resolveWidowmaker = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'widowmaker') throw new Error('[resolveWidowmaker] 대기 없음');
  if (!p.enemyUids.includes(a.uid)) throw new Error('[resolveWidowmaker] 잘못된 대상');
  const t = MC.findByUid(G, a.uid);
  MC.applyDamage(G, t, p.damage, { source: { isPlayer: true }, isAttack: false });
  MC.log(G, '와이도우메이커 — ' + MC.nameOf(t) + '에 ' + p.damage + ' 피해');
  G.pending = null;
};

/* 미즈마블 Morphogenetics: 히어로 신분의 afterEventResponse 조건 충족 시 morphResponse pending 세움.
   조건 — 히어로 폼 + 신분 미소진 + 방금 버린 이벤트가 지정 트레잇(공격/저지/방어) 보유. */
MC.maybeOfferMorphResponse = function(G, pl, event){
  if (G.pending) return;   // 방어 등 다른 대기가 있으면 응답 제안 보류 (중첩 금지)
  if (!pl || pl.form !== 'hero' || pl.exhausted) return;
  const hdef = MC.cardDef(pl.heroCode);
  const resp = hdef && hdef.afterEventResponse;
  if (!resp) return;
  const evd = MC.cardDef(event.defCode) || {};
  const traits = evd.traits || [];
  if (!(resp.traits || []).some(t => traits.includes(t))) return;
  G.pending = { kind:'morphResponse', player: pl.uid, eventUid: event.uid,
    vfx: resp.vfx || null,
    prompt: resp.prompt || (MC.nameOf(pl) + ' 소진 → 이 이벤트를 손으로 되돌릴까?') };
  MC.log(G, MC.nameOf(pl) + ' — Morphogenetics 응답 대기 (' + MC.nameOf(event) + ')');
};

/* Morphogenetics 응답 해소: { player, accept } — accept면 신분 소진 + 그 이벤트를 버림더미→손. */
ACTIONS.resolveMorphResponse = function(G, a){
  const p = G.pending;
  if (!p || p.kind !== 'morphResponse') throw new Error('[resolveMorphResponse] 대기 없음');
  const pl = playerByUid(G, p.player);
  G.pending = null;
  if (!a.accept){ MC.log(G, MC.nameOf(pl) + ' — Morphogenetics 패스'); return; }
  if (pl.exhausted) throw new Error('[resolveMorphResponse] 신분이 이미 소진됨');
  const i = (pl.discard || []).findIndex(c => c.uid === p.eventUid);
  if (i < 0){ MC.log(G, '이벤트를 버림 더미에서 찾을 수 없음'); return; }
  const [ev] = pl.discard.splice(i, 1);
  ev.ownerUid = pl.uid; pl.hand.push(ev);
  pl.exhausted = true;
  G.fxHeroPower = { hero:'ms-marvel', vfx: p.vfx || 'embiggen', targetUid: pl.uid };
  MC.log(G, MC.nameOf(pl) + ' 소진 → ' + MC.nameOf(ev) + ' 손으로 반환 (Morphogenetics)');
};

/* 카드 활성 능력 사용: { player, cardUid, targets? }
   cardDef.activatedAbility = { form?, exhaust?, effect } — 소진/폼 조건 검증 후 효과 실행.
   범용: 소진 능력을 가진 support/upgrade/ally(메이 숙모, 헬리캐리어 등)에 재사용. */
ACTIONS.useCardAbility = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  // 카드 탐색 (모든 플레이 영역)
  let card = null;
  for (const arr of [pl.playArea.supports, pl.playArea.upgrades, pl.playArea.allies])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; break; } }
  // 조우 부착물의 히어로 행동 (강화된 상아 뿔 등): 빌런 부착물도 탐색
  if (!card && G.villain){
    const c = (G.villain.attachments || []).find(x => x.uid === a.cardUid);
    if (c) card = c;
  }
  // 신분 부착물의 행동 (All Tied Up/Media Coverage): 플레이어 신분 부착도 탐색
  if (!card){
    for (const pl2 of G.players){
      const c = (pl2.identityAttachments || []).find(x => x.uid === a.cardUid);
      if (c){ card = c; break; }
    }
  }
  // 하수인의 히어로 행동 (에디슨의 거대 로봇 무효화 등): 모든 플레이어 교전 하수인 탐색
  if (!card){
    for (const pl2 of G.players){
      const c = (pl2.engagedMinions || []).find(x => x.uid === a.cardUid);
      if (c){ card = c; break; }
    }
  }
  if (!card) throw new Error('[useCardAbility] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  // 능력 2개 이상 카드(브루노 등): activatedAbilities 배열 + abilityIndex로 선택. 단일은 activatedAbility.
  const ab = def.activatedAbilities
    ? def.activatedAbilities[a.abilityIndex || 0]
    : def.activatedAbility;
  if (!ab) throw new Error('[useCardAbility] 활성 능력 없음: ' + card.defCode);
  if (ab.form && pl.form !== ab.form)
    throw new Error('[useCardAbility] ' + ab.form + ' 형태에서만 사용 가능');
  // 반응 조건 검사 (심문실=하수인 처치 후 등)
  if (ab.playCondition && !MC.condCheck(G, ab.playCondition, { player: pl, card }))
    throw new Error('[useCardAbility] 발동 조건 미충족: ' + card.defCode);
  // 라운드당 1회 제한 (비전 등)
  if (ab.oncePerRound && card.usedAbilityThisRound)
    throw new Error('[useCardAbility] 이번 라운드 이미 사용: ' + card.defCode);
  if (ab.exhaust && card.exhausted) throw new Error('[useCardAbility] 이미 소진됨');
  // 추가 코스트: 자신에게 피해 (selfDamage:N) — 집중된 분노 등
  if (ab.selfDamage){
    const dmgTarget = ab.selfDamageTarget === 'card' ? card : pl;
    MC.applyDamage(G, dmgTarget, ab.selfDamage, { source: card, isCost: true });
  }
  // 추가 코스트: 다중 타입 자원 지불 (payIcons:{mental:1,physical:1}) — All Tied Up 등
  if (ab.payIcons){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els, card);
    if (!MC.payIconsSatisfied(icons, ab.payIcons))
      throw new Error('[useCardAbility] 자원 지불 불충족: ' + JSON.stringify(ab.payIcons));
    MC.executePayment(G, pl, els);
  }
  // 추가 코스트: 자원 지불 (payCost:{type, count}) — 결제 요소 a.payment
  if (ab.payCost){
    const els = a.payment || [];
    let paid = 0;
    for (const el of els){
      if (el.kind !== 'hand') throw new Error('[useCardAbility] 손패 자원만 지불 가능');
      const c = pl.hand.find(x => x.uid === el.uid);
      if (!c) throw new Error('[useCardAbility] 손패에 없음: ' + el.uid);
      const icons = MC.resourceIconsOf(c);
      paid += (icons[ab.payCost.type] || 0) + (icons.wild || 0);
    }
    if (paid < (ab.payCost.count || 1))
      throw new Error('[useCardAbility] ' + MC.T(ab.payCost.type) + ' 자원 ' + (ab.payCost.count||1) + ' 필요 (지불 ' + paid + ')');
    MC.executePayment(G, pl, els);
  }
  // 추가 코스트: 손에서 카드 N장 버림 (a.discardUids로 지정)
  if (ab.discardCost){
    const uids = a.discardUids || [];
    if (uids.length !== ab.discardCost)
      throw new Error('[useCardAbility] 버릴 카드 ' + ab.discardCost + '장 선택 필요');
    for (const u of uids){
      const ci = pl.hand.findIndex(c => c.uid === u);
      if (ci < 0) throw new Error('[useCardAbility] 손패에 없음: ' + u);
    }
    // 검증 후 실제 버림
    for (const u of uids){
      const c = pl.hand.find(x => x.uid === u);
      pl.hand.splice(pl.hand.indexOf(c), 1);
      MC.moveToDiscard(G, pl, c, {});
    }
  }
  // 소진
  if (ab.exhaust) card.exhausted = true;
  // 카운터 소비 (useCounter:N) — Tac Team 등 Uses 기반. 소진 시 버림.
  if (ab.useCounter){
    if ((card.counters || 0) < ab.useCounter)
      throw new Error('[useCardAbility] 카운터 부족: ' + MC.nameOf(card));
    card.counters -= ab.useCounter;
    MC.log(G, MC.nameOf(card) + ' 카운터 ' + ab.useCounter + ' 소비 (' + card.counters + ' 남음)');
  }
  // 효과 실행
  const ctx = { player: pl, card, self: card,
                targetScheme: a.targetScheme,
                targetPlayer: a.targetPlayer,
                targets: (a.targets||[]).map(u => findByUid(G, u)) };
  log(G, pl.uid + ' 카드 능력: ' + MC.nameOf(card));
  if (ab.effect) MC.runEffectList(G, Array.isArray(ab.effect) ? ab.effect : [ab.effect], ctx);
  // special 핸들러 (호크아이 화살 등 — effect로 표현 어려운 로직)
  if (ab.special && MC.HANDLERS[ab.special]) MC.HANDLERS[ab.special](G, { ...ctx, choice: a.choice });
  if (ab.oncePerRound) card.usedAbilityThisRound = true;
  // Preparation 발동(블랙위도우): 카드를 버리고 Widowmaker 트리거(히어로 폼이면 적 1명에 피해 대기).
  if (ab.preparation){
    MC.triggerPreparation(G, pl, card);
    if (G._widowmaker) MC.offerWidowmaker(G);
  }
  // 카운터 소진 시 버림 (모든 카운터 소진 → discard). keepOnEmpty면 유지 (Hall of Heroes 등 영구 지원).
  if (ab.useCounter && !ab.keepOnEmpty && (card.counters || 0) <= 0){
    for (const arr of [pl.playArea.supports, pl.playArea.upgrades, pl.playArea.allies]){
      const i = arr.indexOf(card);
      if (i >= 0){ arr.splice(i, 1); break; }
    }
    MC.moveToDiscard(G, pl, card, {});
    MC.log(G, MC.nameOf(card) + ' — 카운터 소진, 버림');
  }
};

/* 방어 인터럽트: 방어 pending 시 플레이 영역의 defenseInterrupt 카드 발동.
   피해 N 방지 후 필요 시 자체 버림. { player, cardUid } */
ACTIONS.useDefenseInterrupt = function(G, a){
  const pl = playerByUid(G, a.player);
  if (!G.pending || G.pending.kind !== 'defense' || G.pending.player !== pl.uid)
    throw new Error('[useDefenseInterrupt] 방어 상황이 아님');
  let card = null;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; break; } }
  if (!card) throw new Error('[useDefenseInterrupt] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  const di = def.defenseInterrupt;
  if (!di) throw new Error('[useDefenseInterrupt] 방어 인터럽트 없음: ' + card.defCode);
  const p = G.pending;
  // 같은 공격에 같은 카드는 1회만 (Energy Barrier RRG: 조건당 1회)
  p.usedInterrupts = p.usedInterrupts || [];
  if (p.usedInterrupts.includes(card.uid)) throw new Error('[useDefenseInterrupt] 이 공격에 이미 사용됨');
  // 반영 카운터 소비 (Energy Barrier)
  if (di.counter){
    if ((card.counters || 0) < di.counter) throw new Error('[useDefenseInterrupt] 카운터 부족: ' + MC.nameOf(card));
    card.counters -= di.counter;
  }
  // 자원 지불 (Mockingbird: 아무 자원 1) — 실패 시 롤백 없이 throw
  if (di.payAny){
    const els = a.payment || [];
    const { sum } = MC.computePayment(G, pl, els, card);
    if (sum < di.payAny) throw new Error('[useDefenseInterrupt] 자원 부족 (' + sum + '/' + di.payAny + ')');
    MC.executePayment(G, pl, els);
  }
  log(G, pl.uid + ' 방어 인터럽트: ' + MC.nameOf(card));
  // 피해 방지 (부분 prevent:N 또는 전체 preventAll)
  if (di.preventAll) MC.EFFECTS.preventAll(G, {}, { player: pl, card });
  else if (di.prevent) MC.EFFECTS.preventAmount(G, { amount: di.prevent }, { player: pl, card });
  // 무피해 시 히어로 재준비 플래그 (필사의 방어) — 방어 해소 시 dmg===0이면 ready.
  if (di.readyIfNoDamage) p.readyIfNoDamage = true;
  // 적에게 피해 (Energy Barrier: 카운터당 1피해)
  if (di.damageEnemy){
    const atk = MC.findByUid(G, p.attackerUid);
    if (atk){
      MC.applyDamage(G, atk, di.damageEnemy, { source: card });
      MC.log(G, MC.nameOf(card) + ' — ' + MC.nameOf(atk) + '에 ' + di.damageEnemy + ' 피해');
      if (atk.hp <= 0){ MC.log(G, MC.nameOf(atk) + ' 처치 — 공격 무효화'); G.pending = null; }
    }
  }
  if (di.vfx) G.fxHeroPower = { hero: def.hero || null, vfx: di.vfx, targetUid: p.attackerUid };
  if (G.pending) p.usedInterrupts.push(card.uid);
  // 손 반환 (Mockingbird: 인터럽트 후 소유자 손으로) — returnToHand가 인플레이 제거+상태 리셋
  if (di.returnToHand){
    MC.EFFECTS.returnToHand(G, {}, { player: pl, card, self: card });
  }
  // 자체 버림 (discardSelf 또는 카운터 소진)
  else if (di.discardSelf || (di.counter && (card.counters || 0) <= 0)){
    const arr = pl.playArea.upgrades.includes(card) ? pl.playArea.upgrades
              : pl.playArea.supports.includes(card) ? pl.playArea.supports
              : pl.playArea.allies;
    const i = arr.indexOf(card);
    if (i >= 0) arr.splice(i, 1);
    if (card.attachedTo) MC.detachFrom(G, card);
    MC.moveToDiscard(G, pl, card, {});
    MC.log(G, MC.nameOf(card) + (di.counter ? ' — 카운터 소진, 버림' : ' — 사용 후 버림'));
  }
  // 준비(Preparation) 방어 인터럽트 발동 → Widowmaker (방어 흐름 중이라 빌런 직접 피해로 처리)
  if (di.preparation){
    const hdefW = MC.cardDef(pl.heroCode);
    if (pl.form === 'hero' && hdefW && hdefW.preparationTrigger && G.villain){
      MC.applyDamage(G, G.villain, hdefW.preparationTrigger.damage || 1, { source:{ isPlayer:true }, isAttack:false });
      MC.log(G, '와이도우메이커 — 빌런에 ' + (hdefW.preparationTrigger.damage||1) + ' 피해');
    }
  }
};

/* 기본 공격: { player, targetUid } */
ACTIONS.basicAttack = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'hero') throw new Error('[basicAttack] 영웅 형태 아님');
  if (pl.exhausted) throw new Error('[basicAttack] 소진됨');
  if (pl.status.stunned > 0){ // 기절: 공격 대신 토큰 제거 (활성화 소모)
    pl.exhausted = true; pl.status.stunned--;
    log(G, pl.uid + ' 기절 해제에 활성화 소모');
    return;
  }
  const target = findByUid(G, a.targetUid);
  if (!target || target.hp === undefined) throw new Error('[basicAttack] 유효하지 않은 대상');
  if (target.kind === 'villain' && MC.hasGuardEngaged(G, pl))
    throw new Error('[basicAttack] 수호 하수인 교전 중 — 빌런 공격 불가');
  pl.exhausted = true;
  pl.justBasicAttacked = true;   // 반응 트리거용 (원투 펀치 등) — 다음 액션에서 해제
  const atkTarget = target;
  // Mean Swing 등 "이번 기본 공격 한정" 보너스 (무기 소진 → +3 ATK). 공격 직후 리셋.
  const atkVal = MC.statOf(G, pl, 'attack') + (pl.nextBasicAttackBonus || 0);
  pl.nextBasicAttackBonus = 0;
  const basicOverkill = !!pl.nextBasicAttackOverkill;   // 헐크 스매시: 물리 지불 시 이번 기본 공격 과잉살상
  pl.nextBasicAttackOverkill = false;
  pl.nextBasicThwartBonus = 0;   // Teamwork 1회용: 공격에 썼으면 저지 보너스도 소멸
  MC.applyDamage(G, target, atkVal, { source: pl, isAttack: true, noRetaliate: true, overkill: basicOverkill });
  // ★ 보복: 공격받은 대상(부착물 등으로 retaliate 보유)이 살아남았으면 피해량 무관하게 발동
  //   (강인 흡수·0피해여도). RRG 순서: 공격 해소 후 보복 → 그 다음 강제 반응(afterBasicAttack).
  MC.triggerRetaliate(G, atkTarget, pl);
  // 기본 공격 후 강제 반응 (초인적인 힘 등): 플레이 영역 카드의 afterBasicAttack 훅
  MC.fireAfterBasicAttack(G, pl, atkTarget);
};

/* 신분 액션 (라운드 1회): 캡틴마블 Rechannel·캐롤 Commander·토니 Futurist 등.
   신분 카드 def.identityAction = { form, oncePerRound, payEnergy, selfHeal, effect }.
   { player, targets? } — effect는 EFFECTS 파이프라인. */
ACTIONS.useIdentityAction = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
  const def = MC.cardDef(faceCode);
  const ia = def && def.identityAction;
  if (!ia) throw new Error('[useIdentityAction] 신분 액션 없음: ' + faceCode);
  if (ia.form && pl.form !== ia.form) throw new Error('[useIdentityAction] ' + MC.T(ia.form) + ' 형태 전용');
  if (ia.oncePerRound && pl.usedIdentityActionThisRound[pl.form]) throw new Error('[useIdentityAction] 이번 라운드 이미 사용 (' + MC.T(pl.form) + ')');
  // 페이즈당 1회 제한 (호크아이 Weapon of Choice 등). usedIdentityActionThisPhase[form].
  pl.usedIdentityActionThisPhase = pl.usedIdentityActionThisPhase || {};
  if (ia.oncePerPhase && pl.usedIdentityActionThisPhase[pl.form]) throw new Error('[useIdentityAction] 이번 페이즈 이미 사용 (' + MC.T(pl.form) + ')');
  // 비용: 히어로 자신 소진 (호크아이 Quick Draw: "Exhaust Hawkeye"). 준비 상태여야 사용 가능.
  if (ia.exhaustSelf){
    if (pl.exhausted) throw new Error('[useIdentityAction] 이미 소진됨 — 소진 비용 지불 불가');
  }
  // 비용: 아무 자원 N개 지불 (호크아이 Weapon of Choice: 아무 자원 1). payEnergy와 배타.
  if (ia.payAny){
    const els = a.payment || [];
    const { sum } = MC.computePayment(G, pl, els, null);
    if (sum < ia.payAny) throw new Error('[useIdentityAction] 자원 부족 (' + sum + '/' + ia.payAny + ')');
    MC.executePayment(G, pl, els, null);
  }
  // 비용: 에너지 자원 지불 (a.payment 요소로)
  if (ia.payEnergy){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els, null);
    if ((icons.energy||0) + (icons.wild||0) < ia.payEnergy)
      throw new Error('[useIdentityAction] 에너지 자원 부족');
    MC.executePayment(G, pl, els, null);
  }
  // 비용: 자기 회복 조건 (Rechannel: 1 피해 회복 — 피해 없으면 사용 불가)
  if (ia.selfHeal){
    if (pl.hp >= (MC.heroFace(G, pl).hp || pl.hp)) throw new Error('[useIdentityAction] 회복할 피해 없음');
    MC.healTarget(G, pl, ia.selfHeal);
  }
  // 비용: 손패 버림 (캡틴아메리카 "하루 종일도 가능해!": 손패 1장 버림 → 준비).
  // a.discard = 버릴 손패 카드 uid 배열. 지정 없으면 임의로 첫 N장 버림(UI 미지정 대비).
  if (ia.discardCost){
    const need = ia.discardCost;
    if (pl.hand.length < need) throw new Error('[useIdentityAction] 버릴 손패 부족 (' + pl.hand.length + '/' + need + ')');
    const uids = (a.discard || []).slice(0, need);
    const chosen = [];
    for (const u of uids){ const c = MC.fromHand(pl, u); if (c) chosen.push(c); }
    while (chosen.length < need && pl.hand.length) chosen.push(pl.hand.shift());
    for (const c of chosen) MC.moveToDiscard(G, pl, c, {});
    MC.log(G, MC.nameOf(pl) + ' — 손패 ' + chosen.length + '장 버림 (액션 비용)');
  }
  // 효과 실행
  if (ia.effect) MC.runEffectList(G, ia.effect, { player: pl, card: def, targets: (a.targets||[]).map(uid => findByUid(G, uid)).filter(Boolean) });
  // 히어로 자신 소진 (Quick Draw): 효과 해결 후 소진 (활 준비 → 호크아이 소진)
  if (ia.exhaustSelf) pl.exhausted = true;
  if (ia.oncePerRound) pl.usedIdentityActionThisRound[pl.form] = true;
  if (ia.oncePerPhase) pl.usedIdentityActionThisPhase[pl.form] = true;
  MC.log(G, MC.nameOf(pl) + ' 신분 액션: ' + (ia.name || def.name));
  G.fxIdentityAction = { face: faceCode, vfx: ia.vfx };
};

/* 기본 저지: { player, scheme } */
ACTIONS.basicThwart = function(G, a){
  const pl = playerByUid(G, a.player);
  pl.justBasicAttacked = false;   // 다른 기본 행동 → 반응 기회 소멸
  pl.justDefeatedEnemyByAttack = false;
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'hero') throw new Error('[basicThwart] 영웅 형태 아님');
  if (pl.exhausted) throw new Error('[basicThwart] 소진됨');
  if (pl.status.confused > 0){
    pl.exhausted = true; pl.status.confused--;
    log(G, pl.uid + ' 혼란 해제에 활성화 소모');
    return;
  }
  // ★ 룰 정정: 가드(Guard)는 "빌런 공격 불가"만 제한. 메인 스킴 저지 제한은 순찰(Patrol) 키워드.
  if ((a.scheme === 'main' || !a.scheme) && MC.hasPatrolEngaged(G, pl))
    throw new Error('[basicThwart] 순찰 하수인 교전 중 — 메인 스킴 저지 불가');
  // 교전 중 저지 불가(바론 제모 등): 모든 스킴 저지 차단
  if (MC.hasCannotThwartEngaged(G, pl))
    throw new Error('[basicThwart] 저지 불가 하수인 교전 중 (바론 제모 등) — 저지할 수 없음');
  // 위기(Crisis): crisis 사이드 스킴이 전장에 있으면 메인 스킴 위협 제거 불가
  if ((a.scheme === 'main' || !a.scheme) && MC.hasCrisisScheme(G))
    throw new Error('[basicThwart] 위기(Crisis) 사이드 스킴 — 먼저 처치해야 메인 스킴 저지 가능');
  pl.exhausted = true;
  const thwVal = MC.statOf(G, pl, 'thwart') + (pl.nextBasicThwartBonus || 0);
  pl.nextBasicThwartBonus = 0;
  pl.nextBasicAttackBonus = 0;   // Teamwork 1회용: 저지에 썼으면 공격 보너스도 소멸
  MC.removeThreat(G, a.scheme || 'main', thwVal);
};

/* 기본 회복: { player } */
ACTIONS.basicRecover = function(G, a){
  const pl = playerByUid(G, a.player);
  pl.justBasicAttacked = false;
  pl.justDefeatedEnemyByAttack = false;
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'alter-ego') throw new Error('[basicRecover] 알터에고 형태 아님');
  if (pl.exhausted) throw new Error('[basicRecover] 소진됨');
  pl.exhausted = true;
  MC.healTarget(G, pl, MC.statOf(G, pl, 'recover'));
};

/* 동료 공격/저지: { player, allyUid, targetUid|scheme } — 후유증 피해(atkCost/thwCost) */
/* 동료 공격 실행 코어 (추가 비용 지불 후 재사용) — 피해+보복+afterAttack+consequential. */
function performAllyAttack(G, pl, ally, target){
  ally.exhausted = true;
  MC.applyDamage(G, target, MC.allyStatOf(G, ally, 'attack'), { source: ally, isAttack: true, noRetaliate: true });
  // ★ 보복: 공격받은 대상이 살아남았으면 피해량 무관하게 동료에게 발동 (강인 흡수·0피해여도)
  MC.triggerRetaliate(G, target, ally);
  // 동료 공격 후 강제 반응 (헐크/타이그라 등) — 공격 대상/공격자 전달.
  // ★ atkCost(consequential 자기 피해) 적용 *전*에 발화 (타이그라 FAQ: 회복이 자기 피해보다 먼저).
  MC.fireCardHook(G, ally, 'afterAttack', { player: pl, attacker: ally, target });
  if (ally.atkCost) MC.applyDamage(G, ally, ally.atkCost, { isConsequential: true });
}
MC.performAllyAttack = performAllyAttack;

ACTIONS.allyAttack = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  const ally = pl.playArea.allies.find(x => x.uid === a.allyUid);
  if (!ally) throw new Error('[allyAttack] 동료 없음');
  if (ally.exhausted) throw new Error('[allyAttack] 동료 소진됨');
  if (ally.status.stunned > 0){ ally.exhausted = true; ally.status.stunned--; log(G, MC.nameOf(ally)+' 기절 해제'); return; }
  const target = findByUid(G, a.targetUid);
  if (!target || target.hp === undefined) throw new Error('[allyAttack] 유효하지 않은 대상');
  if (target.kind === 'villain' && MC.hasGuardEngaged(G, pl))
    throw new Error('[allyAttack] 수호 하수인 교전 중 — 빌런 공격 불가');
  // 공격 추가 비용 (원더맨 등): attackExtraCost.discardFromHand N장 — 어느 카드 버릴지 플레이어 선택.
  const adef = MC.cardDef(ally.defCode);
  const need = adef && adef.attackExtraCost && adef.attackExtraCost.discardFromHand;
  if (need){
    if ((pl.hand || []).length < need)
      throw new Error('[allyAttack] 손패 부족 — ' + MC.nameOf(ally) + ' 공격 불가 (추가 비용 ' + need + '장 버림)');
    G.pending = { kind:'handDiscardCost', player: pl.uid, allyUid: ally.uid, targetUid: target.uid,
                  count: need, chosen: [],
                  prompt: MC.nameOf(ally) + ' 공격 추가 비용 — 손패에서 ' + need + '장 버리기' };
    log(G, MC.nameOf(ally) + ' 공격 추가 비용 — 버릴 카드 ' + need + '장 선택 대기');
    return;
  }
  performAllyAttack(G, pl, ally, target);
};

/* 동료 공격 추가 비용(손패 버림) 해소 — a.uid 손패 카드 버림, count 채우면 실제 공격 실행. */
/* 동료 소진→드로우 다중선택 해소 — a.mode:'toggle'(a.uid 선택/해제) | 'confirm'(소진+드로우 실행). */
/* 동료 배치 선택 해소 — a.uid 동료를 손에서 전장에 무료 배치 → (discardSource면) 소스 버림 → 등장 반응 발화. */
/* 우호 캐릭터 부착 선택 해소 — a.target:'hero' 또는 동료 uid. 명예 어벤져 등 attachTarget:'character'. */
/* 손패 선택 버림 해소 — a.uid 카드를 버림. remaining 소진 시 afterEffects 실행. */
ACTIONS.resolveDiscardChoose = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'discardChoose') throw new Error('[resolveDiscardChoose] 대기 없음');
  const pl = playerByUid(G, p.player);
  const idx = pl.hand.findIndex(c => c.uid === a.uid);
  if (idx < 0) throw new Error('[resolveDiscardChoose] 손패에 없음');
  const card = pl.hand[idx];
  pl.hand.splice(idx, 1);
  MC.moveToDiscard(G, pl, card, {});
  p.chosen.push(a.uid);
  p.remaining -= 1;
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 버림 (' + p.remaining + '장 남음)');
  if (p.remaining <= 0){
    const self = MC.findByUid(G, p.selfUid);
    const after = p.afterEffects || [];
    G.pending = null;
    if (after.length) MC.runEffectList(G, after, { player: pl, self, card: self, targetScheme:'main' });
  }
};
// 통제 카드 선택 버림 해소 (Caught Off Guard·의무 등 — 후보 2장 이상일 때 플레이어가 고른 카드).
// 손패 자원 카드 선택 버림 해소 (Tombstone·Power Drain — 무작위 아닌 자원 버림).
ACTIONS.resolveResourceDiscardPick = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'resourceDiscardPick') throw new Error('[resolveResourceDiscardPick] 대기 없음');
  const pl = playerByUid(G, p.player);
  const card = (pl.hand || []).find(c => c.uid === a.uid);
  if (!card) throw new Error('[resolveResourceDiscardPick] 손패에 없음');
  // 자원 필터 검증
  const ic = MC.resourceIconsOf(card) || {};
  const ok = (!p.types || !p.types.length) ? Object.values(ic).some(v => v > 0)
           : (p.types.some(t => (ic[t] || 0) > 0) || (ic.wild || 0) > 0);
  if (!ok) throw new Error('[resolveResourceDiscardPick] 자원 카드 아님');
  MC.discardHandCard(G, pl, card);
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + ' 버림' + (p.reason ? ' (' + p.reason + ')' : ''));
  p.chosen += 1;
  if (p.chosen >= p.count){
    // 이 플레이어 완료 → 큐의 다음 플레이어로 (또는 pending 해제)
    const spec = { queue: p.queue || [], perPlayerCount: p.perPlayerCount, types: p.types, prompt: p.prompt, reason: p.reason };
    G.pending = null;
    MC.setupResourceDiscardPick(G, spec);
  }
};
ACTIONS.resolvePickControlledDiscard = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'pickControlledDiscard') throw new Error('[resolvePickControlledDiscard] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (!(p.cardUids || []).includes(a.uid)) throw new Error('[resolvePickControlledDiscard] 선택 불가 카드');
  const card = MC.findByUid(G, a.uid);
  if (!card) throw new Error('[resolvePickControlledDiscard] 카드 없음');
  MC.discardControlledCard(G, pl, card, '선택 버림');
  G.pending = null;
};
ACTIONS.resolveAttachCharacter = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'attachCharacter') throw new Error('[resolveAttachCharacter] 대기 없음');
  const pl = playerByUid(G, p.player);
  const card = pl.playArea.upgrades.find(c => c.uid === p.cardUid);
  if (!card) throw new Error('[resolveAttachCharacter] 카드 없음');
  if (a.target === 'hero'){
    if (!p.heroTarget) throw new Error('[resolveAttachCharacter] 히어로 부착 불가');
    MC.attachTo(G, card, pl);              // 히어로(정체성) 부착
    if (MC.cardDef(card.defCode).hpBonus) MC.recomputeMaxHp(G, pl);   // 히어로 HP는 recompute로
  } else {
    const ally = (pl.playArea.allies || []).find(x => x.uid === a.target);
    if (!ally || !(p.allyUids || []).includes(a.target)) throw new Error('[resolveAttachCharacter] 선택 불가 동료');
    // upgrades 임시 보관에서 빼서 동료에 부착 (attachTo가 hpBonus/트레잇 처리)
    pl.playArea.upgrades.splice(pl.playArea.upgrades.indexOf(card), 1);
    MC.attachTo(G, card, ally);
  }
  G.pending = null;
};
ACTIONS.resolveDeployAlly = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'deployAlly') throw new Error('[resolveDeployAlly] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (!(p.allyUids || []).includes(a.uid)) throw new Error('[resolveDeployAlly] 선택 불가 동료');
  const ally = pl.hand.find(c => c.uid === a.uid);
  if (!ally) throw new Error('[resolveDeployAlly] 손패에 없음');
  if (pl.playArea.allies.length >= MC.allyLimitOf(G, pl))
    throw new Error('[resolveDeployAlly] 동료 한도 초과 (최대 ' + MC.allyLimitOf(G, pl) + '명)');
  // 손에서 제거 → 전장 무료 배치
  pl.hand.splice(pl.hand.indexOf(ally), 1);
  ally.ownerUid = pl.uid;
  pl.playArea.allies.push(ally);
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(ally) + ' 전장 배치 (무료)');
  // "그 후 소스 버림" (퀸젯) — 등장 반응 전에 처리
  if (p.discardSource){
    const src = MC.findByUid(G, p.sourceUid);
    if (src){
      for (const arr of [pl.playArea.supports, pl.playArea.upgrades, pl.playArea.allies]){
        const i = arr.indexOf(src);
        if (i >= 0){ arr.splice(i, 1); break; }
      }
      MC.moveToDiscard(G, pl, src, {});
      MC.log(G, MC.nameOf(src) + ' 버림');
    }
  }
  G.pending = null;   // deployAlly 해소
  // 등장 반응 발화 (whenPlayed 훅 — 팔콘/스쿼럴걸 등). 새 pending을 세울 수 있음(그대로 유지).
  MC.fireCardHook(G, ally, 'whenPlayed', { player: pl });
};
ACTIONS.resolveAllyExhaustDraw = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'allyExhaustDraw') throw new Error('[resolveAllyExhaustDraw] 대기 없음');
  const pl = playerByUid(G, p.player);
  if (a.mode === 'toggle'){
    if (!(p.allyUids || []).includes(a.uid)) throw new Error('[resolveAllyExhaustDraw] 선택 불가 동료');
    const i = p.chosen.indexOf(a.uid);
    if (i >= 0) p.chosen.splice(i, 1); else p.chosen.push(a.uid);
    return;                                              // pending 유지 (계속 토글)
  }
  // confirm: 선택된 동료 소진 + 그 수만큼 드로우 (0명이면 드로우 0)
  let n = 0;
  for (const uid of p.chosen){
    const ally = pl.playArea.allies.find(x => x.uid === uid);
    if (ally && !ally.exhausted){ ally.exhausted = true; n++; }
  }
  G.pending = null;
  if (n > 0){ MC.drawCards(G, pl, n); MC.log(G, MC.nameOf(pl) + ' — 동료 ' + n + '명 소진 → ' + n + '장 드로우'); }
  else MC.log(G, MC.nameOf(pl) + ' — 소진한 동료 없음 (드로우 0)');
};
ACTIONS.resolveHandDiscardCost = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'handDiscardCost') throw new Error('[resolveHandDiscardCost] 대기 없음');
  const pl = playerByUid(G, p.player);
  const idx = (pl.hand || []).findIndex(c => c.uid === a.uid);
  if (idx < 0) throw new Error('[resolveHandDiscardCost] 손패에 없는 카드: ' + a.uid);
  const [card] = pl.hand.splice(idx, 1);
  MC.moveToDiscard(G, pl, card, {});
  p.chosen.push(a.uid);
  log(G, MC.nameOf(card) + ' 버림 (공격 추가 비용 ' + p.chosen.length + '/' + p.count + ')');
  if (p.chosen.length < p.count) return;                 // 더 버려야 함 — pending 유지
  const ally = pl.playArea.allies.find(x => x.uid === p.allyUid);
  const target = findByUid(G, p.targetUid);
  G.pending = null;
  if (!ally || ally.exhausted){ log(G, '공격자 동료 없음/소진 — 공격 불발'); return; }
  if (!target || target.hp === undefined || target.hp <= 0){ log(G, '공격 대상 없음 — 비용만 지불'); return; }
  if (target.kind === 'villain' && MC.hasGuardEngaged(G, pl)){ log(G, '수호 하수인 교전 — 빌런 공격 불가 (비용만 지불)'); return; }
  performAllyAttack(G, pl, ally, target);
};
ACTIONS.allyThwart = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  const ally = pl.playArea.allies.find(x => x.uid === a.allyUid);
  if (!ally) throw new Error('[allyThwart] 동료 없음');
  if (ally.exhausted) throw new Error('[allyThwart] 동료 소진됨');
  if (ally.status.confused > 0){ ally.exhausted = true; ally.status.confused--; log(G, MC.nameOf(ally)+' 혼란 해제'); return; }
  if ((a.scheme === 'main' || !a.scheme) && MC.hasPatrolEngaged(G, pl))
    throw new Error('[allyThwart] 순찰 하수인 교전 중 — 메인 스킴 저지 불가');
  if ((a.scheme === 'main' || !a.scheme) && MC.hasCrisisScheme(G))
    throw new Error('[allyThwart] 위기(Crisis) 사이드 스킴 — 먼저 처치해야 메인 스킴 저지 가능');
  ally.exhausted = true;
  MC.removeThreat(G, a.scheme || 'main', MC.allyStatOf(G, ally, 'thwart'));
  // 저지 후 강제 반응 (데어데블 등) — 대상 스킴/타깃 전달.
  // ★ thwCost(consequential 자기 피해) 적용 *전*에 발화 (타이그라 FAQ 준용: 데어데블도
  //   마지막 저지에서 피해를 줄 수 있음 = 조건 판정이 자기 피해보다 먼저).
  const pingTargets = (a.pingTargets || a.targets || []).map(u => findByUid(G, u)).filter(Boolean);
  MC.fireCardHook(G, ally, 'afterThwart', { player: pl, thwarter: ally, scheme: a.scheme || 'main', targets: pingTargets });
  if (ally.thwCost) MC.applyDamage(G, ally, ally.thwCost, { isConsequential: true });
};

/* 형태 변경 */
ACTIONS.flipForm = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  MC.flipForm(G, pl);
};

/* 방어 선언 해소: { player, defender:'none'|'identity'|allyUid } */
ACTIONS.resolveDefense = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  MC.resolveDefensePending(G, a.player, a.defender);
};

/* 조우 카드 공개 선택 해소 (하이드라 폭파범 등): { player, option } — option은 pending.options의 키.
   선택된 옵션의 effects를 실행하고 pending 해제 → 공개 큐 재개. */
/* 적 대상 선택 해소 (chooseEnemy pending) — 선택한 적에게 then 효과 실행. 범용. */
/* 적 부착물 제거 (히어로 행동): removeAbility.payIcons 자원 지불 → detach + 버림. 범용.
   소닉 컨버터(⚡🧠💪 각 1) 등. { player, attachUid, payment } */
ACTIONS.removeEnemyAttachment = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const pl = playerByUid(G, a.player);
  if (pl.form !== 'hero') throw new Error('[removeAttach] 히어로 행동은 영웅 형태에서만');
  // 부착물 찾기 (빌런 + 모든 교전 하수인)
  let att = null;
  const hosts = [G.villain, ...(G.environments || [])];
  for (const q of G.players) for (const m of q.engagedMinions) hosts.push(m);
  for (const host of hosts){ const f = (host.attachments||[]).find(x => x.uid === a.attachUid); if (f){ att = f; break; } }
  if (!att) throw new Error('[removeAttach] 부착물 없음');
  const def = MC.cardDef(att.defCode);
  if (!def || !def.removeAbility) throw new Error('[removeAttach] 제거 능력 없음');
  // 소진 비용 (프로그램 전송기: "히어로 소진 + 🧠🧠 지불"). 소진 비용이 없으면 소진 상태여도 제거 가능.
  if (def.removeAbility.exhaustHero && pl.exhausted) throw new Error('[removeAttach] 소진됨 (히어로 소진 비용 필요)');
  const els = a.payment || [];
  const { icons } = MC.computePayment(G, pl, els, att);
  if (!MC.payIconsSatisfied(icons, def.removeAbility.payIcons))
    throw new Error('[removeAttach] 자원 지불 불충족: ' + JSON.stringify(def.removeAbility.payIcons));
  MC.executePayment(G, pl, els);
  if (def.removeAbility.exhaustHero){ pl.exhausted = true; MC.log(G, pl.uid + ' 히어로 소진 (제거 비용)'); }
  MC.detachFrom(G, att);
  G.encounterDiscard.push(att);
  MC.log(G, MC.nameOf(att) + ' — 히어로 행동으로 제거');
};

ACTIONS.resolveChooseEnemy = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'chooseEnemy') throw new Error('[resolveChooseEnemy] 대기 중인 적 선택 없음');
  if (!(p.enemyUids || []).includes(a.uid)) throw new Error('[resolveChooseEnemy] 유효하지 않은 대상: ' + a.uid);
  const enemy = MC.findByUid(G, a.uid);
  const pl = playerByUid(G, p.player);
  const then = p.then || [];
  G.pending = null;
  MC.log(G, MC.nameOf(enemy) + ' — 대상 선택됨');
  MC.runEffectList(G, then, { player: pl, targets: [enemy] });
};

/* 와칸다 포에버! 순서 선택 해소: 플레이어가 탭한 BP 업그레이드를 해결. 남은 게 없으면 시퀀스 종료. */
ACTIONS.resolveWakandaStep = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'wakandaOrder') throw new Error('[resolveWakandaStep] 와칸다 순서 대기 없음');
  if (!(p.remaining || []).includes(a.uid)) throw new Error('[resolveWakandaStep] 유효하지 않은 업그레이드: ' + a.uid);
  const pl = playerByUid(G, p.player);
  const inst = MC.findByUid(G, a.uid);
  p.remaining = p.remaining.filter(u => u !== a.uid);
  const final = p.remaining.length === 0;
  MC.resolveWakandaUpgrade(G, pl, inst, final);
  (p.resolved = p.resolved || []).push(a.uid);
  if (final){ G.pending = null; MC.log(G, '와칸다 포에버! — 시퀀스 완료'); }
};

/* 범용 카드 선택 해소 — cardPick pending에서 a.uid 카드를 선택.
   keep장 다 고르면: 고른 카드 손에, 나머지는 disposition('discard'|'bottom')대로. */
ACTIONS.resolveCardPick = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'cardPick') throw new Error('[resolveCardPick] 카드 선택 대기 없음');
  if (!(p.cardUids || []).includes(a.uid)) throw new Error('[resolveCardPick] 유효하지 않은 카드: ' + a.uid);
  if ((p.chosen || []).includes(a.uid)) throw new Error('[resolveCardPick] 이미 선택한 카드');
  const pl = playerByUid(G, p.player);
  p.chosen.push(a.uid);
  if (p.chosen.length < p.keep) return;                 // 아직 더 골라야 함 — pending 유지
  // keep장 다 고름 → 처리
  const chosenSet = new Set(p.chosen);
  const toHand = p._cards.filter(c => chosenSet.has(c.uid));
  const rest   = p._cards.filter(c => !chosenSet.has(c.uid));
  for (const c of toHand) pl.hand.push(c);
  if (p.disposition === 'bottom'){ for (const c of rest) pl.deck.push(c); }
  else { for (const c of rest) MC.moveToDiscard(G, pl, c, {}); }
  MC.log(G, MC.nameOf(pl) + ' — ' + toHand.length + '장 손에 넣고 ' + rest.length + '장 '
           + (p.disposition === 'bottom' ? '덱 아래로' : '버림'));
  G.pending = null;
};

ACTIONS.resolveRevealChoice = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  const p = G.pending;
  if (!p || p.kind !== 'revealChoice') throw new Error('[resolveRevealChoice] 대기 중인 선택 없음');
  const opt = (p.options || []).find(o => o.key === a.option);
  if (!opt) throw new Error('[resolveRevealChoice] 유효하지 않은 선택: ' + a.option);
  const pl = playerByUid(G, p.player);
  const self = MC.findByUid(G, p.selfUid);
  // 자원 지불 선택지(payIcons: 다중 타입 요구, wild 유연 배정) — 소닉 붐 "자원 3종 지불" 등.
  if (opt.payIcons){
    const els = a.payment || [];
    const { icons } = MC.computePayment(G, pl, els, self);
    if (!MC.payIconsSatisfied(icons, opt.payIcons))
      throw new Error('[resolveRevealChoice] 자원 지불 불충족: ' + JSON.stringify(opt.payIcons));
    MC.executePayment(G, pl, els);
    MC.log(G, MC.nameOf(self || {name:'조우 카드'}) + ' — 자원 지불로 회피');
  }
  G.pending = null;
  MC.log(G, MC.nameOf(self || {name:'조우 카드'}) + ' — 선택: ' + opt.label);
  MC.runEffectList(G, opt.effects || [], { player: pl, self, card: self, targetScheme: 'main' });
  // 강제 위협 선택 체인(노라드 습격 01138b): 남은 플레이어가 있으면 다음 선택 pending으로 이어감.
  if (G._pendingThreatChoice && G._pendingThreatChoice.length && MC.flushThreatChoice){
    MC.flushThreatChoice(G);
  }
  // 각 플레이어 선택 체인(공격 받는 중 01151 등): 남은 플레이어가 있으면 다음으로 이어감.
  else if (G._pendingEachChoice && G._pendingEachChoice.queue && G._pendingEachChoice.queue.length && MC.flushEachChoice){
    MC.flushEachChoice(G);
  }
  // 하수인 등장 반응 체인(호크아이 화살 등): 남은 반응 후보가 있으면 다음 선택으로 이어감.
  else if (G._pendingMinionReactions && G._pendingMinionReactions.length && MC.flushMinionReactions){
    MC.flushMinionReactions(G);
  }
  // Wicked Ambitions 고블린 선택 체인: 버린 고블린마다 [피해3 / 배치] 선택을 순차 제시.
  else if (G._pendingWickedGoblins && MC.flushWickedGoblin){
    MC.flushWickedGoblin(G);
  }
  // pending 해제 완료 — 공개 큐 재개는 UI가 villainStep 재호출로 처리 (방어 해소와 동일 패턴)
};

/* 플레이어 페이즈 종료 (코어: 버림선택→손패 보충→전원 준비→빌런 페이즈) */
ACTIONS.endPlayerPhase = function(G, a){
  if (G.over) throw new Error('게임 종료됨');
  if (G.pending) throw new Error('대기 중인 결정 해소 필요');
  if (G.phase !== 'player') throw new Error('플레이어 페이즈 아님');
  MC.fireHook(G, 'endOfPhase', { phase:'player' });
  // ★ 공식 RRG: 플레이어 페이즈 종료 시 모든 카드 준비 + 핸드 크기까지 드로우
  //   → 그 후 빌런 페이즈 진행 (사용자 룰북·이전 빌드 기준)
  for (const pl of MC.playersInOrder(G)){
    MC.readyAllFor(G, pl);
    // 신분 턴 종료 훅 (헐크 격노: 손패 전체 강제 버림) — 손패 보충 전에 발동.
    const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    const onTurnEnd = MC.cardDef(faceCode) && MC.cardDef(faceCode).onTurnEnd;
    if (onTurnEnd) MC.runEffectList(G, onTurnEnd, { player: pl });
    MC.drawUpToHandSize(G, pl);
    pl.tempTraits = [];   // 일시적 트레잇(로켓 부츠 Aerial 등) — 페이즈 종료 시 소멸
    pl.nextCardDiscount = 0;   // 비용 할인(헬리캐리어) — 페이즈 종료 시 소멸
    pl.nextCardDiscountFilter = null;   // 할인 필터(어벤져스 타워) — 페이즈 종료 시 소멸
    if (pl.tempStatBonus) pl.tempStatBonus = {};   // 히어로 임시 버프(선두에서 이끌기 등) 소멸
    // 동료 임시 스탯 버프(비전 +2 등) — 페이즈 종료 시 소멸
    for (const a of pl.playArea.allies) if (a.tempStatBonus) a.tempStatBonus = {};
  }
  // 단계별 진행 모드 (UI가 villainStep으로 하나씩 실행 — 연출 동기화)
  if (a.stepwise) G.villainStepMode = true;
  MC.startVillainPhase(G);
};

/* 빌런 페이즈 스텝 1개 실행 (단계별 진행 모드) */
ACTIONS.villainStep = function(G, a){
  MC.villainStepOnce(G);
};

/* 카운터 충전: 자원 지불 요소만큼 카운터 축적 (에너지 채널 등).
   { player, cardUid, payment } — payment로 지불한 자원 아이콘 수 = 추가 카운터 */
ACTIONS.counterCharge = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  let card = null;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; break; } }
  if (!card) throw new Error('[counterCharge] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  const ca = def.counterAbility;
  if (!ca || !ca.charge) throw new Error('[counterCharge] 충전 능력 없음');
  const els = a.payment || [];
  if (!els.length) throw new Error('[counterCharge] 충전할 자원을 선택하세요');
  // 지불 자원의 해당 타입 아이콘 수를 카운터로 (에너지 자원 X개 → 카운터 X개)
  const need = ca.charge.resource; // 'energy'
  let gained = 0;
  for (const el of els){
    if (el.kind !== 'hand') throw new Error('[counterCharge] 손패 자원만 충전 가능');
    const c = pl.hand.find(x => x.uid === el.uid);
    if (!c) throw new Error('[counterCharge] 손패에 없음');
    const icons = MC.resourceIconsOf(c);
    gained += (icons[need] || 0) + (icons.wild || 0);
  }
  if (gained <= 0) throw new Error('[counterCharge] ' + MC.T(need) + ' 자원이 필요합니다');
  // 자원 카드 버림 (결제)
  MC.executePayment(G, pl, els);
  card.counters = (card.counters || 0) + gained;
  log(G, MC.nameOf(card) + ' 충전 — 카운터 +' + gained + ' (누적 ' + card.counters + ')');
};

/* 카운터 발사: 카드 버림 + 카운터당 피해 (에너지 채널 등).
   { player, cardUid, targetUid } */
ACTIONS.counterFire = function(G, a){
  const pl = playerByUid(G, a.player);
  assertPlayerTurnable(G, pl);
  if (pl.form !== 'hero') throw new Error('[counterFire] 영웅 형태에서만');
  let card = null, srcArr = null;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports])
    { const c = arr.find(x => x.uid === a.cardUid); if (c){ card = c; srcArr = arr; break; } }
  if (!card) throw new Error('[counterFire] 카드 없음: ' + a.cardUid);
  const def = MC.cardDef(card.defCode);
  const ca = def.counterAbility;
  if (!ca || !ca.fire) throw new Error('[counterFire] 발사 능력 없음');
  const counters = card.counters || 0;
  if (counters < (ca.fire.minCounters || 1)) throw new Error('[counterFire] 카운터 부족 (최소 ' + (ca.fire.minCounters||1) + ')');
  const target = findByUid(G, a.targetUid);
  if (!target) throw new Error('[counterFire] 대상 없음');
  let dmg = counters * (ca.fire.perCounter || 1);
  if (ca.fire.max) dmg = Math.min(dmg, ca.fire.max);
  // 카드 버림 (발사)
  if (ca.fire.discardSelf){
    const i = srcArr.indexOf(card);
    if (i >= 0) srcArr.splice(i, 1);
    MC.moveToDiscard(G, pl, card, {});
  }
  log(G, MC.nameOf(card) + ' 발사 — ' + MC.nameOf(target) + '에게 ' + dmg + ' 피해 (카운터 ' + counters + ')');
  MC.applyDamage(G, target, dmg, { source: pl, isAttack: true });
};

/* 개발용 */
ACTIONS.drawCard = function(G, a){ MC.drawCards(G, playerByUid(G, a.player), a.amount||1); };

/* ── 공용 조회/유틸 ── */
function playerByUid(G, uid){ const p = G.players.find(p=>p.uid===uid); if(!p) throw new Error('플레이어 없음: '+uid); return p; }
function playersInOrder(G){
  const n = G.players.length, out = [];
  for (let i=0;i<n;i++){ const p = G.players[(G.firstPlayer+i)%n]; if (!p.eliminated) out.push(p); }
  return out;
}
function rotateFirstPlayer(G){
  G.firstPlayer = (G.firstPlayer + 1) % G.players.length;
  log(G, '선 플레이어 → ' + G.players[G.firstPlayer].uid);
}
function allInPlay(G){
  const out = [];
  for (const pl of playersInOrder(G)){
    out.push(pl);
    out.push(...pl.playArea.allies, ...pl.playArea.supports, ...pl.playArea.upgrades, ...pl.engagedMinions);
  }
  if (G.villain) out.push(G.villain, ...(G.villain.attachments||[]));
  if (G.mainScheme) out.push(G.mainScheme);
  out.push(...G.sideSchemes);
  // 환경 카드 + 환경 부착물 (울트론 드론 환경 + 업그레이드 드론 등)
  for (const e of (G.environments || [])){ out.push(e); out.push(...(e.attachments || [])); }
  return out;
}
function findByUid(G, uid){ // 라이브 조회 — 스냅샷 stale 참조 방지 (플레이북 §6)
  if (!uid) return null;
  return allInPlay(G).find(x => x.uid === uid) ||
         G.players.flatMap(p=>p.hand.concat(p.discard, p.deck)).find(x=>x.uid===uid) ||
         // 조우 영역 + 공개 진행 중 카드 (의무/배신 공개 처리 중 self 참조 — resolveObligation 등)
         (G.revealing && G.revealing.uid === uid ? G.revealing : null) ||
         (G.encounterDeck||[]).find(x=>x.uid===uid) ||
         (G.encounterDiscard||[]).find(x=>x.uid===uid) ||
         (G.pendingEncounters||[]).map(pe=>pe.inst).find(x=>x&&x.uid===uid) || null;
}
function resolveTarget(G, sel, ctx){
  if (!sel || sel === 'self') return [ctx.player || ctx.self];
  if (sel === 'card' || sel === 'thisCard') return [ctx.card || ctx.self].filter(Boolean);  // 플레이된 카드/동료 자신 (루크 케이지 Tough 등)
  if (sel === 'villain') return [G.villain];
  if (sel === 'chosen') return ctx.targets || [];
  if (sel === 'target') return ctx.target ? [ctx.target] : [];   // 단일 대상(부착물 강제반응의 피해 대상 등)
  if (sel === 'engagedPlayer'){   // 이 하수인(ctx.self)과 교전 중인 플레이어 (고블린 솔저 처치 시 등)
    const self = ctx.self || ctx.card;
    const uid = self && self.engagedWith;
    const pl = uid && G.players.find(p => p.uid === uid);
    return pl ? [pl] : [];
  }
  if (sel === 'firstPlayer') return [playersInOrder(G)[0]];   // 첫 플레이어 (폭발! X 피해 등)
  if (sel === 'allPlayers') return playersInOrder(G);
  if (sel === 'allFriendly'){   // 모든 우호 캐릭터: 각 플레이어 히어로 + 그 플레이어의 동료 (충격파 폭발 01154)
    const out = [];
    for (const pl of playersInOrder(G)){
      if (pl.eliminated) continue;
      out.push(pl);
      out.push(...(pl.playArea ? pl.playArea.allies : []));
    }
    return out;
  }
  if (sel === 'controlled'){   // 활성 플레이어가 통제하는 캐릭터: 그 히어로 + 동료 (충격파 폭발 부스트★)
    const pl = ctx.player || playersInOrder(G)[0];
    const out = [pl];
    out.push(...(pl.playArea ? pl.playArea.allies : []));
    return out;
  }
  if (sel === 'allEnemies'){   // 빌런 + 모든 교전 하수인 (광역기)
    const out = [];
    if (G.villain) out.push(G.villain);
    for (const pl of G.players) for (const m of pl.engagedMinions) out.push(m);
    return out;
  }
  if (sel === 'villainAndMyMinions'){   // 빌런 + 이 플레이어와 교전한 하수인만 (라이트닝 스트라이크 06006)
    const pl = ctx.player || playersInOrder(G)[0];
    const out = [];
    if (G.villain) out.push(G.villain);
    for (const m of (pl.engagedMinions || [])) out.push(m);
    return out;
  }
  throw new Error('[resolveTarget] 미등록 대상: ' + sel);
}
function resolvePlayers(G, sel, ctx){
  if (sel === 'self') return [ctx.player];
  if (sel === 'all') return playersInOrder(G);
  if (sel === 'firstPlayer') return [G.players[G.firstPlayer]];
  throw new Error('[resolvePlayers] 미등록 대상: ' + sel);
}
function fromHand(pl, uid){
  const i = pl.hand.findIndex(c=>c.uid===uid);
  if (i<0) throw new Error('[fromHand] 손패에 없음: '+uid);
  return pl.hand.splice(i,1)[0];
}
function moveToDiscard(G, pl, inst, opt){
  // 보관소가 있는 카드(브루노)가 버려지면 보관된 카드도 소유자 버림 더미로.
  if (inst.stored && inst.stored.length){
    for (const c of inst.stored.splice(0)) pl.discard.push(c);
  }
  pl.discard.push(inst);
  // HP 보너스 카드(MK.5 아머 등)가 버려지면 최대 HP 재계산
  if (MC.cardDef(inst.defCode) && MC.cardDef(inst.defCode).hpBonus) MC.recomputeMaxHp(G, pl);
}
function nameOf(t){ return t.name || t.uid || '?'; }
function setGameOver(G, result, reason, cause){
  // cause: 패배 사유 카테고리 ('heroDefeat' = 히어로 체력 0/전원 탈락, 'schemeComplete' = 메인 스킴 달성).
  // 플레이어 패배 시, 빌런 테마에 맞는 승리 대사를 골라 G.over.villainQuote로 노출 (UI가 표시).
  G.over = { result, reason, cause: cause || null, round: G.round };
  if (result === 'loss' && G.villain && cause){
    const key = G.villain.quoteKey || (MC.cardDef(G.villain.defCode) || {}).quoteKey;
    if (key && MC.hasQuote && MC.hasQuote(key, cause) && MC.randomQuote){
      G.over.villainQuote = MC.randomQuote(key, cause);
      G.over.villainName = MC.nameOf(G.villain);
    }
  }
  log(G, '게임 종료: ' + (result==='win'?'승리':'패배') + ' — ' + reason);
}
function log(G, msg){ G.gameLog.push('[R'+G.round+'/'+G.phase+'] '+msg); }

/* ── 직렬화 ── */
function serialize(G){ return JSON.stringify(G); } // 상태에 라이브 참조 보관 금지 원칙 (uid 참조만)
function deserialize(json){ return JSON.parse(json); }

MC.rand = rand; MC.shuffle = shuffle;
MC.CARDS = CARDS; MC.baseFields = baseFields;
MC.registerCards = registerCards; MC.defineCardFx = defineCardFx; MC.aliasCardFx = aliasCardFx; MC.cardDef = cardDef;
MC.makeInstance = makeInstance; MC.buildDeck = buildDeck;
MC.makeGameState = makeGameState; MC.setupGame = setupGame;
MC.ACTIONS = ACTIONS; MC.dispatch = dispatch;
MC.playerByUid = playerByUid; MC.playersInOrder = playersInOrder;
MC.rotateFirstPlayer = rotateFirstPlayer; MC.allInPlay = allInPlay; MC.findByUid = findByUid;
MC.resolveTarget = resolveTarget; MC.resolvePlayers = resolvePlayers;
MC.fromHand = fromHand; MC.moveToDiscard = moveToDiscard; MC.nameOf = nameOf;
MC.setGameOver = setGameOver; MC.log = log;
MC.serialize = serialize; MC.deserialize = deserialize;

})(typeof window !== 'undefined' ? window : globalThis);
