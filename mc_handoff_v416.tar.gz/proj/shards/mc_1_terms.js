/* ═══════════════════════════════════════════════════════════════
   mc_1_terms.js — 샤드 1/7 : TERMS · GLOSSARY
   편집은 항상 샤드에만. 모놀리스(mc_engine.js)는 reassemble.py로 재생성.
   IIFE는 이 샤드에서 열리고 mc_7_core.js에서 닫힌다.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC = global.MC || {};
MC.VERSION = 'v2026.07.12.172';

/* ── TERMS: 게임 내 모든 용어의 단일 출처. 신규 용어는 grep 후 없을 때만 추가. ──
   한국어 아이덴티티: 이전 빌드(v802) 용어 승계 — 용맹/정의/리더십/보호.
   ※ 한국어판 공식 용어집 확보 시 대조 예정 (PROJECT_STATE 보류항목 T-1) */
const TERMS = {
  // 스탯
  attack:'공격력', defense:'방어력', thwart:'저지력', health:'체력',
  recover:'회복력', handSize:'손패 한도', cost:'비용', threat:'위협',
  // 자원 아이콘
  physical:'물리', mental:'정신', energy:'에너지', wild:'와일드',
  // 성향(aspect) — 이전 빌드 승계
  aggression:'용맹', justice:'정의', leadership:'리더십', protection:'보호', basic:'기본',
  // 플레이어 카드 유형
  hero:'영웅', 'alter-ego':'알터에고', ally:'동료', event:'이벤트',
  support:'지원', upgrade:'업그레이드', resource:'자원 카드',
  // 인카운터 카드 유형
  villain:'빌런', main_scheme:'메인 스킴', side_scheme:'사이드 스킴',
  minion:'하수인', treachery:'배신', attachment:'부착', environment:'환경',
  obligation:'책무', nemesis:'네메시스',
  // 상태 토큰
  stunned:'기절', confused:'혼란', tough:'강인',
  // 페이즈/진행
  playerPhase:'플레이어 페이즈', villainPhase:'빌런 페이즈',
  ready:'준비', exhausted:'소진', firstPlayer:'선 플레이어',
  round:'라운드', setup:'셋업',
  // 키워드 (이전 빌드 승계: guard=수호)
  guard:'수호', retaliate:'보복', piercing:'관통', overkill:'과잉살상',
  quickstrike:'속공', stalwart:'불굴', surge:'쇄도', peril:'위기',
  hinder:'방해', incite:'선동', ranged:'원거리', aerial:'공중',
  toughness:'강인함', restricted:'제한', permanent:'영구', uses:'사용 횟수',
  boost:'증폭', acceleration:'가속', crisis:'위기 아이콘', hazard:'위험 아이콘',
};
function T(key){ return TERMS[key] !== undefined ? TERMS[key] : ('¿'+key+'?'); }

/* ── GLOSSARY: 신규 플레이어용 설명 사전 (UI 툴팁 소스) ── */
const GLOSSARY = {
  tough:'강인: 이 캐릭터가 받을 다음 피해를 모두 무효화하고 강인 토큰을 제거한다.',
  stunned:'기절: 이 캐릭터는 다음 공격을 할 수 없다. 공격 대신 기절 토큰을 제거한다.',
  confused:'혼란: 이 캐릭터는 다음 저지를 할 수 없다. 저지 대신 혼란 토큰을 제거한다.',
  guard:'수호: 수호 하수인이 교전 중이면, 그 하수인을 먼저 처리해야 빌런을 공격할 수 있다.',
  retaliate:'보복 N: 이 캐릭터가 공격받아 피해를 입으면, 공격자에게 피해 N을 준다.',
  piercing:'관통: 이 공격은 강인 토큰을 제거하지 않고 무시한다.',
  overkill:'과잉살상: 하수인을 처치하고 남은 피해를 빌런에게 준다.',
  quickstrike:'속공: 이 적이 플레이에 들어올 때, 즉시 (교전 중인) 영웅을 공격한다.',
  surge:'쇄도: 이 카드 공개 후, 인카운터 카드 1장을 추가로 공개한다.',
  boost:'증폭: 빌런 활성화 시 인카운터 덱에서 뒤집는 카드의 증폭 아이콘만큼 수치가 오른다.',
};
function glossaryFor(key){ return GLOSSARY[key] || null; }

MC.TERMS = TERMS; MC.T = T; MC.GLOSSARY = GLOSSARY; MC.glossaryFor = glossaryFor;
