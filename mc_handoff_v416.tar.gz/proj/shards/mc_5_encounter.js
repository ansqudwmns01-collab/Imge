/* ═══════════════════════════════════════════════════════════════
   mc_5_encounter.js — 샤드 5/7 : 인카운터덱 · 빌런 페이즈 (스텝 큐)
   ★ 설계: 빌런 페이즈는 스텝 큐(G.vq)로 진행. 사람 결정이 필요한 지점
     (방어 선언)에서 G.pending을 세우고 멈춘다. 결정은 액션(resolveDefense)
     으로 들어와 pending을 해소하고 큐를 재개한다.
     → 결정이 곧 액션이므로 재생(replay) 동기화가 그대로 성립.
   빌런 페이즈(코어 룰): ①위협 배치 ②빌런+하수인 활성화 ③인카운터 배분
     ④공개/해결 ⑤선 플레이어 이동·라운드 종료
   ═══════════════════════════════════════════════════════════════ */

function drawEncounterCard(G){
  if (G.encounterDeck.length === 0){
    G.encounterDeck = MC.shuffle(G, G.encounterDiscard.splice(0));
    G.acceleration += 1;
    MC.log(G, '인카운터덱 리셔플 — 가속 토큰 +1 (누적 ' + G.acceleration + ')');
    if (G.encounterDeck.length === 0) return null;
  }
  return G.encounterDeck.pop();
}

function dealEncounterTo(G, pl, n){
  for (let k=0;k<n;k++){
    const c = drawEncounterCard(G);
    if (c) G.pendingEncounters.push({ player: pl.uid, uid: c.uid, inst: c });
  }
}

/* 부스트★ 효과: 부스트로 공개된 카드에 boostStarEffect(또는 boostStarPutIntoPlay)가 있으면 발동.
   - putIntoPlay: 그 카드(하수인)를 부스트 뽑은 플레이어와 교전 상태로 전장 배치 (무기 밀매상).
     이 경우 카드는 버려지지 않고 전장에 남는다 → true 반환(호출측이 버림 스킵).
   - 그 외 이름: EFFECTS 파이프라인 실행 (im-tough=toughEnemy 등). 카드는 정상 버림.
   actKind: 'attack'|'scheme' — 이 부스트가 어떤 활성화에 뒤집혔는지.
   boostStarOnScheme: 암약 활성화 부스트일 때만 발동하는 효과 배열 (프로그램 전송기 01141 등
   "★강제 반응: 울트론이 암약한 후 → …" 유형). boostStarOnDamage(공격+피해 조건부)의 짝.
   반환: true면 카드가 전장에 배치됨(버리지 말 것), false면 일반 버림 진행. */
function resolveBoostStar(G, pl, boostCard, actKind){
  const def = MC.cardDef(boostCard.defCode);
  G._lastBoostStar = null;   // UI 힌트: 이번 부스트★로 무슨 일이 일어났는지 (minion 배치/효과)
  if (!def) return false;
  // 하수인 전장 배치형 (boost_star + minion): 부스트로 뽑히면 교전 등장
  if (def.boostStarPutIntoPlay && def.type === 'minion'){
    boostCard.engagedWith = pl.uid;
    pl.engagedMinions.push(boostCard);
    boostCard.status = boostCard.status || { stunned:0, confused:0, tough: def.toughness ? 1 : 0 };
    MC.minionEnteredPlay(G, boostCard, pl);
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★: ' + pl.uid + '와(과) 교전 상태로 전장 등장');
    (G.revealLog = G.revealLog || []).push({ defCode: boostCard.defCode, name: boostCard.name, type: 'minion', player: pl.uid, fromBoostStar: true });
    G._lastBoostStar = { kind: 'minion' };
    return true;
  }
  // 부스트★ 사이드 스킴 전장 배치 (Goblin Nation): 위협 셋업 후 사이드 스킴으로 등장.
  if (def.boostStarPutIntoPlay && def.type === 'side_scheme'){
    boostCard.threat = (def.baseThreatPerPlayer || 0) * G.players.length + (def.baseThreat || 0);
    boostCard.peakThreat = boostCard.threat;
    boostCard.isMain = false;
    G.sideSchemes.push(boostCard);
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★: 사이드 스킴으로 전장 등장 (위협 ' + boostCard.threat + ')');
    (G.revealLog = G.revealLog || []).push({ defCode: boostCard.defCode, name: boostCard.name, type: 'side_scheme', player: pl.uid, fromBoostStar: true });
    G._lastBoostStar = { kind: 'side_scheme' };
    return true;
  }
  // 효과형 (toughEnemy=villain, discardBooster=player 등)
  if (def.boostStarEffect && MC.EFFECTS[def.boostStarEffect]){
    MC.runEffectList(G, [{ fx: def.boostStarEffect }], { player: pl, self: boostCard, card: boostCard });
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★ 효과: ' + def.boostStarEffect);
    G._lastBoostStar = { kind: 'effect', effect: def.boostStarEffect };
  }
  // 파라미터형 무조건 발동 (boostStarEffects: effects 배열) — 활성화 종류 무관.
  // boostStarEffect(단일 fx명, 파라미터 없음)로 표현 못 하는 데이터 효과용 (수리 시퀀스 회복/드론 등).
  if (def.boostStarEffects){
    MC.runEffectList(G, def.boostStarEffects, { player: pl, self: boostCard, card: boostCard });
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★ 효과 발동');
    G._lastBoostStar = { kind: 'effects' };
  }
  // 암약 조건부 (boostStarOnScheme): 이 부스트가 암약(스킴) 활성화에 뒤집혔을 때만 발동
  if (def.boostStarOnScheme && actKind === 'scheme'){
    MC.runEffectList(G, def.boostStarOnScheme, { player: pl, self: boostCard, card: boostCard });
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★(암약) 효과 발동');
    G._lastBoostStar = { kind: 'effect', effect: 'boostStarOnScheme' };
  }
  // 선택형 부스트★ (boostStarChoice): 부스트로 뒤집힌 플레이어가 선택 (안드로이드 효율 등).
  // 부스트 공개는 방어/암약 해소 도중이라 즉시 pending을 세우면 흐름이 깨진다 →
  // deferred로 적재하고, 해당 활성화(공격·암약)가 끝난 시점에 flushDeferredBoostChoice가 처리.
  if (def.boostStarChoice){
    G._deferredBoostChoice = { playerUid: pl.uid, selfName: MC.nameOf(boostCard),
                               choiceDef: def.boostStarChoice };
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★ 선택 예약 (활성화 종료 후 처리)');
    G._lastBoostStar = { kind: 'choice' };
  }
  // 부스트★ 셔플백 (Goblin Knight): 이 카드를 버리지 않고 조우덱에 셔플백.
  if (def.boostStarShuffleBack){
    G.encounterDeck.push(boostCard);
    MC.shuffle(G, G.encounterDeck);
    MC.log(G, MC.nameOf(boostCard) + ' — 부스트★: 조우덱에 셔플백');
    G._lastBoostStar = { kind: 'shuffleBack' };
    return true;   // 버리지 않음
  }
  return false;
}
MC.resolveBoostStar = resolveBoostStar;

// 적(빌런/하수인)의 유효 공격력 — 동적 ATK + 패시브 집계. 타이타니아(01162) atkEqualsHp: ATK = 현재 HP.
// 패시브(enemyAtkPassive): Goblin Nation 등 "고블린 적 +1 ATK" 지속 효과를 중앙 집계.
function enemyAtk(G, enemy){
  if (!enemy) return 0;
  const d = MC.cardDef(enemy.defCode);
  let atk = (d && d.atkEqualsHp) ? Math.max(0, enemy.hp || 0) : (enemy.attack || 0);
  if (MC.enemyAtkPassive) atk += MC.enemyAtkPassive(G, enemy);
  return Math.max(0, atk);
}
MC.enemyAtk = enemyAtk;

/* 하수인/빌런 ATK 패시브 집계 — Taskmaster(교전 플레이어의 통제 업그레이드 1장당 +1) 등. 중앙 인덱스. */
MC.enemyAtkPassive = function(G, enemy){
  const d = MC.cardDef(enemy.defCode);
  let bonus = 0;
  if (d && d.minionStatScale && d.minionStatScale.atk){
    const pl = G.players.find(p => p.uid === enemy.engagedWith);
    if (pl) bonus += (pl.playArea.upgrades || []).length * d.minionStatScale.atk;
  }
  // 얼티밋 바이오-서번트(04114): 자신에게 붙은 부착물 1개당 ATK +N.
  if (d && d.minionStatScale && d.minionStatScale.perSelfAttachment){
    bonus += (enemy.attachments || []).length * d.minionStatScale.perSelfAttachment;
  }
  return bonus;
};
/* 하수인 암약(SCH) 패시브 집계 — Taskmaster 통제 업그레이드 스케일. */
MC.enemySchemePassive = function(G, enemy){
  const d = MC.cardDef(enemy.defCode);
  let bonus = 0;
  if (d && d.minionStatScale && d.minionStatScale.sch){
    const pl = G.players.find(p => p.uid === enemy.engagedWith);
    if (pl) bonus += (pl.playArea.upgrades || []).length * d.minionStatScale.sch;
  }
  return bonus;
};

/* 지연된 부스트★ 선택 처리 — 공격/암약 활성화가 끝난 뒤 호출.
   choiceDef: { prompt, resourcePayIcons, droneFallback } 형태.
   자원 지불이 가능하면 선택 pending(revealChoice)을 세우고, 불가능하면 자동으로 드론 스폰
   (공식: "spend a resource OR put a drone" — 자원을 못 내면 드론만 남음).
   pending을 세우면 true 반환 → 호출측은 큐를 멈춘다(processVillainQueue가 감지). */
function flushDeferredBoostChoice(G){
  const d = G._deferredBoostChoice;
  if (!d) return false;
  G._deferredBoostChoice = null;
  const pl = G.players.find(p => p.uid === d.playerUid);
  if (!pl || pl.eliminated) return false;
  const cd = d.choiceDef;
  const pay = cd.resourcePayIcons || { energy: 1 };
  // 활성 플레이어가 요구 자원을 낼 수 있는지(손패 아이콘 + 와일드) 판정
  let canPay = false;
  const needType = Object.keys(pay)[0];
  const needN = pay[needType] || 1;
  let avail = 0;
  for (const c of pl.hand){
    const r = c.resources || {};
    avail += (r[needType] || 0) + (r.wild || 0);
  }
  canPay = avail >= needN;
  const droneEffects = [{ fx: 'spawnDrone', scope: 'activePlayer',
                          fallback: cd.droneFallback || { attack:1, scheme:1, hp:1 } }];
  if (!canPay){
    // 자원 불가 → 자동 드론 (선택 없음)
    MC.log(G, d.selfName + ' — 부스트★: 지불할 자원 없음 → 드론 자동 등장');
    MC.runEffectList(G, droneEffects, { player: pl, self: null });
    if (cd.vfx) G.fxCardEffect = { vfx: cd.vfx, quote: cd.quoteAuto || null };
    return false;
  }
  // 선택 pending — resolveRevealChoice가 payIcons/effects 처리
  G.pending = { kind: 'revealChoice', player: pl.uid, selfUid: null,
    prompt: cd.prompt || '자원을 지불하거나 드론을 등장시키세요',
    options: [
      { key: 'resource', label: cd.resourceLabel || '자원 1 지불 (회피)', payIcons: pay, effects: [] },
      { key: 'drone', label: cd.droneLabel || '뒷면 드론 등장', effects: droneEffects },
    ] };
  MC.log(G, d.selfName + ' — 부스트★ 선택 대기 (' + pl.uid + ')');
  return true;
}
MC.flushDeferredBoostChoice = flushDeferredBoostChoice;

/* 강제 위협 선택 체인 (노라드 습격 01138b) — 대기 중인 각 플레이어에게 순차로 선택 pending을 세운다.
   메인 스킴 def.forcedThreatChoice의 options(위협2 / 드론)를 revealChoice로. 한 명 해소 후
   resolveRevealChoice가 다시 이 함수를 호출해 다음 플레이어로 이어간다. pending 세우면 true. */
function flushThreatChoice(G){
  const q = G._pendingThreatChoice;
  if (!q || !q.length) return false;
  const msDef = MC.cardDef(G.mainScheme.defCode);
  const cd = msDef && msDef.forcedThreatChoice;
  if (!cd){ G._pendingThreatChoice = null; return false; }
  let pl = null;
  while (q.length){
    const uid = q.shift();
    const cand = G.players.find(p => p.uid === uid);
    if (cand && !cand.eliminated){ pl = cand; break; }
  }
  if (!pl){ G._pendingThreatChoice = null; return false; }
  G.pending = { kind:'revealChoice', player: pl.uid, selfUid: G.mainScheme.uid,
    prompt: cd.prompt || '선택하세요', options: cd.options || [] };
  MC.log(G, MC.nameOf(G.mainScheme) + ' — 강제 반응: ' + pl.uid + ' 선택 대기');
  return true;
}
MC.flushThreatChoice = flushThreatChoice;

/* 각 플레이어 선택 체인(범용) — whenRevealed 등에서 "각 플레이어가 A or B를 선택" (공격 받는 중 01151,
   충격파 폭발류). G._pendingEachChoice = { selfUid, prompt, options, queue:[uids] }.
   한 명 해소 후 resolveRevealChoice가 다시 호출해 다음 플레이어로. pending 세우면 true. */
function flushEachChoice(G){
  const st = G._pendingEachChoice;
  if (!st || !st.queue || !st.queue.length){ G._pendingEachChoice = null; return false; }
  let pl = null;
  while (st.queue.length){
    const uid = st.queue.shift();
    const cand = G.players.find(p => p.uid === uid);
    if (cand && !cand.eliminated){ pl = cand; break; }
  }
  if (!pl){ G._pendingEachChoice = null; return false; }
  G.pending = { kind:'revealChoice', player: pl.uid, selfUid: st.selfUid || null,
    prompt: st.prompt || '선택하세요', options: st.options || [] };
  MC.log(G, '강제 선택 — ' + pl.uid + ' 선택 대기');
  return true;
}
MC.flushEachChoice = flushEachChoice;

/* ── 위협 ── */
function placeThreat(G, schemeRef, amount){
  if (amount <= 0) return;
  const s = MC.resolveScheme(G, schemeRef);
  // 이벤트 인터럽트로 예약된 위협→피해 대체 (큰 힘에는 큰 책임): 예약량만큼 위협 차감.
  // (히어로 피해는 이벤트 플레이 시점에 이미 적용됨)
  if (G.preventNextThreat && G.preventNextThreat > 0){
    const conv = Math.min(G.preventNextThreat, amount);
    amount -= conv;
    G.preventNextThreat -= conv;
    MC.log(G, '큰 힘에는 큰 책임 — 위협 ' + conv + ' 피해로 대체 (배치 취소)');
    if (amount <= 0){ if (G.preventNextThreat <= 0) delete G.preventNextThreat; return; }
    if (G.preventNextThreat <= 0) delete G.preventNextThreat;
  }
  // 신분 위협 방지 인터럽트 (제니퍼 왈터스 "I Object!": 알터에고, 라운드 1회, 1 방지)
  for (const pl of G.players){
    if (pl.eliminated) continue;
    const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    const def = MC.cardDef(faceCode);
    const tp = def && def.threatPrevent;
    if (!tp) continue;
    if (tp.form && pl.form !== tp.form) continue;
    if (tp.oncePerRound && pl.usedThreatPreventThisRound) continue;
    const prevent = Math.min(tp.amount || 1, amount);
    amount -= prevent;
    if (tp.oncePerRound) pl.usedThreatPreventThisRound = true;
    MC.log(G, MC.nameOf(pl) + ' — ' + (tp.name||'위협 방지') + ': 위협 ' + prevent + ' 방지');
    if (amount <= 0){ MC.log(G, MC.nameOf(s) + ' 위협 전량 방지됨'); return; }
  }
  // 플레이 영역 준비(Preparation) 위협 방지 — Counterintelligence(메인 스킴 위협 놓일 때 버림 → 3 방지 + Widowmaker).
  // 중앙 집계 인덱스 확장: upgrade의 threatPrevent{discardSelf:true} 스캔. 빌런 페이즈 흐름 보호 위해 Widowmaker는 빌런 직접 피해.
  if (s.isMain){
    for (const pl of G.players){
      if (pl.eliminated || amount <= 0) continue;
      if (pl.form !== 'hero') continue;
      for (const c of (pl.playArea.upgrades || []).slice()){
        if (amount <= 0) break;
        const cdef = MC.cardDef(c.defCode);
        const tp2 = cdef && cdef.threatPrevent;
        if (!tp2 || tp2.discardSelf !== true) continue;
        const prevent = Math.min(tp2.amount || 3, amount);
        amount -= prevent;
        MC.triggerPreparation(G, pl, c);
        if (G._widowmaker){ const w = G._widowmaker; G._widowmaker = null; if (G.villain) MC.applyDamage(G, G.villain, w.damage, { source:{ isPlayer:true }, isAttack:false }); }
        MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ': 메인 위협 ' + prevent + ' 방지');
        if (amount <= 0){ MC.log(G, MC.nameOf(s) + ' 위협 전량 방지됨'); return; }
      }
    }
  }
  s.threat += amount;
  // 사이드스킴 최대 위협 추적 (UI 위협바의 분모 — "남은 저지량" 표시용)
  if (!s.isMain) s.peakThreat = Math.max(s.peakThreat || 0, s.threat);
  MC.log(G, MC.nameOf(s) + ' 위협 +' + amount + ' (' + s.threat + '/' + (s.maxThreat||'∞') + ')');
  if (s.isMain && s.threat >= s.maxThreat) MC.onMainSchemeThreshold(G, s);
}
function removeThreat(G, schemeRef, amount){
  const s = MC.resolveScheme(G, schemeRef);
  // 파멸의 카운트다운(01139b) 등: 이 스킴에서는 위협을 제거할 수 없다.
  const sdef = MC.cardDef(s.defCode);
  if (sdef && sdef.threatCannotRemove){
    let blocked = true;
    // 조건부: {whileMinionInPlay:'abomination'} — 그 하수인이 전장에 있을 때만 제거 불가 (Total Destruction).
    if (typeof sdef.threatCannotRemove === 'object' && sdef.threatCannotRemove.whileMinionInPlay){
      const code = sdef.threatCannotRemove.whileMinionInPlay;
      blocked = G.players.some(pl => (pl.engagedMinions || []).some(m => m.defCode === code));
    }
    if (blocked){
      MC.log(G, MC.nameOf(s) + ' — 위협을 제거할 수 없다 (제거 불가 스킴)');
      return;
    }
  }
  const before = s.threat;
  s.threat = Math.max(0, s.threat - amount);
  MC.log(G, MC.nameOf(s) + ' 위협 -' + (before - s.threat) + ' (' + s.threat + ')');
  if (!s.isMain && s.threat === 0) MC.onSideSchemeCleared(G, s);
}
function resolveScheme(G, ref){
  if (ref === 'main' || !ref) return G.mainScheme;
  const ss = G.sideSchemes.find(s => s.uid === ref || s.code === ref);
  if (!ss) throw new Error('[resolveScheme] 스킴 없음: ' + ref);
  return ss;
}
function onSideSchemeCleared(G, s){
  G.sideSchemes = G.sideSchemes.filter(x => x !== s);
  MC.fireCardHook(G, s, 'whenCompleted', {}); // 사이드 스킴 "격퇴 시" 훅
  G.encounterDiscard.push(s);
  MC.log(G, MC.nameOf(s) + ' 격퇴');
}
function onMainSchemeThreshold(G, s){
  const def = MC.cardDef(s.defCode);
  if (def.nextStage) MC.advanceMainScheme(G);
  else MC.setGameOver(G, 'loss', '메인 스킴 완성', 'schemeComplete');
}
function advanceMainScheme(G){
  const old = G.mainScheme;
  MC.fireCardHook(G, old, 'whenCompleted', {});
  const next = MC.cardDef(old.defCode).nextStage;
  const ms = MC.makeInstance(G, next, { isMain: true });
  const def = MC.cardDef(next);
  const n = G.players.length;
  ms.threat = (def.baseThreatPerPlayer||0) * n + (def.baseThreat||0);
  ms.maxThreat = (def.maxThreatPerPlayer||0) * n + (def.maxThreat||0);
  G.mainScheme = ms;
  MC.log(G, '메인 스킴 전환 → ' + MC.nameOf(ms) + ' (' + ms.threat + '/' + ms.maxThreat + ')');
  // 공식 룰: 새 단계가 공개되면 그 면의 "공개 시" 효과 해결 (클로 01117 등)
  MC.fireCardHook(G, ms, 'whenRevealed', { player: G.players[G.firstPlayer] });
}

/* ── 공용 조우 헬퍼 (재사용 인덱스) ──
   revealSpecificSideScheme: 특정 사이드 스킴을 조우덱/버림에서 찾아 공개 + 조우덱 셔플.
     (클로 II "불멸의 클로", 지하 유통망 셋업 "방어망" 등이 이름으로 참조)
   discardUntilMinionIntoPlay: 조우덱에서 하수인이 나올 때까지 버림 →
     지정 플레이어(기본: 첫 플레이어)와 교전 상태로 "전장 배치"(put into play — 공개 아님,
     whenRevealed 미발화, 부스트★ 배치와 동일 규칙). traitFilter로 특성 제한 가능
     (마스터즈 오브 이블 01128 재사용 대비). */
function revealSpecificSideScheme(G, defCode){
  let inst = null;
  let i = G.encounterDeck.findIndex(c => c.defCode === defCode);
  if (i >= 0) inst = G.encounterDeck.splice(i, 1)[0];
  else {
    i = G.encounterDiscard.findIndex(c => c.defCode === defCode);
    if (i >= 0) inst = G.encounterDiscard.splice(i, 1)[0];
  }
  if (!inst){
    /* 조우덱 구성에 포함되지 않은 빌런 전용 사이드스킴(예: 불멸의 클로)은
       카드가 직접 이름으로 참조하므로 새 인스턴스를 생성해 공개한다. */
    inst = MC.makeInstance(G, defCode, {});
    if (!inst){ MC.log(G, '[' + defCode + '] 정의 없음 — 공개 불발'); return null; }
  }
  const pl = G.players[G.firstPlayer];
  resolveEncounterCard(G, pl, inst);
  MC.shuffle(G, G.encounterDeck);
  MC.log(G, MC.nameOf(inst) + ' 공개 — 조우덱 셔플');
  return inst;
}
function discardUntilMinionIntoPlay(G, pl, traitFilter){
  pl = pl || G.players[G.firstPlayer];
  let minion = null;
  let guard = G.encounterDeck.length + G.encounterDiscard.length + 1; // 하수인 부재 시 무한 방지
  while (guard-- > 0){
    const c = drawEncounterCard(G);
    if (!c) break;
    const ok = c.type === 'minion' && (!traitFilter || (c.traits || []).includes(traitFilter));
    if (ok){ minion = c; break; }
    G.encounterDiscard.push(c);
    MC.log(G, MC.nameOf(c) + ' 버림 (하수인 탐색 중)');
  }
  if (!minion){ MC.log(G, '조우덱에 ' + (traitFilter ? traitFilter + ' ' : '') + '하수인 없음 — 효과 불발'); return null; }
  minion.engagedWith = pl.uid;
  pl.engagedMinions.push(minion);
  MC.minionEnteredPlay(G, minion, pl);
  (G.revealLog = G.revealLog || []).push({ defCode: minion.defCode, name: minion.name, type: 'minion', player: pl.uid });
  MC.log(G, MC.nameOf(minion) + ' — 전장 배치 (' + pl.uid + '와 교전)');
  return minion;
}

/* 하수인 탐색 배치(덱+버림) — 조우덱과 버림 더미에서 (특성 일치) 하수인 1명을 찾아
   pl과 교전 상태로 전장에 놓고 조우덱 셔플. "search the encounter deck and discard pile
   for a [[X]] minion and put it into play engaged with you" (혼돈의 지배 01133 등) 범용. */
function searchMinionIntoPlay(G, pl, traitFilter, codeFilter){
  pl = pl || G.players[G.firstPlayer];
  const match = c => c.type === 'minion'
    && (!traitFilter || (c.traits || []).includes(traitFilter))
    && (!codeFilter || (c.defCode || c.code) === codeFilter);
  let minion = null;
  for (const src of [G.encounterDeck, G.encounterDiscard]){
    const i = src.findIndex(match);
    if (i >= 0){ minion = src.splice(i, 1)[0]; break; }
  }
  if (!minion && codeFilter){
    // 조우덱/버림에 없으면 정의로부터 생성(모듈러 셋업 미포함 시 대비) — 마담 히드라 등 named 소환.
    minion = MC.makeInstance(G, codeFilter, {});
    minion.type = 'minion';
    MC.log(G, MC.nameOf(minion) + ' — 정의로부터 소환');
  }
  if (!minion){
    MC.log(G, '조우덱/버림에 ' + (traitFilter ? traitFilter + ' ' : '') + '하수인 없음 — 탐색 불발');
    return null;
  }
  minion.engagedWith = pl.uid;
  pl.engagedMinions.push(minion);
  MC.minionEnteredPlay(G, minion, pl);
  (G.revealLog = G.revealLog || []).push({ defCode: minion.defCode, name: minion.name, type: 'minion', player: pl.uid });
  MC.shuffle(G, G.encounterDeck);
  MC.log(G, MC.nameOf(minion) + ' 탐색 — 전장 배치 (' + pl.uid + '와 교전) · 조우덱 셔플');
  return minion;
}

/* 하수인 연쇄 공격 체인(범용) — pairs: [{attackerUid, playerUid}, ...] 를 순서대로 처리.
   "각 X 하수인이 교전 중인 히어로를 공격한다" (혼돈의 지배 01133, 하일 히드라 03030 유형).
   기절 하수인은 공식 룰대로 기절 소모 후 공격 생략(공격 미개시로 집계). 죽은/사라진 공격자는 스킵.
   첫 유효 공격자에 대한 방어 pending을 세우고 남은 쌍을 pending.attackChain에 실어
   resolveDefensePending이 해소 후 다음 공격을 이어간다. 공격을 1개라도 개시하면 true. */
function startMinionAttackChain(G, pairs){
  const chain = (pairs || []).slice();
  while (chain.length){
    const { attackerUid, playerUid } = chain.shift();
    const attacker = MC.findByUid(G, attackerUid);
    const pl = G.players.find(x => x.uid === playerUid);
    if (!attacker || attacker.hp <= 0 || !pl || pl.eliminated) continue;
    if (attacker.status && attacker.status.stunned > 0){
      attacker.status.stunned--;
      MC.log(G, MC.nameOf(attacker) + ' 기절 소모 — 공격 생략');
      continue;
    }
    G.pending = {
      kind: 'defense',
      player: pl.uid,
      attackerUid: attacker.uid,
      amount: MC.enemyAtk(G, attacker),
      prevented: 0,
      piercing: !!attacker.piercing,
      attackChain: chain.length ? chain : undefined,
    };
    MC.log(G, MC.nameOf(attacker) + ' → ' + pl.uid + ' 공격 (피해 ' + (attacker.attack||0) + ') — 방어 선언 대기');
    return true;
  }
  return false;
}

/* ── 울트론 드론 서브시스템 (범용 환경 기반) ──
   드론 스탯은 droneStats를 가진 환경 카드(울트론 드론 01140)가 정의하고,
   환경 부착물의 droneStatBonus(업그레이드 드론 01142: ATK+1 HP+1)가 가산된다. */
function droneBaseStats(G){
  for (const e of (G.environments || [])){
    const d = MC.cardDef(e.defCode);
    if (!d || !d.droneStats) continue;
    const base = Object.assign({}, d.droneStats);
    for (const a of (e.attachments || [])){
      const ad = MC.cardDef(a.defCode);
      const b = ad && ad.droneStatBonus;
      if (b) for (const k in b) base[k] = (base[k] || 0) + b[k];
    }
    // 울트론 III(01136) droneBuffVillain: 빌런 지속 능력이 모든 드론에 ATK/HP 보너스.
    if (G.villain){
      const vb = MC.cardDef(G.villain.defCode).droneBuffVillain;
      if (vb) for (const k in vb) base[k] = (base[k] || 0) + vb[k];
    }
    return base;
  }
  // 환경이 없어도 빌런 지속 버프는 유효 (fallback 스탯에 얹기 위해 null 대신 버프만 반환하지 않음 —
  // 환경 없으면 배신/사이드스킴의 fallback이 스탯을 정하고, 그 위에 버프는 recalc 시 재적용).
  return null;
}

/* 뒷면 드론 스폰: pl 덱 맨 위 카드를 뒷면으로 뒤집어 드론 하수인으로 전장 배치 (교전).
   공식 울트론: 플레이어 덱 카드가 곧 드론 군단 — 처치 시 뒷면 카드는 소유자 버림 더미로. */
function spawnFacedownDrone(G, pl, fallbackStats){
  pl = pl || G.players[G.firstPlayer];
  const stats = droneBaseStats(G) || fallbackStats || null;
  if (!stats){ MC.log(G, '드론 환경 없음 — 드론 스폰 불발'); return null; }
  if (!pl.deck.length){ MC.log(G, pl.uid + ' 덱 소진 — 드론 스폰 불발'); return null; }
  const facedown = pl.deck.pop();
  const drone = MC.makeInstance(G, 'facedown-drone', {});
  drone.isDrone = true;
  drone.droneOwner = pl.uid;
  drone.facedownCard = facedown;
  drone.attack = stats.attack || 0;
  drone.scheme = stats.scheme || 0;
  drone.hp = drone.maxHp = stats.hp || 1;
  drone.engagedWith = pl.uid;
  pl.engagedMinions.push(drone);
  MC.minionEnteredPlay(G, drone, pl);
  (G.revealLog = G.revealLog || []).push({ defCode: 'facedown-drone', name: drone.name, type: 'minion', player: pl.uid });
  MC.log(G, MC.nameOf(drone) + ' 기동 — ' + pl.uid + ' 덱 맨 위 카드가 뒷면 드론으로 (' + pl.uid + '와 교전)');
  return drone;
}

/* 드론 스탯 재계산: 환경 부착물(업그레이드 드론) 부착/이탈 시 전장의 모든 뒷면 드론에 반영.
   HP는 받은 피해를 보존한 채 상한만 조정 — 상한 하락으로 HP 0 이하가 되면 즉시 격파. */
function recalcDroneStats(G){
  const stats = droneBaseStats(G);
  if (!stats) return;
  for (const pl of G.players){
    for (const m of pl.engagedMinions.slice()){
      if (!m.isDrone) continue;
      const dmg = (m.maxHp || 1) - (m.hp || 0);
      m.attack = stats.attack || 0;
      m.scheme = stats.scheme || 0;
      m.maxHp = stats.hp || 1;
      m.hp = m.maxHp - dmg;
      MC.log(G, MC.nameOf(m) + ' 스탯 갱신 — ATK ' + m.attack + ' · HP ' + m.hp + '/' + m.maxHp);
      if (m.hp <= 0) MC.onDefeated(G, m, {});
    }
  }
}

/* ── 빌런 페이즈: 스텝 큐 ── */
function startVillainPhase(G){
  G.phase = 'villain';
  G.revealLog = [];   // 이번 빌런 페이즈에 공개된 조우/부스트 카드 기록 (UI 확인용)
  for (const pl of G.players) pl._missionPrepUsed = false;   // 나타샤 Mission Prep 페이즈당 1회 리셋
  MC.fireHook(G, 'villainPhaseStart', {});
  G.vq = [{ op:'threat' }];
  for (const pl of MC.playersInOrder(G)) G.vq.push({ op:'activations', player: pl.uid });
  G.vq.push({ op:'dealEnc' }, { op:'reveal' }, { op:'endRound' });
  processVillainQueue(G);
}

/* 빌런 페이즈 스텝 1개만 실행 (단계별 진행 모드 — UI가 연출과 함께 순차 호출).
   결정성: dispatch된 villainStep 액션으로만 호출됨. */
function villainStepOnce(G){
  if (G.over) throw new Error('[villainStep] 게임 종료됨');
  if (G.phase !== 'villain') throw new Error('[villainStep] 빌런 페이즈 아님');
  if (G.pending) throw new Error('[villainStep] 대기 중인 결정 해소 필요');
  if (!G.vq.length) throw new Error('[villainStep] 남은 스텝 없음');
  execStep(G, G.vq.shift());
}

function processVillainQueue(G){
  if (G.villainStepMode) return;   // 단계별 진행 모드: UI가 villainStep으로 하나씩 실행
  while (G.vq.length && !G.over && !G.pending){
    const step = G.vq.shift();
    execStep(G, step);
    // 하수인 등장 반응(호크아이 등) — 스텝 중 하수인이 등장했으면 다음 스텝(활성화 등) 전에 선택 물어봄
    if (!G.pending && flushMinionReactions(G)) return;
  }
}

function execStep(G, step){
  switch (step.op){
    case 'threat': {
      // 공식 룰: 빌런 페이즈 1단계 메인 스킴 위협 = ①기본 상승(escalation, 인원수당 1) + ②가속.
      // ② 가속 = 전장의 사이드 스킴 가속 아이콘 합 + 누적 가속 토큰(덱 리셔플 등).
      //   ※ 메인 스킴의 accelIcons는 공식 escalation_threat(=기본 상승률)를 잘못 매핑한 값이라
      //      기본 상승(baseGain)에 이미 포함됨 → 여기서 다시 더하지 않는다(이중 계산 방지).
      const baseGain = G.players.length;                         // escalation: 인원수당 1 (표준)
      let accelIcons = 0;
      for (const s of (G.sideSchemes || [])){
        const sd = MC.cardDef(s.defCode);
        if (sd && sd.accelIcons) accelIcons += (sd.accelIcons === true ? 1 : sd.accelIcons);
      }
      const accelGain = accelIcons + G.acceleration;             // 가속 아이콘 + 누적 토큰
      // 동적 가속: 메인 스킴 def.accelFrom (뮤타젠 구름 2B = 전장 고블린 적 수)
      let dynAccel = 0;
      const msDef0 = MC.cardDef(G.mainScheme.defCode);
      if (msDef0 && msDef0.accelFrom === 'goblinEnemies' && MC.goblinEnemyCount) dynAccel = MC.goblinEnemyCount(G);
      const total = baseGain + accelGain + dynAccel;
      MC.log(G, '메인 스킴 위협: 기본 +' + baseGain + (accelGain>0 ? ' · 가속 +' + accelGain : '') + (dynAccel>0 ? ' · 고블린 +' + dynAccel : '') + ' = +' + total);
      placeThreat(G, 'main', total);
      // 노라드 습격(01138b) 강제반응: 빌런 페이즈 위협 후 각 플레이어 선택(위협2 or 드론).
      const msDef = MC.cardDef(G.mainScheme.defCode);
      // 어보밍맨 None Shall Pass: 빌런 페이즈 1단계 후 지연(delay) 카운터 +1 — 크로스본즈 도주 진행(추격 타이머).
      if (msDef && msDef.delayPerVillainPhase){
        G.mainScheme.delayCounters = (G.mainScheme.delayCounters || 0) + 1;
        MC.log(G, '⏱ 지연 카운터 +1 (누적 ' + G.mainScheme.delayCounters + ') — 크로스본즈가 멀어진다!');
      }
      // 졸라 섬/미친 박사(04112b/04113b): 빌런 페이즈 1단계 후 실험 카운터 +1. 3개 이상이면 조우덱에서 하수인이 나올 때까지 버리고 그 하수인을 첫 플레이어와 교전 배치 + 실험 카운터 3 제거.
      if (msDef && msDef.testPerVillainPhase){
        G.mainScheme.testCounters = (G.mainScheme.testCounters || 0) + 1;
        MC.log(G, '🧪 실험 카운터 +1 (누적 ' + G.mainScheme.testCounters + ') — 졸라의 실험이 진행된다');
        if (G.mainScheme.testCounters >= 3){
          const pl = G.players[G.firstPlayer];
          const m = MC.discardUntilMinionIntoPlay ? MC.discardUntilMinionIntoPlay(G, pl, null) : null;
          if (m){
            G.mainScheme.testCounters -= 3;
            MC.log(G, '🧪 실험 카운터 3 도달 → 하수인 소환, 실험 카운터 3 제거 (잔여 ' + G.mainScheme.testCounters + ')');
          }
        }
      }
      if (msDef && msDef.forcedThreatChoice){
        G._pendingThreatChoice = MC.playersInOrder(G).filter(p => !p.eliminated).map(p => p.uid);
        if (flushThreatChoice(G)) return;   // 첫 플레이어 선택 pending — 큐 정지
      }
      break;
    }
    case 'activations': { // 실행 시점에 라이브 조회로 확장 (교전 하수인 변동 대응)
      const pl = G.players.find(p => p.uid === step.player);
      if (!pl || pl.eliminated) break;
      const acts = [{ op:'act', enemyUid: G.villain.uid, player: pl.uid }];
      for (const m of pl.engagedMinions) acts.push({ op:'act', enemyUid: m.uid, player: pl.uid });
      G.vq.unshift(...acts);
      break;
    }
    case 'act': {
      const pl = G.players.find(p => p.uid === step.player);
      const enemy = MC.findByUid(G, step.enemyUid);
      if (!pl || pl.eliminated || !enemy || enemy.hp <= 0) break;
      enemyActivation(G, enemy, pl);
      break;
    }
    case 'dealEnc': {
      for (const pl of MC.playersInOrder(G)) dealEncounterTo(G, pl, 1);
      // 위험(Hazard): 전장의 hazard 사이드 스킴 1장당 빌런 페이즈에 조우 카드 +1 (범용).
      const order = MC.playersInOrder(G);
      let hz = 0;
      for (const s of (G.sideSchemes || [])){
        const sd = MC.cardDef(s.defCode);
        if (sd && sd.hazard){ dealEncounterTo(G, order[hz % order.length], 1); hz++; }
      }
      if (hz > 0) MC.log(G, '위험(Hazard) — 조우 카드 +' + hz);
      break;
    }
    case 'reveal':
      revealPendingEncounters(G);
      break;
    case 'resumeReveal': {
      // 인터럽트 정지점 해소 후 그 조우 카드의 처리를 재개 (interruptChecked=true라 재체크 안 함)
      const pl = G.players.find(p => p.uid === step.player);
      const inst = MC.findByUid(G, step.uid);
      if (pl && inst) resolveEncounterCard(G, pl, inst);
      break;
    }
    case 'endRound':
      G.villainStepMode = false;   // 단계별 진행 모드 종료
      MC.fireHook(G, 'endOfPhase', { phase:'villain' });
      MC.rotateFirstPlayer(G);
      MC.fireHook(G, 'endOfRound', {});
      G.round++;
      for (const pl of G.players){
        pl.usedHeroAbilityThisRound = false;
        pl.usedResourceAbilityThisRound = false;
        pl.usedIdentityActionThisRound = {};
        pl.usedIdentityActionThisPhase = {};   // 페이즈당 1회 신분 액션 (호크아이 Weapon of Choice)
        pl.usedIdentityEngageThisPhase = {};   // 페이즈당 1회 신분 교전 반응 (토르 Have at thee!)
        pl.usedLivingLegendThisRound = false;
        pl.usedThreatPreventThisRound = false;
        pl.formChangedThisRound = false;
        pl.eventsUsedThisRound = {};
        pl._missionPrepUsed = false;   // 나타샤 Mission Prep — 다음 라운드 hero 페이즈용 리셋
        // 라운드 지속 스탯 버프(사기 증진 등) — 라운드 종료 시 소멸. 히어로 + 동료 모두.
        if (pl.roundStatBonus) pl.roundStatBonus = {};
        for (const a of pl.playArea.allies) if (a.roundStatBonus) a.roundStatBonus = {};
        // 카드별 라운드당 1회 능력 리셋 (비전 등)
        for (const arr of [pl.playArea.allies, pl.playArea.supports, pl.playArea.upgrades])
          for (const c of arr) if (c.usedAbilityThisRound) c.usedAbilityThisRound = false;
        // 에디슨의 거대 로봇(05028) 무효화(nullifiedThisPhase) 리셋 — 무효화는 페이즈 한정
        for (const m of (pl.engagedMinions || [])) if (m.nullifiedThisPhase) m.nullifiedThisPhase = false;
        // ★ 준비(ready)는 여기서 하지 않는다 (공식 RRG). 준비/드로우는 플레이어 페이즈 종료(endPlayerPhase)에서만 일어난다.
        //   → 빌런 페이즈에 방어 등으로 소진한 카드는 다음 플레이어 페이즈 내내 소진 상태로 남아야 함 (방어의 대가).
      }
      G.phase = 'player';
      MC.fireHook(G, 'playerPhaseStart', {});
      break;
    default: throw new Error('[execStep] 미등록 스텝: ' + step.op);
  }
}

/* 적(하수인/빌런)의 부착물 중 공격 인터럽트(attachAttackInterrupt)를 가진 것을 발화.
   부착물이 공격을 "대체"하면 true 반환 → 호출측(enemyActivation)은 활성화를 중단한다.
   범용: webbed-up처럼 "부착된 적이 공격할 때" 발동하는 부착물에 재사용. */
function fireAttachAttackInterrupt(G, enemy, pl){
  const atts = (enemy.attachments || []).slice();
  for (const att of atts){
    const def = MC.cardDef(att.defCode);
    const hname = def && def.attachAttackInterrupt;
    if (!hname) continue;
    const fn = MC.HANDLERS[hname];
    if (!fn) throw new Error('[fireAttachAttackInterrupt] 미등록 handler: ' + hname);
    const res = fn(G, { self: att, enemy, player: pl, attachment: att });
    if (res === true) return true;   // 공격 대체됨 — 활성화 중단
  }
  return false;
}
function enemyActivation(G, enemy, pl){
  const isVillain = enemy.kind === 'villain';
  // ★ 공식 RRG 2.4.5: 알터에고 폼 상대로는 빌런·하수인 모두 암약(스킴).
  //   히어로 폼 상대로만 공격.
  if (pl.form === 'hero'){
    if (enemy.status.stunned > 0){
      enemy.status.stunned--;
      MC.log(G, MC.nameOf(enemy) + ' 기절 소모 — 공격 생략');
      return;
    }
    // 부착물 기반 공격 인터럽트 (webbed-up 등): 부착물이 공격을 대체하면 활성화 중단
    if (fireAttachAttackInterrupt(G, enemy, pl)) return;
    // ★ 노먼 오스본 attackToCounter: 공격하려 할 때 → 공격 대신 악명 카운터 +N 배치.
    //   실제 공격 미발동 → 방어 pending·부스트·공격 트리거 전부 미발생 (룰북 준수).
    if (isVillain){
      const vd = MC.cardDef(enemy.defCode);
      if (vd && vd.attackToCounter && MC.goblinAddCounter){
        const amt = vd.attackToCounter.amount || 1;
        MC.log(G, MC.nameOf(enemy) + ' — 공격 대신 악명 카운터 +' + amt);
        G.fxGoblinCounter = { targetUid: enemy.uid, op:'add', amount: amt, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        MC.goblinAddCounter(G, amt);
        return;
      }
    }
    // 울트론 II 강제 개입(01135): 공격 시 뒷면 드론 스폰 (그 후 ATK가 교전 드론 수만큼 증가).
    if (isVillain && MC.cardDef(enemy.defCode).villainAttackSpawnDrone){
      MC.log(G, MC.nameOf(enemy) + ' — 강제 개입: 공격과 함께 드론 증원');
      MC.spawnFacedownDrone(G, pl, { attack:1, scheme:1, hp:1 });
    }
    // ★ 룰북 순서: 부스트 카드는 뒷면으로 배분 — 방어 선언 후에 공개·적용
    let boostCard = null;
    let extraBoostCards = null;
    if (isVillain){
      boostCard = drawEncounterCard(G);
      // 강제 난입(공격 추가 부스트): 클로 villainAttackExtraBoost + 부착물(Hysteria grantsExtraBoost) 집계
      const vdef = MC.cardDef(enemy.defCode);
      const extra = MC.villainExtraBoost ? MC.villainExtraBoost(G, 'attack') : (vdef.villainAttackExtraBoost || 0);
      if (extra > 0){
        extraBoostCards = [];
        for (let i = 0; i < extra; i++){
          const bc = drawEncounterCard(G);
          if (bc) extraBoostCards.push(bc);
        }
        if (extraBoostCards.length)
          MC.log(G, MC.nameOf(enemy) + ' — 강제 난입: 부스트 카드 ' + extraBoostCards.length + '장 추가');
      }
    }
    // 빌런 부착물 공격 시 강제 인터럽트 (크로스본즈의 기관총: 탄약 소모 + 조우덱 부스트 피해)
    if (isVillain){
      for (const att of (enemy.attachments || [])){
        const ad = MC.cardDef(att.defCode);
        if (ad && ad.attackForcedInterrupt){
          if (ad.useCounter){ if ((att.counters || 0) < ad.useCounter) continue; att.counters -= ad.useCounter; }
          MC.runEffectList(G, ad.attackForcedInterrupt, { player: pl, self: att, card: att });
        }
      }
    }
    // 방어 선언 대기 (amount = 기본 ATK만. 부스트는 pending에 뒷면 보관)
    // 울트론 II(01135) attackBonusPerDrone: 교전 중인 Drone 수만큼 이 공격의 ATK 증가 (드론 스폰 후 계산).
    let atkAmount = MC.enemyAtk(G, enemy);
    if (isVillain && MC.cardDef(enemy.defCode).attackBonusPerDrone){
      const drones = pl.engagedMinions.filter(m => m.isDrone || (m.traits||[]).includes('drone')).length;
      if (drones > 0){
        atkAmount += drones;
        MC.log(G, MC.nameOf(enemy) + ' — 교전 드론 ' + drones + '명, 이 공격 ATK +' + drones + ' = ' + atkAmount);
      }
    }
    G.pending = {
      kind: 'defense',
      player: pl.uid,
      attackerUid: enemy.uid,
      amount: atkAmount,
      prevented: 0,
      piercing: !!enemy.piercing || (isVillain && ((MC.cardDef(enemy.defCode).piercingWhileWeapon && (enemy.attachments || []).some(a => (MC.cardDef(a.defCode).traits || []).includes('weapon'))) || (enemy.attachments || []).some(a => MC.cardDef(a.defCode).grantsPiercing))),   // 크로스본즈 Weapon 관통 / Combat Knife grantsPiercing
      boostCard: boostCard || undefined,   // 직렬화 안전 (인스턴스 = 순수 데이터)
      extraBoostCards: (extraBoostCards && extraBoostCards.length) ? extraBoostCards : undefined,
    };
    // 뮤타젠 그린 고블린 강제반응: 공격이 피해를 입히면 메인 스킴에 위협 배치 (attackThreatOnDamage)
    if (isVillain){
      const vdef2 = MC.cardDef(enemy.defCode);
      if (vdef2 && vdef2.attackThreatOnDamage) G.pending.threatOnDamage = vdef2.attackThreatOnDamage;
    }
    // 강제 난입 (회오리바람 forcedAttackEachHero): 공격이 다른 모든 히어로에게도 순차 적용.
    // pending.alsoAttack에 남은 히어로 uid들을 담아, 방어 해소 후 체인으로 다음 방어 pending 생성.
    if (!isVillain){
      const fi = MC.cardDef(enemy.defCode).forcedInterrupt;
      if (fi === 'fi_attackEachHero'){
        const others = MC.playersInOrder(G).filter(p => p.uid !== pl.uid && !p.eliminated && p.form === 'hero');
        if (others.length) G.pending.alsoAttack = others.map(p => p.uid);
      }
      // 데이터 방식 forcedInterrupt({effect}) — 바론 모르도: 공격 시 대상 덱 버림 → 자원별 효과.
      else if (fi && fi.effect){
        MC.log(G, MC.nameOf(enemy) + ' — 강제 인터럽트 발동');
        MC.runEffectList(G, fi.effect, { player: pl, self: enemy, card: enemy });
      }
      // 멜터 지속 효과: 교전 영웅은 가능하면 동료로 반드시 방어 (forceAllyDefend).
      // 준비된 동료가 있으면 pending에 mustDefendWithAlly 마커 → UI가 신분/무방어 옵션 차단.
      if (MC.cardDef(enemy.defCode).forceAllyDefend){
        const hasReadyAlly = pl.playArea.allies.some(a => !a.exhausted);
        if (hasReadyAlly) G.pending.mustDefendWithAlly = true;
      }
    }
    // 하수인 공격 연출·대사 힌트 (UI가 vfx.attack + attack 대사 재생). 빌런은 별도 처리.
    if (!isVillain){
      G.fxMinionAttack = { defCode: enemy.defCode, attackerUid: enemy.uid,
                           targetUid: pl.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
    MC.log(G, MC.nameOf(enemy) + ' → ' + pl.uid + ' 공격 (피해 ' + G.pending.amount +
      (boostCard ? ' + 부스트 ?' : '') + ') — 방어 선언 대기');
    // 부착물 공격 보정 (돌진 등): 과잉살상 부여 + 공격 종료 후 버림 예약 (강제 개입)
    for (const att of (enemy.attachments || [])){
      const adef = MC.cardDef(att.defCode);
      if (!adef) continue;
      if (adef.grantOverkillOnAttack){
        G.pending.overkill = true;
        MC.log(G, MC.nameOf(att) + ' — 이 공격은 과잉살상을 얻습니다');
      }
      if (adef.discardAfterAttack)
        (G.pending.discardAfterAttack = G.pending.discardAfterAttack || []).push(att.uid);
    }
    // 공격 개시 인터럽트 (Spider-Sense 등): 대상 플레이어의 신분 카드 훅 발화
    MC.fireAttackInterrupt(G, pl, enemy);
  } else {
    if (enemy.status.confused > 0){
      enemy.status.confused--;
      MC.log(G, MC.nameOf(enemy) + ' 혼란 소모 — 스킴 생략');
      return;
    }
    // ★ 그린 고블린 schemeToCounter: 스킴하려 할 때 → 스킴 대신 광기 카운터 -N 제거.
    //   실제 스킴 미발동 → 위협·부스트·스킴 트리거 전부 미발생 (룰북 준수).
    if (isVillain){
      const vd = MC.cardDef(enemy.defCode);
      if (vd && vd.schemeToCounter && MC.goblinRemoveCounter){
        const amt = vd.schemeToCounter.amount || 1;
        MC.log(G, MC.nameOf(enemy) + ' — 스킴 대신 광기 카운터 -' + amt);
        G.fxGoblinCounter = { targetUid: enemy.uid, op:'remove', amount: amt, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        MC.goblinRemoveCounter(G, amt);
        return;
      }
    }
    let boost = 0, boostCard = null;
    const extraSchemeBoosts = [];
    if (isVillain){
      boostCard = drawEncounterCard(G);
      boost = boostCard ? MC.boostOf(G, boostCard, pl) : 0;
      if (boostCard){
        (G.revealLog = G.revealLog || []).push({ defCode: boostCard.defCode, name: boostCard.name, type: 'boost', boost, player: pl.uid });
        MC.log(G, '부스트 카드: ' + MC.nameOf(boostCard) + ' (부스트 +' + boost + ')');
      }
      // 추가 부스트(스킴): 부착물 Hysteria(grantsExtraBoost) — 공개·아이콘 합산
      const extraS = MC.villainExtraBoost ? MC.villainExtraBoost(G, 'scheme') : 0;
      for (let i = 0; i < extraS; i++){
        const bc = drawEncounterCard(G);
        if (!bc) break;
        const b2 = MC.boostOf(G, bc, pl);
        boost += b2;
        extraSchemeBoosts.push(bc);
        (G.revealLog = G.revealLog || []).push({ defCode: bc.defCode, name: bc.name, type: 'boost', boost: b2, player: pl.uid, extra: true });
        MC.log(G, '추가 부스트 카드(스킴): ' + MC.nameOf(bc) + ' (+' + b2 + ')');
      }
    }
    placeThreat(G, 'main', (enemy.scheme || 0) + (MC.enemySchemePassive ? MC.enemySchemePassive(G, enemy) : 0) + boost);
    // 저지됐다!(foiled)용: 이번 음모의 부스트 아이콘 위협분 추적 → 손패 인터럽트로 소급 취소 가능.
    if (boost > 0) G._lastSchemeBoost = { schemeRef: 'main', boost: boost };
    // 추가 부스트 카드들 부스트★ 처리 + 버림
    for (const bc of extraSchemeBoosts){
      const placedE = MC.resolveBoostStar(G, pl, bc, 'scheme');
      if (!placedE) G.encounterDiscard.push(bc);
    }
    if (boostCard){
      const placed = MC.resolveBoostStar(G, pl, boostCard, 'scheme');
      if (!placed) G.encounterDiscard.push(boostCard);
      // UI 힌트: 스킴 부스트 공개 시퀀스 (무엇을 뽑았고 무슨 옵션이 발동했는지)
      G.fxBoostReveal = { kind: 'scheme', attackerName: MC.nameOf(enemy),
        base: enemy.scheme || 0, boostTotal: boost,
        events: [{ defCode: boostCard.defCode, name: boostCard.name,
          boost, extra: false, star: G._lastBoostStar || undefined }],
        seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
    // ★ 빌런 활성화 후 특성 분기 (04078 어보밍맨 III): 스킴 활성화 완료 후 발동.
    if (isVillain && MC.villainActivateResponse) MC.villainActivateResponse(G, pl);
    // 지연된 부스트★ 선택(안드로이드 효율 등): 암약 처리 종료 후 여기서 pending을 세운다.
    // (pending이 서면 enemyActivation 반환 → processVillainQueue가 큐를 멈춘다.)
    flushDeferredBoostChoice(G);
  }
}

/* 무피해 방어 후 반응 중앙 스캔 — 히어로 방어로 피해 0일 때 발동.
   업그레이드의 afterDefendNoDamage 필드({exhaustSelf?, discardSelf?, effect}) 스캔.
   침착함(unflappable: 드로우+버림) / 무시 못할 존재(hard-to-ignore: 위협 제거+소진) 등 재사용. */
MC.scanAfterDefendNoDamage = function(G, pl){
  const ups = (pl.playArea.upgrades || []).slice();
  for (const u of ups){
    const d = MC.cardDef(u.defCode);
    const h = d && d.afterDefendNoDamage;
    if (!h) continue;
    if (h.exhaustSelf){ if (u.exhausted) continue; u.exhausted = true; }
    MC.log(G, MC.nameOf(u) + ' — 무피해 방어 반응 발동');
    MC.runEffectList(G, h.effect || [], { player: pl, self: u, card: u });
    if (h.discardSelf){
      const i = pl.playArea.upgrades.indexOf(u);
      if (i >= 0) pl.playArea.upgrades.splice(i, 1);
      MC.moveToDiscard(G, pl, u, {});
    }
  }
};

/* 방어 선언 해소 — 액션 resolveDefense에서 호출.
   defender: 'none' | 'identity' | 동료 uid */
function resolveDefensePending(G, playerUid, defender){
  const p = G.pending;
  if (!p || p.kind !== 'defense') throw new Error('[resolveDefense] 대기 중인 방어 없음');
  if (p.player !== playerUid) throw new Error('[resolveDefense] 방어 주체 불일치: ' + playerUid);
  const pl = G.players.find(x => x.uid === playerUid);
  const attacker = MC.findByUid(G, p.attackerUid);
  // 멜터 지속 효과: mustDefendWithAlly면 준비된 동료가 있는 한 신분/무방어 선택 불가 (동료로 방어 강제)
  if (p.mustDefendWithAlly && (defender === 'identity' || defender === 'none')){
    const hasReadyAlly = pl.playArea.allies.some(a => !a.exhausted);
    if (hasReadyAlly) throw new Error('[resolveDefense] 멜터 — 가능하면 동료로 방어해야 함');
  }
  // ★ 룰북 순서: 방어 선언이 확정된 "후" 부스트 카드 공개 + 아이콘 적용
  //   (검증 실패 시 throw로 공개 전에 중단되도록, 검증 먼저)
  if (defender === 'identity'){
    if (pl.form !== 'hero') throw new Error('[resolveDefense] 알터에고는 신분 방어 불가');
    if (pl.exhausted) throw new Error('[resolveDefense] 소진 상태로 방어 불가');
  } else if (defender !== 'none'){
    const ally0 = pl.playArea.allies.find(a => a.uid === defender);
    if (!ally0) throw new Error('[resolveDefense] 동료 없음: ' + defender);
    if (ally0.exhausted) throw new Error('[resolveDefense] 소진된 동료로 방어 불가');
  }
  let boost = 0;
  const boostEvents = [];   // UI 부스트 공개 시퀀스용 (무엇을 뽑았고 무슨 옵션이 발동했는지)
  if (p.boostCard){
    boost = MC.boostOf(G, p.boostCard, pl);
    (G.revealLog = G.revealLog || []).push({ defCode: p.boostCard.defCode, name: p.boostCard.name, type: 'boost', boost, player: playerUid });
    MC.log(G, '부스트 카드 공개: ' + MC.nameOf(p.boostCard) + ' (+' + boost + ')');
    // 부스트★ 효과 (무기 밀매상 전장 배치 등): 배치되면 버리지 않음
    const placed = MC.resolveBoostStar(G, pl, p.boostCard, 'attack');
    if (!placed) G.encounterDiscard.push(p.boostCard);
    boostEvents.push({ defCode: p.boostCard.defCode, name: p.boostCard.name,
      boost: MC.boostOf(G, p.boostCard, pl), extra: false, star: G._lastBoostStar || undefined });
  }
  // 클로 강제 난입 추가 부스트 카드(들): 각각 공개·아이콘 합산·부스트★·버림
  if (p.extraBoostCards){
    for (const bc of p.extraBoostCards){
      const b2 = MC.boostOf(G, bc, pl);
      boost += b2;
      (G.revealLog = G.revealLog || []).push({ defCode: bc.defCode, name: bc.name, type: 'boost', boost: b2, player: playerUid, extra: true });
      MC.log(G, '추가 부스트 카드 공개: ' + MC.nameOf(bc) + ' (+' + b2 + ')');
      const placed2 = MC.resolveBoostStar(G, pl, bc, 'attack');
      if (!placed2) G.encounterDiscard.push(bc);
      boostEvents.push({ defCode: bc.defCode, name: bc.name,
        boost: b2, extra: true, star: G._lastBoostStar || undefined });
    }
  }
  // UI 힌트: 부스트 공개 시퀀스 오버레이 (플립 애니메이션 + 발동 옵션 표시)
  if (boostEvents.length){
    G.fxBoostReveal = { kind: 'attack', attackerName: attacker ? MC.nameOf(attacker) : '적',
      base: p.amount || 0, boostTotal: boost, events: boostEvents,
      seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  }
  const total = Math.max(0, (p.amount || 0) + boost - (p.prevented || 0));
  const pierce = !!p.piercing;
  if (p.prevented) MC.log(G, '피해 방지 적용: -' + p.prevented);
  // 실제로 피해를 입은 대상·피해량 추적 (빌런 부착물 "공격 후" 강제반응용 — 소닉 컨버터 등)
  let dmgTarget = null, dmgDone = 0;
  let defenderChar = null;   // 이 공격에서 "공격받은" 캐릭터 (보복 주체) — 방어자 기준
  if (defender === 'none'){
    defenderChar = pl;
    if (total > 0){ MC.applyDamage(G, pl, total, { source: attacker, isAttack: true, piercing: pierce, noRetaliate: true }); dmgTarget = pl; dmgDone = total; }
    else MC.log(G, '피해 전량 방지 — 무피해');
  } else if (defender === 'identity'){
    pl.exhausted = true;
    const def = MC.statOf(G, pl, 'defense') || 0;
    const dmg = Math.max(0, total - def);
    defenderChar = pl;
    MC.log(G, pl.uid + ' 방어 선언 (DEF ' + def + ')');
    if (dmg > 0){ MC.applyDamage(G, pl, dmg, { source: attacker, isAttack: true, defended: true, piercing: pierce, noRetaliate: true }); dmgTarget = pl; dmgDone = dmg; }
    else {
      if (p.readyIfNoDamage){ pl.exhausted = false; MC.log(G, '필사의 방어 — 무피해, 히어로 재준비'); }
      MC.scanAfterDefendNoDamage(G, pl);
    }
  } else {
    const ally = pl.playArea.allies.find(a => a.uid === defender);
    ally.exhausted = true;
    defenderChar = ally;
    MC.log(G, MC.nameOf(ally) + ' 동료 방어');
    const allyHpBefore = ally.hp;
    const allyHadTough = !!(ally.status && ally.status.tough > 0);
    if (total > 0){ MC.applyDamage(G, ally, total, { source: attacker, isAttack: true, defended: true, piercing: pierce, noRetaliate: true }); dmgTarget = ally; dmgDone = allyHadTough ? 0 : total; }
    // 과잉살상(빌런 공격 — 돌진 등): 동료 초과 피해를 그 동료의 컨트롤러에게.
    // 강인으로 전량 무효된 경우 초과 없음 (단 관통 시엔 강인 무시라 초과 발생)
    if (p.overkill && (pierce || !allyHadTough) && total > allyHpBefore){
      const excess = total - allyHpBefore;
      MC.log(G, '과잉살상 — 동료 초과 피해 ' + excess + ' → ' + pl.uid);
      MC.applyDamage(G, pl, excess, { source: attacker, isAttack: true, piercing: pierce });
    }
  }
  // ★ 보복(Retaliate): 공격받은 캐릭터가 살아남았으면 피해량과 무관하게 공격자에게 발동
  //   (공식 룰: 트리거는 "공격받음" — 방어로 0피해·강인 흡수여도 발동). applyDamage엔 noRetaliate로
  //   위임을 막고 여기서 일괄 처리 → 중복 발동 없음. (BP 신분 방어 시 역습 미발동 버그 수정)
  if (defenderChar && attacker) MC.triggerRetaliate(G, defenderChar, attacker);
  // 카운터 펀치 등 "방어 후 반응"을 위한 힌트: 히어로가 방어한 경우(identity) 그 공격자 기록.
  // (동료 방어는 "your hero defends"가 아니므로 제외)
  if (defender === 'identity' && attacker){
    pl.justDefendedAgainst = attacker.uid;
  } else {
    delete pl.justDefendedAgainst;
  }
  // "공격 종료 후 이 카드를 버립니다" (discardAfterAttack — 돌진): 스탯 원복 후 조우 버림
  if (p.discardAfterAttack && attacker){
    for (const auid of p.discardAfterAttack){
      const att = (attacker.attachments || []).find(a => a.uid === auid);
      if (!att) continue;
      MC.detachFrom(G, att);
      G.encounterDiscard.push(att);
      MC.log(G, MC.nameOf(att) + ' — 공격 종료, 버림');
      G.fxAttachSpent = { defCode: att.defCode, targetUid: attacker.uid,
                          seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
  }
  // 히어로가 이 공격으로 받은 피해 기록 (You'll Pay for That!: 받은 피해당 위협 제거)
  if (dmgTarget === pl) pl.lastDamageTaken = dmgDone;
  // 공격이 피해를 입혔을 때 메인 스킴 위협 배치 (클로의 복수 히어로 분기 등, threatOnDamage)
  if (p.threatOnDamage && dmgDone > 0){
    MC.placeThreat(G, 'main', p.threatOnDamage);
    MC.log(G, '피해 발생 — 메인 스킴 위협 +' + p.threatOnDamage);
  }
  // 이 공격이 임계 이상 피해를 입히면 조우 카드 1장 추가 공개(surge) — Overconfidence 히어로 분기.
  if (p.surgeIfDamageGTE && dmgDone >= p.surgeIfDamageGTE){
    MC.log(G, '공격 피해 ' + dmgDone + ' ≥ ' + p.surgeIfDamageGTE + ' — 급증(surge): 조우 카드 1장 추가');
    dealEncounterTo(G, pl, 1);
  }
  // 공격이 준 피해 1당 활성 플레이어 덱 맨 위 카드 1장 버림 (울트론의 분노 히어로 분기, discardDeckPerDamage)
  if (p.discardDeckPerDamage && dmgDone > 0){
    G._lastDamageDealt = dmgDone;
    MC.discardTopOfDeck(G, pl, dmgDone);
  }
  // 공격이 피해를 입혔을 때 그 대상 기절 (쇄도 등 stunOnHit 배신/공격 · 또는 공격자 def의 stunOnDamage=Scorpion). 범용.
  const attackerStunsOnDamage = attacker && (MC.cardDef(attacker.defCode) || {}).stunOnDamage;
  if ((p.stunOnHit || attackerStunsOnDamage) && dmgTarget && dmgDone > 0){
    MC.setStatus(G, dmgTarget, 'stunned', true);
    MC.log(G, MC.nameOf(dmgTarget) + ' — 공격 피해로 기절');
  }
  // 부스트 카드의 "피해 시" 부스트★ 효과 (소닉 붐: 이 활성화가 피해를 주면 히어로 소진).
  // 즉시 실행되는 boostStarEffect와 달리, 공격이 실제 피해를 준 후에만 발동 (범용, 데이터 effects).
  if (dmgDone > 0){
    for (const ev of boostEvents){
      const bdef = MC.cardDef(ev.defCode);
      if (bdef && bdef.boostStarOnDamage){
        MC.runEffectList(G, bdef.boostStarOnDamage, { player: pl, self: dmgTarget, card: bdef });
        MC.log(G, MC.nameOf(bdef) + ' 부스트★ — 피해 발생으로 효과 발동');
      }
    }
  }
  // 공격자(빌런/하수인) 부착물의 "공격+피해 후" 강제반응 (attackDamagedResponse).
  // 공식 "After [attacker] attacks and damages a character" — 실제 피해가 든 경우만.
  // 소닉 컨버터(01118): 데미지 입힌 캐릭터를 기절. 대상은 dmgTarget(히어로 또는 방어 동료).
  if (attacker && dmgTarget && dmgDone > 0){
    for (const att of (attacker.attachments || [])){
      const adef = MC.cardDef(att.defCode);
      const h = adef && adef.attackDamagedResponse;
      if (h && MC.HANDLERS[h]) MC.HANDLERS[h](G, { player: pl, target: dmgTarget, attacker, self: att });
    }
    // 공격자 자신의 "공격+피해 후" 효과 (attackDamagedEffects) — Tombstone: 자원 버림.
    const selfDef = MC.cardDef(attacker.defCode);
    if (selfDef && selfDef.attackDamagedEffects){
      MC.runEffectList(G, selfDef.attackDamagedEffects, { player: pl, self: attacker, card: attacker, target: dmgTarget, attacker });
    }
  }
  // 빌런 부착물의 "공격 후" 강제반응 (attackResponseEffects) — 피해 여부 무관 (Pumpkin Bombs).
  //   공식 "After the villain attacks you" — 방어 대상 플레이어(pl)에게 발화. 부착물 버림 등으로
  //   attachments가 변하므로 복사본을 순회한다.
  if (attacker && attacker.kind === 'villain'){
    for (const att of [...(attacker.attachments || [])]){
      const adef = MC.cardDef(att.defCode);
      if (adef && adef.attackResponseEffects){
        MC.runEffectList(G, adef.attackResponseEffects, { player: pl, self: att, card: att, target: pl });
      }
    }
  }
  // 하수인 공격 후 강제 반응 (forcedResponse): 라디오액티브 맨 = 공격 후 손패 무작위 1장 버림.
  // 공식 "After ... attacks you" — 피해 여부 무관, 방어 대상 플레이어에게 발화. (빌런은 제외)
  if (attacker && attacker.kind !== 'villain' && attacker.type === 'minion'){
    const adef = MC.cardDef(attacker.defCode);
    const fr = adef && adef.forcedResponse;
    if (fr && MC.HANDLERS[fr]){
      MC.HANDLERS[fr](G, { player: pl, self: attacker, card: attacker, attacker });
    }
    // 데이터 기반 강제 반응: def.forcedResponseEffects 배열을 runEffectList로 실행 (욘-로그 01177 등).
    if (adef && adef.forcedResponseEffects){
      MC.runEffectList(G, adef.forcedResponseEffects, { player: pl, self: attacker, card: attacker, attacker });
    }
  }
  // 하수인 무방어 공격 후 강제 반응 (하이드라 화염병: 통제 서포트 버림). afterUndefendedAttack.
  if (defender === 'none' && attacker){
    const aud = MC.cardDef(attacker.defCode);
    if (aud && aud.afterUndefendedAttack){
      MC.runEffectList(G, aud.afterUndefendedAttack, { player: pl, self: attacker, card: attacker });
    }
  }
  // ★ 어보밍맨 환경 미방어 반응 (범용 인덱스): 빌런이 미방어 공격한 후 전장 환경 카드들의
  //   envUndefendedResponse를 발동. 메인 스킴 지연(delay) 카운터 5+면 값 2배(delayScale).
  //   환경 4종(숲=간접피해/언덕=위협/바위=빌런회복/시설=자원버림)이 값·타입만 다른 변형이므로 데이터로 표현.
  if (defender === 'none' && attacker && attacker.kind === 'villain'){
    const delay = (G.mainScheme && G.mainScheme.delayCounters) || 0;
    for (const env of (G.environments || [])){
      const r = MC.cardDef(env.defCode).envUndefendedResponse;
      if (!r) continue;
      const amt = (r.delayScale && delay >= 5) ? r.delayScale : (r.amount || 1);
      const en = MC.nameOf(env);
      if (r.type === 'damage'){
        MC.applyDamage(G, pl, amt, { source: attacker, indirect: true });
        MC.log(G, en + ' — 미방어 반응: ' + pl.uid + ' 간접 피해 ' + amt);
      } else if (r.type === 'threat'){
        MC.placeThreat(G, 'main', amt);
        MC.log(G, en + ' — 미방어 반응: 메인 스킴 위협 +' + amt);
      } else if (r.type === 'healVillain'){
        MC.runEffectList(G, [{ fx: 'healVillain', amount: amt }], { player: pl, self: attacker, card: attacker });
        MC.log(G, en + ' — 미방어 반응: 어보밍맨 회복 ' + amt);
      } else if (r.type === 'discardResource'){
        MC.runEffectList(G, [{ fx: 'discardFromHand', count: amt, random: true }], { player: pl });
        MC.log(G, en + ' — 미방어 반응: ' + pl.uid + ' 손에서 자원 ' + amt + ' 버림');
      }
      G._environmentReaction = { defCode: env.defCode, type: r.type, amount: amt, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    }
  }
  // ★ 빌런 활성화 후 특성 분기 (04078 어보밍맨 III): 공격 활성화 완료 후 발동 (방어 여부 무관).
  if (attacker && attacker.kind === 'villain' && MC.villainActivateResponse){
    MC.villainActivateResponse(G, pl);
  }
  // Toe to Toe 등: 방어 해소 후 예약 효과 (공격자 대상 5피해). pending.afterEffects.
  if (p.afterEffects && attacker){
    MC.runEffectList(G, p.afterEffects, { player: pl, targets: [attacker], self: attacker, card: attacker });
  }
  // 강제 난입 체인 (회오리바람): alsoAttack에 남은 히어로가 있으면 그 다음 히어로에 대한
  // 새 방어 pending을 세운다 (동일 공격 순차 적용). 남은 대상 없으면 정상 종료.
  const chain = p.alsoAttack;
  if (chain && chain.length && attacker && attacker.hp > 0){
    const nextUid = chain[0];
    const nextPl = G.players.find(x => x.uid === nextUid);
    if (nextPl && !nextPl.eliminated && nextPl.form === 'hero'){
      G.pending = {
        kind: 'defense',
        player: nextUid,
        attackerUid: attacker.uid,
        amount: MC.enemyAtk(G, attacker),
        prevented: 0,
        piercing: !!attacker.piercing,
        alsoAttack: chain.slice(1),
      };
      MC.log(G, MC.nameOf(attacker) + ' 강제 난입 — ' + nextUid + '에게도 공격');
      return;   // 큐 재개 없이 다음 방어 대기
    }
  }
  // 하수인 연쇄 공격 체인 (혼돈의 지배 등): attackChain에 남은 (공격자,대상) 쌍이 있으면
  // 다음 하수인의 방어 pending을 세운다 (startMinionAttackChain이 기절/사망 스킵 포함 처리).
  if (p.attackChain && p.attackChain.length){
    if (startMinionAttackChain(G, p.attackChain)) return;   // 다음 공격 대기 (큐 재개 없이)
  }
  // 공격+피해 후 효과(attackDamagedEffects 등)가 선택 pending을 세웠으면 유지 + 큐 재개 보류.
  //   (Tombstone 자원 버림 선택 등 — 플레이어 해소 후 UI가 큐를 재개한다.)
  if (G.pending && G.pending !== p) return;
  G.pending = null;
  // 빌런 공격 후 강제 반응 선택 (울트론 I 01134: 메인 위협1 or 드론). 방어·피해 종료 후 선택 pending.
  if (attacker && attacker.kind === 'villain'){
    const vdef = MC.cardDef(attacker.defCode);
    if (vdef && vdef.forcedAttackChoice){
      G.pending = { kind:'revealChoice', player: pl.uid, selfUid: attacker.uid,
        prompt: vdef.forcedAttackChoice.prompt || '선택하세요',
        options: vdef.forcedAttackChoice.options || [] };
      MC.log(G, MC.nameOf(attacker) + ' — 공격 후 강제 반응: 선택 대기');
      return;   // 선택 해소까지 큐 재개 보류
    }
  }
  // 지연된 부스트★ 선택(안드로이드 효율 등): 이 공격의 부스트로 뒤집혔다면 여기서 pending을 세운다.
  // (방어·체인·피해가 모두 끝난 뒤라 흐름을 깨지 않는다. pending이 서면 큐 재개를 건너뛴다.)
  if (flushDeferredBoostChoice(G)) return;
  processVillainQueue(G); // 큐 재개
}

/* ── 인카운터 공개 ── */
function revealPendingEncounters(G){
  while (G.pendingEncounters.length){
    const { player, inst } = G.pendingEncounters.shift();
    const pl = G.players.find(p => p.uid === player);
    MC.log(G, pl.uid + ' 인카운터 공개: ' + MC.nameOf(inst));
    resolveEncounterCard(G, pl, inst);
    if (G.over) return;
    if (inst.surge) dealEncounterTo(G, pl, 1);
    // 공개 처리 중 결정 대기(방어/선택 등)가 서면 남은 공개를 중단하고 해소 후 재개.
    // (배신의 villainAttacks/minionsAttack 등이 세운 pending을 다음 공개가 덮어쓰는 것 방지)
    if (G.pending){
      if (!G.vq.length || G.vq[0].op !== 'reveal') G.vq.unshift({ op:'reveal' });
      return;
    }
  }
}
function resolveEncounterCard(G, pl, inst){
  // 인터럽트 정지점: 이 카드 공개에 대응할 인터럽트 카드가 있으면 멈춘다.
  // (아직 인터럽트를 검토하지 않은 경우에만 — 재진입 시 inst.interruptChecked로 스킵)
  if (!inst.interruptChecked){
    inst.interruptChecked = true;
    if (checkRevealInterrupt(G, pl, inst)){
      G.revealing = inst;   // 공개 진행 중 카드 (uid로 findByUid가 찾도록 — 아래 참조)
      return;
    }
  }
  // 공개 기록 (UI 확인용 — 중복 방지)
  if (!inst._logged){
    inst._logged = true;
    (G.revealLog = G.revealLog || []).push({ defCode: inst.defCode, name: inst.name, type: inst.type, player: pl.uid });
  }
  switch (inst.type){
    case 'minion':
      inst.engagedWith = pl.uid; pl.engagedMinions.push(inst);
      // 하수인 등장 반응 (호크아이 화살 등): 중앙 헬퍼가 힌트 기록 + 등장 반응 발동.
      MC.minionEnteredPlay(G, inst, pl);
      fireRevealWithInterrupt(G, pl, inst);
      // whenRevealed가 플레이어 선택 대기(revealChoice)를 세웠으면 공개 루프 정지 → 선택 후 재개
      if (G.pending && G.pending.kind === 'revealChoice'){
        G.vq.unshift({ op:'reveal' });
        return;
      }
      const idef = MC.cardDef(inst.defCode);
      if ((inst.quickstrike || (idef && idef.quickstrike)) && pl.form === 'hero'){
        // 속공: 즉시 공격 → 방어 대기 (공개 루프는 pending 해소 후 재개 필요)
        G.pending = { kind:'defense', player: pl.uid, attackerUid: inst.uid,
                      amount: MC.enemyAtk(G, inst) };
        G.vq.unshift({ op:'reveal' }); // 남은 공개를 큐로 되돌림
        return;
      }
      break;
    case 'treachery':
      fireRevealWithInterrupt(G, pl, inst);
      G.encounterDiscard.push(inst);
      break;
    case 'side_scheme': {
      const def = MC.cardDef(inst.defCode);
      inst.threat = (def.baseThreatPerPlayer||0) * G.players.length + (def.baseThreat||0);
      inst.peakThreat = inst.threat;   // 위협바 분모 (남은 저지량 표시)
      inst.isMain = false;
      G.sideSchemes.push(inst);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    }
    case 'attachment': {
      // 부착 대상 라우팅: attachTarget이 환경 슬러그면 그 환경에 부착 (업그레이드 드론 01142 등).
      // 대상 환경이 전장에 없으면 부착 불발 → 버림. 기본은 빌런.
      const adef = MC.cardDef(inst.defCode);
      const at = adef && adef.attachTarget;
      let host = G.villain;
      if (at === 'identity'){
        // 신분 부착 (All Tied Up / Media Coverage): 공개한 플레이어의 신분 카드에 부착.
        (pl.identityAttachments = pl.identityAttachments || []).push(inst);
        inst.attachedToPlayer = pl.uid;
        MC.log(G, MC.nameOf(inst) + ' — ' + MC.nameOf(pl) + '의 신분에 부착');
        fireRevealWithInterrupt(G, pl, inst);
        break;
      }
      if (at === 'minionMostHp'){
        // 졸라 부착(04117-119): 동일 부착물이 없는, 남은 HP가 가장 많은 하수인. 없으면 surge 후 버림.
        const minions = [];
        for (const pl2 of G.players) for (const m of (pl2.engagedMinions || [])) if (m.hp > 0) minions.push(m);
        const cands = minions.filter(m => !((m.attachments || []).some(x => x.defCode === inst.defCode)));
        let best = null;
        for (const m of cands){ if (!best || (m.hp || 0) > (best.hp || 0)) best = m; }
        if (!best){
          inst.surge = true;
          MC.log(G, MC.nameOf(inst) + ' — 부착 대상 하수인 없음 · surge');
          G.encounterDiscard.push(inst);
          break;
        }
        host = best;
        if (adef.grantsMinionGuard){ host.grantedGuard = true; host.guard = true; }
        MC.log(G, MC.nameOf(inst) + ' — 최다 잔여 HP 하수인 ' + MC.nameOf(host) + '에 부착' + (adef.grantsMinionGuard ? ' (호위 부여)' : ''));
        MC.attachTo(G, inst, host);
        fireRevealWithInterrupt(G, pl, inst);
        break;
      }
      if (at === 'highestHpEnemy'){
        // 최고 인쇄 HP 적(빌런+하수인) 중 동일 부착물이 없는 대상. 없으면 surge 후 버림.
        const enemies = [G.villain];
        for (const pl2 of G.players) for (const m of (pl2.engagedMinions || [])) enemies.push(m);
        const cands = enemies.filter(e => e && !((e.attachments || []).some(x => x.defCode === inst.defCode)));
        let best = null;
        for (const e of cands){ if (!best || (e.maxHp || 0) > (best.maxHp || 0)) best = e; }
        if (!best){
          inst.surge = true;
          MC.log(G, MC.nameOf(inst) + ' — 부착 대상 없음 · surge');
          G.encounterDiscard.push(inst);
          break;
        }
        host = best;
        MC.log(G, MC.nameOf(inst) + ' — 최고 HP 적 ' + MC.nameOf(host) + '에 부착');
      } else if (at && at !== 'villain'){
        host = (G.environments || []).find(e => e.defCode === at) || null;
        if (!host){
          MC.log(G, MC.nameOf(inst) + ' — 부착 대상(' + at + ') 없음 · 버림');
          G.encounterDiscard.push(inst);
          break;
        }
      }
      MC.attachTo(G, inst, host);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    }
    case 'environment':
      // 환경 카드: 전장에 유지 (버리지 않음). 드론 스탯 정의(droneStats) 등 지속 효과의 호스트.
      G.environments = G.environments || [];
      // 어보밍맨 None Shall Pass: 환경 1개만 유지 — 새 환경 등장 시 기존 환경 버림 (지형이 계속 바뀌는 추격전).
      { const _msD = MC.cardDef(G.mainScheme.defCode);
        if (_msD && _msD.singleEnvironment && G.environments.length){
          for (const old of G.environments){ MC.log(G, MC.nameOf(old) + ' — 지형이 바뀌며 사라짐'); G.encounterDiscard.push(old); }
          G.environments = [];
          G._environmentChanged = true;   // UI 전환 애니메이션 힌트
        } }
      G.environments.push(inst);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    case 'obligation':
      // 의무: 조우 버린더미에 먼저 놓아 findByUid가 공개 중 카드를 찾게 한 뒤 whenRevealed 발동.
      // whenRevealed(offerChoice→택1)의 resolveObligation이 최종 처리:
      //   mode:'game' → 버린더미에서 splice + 게임 제거 / mode:'discard' → 그대로 유지.
      if (!G.encounterDiscard.includes(inst)) G.encounterDiscard.push(inst);
      fireRevealWithInterrupt(G, pl, inst);
      break;
    default:
      fireRevealWithInterrupt(G, pl, inst);
      G.encounterDiscard.push(inst);
  }
}

/* whenRevealed 발화 — 단, 대응 가능한 인터럽트 카드가 있으면 정지점(pending)을 띄운다.
   inst.revealCancelled가 서 있으면(인터럽트로 취소됨) whenRevealed를 발화하지 않는다.
   범용: 각 인터럽트 카드는 cardDef.interruptOn = { encounterType:'treachery'|... } 로 선언. */
function fireRevealWithInterrupt(G, pl, inst){
  if (inst.revealCancelled) {              // 이미 인터럽트로 취소됨
    MC.log(G, MC.nameOf(inst) + ' — "공개 시" 효과 취소됨');
    return;
  }
  MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
  // Media Coverage(신분 부착): 이 플레이어가 공개한 카드의 "공개 시"를 1회 추가 발동.
  //   첫 발동이 pending(선택/방어)을 세우지 않은 경우에만 재발동 (pending 클로버·재귀 방지).
  if (!inst._wrDoubled && MC.identityAttachHas && MC.identityAttachHas(G, pl, 'wrDoubling')){
    const d = MC.cardDef(inst.defCode);
    if (d && d.whenRevealed && !G.pending && !G.over){
      inst._wrDoubled = true;
      MC.log(G, MC.nameOf(inst) + ' — Media Coverage: "공개 시" 1회 추가 발동');
      MC.fireCardHook(G, inst, 'whenRevealed', { player: pl });
    }
  }
}

/* 조우 카드에 대응할 수 있는 인터럽트 카드를 가진 플레이어가 있는지 검사.
   있으면 pending:{kind:'revealInterrupt'}를 띄우고 true 반환(호출측은 멈춤). */
function checkRevealInterrupt(G, pl, inst){
  const opts = collectRevealInterrupts(G, inst);
  if (!opts.length) return false;
  G.pending = { kind:'revealInterrupt', player: pl.uid, targetUid: inst.uid,
                encounterType: inst.type };
  MC.log(G, MC.nameOf(inst) + ' 공개 — 인터럽트 대응 가능');
  return true;
}

/* 인터럽트 해소: 카드를 사용하거나(취소) 패스한다. 그 후 공개 재개.
   use=false면 패스(원래 whenRevealed 발화). */
function resolveRevealInterrupt(G, playerUid, cardUid, payment){
  const p = G.pending;
  if (!p || p.kind !== 'revealInterrupt') throw new Error('[interrupt] 대기 중인 인터럽트 없음');
  const inst = G.revealing;
  const owner = G.players.find(x => x.uid === p.player); // 조우 카드를 공개한 플레이어
  G.pending = null;

  if (cardUid){
    // 손패 인터럽트 이벤트 vs 플레이 영역 동료/서포트 인터럽트 구분
    const handUser = G.players.find(x => x.hand.some(c => c.uid === cardUid));
    if (handUser){
      // ── 손패 인터럽트 이벤트 (Backflip류 아님, Enhanced Spider-Sense류) ──
      const card = handUser.hand.find(c => c.uid === cardUid);
      const def = MC.cardDef(card.defCode);
      const els = payment || [];
      MC.validatePayment(G, handUser, els, card.cost||0, card);
      handUser.hand.splice(handUser.hand.indexOf(card), 1);
      MC.executePayment(G, handUser, els);
      MC.log(G, handUser.uid + ' 인터럽트: ' + MC.nameOf(card));
      const eff = def.interruptEffect || 'cancelReveal';
      if (eff === 'cancelReveal'){
        inst.revealCancelled = true;
      } else if (MC.HANDLERS[eff]){
        // 커스텀 인터럽트 핸들러 (get-behind-me 등): 취소 여부·추가 효과를 핸들러가 결정.
        // 기본적으로 취소 플래그를 세우고, 핸들러가 추가 효과(빌런 공격 등)를 처리.
        inst.revealCancelled = true;
        MC.HANDLERS[eff](G, { player: handUser, card, targetInst: inst, self: card });
      } else {
        MC.runEffectList(G, def.effects || [], { player: handUser, card, targetInst: inst });
      }
      MC.moveToDiscard(G, handUser, card, {});
    } else {
      // ── 플레이 영역 동료/서포트/준비 인터럽트 (Black Widow류): 소진/버림 + 자원 지불 → 취소 + 추가 효과 ──
      let user = null, srcCard = null;
      for (const pl of G.players)
        for (const arr of [pl.playArea.allies, pl.playArea.supports, pl.playArea.upgrades]){
          const c = arr.find(x => x.uid === cardUid);
          if (c){ user = pl; srcCard = c; break; }
        }
      if (!user) throw new Error('[interrupt] 인터럽트 카드 없음: ' + cardUid);
      const def = MC.cardDef(srcCard.defCode);
      const io = def.interruptOn;
      if (srcCard.exhausted) throw new Error('[interrupt] 이미 소진됨: ' + MC.nameOf(srcCard));
      // 자원 지불 (io.pay = {type, count})
      if (io.pay){
        const els = payment || [];
        MC.validatePayment(G, user, els, io.pay.count || 0, srcCard, { type: io.pay.type, count: io.pay.count });
        MC.executePayment(G, user, els);
      }
      // 효과: 취소 (기본)
      inst.revealCancelled = true;
      // 준비(Preparation) 카드는 발동 시 버려짐 + Widowmaker; 그 외(동료/서포트)는 소진.
      if (io.discardSelf || (def.traits || []).includes('preparation')){
        MC.triggerPreparation(G, user, srcCard);
        if (G._widowmaker && MC.offerWidowmaker) MC.offerWidowmaker(G);
      } else {
        srcCard.exhausted = true;
      }
      MC.log(G, user.uid + ' 인터럽트: ' + MC.nameOf(srcCard));
      // 추가 효과: 조우덱에서 1장 더 공개 (io.thenReveal)
      if (io.thenReveal) G._pendingExtraReveal = (G._pendingExtraReveal||0) + io.thenReveal;
    }
  }
  // 공개 재개 (interruptChecked=true라 다시 멈추지 않음)
  const rInst = G.revealing;
  G.revealing = null;
  resolveEncounterCard(G, owner, rInst);
  // 추가 공개 (Black Widow: 취소 후 조우덱에서 1장 더)
  while (G._pendingExtraReveal > 0){
    G._pendingExtraReveal--;
    MC.dealEncounterTo(G, owner, 1);
    revealPendingEncounters(G);
    if (G.pending) return; // 추가 공개 중 또 인터럽트/방어 대기 발생하면 멈춤
  }
  processVillainQueue(G);
}

/* 대응 가능한 인터럽트 목록. cardDef.interruptOn.encounterType 매칭.
   반환 항목: { player, cardUid, source:'hand'|'ally', needsPay, form } */
function collectRevealInterrupts(G, inst){
  const out = [];
  const matches = (io) => io && (io.encounterType === inst.type || io.encounterType === 'any');
  for (const p of G.players){
    // ① 손패의 인터럽트 이벤트 (히어로 폼 전용 — Hero Interrupt)
    if (p.form === 'hero'){
      for (const c of p.hand){
        const def = MC.cardDef(c.defCode);
        if (matches(def && def.interruptOn))
          out.push({ player: p.uid, cardUid: c.uid, source:'hand' });
      }
    }
    // ② 플레이 영역 동료/서포트의 인터럽트 (소진 + 자원 지불형, 폼 무관)
    for (const arr of [p.playArea.allies, p.playArea.supports]){
      for (const c of arr){
        const def = MC.cardDef(c.defCode);
        const io = def && def.interruptOn;
        if (matches(io) && !c.exhausted){
          // 폼 제약이 있으면 확인 (없으면 모든 폼)
          if (io.form && p.form !== io.form) continue;
          out.push({ player: p.uid, cardUid: c.uid, source:'ally', needsPay: io.pay });
        }
      }
    }
    // ③ 플레이 영역 업그레이드의 준비(Preparation) 인터럽트 — 그래플링 훅 (히어로 폼, 발동 시 버림 + Widowmaker)
    if (p.form === 'hero'){
      for (const c of p.playArea.upgrades){
        const def = MC.cardDef(c.defCode);
        const io = def && def.interruptOn;
        if (matches(io) && !c.exhausted){
          if (io.form && p.form !== io.form) continue;
          out.push({ player: p.uid, cardUid: c.uid, source:'preparation', needsPay: io.pay });
        }
      }
    }
  }
  return out;
}
/* 부착: 부착물 inst를 대상 target에 건다. 양방향 링크(attachedTo ↔ attachments).
   범용 — 하수인/빌런/정체성/스킴 어디든 대상 가능. */
function attachTo(G, inst, target){
  target.attachments = target.attachments || [];
  target.attachments.push(inst);
  inst.attachedTo = target.uid;
  MC.log(G, MC.nameOf(inst) + ' → ' + MC.nameOf(target) + '에 부착');
  // 부착 스탯 보정 (attachStats: {attack:+3} 등 — 돌진). 이탈 시 detachFrom이 원복.
  // 적용량을 inst.appliedStats에 기록해 원복이 정의 변경과 무관하게 정확하도록.
  const adef = MC.cardDef(inst.defCode);
  if (adef && adef.attachStats){
    inst.appliedStats = {};
    for (const k in adef.attachStats){
      target[k] = (target[k] || 0) + adef.attachStats[k];
      inst.appliedStats[k] = adef.attachStats[k];
      MC.log(G, MC.nameOf(target) + ' ' + k + ' ' + (adef.attachStats[k] >= 0 ? '+' : '') + adef.attachStats[k] + ' (' + MC.nameOf(inst) + ')');
    }
  }
  // HP 부여 부착물 (명예 어벤져 등 hpBonus): 대상이 HP 인스턴스(동료/하수인 등)면 maxHp+hp 동시 증가.
  //   히어로(pl) 부착은 recomputeMaxHp가 별도 처리 → 여기선 카드 인스턴스(type+maxHp 존재)만.
  if (adef && adef.hpBonus && target.type && target.maxHp !== undefined){
    target.maxHp += adef.hpBonus;
    target.hp = (target.hp || 0) + adef.hpBonus;
    inst.appliedHpBonus = adef.hpBonus;
    MC.log(G, MC.nameOf(target) + ' HP +' + adef.hpBonus + ' (' + MC.nameOf(inst) + ')');
  }
  // 드론 스탯 보정 부착물 (업그레이드 드론): 전장의 뒷면 드론 스탯 재계산
  if (adef && adef.droneStatBonus) recalcDroneStats(G);
}

/* 부착 해제: 대상에서 부착물 링크 제거 (인스턴스 자체 정리는 호출측 책임). */
function detachFrom(G, inst){
  if (!inst.attachedTo) return null;
  const target = MC.findByUid(G, inst.attachedTo);
  if (target && target.attachments)
    target.attachments = target.attachments.filter(a => a.uid !== inst.uid);
  // 부착 스탯 원복 (attachStats 적용분)
  if (inst.appliedStats && target){
    for (const k in inst.appliedStats) target[k] = (target[k] || 0) - inst.appliedStats[k];
  }
  delete inst.appliedStats;
  // HP 부여 원복 (동료 hpBonus): maxHp 감소 + hp 상한 클램프
  if (inst.appliedHpBonus && target && target.maxHp !== undefined){
    target.maxHp -= inst.appliedHpBonus;
    if (target.hp > target.maxHp) target.hp = target.maxHp;
    if (target.hp < 0) target.hp = 0;
  }
  delete inst.appliedHpBonus;
  inst.attachedTo = null;
  // 드론 스탯 보정 부착물 이탈: 뒷면 드론 스탯 재계산 (HP 상한 하락 즉사 포함)
  const ddef = MC.cardDef(inst.defCode);
  if (ddef && ddef.droneStatBonus) recalcDroneStats(G);
  return target;
}

/* 대상이 격파/제거될 때 그 부착물들을 처리한다.
   각 부착물의 whenAttachedDefeated 훅을 발화한 뒤, 소유에 따라 정리:
   플레이어 카드(side:'player') → 소유자 버림 / 인카운터 카드 → 조우 버림. */
function releaseAttachments(G, target){
  const atts = (target.attachments || []).slice();
  for (const att of atts){
    const def = MC.cardDef(att.defCode);
    // 부착 대상이 격파될 때 발동하는 훅 (spider-tracer 등)
    MC.fireCardHook(G, att, 'whenAttachedDefeated', { target, attachment: att });
    att.attachedTo = null;
    delete att.appliedStats;   // 대상 격파 — 스탯 원복 불필요, 잔여 기록만 정리 (재공개 시 오염 방지)
    if (def.side === 'player'){
      const owner = G.players.find(p => p.uid === att.ownerUid);
      if (owner){
        for (const arr of [owner.playArea.upgrades, owner.playArea.supports])
          { const i = arr.indexOf(att); if (i>=0) arr.splice(i,1); }
        MC.moveToDiscard(G, owner, att, {});
      }
    } else {
      G.encounterDiscard.push(att);
    }
  }
  target.attachments = [];
}

MC.drawEncounterCard = drawEncounterCard; MC.dealEncounterTo = dealEncounterTo;
MC.placeThreat = placeThreat; MC.removeThreat = removeThreat; MC.resolveScheme = resolveScheme;
MC.onSideSchemeCleared = onSideSchemeCleared;
MC.onMainSchemeThreshold = onMainSchemeThreshold; MC.advanceMainScheme = advanceMainScheme;
MC.startVillainPhase = startVillainPhase; MC.processVillainQueue = processVillainQueue;
MC.villainStepOnce = villainStepOnce;
MC.enemyActivation = enemyActivation; MC.resolveDefensePending = resolveDefensePending;
MC.revealPendingEncounters = revealPendingEncounters; MC.resolveEncounterCard = resolveEncounterCard;
MC.resolveRevealInterrupt = resolveRevealInterrupt; MC.collectRevealInterrupts = collectRevealInterrupts;
MC.attachTo = attachTo; MC.detachFrom = detachFrom; MC.releaseAttachments = releaseAttachments;
MC.revealSpecificSideScheme = revealSpecificSideScheme;
MC.discardUntilMinionIntoPlay = discardUntilMinionIntoPlay;
MC.searchMinionIntoPlay = searchMinionIntoPlay;
MC.startMinionAttackChain = startMinionAttackChain;
MC.spawnFacedownDrone = spawnFacedownDrone;
MC.recalcDroneStats = recalcDroneStats;
MC.droneBaseStats = droneBaseStats;
