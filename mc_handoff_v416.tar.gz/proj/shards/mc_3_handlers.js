/* ═══════════════════════════════════════════════════════════════
   mc_3_handlers.js — 샤드 3/7 : HANDLERS(트리거/지속) + fireHook
   카드 필드 → 훅 매핑:
     whenPlayed / response / interrupt / forcedResponse / forcedInterrupt
     whenRevealed / whenDefeated / whenCompleted / setup
     villainPhaseStart / playerPhaseStart / endOfPhase / endOfRound
   카드에는 { whenRevealed:'핸들러이름' } 처럼 이름만 둔다.
   ═══════════════════════════════════════════════════════════════ */

const HANDLERS = {};

/* fireHook(G, hookName, ctx)
   플레이 중인 모든 카드 인스턴스에서 hookName 필드를 가진 카드를 찾아
   HANDLERS[card[hookName]] 호출. 순서: 선 플레이어부터 시계방향 → 인카운터측. */
function fireHook(G, hookName, ctx){
  const insts = MC.allInPlay(G); // mc_7_core에서 정의 (선 플레이어 순 정렬)
  for (const inst of insts){
    const hname = inst[hookName];
    if (!hname) continue;
    const fn = HANDLERS[hname];
    if (!fn) throw new Error('[fireHook] 미등록 handler: ' + hname + ' (hook=' + hookName + ')');
    fn(G, Object.assign({ self: inst, hook: hookName }, ctx || {}));
  }
}

/* 단일 카드 대상 훅 호출 (whenRevealed/whenPlayed/whenDefeated 등 자기 자신 트리거).
   훅 이름은 인스턴스 우선, 없으면 카드 정의(cardDef)에서 조회 — whenPlayed 등은
   baseFields라 인스턴스로 복사되지 않고 정의에만 존재. */
function fireCardHook(G, inst, hookName, ctx){
  const raw = (inst && inst[hookName]) ||
              (inst && inst.defCode && MC.cardDef(inst.defCode) && MC.cardDef(inst.defCode)[hookName]);
  if (!raw) return false;
  // 데이터(인덱스) 방식: { useCounter?, cond?, effect:[...] } — 카운터 소비 후 효과 실행 (Iron Fist 등).
  if (typeof raw === 'object'){
    if (raw.useCounter){
      if ((inst.counters || 0) < 1){ MC.log(G, MC.nameOf(inst) + ' — 카운터 없음, 능력 불발'); return false; }
      inst.counters -= 1;
      MC.log(G, MC.nameOf(inst) + ' — 카운터 1 소비 (' + inst.counters + ' 남음)');
    }
    const c2 = Object.assign({ self: inst, hook: hookName }, ctx || {});
    if (!raw.cond || MC.condCheck(G, raw.cond, c2)) MC.runEffectList(G, raw.effect || [], c2);
    return true;
  }
  const fn = HANDLERS[raw];
  if (!fn) throw new Error('[fireCardHook] 미등록 handler: ' + raw);
  fn(G, Object.assign({ self: inst, hook: hookName }, ctx || {}));
  return true;
}

/* 공격 개시 인터럽트: 대상 플레이어의 현재 신분(영웅면)에 걸린 attackInterrupt 훅 발화.
   Spider-Sense처럼 "빌런이 당신을 공격 개시할 때" 트리거되는 능력용.
   신분 카드 정의(cardDef)의 attackInterrupt 이름 → HANDLERS 조회. */
function fireAttackInterrupt(G, pl, attacker){
  if (pl.form !== 'hero') return;              // 영웅면 능력만
  const def = MC.cardDef(pl.heroCode);
  const hname = def && def.attackInterrupt;
  if (!hname) return;
  const fn = HANDLERS[hname];
  if (!fn) throw new Error('[fireAttackInterrupt] 미등록 handler: ' + hname);
  fn(G, { self: pl, hook: 'attackInterrupt', player: pl, attacker });
}

/* 범용 훅 핸들러: 카드 정의의 effects 배열(또는 훅별 <hook>Effects)을 데이터로 실행.
   조우 카드가 커스텀 핸들러 없이 whenRevealed:'runCardEffects' + effects:[...]만 선언하면
   빌런 공격/암약/위협/폼분기 등을 인덱스(EFFECTS)로 처리. ctx.player는 공개한 플레이어. */
HANDLERS.runCardEffects = function(G, ctx){
  const self = ctx.self;
  const def = (self && self.defCode && MC.cardDef(self.defCode)) || self;
  const list = (def && (def[(ctx.hook || '') + 'Effects'] || def.effects)) || null;
  if (!list) return;
  // UI/디스패치가 넘긴 대상 선택값(targetScheme/targetPlayer/choice/targets)을 효과까지 전달.
  MC.runEffectList(G, list, { player: ctx.player, card: self, self,
    targetScheme: ctx.targetScheme, targetPlayer: ctx.targetPlayer,
    choice: ctx.choice, targets: ctx.targets });
};

// 에디슨의 거대 로봇(05028) 무효화: 🧠1 지불 후 이 하수인의 텍스트 박스를 페이즈 끝까지 무효화 (피해 가능해짐).
HANDLERS.nullifyRobot = function(G, ctx){
  const m = ctx.self || ctx.card;
  if (!m) return;
  m.nullifiedThisPhase = true;
  MC.log(G, MC.nameOf(m) + ' — 텍스트 무효화 (이 페이즈 피해 가능)');
};

// 부착물 "공격+피해 후" 강제반응을 데이터로 실행 (소닉 컨버터=피해 대상 기절 등). 범용 인덱스.
//   방어 해소부가 { player, target: dmgTarget, attacker, self: 부착물 } 컨텍스트로 호출.
HANDLERS.runAttachDamagedEffects = function(G, ctx){
  const def = ctx.self && MC.cardDef(ctx.self.defCode);
  if (def && def.attackDamagedEffects)
    MC.runEffectList(G, def.attackDamagedEffects,
      { player: ctx.player, self: ctx.self, card: ctx.self, target: ctx.target, attacker: ctx.attacker });
};

// 페이즈 훅에서 자신에게 카운터 N개 적립 (데이터: counterGainPerPhase, 기본 1). 퀸젯 시간 카운터 등 범용 인덱스.
//   playerPhaseStart 등 훅 필드가 이 핸들러명을 가리키면, fireHook이 전장의 해당 카드마다 호출.
HANDLERS.gainCounterOnPhase = function(G, ctx){
  const self = ctx.self;
  if (!self) return;
  const gain = (MC.cardDef(self.defCode).counterGainPerPhase) || 1;
  self.counters = (self.counters || 0) + gain;
  MC.log(G, MC.nameOf(self) + ' — 카운터 +' + gain + ' (누적 ' + self.counters + ')');
};

// Preemptive Strike(방어 인터럽트): 방어 pending의 부스트 카드를 취소(▲아이콘 제거) + 취소 수만큼 빌런 피해.
HANDLERS.preemptiveStrike = function(G, ctx){
  const p = G.pending;
  if (!p || p.kind !== 'defense'){ MC.log(G, 'Preemptive Strike — 방어 상황이 아님'); return; }
  const pl = ctx.player;
  const bc = p.boostCard;
  if (!bc){ MC.log(G, 'Preemptive Strike — 취소할 부스트 카드 없음'); return; }
  const icons = MC.boostOf(G, bc, pl) || 0;
  // 부스트 카드 취소: pending에서 제거 + 버림 (앞면 공개 없이 취소 → ★효과 미발동)
  p.boostCard = null;
  G.encounterDiscard.push(bc);
  MC.log(G, 'Preemptive Strike — 부스트 카드(' + MC.nameOf(bc) + ') 취소, ▲' + icons + ' 아이콘 제거');
  // 취소한 아이콘 수만큼 빌런에 피해
  if (icons > 0 && G.villain){
    MC.applyDamage(G, G.villain, icons, { source: ctx.self });
    MC.log(G, 'Preemptive Strike — 빌런에 ' + icons + ' 피해');
  }
  G.fxEvent = { vfx:'preemptiveStrike', villainUid: G.villain && G.villain.uid, targetUids: G.villain ? [G.villain.uid] : [] };
};

/* ★ 어보밍맨 II(04077) When Revealed: Super Absorbing Power(04092)가 전장에 있으면
   각 플레이어에게 조우 카드 1장, 없으면 04092를 소환(사이드 스킴 배치)한다.
   04092는 setAside 카드 — 조우덱/버린더미에 없으므로 makeInstance로 직접 생성해 배치. */
HANDLERS.absorbingSummonSuperPower = function(G, ctx){
  const inPlay = (G.sideSchemes || []).some(s => s.defCode === '04092');
  if (inPlay){
    for (const pl of MC.playersInOrder(G))
      MC.runEffectList(G, [{ fx: 'dealEncounterToEngaged', count: 1 }], { player: pl });
    MC.log(G, '초강력 흡수가 이미 전장에 — 각 플레이어 조우 카드 1장');
  } else {
    const def = MC.cardDef('04092');
    const inst = MC.makeInstance(G, '04092', { kind: 'side_scheme', isMain: false });
    inst.threat = (def.baseThreatPerPlayer || 0) * G.players.length + (def.baseThreat || 0);
    inst.peakThreat = inst.threat;
    G.sideSchemes.push(inst);
    MC.log(G, '초강력 흡수(Super Absorbing Power) 소환 — 시작 위협 ' + inst.threat);
    G._superAbsorbSpawn = { defCode: '04092', uid: inst.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  }
};

/* 하이드라에 포획(04107 Captured by Hydra) — 공개 시: 게임 밖에 둔 포로(Captive) 동료 1명을
   이 사이드 스킴 아래에 둔다(억류). 이 스킴을 저지하면 그 동료를 구출해 손에 넣는다. */
HANDLERS.capturedByHydraReveal = function(G, ctx){
  const self = ctx.self || ctx.card;
  const pool = G.setAsideCaptives || [];
  if (!pool.length){ MC.log(G, '억류할 포로 동료가 없음'); return; }
  const idx = Math.floor((MC.rng ? MC.rng(G) : Math.random()) * pool.length);
  const cap = pool.splice(idx, 1)[0];
  self.captiveAlly = cap;   // 이 스킴 아래 (facedown)
  MC.log(G, MC.nameOf(self) + ' — 포로 동료 1명을 억류했다');
  G._captiveHeld = { schemeUid: self.uid, allyCode: cap, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
};
HANDLERS.capturedByHydraDefeat = function(G, ctx){
  const self = ctx.self || ctx.card;
  const pl = ctx.player || G.players[G.firstPlayer];
  if (self.captiveAlly){
    const inst = MC.makeInstance(G, self.captiveAlly, {});
    pl.hand.push(inst);
    MC.log(G, MC.nameOf(pl) + ' — 포로 동료 ' + MC.nameOf(inst) + ' 구출! 손에 넣었다');
    G._captiveRescued = { allyCode: self.captiveAlly, player: pl.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    self.captiveAlly = null;
  }
  self.removeFromGame = true;   // 게임에서 제거 (버림 아님)
};

MC.HANDLERS = HANDLERS;
MC.fireHook = fireHook;
MC.fireCardHook = fireCardHook;
MC.fireAttackInterrupt = fireAttackInterrupt;

/* 기본 공격 후 강제 반응: 발동 플레이어의 플레이 영역 카드(업그레이드/서포트) 중
   afterBasicAttack 핸들러가 있으면 발화 (초인적인 힘 등). 대상=공격받은 적. */
function fireAfterBasicAttack(G, pl, attackedTarget){
  const zones = [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies];
  for (const zone of zones){
    for (const card of zone.slice()){   // slice: 발화 중 버림으로 배열 변형 대비
      const def = MC.cardDef(card.defCode);
      const hname = card.afterBasicAttack || (def && def.afterBasicAttack);
      if (!hname) continue;
      const fn = HANDLERS[hname];
      if (!fn) throw new Error('[fireAfterBasicAttack] 미등록 handler: ' + hname);
      fn(G, { self: card, hook: 'afterBasicAttack', player: pl, target: attackedTarget });
    }
  }
  // 선택 반응 (afterAttackReaction 인덱스) — 조건 충족 카드를 큐에 모아 순차 pending 창 생성.
  MC.queueAfterAttackReactions(G, pl, attackedTarget);
}
/* 공격 후 선택 반응(afterAttackReaction) 큐 생성. Battle Fury(처치 조건)·Jarnbjorn(자원 지불) 등.
   cardDef.afterAttackReaction = { condition?, cost?, needsTarget?, effects, discardSelf?, prompt } */
function queueAfterAttackReactions(G, pl, attackedTarget){
  if (G.pending) return;   // 다른 pending 진행 중이면 스킵(안전)
  const cands = [];
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const rx = MC.cardDef(c.defCode).afterAttackReaction;
      if (!rx) continue;
      if (rx.condition === 'defeatedMinion'){   // 공격으로 하수인 처치 시에만 (Battle Fury)
        if (!attackedTarget || attackedTarget.type !== 'minion' || attackedTarget.hp > 0) continue;
      }
      // 자원 지불(cost)이 필요한데 지불 가능한 손패 자원이 전혀 없으면 후보 제외 (Jarnbjorn)
      cands.push({ cardUid: c.uid, targetUid: attackedTarget && attackedTarget.uid });
    }
  }
  if (!cands.length) return;
  G._afterAttackQueue = cands.slice(1);
  const first = cands[0];
  G.pending = { kind:'afterAttackReaction', player: pl.uid, cardUid: first.cardUid, targetUid: first.targetUid };
}
MC.queueAfterAttackReactions = queueAfterAttackReactions;
MC.fireAfterBasicAttack = fireAfterBasicAttack;

/* ── 범용 사이드 스킴 핸들러 ──
   공개 시 플레이어당 추가 위협 (방어망 01125, 불법 무기 공장 01126 등 다수 재사용).
   기본 1/인 — 다른 양이 필요하면 def.revealThreatPerHero로 지정. */
