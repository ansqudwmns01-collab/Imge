/* ═══════════════════════════════════════════════════════════════
   mc_6_keywords.js — 샤드 6/7 : 피해 파이프라인 · 상태 · condCheck
   강인/관통/보복/과잉살상 상호작용은 반드시 이 파이프라인 한 곳에서.
   (넷러너의 effectiveStrength 파이프라인에 해당)
   ═══════════════════════════════════════════════════════════════ */

/* applyDamage(G, target, amount, opt)
   opt: { source, piercing, overkill, isVillainAttack } */
function applyDamage(G, target, amount, opt){
  opt = opt || {};
  if (amount <= 0) return 0;
  // 0) 울트론 III(01136) invulnWhileDrone: 전장에 Drone 하수인이 하나라도 있으면 빌런은 피해를 받지 않음.
  if (target.kind === 'villain'){
    const vdef = MC.cardDef(target.defCode);
    if (vdef && vdef.invulnWhileDrone){
      const anyDrone = G.players.some(p => p.engagedMinions.some(m => m.isDrone || (m.traits||[]).includes('drone')));
      if (anyDrone){
        MC.log(G, MC.nameOf(target) + ' — 전장에 드론이 있어 피해 무효 (무적)');
        G.fxUltronInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.5) 킬몽거(01157) immuneToUpgradeDamage: 특정 영웅의 업그레이드가 주는 피해를 받지 않음.
  if (opt.source){
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.immuneToUpgradeDamage){
      const sd = MC.cardDef(opt.source.defCode || opt.source.code);
      if (sd && sd.type === 'upgrade' && sd.hero === tdef.immuneToUpgradeDamage){
        MC.log(G, MC.nameOf(target) + ' — ' + tdef.immuneToUpgradeDamage + ' 업그레이드 피해 면역');
        G.fxKillmongerImmune = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.6) 마담 히드라(01181) invulnWhileScheme: 특정 사이드 스킴이 전장에 있는 동안 피해 면역.
  {
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.invulnWhileScheme){
      const present = (G.sideSchemes || []).some(s => s.defCode === tdef.invulnWhileScheme);
      if (present){
        MC.log(G, MC.nameOf(target) + ' — ' + tdef.invulnWhileScheme + ' 존재 중 피해 면역');
        G.fxSchemeInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.68) 크로스본즈의 아머(04065): 빌런이 피해를 받을 때 → 아머가 대신 흡수(여기 배치). 5+ 누적 시 아머 파괴.
  if (target.kind === 'villain'){
    const armor = (target.attachments || []).find(a => MC.cardDef(a.defCode) && MC.cardDef(a.defCode).absorbsVillainDamage);
    if (armor){
      armor.absorbedDamage = (armor.absorbedDamage || 0) + amount;
      MC.log(G, MC.nameOf(target) + ' 피해 ' + amount + ' → ' + MC.nameOf(armor) + ' 흡수 (누적 ' + armor.absorbedDamage + ')');
      if (armor.absorbedDamage >= 5){
        const i = target.attachments.indexOf(armor);
        if (i >= 0) target.attachments.splice(i, 1);
        try { if (MC.detachFrom) MC.detachFrom(G, armor); } catch (e) {}
        (G.encounterDiscard = G.encounterDiscard || []).push(armor);
        MC.log(G, MC.nameOf(armor) + ' — 5 이상 피해 누적, 파괴');
      }
      return 0;
    }
  }
  // 0.69) 사진 반사(04104): 태스크마스터가 피해를 받을 때 → 그 피해를 방지하고, 같은 양을 공격한 플레이어의 신분에 대신 준다. 그 후 이 부착을 버린다.
  if (target.kind === 'villain'){
    const reflect = (target.attachments || []).find(a => { const cd = MC.cardDef(a.defCode); return cd && cd.villainDamageReflect; });
    if (reflect && opt.source){
      // 공격자 플레이어 판별: source가 플레이어 객체거나, source.playerUid/owner로 소급
      let pl = null;
      if (opt.source.uid && (G.players || []).some(p => p.uid === opt.source.uid)) pl = G.players.find(p => p.uid === opt.source.uid);
      else if (opt.source.playerUid) pl = G.players.find(p => p.uid === opt.source.playerUid);
      else if (opt.source.isPlayer && G.players.length === 1) pl = G.players[0];
      if (pl && !pl.eliminated){
        MC.log(G, MC.nameOf(target) + ' — 사진 반사: 피해 ' + amount + ' 방지 → ' + MC.nameOf(pl) + '의 신분에 반사');
        G._photoReflect = { targetUid: target.uid, playerUid: pl.uid, amount, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        // 부착 버림 (반사 처리 전에 제거하여 반사 피해가 다시 이 부착을 타지 않도록)
        const i = target.attachments.indexOf(reflect);
        if (i >= 0) target.attachments.splice(i, 1);
        try { if (MC.detachFrom) MC.detachFrom(G, reflect); } catch (e) {}
        (G.encounterDiscard = G.encounterDiscard || []).push(reflect);
        MC.applyDamage(G, pl, amount, { source: reflect, isAttack: false });
        return 0;
      }
    }
  }
  // 0.65) 토마스 에디슨(05027) invulnWhileOtherMinion: 자신과 같은 플레이어와 교전 중인 다른 하수인이 있으면 피해 면역.
  {
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.invulnWhileOtherMinion && target.kind === 'minion'){
      const hasOther = G.players.some(pl =>
        (pl.engagedMinions || []).includes(target) &&
        pl.engagedMinions.some(m => m !== target && m.hp > 0));
      if (hasOther){
        MC.log(G, MC.nameOf(target) + ' — 다른 하수인과 함께 있어 피해 면역');
        G.fxMinionInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return 0;
      }
    }
  }
  // 0.66) 에디슨의 거대 로봇(05028) invulnUnlessNullified: 기본 피해 면역. 무효화 액션(nullifiedThisPhase)이면 피해 가능.
  {
    const tdef = MC.cardDef(target.defCode);
    if (tdef && tdef.invulnUnlessNullified && target.kind === 'minion' && !target.nullifiedThisPhase){
      MC.log(G, MC.nameOf(target) + ' — 피해 면역 (무효화 필요)');
      G.fxRobotInvuln = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
      return 0;
    }
  }
  // 0.7) 노먼 오스본 damageToCounter: 빌런이 피해를 받게 될 때 → 피해 대신 그만큼
  //      악명 카운터를 제거한다 (0 도달 시 goblinRemoveCounter가 폼전환 발동).
  if (target.kind === 'villain'){
    const vdef = MC.cardDef(target.defCode);
    if (vdef && vdef.damageToCounter && MC.goblinRemoveCounter){
      MC.log(G, MC.nameOf(target) + ' — 피해 ' + amount + ' 대신 악명 카운터 제거');
      G.fxGoblinCounter = { targetUid: target.uid, op:'remove', amount, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
      MC.goblinRemoveCounter(G, amount);
      return 0;   // 빌런 본체 무피해
    }
  }
  // 1) 강인: 관통이 아니면 피해 전부 무효 + 토큰 제거
  if (target.status && target.status.tough > 0 && !opt.piercing){
    target.status.tough--;
    MC.log(G, MC.nameOf(target) + ' 강인 — 피해 무효');
    return 0;
  }
  // 1.5) 라이노 장갑 슈트: 빌런에 부착된 armor-suit이 있으면 피해를 슈트에 쌓음.
  //      5 이상 쌓이면 슈트 파괴 (다음 피해부터 빌런 본체가 받음). 강제 개입.
  if (target.attachments && target.attachments.length){
    const suit = target.attachments.find(a => a.defCode === 'rhino-suit' && !a._destroyed);
    if (suit){
      suit.damageHere = (suit.damageHere || 0) + amount;
      MC.log(G, '장갑 라이노 슈트 — 피해 ' + amount + ' 흡수 (누적 ' + suit.damageHere + ')');
      if (suit.damageHere >= 5){
        suit._destroyed = true;
        const i = target.attachments.indexOf(suit);
        if (i >= 0) target.attachments.splice(i, 1);
        if (G.encounterDiscard) G.encounterDiscard.push(suit);
        MC.log(G, '장갑 라이노 슈트 — 5 피해 누적, 파괴됨');
        G.fxSuitBreak = { targetUid: target.uid };
      }
      return 0;   // 슈트가 전부 흡수 (빌런 본체 무피해)
    }
  }
  // 2) 피해 적용
  target.hp -= amount;
  MC.log(G, MC.nameOf(target) + ' 피해 ' + amount + ' (HP ' + target.hp + '/' + target.maxHp + ')');
  // 3) 보복 (공격에 의한 피해일 때, 공격자에게) — 공식 룰: 트리거는 "공격받음"(피해량 무관),
  //    단 공격에서 살아남아야 함. 방어로 0피해·강인 흡수인 경우는 공격 해소부(resolveDefense 등)가
  //    triggerRetaliate를 직접 호출하므로, 여기선 실제 피해가 간 공격에 한해 발동(noRetaliate로 억제 가능).
  if (!opt.isRetaliate && !opt.noRetaliate)
    MC.triggerRetaliate(G, target, opt.source);
  // 4) 처치 판정
  if (target.hp <= 0){
    // 히어로 패배 방지 (캡틴아메리카의 헬멧 등): 플레이 영역 업그레이드가 "패배당할 때 HP를 N으로" 하고 자신을 버림.
    if (!opt.isRetaliate && target.playArea && target.playArea.upgrades){
      const prot = target.playArea.upgrades.find(c => {
        const cd = MC.cardDef(c.defCode); return cd && cd.preventDefeatToHp !== undefined;
      });
      if (prot){
        const cd = MC.cardDef(prot.defCode);
        target.hp = cd.preventDefeatToHp;
        const i = target.playArea.upgrades.indexOf(prot);
        if (i >= 0) target.playArea.upgrades.splice(i, 1);
        if (prot.attachments && prot.attachments.length) MC.releaseAttachments(G, prot);
        MC.moveToDiscard(G, target, prot, {});
        MC.log(G, MC.nameOf(target) + ' — ' + MC.nameOf(prot) + ' 난입: 패배 대신 HP ' + target.hp + '로, 카드 버림');
        G.fxHelmetSave = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        return amount;
      }
    }
    // 부착물 부활(reviveOnDefeat): 부착 하수인이 처치될 뻔하면 HP 전량 회복 후 그 부착물만 버림 (Biomechanical Upgrades 01185).
    if (!opt.isRetaliate && target.attachments && target.attachments.length){
      const rev = target.attachments.find(a => { const ad = MC.cardDef(a.defCode); return ad && ad.reviveOnDefeat; });
      if (rev){
        target.hp = target.maxHp;
        MC.detachFrom(G, rev, target);
        (G.encounterDiscard = G.encounterDiscard || []).push(rev);
        MC.log(G, MC.nameOf(target) + ' — ' + MC.nameOf(rev) + ' 강제 난입: HP 전량 회복 후 부착물 버림 (처치 방지)');
        G.fxBiomechRevive = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
        MC.fireCardHook(G, rev, 'onRevive', { target });
        return amount;
      }
    }
    // 과잉살상(overkill): 하수인 처치 시 초과 피해를 빌런에게 전달 (opt.overkill일 때).
    // 초과 = 처치 후 남은 음수 HP의 절댓값. 빌런에게는 overkill을 전파하지 않음(중복 방지).
    let excess = 0;
    if (opt.overkill && target.type === 'minion') excess = -target.hp;
    MC.onDefeated(G, target, opt);
    if (excess > 0 && G.villain && G.villain.hp > 0){
      MC.log(G, '과잉살상 — 초과 피해 ' + excess + ' → 빌런');
      applyDamage(G, G.villain, excess, { source: opt.source, piercing: opt.piercing });
    }
  } else if (!opt.isRetaliate && target.attachments && target.attachments.length){
    // 비브라늄 갑옷(01152) 강제반응: 빌런이 피해를 받은 후(생존 시) 강인(Tough) 카드 부여.
    for (const att of target.attachments){
      const adef = MC.cardDef(att.defCode);
      if (adef && adef.grantsToughOnDamage){
        MC.setStatus(G, target, 'tough', true);
        MC.log(G, MC.nameOf(target) + ' — ' + MC.nameOf(att) + ': 피해 후 강인(Tough) 부여');
        G.fxArmorRetough = { targetUid: target.uid, seq: (G.fxSeq = (G.fxSeq||0)+1) };
        break;
      }
    }
  }
  return amount;
}

function healTarget(G, target, amount){
  const before = target.hp;
  target.hp = Math.min(target.maxHp, target.hp + amount);
  const healed = target.hp - before;
  MC.log(G, MC.nameOf(target) + ' 회복 ' + healed + ' (HP ' + target.hp + ')');
  return healed;
}

function setStatus(G, target, status, on){
  target.status = target.status || { stunned:0, confused:0, tough:0 };
  if (on) target.status[status]++;
  else target.status[status] = Math.max(0, target.status[status]-1);
}

function onDefeated(G, target, opt){
  MC.log(G, MC.nameOf(target) + ' 격파됨');
  // 히어로가 공격으로 적(하수인 또는 빌런단계)을 처치한 경우 추적 (chase-them-down 반응용).
  // opt.source가 히어로 신분(isPlayer/heroCode)이고 공격(isAttack)일 때 플레이어에 플래그.
  if (opt && opt.isAttack && opt.source && (opt.source.isPlayer || opt.source.heroCode) &&
      (target.type === 'minion' || target.kind === 'villain')){
    opt.source.justDefeatedEnemyByAttack = true;
  }
  // 히어로 본인이 하수인을 처치한 경우 추적 (심문실 반응용 — 공격/이벤트 등 수단 무관,
  // 단 하수인만. 동료·지원 소스는 제외. FAQ: "당신"=정체성/업그레이드/자원카드/이벤트).
  if (opt && opt.source && target.type === 'minion'){
    const src = opt.source;
    const owner = src.isPlayer ? src : (src.heroCode ? G.players.find(p => p.heroCode === src.heroCode) : null);
    if (owner){
      owner.justDefeatedMinionByHero = true;
      // 영광 카운터 축적 (Hall of Heroes 06017): 하수인 처치 시 gloryOnMinionDefeat 지원 카드에 +1.
      for (const c of (owner.playArea.supports || [])){
        if (MC.cardDef(c.defCode).gloryOnMinionDefeat){
          c.counters = (c.counters || 0) + 1;
          MC.log(G, MC.nameOf(c) + ' — 영광 카운터 +1 (총 ' + c.counters + ')');
        }
      }
    }
  }
  MC.fireCardHook(G, target, 'whenDefeated', { by: opt.source });
  // 부착물 처리: 대상이 사라지기 전에 whenAttachedDefeated 발화 + 부착물 정리
  if (target.attachments && target.attachments.length) MC.releaseAttachments(G, target);
  if (target.kind === 'villain'){
    // 코어 룰: 게임당 2스테이지. 최종 스테이지 번호(G.villainFinalStageNum)에 도달한 단계를 처치하면 승리.
    //   일반: I 처치 → II 진행, II(최종) 처치 → 승리 / 전문가: II 처치 → III 진행, III(최종) 처치 → 승리.
    const vdef = MC.cardDef(target.defCode);
    const finalNum = G.villainFinalStageNum || Infinity;
    const isFinal = !vdef.nextStage || (vdef.stage || 1) >= finalNum;
    if (!isFinal) MC.advanceVillainStage(G);
    else MC.setGameOver(G, 'win', '빌런 격파');
  } else if (target.isPlayer){
    MC.onPlayerDefeated(G, target);
  } else if (target.type === 'minion'){
    // 로키(06028) 격파 인터럽트: 조우덱 top 1장 버림 → 배신(Treachery)이면 전체 회복하여 부활 (격파 취소)
    const mdef = MC.cardDef(target.defCode);
    if (mdef.reviveOnTreachery && !opt._noRevive && (G.encounterDeck || []).length){
      const top = G.encounterDeck.pop();
      G.encounterDiscard.push(top);
      const isTreach = MC.cardDef(top.defCode).type === 'treachery';
      MC.log(G, MC.nameOf(target) + ' 격파 인터럽트 — 조우덱 상단 ' + MC.nameOf(top) + ' 버림' + (isTreach ? ' (배신!)' : ''));
      if (isTreach){
        target.hp = target.maxHp;
        MC.log(G, MC.nameOf(target) + ' — 배신 카드로 전체 회복하여 부활!');
        G.fxRevive = { uid: target.uid, quoteKey: target.defCode };
        return;   // 격파 취소 (조우 버림 안 함, 전장 유지)
      }
    }
    // 과잉살상: 잉여 피해 → 빌런 (opt.overkill일 때) — Phase 1에서 잉여 계산 연결
    const pl = G.players.find(p => p.uid === target.engagedWith);
    if (pl) pl.engagedMinions = pl.engagedMinions.filter(m => m !== target);
    if (target.isDrone){
      // 울트론 드론 환경 강제 반응: 드론 처치 시 뒷면 카드는 소유자의 버림 더미로 (토큰은 소멸)
      const owner = G.players.find(p => p.uid === target.droneOwner) || pl;
      if (owner && target.facedownCard){
        owner.discard.push(target.facedownCard);
        MC.log(G, '드론의 뒷면 카드(' + MC.nameOf(target.facedownCard) + ') → ' + owner.uid + ' 버림 더미로');
      }
    } else {
      G.encounterDiscard.push(target);
    }
  } else if (target.type === 'ally'){
    const pl = G.players.find(p => p.uid === target.ownerUid);
    if (pl){
      pl.playArea.allies = pl.playArea.allies.filter(a => a !== target);
      const di = MC.cardDef(target.defCode).defeatInterrupt;
      if (di && di.shuffleIntoDeck){
        // 클레아: 격파 시 버림 대신 소유자 덱에 셔플.
        pl.deck.push(target);
        if (MC.shuffle) MC.shuffle(G, pl.deck);
        MC.log(G, MC.nameOf(target) + ' 격파 — 소유자 덱에 셔플');
        return;
      }
      if (di && !G.pending){
        // 처치 인터럽트(레드 대거): 서로 다른 자원 2개 지불 → 적에 피해 + 손 반환. 미지불 시 버림.
        G.pending = { kind:'allyDefeatInterrupt', player: pl.uid, ally: target,
          allyUid: target.uid, damage: di.damage || 0, differentTypes: di.differentTypes || 2,
          vfx: di.vfx || null, chosenPay: [], targetUid: null,
          prompt: di.prompt || (MC.nameOf(target) + ' 처치 — 서로 다른 자원 2개를 지불하면 적에게 피해를 주고 손으로 되돌립니다') };
        MC.log(G, MC.nameOf(target) + ' 처치 — 인터럽트 대기 (자원 지불 선택)');
        return;
      }
      MC.moveToDiscard(G, pl, target, {});
      MC.maybeOfferRapidResponse(G, pl, target);   // 처치된 동료를 버린더미에서 되살림 (히어로 반응)
    }
  }
}

/* 빌런 단계 전환 (코어 룰): 다음 단계로 교체, HP는 새 단계 만점(잉여 피해 이월 없음),
   부착물/상태 토큰은 유지 */
function advanceVillainStage(G){
  const old = G.villain;
  const next = MC.cardDef(old.defCode).nextStage;
  const v = MC.makeInstance(G, next, { kind:'villain' });
  const def = MC.cardDef(next);
  const per = def.hpPerPlayer !== undefined ? def.hpPerPlayer : def.hp;
  v.hp = v.maxHp = per * G.players.length;
  v.attachments = old.attachments || [];
  v.status = old.status;
  G.villain = v;
  MC.log(G, '빌런 단계 전환 → ' + MC.nameOf(v) + ' 단계 ' + (MC.cardDef(next).stage||'?') +
    ' (HP ' + v.hp + ', ATK ' + v.attack + ')');
  // 새 단계의 When Revealed 발화 (라이노 II=사이드스킴 공개, III=Toughness+전체기절)
  MC.fireCardHook(G, v, 'whenRevealed', { villain: v });
}

/* 하수인 등장 힌트 + 아군 동료의 하수인 등장 반응(호크아이 화살 등)을 선택 큐에 등록.
   onMinionEnterDamage {counter?, amount} 보유 동료마다 반응 후보를 G._pendingMinionReactions에 push.
   실제 발동/대상은 flushMinionReactions가 revealChoice(발동/넘김) 선택으로 물어봄 → 카드 선택 기능 보존. */
function minionEnteredPlay(G, minion, pl){
  if (!minion) return;
  G.minionJustEntered = minion.uid;
  // 신분 "하수인 교전 후" 반응 (토르 06001a Have at thee! — 페이즈당 1회 카드 2장 드로우).
  // 교전 플레이어(pl)의 현재 폼 신분 def에 onMinionEngage가 있으면 발동. 범용 인덱스.
  if (pl && !pl.eliminated){
    const idef = MC.cardDef(pl.form === 'hero' ? pl.heroCode : pl.aeCode);
    const eng = idef && idef.onMinionEngage;
    if (eng && (!eng.form || pl.form === eng.form)){
      pl.usedIdentityEngageThisPhase = pl.usedIdentityEngageThisPhase || {};
      if (!(eng.oncePerPhase && pl.usedIdentityEngageThisPhase[pl.form])){
        if (eng.drawCards) MC.drawCards(G, pl, eng.drawCards);
        if (eng.effect) MC.runEffectList(G, Array.isArray(eng.effect) ? eng.effect : [eng.effect], { player: pl });
        if (eng.oncePerPhase) pl.usedIdentityEngageThisPhase[pl.form] = true;
        MC.log(G, MC.nameOf(pl) + ' — ' + (eng.name || '신분 반응') + ' 발동');
        if (eng.vfx) G._identityEngageVfx = { vfx: eng.vfx, playerUid: pl.uid };
      }
    }
  }
  for (const p of (G.players || [])){
    for (const ally of (p.playArea.allies || [])){
      const ad = MC.cardDef(ally.defCode);
      if (!ad || !ad.onMinionEnterDamage) continue;
      const spec = ad.onMinionEnterDamage;
      if (spec.counter && (ally.counters || 0) <= 0) continue;   // 카운터 없으면 발동 불가 → 후보 제외
      (G._pendingMinionReactions = G._pendingMinionReactions || []).push({
        allyUid: ally.uid, minionUid: minion.uid, amount: spec.amount, counter: spec.counter,
        vfx: (ad.vfx && ad.vfx.reaction) || null });
    }
  }
  // 태스크마스터 훈련소(04108): 전장에 있으면 하수인이 등장할 때 강인(tough) 상태 부여
  if ((G.sideSchemes || []).some(s => s.defCode === '04108')){
    MC.setStatus(G, minion, 'tough', true);
    MC.log(G, MC.nameOf(minion) + ' — 태스크마스터 훈련소: 강인(tough) 부여');
  }
}
MC.minionEnteredPlay = minionEnteredPlay;

/* 하수인 등장 반응 선택 큐 flush — 다음 유효 반응 1건을 revealChoice(발동/넘김)로 물어봄.
   flushThreatChoice/flushEachChoice와 동일 패턴. pending 세우면 true. resolveRevealChoice·dispatch·빌런큐에서 체인 호출. */
function flushMinionReactions(G){
  const q = G._pendingMinionReactions;
  if (!q || !q.length){ G._pendingMinionReactions = null; return false; }
  while (q.length){
    const r = q.shift();
    const ally = MC.findByUid(G, r.allyUid);
    const minion = MC.findByUid(G, r.minionUid);
    if (!ally || !minion || minion.hp <= 0) continue;               // 하수인 이미 처치됨 → 스킵
    if (r.counter && (ally.counters || 0) <= 0) continue;           // 카운터 소진됨 → 스킵
    const owner = G.players.find(p => (p.playArea.allies || []).some(a => a.uid === ally.uid));
    if (!owner || owner.eliminated) continue;
    G.pending = { kind:'revealChoice', player: owner.uid, selfUid: ally.uid,
      prompt: MC.nameOf(ally) + ' — 반응: ' + MC.nameOf(minion) + '에게 ' + r.amount + ' 피해를 줄까요?' +
              (r.counter ? ' (' + r.counter + ' 카운터 ' + (ally.counters || 0) + '개)' : ''),
      options: [
        { key:'fire', label: r.amount + ' 피해 발동' + (r.counter ? ' (' + r.counter + ' 1 소진)' : ''),
          effects:[{ fx:'minionReactionDamage', allyUid: ally.uid, minionUid: minion.uid, amount: r.amount, counter: r.counter, vfx: r.vfx }] },
        { key:'skip', label:'넘김' }
      ] };
    MC.log(G, MC.nameOf(ally) + ' 등장 반응 — ' + owner.uid + ' 선택 대기');
    return true;
  }
  G._pendingMinionReactions = null;
  return false;
}
MC.flushMinionReactions = flushMinionReactions;

function onPlayerDefeated(G, pl){
  pl.eliminated = true;
  MC.log(G, pl.uid + ' 탈락');
  if (G.players.every(p => p.eliminated)) MC.setGameOver(G, 'loss', '전원 탈락', 'heroDefeat');
}

/* 수호: 교전 중인 수호 하수인이 있으면 빌런 공격/저지 불가 */
function hasGuardEngaged(G, pl){
  return pl.engagedMinions.some(m => m.guard && m.hp > 0);
}
/* 순찰(Patrol): 교전 중이면 메인 스킴에서 위협 제거 불가 (가드=빌런 공격 불가와 구분) */
function hasPatrolEngaged(G, pl){
  return pl.engagedMinions.some(m => m.patrol && m.hp > 0);
}
/* 교전 중 저지 불가(whileEngagedCannotThwart): 이 필드를 가진 하수인이 교전 중이면 그 플레이어는 저지(basic thwart) 불가.
   바론 제모(03028) 등. 순찰(Patrol=메인만)과 달리 모든 스킴 저지 차단. 범용 데이터 필드. */
function hasCannotThwartEngaged(G, pl){
  return pl.engagedMinions.some(m => {
    if (m.hp <= 0) return false;
    const d = MC.cardDef(m.defCode);
    return (m.whileEngagedCannotThwart || (d && d.whileEngagedCannotThwart));
  });
}
/* 위기(Crisis): 전장에 crisis 아이콘 사이드 스킴이 하나라도 있으면 메인 스킴 위협 제거 불가.
   군중 통제(01108) 등. 범용 — 저지/카드 능력 모두 이 헬퍼로 판정. */
function hasCrisisScheme(G){
  return (G.sideSchemes || []).some(s => {
    const d = MC.cardDef(s.defCode);
    return d && d.crisis && s.threat > 0;
  });
}

/* 플레이어가 특정 트레잇을 보유하는지 판정. 신분(영웅/알터에고) 트레잇 +
   플레이 영역 카드가 부여하는 트레잇(cardDef.grantsTrait). 범용 — Aerial/Armor 등. */
function playerHasTrait(G, pl, trait){
  const t = String(trait).toLowerCase();
  // 신분 트레잇 (현재 폼)
  const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
  const fdef = MC.cardDef(faceCode);
  if (fdef && (fdef.traits||[]).some(x => String(x).toLowerCase() === t)) return true;
  // 플레이 영역 카드가 부여하는 트레잇 (grantsTrait: 'aerial' | ['aerial', ...])
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const g = MC.cardDef(c.defCode).grantsTrait;
      if (!g) continue;
      const list = Array.isArray(g) ? g : [g];
      if (list.some(x => String(x).toLowerCase() === t)) return true;
    }
  }
  // 일시적 트레잇 (로켓 부츠 등 — 이번 페이즈 동안 부여, 페이즈 종료 시 리셋)
  if (pl.tempTraits && pl.tempTraits.some(x => String(x).toLowerCase() === t)) return true;
  return false;
}

/* ── condCheck: 조건 판정 단일 창구 ── */
function condCheck(G, cond, ctx){
  if (!cond) return true;
  const r = condCheckRaw(G, cond, ctx);
  return cond.negate ? !r : r;   // 범용 반전 — 어떤 조건이든 negate:true로 뒤집어 재사용
}
function condCheckRaw(G, cond, ctx){
  const pl = ctx && ctx.player;
  switch (cond.type){
    case 'isHeroForm':      return pl && pl.form === 'hero';
    case 'isAlterEgoForm':  return pl && pl.form !== 'hero';
    case 'identityReady':   return pl && !pl.exhausted;   // 신분(히어로/알터에고)이 준비 상태 — 소진 비용 지불 가능 여부
    case 'isAlterEgoForm':  return pl && pl.form === 'alter-ego';
    case 'justBasicAttacked': return pl && !!pl.justBasicAttacked;   // 방금 기본 공격함 (원투 펀치)
    case 'justDefeatedEnemyByAttack': return pl && !!pl.justDefeatedEnemyByAttack;   // 방금 공격으로 적 처치 (추적하라!)
    case 'justDefeatedMinionByHero': return pl && !!pl.justDefeatedMinionByHero;   // 방금 히어로 본인이 하수인 처치 (심문실)
    case 'minionJustEntered': return !!G.minionJustEntered;   // 방금 하수인이 전장에 등장 (호크아이)
    case 'minionPlaced':    return !!(ctx && ctx._minionPlaced);   // 직전 효과로 하수인 배치 성공 (아홉 왕국의 수호자 → 순차)
    case 'discardHadTrait': return !!(ctx && ctx._discardHadTrait);   // 직전 discardTopDeck에서 지정 아이콘(thwart/attack) 카드를 버렸는지 (모방 04105)
    case 'hasReadyWeapon':  return pl && (pl.playArea.upgrades || []).some(c => !c.exhausted && ((MC.cardDef(c.defCode).traits) || []).includes('weapon'));   // 준비된 무기 업그레이드 존재 (Mean Swing)
    case 'justDefended': return pl && !!pl.justDefendedAgainst;   // 방금 히어로가 방어함 (카운터 펀치)
    case 'hasStatus':       return ctx.target && ctx.target.status && ctx.target.status[cond.status] > 0;
    case 'threatGTE':       return MC.resolveScheme(G, cond.scheme||'main').threat >= cond.value;
    case 'minionsInPlay':   return G.players.some(p => p.engagedMinions.length > 0);
    case 'playerCountGTE':  return G.players.length >= cond.value;
    case 'hasTrait':        return pl && playerHasTrait(G, pl, cond.trait);
    case 'isIdentity': {    // 현재 신분(폼) 카드가 특정 코드인지 (캐롤 댄버스 등 특정 영웅 판정)
      if (!pl) return false;
      const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
      const codes = Array.isArray(cond.code) ? cond.code : [cond.code];
      return codes.includes(faceCode);
    }
    case 'notIdentity': {   // isIdentity의 부정 (상호배타 조건부 효과용)
      if (!pl) return true;
      const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
      const codes = Array.isArray(cond.code) ? cond.code : [cond.code];
      return !codes.includes(faceCode);
    }
    case 'paidWith': {      // 결제에 특정 자원 아이콘을 썼는지 (와일드도 충족) — 키커 효과용
      const need = cond.resource;
      const have = (ctx.paidIcons && ((ctx.paidIcons[need]||0) + (ctx.paidIcons.wild||0))) || 0;
      return have >= (cond.count || 1);
    }
    case 'hasCardInPlay': {  // 특정 카드(slug)가 플레이 영역에 존재(소진 무관) — 방패 던지기(방패 반환) 조건 등
      if (!pl) return false;
      for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
        if (arr.some(c => c.defCode === cond.card)) return true;
      return false;
    }
    case 'hasReadyCard': {  // 특정 카드(slug)가 플레이 영역에 준비(비소진) 상태로 존재 — 방패 막기 조건 등
      if (!pl) return false;
      for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
        if (arr.some(c => c.defCode === cond.card && !c.exhausted)) return true;
      return false;
    }
    case 'targetStatus': {  // 대상(villain/self/target)이 특정 상태(tough/confused/stunned)인지 — 범용 재사용
      const t = cond.target === 'villain' ? G.villain
              : cond.target === 'self' ? pl
              : ctx.target;
      return !!(t && t.status && (t.status[cond.status] || 0) > 0);
    }
    case 'villainHasWeapon':   // 빌런에 Weapon 부착물이 있는지 (무기 마스터 급증 조건)
      return !!(G.villain && (G.villain.attachments || []).some(a => (MC.cardDef(a.defCode).traits || []).includes('weapon')));
    case 'villainHasTrait':    // 빌런이 특정 특성을 (흡수 포함) 갖는지 — 어보밍맨 환경 특성 분기. trait 하나 또는 배열(any)
      { const need = Array.isArray(cond.trait) ? cond.trait : [cond.trait];
        const has = MC.villainTraitsOf(G);
        return need.some(t => has.includes(String(t).toLowerCase())); }
    case 'delayGTE':           // 메인 스킴 지연(delay) 카운터가 기준 이상 — 어보밍맨 배반/환경 delay 스케일
      return ((G.mainScheme && G.mainScheme.delayCounters) || 0) >= (cond.amount || 0);
    case 'healedNone':      return (G._lastHealDone || 0) === 0;   // 직전 healVillain이 하나도 회복 못함 (음파 조작 급증)
    case 'minionsAttacked': return (G._lastMinionAttacks || 0) > 0;   // 직전 minionsAttack이 공격을 1회 이상 개시함 (혼돈의 지배 분기 연출)
    case 'schemeInPlay':    // 특정 사이드 스킴(slug)이 전장에 위협을 남긴 채 존재하는지 (폭발!=폭탄 위협 연계)
      return (G.sideSchemes || []).some(s => s.defCode === cond.slug && (s.threat || 0) > 0);
    case 'enemyInPlay':     // 특정 하수인/빌런(slug)이 전장에 살아있는지 (급강하 습격=벌처 전장 시 급증)
      return G.players.some(p => (p.engagedMinions || []).some(m => (m.defCode || m.code) === cond.slug && m.hp > 0))
          || (G.villain && (G.villain.defCode || G.villain.code) === cond.slug && G.villain.hp > 0);
    case 'treasonDiscardedNone': return (G._treasonDiscarded || 0) === 0;   // 욘-로그의 반역: 버린 자원 카드가 없으면 급증
    case 'discardedUpgradeOrSupportNone': return G._discardedUpgradeOrSupport === false;   // Caught Off Guard: 버린 업그레이드/지원 없으면 급증
    case 'nemesisMinionNotEntered': return G._nemesisMinionEntered === false;   // Shadow of the Past: 넴시스 하수인 미등장 시 급증
    case 'noSideSchemesInPlay': return !(G.sideSchemes && G.sideSchemes.length);   // Masterplan: 전장에 사이드 스킴 없을 때
    case 'anySideSchemeInPlay': return !!(G.sideSchemes && G.sideSchemes.length);   // Masterplan: 전장에 사이드 스킴 있을 때
    default: throw new Error('[condCheck] 미등록 조건: ' + cond.type);
  }
}

/* 보복 집계 인덱스 (passiveStatMod 대칭): 한 캐릭터의 총 보복을 모든 소스에서 합산.
   ① 인스턴스 retaliate (적 기본 + attachStats.retaliate가 attachTo로 적용된 분)
   ② 히어로 신분 인쇄 보복 (블랙팬서 등, 히어로 폼만)
   ③ 히어로 비부착 업그레이드/서포트의 grantsRetaliate (캡틴아메리카의 방패 등)
   새 보복 소스는 이 함수에만 추가하면 트리거·표시 전체에 일괄 적용됨. */
function passiveRetaliate(G, ch){
  if (!ch) return 0;
  let r = ch.retaliate || 0;
  if (ch.form === 'hero' && ch.heroCode){
    const fdef = MC.cardDef(ch.heroCode);
    if (fdef && fdef.retaliate) r += fdef.retaliate;
  }
  if (ch.form === 'hero' && ch.playArea){
    for (const arr of [ch.playArea.upgrades, ch.playArea.supports])
      for (const c of arr){ const cd = MC.cardDef(c.defCode); if (cd && cd.grantsRetaliate) r += cd.grantsRetaliate; }
  }
  return r;
}
MC.passiveRetaliate = passiveRetaliate;

/* 보복(Retaliate): 캐릭터가 공격받으면 발동 — 공식 룰: 트리거는 "공격받음"이라 피해량 무관
   (방어로 0피해·강인 흡수여도 발동). 단 그 공격에서 살아남아야(hp>0) 보복 피해를 준다.
   보복 피해는 재보복하지 않음(isRetaliate). 공격 해소부(applyDamage/resolveDefense 등)에서 호출. */
function triggerRetaliate(G, attacked, attacker){
  if (!attacked || !attacker || attacker.hp === undefined) return;
  if (attacked.hp <= 0) return;                      // 공격에서 살아남아야 함
  const retal = passiveRetaliate(G, attacked);       // 집계 인덱스로 총 보복 산출
  if (retal <= 0) return;
  // 연출 힌트 (히어로 신분 보복 / 부착물 부여 보복 / 업그레이드 부여 보복)
  if (attacked.form === 'hero' && attacked.heroCode){
    const fdef = MC.cardDef(attacked.heroCode);
    const rvfx = fdef && fdef.vfx && fdef.vfx.retaliate;
    if (rvfx) G.fxRetaliate = { targetUid: attacker.uid, heroUid: attacked.uid, vfx: rvfx };
  }
  if (!G.fxRetaliate && attacked.form === 'hero' && attacked.playArea){  // 업그레이드 부여 보복(캡틴아메리카의 방패)
    for (const arr of [attacked.playArea.upgrades, attacked.playArea.supports]){
      const c = arr.find(x => { const cd = MC.cardDef(x.defCode); return cd && cd.grantsRetaliate && cd.vfx && cd.vfx.retaliate; });
      if (c){ const cd = MC.cardDef(c.defCode); G.fxRetaliate = { targetUid: attacker.uid, heroUid: attacked.uid, vfx: cd.vfx.retaliate, defCode: c.defCode }; break; }
    }
  }
  if (!G.fxRetaliate && attacked.attachments){
    for (const att of attacked.attachments){
      const adef = MC.cardDef(att.defCode);
      const grantsRetal = adef && ((adef.attachStats && adef.attachStats.retaliate) || adef.retaliate);
      const rvfx = grantsRetal && adef.vfx && adef.vfx.retaliate;
      if (rvfx){ G.fxRetaliate = { targetUid: attacker.uid, heroUid: attacked.uid, vfx: rvfx, defCode: att.defCode }; break; }
    }
  }
  MC.log(G, MC.nameOf(attacked) + ' 보복 — ' + MC.nameOf(attacker) + '에게 ' + retal + ' 피해');
  applyDamage(G, attacker, retal, { source: attacked, isRetaliate: true });
}
MC.triggerRetaliate = triggerRetaliate;

MC.applyDamage = applyDamage; MC.healTarget = healTarget; MC.setStatus = setStatus;MC.onDefeated = onDefeated; MC.advanceVillainStage = advanceVillainStage;
MC.onPlayerDefeated = onPlayerDefeated; MC.condCheck = condCheck;
MC.hasGuardEngaged = hasGuardEngaged; MC.hasPatrolEngaged = hasPatrolEngaged; MC.hasCannotThwartEngaged = hasCannotThwartEngaged; MC.hasCrisisScheme = hasCrisisScheme; MC.playerHasTrait = playerHasTrait;

/* 동료(ally 인스턴스)가 특정 트레잇을 갖는지 — 인쇄 트레잇 + 부착물이 부여하는 트레잇(grantsTrait) 집계.
   명예 어벤져(Avenger 부여) 등. 인플레이 동료 트레잇 판정은 반드시 이 함수로(직접 cardDef.traits 조회 금지). */
function allyHasTrait(G, ally, trait){
  const t = String(trait).toLowerCase();
  const def = MC.cardDef(ally.defCode);
  if (def && (def.traits || []).some(x => String(x).toLowerCase() === t)) return true;
  for (const at of (ally.attachments || [])){
    const g = MC.cardDef(at.defCode).grantsTrait;
    if (!g) continue;
    const list = Array.isArray(g) ? g : [g];
    if (list.some(x => String(x).toLowerCase() === t)) return true;
  }
  return false;
}
MC.allyHasTrait = allyHasTrait;

/* ── 빌런 특성 집계 (환경 특성 흡수) ── 어보밍맨 전용 시스템.
   빌런 인쇄 트레잇 + (gainsEnvironmentTraits면) 전장 환경 트레잇 + grantsElementTraits 사이드스킴 + 부착물 트레잇.
   어보밍맨의 특성별 분기(traitBranch)·표시(UI)는 반드시 이 함수로 판정. 소문자 통일. */
function villainTraitsOf(G){
  const v = G.villain; if (!v) return [];
  const def = MC.cardDef(v.defCode);
  const traits = (def.traits || []).map(t => String(t).toLowerCase());
  const add = t => { const lt = String(t).toLowerCase(); if (!traits.includes(lt)) traits.push(lt); };
  if (def.gainsEnvironmentTraits){
    for (const e of (G.environments || []))
      for (const t of (MC.cardDef(e.defCode).traits || [])) add(t);
    for (const s of (G.sideSchemes || [])){
      const sd = MC.cardDef(s.defCode);
      if (sd.grantsElementTraits) for (const t of sd.grantsElementTraits) add(t);
    }
  }
  for (const a of (v.attachments || []))
    for (const t of (MC.cardDef(a.defCode).traits || [])) add(t);
  return traits;
}
MC.villainTraitsOf = villainTraitsOf;

/* ★ 빌런 활성화 후 특성 분기 반응 (범용 인덱스) — 어보밍맨 III(04078) Forced Response.
   빌런이 공격/스킴으로 활성화한 후, 흡수한 특성에 따라 데이터 분기(villainActivateResponse)를 발동.
   각 분기는 독립(공식: Ice/Stone과 Metal/Wood 조건이 별개로 체크됨 — 두 특성 동시 보유 시 둘 다 발동).
   값·특성·타입만 다른 변형이므로 데이터로 표현. 다른 빌런의 "활성화 후 특성별 효과"에 재사용 가능. */
function villainActivateResponse(G, pl){
  const v = G.villain; if (!v || !pl) return;
  const resp = MC.cardDef(v.defCode).villainActivateResponse;
  if (!resp) return;
  const traits = villainTraitsOf(G);
  for (const b of (Array.isArray(resp) ? resp : [resp])){
    if (!(b.traits || []).some(t => traits.includes(String(t).toLowerCase()))) continue;
    if (b.type === 'threat'){
      MC.placeThreat(G, b.scheme || 'main', b.amount || 1);
      MC.log(G, MC.nameOf(v) + ' — 활성화 반응(' + b.traits.join('/') + '): 메인 스킴 위협 +' + (b.amount || 1));
    } else if (b.type === 'damage'){
      MC.applyDamage(G, pl, b.amount || 1, { source: v, indirect: true });
      MC.log(G, MC.nameOf(v) + ' — 활성화 반응(' + b.traits.join('/') + '): ' + pl.uid + ' 간접 피해 ' + (b.amount || 1));
    }
  }
}
MC.villainActivateResponse = villainActivateResponse;
