/* ═══════════════════════════════════════════════════════════════
   mc_4_players.js — 샤드 4/7 : 플레이어 모델 (1~4인 · 1급 개념)
   각 플레이어: 영웅/알터에고 flip · 손패 · 덱 · 자원 결제 · 플레이 영역
   ※ 4인 지원은 여기서 태어난다. G.hero 같은 단수 모델 금지.
   ═══════════════════════════════════════════════════════════════ */

/* 플레이어 생성. heroCode = 양면 카드의 영웅면 코드 ('01001a' 등) */
function makePlayer(G, seatIdx, heroCode, deckCodes){
  const heroCard = MC.cardDef(heroCode);
  if (!heroCard) throw new Error('[makePlayer] 미등록 영웅: ' + heroCode);
  const aeCard = MC.cardDef(heroCard.backLink);
  const pl = {
    uid: 'P' + seatIdx,
    seat: seatIdx,                 // 0..3
    heroCode, aeCode: heroCard.backLink,
    form: 'alter-ego',             // 게임은 알터에고면으로 시작
    hp: heroCard.hp, maxHp: heroCard.hp,
    exhausted: false,
    status: { stunned:0, confused:0, tough:0 },
    deck: MC.buildDeck(G, deckCodes), // 인스턴스 배열 (셔플은 셋업에서)
    hand: [], discard: [],
    playArea: { allies: [], supports: [], upgrades: [] },
    engagedMinions: [],
    obligationsOut: [],
    nemesisSetAside: [],           // 넴시스 세트 셋어사이드 카드 인스턴스 (Shadow of the Past가 투입)
    usedHeroAbilityThisRound: false,
    usedResourceAbilityThisRound: false,
    usedIdentityActionThisRound: {},   // 폼별(hero/alter-ego) 각각 라운드 1회 추적
    usedThreatPreventThisRound: false,
    formChangedThisRound: false,
    tempTraits: [],
    isPlayer: true, kind: 'identity',
  };
  return pl;
}

function heroFace(G, pl){ return MC.cardDef(pl.form === 'hero' ? pl.heroCode : pl.aeCode); }

/* 최대 HP 재계산: 기본 HP + 플레이 영역 카드의 hpBonus 합 (MK.5 아머 등).
   설치/제거 시 호출 → maxHp 갱신 + 증감 델타만큼 현재 HP 조정 (코어 룰: HP 토큰 증감). */
function recomputeMaxHp(G, pl){
  const face = MC.cardDef(pl.heroCode);   // HP는 앞뒷면 공통(기본 신분 기준)
  let bonus = 0;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const b = MC.cardDef(c.defCode).hpBonus;
      if (b) bonus += b;
    }
  }
  const newMax = (face.hp || 0) + bonus;
  const delta = newMax - pl.maxHp;
  pl.maxHp = newMax;
  if (delta > 0) pl.hp += delta;               // 최대 증가분만큼 현재도 증가
  if (pl.hp > pl.maxHp) pl.hp = pl.maxHp;       // 최대 감소 시 현재 상한 클램프
  if (pl.hp < 0) pl.hp = 0;
}
MC.recomputeMaxHp = recomputeMaxHp;
function statOf(G, pl, stat){ // attack/thwart/defense/recover/handSize + 플레이 영역 카드의 패시브 수정치
  const face = heroFace(G, pl);
  let base = face[stat] !== undefined ? face[stat] : 0;
  base += passiveStatMod(G, pl, stat);
  // 임시 스탯 버프 (선두에서 이끌기 등 — 페이즈 종료까지 히어로 +1). pl.tempStatBonus 합산.
  if (pl.tempStatBonus && pl.tempStatBonus[stat]) base += pl.tempStatBonus[stat];
  // 라운드 지속 스탯 버프 (사기 증진 등 — 라운드 종료까지 +1, 빌런 페이즈 DEF 포함). pl.roundStatBonus 합산.
  if (pl.roundStatBonus && pl.roundStatBonus[stat]) base += pl.roundStatBonus[stat];
  // 신분 동적 손패 (아이언맨: Tech 업그레이드 1개당 +1, 상한 max)
  if (stat === 'handSize'){
    const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
    const dh = MC.cardDef(faceCode) && MC.cardDef(faceCode).dynamicHandSize;
    if (dh && dh.perTrait){
      let cnt = 0;
      for (const c of pl.playArea.upgrades){
        const cdef = MC.cardDef(c.defCode);
        if (dh.cardType && cdef.type !== dh.cardType) continue;
        if ((cdef.traits || []).includes(dh.perTrait)) cnt++;
      }
      base += cnt;
      if (dh.max !== undefined && base > dh.max) base = dh.max;
    }
  }
  return base;
}

/* 플레이 영역 카드(support/upgrade)가 부여하는 지속 스탯 수정치 합산.
   cardDef.statMod = { stat:'defense', amount:1, cond?, amountIf?:{cond, amount} }
   조건부: amountIf가 있고 cond 충족 시 그 값으로 대체(헬멧: Aerial이면 +2 대신). 범용. */
function passiveStatMod(G, pl, stat){
  let total = 0;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr){
      const sm = MC.cardDef(c.defCode).statMod;
      if (!sm) continue;
      const mods = Array.isArray(sm) ? sm : [sm];
      for (const m of mods){
        if (m.stat !== stat) continue;
        // 기본 조건(cond) 불충족이면 스킵
        if (m.cond && !MC.condCheck(G, m.cond, { player: pl })) continue;
        // 조건부 대체값(amountIf): 충족 시 그 값, 아니면 기본 amount
        if (m.amountIf && MC.condCheck(G, m.amountIf.cond, { player: pl })) total += m.amountIf.amount;
        else total += (m.amount || 0);
      }
    }
  }
  return total;
}

/* 영웅 ↔ 알터에고 flip — 라운드당 1회 (코어 룰) */
function flipForm(G, pl, opt){
  opt = opt || {};
  if (!opt.force && pl.formChangedThisRound) throw new Error('[flipForm] 이번 라운드에 이미 형태 변경');
  // 신분 부착(All Tied Up): 형태 변경 불가 (force 포함 — 공식 "cannot change form").
  if (identityAttachHas(G, pl, 'identityCannotFlip'))
    throw new Error('[flipForm] ' + MC.nameOf(pl) + ' — 신분에 부착된 카드로 형태 변경 불가');
  // 왕좌 찬탈(01156) 등: 특정 사이드 스킴이 전장에 있는 동안 히어로→알터에고 전환 봉쇄.
  //   force 전환(이중인격 등)도 막는다(공식: "cannot flip"). 알터에고→히어로 복귀는 허용.
  if (pl.form === 'hero'){
    const blocker = (G.sideSchemes || []).find(s => {
      const d = MC.cardDef(s.defCode);
      return d && d.blocksAlterEgoFlip;
    });
    if (blocker) throw new Error('[flipForm] ' + MC.nameOf(blocker) + ' — 알터에고 형태로 전환 불가');
  }
  if (!opt.force) pl.formChangedThisRound = true;   // 강제 전환(이중인격)은 라운드 제한 미소모
  pl.form = (pl.form === 'hero') ? 'alter-ego' : 'hero';
  MC.log(G, pl.uid + ' → ' + MC.T(pl.form) + ' 형태');
  MC.fireHook(G, 'onFormChange', { player: pl });
  // 업그레이드/서포트 onFormChangeDiscard (끝없는 분노: 폼 변경 후 버림)
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    for (const c of arr.slice()){
      if (MC.cardDef(c.defCode).onFormChangeDiscard){
        const i = arr.indexOf(c); if (i >= 0) arr.splice(i, 1);
        MC.moveToDiscard(G, pl, c, {});
        MC.log(G, MC.nameOf(c) + ' — 폼 변경으로 버림');
      }
    }
  }
  // 신분(identity) 카드 자체의 onFormChange 능력 (She-Hulk 히어로 파워 등) — 새 폼 기준
  const faceCode = pl.form === 'hero' ? pl.heroCode : pl.aeCode;
  const fdef = MC.cardDef(faceCode);
  if (fdef && fdef.onFormChange && MC.HANDLERS[fdef.onFormChange]){
    MC.HANDLERS[fdef.onFormChange](G, { self: fdef, player: pl, hook: 'onFormChange', newForm: pl.form });
  }
  // 태스크마스터: 히어로 폼으로 전환한 후 빌런 강제 반응 (조우덱 top 버리고 부스트 아이콘만큼 피해). 데이터 기반.
  if (pl.form === 'hero' && G.villain){
    const vd = MC.cardDef(G.villain.defCode);
    if (vd && vd.onHeroFormResponse) MC.runEffectList(G, vd.onHeroFormResponse, { player: pl });
  }
}

/* ── 자원 결제: 요소(element) 모델 ──
   element = { kind:'hand', uid }                 손패 카드를 자원으로 버림
           | { kind:'ability', id:'scientist' }   신분 자원 능력 (라운드 제한 등)
   특수 규칙:
   - doubleForAspect: 대상 카드 성향 일치 시 이 카드의 자원 생성량 2배 (예: 수호의 힘)
   - 신분 자원 능력은 RESOURCE_ABILITIES 레지스트리로 정의 */
const RESOURCE_ABILITIES = {
  scientist: { name:'과학자', form:'alter-ego', icons:{ mental:1 }, oncePerRound:true },
};

function resourceIconsOf(inst){
  const r = inst.resources || {};
  return { physical:r.physical||0, mental:r.mental||0, energy:r.energy||0, wild:r.wild||0 };
}
/* 요소 1개의 유효 아이콘 계산 (대상 카드 문맥 반영) */
function elementIcons(G, pl, el, targetCard){
  if (el.kind === 'hand'){
    const inst = pl.hand.find(c => c.uid === el.uid);
    if (!inst) throw new Error('[payment] 손패에 없음: ' + el.uid);
    const icons = resourceIconsOf(inst);
    const def = MC.cardDef(inst.defCode);
    if (def && def.doubleForAspect && targetCard && targetCard.aspect === def.doubleForAspect)
      for (const k in icons) icons[k] *= 2;
    return { icons, inst };
  }
  if (el.kind === 'ability'){
    const ab = RESOURCE_ABILITIES[el.id];
    if (!ab) throw new Error('[payment] 미등록 자원 능력: ' + el.id);
    const face = MC.heroFace(G, pl);
    const fdef = MC.cardDef(pl.form === 'hero' ? pl.heroCode : pl.aeCode);
    if (!fdef || fdef.resourceAbility !== el.id) throw new Error('[payment] 현재 신분에 없는 능력: ' + ab.name);
    if (ab.form && pl.form !== ab.form) throw new Error('[payment] ' + ab.name + '은(는) ' + MC.T(ab.form) + ' 전용');
    if (ab.oncePerRound && pl.usedResourceAbilityThisRound) throw new Error('[payment] ' + ab.name + ' 이번 라운드 사용됨');
    return { icons: Object.assign({ physical:0, mental:0, energy:0, wild:0 }, ab.icons), ability: ab };
  }
  if (el.kind === 'card'){
    // 카드 자원 생성 (웹 슈터 등): 플레이 영역의 카드가 resourceGenerator로 자원을 냄.
    // 소진/카운터 조건은 executePayment에서 실제 차감. 여기선 아이콘만 계산(무변이).
    let inst = null;
    for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
      { const c = arr.find(x => x.uid === el.uid); if (c){ inst = c; break; } }
    if (!inst) throw new Error('[payment] 플레이 영역에 없음: ' + el.uid);
    const def = MC.cardDef(inst.defCode);
    const rg = def.resourceGenerator;
    if (!rg) throw new Error('[payment] 자원 생성 능력 없음: ' + inst.defCode);
    if (rg.form && pl.form !== rg.form) throw new Error('[payment] ' + MC.T(rg.form) + ' 전용 자원');
    if (rg.exhaust && inst.exhausted) throw new Error('[payment] 이미 소진됨: ' + MC.nameOf(inst));
    if (rg.counter && (inst.counters||0) < rg.counter) throw new Error('[payment] 카운터 부족: ' + MC.nameOf(inst));
    // 동적 자원: 버림 더미 맨 위 카드의 자원 (페퍼 포츠). 버림 더미 비면 자원 없음.
    if (rg.fromDiscardTop){
      const top = pl.discard[pl.discard.length - 1];
      if (!top) throw new Error('[payment] 버림 더미가 비어 자원 생성 불가: ' + MC.nameOf(inst));
      const topIcons = MC.resourceIconsOf(top);
      return { icons: Object.assign({ physical:0, mental:0, energy:0, wild:0 }, topIcons), gen: inst };
    }
    return { icons: Object.assign({ physical:0, mental:0, energy:0, wild:0 }, rg.icons), gen: inst };
  }
  throw new Error('[payment] 미지원 요소: ' + el.kind);
}
/* 검증 전용 — 무변이. 합계/아이콘 반환 */
function computePayment(G, pl, elements, targetCard){
  let sum = 0;
  const icons = { physical:0, mental:0, energy:0, wild:0 };
  const seen = new Set();
  for (const el of elements){
    const key = el.kind + ':' + (el.uid || el.id);
    if (seen.has(key)) throw new Error('[payment] 요소 중복: ' + key);
    seen.add(key);
    const { icons: ic } = elementIcons(G, pl, el, targetCard);
    for (const k in icons){ icons[k] += ic[k]; sum += ic[k]; }
  }
  return { sum, icons };
}
function validatePayment(G, pl, elements, cost, targetCard, requires){
  const { sum, icons } = computePayment(G, pl, elements, targetCard);
  if (sum < cost) throw new Error('[payment] 자원 부족: ' + sum + '/' + cost);
  if (requires){
    const have = (icons[requires.type]||0) + icons.wild;
    if (have < requires.count) throw new Error('[payment] 자원 유형 불충족: ' + MC.T(requires.type));
  }
  return { sum, icons };
}
/* 실행 — 검증 후에만 호출 */
function executePayment(G, pl, elements){
  for (const el of elements){
    if (el.kind === 'hand'){
      MC.moveToDiscard(G, pl, MC.fromHand(pl, el.uid), { asResource:true });
    } else if (el.kind === 'ability'){
      const ab = RESOURCE_ABILITIES[el.id];
      if (ab.oncePerRound) pl.usedResourceAbilityThisRound = true;
      MC.log(G, pl.uid + ' 자원 능력: ' + ab.name);
    } else if (el.kind === 'card'){
      // 카드 자원 생성: 소진 + 카운터 차감. 카운터가 0이 되면 카드 버림.
      let inst = null, srcArr = null;
      for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies])
        { const c = arr.find(x => x.uid === el.uid); if (c){ inst = c; srcArr = arr; break; } }
      if (!inst) throw new Error('[payment] 자원 생성 카드 없음: ' + el.uid);
      const rg = MC.cardDef(inst.defCode).resourceGenerator;
      if (rg.exhaust) inst.exhausted = true;
      if (rg.discard){   // 리소스풀: 버림으로 자원 생성 (자기 자신을 버림 더미로)
        if (inst.attachedTo) MC.detachFrom(G, inst);
        const i = srcArr.indexOf(inst); if (i >= 0) srcArr.splice(i, 1);
        MC.moveToDiscard(G, pl, inst, {});
        MC.log(G, MC.nameOf(inst) + ' — 버림으로 자원 생성');
      }
      if (rg.counter){
        inst.counters = (inst.counters||0) - rg.counter;
        MC.log(G, MC.nameOf(inst) + ' 자원 생성 (카운터 ' + inst.counters + ' 남음)');
        if (inst.counters <= 0){
          // 부착물이면 해제 후 버림 / 아니면 영역에서 제거 후 버림
          if (inst.attachedTo) MC.detachFrom(G, inst);
          const i = srcArr.indexOf(inst); if (i>=0) srcArr.splice(i,1);
          MC.moveToDiscard(G, pl, inst, {});
          MC.log(G, MC.nameOf(inst) + ' — 카운터 소진, 버림');
        }
      } else {
        MC.log(G, MC.nameOf(inst) + ' 자원 생성');
      }
    }
  }
}
/* (구형 호환) paymentTotal: 손패 인스턴스 배열 합계 */
function paymentTotal(insts){
  let sum = 0, icons = { physical:0, mental:0, energy:0, wild:0 };
  for (const i of insts){
    const r = resourceIconsOf(i);
    for (const k in icons){ icons[k] += r[k]; sum += r[k]; }
  }
  return { sum, icons };
}

/* 손패/덱 유틸 */
function drawCards(G, pl, n){
  for (let k=0;k<n;k++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); if (pl.deck.length===0) break; }
    pl.hand.push(pl.deck.pop());
  }
}
/* 공용 강제 버림 — 지정 카드들을 손패에서 버림 + VFX 힌트(G.fxForcedDiscard) 설정.
   헐크 격노(손패 전체) / 무작위 버림 / 브루스 배너 등 모든 강제 버림이 재사용. */
MC.forcedDiscard = function(G, pl, cards, opt){
  opt = opt || {};
  const codes = [];
  for (const c of cards){
    const i = pl.hand.indexOf(c);
    if (i >= 0){ pl.hand.splice(i, 1); MC.moveToDiscard(G, pl, c, {}); codes.push(c.defCode); }
  }
  if (codes.length){
    G.fxForcedDiscard = { playerUid: pl.uid, count: codes.length, cards: codes, reason: opt.reason || '', seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    MC.log(G, MC.nameOf(pl) + ' — 카드 ' + codes.length + '장 강제 버림' + (opt.reason ? ' (' + opt.reason + ')' : ''));
  }
  return codes.length;
};
function discardRandomFromHand(G, pl, n){
  const picked = [];
  for (let k=0;k<n && (pl.hand.length - picked.length) > 0;k++){
    const avail = pl.hand.filter(c => picked.indexOf(c) < 0);
    if (!avail.length) break;
    picked.push(avail[Math.floor(MC.rand(G) * avail.length)]);
  }
  MC.forcedDiscard(G, pl, picked, { reason: '무작위 버림' });
}
/* 플레이어 페이즈 종료 정리: 손패 보충 + 전체 준비 (코어: 버림선택→보충→준비) */
function drawUpToHandSize(G, pl){
  const hs = MC.statOf(G, pl, 'handSize') || 5;
  if (pl.hand.length < hs) drawCards(G, pl, hs - pl.hand.length);
}
function readyAllFor(G, pl){
  // 신분 부착(All Tied Up)이 준비를 막으면 신분(exhausted)은 준비하지 않는다.
  if (!identityAttachHas(G, pl, 'identityCannotReady')) pl.exhausted = false;
  for (const arr of [pl.playArea.allies, pl.playArea.supports, pl.playArea.upgrades])
    for (const c of arr) c.exhausted = false;
}
/* 플레이어 신분에 부착된 카드 중 지정 플래그를 가진 것이 있는가 (All Tied Up 등). */
function identityAttachHas(G, pl, flag){
  for (const a of (pl.identityAttachments || [])){
    const d = MC.cardDef(a.defCode);
    if (d && d[flag]) return true;
  }
  return false;
}
MC.identityAttachHas = identityAttachHas;

/* 플레이어 덱 소진: 인카운터 1장 받은 뒤 버림 더미를 섞어 새 덱 (코어 룰) */
function onEmptyPlayerDeck(G, pl){
  MC.log(G, pl.uid + ' 덱 소진 → 리셔플 + 인카운터 카드 1장');
  pl.deck = MC.shuffle(G, pl.discard.splice(0));   // RRG: ① 버림 더미를 섞어 새 덱
  MC.dealEncounterTo(G, pl, 1);                     // RRG: ② 즉시 조우 카드 1장
}

/* 덱 맨 위 N장을 버림 더미로 (밀링) — 울트론의 분노 등 "덱 맨 위 카드를 버린다" 후속 효과.
   RRG: 밀 중 덱 소진 시 onEmptyPlayerDeck(인카운터+리셔플) 후 중단 — 새로 섞인 덱에선 밀지 않음. 실제 버린 수 반환. */
function discardTopOfDeck(G, pl, n){
  let done = 0;
  for (let i = 0; i < n; i++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); break; }
    pl.discard.push(pl.deck.pop());
    done++;
  }
  if (done) MC.log(G, pl.uid + ' 덱 맨 위 ' + done + '장 버림');
  return done;
}
MC.discardTopOfDeck = discardTopOfDeck;

MC.makePlayer = makePlayer;
MC.heroFace = heroFace; MC.statOf = statOf; MC.flipForm = flipForm;

/* 동료의 유효 스탯 계산 (attack/thwart) — 기본 스탯 + 카드 def의 dynamicStat 보너스.
   cardDef.dynamicStat = { stat:'thwart', per:'sideScheme' } 형태.
   per='sideScheme': 전장의 사이드 스킴 개수만큼 +1 (제시카 존스). 범용 확장 가능. */
function allyStatOf(G, ally, stat){
  let base = ally[stat] || 0;
  const def = MC.cardDef(ally.defCode);
  const ds = def && def.dynamicStat;
  if (ds && ds.stat === stat){
    if (ds.per === 'sideScheme') base += (G.sideSchemes || []).length;
    else if (ds.per === 'damageOnSelf') base += Math.max(0, (ally.maxHp || (def && def.hp) || 0) - (ally.hp || 0));   // 쉬헐크: 피해 토큰당 +1 ATK
  }
  // 임시 스탯 버프 (비전=페이즈 종료까지 +2 등). tempStatBonus[stat] 합산.
  if (ally.tempStatBonus && ally.tempStatBonus[stat]) base += ally.tempStatBonus[stat];
  // 라운드 지속 스탯 버프 (라운드 종료까지). roundStatBonus[stat] 합산.
  if (ally.roundStatBonus && ally.roundStatBonus[stat]) base += ally.roundStatBonus[stat];
  return base;
}
MC.allyStatOf = allyStatOf;

/* 플레이어의 동료 한도 계산 (기본 3 + 플레이 영역 카드의 allyLimitBonus 합산).
   트리스켈리온 등이 동료 한도를 늘림. */
function allyLimitOf(G, pl){
  let limit = 3;
  for (const arr of [pl.playArea.supports, pl.playArea.upgrades]){
    for (const c of arr){
      const def = MC.cardDef(c.defCode);
      if (def && def.allyLimitBonus){
        // 조건부 한도(어벤져스 타워): 당신의 모든 동료가 특정 특성을 가질 때만 보너스 적용.
        //   동료 0명이면 공허참(vacuously true)으로 적용.
        if (def.allyLimitCondAllTrait){
          const t = String(def.allyLimitCondAllTrait).toLowerCase();
          const allMatch = (pl.playArea.allies || []).every(a => MC.allyHasTrait(G, a, t));
          if (allMatch) limit += def.allyLimitBonus;
        } else {
          limit += def.allyLimitBonus;
        }
      }
    }
  }
  return limit;
}
MC.allyLimitOf = allyLimitOf;
MC.RESOURCE_ABILITIES = RESOURCE_ABILITIES;
MC.resourceIconsOf = resourceIconsOf; MC.paymentTotal = paymentTotal;
MC.elementIcons = elementIcons; MC.computePayment = computePayment;
/* payIconsSatisfied(icons, req) — 지불된 아이콘 집계(icons: {energy,mental,physical,wild,...})가
   요구(req: {energy:1,mental:1,physical:1})를 충족하는지. 부족분은 wild로 메움(유연 배정).
   소닉 붐 "자원 3종 지불" 등 다중 타입 요구 선택지 검증에 범용 사용. */
function payIconsSatisfied(icons, req){
  let wild = icons.wild || 0;
  for (const t in req){
    if (t === 'total') continue;   // 합계 요구는 아래에서 처리
    const have = icons[t] || 0;
    if (have >= req[t]) continue;
    const need = req[t] - have;
    if (wild >= need) wild -= need; else return false;
  }
  if (req.total){   // "아무 타입 N개" — 전체 아이콘 합계
    const sum = (icons.energy||0) + (icons.mental||0) + (icons.physical||0) + (icons.wild||0);
    if (sum < req.total) return false;
  }
  return true;
}
MC.payIconsSatisfied = payIconsSatisfied;
/* canPayDifferentTypes(icons, n) — 지불 아이콘 집계가 서로 다른 타입 n개를 구성할 수 있는가.
   (레드 대거 "서로 다른 종류의 자원 2개"). Wild는 어느 타입으로든 배정 가능. */
function canPayDifferentTypes(icons, n){
  let distinct = 0;
  for (const t of ['physical','mental','energy']) if ((icons[t]||0) >= 1) distinct++;
  const wild = icons.wild || 0;
  return (distinct + wild) >= n;   // 서로 다른 비-와일드 타입 + 와일드(각각 다른 타입 대체)
}
MC.canPayDifferentTypes = canPayDifferentTypes;
MC.validatePayment = validatePayment; MC.executePayment = executePayment;
MC.drawCards = drawCards; MC.discardRandomFromHand = discardRandomFromHand;
MC.onEmptyPlayerDeck = onEmptyPlayerDeck;
MC.readyAllFor = readyAllFor; MC.drawUpToHandSize = drawUpToHandSize;
