/* ═══════════════════════════════════════════════════════════════
   mc_2_effects.js — 샤드 2/7 : EFFECTS 레지스트리 + runEffectList
   즉발 효과만 등록. 트리거형은 mc_3_handlers.js(HANDLERS)로.
   ※ 함정 주의: runEffectList는 EFFECTS만 조회한다.
   등록 규율: 재사용 → 확장 → 신규. 신규 시 "왜 기존 것 불가" 주석 필수.
   ═══════════════════════════════════════════════════════════════ */

const EFFECTS = {};

/* runEffectList(G, list, ctx)
   list: [{fx:'dealDamage', amount:2, target:'chosen'}, ...]
   ctx : {player, card, source, targets, ...} */
function runEffectList(G, list, ctx){
  if (!list) return;
  for (const step of list){
    // 조건부 효과: step.cond가 있으면 condCheck 통과 시에만 실행 (범용 — Aerial 등)
    if (step.cond && !MC.condCheck(G, step.cond, ctx || {})) continue;
    const fn = EFFECTS[step.fx];
    if (!fn) throw new Error('[runEffectList] 미등록 fx: ' + step.fx);
    fn(G, step, ctx || {});
  }
}

/* ── 원시 효과 (Phase 1에서 규칙 파이프라인과 결합해 확장) ── */

// 피해: 강인/보복/과잉살상 상호작용은 applyDamage 파이프라인(mc_6)에서 일괄 처리
/* 순차 다중 대상 피해 (melee=근접전투): p.lines 개수만큼 서로 다른 적에게 각 amount 피해.
   각 라인을 순서대로 해결 (첫 라인 처치로 Guard 돌파/빌런 단계 전환 반영).
   ctx.targets[i]가 각 라인 대상. 각 대상은 서로 달라야 함 (공식 FAQ: another enemy).
   대상이 부족하면(둘째 미지정) 해당 라인은 스킵 (기절 시 첫 라인만 등도 UI에서 처리). */
EFFECTS.dealDamageMulti = function(G, p, ctx){
  const targets = ctx.targets || [];
  const lines = p.lines || 2;
  const amount = p.amount;
  const used = [];
  for (let i = 0; i < lines; i++){
    const t = targets[i];
    if (!t){ MC.log(G, '(근접 전투 ' + (i+1) + '번째 대상 없음 — 라인 스킵)'); continue; }
    // 서로 다른 적 검증 (같은 uid 중복 금지)
    if (used.includes(t.uid)){ MC.log(G, '(근접 전투 — 같은 적 중복 불가, 라인 스킵)'); continue; }
    used.push(t.uid);
    // 대상이 이미 처치됐으면(앞 라인 결과) 스킵
    if (t.hp !== undefined && t.hp <= 0){ MC.log(G, '(대상 이미 처치됨 — 라인 스킵)'); continue; }
    MC.applyDamage(G, t, amount, { source: ctx.card, isAttack: p.isAttack !== false });
  }
};

// 빌런 최대/현재 HP 증감 (불멸의 클로 +10 / 해결 시 -10 등). 감소 시 현재 HP는 상한 클램프만.
// 스킴의 목표 위협치(maxThreat) 증가 (Under Surveillance 06031 — 완료 지연). _targetBuff 누적(UI 표시).
EFFECTS.buffSchemeTarget = function(G, p, ctx){
  const s = (ctx.targets && ctx.targets[0]) || G.mainScheme;
  if (!s) return;
  const amt = p.amount || 0;
  s.maxThreat = Math.max(1, (s.maxThreat || 0) + amt);
  s._targetBuff = (s._targetBuff || 0) + amt;
  MC.log(G, MC.nameOf(s) + ' 목표 위협치 ' + (amt >= 0 ? '+' : '') + amt + ' (완료 ' + s.threat + '/' + s.maxThreat + ')');
};

EFFECTS.buffVillainHp = function(G, p, ctx){
  const v = G.villain;
  if (!v) return;
  const amt = p.amount || 0;
  v.maxHp = Math.max(1, (v.maxHp || v.hp || 0) + amt);
  v._hpBuff = (v._hpBuff || 0) + amt;   // 추가 체력 누적 (UI 표시용 — 불멸의 클로 등)
  if (amt > 0) v.hp = (v.hp || 0) + amt;
  else if (v.hp > v.maxHp) v.hp = v.maxHp;   // 감소 시 최대치 초과분만 감소 (스킴 해결로 죽지 않음)
  MC.log(G, MC.nameOf(v) + ' HP ' + (amt >= 0 ? '+' : '') + amt + ' (현재 ' + v.hp + '/' + v.maxHp + ')');
};

// 대상 하수인을 이 플레이어와 교전 상태로 (Get Over Here! Aerial 교전 등). ctx.targets[0] 또는 ctx.target.
// 컨트롤러 히어로에게 피해 (Battle Fury 06018 등 반응 비용). p.amount.
EFFECTS.selfDamage = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl) return;
  MC.applyDamage(G, pl, p.amount || 1, { source: ctx.self || ctx.card });
};

// 준비된 Weapon 특성 업그레이드 1개 소진 → 다음 기본 공격 ATK 보너스 (Mean Swing 06015).
EFFECTS.exhaustWeapon = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const w = (pl.playArea.upgrades || []).find(c => !c.exhausted && ((MC.cardDef(c.defCode).traits) || []).includes('weapon'));
  if (!w){ MC.log(G, '준비된 무기(Weapon) 없음 — 효과 불발'); return; }
  w.exhausted = true;
  pl.nextBasicAttackBonus = (pl.nextBasicAttackBonus || 0) + (p.attackBonus || 3);
  MC.log(G, MC.nameOf(w) + ' 소진 → 다음 기본 공격 ATK +' + (p.attackBonus || 3));
};

EFFECTS.engageTarget = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const t = (ctx.targets && ctx.targets[0]) || ctx.target;
  if (!t || t.type !== 'minion' || t.hp <= 0) return;
  if (t.engagedWith === pl.uid) return;   // 이미 교전 중
  for (const p2 of G.players){
    const i = (p2.engagedMinions || []).indexOf(t);
    if (i >= 0) p2.engagedMinions.splice(i, 1);
  }
  t.engagedWith = pl.uid;
  pl.engagedMinions.push(t);
  MC.log(G, MC.nameOf(t) + ' — ' + MC.nameOf(pl) + '와 교전 (Get Over Here!)');
};

/* 덱 맨 위 카드 1장 버림 → 그 카드의 인쇄 자원별로 지정된 효과 분기 실행 (와일드=전부).
   Magic Blast·Baron Mordo 등 "자원-효과 매핑" 공통 패턴. branches:{physical:[...],energy:[...],mental:[...]}. */
/* 방어 pending에 "무피해 시 재준비" 플래그 설정 — 필사의 방어. resolveDefensePending이 dmg===0일 때 히어로 ready. */
/* 대상에서 상태 카드(기절/혼란/충격) 1개 제거 — Night Nurse. target 생략 시 시전자 히어로. */
/* 다음 기본 공격 ATK +N (무기 소진 불필요) — Skilled Strike. */
EFFECTS.buffNextBasicAttack = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.nextBasicAttackBonus = (pl.nextBasicAttackBonus || 0) + (p.amount || 2);
  MC.log(G, '다음 기본 공격 ATK +' + (p.amount || 2));
};

/* 다음 기본 공격에 과잉살상(Overkill) 부여 — 헐크 스매시(물리 지불 시). cond로 조건부. */
/* 거인들의 충돌(Clash of the Titans) — 최고 ATK 적이 최고 ATK 히어로/동료를 공격.
   공격이 이뤄지지 않으면(적 없음/ATK 0) 이 배신 카드 surge. */
EFFECTS.clashOfTitans = function(G, p, ctx){
  const enemies = [];
  if (G.villain) enemies.push(G.villain);
  for (const pl of G.players) for (const m of (pl.engagedMinions || [])) enemies.push(m);
  let topEnemy = null, topEnemyAtk = -1;
  for (const e of enemies){ const a = MC.enemyAtk(G, e); if (a > topEnemyAtk){ topEnemyAtk = a; topEnemy = e; } }
  let topChar = null, topCharAtk = -1, topCharPl = null, topIsHero = false;
  for (const pl of G.players){
    if (pl.form === 'hero'){ const a = MC.statOf(G, pl, 'attack'); if (a > topCharAtk){ topCharAtk = a; topChar = pl; topCharPl = pl; topIsHero = true; } }
    for (const al of (pl.playArea.allies || [])){ const a = MC.allyStatOf(G, al, 'attack'); if (a > topCharAtk){ topCharAtk = a; topChar = al; topCharPl = pl; topIsHero = false; } }
  }
  if (topEnemy && topChar && topEnemyAtk > 0){
    MC.log(G, '거인들의 충돌 — ' + MC.nameOf(topEnemy) + '(ATK ' + topEnemyAtk + ') → ' + MC.nameOf(topChar) + '(ATK ' + topCharAtk + ') 공격');
    if (topIsHero){ MC.enemyActivation(G, topEnemy, topCharPl); }
    else { MC.applyDamage(G, topChar, topEnemyAtk, { source: topEnemy, isAttack: true }); }
  } else {
    const self = ctx.self || ctx.card;
    if (self) self.surge = true;
    MC.log(G, '거인들의 충돌 — 공격이 이뤄지지 않음, 급증(surge)');
  }
};

/* 적 공격 유발 (Toe to Toe) — 선택한 적이 히어로를 공격하게 함 + 방어 해소 후 afterEffects(그 적 5피해).
   enemyActivation으로 공격 유발 → 방어 pending에 afterEffects 심음 (해소 후 실행). */
EFFECTS.provokeEnemyAttack = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const enemy = (ctx.targets && ctx.targets[0]);
  if (!enemy){ MC.log(G, '(공격 유발 대상 없음)'); return; }
  MC.log(G, MC.nameOf(enemy) + ' — 도발당해 ' + MC.nameOf(pl) + '을(를) 공격');
  MC.enemyActivation(G, enemy, pl);
  if (G.pending && G.pending.kind === 'defense'){
    G.pending.afterEffects = p.afterEffects || [];   // 방어 해소 후 그 적에 5피해
  } else if (p.afterEffects){
    // 공격이 생략됐으면(기절 등) 즉시 후속 효과
    MC.runEffectList(G, p.afterEffects, { player: pl, targets: [enemy], self: enemy, card: enemy });
  }
};

EFFECTS.setNextAttackOverkill = function(G, p, ctx){
  if (p.cond && !MC.condCheck(G, p.cond, ctx)) return;
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.nextBasicAttackOverkill = true;
  MC.log(G, '다음 기본 공격 — 과잉살상(Overkill) 부여');
};

EFFECTS.removeStatus = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target || 'self', ctx);
  const arr = Array.isArray(tgt) ? tgt : [tgt];
  for (const t of arr){
    if (!t || !t.status) continue;
    for (const st of ['stunned', 'confused', 'tough']){
      if (t.status[st] > 0){ t.status[st] = 0; MC.log(G, MC.nameOf(t) + ' — ' + st + ' 상태 제거'); break; }
    }
  }
};

/* 저지됐다!(foiled) — 직전 빌런/하수인 음모의 부스트 아이콘 위협분 취소.
   음모 부스트는 자동 집계되므로 G._lastSchemeBoost로 추적된 부스트분을 소급 제거. */
/* 다크 디멘션(open-dark-dimension) 발동덱 조작.
   stashInvocation: 발동 덱 맨 위 카드 1장을 이 스킴 아래로 격리(발동덱에서 제외).
   restoreInvocation: 격파 시 격리 카드를 발동 덱에 복귀 + 셔플. */
/* 생각 조종(thoughtcasting): 손패에서 인쇄 비용이 가장 높은 카드 1장 버림 →
   then:'threat'이면 그 비용만큼 메인 스킴 위협 / then:'damage'이면 그 비용만큼 피해. */
EFFECTS.discardHighestCostHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl.hand || !pl.hand.length){ MC.log(G, '(손패 없음 — 생각 조종 효과 없음)'); return; }
  let best = null, bestCost = -1;
  for (const c of pl.hand){
    const cost = MC.cardDef(c.defCode).cost || 0;
    if (cost > bestCost){ bestCost = cost; best = c; }
  }
  if (!best) return;
  const i = pl.hand.indexOf(best);
  pl.hand.splice(i, 1);
  MC.moveToDiscard(G, pl, best, {});
  MC.log(G, '생각 조종 — 최고 비용 카드 ' + MC.nameOf(best) + ' 버림 (비용 ' + bestCost + ')');
  if (bestCost <= 0) return;
  if (p.then === 'threat'){ MC.placeThreat(G, 'main', bestCost); MC.log(G, '메인 스킴 위협 +' + bestCost); }
  else if (p.then === 'damage'){ MC.applyDamage(G, pl, bestCost, { source: ctx.self || ctx.card }); MC.log(G, '히어로 ' + bestCost + ' 피해'); }
};

EFFECTS.stashInvocation = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl.invocationDeck || !pl.invocationDeck.length) MC.invocationReshuffleIfEmpty(G, pl);
  if (pl.invocationDeck && pl.invocationDeck.length){
    const card = pl.invocationDeck.shift();
    const s = ctx.self || ctx.card;
    s.stashedInvocation = s.stashedInvocation || [];
    s.stashedInvocation.push(card.defCode);
    s.stashedOwner = pl.uid;
    MC.log(G, '다크 디멘션 열림 — 발동 카드 ' + MC.nameOf(card) + ' 격리 (발동덱에서 제외)');
  } else MC.log(G, '다크 디멘션 — 격리할 발동 카드 없음');
};
EFFECTS.restoreInvocation = function(G, p, ctx){
  const s = ctx.self || ctx.card;
  if (s.stashedInvocation && s.stashedInvocation.length){
    const pl = G.players.find(x => x.uid === s.stashedOwner) || G.players[G.firstPlayer];
    pl.invocationDeck = pl.invocationDeck || [];
    for (const code of s.stashedInvocation) pl.invocationDeck.push(MC.makeInstance(G, code));
    MC.shuffle(G, pl.invocationDeck);
    MC.log(G, '다크 디멘션 격파 — 발동 카드 ' + s.stashedInvocation.length + '장 발동덱 복귀+셔플');
    s.stashedInvocation = [];
  }
};

EFFECTS.cancelLastSchemeBoost = function(G, p, ctx){
  const lb = G._lastSchemeBoost;
  if (!lb || !lb.boost){ MC.log(G, '저지됐다! — 취소할 음모 부스트 없음'); return; }
  MC.removeThreat(G, lb.schemeRef || 'main', lb.boost);
  MC.log(G, '저지됐다! — 음모 부스트 아이콘 취소 (위협 -' + lb.boost + ')');
  G._lastSchemeBoost = null;
};

EFFECTS.setReadyIfNoDamage = function(G, p, ctx){
  if (G.pending && G.pending.kind === 'defense') G.pending.readyIfNoDamage = true;
};

EFFECTS.discardTopResourceBranch = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl || !pl.deck || !pl.deck.length){ MC.log(G, '(덱 비어있음 — 자원 판정 없음)'); return; }
  const c = pl.deck.pop();
  const icons = (MC.resourceIconsOf ? MC.resourceIconsOf(c) : {}) || {};
  MC.moveToDiscard(G, pl, c, {});
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 버림 (자원 판정)');
  const w = (icons.wild || 0) > 0;
  const br = p.branches || {};
  for (const res of ['physical', 'energy', 'mental']){
    if (((icons[res] || 0) > 0 || w) && br[res]) MC.runEffectList(G, br[res], ctx);
  }
};

EFFECTS.dealDamage = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  // 조건부 피해량 (amountIf: {cond, amount}) — 조건 충족 시 그 값으로 대체 (초음속 펀치=Aerial 시 8)
  let amount = p.amount;
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  if (p.amountFrom === 'ritualX') amount = G._ritualX || 0;
  if (p.amountFrom === 'heroAtk') amount = MC.statOf(G, ctx.player || G.players[G.firstPlayer], 'attack') || 0;   // 헐크 크러싱 블로우: ATK만큼 피해
  if (p.amountFrom === 'xValue') amount = ctx.xValue || 0;   // X 에너지 지불량 = 피해 (라이트닝 스트라이크 06006)
  if (p.amountFrom === 'upgradeCount'){
    const who = ctx.player || G.players[G.firstPlayer];
    amount = (who.playArea.upgrades || []).length;
  }
  // 사이드 스킴 위협 수를 피해량으로 (폭발!=폭탄 위협 위협 수만큼 X 피해)
  if (p.amountFromSchemeThreat){
    const ss = (G.sideSchemes || []).find(s => s.defCode === p.amountFromSchemeThreat);
    amount = ss ? (ss.threat || 0) : 0;
  }
  amount += (ctx.eventDamageBonus || 0);   // Embiggen! 등 이벤트 강화 인터럽트 보너스
  // 조건부 오버킬 (overkillIf: cond) — 결제 자원 등 조건 충족 시 과잉살상 획득 (거침없는 돌진=피지컬 지불)
  const overkill = !!p.overkill || (p.overkillIf && MC.condCheck(G, p.overkillIf, ctx));
  // 조건부 관통 (piercingIf: cond) — 조건 충족 시 강인(Tough) 무시 (라이트닝 스트라이크=Aerial 시)
  const piercing = !!p.piercing || (p.piercingIf && MC.condCheck(G, p.piercingIf, ctx));
  for (const t of tgt){
    const wasEnemy = (t.type === 'villain' || t.type === 'minion');
    MC.applyDamage(G, t, amount, { source: ctx.card, piercing, overkill, isAttack: !!p.isAttack });
    // 격파 시 후속 효과 (onDefeat) — 은밀한 일격(격파 시 위협 제거) 등. 범용 데이터.
    if (p.onDefeat && wasEnemy && ((t.hp !== undefined && t.hp <= 0) || t.defeated)){
      MC.runEffectList(G, Array.isArray(p.onDefeat) ? p.onDefeat : [p.onDefeat], ctx);
    }
  }
};

EFFECTS.heal = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  let amount = p.amount;
  // 조건부 회복량 (amountIf: {cond, amount}) — 멘탈 지불 시 5 등. dealDamage/removeThreat와 동일 패턴.
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  for (const t of tgt) MC.healTarget(G, t, amount);
};

/* 자신을 준비(ready) 상태로 (원투 펀치 등): 소진 해제 → 추가 액션 가능. */
EFFECTS.readySelf = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  pl.exhausted = false;
  MC.log(G, MC.nameOf(pl) + ' 준비 상태로 — 추가 행동 가능');
};

/* 버림 더미에서 특정 특성의 맨 위 카드를 손으로 회수 (스타크 타워: Tech 업그레이드).
   p.trait(필터 특성), p.cardType(선택적 타입 필터). ctx.player 대상(단일플레이=자신). */
/* 덱(+선택적 버림)에서 trait/type 일치 카드 1장을 손에 추가 후 덱 셔플 — Agent Coulson(준비 카드 서치). */
/* 버림 더미에서 동료 1장을 전장에 복귀 + 지정 피해 — Rapid Response(동료 부활). targets 우선, 없으면 최근 동료. */
/* 손패에서 가장 비용 높은 준비(Preparation) 카드 1장 버림 — Burn Notice. 버렸으면 ctx._discardedUpgrade=true (surgeIfNoDiscard 재사용). */
EFFECTS.discardMostExpensivePreparation = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl){ ctx._discardedUpgrade = false; return; }
  let best = -1, bestIdx = -1;
  for (let i = 0; i < pl.hand.length; i++){
    const d = MC.cardDef(pl.hand[i].defCode);
    if (!(d.traits || []).includes('preparation')) continue;
    if ((d.cost || 0) > best){ best = d.cost || 0; bestIdx = i; }
  }
  if (bestIdx >= 0){
    const c = pl.hand.splice(bestIdx, 1)[0];
    MC.moveToDiscard(G, pl, c, {});
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 버림 (가장 비싼 준비 카드)');
    ctx._discardedUpgrade = true;
  } else {
    MC.log(G, '(버릴 준비 카드 없음 → 급증)');
    ctx._discardedUpgrade = false;
  }
};

EFFECTS.reviveAllyFromDiscard = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  let idx = -1;
  if (ctx.targets && ctx.targets[0]){
    idx = pl.discard.findIndex(c => c.uid === ctx.targets[0].uid);
  }
  if (idx < 0){
    for (let i = pl.discard.length - 1; i >= 0; i--){
      if (MC.cardDef(pl.discard[i].defCode).type === 'ally'){ idx = i; break; }
    }
  }
  if (idx < 0){ MC.log(G, '(버림 더미에 복귀할 동료 없음)'); return; }
  const c = pl.discard.splice(idx, 1)[0];
  const inst = MC.makeInstance(G, c.defCode);
  pl.playArea.allies.push(inst);
  MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(inst) + ' 버림 더미에서 전장 복귀');
  if (p.damage) MC.applyDamage(G, inst, p.damage, { source:{ isPlayer:true }, isAttack:false });
};

/* 닥터 스트레인지 발동 덱 EFFECT 래퍼 — 신분 능력(effect 파이프라인)에서 호출. */
/* 조우덱 맨 위 카드를 확인 → 그 부스트 아이콘 수만큼 지정 스킴에서 위협 제거 — Astral Projection. */
EFFECTS.removeThreatByEncounterBoost = function(G, p, ctx){
  const top = G.encounterDeck && G.encounterDeck[G.encounterDeck.length - 1];
  if (!top){ MC.log(G, '(조우덱 비어있음 — 추가 위협 제거 없음)'); return; }
  const b = (MC.boostOf ? MC.boostOf(G, top, ctx.player) : 0) || 0;
  MC.log(G, '유체이탈 — 조우덱 위 ' + MC.nameOf(top) + ' 확인 (부스트 ' + b + ')');
  if (b > 0) MC.EFFECTS.removeThreat(G, { scheme: p.scheme || 'chosen', amount: b }, ctx);
};

EFFECTS.castInvocation = function(G, p, ctx){
  if (MC.castInvocation) MC.castInvocation(G, ctx.player, { targets: ctx.targets, keepOnTop: p.keepOnTop });
};
EFFECTS.naturalTalent = function(G, p, ctx){
  if (MC.naturalTalent) MC.naturalTalent(G, ctx.player);
};

/* 덱 맨 위 N장에서 조건 일치 카드 1장을 손에 추가 후 셔플 — Brother Voodoo(상단 5장 이벤트 서치). */
EFFECTS.searchTopN = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  const n = p.count || 5;
  const top = pl.deck.slice(-n).reverse();
  for (const c of top){
    const def = MC.cardDef(c.defCode);
    if (p.cardType && def.type !== p.cardType) continue;
    if (p.trait && !(def.traits || []).includes(p.trait)) continue;
    if (p.hero && def.hero !== p.hero) continue;
    const idx = pl.deck.indexOf(c);
    pl.deck.splice(idx, 1);
    pl.hand.push(c);
    if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손에 추가 (덱 상단 ' + n + '장 서치)');
    return;
  }
  if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
  MC.log(G, '(덱 상단 ' + n + '장에 ' + (p.cardType || '카드') + ' 없음)');
};

EFFECTS.searchDeckToHand = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  const pools = p.includeDiscard ? [pl.deck, pl.discard] : [pl.deck];
  for (const pool of pools){
    for (let i = pool.length - 1; i >= 0; i--){
      const c = pool[i];
      const def = MC.cardDef(c.defCode);
      if (p.cardType && def.type !== p.cardType) continue;
      if (p.trait && !(def.traits || []).includes(p.trait)) continue;
      if (p.hero && def.hero !== p.hero) continue;
      pool.splice(i, 1);
      pl.hand.push(c);
      MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손에 추가 (덱/버림 서치: ' + (p.trait || '') + ')');
      if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
      G.fxReveal = { kind:'search', card:{ defCode:c.defCode, name: MC.nameOf(c) }, trait:p.trait };
      return;
    }
  }
  if (p.shuffle && MC.shuffle) MC.shuffle(G, pl.deck);
  MC.log(G, '(' + (p.trait || '카드') + ' 없음 — 서치 실패)');
};

/* 버림 더미의 주문(Spell) 카드 1장을 덱에 셔플 — Sanctum Sanctorum. */
EFFECTS.recallSpellToDeck = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  for (let i = pl.discard.length - 1; i >= 0; i--){
    const c = pl.discard[i];
    if (!(MC.cardDef(c.defCode).traits || []).includes('spell')) continue;
    pl.discard.splice(i, 1);
    pl.deck.push(c);
    if (MC.shuffle) MC.shuffle(G, pl.deck);
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 덱에 셔플 (주문 회수)');
    return;
  }
  MC.log(G, '(버림 더미에 주문 카드 없음)');
};

EFFECTS.recallFromDiscard = function(G, p, ctx){
  const pl = (ctx.targets && ctx.targets[0] && ctx.targets[0].hand) ? ctx.targets[0] : ctx.player;
  if (!pl){ MC.log(G, '(회수 대상 플레이어 없음)'); return; }
  // 버림 더미 위에서부터 탐색 (맨 위 = 배열 끝)
  for (let i = pl.discard.length - 1; i >= 0; i--){
    const c = pl.discard[i];
    const def = MC.cardDef(c.defCode);
    if (p.cardType && def.type !== p.cardType) continue;
    const traits = def.traits || [];
    if (p.trait && !traits.includes(p.trait)) continue;
    // 발견 — 손으로 반환
    pl.discard.splice(i, 1);
    pl.hand.push(c);
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손으로 회수 (' + (p.trait||'') + ')');
    G.fxReveal = { kind:'recall', card:{ defCode:c.defCode, name: MC.nameOf(c) }, trait:p.trait };
    return;
  }
  MC.log(G, '(버림 더미에 해당 특성 카드 없음: ' + (p.trait||'') + ')');
};

/* 일시적 트레잇 부여 (로켓 부츠: 이번 페이즈 동안 Aerial). p.trait. */
EFFECTS.grantTrait = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  pl.tempTraits = pl.tempTraits || [];
  const t = String(p.trait).toLowerCase();
  if (!pl.tempTraits.includes(t)){
    pl.tempTraits.push(t);
    MC.log(G, MC.nameOf(pl) + ' — 이번 페이즈 동안 ' + p.trait + ' 획득');
  }
  G.fxReveal = { kind:'trait', trait: t };
};

/* 리펄서 블래스트: 대상 1 피해 + 덱 위 N장 버림 → 버려진 인쇄 에너지 아이콘당 추가 2 피해.
   아이언맨 시그니처. ctx.targets[0] 대상. p.mill(버릴 장수), p.perEnergy(에너지당 피해). */
EFFECTS.repulsorBlast = function(G, p, ctx){
  const pl = ctx.player;
  const target = (ctx.targets && ctx.targets[0]);
  if (!target){ MC.log(G, '(리펄서 블래스트 대상 없음)'); return; }
  const mill = p.mill || 5, perEnergy = p.perEnergy || 2;
  let energy = 0;
  const milledCards = [];   // UI 연출 힌트용 (표시 전용, 상태 결정성 무관)
  for (let i = 0; i < mill; i++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); break; }   // RRG: 밀 중 소진→리셔플+조우카드 후 새 덱에선 안 밀음
    const c = pl.deck.pop();   // 덱 위 = 끝(pop). shift(앞=바닥)는 버그였음 (lookAtTopChoose와 동일 계열)
    if (!c) break;
    const icons = MC.resourceIconsOf(c);
    const eCount = icons.energy || 0;
    if (eCount > 0) energy += eCount;
    pl.discard.push(c);
    milledCards.push({ defCode: c.defCode, name: MC.nameOf(c), energy: eCount });
  }
  const bonus = energy * perEnergy;
  const total = (p.base || 1) + bonus;
  MC.log(G, MC.nameOf(ctx.card) + ' — 덱 ' + milledCards.length + '장 공개 (에너지 ' + energy + ' → 추가 ' + bonus + ')');
  // UI 연출 힌트 (다음 render에서 소비 후 폐기 — 상태 스냅샷/재생에 영향 없음)
  G.fxReveal = { kind:'repulsor', cards: milledCards, energy, perEnergy, base: (p.base||1), total,
                 targetUid: target.uid };
  MC.applyDamage(G, target, total, { source: pl, isAttack: true });
  MC.log(G, MC.nameOf(target) + '에게 리펄서 ' + total + ' 피해');
};

/* 카드 버림 → 버린 수만큼 위협 제거 (법률 업무 등). ctx.discardUids로 버릴 카드 지정.
   p.max 최대 버림 수, p.perCard 카드당 위협 제거량(기본 1). 메인 스킴 대상. */
EFFECTS.discardForThreat = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  let uids = (ctx.discardUids || []).slice(0, p.max || 5);
  let discarded = 0;
  for (const uid of uids){
    const i = pl.hand.findIndex(c => c.uid === uid);
    if (i < 0) continue;
    const c = pl.hand.splice(i, 1)[0];
    pl.discard.push(c);
    discarded++;
  }
  if (discarded <= 0){ MC.log(G, '(버린 카드 없음 — 위협 제거 없음)'); return; }
  const remove = discarded * (p.perCard || 1);
  MC.log(G, MC.nameOf(ctx.card) + ' — 카드 ' + discarded + '장 버림 → 위협 ' + remove + ' 제거');
  MC.removeThreat(G, p.scheme || 'main', remove);
};

/* 누적 피해량 기반 가변 피해 (감마 슬램): 발동자의 누적 피해(maxHp - hp)만큼
   대상에게 피해. p.max 상한. "자기 상태 기반 가변 피해" 패턴. */
EFFECTS.dealDamageSustained = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  let dmg = Math.max(0, (pl.maxHp || 0) - (pl.hp || 0));
  if (p.max) dmg = Math.min(dmg, p.max);
  const tgt = MC.resolveTarget(G, p.target || 'chosen', ctx);
  for (const t of tgt){
    MC.log(G, MC.nameOf(ctx.card || pl) + ' — ' + MC.nameOf(t) + '에게 누적 피해 ' + dmg);
    MC.applyDamage(G, t, dmg, { source: pl, isAttack: true });
  }
};

/* 이중인격(split personality): 라운드 제한 무시 폼 전환 후 인쇄 핸드 크기까지 드로우.
   flipForm(force) + drawUpToHandSize. She-Hulk 전용이지만 범용 효과. */
EFFECTS.splitPersonality = function(G, p, ctx){
  const pl = ctx.player;
  if (!pl) return;
  MC.flipForm(G, pl, { force: true });
  MC.drawUpToHandSize(G, pl);
  MC.log(G, MC.nameOf(pl) + ' — 이중인격: 폼 전환 후 손패 보충');
};

/* 버림 더미에서 맨 위 특정 특성 업그레이드를 손으로 반환 (스타크 타워: Tech 업그레이드).
   p.trait(한글 특성 키워드, textKo 기반 판정), p.cardType(기본 upgrade). 대상=chosen 플레이어. */
EFFECTS.returnTopTraitUpgrade = function(G, p, ctx){
  // 대상 플레이어: chosen 있으면 그 플레이어, 없으면 발동자
  let targetPl = ctx.player;
  if (ctx.targets && ctx.targets[0] && ctx.targets[0].uid && ctx.targets[0].hand) targetPl = ctx.targets[0];
  else if (ctx.targetPlayer) targetPl = ctx.targetPlayer;
  const trait = p.trait || '기술';
  const cardType = p.cardType || 'upgrade';
  // 버림 더미 맨 위(뒤에서부터)에서 조건 맞는 첫 카드
  for (let i = targetPl.discard.length - 1; i >= 0; i--){
    const c = targetPl.discard[i];
    const def = MC.cardDef(c.defCode);
    if (def.type !== cardType) continue;
    if (!(def.textKo || '').includes(trait)) continue;
    targetPl.discard.splice(i, 1);
    targetPl.hand.push(c);
    MC.log(G, MC.nameOf(targetPl) + ' — 버림 더미에서 ' + MC.nameOf(c) + ' 손으로 반환 (' + trait + ')');
    return;
  }
  MC.log(G, '(버림 더미에 반환할 ' + trait + ' ' + cardType + ' 없음)');
};

/* 카드를 소유자 손으로 반환 (self 대상). 동료/업그레이드 등. 손으로 가면 인스턴스
   상태(HP/소진/카운터)는 새로 플레이 시 makeInstance로 초기화되므로 여기선 이동만. */
EFFECTS.returnToHand = function(G, p, ctx){
  let card = ctx.self || ctx.card;
  // p.card(slug) 지정 시 컨트롤러 플레이 영역에서 해당 카드 탐색 (Hammer Throw → Mjolnir 반환 등).
  if (p && p.card){
    const pl = ctx.player || G.players[G.firstPlayer];
    if (pl) for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies]){
      const found = arr.find(c => c.defCode === p.card);
      if (found){ card = found; break; }
    }
  }
  if (!card) return;
  const owner = G.players.find(x => x.uid === card.ownerUid) || ctx.player;
  if (!owner) return;
  // 플레이 영역에서 제거
  for (const arr of [owner.playArea.allies, owner.playArea.supports, owner.playArea.upgrades]){
    const i = arr.indexOf(card);
    if (i >= 0){ arr.splice(i, 1); break; }
  }
  // 부착물이 있으면 해제
  if (card.attachments && card.attachments.length) MC.releaseAttachments(G, card);
  // 새 인스턴스로 손에 추가 (상태 리셋 — HP 등 원상복구)
  const fresh = MC.makeInstance(G, card.defCode, {});
  fresh.ownerUid = owner.uid;
  owner.hand.push(fresh);
  MC.log(G, MC.nameOf(card) + ' — 소유자 손으로 반환');
};

EFFECTS.draw = function(G, p, ctx){
  const who = MC.resolvePlayers(G, p.who || 'self', ctx);
  for (const pl of who) MC.drawCards(G, pl, p.amount || 1);
};

// 덱 위에서 특정 히어로 시그니처 카드가 나올 때까지 버림 → 그 카드를 손에 (미즈마블 Teen Spirit).
EFFECTS.discardUntilHeroCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const hero = p.hero;
  let milled = 0, found = null;
  while (pl.deck && pl.deck.length){
    const c = pl.deck.shift();
    const d = MC.cardDef(c.defCode) || {};
    if (d.hero === hero){ found = c; break; }
    MC.moveToDiscard(G, pl, c, {}); milled++;
  }
  if (found){
    found.ownerUid = pl.uid; pl.hand.push(found);
    MC.log(G, MC.nameOf(pl) + ' — 덱 ' + milled + '장 버림 후 ' + MC.nameOf(found) + ' 손에 (Teen Spirit)');
  } else {
    MC.log(G, MC.nameOf(pl) + ' — 덱에서 미즈마블 카드 못 찾음 (' + milled + '장 버림)');
  }
};

EFFECTS.discardFromHand = function(G, p, ctx){
  const who = MC.resolvePlayers(G, p.who || 'self', ctx);
  for (const pl of who) MC.discardRandomFromHand(G, pl, p.amount || 1); // Phase 1: 선택 discard로 확장
}

/* 각 히어로 형태 플레이어가 손에서 N장 버림 — 태스크마스터 배반 04106 Hunted by Hydra. 범용. */
EFFECTS.discardFromHandEachHero = function(G, p, ctx){
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated || pl.form !== 'hero') continue;
    MC.runEffectList(G, [{ fx:'discardFromHand', count: p.count || 1, random: p.random }], { player: pl });
  }
};;

/* 손패 전체 강제 버림 (헐크 격노 등) — 공용 forcedDiscard로 VFX 힌트까지 처리. */
EFFECTS.discardHand = function(G, p, ctx){
  const who = MC.resolvePlayers(G, p.who || 'self', ctx);
  for (const pl of who){
    const cards = pl.hand.slice();
    if (cards.length) MC.forcedDiscard(G, pl, cards, { reason: p.reason || '강제 버림' });
  }
};

EFFECTS.placeThreat = function(G, p, ctx){
  // scheme:'self' → 이 카드(사이드 스킴) 자신. perHero → 인원수 비례 추가 위협.
  // scheme:'eachSide' → 전장의 각 사이드 스킴에 amount씩 (프로그램 전송기 01141 부스트★ 등).
  // perDroneInPlay → 전장의 모든 Drone 하수인 수 × 값만큼 추가 (드론 공장 01148).
  let amount = p.amount || 0;
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  if (p.amountFrom === 'ritualX') amount = G._ritualX || 0;
  if (p.perHero) amount += p.perHero * G.players.length;
  if (p.perDroneInPlay){
    let drones = 0;
    for (const pl of G.players)
      drones += pl.engagedMinions.filter(m => m.isDrone || (m.traits||[]).includes('drone')).length;
    amount += p.perDroneInPlay * drones;
    MC.log(G, '전장 Drone ' + drones + '명 × ' + p.perDroneInPlay + ' 위협');
  }
  if (p.scheme === 'eachSide'){
    const sides = (G.sideSchemes || []).slice();
    if (!sides.length){ MC.log(G, '(사이드 스킴 없음 — 위협 배치 불발)'); return; }
    for (const ss of sides) MC.placeThreat(G, ss.uid, amount);
    MC.log(G, '각 사이드 스킴에 위협 +' + amount + ' (' + sides.length + '곳)');
    return;
  }
  if (p.scheme === 'namedSide' && p.slug){   // 특정 사이드 스킴(defCode)에 위협 — 욘-로그 강제반응 등
    const ss = (G.sideSchemes || []).find(s => s.defCode === p.slug);
    if (ss){ MC.placeThreat(G, ss.uid, amount); MC.log(G, MC.nameOf(ss) + '에 위협 +' + amount); }
    else MC.log(G, p.slug + ' 사이드 스킴 없음 — 위협 배치 불발');
    return;
  }
  let ref = p.scheme || 'main';
  if (ref === 'self' && ctx.self) ref = ctx.self.uid;
  MC.placeThreat(G, ref, amount);
}

/* ★ 지연 카운터 비례 위협 (범용): 메인 스킴 delay 카운터 (per)개당 위협 1 배치.
   배치가 0이면 surgeIfNone 시 이 카드에 surge 부여 — 어보밍맨 배반 04085 Stall Tactics.
   추격전(delayPerVillainPhase) 시나리오의 "지연될수록 위협" 패턴에 재사용. */
EFFECTS.placeThreatPerDelayCounters = function(G, p, ctx){
  const delay = (G.mainScheme && G.mainScheme.delayCounters) || 0;
  const per = p.per || 2;
  const amt = Math.floor(delay / per);
  if (amt > 0){
    MC.placeThreat(G, p.scheme || 'main', amt);
    MC.log(G, '지연 카운터 ' + delay + ' → ' + (p.scheme || 'main') + ' 위협 +' + amt);
  } else if (p.surgeIfNone && ctx.self){
    ctx.self.surge = true;
    MC.log(G, '지연 카운터 부족 — 위협 배치 없음 → 급증(surge)');
  }
};;

/* 조우 덱 상위 N장을 확인(look at — 순서 유지, 버리지 않음) → matchType 카드 수 × perMatch 만큼 스킴 위협 제거.
   파라미터: count(볼 장수, 기본3), matchType(카운트 타입, 기본 treachery), perMatch(장당 제거, 기본1), scheme(대상, 기본 ctx.targetScheme||main).
   팔콘 등 "조우덱 훔쳐보고 배신 수만큼 위협 제거" 계열 재사용. 상위 = 덱 끝(pop 방향). */
EFFECTS.peekEncounterRemoveThreat = function(G, p, ctx){
  const n = p.count || 3;
  const deck = G.encounterDeck || [];
  const top = deck.slice(Math.max(0, deck.length - n));   // 상위 N장 (순서 유지 — 확인만)
  const ordered = top.slice().reverse();                  // 표시용: 덱 위(끝) → 아래 순
  let x = 0; const cards = [];
  for (const card of ordered){
    const d = MC.cardDef(card.defCode || card.code);
    const isMatch = !!(d && d.type === (p.matchType || 'treachery'));
    if (isMatch) x++;
    cards.push({ defCode: card.defCode, name: MC.nameOf(card), isMatch });
  }
  MC.log(G, '조우덱 상위 ' + top.length + '장 확인 [' + cards.map(c=>c.name).join(', ') + '] — ' + (p.matchType || 'treachery') + ' ' + x + '장');
  const amount = x * (p.perMatch || 1);
  // UI 공개 힌트 — 플레이어가 확인한 카드를 직접 볼 수 있게 (리펄서와 동일 패턴). 표시 전용.
  G.fxReveal = { kind:'peek', cards, matchType: (p.matchType || 'treachery'),
                 matchCount: x, perMatch: (p.perMatch || 1), threatRemoved: amount,
                 title: (ctx.card ? MC.nameOf(ctx.card) : '조우덱 확인') };
  if (amount > 0) MC.runEffectList(G, [{ fx:'removeThreat', amount, scheme: ctx.targetScheme || p.scheme }], ctx);
  else MC.log(G, '(' + (p.matchType || 'treachery') + ' 없음 — 위협 제거 없음)');
};

/* 하수인 등장 반응 발동(호크아이 등) — flushMinionReactions의 'fire' 선택지에서 호출.
   p: {allyUid, minionUid, amount, counter?, vfx?}. 동료 카운터 1 소진 후 그 하수인에 피해. */
EFFECTS.minionReactionDamage = function(G, p, ctx){
  const ally = MC.findByUid(G, p.allyUid);
  const minion = MC.findByUid(G, p.minionUid);
  if (!ally || !minion || minion.hp <= 0){ MC.log(G, '반응 대상 없음 — 불발'); return; }
  if (p.counter){
    if ((ally.counters || 0) <= 0){ MC.log(G, (p.counter) + ' 카운터 없음 — 불발'); return; }
    ally.counters = (ally.counters || 0) - 1;
  }
  if (p.vfx) G.fxAllyReaction = { allyUid: ally.uid, targetUid: minion.uid, vfx: p.vfx, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  MC.log(G, MC.nameOf(ally) + ' 등장 반응 발동 — ' + MC.nameOf(minion) + '에 ' + p.amount + ' 피해' +
    (p.counter ? ' (' + p.counter + ' 잔여 ' + (ally.counters || 0) + ')' : ''));
  MC.applyDamage(G, minion, p.amount, { source: ally });
};

/* 트레잇 기준 캐릭터 준비 — p.trait(예:'avenger'). ctx.player가 조종하는 히어로(신분이 트레잇 보유)+동료(trait 보유) 준비.
   어벤져스 어셈블 등. p.scope:'controlled'(기본, 조종 캐릭터만) | 'all'(전 플레이어). */
EFFECTS.readyCharactersByTrait = function(G, p, ctx){
  const trait = String(p.trait || '').toLowerCase();
  const players = p.scope === 'all' ? G.players : [ctx.player || G.players[G.firstPlayer]];
  let n = 0;
  for (const pl of players){
    if (!pl || pl.eliminated) continue;
    if (MC.playerHasTrait(G, pl, trait) && pl.exhausted){ pl.exhausted = false; n++; }
    for (const ally of (pl.playArea.allies || [])){
      if (MC.allyHasTrait(G, ally, trait) && ally.exhausted){ ally.exhausted = false; n++; }
    }
  }
  MC.log(G, trait + ' 캐릭터 ' + n + '명 준비(ready)');
};

/* 트레잇 기준 페이즈 임시 스탯 버프 — p.trait, p.stats({thwart:1,attack:1,...}). 전장의 해당 트레잇 캐릭터(전 플레이어) tempStatBonus 가산.
   페이즈 종료 시 자동 소멸(endPlayerPhase에서 tempStatBonus 초기화). */
EFFECTS.buffCharactersByTrait = function(G, p, ctx){
  const trait = String(p.trait || '').toLowerCase();
  const stats = p.stats || {};
  const add = (obj) => { obj.tempStatBonus = obj.tempStatBonus || {}; for (const k in stats) obj.tempStatBonus[k] = (obj.tempStatBonus[k] || 0) + stats[k]; };
  let n = 0;
  for (const pl of G.players){
    if (!pl || pl.eliminated) continue;
    if (MC.playerHasTrait(G, pl, trait)){ add(pl); n++; }
    for (const ally of (pl.playArea.allies || [])){
      if (MC.allyHasTrait(G, ally, trait)){ add(ally); n++; }
    }
  }
  const label = Object.entries(stats).map(([k,v]) => (v>=0?'+':'') + v + ' ' + k).join(', ');
  MC.log(G, '전장의 ' + trait + ' 캐릭터 ' + n + '명 이번 페이즈 ' + label);
};

/* 원하는 수만큼 동료 소진 → 소진 수만큼 드로우 (수적 우위). 준비된 동료 중 플레이어가 임의 다중 선택.
   준비된 동료가 없으면 no-op. 선택은 allyExhaustDraw pending(토글+확정)으로 처리 — 선택 기능 보존. */
/* 손에서 조건 맞는 동료 1명을 전장에 무료 배치 → 선택 pending (deployAlly).
   trait: 요구 특성(avenger 등). costFromCounters: 소스 카운터 수 이하 인쇄비용만. discardSelfAfter: 배치 후 소스 버림.
   퀸젯 등. 배치 가능 동료 없으면 throw(행동 불발) — 소스 소비 방지. 선택 기능 보존. */
/* 이번 페이즈 다음에 플레이하는 카드 비용 감소 (헬리캐리어 일반화). amount: 감소량.
   allyTrait 지정 시 → 그 특성 동료에만 적용(어벤져스 타워: 다음 Avenger 동료). 필터 미매치 카드엔 할인 미소모(유지). */
/* 플레이어 순서로 각자 조우덱 top 1장 버림 → 버린 카드의 부스트 아이콘 수만큼 그 플레이어에게 피해 (히트 스쿼드).
   drawEncounterCard 재사용(pop=top, 리셔플·가속 처리). 부스트 아이콘 = def.boost. */
/* 빌런 활성화 (Crossbones' Assault: 처치 시 크로스본즈가 그 플레이어를 공격). */
EFFECTS.villainActivate = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (G.villain) MC.enemyActivation(G, G.villain, pl);
};

/* 조우덱 top N장(perHero면 1/영웅) 버림 → 버린 카드 부스트 아이콘 합만큼 지정 스킴에 위협 (Cornered Staff).
   self:true면 ctx.self(이 사이드 스킴)에 배치. */
EFFECTS.discardEncounterBoostToScheme = function(G, p, ctx){
  const n = p.perHero ? (G.players ? G.players.length : 1) : (p.amount || 1);
  let boostSum = 0;
  for (let i = 0; i < n; i++){
    const c = MC.drawEncounterCard ? MC.drawEncounterCard(G) : null;
    if (!c) break;
    boostSum += (MC.cardDef(c.defCode).boost || 0);
    if (G.encounterDiscard) G.encounterDiscard.push(c);
  }
  const scheme = p.self ? (ctx.self || ctx.card) : MC.resolveScheme(G, p.scheme || 'main');
  if (scheme && boostSum > 0){
    scheme.threat = (scheme.threat || 0) + boostSum;
    MC.log(G, MC.nameOf(scheme) + ' — 조우덱 버림 부스트 위협 +' + boostSum);
  }
};

EFFECTS.eachPlayerDiscardEncounterBoostDamage = function(G, p, ctx){
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    const card = MC.drawEncounterCard(G);
    if (!card){ MC.log(G, MC.nameOf(pl) + ' — 조우덱 비어 버릴 카드 없음'); continue; }
    const d = MC.cardDef(card.defCode) || {};
    const boostN = (typeof d.boost === 'number') ? d.boost : 0;
    (G.encounterDiscard = G.encounterDiscard || []).push(card);
    MC.log(G, MC.nameOf(pl) + ' — 조우덱 top 버림: ' + MC.nameOf(card) + ' (부스트 ' + boostN + ')');
    if (boostN > 0) MC.applyDamage(G, pl, boostN, { source: ctx.self || ctx.card });
  }
};

/* 활성 플레이어가 조우덱 top N장 버림 → 버린 카드 부스트 아이콘 합만큼 간접 피해.
   countFrom:'villainAtk'면 N = 빌런 ATK (Full Auto 히어로 분기). Machine Gun(1장)도 재사용. */
/* 조우덱 top부터 특정 trait 카드가 나올 때까지 버림 → 그 카드를 공개(resolveEncounterCard).
   무기고 습격: Weapon 부착물이 나올 때까지 버리고 그 무기를 공개(빌런에 부착). */
EFFECTS.discardEncounterUntilTrait = function(G, p, ctx){
  const trait = String(p.trait || '').toLowerCase();
  let found = null;
  for (let guard = 0; guard < 40; guard++){
    const c = MC.drawEncounterCard(G);
    if (!c) break;
    const d = MC.cardDef(c.defCode) || {};
    if ((d.traits || []).map(t => String(t).toLowerCase()).includes(trait)){ found = c; break; }
    (G.encounterDiscard = G.encounterDiscard || []).push(c);
    MC.log(G, '무기고 습격 — ' + MC.nameOf(c) + ' 버림 (' + trait + ' 아님)');
  }
  if (found){
    MC.log(G, '무기고 습격 — ' + MC.nameOf(found) + ' 공개!');
    if (MC.resolveEncounterCard) MC.resolveEncounterCard(G, found, ctx.player || G.players[G.firstPlayer]);
  } else {
    MC.log(G, '무기고 습격 — 조우덱에서 ' + trait + ' 카드를 찾지 못함');
  }
};

EFFECTS.discardEncounterByCountBoostDamage = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let n = p.amount || 1;
  if (p.countFrom === 'villainAtk') n = G.villain ? MC.enemyAtk(G, G.villain) : 0;
  let boostSum = 0;
  for (let i = 0; i < n; i++){
    const card = MC.drawEncounterCard(G);
    if (!card) break;
    boostSum += (MC.cardDef(card.defCode).boost || 0);
    (G.encounterDiscard = G.encounterDiscard || []).push(card);
  }
  if (boostSum > 0) MC.applyDamage(G, pl, boostSum, { source: ctx.self || ctx.card });
  MC.log(G, MC.nameOf(pl) + ' — 조우덱 ' + n + '장 버림, 부스트 ' + boostSum + ' 간접 피해');
};

EFFECTS.reduceNextPlayCost = function(G, p, ctx){
  const target = (ctx.targetPlayer && G.players.find(x => x.uid === ctx.targetPlayer)) || ctx.player;
  target.nextCardDiscount = (target.nextCardDiscount || 0) + (p.amount || 1);
  if (p.allyTrait) target.nextCardDiscountFilter = { type:'ally', trait: String(p.allyTrait).toLowerCase() };
  else target.nextCardDiscountFilter = null;
  MC.log(G, MC.nameOf(target) + ' — 다음 ' + (p.allyTrait ? p.allyTrait + ' 동료' : '카드') + ' 비용 -' + (p.amount || 1) + ' (이번 페이즈)');
};

// 버림 더미의 카드 1장을 덱 맨 아래로 → 카드 1장 드로우 (아미르 칸 Persona 액션).
// p.pick:'first'(임시 자동) — 후보 여러 장이면 이상적으론 선택이나, 우선 가장 오래된 1장.
EFFECTS.recycleDiscardBottomDraw = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (pl.discard && pl.discard.length){
    const card = pl.discard.shift();               // 가장 아래(오래된) 카드
    (pl.deck = pl.deck || []).push(card);          // 덱 맨 아래로
    MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(card) + '을(를) 덱 맨 아래로 (아미르 칸)');
  } else {
    MC.log(G, MC.nameOf(pl) + ' — 버림 더미 비어있음 (덱 바닥 이동 생략)');
  }
  MC.drawCards(G, pl, 1);
};

EFFECTS.deployAllyFromHand = function(G, p, ctx){
  const pl = ctx.player;
  const src = ctx.card;
  const cap = p.costFromCounters ? (src.counters || 0) : Infinity;
  const trait = p.trait ? String(p.trait).toLowerCase() : null;
  const eligible = (pl.hand || []).filter(c => {
    const d = MC.cardDef(c.defCode);
    if (!d || d.type !== 'ally') return false;
    if (trait && !(d.traits || []).some(t => String(t).toLowerCase() === trait)) return false;
    if ((d.cost || 0) > cap) return false;
    return true;
  });
  if (!eligible.length)
    throw new Error('[deployAllyFromHand] 배치 가능한 동료 없음 (인쇄비용 ' + cap + ' 이하 ' + (p.trait || '') + ' 동료)');
  G.pending = { kind:'deployAlly', player: pl.uid, allyUids: eligible.map(c => c.uid),
                sourceUid: src.uid, discardSource: !!p.discardSelfAfter,
                prompt: p.prompt || '전장에 배치할 동료 선택 (인쇄비용 ' + cap + ' 이하)' };
  MC.log(G, MC.nameOf(src) + ' — 배치할 동료 선택 대기 (후보 ' + eligible.length + ')');
};

EFFECTS.exhaustAlliesForDraw = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const ready = (pl.playArea.allies || []).filter(a => !a.exhausted);
  if (!ready.length){ MC.log(G, '준비된 동료 없음 — 소진/드로우 없음'); return; }
  G.pending = { kind:'allyExhaustDraw', player: pl.uid,
                allyUids: ready.map(a => a.uid), chosen: [],
                prompt: p.prompt || '소진할 동료 선택 (소진한 수만큼 드로우)' };
  MC.log(G, '수적 우위 — 소진할 동료 선택 대기');
};

EFFECTS.removeThreat = function(G, p, ctx){
  // 조건부 제거량 (amountIf: {cond, amount}) — 조건 충족 시 그 값으로 대체
  // (정의를 위해!=멘탈 지불 시 3→4). dealDamage amountIf와 동일 패턴.
  let amount = p.amount;
  if (p.amountFrom === 'lastDamageTaken'){   // You'll Pay for That!: 받은 피해당 위협 제거 (최대 max)
    const plr = ctx.player || G.players[G.firstPlayer];
    amount = Math.min(p.max || 99, plr.lastDamageTaken || 0);
  }
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  amount += (ctx.eventThreatBonus || 0);   // Shrink 등 이벤트 강화 인터럽트 보너스
  // 조건부 광역: allSchemesIf 충족 시 모든 스킴에서 제거 (MK.5 헬멧 Aerial 등)
  if (p.allSchemesIf && MC.condCheck(G, p.allSchemesIf, ctx)){
    MC.removeThreat(G, 'main', amount);
    for (const ss of (G.sideSchemes || []).slice()) MC.removeThreat(G, ss.uid, amount);
    MC.log(G, '(모든 스킴에서 위협 ' + amount + '씩 제거 — Aerial)');
    return;
  }
  // 단일 스킴: ctx.targetScheme(UI 선택) 우선, 없으면 p.scheme 또는 main
  const ref = ctx.targetScheme || p.scheme || 'main';
  // 위기(Crisis): crisis 사이드 스킴이 전장에 있으면 메인 스킴 위협 제거 불가.
  //   단, 저지 효과가 위기 무시(ignoreCrisis)를 명시하면 통과(케이블 화살/위기 회피 등).
  if (ref === 'main' && !p.ignoreCrisis && MC.hasCrisisScheme && MC.hasCrisisScheme(G)){
    MC.log(G, '위기(Crisis) 사이드 스킴 — 메인 스킴 위협 제거 불가 (제거 불발)');
    return;
  }
  MC.removeThreat(G, ref, amount);
};

EFFECTS.applyStatus = function(G, p, ctx){ // stunned | confused | tough
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt){
    // failIfHas: 이미 그 상태면 부여 실패 → failEffect (Hard as Nails: tough 불가 시 3 회복)
    if (p.failIfHas && t.status && t.status[p.status] > 0){
      if (p.failEffect) MC.runEffectList(G, p.failEffect, Object.assign({}, ctx, { targets:[t] }));
    } else {
      MC.setStatus(G, t, p.status, true);
    }
  }
};

/* 라운드 지속 히어로 스탯 버프 (사기 증진 등). p:{ stats:{thwart?,attack?,defense?,...} }.
   대상 = ctx.targetPlayer(멀티 선택) 또는 시전자 본인의 히어로. roundStatBonus에 누적 → 라운드 종료 시 소멸.
   statOf가 roundStatBonus를 합산하므로 신규 집계 코드 불필요 — 데이터로만 표현. */
EFFECTS.roundStatBuff = function(G, p, ctx){
  const target = (ctx.targetPlayer && G.players.find(q => q.uid === ctx.targetPlayer)) || ctx.player;
  target.roundStatBonus = target.roundStatBonus || {};
  const stats = p.stats || {};
  for (const st in stats) target.roundStatBonus[st] = (target.roundStatBonus[st] || 0) + stats[st];
  MC.log(G, MC.nameOf(target) + ' 라운드 버프 ' +
    Object.keys(stats).map(k => k + '+' + stats[k]).join('/') + ' (라운드 종료까지)');
};

EFFECTS.readyTarget = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt) t.exhausted = false;
};

EFFECTS.exhaustTarget = function(G, p, ctx){
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt) t.exhausted = true;
};

// 특정 카드(defCode/slug 또는 mcode)를 준비(ready) — 호크아이 Quick Draw가 "호크아이의 활"을 준비 등. 소진된 첫 카드 1장.
EFFECTS.readyNamedCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl) return false;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies]){
    const c = arr.find(x => x.exhausted && (x.defCode === p.card || (p.mcode && MC.cardDef(x.defCode) && MC.cardDef(x.defCode).mcode === p.mcode)));
    if (c){ c.exhausted = false; MC.log(G, MC.nameOf(c) + ' 준비'); return true; }
  }
  MC.log(G, '(' + (p.card || p.mcode) + ' 준비할 카드 없음 — 이미 준비되었거나 인플레이 없음)');
  return false;
};

// 특정 카드(defCode/slug)를 비용으로 소진 — 방패 막기가 "캡틴아메리카의 방패"를 소진 등. 준비된 첫 카드 1장.
EFFECTS.exhaustNamedCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl) return false;
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports, pl.playArea.allies]){
    const c = arr.find(x => x.defCode === p.card && !x.exhausted);
    if (c){ c.exhausted = true; MC.log(G, MC.nameOf(c) + ' 소진 (비용)'); return true; }
  }
  MC.log(G, '(' + p.card + ' 준비된 카드 없음 — 소진 불가)');
  return false;
};

// 통제하는 모든 동료 소진 (멜터 부스트★): ctx.player의 동료 전부 exhausted. 대상 미지정 시 전 플레이어.
EFFECTS.exhaustAllAllies = function(G, p, ctx){
  const players = ctx.player ? [ctx.player] : MC.playersInOrder(G);
  let n = 0;
  for (const pl of players) for (const a of pl.playArea.allies){ if (!a.exhausted){ a.exhausted = true; n++; } }
  if (n) MC.log(G, '멜터 부스트★ — 동료 ' + n + '명 소진');
};

// 통제하는 모든 캐릭터(히어로 자신 + 동료) 소진 — "각 캐릭터를 소진" 배신(소닉 붐 등).
// exhaustAllAllies와 분리: 그건 동료 전용 + 멜터 전용 로그라 히어로 포함 불가. 범용 로그 사용.
EFFECTS.exhaustControlled = function(G, p, ctx){
  const players = ctx.player ? [ctx.player] : MC.playersInOrder(G);
  let n = 0;
  for (const pl of players){
    if (!pl.exhausted){ pl.exhausted = true; n++; }                 // 히어로 자신
    for (const a of pl.playArea.allies){ if (!a.exhausted){ a.exhausted = true; n++; } }  // 동료
  }
  if (n) MC.log(G, MC.nameOf(ctx.self || { name: '효과' }) + ' — 통제 캐릭터 ' + n + '명 소진');
};

// 신분 카드 소진 — Exhaustion(01191). 활성 플레이어의 신분(정체성) 카드를 소진 상태로.
EFFECTS.exhaustIdentity = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.exhausted = true;
  MC.log(G, MC.nameOf(pl) + ' 신분 카드 소진 (Exhaustion)');
};

// 조우덱에서 사이드 스킴이 나올 때까지 버리고 그 사이드 스킴을 전장에 공개 — Masterplan(01192) 폴백.
EFFECTS.discardUntilSideScheme = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let guard = G.encounterDeck.length + G.encounterDiscard.length + 1;
  let found = null;
  while (guard-- > 0){
    const c = MC.drawEncounterCard(G);
    if (!c) break;
    if (c.type === 'side_scheme' || c.type === 'sideScheme'){ found = c; break; }
    G.encounterDiscard.push(c);
    MC.log(G, MC.nameOf(c) + ' 버림 (사이드 스킴 탐색 중)');
  }
  if (!found){ MC.log(G, '조우덱에 사이드 스킴 없음 — 효과 불발'); return; }
  found.threat = found.threat || 0;
  (G.sideSchemes = G.sideSchemes || []).push(found);
  MC.log(G, '사이드 스킴 ' + MC.nameOf(found) + ' 전장 공개 (Masterplan)');
  MC.fireCardHook(G, found, 'whenRevealed', { player: pl });
};

// Shadow of the Past(01190): 셋어사이드된 넴시스 하수인·사이드스킴을 전장에 투입, 나머지는 조우덱에 셔플.
// 하수인이 등장하지 못하면(이미 전장/제거 등) ctx._nemesisMinionEntered=false → 호출부 surge.
EFFECTS.revealNemesisSet = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const aside = pl.nemesisSetAside || [];
  let minionEntered = false;
  const remaining = [];
  for (const card of aside){
    if (card._nemesisRole === 'minion'){
      // 이미 같은 넴시스 하수인이 전장에 있으면 재투입하지 않음 (중복 방지)
      const already = G.players.some(q => (q.engagedMinions || []).some(m => (m.defCode || m.code) === (card.defCode || card.code) && m.hp > 0));
      if (already){ remaining.push(card); continue; }
      card.type = 'minion';
      card.engagedWith = pl.uid;
      card.status = card.status || { stunned:0, confused:0, tough:0 };
      pl.engagedMinions.push(card);
      MC.minionEnteredPlay(G, card, pl);
      (G.revealLog = G.revealLog || []).push({ defCode: card.defCode, name: card.name, type:'minion', player: pl.uid });
      minionEntered = true;
      MC.log(G, '넴시스 하수인 ' + MC.nameOf(card) + ' 전장 투입 (' + pl.uid + '와 교전)');
      MC.fireCardHook(G, card, 'whenRevealed', { player: pl });
    } else if (card._nemesisRole === 'sideScheme'){
      const ss = card;
      ss.threat = ss.threat || 0;
      (G.sideSchemes = G.sideSchemes || []).push(ss);
      MC.log(G, '넴시스 사이드 스킴 ' + MC.nameOf(ss) + ' 전장 공개');
      MC.fireCardHook(G, ss, 'whenRevealed', { player: pl });
    } else {
      remaining.push(card);   // 나머지(배신/부착)는 조우덱으로
    }
  }
  // 나머지를 조우덱에 섞기
  if (remaining.length){
    for (const c of remaining){ c._nemesisRole = undefined; G.encounterDeck.push(c); }
    MC.shuffle(G, G.encounterDeck);
    MC.log(G, '나머지 넴시스 조우 카드 ' + remaining.length + '장 조우덱에 셔플');
  }
  pl.nemesisSetAside = [];
  ctx._nemesisMinionEntered = minionEntered;
  G._nemesisMinionEntered = minionEntered;
};

// 빌런과 활성 플레이어와 교전 중인 각 하수인이 그 플레이어를 공격 — Gang-Up(01189).
// 빌런을 체인 맨 앞에 넣고, 이어서 교전 하수인들을 순서대로 공격시킨다(startMinionAttackChain 재사용).
EFFECTS.villainAndMinionsAttack = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const pairs = [];
  if (G.villain && G.villain.hp > 0) pairs.push({ attackerUid: G.villain.uid, playerUid: pl.uid });
  for (const m of (pl.engagedMinions || [])){
    if (m.hp > 0) pairs.push({ attackerUid: m.uid, playerUid: pl.uid });
  }
  if (pairs.length){
    MC.log(G, MC.nameOf(pl) + '에게 집중 공격 — 빌런 + 교전 하수인 ' + (pairs.length - 1) + '명');
    MC.startMinionAttackChain(G, pairs);
  }
};

// 통제하는 업그레이드 또는 지원 1장 버림 (영구/부착 제외) — Caught Off Guard(01188).
// 공식: 소유 플레이어가 어느 카드를 버릴지 선택. 후보 0=급증 / 1=자동 / 2+=플레이어 선택(pickControlledDiscard).
// 버린 게 없으면(후보 0) surge 판정용 플래그를 false로. 후보 있으면 반드시 1장 버려지므로 선판정 true.
EFFECTS.discardUpgradeOrSupport = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const cands = [];
  const arrs = p.onlyType === 'support' ? [pl.playArea.supports || []]
             : p.onlyType === 'upgrade' ? [pl.playArea.upgrades || []]
             : [pl.playArea.upgrades || [], pl.playArea.supports || []];
  for (const arr of arrs){
    for (const c of arr){
      const d = MC.cardDef(c.defCode || c.code) || {};
      if (!d.permanent && !c.attachedTo && !c.hostUid) cands.push(c);   // 영구·부착물 제외
    }
  }
  if (!cands.length){
    ctx._discardedCard = false; G._discardedUpgradeOrSupport = false;
    MC.log(G, '버릴 업그레이드/지원 없음 — 급증(Surge)');
    return;
  }
  ctx._discardedCard = true; G._discardedUpgradeOrSupport = true;   // 후보 있음 → 반드시 버려짐(급증 없음, 선판정)
  if (cands.length === 1){ MC.discardControlledCard(G, pl, cands[0], 'Caught Off Guard'); return; }
  // 2장 이상 → 무작위 아님 → 플레이어가 직접 선택
  G.pending = { kind:'pickControlledDiscard', player: pl.uid,
                cardUids: cands.map(c => c.uid),
                prompt: p.prompt || '버릴 업그레이드/지원 1장 선택' };
  MC.log(G, MC.nameOf(pl) + ' — 버릴 장비 선택 대기 (' + cands.length + '장 중 1장)');
};

// 통제하는 모든 업그레이드 소진 — 사업 문제(01170) 등. ctx.player 기준.
EFFECTS.exhaustAllUpgrades = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let n = 0;
  for (const up of (pl.playArea.upgrades || [])){ if (!up.exhausted){ up.exhausted = true; n++; } }
  MC.log(G, '통제 업그레이드 ' + n + '개 소진 (의무 해결)');
};

// 선택 배신 범용화 — 플레이어 선택 pending(revealChoice)을 데이터로 세운다.
// 커스텀 핸들러(rev_hydraBomber 등) 없이 effects:[{fx:'offerChoice', prompt, options:[...]}]로 선언.
// options: [{ key, label, effects:[...], payIcons:{energy:1,...} }]. payIcons 지불은 resolveRevealChoice가 처리.
EFFECTS.offerChoice = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const self = ctx.self || ctx.card;
  // 옵션별 availableIf 조건 필터 (예: 신분이 준비 상태일 때만 "소진→제거" 옵션 제공)
  const opts = (p.options || []).filter(o => !o.availableIf || MC.condCheck(G, o.availableIf, { player: pl, card: self, self }));
  G.pending = { kind: 'revealChoice', player: pl.uid,
                selfUid: self ? self.uid : null,
                prompt: p.prompt || '선택하세요', options: opts.length ? opts : (p.options || []) };
  MC.log(G, MC.nameOf(self || { name: '조우 카드' }) + ' 공개 — 선택 대기');
};

// 통제 중인 업그레이드 1장 버림 — p.hero 지정 시 그 영웅 시그니처 업그레이드만(블랙 팬서 의무 등).
// 공식: 소유 플레이어 선택. 후보 0=no-op(호출부 surge) / 1=자동 / 2+=플레이어 선택. 버린 여부를 ctx._discardedUpgrade.
EFFECTS.discardControlledUpgrade = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const ups = pl.playArea.upgrades || [];
  const cands = ups.filter(u => {
    const d = MC.cardDef(u.defCode || u.code);
    return d && (!p.hero || d.hero === p.hero) && (!p.trait || (d.traits || []).includes(p.trait))
             && !d.permanent && !u.attachedTo && !u.hostUid;
  });
  if (!cands.length){ ctx._discardedUpgrade = false; MC.log(G, '버릴 ' + (p.hero || '') + ' 업그레이드 없음'); return; }
  ctx._discardedUpgrade = true;   // 후보 있음 → 반드시 버려짐(선판정)
  if (cands.length === 1){ MC.discardControlledCard(G, pl, cands[0], '의무 해결'); return; }
  G.pending = { kind:'pickControlledDiscard', player: pl.uid,
                cardUids: cands.map(c => c.uid),
                prompt: p.prompt || '버릴 업그레이드 1장 선택' };
  MC.log(G, MC.nameOf(pl) + ' — 버릴 업그레이드 선택 대기 (' + cands.length + '장 중 1장)');
};

// 공용: 통제 중인 카드(업그레이드/지원/동료) 1장을 플레이 영역에서 제거 → 버림 더미로.
MC.discardControlledCard = function(G, pl, card, reason){
  for (const key of ['upgrades', 'supports', 'allies']){
    const arr = pl.playArea[key]; if (!arr) continue;
    const i = arr.indexOf(card);
    if (i >= 0){
      arr.splice(i, 1);
      if (MC.moveToDiscard) MC.moveToDiscard(G, pl, card, {});
      else (pl.discard = pl.discard || []).push(card);
      MC.log(G, MC.nameOf(card) + ' 버림' + (reason ? ' (' + reason + ')' : ''));
      return true;
    }
  }
  return false;
};

// 손패에서 자원 아이콘 가진 카드 후보 (types 지정 시 그 타입 또는 wild, 미지정 시 아무 자원).
MC.resourceCandidates = function(pl, types){
  return (pl.hand || []).filter(c => {
    const ic = MC.resourceIconsOf(c) || {};
    if (!types || !types.length) return Object.values(ic).some(v => v > 0);   // 아무 자원
    return types.some(t => (ic[t] || 0) > 0) || (ic.wild || 0) > 0;
  });
};
// 손패 카드 1장 버림 (제거+버림더미).
MC.discardHandCard = function(G, pl, card){
  const i = (pl.hand || []).indexOf(card); if (i < 0) return false;
  pl.hand.splice(i, 1);
  if (MC.moveToDiscard) MC.moveToDiscard(G, pl, card, {});
  else (pl.discard = pl.discard || []).push(card);
  return true;
};
// 손패 자원 카드 선택 버림 pending 셋업 (다중 플레이어 큐). 후보 0=스킵, ≤필요=자동 전부, >필요=플레이어 선택.
// ctx: { queue:[uid...], perPlayerCount, types|null, prompt, reason }. pending 세우면 true, 전부 자동처리면 false.
MC.setupResourceDiscardPick = function(G, spec){
  const findPl = uid => G.players.find(p => p.uid === uid);
  while (spec.queue.length){
    const uid = spec.queue[0];
    const pl = findPl(uid);
    if (!pl || pl.eliminated){ spec.queue.shift(); continue; }
    const cands = MC.resourceCandidates(pl, spec.types);
    if (!cands.length){                                   // 자원 없음 → 스킵 (if able)
      MC.log(G, MC.nameOf(pl) + ' — 버릴 자원 없음' + (spec.reason ? ' (' + spec.reason + ')' : ''));
      spec.queue.shift(); continue;
    }
    const need = Math.min(spec.perPlayerCount, cands.length);
    if (cands.length <= need){                            // 후보 ≤ 필요 → 전부 자동 (선택 의미 없음)
      for (const c of cands.slice()){ MC.discardHandCard(G, pl, c); MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 버림' + (spec.reason ? ' (' + spec.reason + ')' : '')); }
      spec.queue.shift(); continue;
    }
    G.pending = { kind:'resourceDiscardPick', player: uid, count: need, chosen: 0,
                  types: spec.types || null, queue: spec.queue.slice(1),
                  perPlayerCount: spec.perPlayerCount, prompt: spec.prompt || '버릴 자원 카드 선택', reason: spec.reason };
    return true;
  }
  return false;
};

// 의무(Obligation) 카드 자체 처리 — p.mode:'game'(게임에서 영구 제거) / 'discard'(조우 버림).
// ctx.self가 의무 카드. obligationsOut에서도 제거. p.surgeIfNoDiscard면 직전 버림 실패 시 surge.
/* 알터에고 폼으로 전환 (카드 부여 전환 — 라운드 1회 제한 무시, force). 이미 알터에고면 no-op.
   맨 아웃 오브 타임 등 "알터에고로 전환 가능" 의무. */
/* 형태 강제 변경(토글) — 내면의 악마: 현재 폼의 반대로 뒤집기. */
EFFECTS.changeForm = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  MC.flipForm(G, pl, { force: true });
  MC.log(G, MC.nameOf(pl) + ' — 형태 강제 변경');
};
/* 히어로(신분) 소진 — 내면의 악마(헐크면 소진). */
EFFECTS.exhaustPlayer = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  pl.exhausted = true;
  MC.log(G, MC.nameOf(pl) + ' — 히어로 소진');
};

EFFECTS.flipToAlterEgo = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (pl.form === 'alter-ego'){ MC.log(G, '이미 알터에고 폼'); return; }
  MC.flipForm(G, pl, { force: true });
  MC.log(G, MC.nameOf(pl) + ' — 알터에고 폼으로 전환 (의무)');
};

/* 손패에서 원하는 카드 N장(또는 절반 내림) 선택 버림 → 완료 후 afterEffects 실행. 선택식(discardChoose pending).
   맨 아웃 오브 타임(손패 절반) 등. countHalf:true면 floor(hand/2). N=0이면 즉시 afterEffects. */
EFFECTS.discardChooseFromHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const self = ctx.self || ctx.card;
  const n = p.countHalf ? Math.floor((pl.hand || []).length / 2) : (p.count || 0);
  const after = p.afterEffects || [];
  if (n <= 0){
    MC.log(G, '버릴 카드 없음 — 후속 효과로');
    if (after.length) MC.runEffectList(G, after, { player: pl, self, card: self, targetScheme:'main' });
    return;
  }
  G.pending = { kind:'discardChoose', player: pl.uid, remaining: n, total: n, chosen: [],
                selfUid: self ? self.uid : null, afterEffects: after,
                prompt: p.prompt || ('손패에서 ' + n + '장 선택하여 버리기') };
  MC.log(G, MC.nameOf(pl) + ' — 손패 ' + n + '장 선택 버림 대기');
};

/* 특정 slug 카드를 손 또는 전장(업그레이드)에서 버림 — 오딘의 분노(묠니르 버림). 대상 = ctx.player(의무 소유자). */
/* 각 플레이어 덱 상단 N장 버림 → 버려진 카드의 서로 다른 타입 종류 수만큼 메인 스킴 위협 추가 (속임수 06030). */
EFFECTS.discardTopCountTypes = function(G, p, ctx){
  const n = p.count || 3;
  const types = new Set();
  for (const pl of G.players){
    for (let i = 0; i < n && pl.deck.length; i++){
      const c = pl.deck.pop();
      pl.discard.push(c);
      const d = MC.cardDef(c.defCode);
      if (d && d.type) types.add(d.type);
      MC.log(G, MC.nameOf(pl) + ' 덱 상단 ' + MC.nameOf(c) + ' 버림 (' + (d ? d.type : '?') + ')');
    }
  }
  const count = types.size;
  if (count > 0){ MC.placeThreat(G, 'main', count); MC.log(G, '속임수 — 서로 다른 타입 ' + count + '종 → 메인 스킴 위협 +' + count); }
  else MC.log(G, '속임수 — 버린 카드 없음 (위협 추가 없음)');
};

/* 이 스킴(ctx.self)에 위협 직접 추가 — Killer for Hire(공개 시 +1). */
EFFECTS.addSelfThreat = function(G, p, ctx){
  const s = ctx.self || ctx.card || (G.sideSchemes && G.sideSchemes[G.sideSchemes.length - 1]);
  if (s){ s.threat = (s.threat || 0) + (p.amount || 1); MC.log(G, MC.nameOf(s) + ' 위협 +' + (p.amount || 1) + ' (' + s.threat + ')'); }
};

/* 전장의 특정 트레잇 카드 수만큼 이 스킴(ctx.self)에 위협 추가 — 가족의 불화(Asgard 카드 1장당 +1). */
EFFECTS.countTraitAddThreat = function(G, p, ctx){
  const trait = p.trait;
  let count = 0;
  for (const pl of G.players)
    for (const arr of [pl.playArea.allies || [], pl.playArea.upgrades || [], pl.playArea.supports || []])
      for (const c of arr){ const d = MC.cardDef(c.defCode); if (d && (d.traits || []).includes(trait)) count++; }
  const s = ctx.self || ctx.card || (G.sideSchemes && G.sideSchemes[G.sideSchemes.length - 1]);
  if (s && count > 0){ s.threat = (s.threat || 0) + count; MC.log(G, MC.nameOf(s) + ' — ' + trait + ' 카드 ' + count + '장 → 위협 +' + count + ' (' + s.threat + ')'); }
  else MC.log(G, '(' + trait + ' 카드 없음 — 위협 추가 없음)');
};

EFFECTS.discardNamedCard = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const slug = p.card;
  let idx = pl.hand.findIndex(c => c.defCode === slug);
  if (idx >= 0){ const c = pl.hand.splice(idx, 1)[0]; MC.moveToDiscard(G, pl, c, {}); MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 손에서 버림'); ctx._discardedNamed = true; return; }
  idx = (pl.playArea.upgrades || []).findIndex(c => c.defCode === slug);
  if (idx >= 0){ const c = pl.playArea.upgrades.splice(idx, 1)[0]; MC.moveToDiscard(G, pl, c, {}); MC.log(G, MC.nameOf(pl) + ' — ' + MC.nameOf(c) + ' 전장에서 버림'); ctx._discardedNamed = true; return; }
  MC.log(G, '(' + slug + ' 없음 — 버릴 대상 없음)'); ctx._discardedNamed = false;
};

EFFECTS.resolveObligation = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const pl = ctx.player;
  if (p.surgeIfNoDiscard && ctx._discardedUpgrade === false){
    G.pendingSurge = (G.pendingSurge || 0) + 1;
    MC.log(G, '의무 — 버릴 업그레이드 없음 → 급증(Surge)');
  }
  if (p.mode === 'game'){
    (G.removedFromGame = G.removedFromGame || []).push(self ? (self.defCode || self.code) : null);
    // 조우 영역에서 실제 인스턴스 제거 (게임에서 영구 제거 — 버린더미/덱에 남지 않도록)
    if (self){
      for (const zone of ['encounterDiscard','encounterDeck']){
        const arr = G[zone]; if (!arr) continue;
        const i = arr.indexOf(self); if (i >= 0){ arr.splice(i, 1); break; }
      }
    }
    MC.log(G, '의무 해결 — 게임에서 영구 제거');
  } else {
    // 조우 버린더미로 (이미 있으면 중복 방지)
    if (self && G.encounterDiscard && !G.encounterDiscard.includes(self)) G.encounterDiscard.push(self);
    MC.log(G, '의무 카드 버림');
  }
  if (pl && self) pl.obligationsOut = (pl.obligationsOut || []).filter(u => u !== self.uid);
};

/* ── 페르소나(Persona) 지원 처리 — 미즈마블 네메시스 공통. persona 트레잇 support가 대상. ── */
// 전장 인플레이 페르소나 지원 목록 (모든 플레이어)
function personaSupports(G){
  const out = [];
  for (const pl of G.players)
    for (const s of (pl.playArea.supports || [])){
      const d = MC.cardDef(s.defCode);
      if (d && (d.traits || []).includes('persona')) out.push({ owner: pl, card: s });
    }
  return out;
}
// 페르소나 지원 1장 버림 (home-by-dawn). 버렸으면 ctx._discardedUpgrade=true (resolveObligation surgeIfNoDiscard 재사용).
EFFECTS.discardPersonaSupport = function(G, p, ctx){
  const list = personaSupports(G);
  if (!list.length){ ctx._discardedUpgrade = false; MC.log(G, '버릴 페르소나 지원 없음'); return; }
  const { owner, card } = list[0];
  const arr = owner.playArea.supports;
  const i = arr.indexOf(card); if (i >= 0) arr.splice(i, 1);
  MC.moveToDiscard(G, owner, card, {});
  ctx._discardedUpgrade = true;
  MC.log(G, MC.nameOf(card) + ' — 페르소나 지원 버림 (Home by Dawn)');
};
// 전장의 (동료 + 페르소나 지원) 수만큼 각 플레이어 덱 상단 버림 (generation-why).
EFFECTS.millPerAllyAndPersona = function(G, p, ctx){
  let n = 0;
  for (const pl of G.players){
    n += (pl.playArea.allies || []).length;
    for (const s of (pl.playArea.supports || [])){
      const d = MC.cardDef(s.defCode);
      if (d && (d.traits || []).includes('persona')) n++;
    }
  }
  if (n <= 0){ MC.log(G, '동료·페르소나 없음 — 버릴 카드 없음'); return; }
  for (const pl of G.players){
    for (let i = 0; i < n && pl.deck.length; i++){
      const c = pl.deck.shift();
      MC.moveToDiscard(G, pl, c, {});
    }
    MC.log(G, MC.nameOf(pl) + ' — 덱 상단 ' + n + '장 버림 (Generation Why?)');
  }
};
// 각 페르소나 지원 소진 → 소진 수만큼 빌런 회복. 0장이면 surge (harvest).
EFFECTS.exhaustPersonaHealVillain = function(G, p, ctx){
  const list = personaSupports(G);
  let n = 0;
  for (const { card } of list){ if (!card.exhausted){ card.exhausted = true; n++; } }
  if (n > 0){
    MC.healTarget(G, G.villain, n);
    MC.log(G, '페르소나 지원 ' + n + '개 소진 → 빌런 ' + n + ' 회복 (Harvest)');
  } else {
    G.pendingSurge = (G.pendingSurge || 0) + 1;
    MC.log(G, '소진할 페르소나 지원 없음 → 급증(Surge)');
  }
};

// 교전 중인(또는 활성) 플레이어에게 조우 카드 N장 지급 — 하이드라 솔저 처치 시 등.
EFFECTS.dealEncounterToEngaged = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const n = p.count || 1;
  if (MC.dealEncounterTo) MC.dealEncounterTo(G, pl, n);
  MC.log(G, pl.uid + '에게 조우 카드 ' + n + '장 지급 (하이드라 솔저 처치)');
}

/* 각 플레이어에게 조우 카드 N장씩 배분 — 태스크마스터 II/III When Revealed "deal each player an encounter card". 범용. */
EFFECTS.dealEncounterEachPlayer = function(G, p, ctx){
  const n = p.count || 1;
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    if (MC.dealEncounterTo) MC.dealEncounterTo(G, pl, n);
  }
  MC.log(G, '각 플레이어에게 조우 카드 ' + n + '장씩 배분');
};

/* 각 플레이어가 조우덱/버린더미에서 특정 특성(trait) 또는 코드(code)의 하수인 1명을 찾아 교전 배치.
   그 후 조우덱 셔플 — 하이드라 순찰대(04154) 처치 시 각 플레이어 하이드라 하수인 소환. 범용. */
EFFECTS.searchMinionEachPlayer = function(G, p, ctx){
  let any = false;
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    const m = MC.searchMinionIntoPlay(G, pl, p.trait || null, p.code || null);
    if (m) any = true;
  }
  if (any && MC.shuffle) MC.shuffle(G, G.encounterDeck);
  MC.log(G, '각 플레이어 ' + (p.trait || p.code || '') + ' 하수인 소환 — 조우덱 셔플');
};;

// 특정 named 하수인이 전장에 없으면 조우덱/버림 탐색(없으면 정의로 생성)해 활성 플레이어와 교전 배치 — Legions of Hydra(01180) 등.
EFFECTS.summonNamedMinionIfAbsent = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const code = p.code;
  const present = G.players.some(x => (x.engagedMinions || []).some(m => (m.defCode || m.code) === code && m.hp > 0));
  if (present){ MC.log(G, code + ' 이미 전장에 있음 — 소환 생략'); return; }
  if (MC.searchMinionIntoPlay) MC.searchMinionIntoPlay(G, pl, null, code);
}

// ★ 각 플레이어가 조우덱/버림에서 특정 트레잇 하수인 1명을 탐색해 자신과 교전 배치 (범용).
//   Hydra Patrol(04154) 처치 시 각 플레이어가 Hydra 하수인 소환. p:{ trait?, code? }.
EFFECTS.searchMinionEachPlayer = function(G, p, ctx){
  for (const pl of MC.playersInOrder(G).filter(x => !x.eliminated)){
    if (MC.searchMinionIntoPlay) MC.searchMinionIntoPlay(G, pl, p.trait || null, p.code || null);
  }
  MC.log(G, '각 플레이어 ' + (p.trait || '') + ' 하수인 탐색 소환');
};;

// 전장의 특정 트레잇 적 수 × 배수만큼 이 사이드 스킴(ctx.self)에 위협 — Legions of Hydra: 히드라 적 수 ×2.
EFFECTS.placeThreatPerEnemyTrait = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const trait = (p.trait || '').toLowerCase();
  const mult = p.mult || 1;
  let count = 0;
  if (G.villain && ((MC.cardDef(G.villain.defCode).traits) || []).map(t => t.toLowerCase()).includes(trait)) count++;
  for (const pl of G.players){
    for (const m of (pl.engagedMinions || [])){
      if (m.hp > 0 && ((MC.cardDef(m.defCode).traits) || []).map(t => t.toLowerCase()).includes(trait)) count++;
    }
  }
  const amount = count * mult;
  if (self && amount > 0){ MC.placeThreat(G, self.uid, amount); MC.log(G, trait + ' 적 ' + count + '명 × ' + mult + ' → 위협 +' + amount); }
  else MC.log(G, trait + ' 적 없음 — 추가 위협 없음');
};

// 활성 플레이어 손패에서 자원 아이콘을 가진 카드를 모두 버림 — 욘-로그의 반역(01179).
// 마챔 규칙: 거의 모든 플레이어 카드가 자원 아이콘을 가지므로 사실상 손패 대부분을 버림.
// 버린 카드 수를 ctx._treasonDiscarded에 기록(0이면 호출부에서 surge).
EFFECTS.discardAllResourcesFromHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const keep = [], discarded = [];
  for (const card of (pl.hand || [])){
    const d = MC.cardDef(card.defCode) || {};
    const res = d.resources || {};
    const hasResource = ['physical', 'mental', 'energy', 'wild'].some(t => (res[t] || 0) > 0);
    if (hasResource) discarded.push(card); else keep.push(card);
  }
  pl.hand = keep;
  for (const c of discarded) (pl.discard = pl.discard || []).push(c);
  ctx._treasonDiscarded = discarded.length;
  G._treasonDiscarded = discarded.length;
  MC.log(G, pl.uid + ' 손패 자원 카드 ' + discarded.length + '장 버림 (욘-로그의 반역)');
};

// 각 플레이어 덱 top N장 버림 → 버린 카드의 인쇄 에너지(⚡) 자원 총량만큼 그 플레이어 피해 — 전자기 반발(01174).
EFFECTS.discardTopEnergyDamage = function(G, p, ctx){
  const n = p.count || 5;
  for (const pl of G.players){
    let energy = 0, cnt = 0;
    for (let i = 0; i < n && pl.deck.length; i++){
      const card = pl.deck.pop();
      (pl.discard = pl.discard || []).push(card);
      const d = MC.cardDef(card.defCode) || {};
      energy += ((d.resources || {}).energy || 0);
      cnt++;
    }
    MC.log(G, pl.uid + ' 덱 top ' + cnt + '장 버림 — 에너지 자원 ' + energy);
    if (energy > 0) MC.applyDamage(G, pl, energy, {});
  }
};

// 각 플레이어 손패 무작위 1장 버림 → 버린 카드들의 서로 다른 자원 종류 수만큼 메인 스킴 위협 — 벌처의 계략(01169).
EFFECTS.discardRandomCountResources = function(G, p, ctx){
  const types = new Set();
  for (const pl of G.players){
    if (!pl.hand || !pl.hand.length) continue;
    const idx = Math.floor(MC.rand(G) * pl.hand.length);
    const [card] = pl.hand.splice(idx, 1);
    (pl.discard = pl.discard || []).push(card);
    const d = MC.cardDef(card.defCode) || {};
    const res = d.resources || {};
    for (const t of ['physical', 'mental', 'energy', 'wild']) if (res[t] > 0) types.add(t);
    MC.log(G, pl.uid + ' 손패 1장(' + MC.nameOf(card) + ') 무작위 버림');
  }
  const X = types.size;
  G._vulturePlansX = X;
  if (X > 0) MC.placeThreat(G, 'main', X);
  MC.log(G, '서로 다른 자원 ' + X + '종 → 메인 스킴 위협 +' + X);
};

// 이 활성화가 우호 캐릭터에 피해를 주면 그 캐릭터를 기절 — 급강하 습격(01168) 부스트★. 플래그로 표시.
EFFECTS.setBoostStunOnDamage = function(G, p, ctx){
  G._boostStunOnDamage = true;
  MC.log(G, '급강하 습격 부스트★ — 이 활성화 피해 대상 기절 예약');
};

// 각 플레이어 손패 무작위 1장을 이 사이드 스킴(ctx.self)에 뒷면 보관 — 노상 강도(01166). 소유자 기록.
EFFECTS.storeRandomFromEachHand = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  if (!self) return;
  self.storedCards = self.storedCards || [];
  for (const pl of G.players){
    if (!pl.hand || !pl.hand.length) continue;
    const idx = Math.floor(MC.rand(G) * pl.hand.length);
    const [card] = pl.hand.splice(idx, 1);
    card._storedOwner = pl.uid;
    self.storedCards.push(card);
    MC.log(G, pl.uid + ' 손패 1장(' + MC.nameOf(card) + ') → ' + MC.nameOf(self) + '에 보관');
  }
};

// 보관된 카드를 각 소유자 손으로 반환 — 노상 강도 처치 시.
EFFECTS.returnStoredCards = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const stored = (self && self.storedCards) || [];
  for (const card of stored){
    const pl = G.players.find(x => x.uid === card._storedOwner);
    if (pl){ pl.hand.push(card); MC.log(G, MC.nameOf(card) + ' → ' + pl.uid + ' 손으로 반환'); }
  }
  if (self) self.storedCards = [];
};

// 타이타니아의 분노(01164): 전장의 타이타니아가 활성 플레이어 히어로를 공격(동적 ATK).
//   타이타니아가 없거나 공격 불가(기절)면 → (있으면)완전 회복 + 이 카드 surge.
EFFECTS.titaniaFury = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const self = ctx.self || ctx.card;
  let titania = null;
  for (const p2 of G.players){
    const m = (p2.engagedMinions || []).find(x => (x.defCode || x.code) === 'titania' && x.hp > 0);
    if (m){ titania = m; break; }
  }
  const canAttack = titania && !(titania.status && titania.status.stunned > 0);
  if (canAttack){
    const atk = MC.enemyAtk(G, titania);
    MC.applyDamage(G, pl, atk, { source: titania });
    MC.log(G, '타이타니아가 히어로를 공격 (' + atk + ' 피해)');
  } else {
    if (titania){
      titania.hp = MC.cardDef('titania').hp + (titania.maxHp ? (titania.maxHp - MC.cardDef('titania').hp) : 0);
      titania.hp = titania.maxHp || MC.cardDef('titania').hp;
      MC.log(G, '타이타니아 완전 회복');
    }
    if (self) self.surge = true;
    MC.log(G, '타이타니아 공격 불가 — 급증(Surge)');
  }
};

// 빌런 활성화에 부스트 카드 1장 추가(플래그 G._extraBoostThisActivation). 타이타니아의 분노 부스트★ 등.
EFFECTS.addVillainBoostCard = function(G, p, ctx){
  G._extraBoostThisActivation = (G._extraBoostThisActivation || 0) + (p.amount || 1);
  MC.log(G, '빌런 활성화 부스트 카드 +' + (p.amount || 1));
};

// 인쇄 HP가 가장 높은 하수인에 부착물(ctx.self) 부착 — 유전자 강화(01163). 하수인 없으면 surge.
// attachTo가 def.attachStats({hp,maxHp})를 자동 적용.
EFFECTS.attachToHighestHpMinion = function(G, p, ctx){
  const self = ctx.self || ctx.card;
  const selfCode = self && self.defCode;
  let minions = [];
  for (const pl of G.players) minions.push(...(pl.engagedMinions || []));
  // excludeSameAttachment: 이미 같은 종류의 부착물이 붙은 하수인은 제외 (Biomechanical Upgrades 중복 불가).
  if (p.excludeSameAttachment && selfCode){
    minions = minions.filter(m => !(m.attachments || []).some(a => a.defCode === selfCode));
  }
  if (!minions.length){
    if (p.surgeIfNone && self) self.surge = true;
    MC.log(G, '부착 가능한 하수인 없음 — 부착 불발, 급증(Surge)');
    return;
  }
  let best = minions[0], bestHp = (MC.cardDef(best.defCode).hp || 0);
  for (const m of minions){
    const h = MC.cardDef(m.defCode).hp || 0;
    if (h > bestHp){ best = m; bestHp = h; }
  }
  if (self) MC.attachTo(G, self, best);
};

// 메인 스킴 가속 토큰 부여(전역 G.acceleration 누적) — 법률 업무(01160) 등. 빌런 페이즈 위협 상승률 증가.
EFFECTS.addAcceleration = function(G, p, ctx){
  G.acceleration += (p.amount || 1);
  MC.log(G, '가속 토큰 +' + (p.amount || 1) + ' (누적 ' + G.acceleration + ')');
};

// 조우덱 top 1장 버림 + X 계산(부스트 아이콘 수 + p.plus). G._ritualX에 저장 → 이후 amountFrom:'ritualX'로 참조.
// 의식 결투(01159): X = 버린 조우 카드의 부스트 아이콘 + 1.
EFFECTS.discardEncounterComputeX = function(G, p, ctx){
  let boostN = 0;
  if (G.encounterDeck && G.encounterDeck.length){
    const card = G.encounterDeck.shift();
    const d = MC.cardDef(card.defCode || card.code);
    boostN = (d && typeof d.boost === 'number') ? d.boost : 0;
    (G.encounterDiscard = G.encounterDiscard || []).push(card);
    MC.log(G, '조우덱 top 버림 (' + MC.nameOf(card) + ') — 부스트 아이콘 ' + boostN);
  }
  G._ritualX = boostN + (p.plus || 1);
  MC.log(G, '의식 결투 X = ' + G._ritualX);
};

// 적에게 강인함(Tough) 상태 카드 부여 — p.scope:'villain'(빌런만) / 'villainAndEngaged'(빌런+활성 플레이어 교전 하수인).
// 빌런 강화 배신(심장 모양 허브 01158 등)에 사용.
EFFECTS.grantTough = function(G, p, ctx){
  const targets = [];
  if (G.villain && G.villain.hp > 0) targets.push(G.villain);
  if (p.scope === 'villainAndEngaged'){
    const pl = ctx.player || G.players[G.firstPlayer];
    targets.push(...(pl.engagedMinions || []));
  }
  for (const t of targets){ MC.setStatus(G, t, 'tough', true); MC.log(G, MC.nameOf(t) + ' — 강인함(Tough) 부여'); }
};

// 적 1명 선택 → then 효과 실행 (target:'chosen'으로 전달). 범용 인덱스:
//   "적 선택 후 기절/혼란/피해/조준…" 카드에 재사용. scope로 후보 제한(기본: 빌런+교전 하수인).
//   후보가 1명이면 자동 대상 처리, 없으면 무효. p.then은 순수 데이터 effects 배열.
EFFECTS.chooseEnemy = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const enemies = [];
  if (G.villain && G.villain.hp > 0 && p.scope !== 'minion') enemies.push(G.villain);
  if (p.scope !== 'villain'){
    for (const q of G.players) for (const m of q.engagedMinions) if (m.hp > 0) enemies.push(m);
  }
  if (!enemies.length){ MC.log(G, (p.prompt || '대상 적') + ' — 대상 적 없음'); return; }
  if (enemies.length === 1){                                  // 후보 하나면 자동
    MC.runEffectList(G, p.then || [], { player: pl, targets: [enemies[0]] });
    return;
  }
  G.pending = { kind: 'chooseEnemy', player: pl.uid,
                enemyUids: enemies.map(e => e.uid),
                then: p.then || [], prompt: p.prompt || '대상 적을 선택하세요' };
  MC.log(G, (p.prompt || '대상 적 선택') + ' — 선택 대기');
};

/* 덱 위 N장을 보고 K장을 손에 넣고 나머지는 버린다 — 범용 카드 선택(cardPick) pending.
   미래학자(Futurist)·Agatha·헤임달류 "look at top N, choose" 카드에 재사용.
   params: { count:3, keep:1, prompt, disposition:'discard'|'bottom' } (기본 나머지는 버림).
   후보가 keep 이하면 자동으로 전부 손에 넣고 끝(선택 불필요). */
// 조우덱 상위 count장을 보고 discard장 버림, 나머지 되돌림 (하임달 06020 예지).
// pending:encounterScry → UI에서 버릴 카드 선택. 나머지는 원래 위 순서 유지로 되돌림.
EFFECTS.scryEncounter = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const count = p.count || 3, discard = p.discard || 1;
  const revealed = [];
  for (let i = 0; i < count && G.encounterDeck.length; i++) revealed.push(G.encounterDeck.pop());   // 덱 위=끝(pop)
  if (!revealed.length){ MC.log(G, '조우덱이 비어있음 — 예지 대상 없음'); return; }
  if (revealed.length <= discard){   // 후보가 버릴 수 이하 → 전부 버림 (선택 불필요)
    for (const c of revealed) G.encounterDiscard.push(c);
    MC.log(G, MC.nameOf(pl) + ' — 조우덱 ' + revealed.length + '장 전부 버림 (예지)');
    return;
  }
  G.pending = { kind:'encounterScry', player: pl.uid,
                _cards: revealed, cardUids: revealed.map(c => c.uid),
                discard, chosen: [],
                prompt: p.prompt || ('조우덱 상위 ' + revealed.length + '장 — ' + discard + '장 버림') };
  MC.log(G, MC.nameOf(pl) + ' — 조우덱 상위 ' + revealed.length + '장 확인 (예지, ' + discard + '장 버림 선택)');
};

EFFECTS.lookAtTopChoose = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const count = p.count || 3, keep = p.keep || 1;
  const revealed = [];                                  // 덱 위(=끝, pop방향)에서 실제로 뽑아 pending에 보관
  for (let i = 0; i < count && pl.deck.length; i++) revealed.push(pl.deck.pop());
  if (!revealed.length){ MC.log(G, (p.prompt||'카드 선택') + ' — 덱이 비어 대상 없음'); return; }
  if (revealed.length <= keep){                         // 후보가 keep 이하 → 자동 전부 손
    for (const c of revealed) pl.hand.push(c);
    MC.log(G, MC.nameOf(pl) + ' — 덱 위 ' + revealed.length + '장 자동 손에 (선택 불필요)');
    return;
  }
  G.pending = { kind:'cardPick', player: pl.uid,
                cardUids: revealed.map(c => c.uid),
                _cards: revealed,                       // pending 내부 보관(덱에서 이미 분리)
                keep, chosen: [],
                disposition: p.disposition || 'discard',
                prompt: p.prompt || ('카드 ' + keep + '장 선택 (나머지는 버림)') };
  MC.log(G, MC.nameOf(pl) + ' — 덱 위 ' + revealed.length + '장 확인, ' + keep + '장 선택 대기');
};

/* ── 조우/능력 확장 효과 (Phase 3) ── */

// 급증: 이 카드 공개 후 조우 1장 추가 공개. inst에 surge 플래그 세워 기존 배선 재사용.
/* 로그만 출력 (ranged 등 표시용 — 방어 시스템 미배선 키워드 안내). */
EFFECTS.logOnly = function(G, p, ctx){ MC.log(G, p.text || ''); };

/* 실험 무기 덱(Experimental Weapons) top 1장 공개 → 빌런에 부착 (resolveEncounterCard).
   크로스본즈 III / 메인 스킴 2B·3B 공개 시. UI 연출용 G.fxWeaponReveal 힌트 설정. */
EFFECTS.revealExperimentalWeapon = function(G, p, ctx){
  if (!G.experimentalWeaponsDeck || !G.experimentalWeaponsDeck.length){
    MC.log(G, '실험 무기 덱이 비어 공개할 무기 없음');
    return;
  }
  const weapon = G.experimentalWeaponsDeck.shift();
  MC.log(G, '실험 무기 덱 공개 — ' + MC.nameOf(weapon) + '!');
  G.fxWeaponReveal = { defCode: weapon.defCode, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
  if (MC.resolveEncounterCard) MC.resolveEncounterCard(G, weapon, ctx.player || G.players[G.firstPlayer]);
};

EFFECTS.surge = function(G, p, ctx){
  if (ctx.self) ctx.self.surge = true;
};

// 빌런 HP 회복 (없으면 급증 등 대체효과는 cond:{type:'healedNone'}로 데이터 분기).
// 실제 회복량을 G._lastHealDone에 기록 → 다음 step에서 healedNone 조건 검사.
// perEngagedDrone: 활성 플레이어와 교전 중인 Drone 하수인 1명당 회복량 (수리 시퀀스 01146).
EFFECTS.healVillain = function(G, p, ctx){
  let amount = p.amount || 0;
  if (p.stageX2) amount = 2 * ((MC.cardDef(G.villain.defCode) || {}).stage || 1);   // Regenerative Healing: 2×스테이지
  if (p.amountFrom === 'boostDiscarded') amount = G._lastBoostDiscarded || 0;         // Shock Therapy: 버린 부스트당 1
  if (p.perEngagedDrone){
    const pl = ctx.player || G.players[G.firstPlayer];
    const drones = pl.engagedMinions.filter(m => m.isDrone || (m.traits||[]).includes('drone')).length;
    amount = p.perEngagedDrone * drones;
    MC.log(G, '교전 드론 ' + drones + '명 × ' + p.perEngagedDrone + ' = 회복 ' + amount);
  }
  G._lastHealDone = MC.healTarget(G, G.villain, amount);
};

// 각 히어로에게 피해 (allPlayers 대상, 신분/조우 카드). 피격 대상 힌트를 남겨 UI가 이펙트 재생.
EFFECTS.damageEachHero = function(G, p, ctx){
  const hit = [];
  let players = MC.resolvePlayers(G, 'all', ctx);
  if (p.heroForm) players = players.filter(pl => pl.form === 'hero');   // 히어로 폼 한정(그린 고블린 I WR)
  let amount = p.amount;
  if (p.amountIf && MC.condCheck(G, p.amountIf.cond, ctx)) amount = p.amountIf.amount;
  for (const pl of players){
    MC.applyDamage(G, pl, amount, { source: ctx.card || ctx.self, indirect: !!p.indirect });
    hit.push(pl.uid);
  }
  // VFX 힌트: 어떤 카드(source)가 각 히어로에게 얼마의 피해를 줬는지 → UI가 대상 위에 이펙트.
  const src = ctx.card || ctx.self;
  G.fxDamageEachHero = { defCode: src && src.defCode, amount: p.amount,
    targetUids: hit, indirect: !!p.indirect, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
};

// 각 히어로에 상태 부여 (혼란/기절)
EFFECTS.statusEachHero = function(G, p, ctx){
  for (const pl of MC.resolvePlayers(G, 'all', ctx)) MC.setStatus(G, pl, p.status, true);
};

// 대상(빌런/부착된 적 등)에 강인함
EFFECTS.toughEnemy = function(G, p, ctx){
  const t = p.target === 'villain' ? G.villain : (ctx.self && ctx.self.attachedTo ? MC.findByUid(G, ctx.self.attachedTo) : G.villain);
  MC.setStatus(G, t, 'tough', true);
};

// 빌런이 활성 플레이어를 공격 — 방어 선언 pending 생성 (기존 방어 머신 재사용).
// 주의: pending을 세우므로 이 효과 뒤 스텝은 resolveDefense 후 재개돼야 함(핸들러에서 단독 사용).
EFFECTS.villainAttacks = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let bonus = p.bonus || 0;
  if (p.bonusFrom === 'villainStage') bonus += (MC.cardDef(G.villain.defCode) || {}).stage || 0;
  if (p.bonusIfTrait && MC.villainTraitsOf(G).includes(String(p.bonusIfTrait.trait).toLowerCase())) bonus += (p.bonusIfTrait.bonus || 1);
  const amt = MC.enemyAtk(G, G.villain) + bonus;
  G.pending = { kind:'defense', player: pl.uid, attackerUid: G.villain.uid, amount: amt,
                stunOnHit: !!p.stunOnHit, threatOnDamage: p.threatOnDamage || 0,
                surgeIfDamageGTE: p.surgeIfDamageGTE || 0,
                discardDeckPerDamage: !!p.discardDeckPerDamage };
  // withBoost: 이 공격에 부스트 카드 1장 부여. noBoostIfAlterEgo면 알터에고 폼일 때 생략 (I See You).
  if (p.withBoost && !(p.noBoostIfAlterEgo && pl.form === 'alter-ego')){
    const bc = MC.drawEncounterCard(G);
    if (bc) G.pending.boostCard = bc;
  }
  MC.log(G, MC.nameOf(G.villain) + ' → ' + pl.uid + ' 공격 (피해 ' + amt + ') — 방어 선언 대기');
};

// 빌런 암약(스킴) — 메인 스킴에 빌런 SCH만큼 위협 배치. 조우 카드가 "빌런이 암약한다"를 유발할 때.
// villainAttacks의 짝. p: { scheme:'main', bonus:0 }. 놓은 위협량을 G._lastThreatPlaced에 기록
// → discardTopDeck amountFrom:'lastThreatPlaced'로 연계 (울트론의 분노 알터에고 분기).
EFFECTS.villainSchemes = function(G, p, ctx){
  let bonus = p.bonus || 0;
  if (p.bonusFrom === 'villainStage') bonus += (MC.cardDef(G.villain.defCode) || {}).stage || 0;
  if (p.bonusIfTrait && MC.villainTraitsOf(G).includes(String(p.bonusIfTrait.trait).toLowerCase())) bonus += (p.bonusIfTrait.bonus || 1);
  const amt = (G.villain.scheme || 0) + bonus;
  G._lastThreatPlaced = 0;
  if (amt <= 0){ MC.log(G, MC.nameOf(G.villain) + ' 암약 — 위협 0 (SCH 0)'); return; }
  MC.placeThreat(G, p.scheme || 'main', amt);
  G._lastThreatPlaced = amt;
  MC.log(G, MC.nameOf(G.villain) + ' 암약 — ' + (p.scheme || 'main') + ' 위협 +' + amt);
};

// 덱 맨 위 N장 버림(범용) — p:{ amount 또는 amountFrom:'lastThreatPlaced'|'lastDamageDealt',
//   scope?:'activePlayer'(기본)|'eachPlayer' }. "각 플레이어 덱 맨 위 3장 버림"(침습 AI 01149) 등.
EFFECTS.discardTopDeck = function(G, p, ctx){
  let n = p.amount || 0;
  if (p.amountFrom === 'lastThreatPlaced') n = G._lastThreatPlaced || 0;
  else if (p.amountFrom === 'lastDamageDealt') n = G._lastDamageDealt || 0;
  if (n <= 0){ MC.log(G, '(덱 버림 0장 — 조건값 없음)'); return; }
  const players = p.scope === 'eachPlayer'
    ? MC.playersInOrder(G).filter(pl => !pl.eliminated)
    : [ctx.player || G.players[G.firstPlayer]];
  // checkTrait: 이렇게 버린 카드 중 지정 특성(파워 아이콘 근사: traits의 thwart/attack)을 가진 카드가 있으면 ctx._discardHadTrait 기록 (모방 04105 등 조건 분기용).
  let hadTrait = false;
  for (const pl of players){
    const before = pl.discard.length;
    MC.discardTopOfDeck(G, pl, n);
    if (p.checkTrait){
      const newly = pl.discard.slice(before);
      if (newly.some(c => { const cd = MC.cardDef(c.defCode || c.code); return cd && (cd.traits || []).includes(p.checkTrait); })) hadTrait = true;
    }
  }
  if (p.checkTrait && ctx){ ctx._discardHadTrait = hadTrait; MC.log(G, '버린 카드 중 ' + p.checkTrait + ' 아이콘 ' + (hadTrait ? '있음' : '없음')); }
};

// 하수인 탐색 배치(범용) — 조우덱에서 (특성 일치) 하수인이 나올 때까지 버림 → 첫 플레이어와 교전 배치.
// "The Masters of Evil"(01128) 등 "Discard cards from the encounter deck until a [[X]] minion is discarded.
// Put that minion into play engaged with the first player." 유형을 데이터로. p: { trait?, who? }
// who:'you' → 카드 플레이어(ctx.player)와 교전 (아홉 왕국의 수호자 06003). 기본 → 첫 플레이어(조우 카드).
// (엔진 헬퍼 MC.discardUntilMinionIntoPlay 재사용 — 하수인 부재 시 안전 불발 처리 포함)
// 하수인 배치 성공 여부를 ctx._minionPlaced에 남김 → 후속 효과(위협 제거 등)의 cond:minionPlaced 조건용.
EFFECTS.discardUntilMinion = function(G, p, ctx){
  const pl = (p.who === 'you' && ctx && ctx.player) ? ctx.player : G.players[G.firstPlayer];
  const minion = MC.discardUntilMinionIntoPlay(G, pl, p.trait || null);
  if (ctx) ctx._minionPlaced = !!minion;
};

// 뒷면 드론 스폰(범용) — p:{ scope:'eachPlayer'|'activePlayer'|'firstPlayer', count?:1, fallback? }.
// "각 플레이어(또는 당신/첫 플레이어)가 덱 맨 위 카드를 뒷면 Drone 하수인으로 전장에 놓는다"
// (안드로이드 효율 01144 eachPlayer, 울트론의 명령 01150 firstPlayer×2 등).
// 드론 스탯은 울트론 드론 환경(droneStats)이 있으면 그 값, 없으면 fallback. 스폰 수를 G._lastDroneSpawns에 기록.
EFFECTS.spawnDrone = function(G, p, ctx){
  const fb = p.fallback || { attack:1, scheme:1, hp:1 };
  const count = p.count || 1;
  let n = 0;
  if (p.scope === 'activePlayer' || p.scope === 'firstPlayer'){
    const pl = p.scope === 'firstPlayer'
      ? G.players[G.firstPlayer]
      : ((ctx && ctx.player) || G.players[G.firstPlayer]);
    for (let i = 0; i < count; i++){ if (MC.spawnFacedownDrone(G, pl, fb)) n++; }
  } else {   // eachPlayer (기본)
    for (const pl of MC.playersInOrder(G)){
      if (pl.eliminated) continue;
      for (let i = 0; i < count; i++){ if (MC.spawnFacedownDrone(G, pl, fb)) n++; }
    }
  }
  G._lastDroneSpawns = n;
};

// 하수인 일제 공격(범용) — "각 X 하수인이 교전 중인 히어로를 공격한다. 이 방식으로 공격이
// 없었다면 → (fallback)" (혼돈의 지배 01133, 군집 공격 01147, 하일 히드라 03030 유형).
// p: { trait?, scope?:'allPlayers'|'activePlayer', fallback?:'searchEngage'|'spawnDrone', droneFallback? }.
//   scope 기본 allPlayers(혼돈: 모든 플레이어의 X 하수인) / activePlayer(군집: 공개한 플레이어만).
//   fallback: searchEngage(조우덱+버림 하수인 탐색) / spawnDrone(덱 맨 위 뒷면 드론 스폰).
// 공격 개시 수를 G._lastMinionAttacks에 기록 → cond:{type:'minionsAttacked'}(및 negate)로 분기 연출/대사.
EFFECTS.minionsAttack = function(G, p, ctx){
  const pairs = [];
  const players = p.scope === 'activePlayer'
    ? [(ctx && ctx.player) || G.players[G.firstPlayer]]
    : MC.playersInOrder(G);
  const attackedPlayers = new Set();
  for (const pl of players){
    if (!pl || pl.eliminated) continue;
    for (const m of pl.engagedMinions){
      if (p.trait && !(m.traits || []).includes(p.trait)) continue;
      if (m.hp <= 0) continue;
      pairs.push({ attackerUid: m.uid, playerUid: pl.uid });
      attackedPlayers.add(pl.uid);
    }
  }
  // 헤일 하이드라: 이번에 (해당 특성 하수인에게) 공격받지 않은 각 플레이어는 조우덱/버림에서 그 특성 하수인 탐색→교전 배치.
  //   공격 전에 배치해도 새 하수인은 pairs에 없어 이번 공격엔 미참여 (공식 순서와 결과 동일).
  if (p.reinforceUnattacked){
    for (const pl of players){
      if (!pl || pl.eliminated || attackedPlayers.has(pl.uid)) continue;
      MC.searchMinionIntoPlay(G, pl, p.trait || null);
    }
  }
  const started = pairs.length ? MC.startMinionAttackChain(G, pairs) : false;
  G._lastMinionAttacks = started ? 1 : 0;
  if (!started && !p.reinforceUnattacked){
    const pl = (ctx && ctx.player) || G.players[G.firstPlayer];
    if (p.fallback === 'searchEngage'){
      MC.log(G, '공격한 ' + (p.trait || '') + ' 하수인 없음 — 조우덱/버림에서 증원 탐색');
      MC.searchMinionIntoPlay(G, pl, p.trait || null);
    } else if (p.fallback === 'spawnDrone'){
      MC.log(G, '공격한 Drone 없음 — 덱 맨 위 카드를 뒷면 드론으로 증원');
      MC.spawnFacedownDrone(G, pl, p.droneFallback || { attack:1, scheme:1, hp:1 });
    }
  }
};

// 각 플레이어 선택(범용) — p:{ prompt, options:[{key,label,effects,payIcons?}] }.
// "각 플레이어가 A 또는 B를 선택한다"(공격 받는 중 01151 등). 각 플레이어 순차 선택 pending 체인.
// ctx.self가 이 카드(사이드 스킴 등)면 selfUid로 전달 → 옵션 effects의 scheme:'self'가 이 카드 참조.
EFFECTS.eachPlayerChoice = function(G, p, ctx){
  const queue = MC.playersInOrder(G).filter(pl => !pl.eliminated).map(pl => pl.uid);
  G._pendingEachChoice = { selfUid: ctx.self ? ctx.self.uid : null,
                           prompt: p.prompt, options: p.options || [], queue };
  MC.flushEachChoice(G);
};

// 폼 분기 — 현재 활성 플레이어의 폼(hero/alter)에 따라 다른 effects 배열을 재귀 실행.
// 배신 카드 다수가 "공개 시(히어로)/공개 시(알터에고)" 분기를 가짐 → 커스텀 핸들러 없이 데이터로.
// p: { hero:[...effects], alter:[...effects] }. 해당 폼 브랜치가 없으면 아무것도 안 함.
EFFECTS.formBranch = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const branch = pl.form === 'hero' ? p.hero : p.alter;
  if (branch && branch.length) runEffectList(G, branch, ctx);
};

// 연출 힌트 세팅(범용) — effects 배열 안에서 카드별 전용 연출/대사를 데이터로 지정.
// p: { vfx, quoteKey, quoteKind, target:'villain'|'self' }. UI가 G.fxCardEffect를 읽어 재생.
EFFECTS.playVfx = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const quote = (p.quoteKey && MC.randomQuote) ? MC.randomQuote(p.quoteKey, p.quoteKind || 'attack') : null;
  G.fxCardEffect = { vfx: p.vfx, quote, target: p.target || 'villain',
                     player: pl.uid, cardCode: ctx.card ? ctx.card.defCode : (ctx.self && ctx.self.defCode),
                     seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
};

// 조건부 피해: 지불 아이콘(paidIcons)에 특정 타입이 있으면 피해 (와일드도 충족)
EFFECTS.dealDamageIfPaid = function(G, p, ctx){
  const need = p.resource; // 'physical' 등
  const have = (ctx.paidIcons && ((ctx.paidIcons[need]||0) + (ctx.paidIcons.wild||0))) || 0;
  if (have <= 0) return;
  const tgt = MC.resolveTarget(G, p.target, ctx);
  for (const t of tgt) MC.applyDamage(G, t, p.amount, { source: ctx.card });
};

// 덱 위 N장을 버리되, 조건(인쇄 자원 등) 맞는 카드는 손으로 회수.
// p: { amount, keepResource:'mental' } — self 플레이어 대상
EFFECTS.millAndGrab = function(G, p, ctx){
  const pl = ctx.player || ctx.self;
  const n = p.amount || 0;
  for (let i = 0; i < n; i++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); break; }   // RRG: 밀 중 소진→리셔플+조우카드 후 새 덱에선 안 밀음
    const card = pl.deck.pop();
    const def = MC.cardDef(card.defCode);
    const printed = def && def.resources ? (def.resources[p.keepResource] || 0) : 0;
    if (p.keepResource && printed > 0){
      pl.hand.push(card);
      MC.log(G, MC.nameOf(card) + ' 손에 추가 (인쇄 ' + p.keepResource + ')');
    } else {
      MC.moveToDiscard(G, pl, card, {});
      MC.log(G, MC.nameOf(card) + ' 버림');
    }
  }
};

// 전체 피해 방지 (방어 인터럽트 이벤트 — Backflip 등):
// 현재 방어 pending을 피해 0으로 해소하고 빌런 큐 재개.
EFFECTS.preventAll = function(G, p, ctx){
  const pend = G.pending;
  if (!pend || pend.kind !== 'defense'){
    // pending 없이 플레이된 경우(방어 대상 아님) — 조용히 무효
    MC.log(G, '(방어할 공격 없음 — 피해 방지 효과 없음)');
    return;
  }
  MC.log(G, MC.nameOf(ctx.card) + ' — 공격의 모든 피해 방지');
  // 뒷면 부스트 카드가 있으면 공개(무효) 후 버림 (카드 유실 방지)
  if (pend.boostCard){
    MC.log(G, '부스트 카드 공개(무효): ' + (pend.boostCard.name || '?'));
    G.encounterDiscard.push(pend.boostCard);
  }
  G.pending = null;
  MC.processVillainQueue(G); // 방어 해소 후 큐 재개
};

/* 부분 피해 방지: 방어 pending의 피해량을 N만큼 감소 (0 이하면 방어 해소).
   우주 비행(3 방지) 등. p.amount = 방지량. */
EFFECTS.preventAmount = function(G, p, ctx){
  const pend = G.pending;
  if (!pend || pend.kind !== 'defense'){
    MC.log(G, '(방어할 공격 없음 — 피해 방지 효과 없음)');
    return;
  }
  // ★ 룰북: 부스트가 뒷면(미공개)이므로 총피해를 알 수 없다 → 방지량을 누적만 하고
  //   방어 해소 시(부스트 공개 후) 총피해에서 차감. 조기 완결하지 않음.
  const prevent = p.amount || 0;
  pend.prevented = (pend.prevented || 0) + prevent;
  MC.log(G, MC.nameOf(ctx.card) + ' — 피해 ' + prevent + ' 방지 예약 (누적 ' + pend.prevented + ')');
};

/* 부스트 카드의 유효 부스트 값 — 기본 boost + 조건부 아이콘.
   boostBonusIfGoblinEngaged(I See You): 대상 플레이어에 고블린 하수인 교전 시 +N. */
MC.boostOf = function(G, card, pl){
  let b = (card && card.boost) || 0;
  const def = card && MC.cardDef(card.defCode);
  if (def && def.boostBonusIfGoblinEngaged && pl){
    const has = (pl.engagedMinions || []).some(m => ((MC.cardDef(m.defCode) || {}).traits || []).includes('goblin'));
    if (has) b += def.boostBonusIfGoblinEngaged;
  }
  return b;
};

/* 특정 사이드 스킴 공개(범용 데이터판) — 조우덱/버림에서 지정 코드 사이드 스킴을 찾아 공개 + 조우덱 셔플.
   (졸라 II 04110 = Test Subjects 공개 등. 엔진 헬퍼 MC.revealSpecificSideScheme 재사용) p:{ code } */
EFFECTS.revealSideScheme = function(G, p, ctx){
  if (p.code && MC.revealSpecificSideScheme) MC.revealSpecificSideScheme(G, p.code);
};

/* 실험(test) 카운터 배치(범용) — 메인 스킴에 test 카운터 N개를 놓는다.
   (졸라 04116 부스트 / 04121 기술적 강화 등). 3개 도달 시 하수인 소환은 빌런 페이즈 처리(mc_5)에서. p:{ amount } */
EFFECTS.placeTestCounter = function(G, p, ctx){
  const n = p.amount || 1;
  if (!G.mainScheme) return;
  G.mainScheme.testCounters = (G.mainScheme.testCounters || 0) + n;
  MC.log(G, '🧪 실험 카운터 +' + n + ' (누적 ' + G.mainScheme.testCounters + ')');
};

/* 졸라의 뮤테이트(04115) 공개 시 — 조우덱 맨 위에서 [[Tech]] 부착물이 나올 때까지 버리고, 그 부착물을 이 하수인에게 부착. */
EFFECTS.attachTechToSelf = function(G, p, ctx){
  const minion = ctx.card || ctx.self || ctx.minion;
  if (!minion || !G.encounterDeck) return;
  let guard = 0;
  while (G.encounterDeck.length && guard++ < 60){
    if (G.encounterDeck.length === 0){ G.encounterDeck = MC.shuffle(G, (G.encounterDiscard || []).splice(0)); if (!G.encounterDeck.length) break; }
    const c = G.encounterDeck.pop();
    const cd = MC.cardDef(c.defCode || c.code);
    if (cd && cd.type === 'attachment' && (cd.traits || []).includes('tech')){
      minion.attachments = minion.attachments || [];
      minion.attachments.push(c);
      try { if (MC.applyAttachStats) MC.applyAttachStats(G, minion, c); } catch (e) {}
      MC.log(G, MC.nameOf(minion) + '에 ' + MC.nameOf(c) + ' 부착 (조우덱에서 Tech 탐색)');
      return;
    }
    (G.encounterDiscard = G.encounterDiscard || []).push(c);
  }
  MC.log(G, '조우덱에 Tech 부착물 없음 — 부착 불발');
};

/* 졸라의 뮤테이트(04115) 부스트 — 이 하수인을 조우 덱에 섞어 넣는다. (부스트 시점: 아직 전장 밖 → 조우덱 셔플만) */
EFFECTS.shuffleSelfIntoEncounter = function(G, p, ctx){
  const minion = ctx.card || ctx.self;
  if (minion && G.players){
    for (const pl of G.players){
      const idx = (pl.engagedMinions || []).indexOf(minion);
      if (idx >= 0){ pl.engagedMinions.splice(idx, 1); (G.encounterDeck = G.encounterDeck || []).push(minion); break; }
    }
  }
  if (MC.shuffle && G.encounterDeck) MC.shuffle(G, G.encounterDeck);
  MC.log(G, '졸라의 뮤테이트 — 조우 덱에 섞임');
};

/* 광폭 뮤테이트(04116) 부스트 — 메인 스킴의 실험 카운터 1개당 졸라가 이 활성화 동안 SCH +1, ATK +1.
   (G._villainActBonus에 기록 → 빌런 활성화 계산 시 참조. 없으면 로그만 남겨 안전.) */
EFFECTS.berserkTestBonus = function(G, p, ctx){
  const tc = (G.mainScheme && G.mainScheme.testCounters) || 0;
  if (tc > 0){
    G._villainActBonus = { attack: tc, scheme: tc, seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
    MC.log(G, '광폭 뮤테이트 부스트 — 실험 카운터 ' + tc + ' → 졸라 이 활성화 ATK/SCH +' + tc);
  }
};

MC.EFFECTS = EFFECTS;
MC.runEffectList = runEffectList;
