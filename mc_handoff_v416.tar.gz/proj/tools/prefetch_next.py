#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""prefetch_next.py [N] — mcode 순 다음 N개(기본 10) 미완성 카드의 공식 JSON을 한 번에 추출.
결과를 /tmp/next_cards.json에 저장 + 요약 출력. 카드마다 curl/파싱 반복 제거.
사용: python3 tools/prefetch_next.py 10"""
import json, subprocess, sys, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
N = int(sys.argv[1]) if len(sys.argv) > 1 else 10

# 미완성 목록 (mcode 순)
js = f"""
global.window=undefined;const fs=require('fs');
eval(fs.readFileSync('{ROOT}/mc_engine.js','utf8'));eval(fs.readFileSync('{ROOT}/mc_cards.js','utf8'));
const MC=globalThis.MC;const rows=[];
for(const slug in MC.CARDS){{const d=MC.CARDS[slug];const m=d.mcode||'';
  if(!/^01/.test(m)||!d.todoFx)continue;rows.push({{m,slug,type:d.type,name:d.name}});}}
rows.sort((a,b)=>a.m.localeCompare(b.m));
console.log(JSON.stringify(rows.slice(0,{N})));
"""
r = subprocess.run(['node','-e',js], capture_output=True, text=True, cwd=ROOT)
todo = json.loads(r.stdout)

officials = []
for f in ['/tmp/core_enc.json','/tmp/core.json']:
    if os.path.exists(f):
        try: officials += json.load(open(f, encoding='utf-8'))
        except Exception: pass

out = []
for t in todo:
    matches = [c for c in officials if c.get('code','').startswith(t['m'])]
    keep = []
    for c in matches:
        keep.append({k: c[k] for k in ['code','name','type_code','set_code','text','flavor','traits',
                    'boost','attack','scheme','health','base_threat','escalation_threat','threat',
                    'health_per_hero','quantity','cost','resource_physical','resource_mental',
                    'resource_energy','resource_wild','is_unique'] if k in c})
    out.append({'mcode': t['m'], 'slug': t['slug'], 'type': t['type'], 'name': t['name'], 'official': keep})

json.dump(out, open('/tmp/next_cards.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'다음 {len(out)}장 → /tmp/next_cards.json')
for o in out:
    off = o['official'][0] if o['official'] else {}
    print(f"{o['mcode']:7} {o['type'] or '?':12} {o['slug']:26} | 공식: {off.get('name','캐시 없음')}")
