#!/usr/bin/env python3
"""inspect_card.py — 카드 하나의 전체 상태를 한눈에.
   사용: node 아님, python3 tools/inspect_card.py <코드 또는 슬러그> [...]
   출력: 공식(zzorba) 데이터 · 마이그레이션 인덱스 · 구현(effects/handlers/vfx/todoFx) · 연출 슬롯
"""
import json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
zz = json.load(open('/home/claude/mc/zz/zz_by_code.json'))
idx = json.load(open('/mnt/project/marvel_card_index.json'))['cards']

# 조립된 mc_cards.js에서 등록 상태 추출 (JS 실행 없이 정적 파싱은 부정확 → node로 덤프)
def dump_impl(codes):
    import subprocess
    script = '''
    require('%s/mc_engine.js'); require('%s/mc_cards.js');
    const MC=globalThis.MC;
    const out={};
    for (const c of %s){
      const d=MC.cardDef(c);
      if(!d){ out[c]=null; continue; }
      out[c]={ name:d.name, type:d.type, todoFx:!!d.todoFx,
        effects:d.effects||null,
        hooks:['whenPlayed','whenRevealed','whenDefeated','whenCompleted','response','interrupt','forcedResponse','forcedInterrupt','setup'].filter(h=>d[h]).map(h=>h+':'+d[h]),
        vfx:d.vfx||null, quoteKey:d.quoteKey||null,
        resourceAbility:d.resourceAbility||null, doubleForAspect:d.doubleForAspect||null,
        stats:{cost:d.cost,attack:d.attack,thwart:d.thwart,defense:d.defense,recover:d.recover,hp:d.hp,scheme:d.scheme,boost:d.boost},
        resources:d.resources||null, traits:d.traits||null, deckLimit:d.deckLimit, copies:d.copies };
    }
    process.stdout.write(JSON.stringify(out));
    ''' % (ROOT, ROOT, json.dumps(codes))
    r = subprocess.run(['node','-e',script], capture_output=True, text=True)
    if r.returncode != 0:
        print('impl dump 오류:', r.stderr[:400]); return {}
    return json.loads(r.stdout)

def mcode_of_slug(slug):
    c = idx.get(slug)
    if not c: return None
    m = re.search(r'/cards/([0-9A-Za-z]+)\.png', c.get('image','') or '')
    return m.group(1) if m else None

def resolve(arg):
    # 숫자코드면 그대로, 슬러그면 그대로. 둘 다 시도.
    return arg

args = sys.argv[1:] or ['01001a','01001b']
impl = dump_impl(args)

for arg in args:
    print('\n' + '═'*66)
    d = impl.get(arg)
    if d is None:
        print(f'[{arg}] 엔진에 미등록'); 
    else:
        print(f'[{arg}] {d["name"]} ({d["type"]})  todoFx={"Y" if d["todoFx"] else "N"}')
        st = {k:v for k,v in d['stats'].items() if v is not None}
        if st: print('  스탯:', ' · '.join(f'{k} {v}' for k,v in st.items()))
        if d['resources']: print('  자원:', d['resources'])
        if d['traits']: print('  특성:', d['traits'])
        if d.get('deckLimit') is not None or d.get('copies') is not None:
            print(f'  덱: limit={d.get("deckLimit")} copies={d.get("copies")}')
        print('  ── 구현 상태 ──')
        print('  effects  :', json.dumps(d['effects'], ensure_ascii=False) if d['effects'] else '(없음)')
        print('  hooks    :', ', '.join(d['hooks']) if d['hooks'] else '(없음)')
        print('  vfx      :', json.dumps(d['vfx'], ensure_ascii=False) if d['vfx'] else '(없음)',
              '| quoteKey:', d['quoteKey'] or '-')
        extras = []
        if d['resourceAbility']: extras.append('resourceAbility='+d['resourceAbility'])
        if d['doubleForAspect']: extras.append('doubleForAspect='+d['doubleForAspect'])
        if extras: print('  기타     :', ', '.join(extras))
    # 공식 텍스트 (인덱스 → zzorba 순)
    slug = arg
    ic = idx.get(slug)
    z = zz.get(arg) or (zz.get(mcode_of_slug(slug)) if not arg[0].isdigit() else None)
    if ic and ic.get('desc'):
        print('  ── 한글 텍스트(인덱스) ──')
        for line in ic['desc'].split('\n'):
            if line.strip(): print('   ', line.strip())
    if z and z.get('text'):
        print('  ── 공식 원문(zzorba) ──')
        print('   ', re.sub(r'\[\[|\]\]','', z['text']).replace('\n',' / ')[:300])
    if z:
        meta = {k:z[k] for k in ('traits','keywords','set_code','card_set_code') if z.get(k)}
        if meta: print('  공식 메타:', meta)

print('\n' + '═'*66)
print('연출 슬롯 참고: vfx.{basicAttack, enemyAttack, basicThwart, formChange, cardInstall,')
print('  entrance, onHit, onDefeat, install} — 카드/신분 정의에 이름만, 구현은 MC.VFX')
