#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""preflight.py <mcode|slug> — 카드 등록 전 사전 점검 원샷.
① 공식 JSON 필드(core_enc/core) ② db/seed 등록 상태 ③ slug/code 중복 ④ 연출·대사 존재
사용: python3 tools/preflight.py 01128
     python3 tools/preflight.py masters-of-evil-scheme
출력은 요약만 (토큰 절약). node가 필요."""
import json, subprocess, sys, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def official(mcode):
    out = []
    for f, tag in [('/tmp/core_enc.json','enc'), ('/tmp/core.json','player')]:
        if not os.path.exists(f): continue
        try: data = json.load(open(f, encoding='utf-8'))
        except Exception: continue
        for c in data:
            code = c.get('code','')
            if code == mcode or code == mcode+'a' or code == mcode+'b':
                keep = {k: c[k] for k in ['code','name','type_code','set_code','text','flavor',
                        'traits','boost','attack','scheme','health','base_threat','escalation_threat',
                        'threat','amount','health_per_hero','cost','resource_physical','resource_mental',
                        'resource_energy','resource_wild','is_unique','quantity'] if k in c}
                keep['_src'] = tag
                out.append(keep)
    return out

def node_state(key):
    js = f"""
global.window=undefined;const fs=require('fs');
eval(fs.readFileSync('{ROOT}/mc_engine.js','utf8'));eval(fs.readFileSync('{ROOT}/mc_cards.js','utf8'));
try{{require('{ROOT}/ui/mc_vfx.js');}}catch(e){{}}
const MC=globalThis.MC;const KEY='{key}';
const hits=[];
for(const slug in MC.CARDS){{const d=MC.CARDS[slug];
  if(slug===KEY||d.mcode===KEY||d.code===KEY) hits.push(slug);}}
const out=[];
for(const slug of hits){{const d=MC.CARDS[slug];
  const o={{slug,name:d.name,type:d.type,todoFx:!!d.todoFx}};
  for(const k of ['whenRevealed','whenCompleted','whenDefeated','attackDamagedResponse','boostStar','crisis','hazard','accelIcons','baseThreat','baseThreatPerPlayer','copies','attachStats','removeAbility','boost','attack','scheme','hp','guard','toughness','patrol']) if(d[k]!==undefined)o[k]=d[k];
  if(d.effects)o.effects=d.effects.map(e=>e.fx).join('+');
  if(d.quoteKey){{o.quoteKey=d.quoteKey;
    const q=MC.QUOTES&&MC.QUOTES[d.quoteKey];o.quotes=q?Object.entries(q).map(([k,v])=>k+':'+v.length).join(','):'없음';}}
  if(d.vfx){{o.vfx={{}};for(const k in d.vfx)o.vfx[k]=(MC.VFX&&MC.VFX[d.vfx[k]])?d.vfx[k]:d.vfx[k]+'(미정의!)';}}
  out.push(o);}}
console.log(JSON.stringify({{hits,cards:out}},null,1));
"""
    r = subprocess.run(['node','-e',js], capture_output=True, text=True, cwd=ROOT)
    if r.returncode != 0:
        return {'error': r.stderr.strip()[:300]}
    try: return json.loads(r.stdout)
    except Exception: return {'error': r.stdout[:300]}

def main():
    if len(sys.argv) < 2:
        print(__doc__); return
    key = sys.argv[1]
    mcode = key if re.match(r'^\d{5}[ab]?$', key) else None

    print(f'══ preflight {key} ══')
    # ① 공식
    if mcode:
        off = official(mcode)
        if off:
            for c in off:
                print(f"[공식/{c.pop('_src')}] " + json.dumps(c, ensure_ascii=False))
        else:
            print('[공식] /tmp 캐시에 없음 → curl로 core.json/core_enc.json 확보 필요')
    # ② db/seed 상태 + ③ 중복 + ④ 연출·대사
    st = node_state(key)
    if 'error' in st:
        print('[엔진] 오류:', st['error']); return
    hits = st.get('hits', [])
    if not hits:
        print('[등록] 미등록 — db/seed 어디에도 없음')
    elif len(hits) > 1:
        print(f'[⚠중복] {len(hits)}건: {", ".join(hits)} — 정본 통일 필요!')
    for c in st.get('cards', []):
        status = '미완성(todoFx)' if c['todoFx'] else '완료'
        print(f"[{status}] {c['slug']} ({c.get('type','?')}) {c.get('name','')}")
        rest = {k:v for k,v in c.items() if k not in ('slug','name','type','todoFx')}
        if rest: print('   ' + json.dumps(rest, ensure_ascii=False))

if __name__ == '__main__':
    main()
