/* audit_identities.js — 영웅 신분(Identity) 능력 배선 감사 (중복 작업 방지 도구)
   ★ 영웅 능력은 두 군데에 등록될 수 있다: db(mc_cards_identities.js)의 카드 필드 +
     별도 fx(mc_cards_zidentity_fx.js)의 defineCardFx. 한쪽만 보면 이미 된 걸 다시 만든다.
   ★ 이 도구는 db+fx 통합 상태(cardDef)로 각 영웅이 능력을 가졌는지 판정한다.
   사용: node tools/audit_identities.js            (전체 요약)
         node tools/audit_identities.js 03001a    (특정 영웅 상세 — 작업 전 필수 확인) */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

// 능력을 나타내는 정의 필드 (db 필드 + fx 필드 통합). 하나라도 있으면 "배선됨".
const ABILITY_FIELDS = [
  'attackInterrupt','resourceAbility','identityAction','onFormChange','dynamicHandSize',
  'dynamicStat','retaliate','onSetup','threatPrevent','defenseInterrupt','counterAbility',
  'grantsTrait','statMod','special','drawOnVillainAttack','forcedResponse','response',
  'interrupt','forcedInterrupt','activatedAbility','allyLimitBonus','hpBonus',
  'onMinionEngage','afterEventResponse','livingLegend',
];

function abilitiesOf(code){
  const d = MC.cardDef(code);
  if (!d) return null;
  return ABILITY_FIELDS.filter(f => d[f] !== undefined);
}

const arg = process.argv[2];

if (arg){
  // 특정 영웅 상세 — 작업 전 반드시 확인
  const d = MC.cardDef(arg);
  if (!d){ console.error('미등록 코드: ' + arg); process.exit(1); }
  const heroCode = d.type === 'hero' ? arg : d.backLink;
  const aeCode = d.type === 'hero' ? d.backLink : arg;
  const hAb = abilitiesOf(heroCode) || [];
  const aAb = abilitiesOf(aeCode) || [];
  console.log('=== ' + (MC.cardDef(heroCode).name) + ' (' + heroCode + '/' + aeCode + ') ===');
  console.log('히어로 능력 필드:', hAb.length ? hAb.join(', ') : '(없음)');
  console.log('알터에고 능력 필드:', aAb.length ? aAb.join(', ') : '(없음)');
  for (const [label, code] of [['히어로', heroCode], ['알터에고', aeCode]]){
    const def = MC.cardDef(code);
    const detail = ABILITY_FIELDS.filter(f => def[f] !== undefined)
      .map(f => '  · ' + f + ' = ' + JSON.stringify(def[f]));
    if (detail.length) console.log(label + ' 상세:\n' + detail.join('\n'));
  }
  const wired = hAb.length > 0 || aAb.length > 0;
  console.log('\n판정: ' + (wired ? '★ 이미 배선됨 — 중복 등록 주의!' : '미배선 — 신규 등록 대상'));
  process.exit(0);
}

// 전체 요약
const heroes = Object.keys(MC.CARDS).filter(k => MC.CARDS[k].type === 'hero').sort();
let wired = 0; const missing = [];
for (const h of heroes){
  const d = MC.cardDef(h);
  const hAb = abilitiesOf(h) || [];
  const aAb = abilitiesOf(d.backLink) || [];
  const ok = hAb.length > 0 || aAb.length > 0;
  if (ok) wired++; else missing.push(h + '/' + d.backLink + ' (' + d.name + ')');
  console.log((ok ? '✓' : '✗') + ' ' + h + ' ' + d.name.padEnd(10) +
    ' | H:[' + hAb.join(',') + '] AE:[' + aAb.join(',') + ']');
}
console.log('\n배선됨: ' + wired + ' / ' + heroes.length + ' 영웅');
console.log('미배선 (' + missing.length + '): ' + missing.join(', '));
console.log('\n※ 특정 영웅 작업 전 반드시: node tools/audit_identities.js <코드> 로 상세 확인');
