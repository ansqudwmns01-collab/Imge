#!/usr/bin/env python3
"""reassemble.py — 샤드 → 모놀리스 조립
   shards/mc_1..mc_7 → mc_engine.js
   cards/mc_cards_*.js → mc_cards.js
   ★ 모놀리스는 절대 직접 편집하지 않는다. 항상 이 스크립트로 재생성."""
import os, sys, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def assemble(pattern, out, sort_key=None):
    files = sorted(glob.glob(os.path.join(ROOT, pattern)), key=sort_key)
    if not files:
        print(f'[reassemble] 경고: {pattern} 매칭 없음'); return
    parts = []
    for f in files:
        with open(f, encoding='utf-8') as fh:
            parts.append(f'/* ◇◇ from {os.path.basename(f)} ◇◇ */\n' + fh.read())
    body = '\n\n'.join(parts)
    outp = os.path.join(ROOT, out)
    with open(outp, 'w', encoding='utf-8') as fh:
        fh.write('/* 자동 생성 파일 — 직접 편집 금지. tools/reassemble.py 로 재생성 */\n' + body)
    print(f'[reassemble] {out}  ← {len(files)}개 샤드, {len(body):,} bytes')

if __name__ == '__main__':
    assemble('shards/mc_*_*.js', 'mc_engine.js')
    assemble('cards/mc_cards_*.js', 'mc_cards.js')
