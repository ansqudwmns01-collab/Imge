#!/bin/bash
# quick_check.sh [테스트파일...] — 토큰 절약형 검증.
# 인자 없으면: test_index + (있으면) 지정 테스트만. 출력은 실패시에만 상세, 성공시 한 줄.
# 전체 회귀는 묶음(3~5카드) 끝에서만 run_tests.sh로.
cd "$(dirname "$0")/.."
FAIL=0
run(){
  local name="$1"; shift
  local out
  out=$("$@" 2>&1)
  if [ $? -ne 0 ] || echo "$out" | grep -q "✗\|Error\|실패"; then
    echo "✗ $name"; echo "$out" | grep -E "✗|Error|실패" | head -5; FAIL=1
  else
    echo "✓ $name"
  fi
}
run "index" node tools/test_index.js
for t in "$@"; do
  run "$(basename $t .js)" node "$t"
done
[ $FAIL -eq 0 ] && echo "══ PASS ══" || { echo "══ FAIL ══"; exit 1; }
