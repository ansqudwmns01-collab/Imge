#!/usr/bin/env python3
"""migrate_index.py — marvel_card_index.json(이전 빌드 추출본) → cards/mc_cards_db.js
   원칙:
   - 데이터만 이식. effect 플래그는 엔진에 넣지 않고 docs/effect_flags_report.json으로 보존
   - 이미지 URL에서 공식 코드(mcode) 추출 → zzorba authoritative와 교차검증
   - 자원 아이콘 누락은 zzorba resource_*로 자동 보정, 잔여분은 리포트
   - 능력 미구현 카드는 todoFx:true (UI '수동' 배지 + Phase 3 파이프라인 추적)
"""
import json, re, os, collections

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = '/mnt/project/marvel_card_index.json'
ZZ  = '/home/claude/mc/zz/zz_by_code.json'

idx = json.load(open(SRC))
zz  = json.load(open(ZZ)) if os.path.exists(ZZ) else {}
cards = idx['cards']

TYPE_MAP = {
  'side-scheme':'side_scheme', 'main-scheme':'main_scheme',
}
KEYWORD_FLAGS = {'guard','quickstrike','toughness','stalwart','hinder','surge','peril',
                 'piercing','overkill','ranged','aerial','patrol','permanent','restricted','incite'}
DEF_ONLY_KEYWORDS = {'victory','villainous','setup'}  # 정의 메타로만 보존
EFFECT_FIELDS = ['effect','when','heroAction','onDefeatMinion','boostStarEffect','alterEgoAction',
                 'action','response','forced','interrupt','setupFn']

out = {}
# 자원 오버라이드: 리프린트 이미지코드라 zzorba 원판 코드와 매핑 안 되는 카드를
# 원판(공식) 자원으로 강제. 값은 zzorba 원판 대조로 확정.
RESOURCE_OVERRIDE = {
    'goliath-ally':     { 'mental': 1 },    # 원판 04013 = mental (이미지 23015는 리프린트)
    'mockingbird-ally': { 'physical': 1 },  # 원판 01083 = physical (이미지 23022는 리프린트)
    'weapons-master':   { 'physical': 1 },  # 22007 = physical (누락분 보정)
}

report = { 'effectFlags': {}, 'resourceFilled': [], 'resourceMissing': [],
           'statMismatch': [], 'noImage': [], 'keywordUnknown': collections.Counter() }

def mcode_of(c):
    m = re.search(r'/cards/([0-9A-Za-z]+)\.png', c.get('image','') or '')
    return m.group(1) if m else None

for cid, c in cards.items():
    t = TYPE_MAP.get(c['type'], c['type'])
    d = { 'code': cid, 'type': t, 'name': c['name'] }
    if c.get('nameEn'): d['nameEn'] = c['nameEn']
    d['side'] = 'player' if t in ('ally','event','support','upgrade','resource') else 'encounter'
    if t in ('obligation','invocation'): d['side'] = 'player'
    for src,dst in [('cost','cost'),('atk','attack'),('thw','thwart'),('hp','hp'),
                    ('sch','scheme'),('atkPip','atkCost'),('thwPip','thwCost'),
                    ('boostIcons','boost'),('aspect','aspect'),('traits','traits'),
                    ('unique','unique'),('acceleration','accelIcons'),('hazard','hazard')]:
        if c.get(src) is not None: d[dst] = c[src]
    # atkPip/thwPip가 true(불리언)인 경우 1로 정규화
    for k in ('atkCost','thwCost'):
        if d.get(k) is True: d[k] = 1
    # 자원: 'physical' → {physical:1}
    if c.get('resource'): d['resources'] = { c['resource']: 1 }
    # 키워드 배열 → 플래그
    for kw in (c.get('keywords') or []):
        if kw in KEYWORD_FLAGS: d[kw] = True
        elif kw == 'retaliate' or kw == 'retaliate-1': d['retaliate'] = 1
        elif kw.startswith('retaliate-'): d['retaliate'] = int(kw.split('-')[1])
        elif kw in DEF_ONLY_KEYWORDS: d['kw_'+kw] = True
        else: report['keywordUnknown'][kw] += 1
    # 스킴 위협: zzorba가 있으면 그 스키마를 진실로 (아래 교차검증에서 덮어씀),
    # 없으면 인덱스 값 잠정 사용
    if t == 'side_scheme':
        if c.get('threat') is not None: d['baseThreatPerPlayer'] = c['threat']
        if c.get('maxThreat') is not None: d['maxThreat'] = c['maxThreat']
    if t == 'main_scheme':
        if c.get('threat') is not None: d['baseThreatPerPlayer'] = c['threat']
        if c.get('maxPerPlayer') is not None: d['maxThreatPerPlayer'] = c['maxPerPlayer']
        elif c.get('maxThreat') is not None: d['maxThreatPerPlayer'] = c['maxThreat']
    # 정의 전용 메타
    if c.get('image'): d['image'] = c['image']
    else: report['noImage'].append(cid)
    mc = mcode_of(c)
    if mc: d['mcode'] = mc
    if c.get('hero'): d['hero'] = c['hero']
    if c.get('module'): d['module'] = c['module']
    if c.get('desc'): d['textKo'] = c['desc']
    if c.get('flavor'): d['flavor'] = c['flavor']
    if c.get('_copies'): d['copies'] = c['_copies']
    if c.get('boostStar'): d['boostStar'] = True
    if c.get('attachTarget'): d['attachTarget'] = c['attachTarget']
    # ── zzorba 교차검증 ──
    z = zz.get(mc) if mc else None
    if z:
        # 자원 보정
        if 'resources' not in d and d['side'] == 'player' and t != 'resource':
            r = {}
            for k in ('physical','mental','energy','wild'):
                v = z.get('resource_'+k)
                if v: r[k] = v
            if r:
                d['resources'] = r
                report['resourceFilled'].append(cid)
        # 이중 자원 카드 반영 (인덱스는 단일 표기)
        elif 'resources' in d:
            zr = { k: z['resource_'+k] for k in ('physical','mental','energy','wild') if z.get('resource_'+k) }
            if zr and zr != d['resources']: d['resources'] = zr
    # 자원 오버라이드 (리프린트 코드 대응) — zzorba 매핑 실패분 강제 보정
    if cid in RESOURCE_OVERRIDE:
        d['resources'] = dict(RESOURCE_OVERRIDE[cid])
        report['resourceFilled'].append(cid + '(override)')

    if z:
        # 스탯: zzorba(공식)를 진실로 자동 채택 — 표본 검증에서 인덱스 boost 과소 확인됨
        for a,b in [('attack','attack'),('thwart','thwart'),('hp','health'),('cost','cost'),
                    ('boost','boost'),('scheme','scheme'),('atkCost','attack_cost'),('thwCost','thwart_cost')]:
            if z.get(b) is not None:
                if d.get(a) is not None and d[a] != z[b]:
                    report['statMismatch'].append({'id':cid,'field':a,'index':d[a],'zzorba':z[b],'adopted':'zzorba'})
                d[a] = z[b]
        # 덱 투입 한도 (덱빌더용) + 시그니처 세트 수량 (영웅 전용 카드의 공식 동봉 수)
        if z.get('deck_limit') is not None: d['deckLimit'] = z['deck_limit']
        if d.get('hero') and z.get('quantity') is not None: d['copies'] = z['quantity']
        # 스킴 위협: zzorba 스키마 정밀 매핑
        if t == 'side_scheme':
            d.pop('baseThreatPerPlayer', None); d.pop('maxThreat', None)
            if z.get('base_threat') is not None:
                if z.get('base_threat_fixed'): d['baseThreat'] = z['base_threat']
                else: d['baseThreatPerPlayer'] = z['base_threat']
            if z.get('scheme_acceleration'): d['accelIcons'] = z['scheme_acceleration']
        if t == 'main_scheme':
            d.pop('baseThreatPerPlayer', None); d.pop('maxThreatPerPlayer', None)
            if z.get('base_threat') is not None:
                if z.get('base_threat_fixed'): d['baseThreat'] = z['base_threat']
                else: d['baseThreatPerPlayer'] = z['base_threat']
            if z.get('threat') is not None:
                if z.get('threat_fixed'): d['maxThreat'] = z['threat']
                else: d['maxThreatPerPlayer'] = z['threat']
            if z.get('escalation_threat'): d['accelIcons'] = z['escalation_threat']
    if d['side']=='player' and t in ('ally','event','support','upgrade') and 'resources' not in d:
        report['resourceMissing'].append(cid)
    # ── effect 플래그 보존 (엔진 제외) ──
    flags = { f: c[f] for f in EFFECT_FIELDS if c.get(f) is not None }
    if flags:
        report['effectFlags'][cid] = flags
        d['todoFx'] = True   # 능력 미구현 마커 (Phase 3 파이프라인에서 제거)
    out[cid] = d

# ── 출력 ──
os.makedirs(os.path.join(ROOT,'docs'), exist_ok=True)
report['keywordUnknown'] = dict(report['keywordUnknown'])
json.dump(report, open(os.path.join(ROOT,'docs/effect_flags_report.json'),'w'), ensure_ascii=False, indent=1)

js = "/* 자동 생성 — tools/migrate_index.py. 직접 편집 금지 (원본: marvel_card_index.json + zzorba 교차검증) */\n"
js += "(function(global){\n'use strict';\nconst MC = global.MC;\nMC.registerCards(" + json.dumps(out, ensure_ascii=False) + ");\n"
js += "})(typeof window !== 'undefined' ? window : globalThis);\n"
open(os.path.join(ROOT,'cards/mc_cards_db.js'),'w').write(js)

print(f"[migrate] {len(out)}장 이식 → cards/mc_cards_db.js ({len(js):,} bytes)")
print(f"  자원 자동보정 {len(report['resourceFilled'])} · 자원 잔여누락 {len(report['resourceMissing'])}"
      f" · 스탯 불일치 {len(report['statMismatch'])} · 이미지 없음 {len(report['noImage'])}"
      f" · 능력 미구현(todoFx) {len(report['effectFlags'])}")
print("  잔여 자원누락:", report['resourceMissing'][:30])
print("  미지 키워드:", report['keywordUnknown'])
