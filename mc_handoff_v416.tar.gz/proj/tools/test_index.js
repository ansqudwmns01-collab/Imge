/* test_index.js — 모든 카드의 fx/훅/조건 참조가 인덱스에 등록됐는지 검사.
   미등록 0 이어야 통과. 사용: node tools/test_index.js */
'use strict';
const path = require('path');
const ROOT = path.dirname(__dirname);
require(path.join(ROOT, 'mc_engine.js'));
require(path.join(ROOT, 'mc_cards.js'));
const MC = globalThis.MC;

const HOOK_FIELDS = [
  'whenPlayed','response','interrupt','forcedResponse','forcedInterrupt',
  'whenRevealed','whenDefeated','whenCompleted','setup','attackDamagedResponse',
  'villainPhaseStart','playerPhaseStart','endOfPhase','endOfRound','onFormChange',
];

let bad = 0, total = 0;
for (const code in MC.CARDS){
  total++;
  const c = MC.CARDS[code];
  // effects[].fx → EFFECTS (formBranch의 hero/alter 등 중첩 배열도 재귀 검사)
  const checkFx = (list) => {
    if (!Array.isArray(list)) return;
    for (const st of list){
      if (!st || !st.fx) continue;
      if (!MC.EFFECTS[st.fx]){ console.error(`✗ ${code} ${c.name}: 미등록 fx '${st.fx}'`); bad++; }
      // 중첩 effects 배열(폼분기 hero/alter, 선택지 등)도 검사
      for (const k in st){ if (Array.isArray(st[k]) && st[k].some(x => x && x.fx)) checkFx(st[k]); }
    }
  };
  if (c.effects) checkFx(c.effects);
  // 훅별 effects 배열(whenRevealedEffects/whenCompletedEffects/whenDefeatedEffects)도 fx 검사
  for (const ef of ['whenRevealedEffects','whenCompletedEffects','whenDefeatedEffects','attackDamagedEffects','whenPlayedEffects','forcedResponseEffects','onSetupEffects']){
    if (c[ef]) checkFx(c[ef]);
  }
  // 훅 필드 → HANDLERS
  for (const hf of HOOK_FIELDS){
    if (c[hf] && typeof c[hf] === 'string' && !MC.HANDLERS[c[hf]]){
      console.error(`✗ ${code} ${c.name}: 미등록 handler '${c[hf]}' (${hf})`); bad++;
    }
  }
  // 데이터 필드가 baseFields에 있는지 (인스턴스 누락 방지)
  const KNOWN_META = new Set(['stage','hpPerPlayer','maxThreatPerPlayer','nextStage',
    // 마이그레이션 정의 전용 메타 (인스턴스 복사 불필요)
    'image','mcode','textKo','textEn','flavor','illustrator','todoFx','hero','module',
    'copies','boostStar','attachTarget','kw_victory','kw_villainous','kw_setup','resourceAbility','doubleForAspect','deckLimit','vfx','quoteKey','boostStarEffect','boostStarEffects','boostStarPutIntoPlay','boostStarOnDamage','boostStarOnScheme','boostStarChoice','boostStarShuffleBack','boostBonusIfGoblinEngaged','stunOnDamage','identityCannotReady','identityCannotFlip','wrDoubling','droneStats','droneStatBonus','forceAllyDefend','villainAttackExtraBoost','forcedAttackChoice','villainAttackSpawnDrone','attackBonusPerDrone','droneBuffVillain','invulnWhileDrone','attachStats','grantOverkillOnAttack','discardAfterAttack','removeAbility','grantsToughOnDamage','retaliate','discardControlledUpgrade','resolveObligation','blocksAlterEgoFlip','immuneToUpgradeDamage','atkEqualsHp','crisis','forcedResponseEffects','invulnWhileScheme','reviveOnDefeat','onRevive','onReviveEffects','preventDefeatToHp','grantsRetaliate','entersWithCounters','onMinionEnterDamage','attackExtraCost','maxPerRound','livingLegend','counterGainPerPhase','allyLimitCondAllTrait','whenPlayedEffects','onSetupEffects','uiFlow']); // 정의 전용 필드
  for (const f in c){
    if (!MC.baseFields.includes(f) && !KNOWN_META.has(f)){
      console.error(`✗ ${code} ${c.name}: baseFields 미등록 필드 '${f}'`); bad++;
    }
  }
}
console.log(`[test_index] 카드 ${total}장 검사 — 미등록 ${bad}건`);
process.exit(bad === 0 ? 0 : 1);
