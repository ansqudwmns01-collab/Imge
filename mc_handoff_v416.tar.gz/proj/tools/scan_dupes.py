#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""scan_dupes.py — seed/db 이중 등록(같은 mcode에 slug 여러 개) 전수 스캔.
소닉 컨버터·견고한 음체·불멸의 클로·아머드 가드에서 반복된 중복 패턴을 사전에 잡는다.
사용: python3 tools/scan_dupes.py"""
import json, subprocess, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

js = f"""
global.window=undefined;const fs=require('fs');
eval(fs.readFileSync('{ROOT}/mc_engine.js','utf8'));eval(fs.readFileSync('{ROOT}/mc_cards.js','utf8'));
const MC=globalThis.MC;
const byM={{}};
for(const slug in MC.CARDS){{const d=MC.CARDS[slug];const m=d.mcode;
  if(!m)continue;(byM[m]=byM[m]||[]).push({{slug,name:d.name,type:d.type,todoFx:!!d.todoFx,
    hasFx:!!(d.whenRevealed||d.effects||d.attackDamagedResponse||d.boostStar||d.attachStats)}});}}
const dupes=Object.entries(byM).filter(([m,l])=>l.length>1).sort();
console.log(JSON.stringify(dupes,null,1));
"""
r = subprocess.run(['node','-e',js], capture_output=True, text=True, cwd=ROOT)
if r.returncode != 0:
    print('오류:', r.stderr[:300]); raise SystemExit(1)
dupes = json.loads(r.stdout)
if not dupes:
    print('중복 없음 ✓')
else:
    print(f'⚠ mcode 중복 {len(dupes)}건:')
    for m, lst in dupes:
        print(f'── {m} ──')
        for c in lst:
            print(f"  {c['slug']:26} {c['name']:14} {'미완성' if c['todoFx'] else '완료'} fx={'있음' if c['hasFx'] else '없음'}")
