#!/usr/bin/env python3
"""gen_identities.py — 전 영웅 신분 카드 생성
   zzorba(공식 스탯) × 인덱스 heroDB(한국어 이름) 결합 → cards/mc_cards_identities.js
   - 영웅면(type hero) + back_link 알터에고면 쌍으로 등록 (zzorba 코드 사용)
   - MC.HEROES 메타(키→이름/아트) 동시 생성 (UI 로스터의 단일 출처)
   - 다중 형태 영웅(자이언트맨 등)은 첫 영웅면만 사용 [제한사항 H-1]
"""
import json, re, os, collections

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
zz = json.load(open('/home/claude/mc/zz/zz_by_code.json'))
idx = json.load(open('/mnt/project/marvel_card_index.json'))

def norm(s):
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())

# zzorba 신분 수집: hero 면 + back_link
heroes_by_norm = {}
for code, z in zz.items():
    if z.get('type_code') != 'hero': continue
    back = z.get('back_link')
    if not back or back not in zz: continue
    key = norm(z['name'])
    # 같은 영웅 다중 면: 코드가 가장 작은 면 채택 (기본 면)
    if key not in heroes_by_norm or code < heroes_by_norm[key][0]:
        heroes_by_norm[key] = (code, z, zz[back])

# 인덱스 영웅 키 목록: heroDB + 카드 hero 필드
# 접미사 없는 중복 키는 제외 (카드 사용 0건 — heroDB 잔재)
DROP_KEYS = {'black-widow','hulk','nebula','wolverine','hawkeye','drax'}
hero_keys = set(idx.get('heroDB', {}).keys())
for c in idx['cards'].values():
    if c.get('hero'): hero_keys.add(c['hero'])
hero_keys = sorted(k for k in hero_keys if not k.startswith('hero-') and k not in DROP_KEYS)

ALIAS = {  # 슬러그 ↔ 공식명 특수 매칭
  'spiderman':'spiderman', 'antman':'antman', 'spider-woman':'spiderwoman',
  'doctor-strange':'doctorstrange', 'captain-marvel':'captainmarvel',
  'captain-america':'captainamerica', 'black-panther':'blackpanther',
  'black-widow':'blackwidow', 'iron-man':'ironman', 'ms-marvel':'msmarvel',
  'scarlet-witch':'scarletwitch', 'she-hulk':'shehulk', 'star-lord':'starlord',
  'war-machine':'warmachine', 'ghost-spider':'ghostspider', 'spider-ham':'spiderham',
  # 카드 hero 필드가 쓰는 접미사 키 → 공식명 (카드-키 일치가 우선이므로 접미사 키를 정식 채택)
  'black-widow-hero':'blackwidow', 'drax-hero':'drax', 'hulk-hero':'hulk',
  'nebula-hero':'nebula', 'wolverine-hero':'wolverine', 'hawkeye-cb':'hawkeye',
}


defs, HEROES, unmatched = {}, {}, []
STAT = [('attack','attack'),('thwart','thwart'),('defense','defense'),
        ('recover','recover'),('health','hp'),('hand_size','handSize')]
EXTRA = {  # 신분별 추가 필드 (파이프라인에서 확장)
  '01001a': { 'attackInterrupt': 'spiderSense',
              'vfx': { 'basicAttack': 'strike', 'cardInstall': 'webInstall', 'spiderSense': 'spiderSense' } },   # 스파이더맨: Spider-Sense 인터럽트 + 연출
  '01001b': { 'resourceAbility': 'scientist' },
}

for hk in hero_keys:
    zkey = ALIAS.get(hk, norm(hk))
    hit = heroes_by_norm.get(zkey)
    if not hit:
        unmatched.append(hk); continue
    code, zh, za = hit
    hdb = idx.get('heroDB', {}).get(hk, {})
    nameKo = hdb.get('heroName') or zh['name']
    alterKo = hdb.get('alterName') or za['name']
    def face(z, name_ko, typ, back):
        d = { 'code': z['code'], 'side':'player', 'type': typ, 'name': name_ko,
              'nameEn': z['name'], 'unique': True, 'backLink': back }
        for a,b in STAT:
            if z.get(a) is not None: d[b] = z[a]
        tr = z.get('traits')
        if tr: d['traits'] = [t.strip().lower().replace(' ','-') for t in tr.rstrip('.').split('.') if t.strip()]
        d['vfx'] = { 'formChange': 'formFlip', 'basicThwart': 'patrol' }   # 전 신분 공통 연출
        ex = EXTRA.get(z['code'], {})
        for k, v in ex.items():
            if k == 'vfx': d['vfx'].update(v)      # vfx는 병합 (덮어쓰기 금지)
            else: d[k] = v
        return d
    defs[zh['code']] = face(zh, nameKo, 'hero', za['code'])
    defs[za['code']] = face(za, alterKo, 'alter-ego', zh['code'])
    HEROES[hk] = { 'name': nameKo, 'alterName': alterKo, 'art': zh['code'], 'aeArt': za['code'] }

js = "/* 자동 생성 — tools/gen_identities.py. 직접 편집 금지 (zzorba 스탯 × heroDB 한국어명) */\n"
js += "(function(global){\n'use strict';\nconst MC = global.MC;\n"
js += "MC.registerCards(" + json.dumps(defs, ensure_ascii=False) + ");\n"
js += "MC.HEROES = " + json.dumps(HEROES, ensure_ascii=False) + ";\n"
js += "})(typeof window !== 'undefined' ? window : globalThis);\n"
open(os.path.join(ROOT, 'cards/mc_cards_identities.js'), 'w').write(js)
print(f"[identities] 영웅 {len(HEROES)}명 / 신분 카드 {len(defs)}장 생성")
print("미매칭 키:", unmatched)
