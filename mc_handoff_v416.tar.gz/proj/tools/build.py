#!/usr/bin/env python3
"""build.py — 소스 JS → 단일 HTML 빌드 (reassemble 선행 필수)
   ★ HANDOFF.md의 버전을 읽어 UI_VER 스탬프에 자동 주입 (화면 버전 = 실제 빌드 보장)"""
import os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def read(p): return open(os.path.join(ROOT,p),encoding='utf-8').read()

# HANDOFF.md에서 현재 버전 추출 (예: "- **버전:** v2026.07.13.194 (...)")
ver = None
try:
    hd = read('HANDOFF.md')
    m = re.search(r'\*\*버전:\*\*\s*(v[\d.]+)', hd)
    if m: ver = m.group(1)
except Exception:
    pass

html = read('ui/template.html')
html = html.replace('/*__ENGINE__*/', read('mc_engine.js'))
html = html.replace('/*__CARDS__*/',  read('mc_cards.js'))
html = html.replace('/*__NET__*/',    read('net/mc_net.js'))
html = html.replace('/*__VFX__*/',    read('ui/mc_vfx.js'))
html = html.replace('/*__UI__*/',     read('ui/mc_ui.js'))

# 버전 스탬프 자동 주입: const UI_VER = 'vX.Y.Z';
if ver:
    html, n = re.subn(r"const UI_VER = '[^']*';", f"const UI_VER = '{ver}';", html, count=1)
    print(f'[build] 버전 스탬프 → {ver}' + ('' if n else ' (경고: UI_VER 미치환!)'))

out = os.path.join(ROOT, 'marvel_champions_build.html')
open(out,'w',encoding='utf-8').write(html)
print(f'[build] marvel_champions_build.html  {len(html):,} bytes')
