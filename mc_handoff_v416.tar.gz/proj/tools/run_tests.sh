#!/bin/bash
# run_tests.sh — 회귀 스위트. 카드별 test_*.js를 여기 등록한다.
set -e
cd "$(dirname "$0")/.."
python3 tools/reassemble.py
node -c mc_engine.js && echo "[syntax] mc_engine.js OK"
node -c mc_cards.js  && echo "[syntax] mc_cards.js OK"
node tools/test_index.js
FAIL=0
for t in tests/test_*.js; do
  echo "── $t"
  node "$t" || FAIL=1
done
if [ $FAIL -eq 0 ]; then echo "══ 회귀 전체 통과 ══"; else echo "══ 회귀 실패 ══"; exit 1; fi
