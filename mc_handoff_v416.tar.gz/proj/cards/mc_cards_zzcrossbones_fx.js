/* ◇ 크로스본즈 시나리오 인카운터 fx ◇ (Crossbones set 04064~04071 + Experimental Weapons)
   레드 스컬의 부상 캠페인 #1 — 크로스본즈. */
(function(global){
  'use strict';
  const MC = global.MC;
  if (!MC || !MC.defineCardFx) return;

  /* 04066 하이드라 폭격병 (Hydra Bomber) — 하수인. ATK1/HP2/SCH1. ×2.
     공개 시: 피해 2를 받거나, 메인 스킴에 위협 1을 놓는다 (선택). offerChoice 재사용. */
  MC.defineCardFx('04066', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'offerChoice',
      prompt:'하이드라 폭격병 — 폭탄을 던진다! 선택하세요',
      options:[
        { key:'damage', label:'피해 2 받기',        effects:[{ fx:'dealDamage', target:'self', amount:2 }] },
        { key:'threat', label:'메인 스킴 위협 +1',   effects:[{ fx:'placeThreat', scheme:'main', amount:1 }] },
      ] }],
  });

  /* 04068 강철 같은 의지 (Hard as Nails) — 배신. 공개 시(+부스트★): 빌런에게 강인(tough) 부여.
     부여할 수 없으면(이미 강인) 대신 빌런 3 회복. applyStatus failIfHas + failEffect(heal). */
  MC.defineCardFx('04068', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'applyStatus', target:'villain', status:'tough',
      failIfHas:true, failEffect:[{ fx:'heal', target:'villain', amount:3 }] }],
    boostStarEffects: [{ fx:'applyStatus', target:'villain', status:'tough',
      failIfHas:true, failEffect:[{ fx:'heal', target:'villain', amount:3 }] }],
  });

  /* 04070 크로스본즈의 강습 (Crossbones' Assault) — 사이드 스킴. 위협 2/영웅. ×2.
     격퇴 시: 크로스본즈가 이 스킴을 격퇴한 플레이어를 공격(활성화). whenCompleted + villainActivate. */
  MC.defineCardFx('04070', {
    whenCompleted: 'runCardEffects',
    whenCompletedEffects: [{ fx:'villainActivate' }],
  });

  /* 04071 궁지에 몰린 참모 (Cornered Staff) — 사이드 스킴. 위협 3(고정). ×1.
     공개 시: 조우덱 top 1/영웅 버림 → 버린 카드 부스트 아이콘마다 이 스킴에 위협 1 추가.
     discardEncounterBoostToScheme(perHero, self). */
  MC.defineCardFx('04071', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'discardEncounterBoostToScheme', perHero:true, self:true }],
  });

  /* 04067 풀 오토 (Full Auto) — 배신. ×2.
     공개 시(알터에고): 급증(surge). 공개 시(히어로): 크로스본즈 ATK만큼 조우덱 버림 → 부스트당 간접피해.
     goblinPlayerFormReveal(폼 분기) + surge / discardEncounterByCountBoostDamage(countFrom villainAtk). */
  MC.defineCardFx('04067', {
    whenRevealed: 'goblinPlayerFormReveal',
    whenRevealedByPlayerForm: {
      'alter-ego': [{ fx:'surge' }],
      'hero':      [{ fx:'discardEncounterByCountBoostDamage', countFrom:'villainAtk' }],
    },
  });

  /* 04065 크로스본즈의 아머 (Crossbones' Armor) — 부착물(Armor). 크로스본즈에 부착. ×1.
     강제 인터럽트: 크로스본즈가 피해를 받을 때 → 대신 아머가 흡수(여기 배치). 5 이상 누적 시 아머 파괴.
     absorbsVillainDamage(applyDamage 배선). */
  MC.defineCardFx('04065', {
    absorbsVillainDamage: true,
  });

  /* 04064 크로스본즈의 기관총 (Crossbones' Machine Gun) — 부착물(Weapon). 크로스본즈에 부착. ×1.
     탄약 카운터 2/영웅으로 등장. ★강제 인터럽트: 크로스본즈가 공격할 때 → 탄약 1 소모 +
     조우덱 top 1장 버림 → 버린 카드 부스트 아이콘만큼 간접 피해.
     entersWithCountersPerHero + attackForcedInterrupt + useCounter + discardEncounterByCountBoostDamage 재사용. */
  MC.defineCardFx('04064', {
    entersWithCountersPerHero: 2,
    useCounter: 1,
    attackForcedInterrupt: [{ fx:'discardEncounterByCountBoostDamage', amount:1 }],
  });

  /* 04069 무기고 습격 (Raid the Armory) — 배신. ×2.
     선동(Incite 1): 공개 시 메인 스킴에 위협 1. 그 후 조우덱을 Weapon 부착물이 나올 때까지 버리고 그 무기를 공개(빌런 부착).
     placeThreat(main,1) + discardEncounterUntilTrait(weapon). */
  MC.defineCardFx('04069', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [
      { fx:'placeThreat', scheme:'main', amount:1 },
      { fx:'discardEncounterUntilTrait', trait:'weapon' },
    ],
  });

  /* ═══ Experimental Weapons (실험 무기) — 빌런 부착 무기. 무기덱에서 공개 → 빌런 부착. ═══ */

  /* 04072 레이저 라이플 (Laser Rifle) — 부착물(Experimental/Weapon). 빌런 ATK +1.
     ★공격 시 원거리(ranged) 부여. 히어로 행동: 에너지+물리 지불 → 제거.
     attachStats{attack} + removeAbility(payIcons). (ranged는 방어 시스템 표시) */
  MC.defineCardFx('04072', {
    attachStats: { attack: 1 },
    attackForcedInterrupt: [{ fx:'logOnly', text:'레이저 라이플 — 이 공격 원거리(ranged)' }],
    removeAbility: { payIcons: { energy: 1, physical: 1 } },
  });

  /* 04073 에너지 실드 (Energy Shield) — 부착물. 부착된 빌런에게 보복(retaliate) 1.
     히어로 행동: 에너지+멘탈 지불 → 제거. attachStats{retaliate} + removeAbility. */
  MC.defineCardFx('04073', {
    attachStats: { retaliate: 1 },
    removeAbility: { payIcons: { energy: 1, mental: 1 } },
  });

  /* 04074 파워 건틀릿 (Power Gauntlets) — 부착물.
     ★강제 반응: 부착 빌런이 공격해 피해를 입힌 후 → 손패 1장 버림. 히어로 행동: 멘탈+물리 → 제거.
     attackDamagedEffects(discardFromHand) + removeAbility. */
  MC.defineCardFx('04074', {
    attackDamagedEffects: [{ fx:'discardFromHand', amount: 1 }],
    removeAbility: { payIcons: { mental: 1, physical: 1 } },
  });

  /* 04075 엑소슈트 (Exo-Suit) — 부착물. 빌런 ATK +1.
     히어로 행동: 에너지+멘탈+물리 지불 → 제거. attachStats{attack} + removeAbility. */
  MC.defineCardFx('04075', {
    attachStats: { attack: 1 },
    removeAbility: { payIcons: { energy: 1, mental: 1, physical: 1 } },
  });

  /* ═══ 무기덱 공개 트리거 — 크로스본즈 III / 메인 스킴 2B·3B 공개 시 실험 무기 덱 top 공개 ═══ */
  MC.defineCardFx('04060', {   // 크로스본즈 (III)
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'revealExperimentalWeapon' }],
  });
  MC.defineCardFx('04062b', {  // 인피니티 스톤 (2B)
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'revealExperimentalWeapon' }],
  });
  MC.defineCardFx('04063b', {  // 도주 (3B)
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'revealExperimentalWeapon' }],
  });

  /* ═══ 모듈러: 하이드라 강습 + 무기 마스터 ═══ */

  /* 04146 하이드라 제트 특공대 (Hydra Jet-Trooper) — 하수인. ATK2/HP3. 속공(quickstrike).
     ★부스트: 히어로 폼이면 이 활성화 후 빌런이 당신을 공격(부스트 없이). */
  MC.defineCardFx('04146', {
    boostStarEffects: [{ fx:'villainAttacks', noBoost:true, cond:{ type:'isHeroForm' } }],
  });

  /* 04148 전투용 나이프 (Combat Knife) — 부착물(Weapon). 빌런 ATK +1.
     ★부착 빌런의 공격은 관통(piercing). 히어로 행동: 멘탈+물리 → 제거.
     attachStats{attack} + grantsPiercing + removeAbility. */
  MC.defineCardFx('04148', {
    attachStats: { attack: 1 },
    grantsPiercing: true,
    removeAbility: { payIcons: { mental: 1, physical: 1 } },
  });

  /* 04149 하이드라 사이드암 (Hydra Sidearm) — 부착물(Weapon). 빌런 ATK +1.
     ★공격 시 원거리(ranged). 히어로 행동: 멘탈+물리 → 제거. */
  MC.defineCardFx('04149', {
    attachStats: { attack: 1 },
    attackForcedInterrupt: [{ fx:'logOnly', text:'하이드라 사이드암 — 이 공격 원거리(ranged)' }],
    removeAbility: { payIcons: { mental: 1, physical: 1 } },
  });

  /* 04150 무기 마스터 (Weapon Master) — 배신. ×2.
     공개(알터에고): 빌런 음모. 공개(히어로): 빌런 공격. 빌런에 Weapon 부착이 있으면 급증(surge). */
  MC.defineCardFx('04150', {
    whenRevealed: 'goblinPlayerFormReveal',
    whenRevealedByPlayerForm: {
      'alter-ego': [{ fx:'villainSchemes', scheme:'main' }, { fx:'surge', cond:{ type:'villainHasWeapon' } }],
      'hero':      [{ fx:'villainAttacks' }, { fx:'surge', cond:{ type:'villainHasWeapon' } }],
    },
  });

  /* 04151 섬광 수류탄 (Concussion Grenade) — 배신. ×1.
     공개(알터에고): 혼란 + 메인 스킴 위협 1 (이미 혼란이면 2). 공개(히어로): 기절 + 히어로 1 피해 (이미 기절이면 2).
     goblinPlayerFormReveal + applyStatus + placeThreat/dealDamage(amountIf targetStatus self). */
  MC.defineCardFx('04151', {
    whenRevealed: 'goblinPlayerFormReveal',
    whenRevealedByPlayerForm: {
      'alter-ego': [
        { fx:'placeThreat', scheme:'main', amount:1, amountIf:{ cond:{ type:'targetStatus', target:'self', status:'confused' }, amount:2 } },
        { fx:'applyStatus', target:'self', status:'confused' },
      ],
      'hero': [
        { fx:'dealDamage', target:'self', amount:1, amountIf:{ cond:{ type:'targetStatus', target:'self', status:'stunned' }, amount:2 } },
        { fx:'applyStatus', target:'self', status:'stunned' },
      ],
    },
  });

  /* 04145 하이드라 화염병 (Hydra Flame-Soldier) — 하수인. ATK1/HP4/SCH1.
     ★강제 반응: 무방어 공격 후 → 통제 중인 지원(support) 1장 버림. ★부스트도 동일.
     afterUndefendedAttack + discardUpgradeOrSupport(onlyType:support). */
  MC.defineCardFx('04145', {
    afterUndefendedAttack: [{ fx:'discardUpgradeOrSupport', onlyType:'support' }],
    boostStarEffects: [{ fx:'discardUpgradeOrSupport', onlyType:'support' }],
  });

  /* 04147 하일 하이드라! (Hail Hydra!) — 배신. 각 하이드라 하수인이 교전 히어로를 공격하고,
     공격받지 않은 플레이어는 하이드라 하수인을 서치해 교전 등장(증원).
     minionsAttack(trait:'hydra', reinforceUnattacked) 재사용. */
  MC.defineCardFx('04147', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'minionsAttack', trait:'hydra', reinforceUnattacked:true }],
  });

})(typeof window !== 'undefined' ? window : globalThis);
