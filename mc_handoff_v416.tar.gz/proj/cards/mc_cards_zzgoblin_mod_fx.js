/* ═══════════════════════════════════════════════════════════════
   MVC02 그린 고블린 — 모듈러 인카운터 세트 fx
   4종: Goblin Gimmicks · A Mess of Things · Power Drain · Running Interference
   각 시나리오(Risky Business/Mutagen Formula)에 섞을 수 있는 선택 세트.

   ★ 정확도 확실한 것부터. 현재: Goblin Gimmicks
     (Goblin Glider/Pumpkin Bombs는 시나리오 카드 02019/02021 재사용 — 동일 카드).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* ── 공용 신규 효과 ── */
/* 직전 회복량(_lastHealDone)이 0이면 이 카드 surge (Regenerative Healing). */
MC.EFFECTS.surgeIfNoHeal = function(G, p, ctx){
  if ((G._lastHealDone || 0) <= 0 && ctx.self){
    ctx.self.surge = true;
    MC.log(G, MC.nameOf(ctx.self) + ' — 회복 없음 → 급증(surge)');
  }
};
/* 빌런에게 뒷면 부스트 카드 N개 저장 — 다음 활성화에 추가 (Intimidation). */
MC.EFFECTS.giveVillainBoost = function(G, p, ctx){
  G.villainStoredBoost = (G.villainStoredBoost || 0) + (p.amount || 1);
  MC.log(G, '빌런에게 뒷면 부스트 카드 ' + (p.amount || 1) + '개 부여 (다음 활성화)');
};

/* ═══ Goblin Gimmicks ═══ */
/* 02036 Regenerative Healing — WR: 빌런 2×스테이지 회복(회복 0이면 surge) / 부스트★: 빌런 2 회복. */
MC.defineCardFx('regenerative-healing', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'healVillain', stageX2:true }, { fx:'surgeIfNoHeal' }],
  boostStarEffects:[{ fx:'healVillain', amount:2 }],
});

/* 02035 Intimidation — WR: [자원 2 지불 / 빌런에게 뒷면 부스트 1] 선택 / 부스트★: 빌런 추가 부스트 1.
   (slug 'intimidation'은 플레이어 이벤트가 선점 → 코드 '02035'로 등록) */
MC.defineCardFx('02035', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'offerChoice', prompt:'위협 — 자원 2를 지불하거나, 빌런에게 뒷면 부스트 카드를 준다',
    options:[
      { key:'pay', label:'자원 2 지불', payIcons:{ total:2 }, effects:[] },
      { key:'boost', label:'빌런에게 부스트 부여', effects:[{ fx:'giveVillainBoost', amount:1 }] },
    ] }],
  boostStarEffects:[{ fx:'giveVillainBoost', amount:1 }],
});

/* ═══ A Mess of Things ═══ */
/* 전장의 기절한 아군 캐릭터(히어로+동료) 수 */
MC.stunnedFriendlyCount = function(G){
  let n = 0;
  for (const pl of G.players){
    if (pl.status && pl.status.stunned > 0) n++;
    for (const al of (pl.playArea && pl.playArea.allies || []))
      if (al.status && al.status.stunned > 0) n++;
  }
  return n;
};
/* threatHere에 stunnedFriendlies×2 소스 추가 (A Mess of Things WR) */
const _threatHereBase = MC.EFFECTS.threatHere;
MC.EFFECTS.threatHere = function(G, p, ctx){
  if (p && p.amountFrom === 'stunnedFriendliesX2'){
    const amt = 2 * MC.stunnedFriendlyCount(G);
    if (ctx.self && amt > 0){ ctx.self.threat = (ctx.self.threat||0) + amt; MC.log(G, MC.nameOf(ctx.self)+' — 위협 +'+amt+' (기절 아군)'); }
    return;
  }
  return _threatHereBase(G, p, ctx);
};
/* 02037 A Mess of Things — WR: 기절한 아군 1명당 이 스킴에 위협 +2 */
MC.defineCardFx('a-mess-of-things', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'threatHere', amountFrom:'stunnedFriendliesX2' }],
});

/* 02038 Scorpion — Quickstrike + 공격이 피해를 입히면 그 대상 기절(stunOnDamage). */
MC.defineCardFx('scorpion', {
  quickstrike:true,
  stunOnDamage:true,
  vfx:{ attack:'scorpionStrike' },
});

/* 02040 Tail Sweep — WR: Scorpion이 당신을 공격. 공격이 없었으면 당신 기절. 부스트★: 당신 기절.
   (전장에 Scorpion 하수인이 있으면 그 하수인이 공격, 없으면 기절) */
MC.EFFECTS.scorpionAttacksOrStun = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  let scorpion = null;
  for (const p2 of G.players) for (const m of (p2.engagedMinions||[])) if (m.defCode==='scorpion'){ scorpion=m; break; }
  if (scorpion){
    G.pending = { kind:'defense', player: pl.uid, attackerUid: scorpion.uid, amount: MC.enemyAtk(G, scorpion) };
    MC.log(G, MC.nameOf(scorpion) + ' → ' + pl.uid + ' 공격 (Tail Sweep)');
  } else {
    MC.setStatus(G, pl, 'stunned', true);
    MC.log(G, 'Scorpion 없음 — ' + MC.nameOf(pl) + ' 기절 (Tail Sweep)');
  }
};
MC.defineCardFx('tail-sweep', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'scorpionAttacksOrStun' }],
  boostStarEffects:[{ fx:'applyStatus', target:'self', status:'stunned' }],
});

/* ═══ Power Drain (Electro) ═══
   공통 메커니즘: 조우덱 N장 버림 → 버린 부스트 아이콘 합계를 G._lastBoostDiscarded에 기록.
   파생 효과들이 이 값을 소비(간접피해/빌런회복/자원버림). 인덱스식 수렴. */
MC.EFFECTS.boostDrain = function(G, p, ctx){
  const n = p.count != null ? p.count : (p.countPerHero ? p.countPerHero * G.players.length : 2);
  let boostSum = 0; const discarded = [];
  for (let i = 0; i < n; i++){
    const c = MC.drawEncounterCard(G);
    if (!c) break;
    boostSum += MC.boostOf ? MC.boostOf(G, c, ctx.player) : (c.boost || 0);
    discarded.push(c);
    G.encounterDiscard.push(c);
  }
  G._lastBoostDiscarded = boostSum;
  G._lastDrainDiscarded = discarded;
  MC.log(G, '조우 ' + n + '장 버림 — 부스트 아이콘 ' + boostSum);
};
/* 버린 부스트당 간접 피해 1 (Lightning Bolt / Electro FR) */
MC.EFFECTS.damagePerBoostDiscarded = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const dmg = G._lastBoostDiscarded || 0;
  if (dmg > 0){ MC.applyDamage(G, pl, dmg, { source: ctx.self || ctx.card, indirect:true }); MC.log(G, MC.nameOf(pl) + ' — 버린 부스트당 간접 피해 ' + dmg); }
};
/* 각 플레이어가 버린 부스트당 손패 자원 1장 버림 (Power Drain 격퇴) — 공식: 각 플레이어가 "선택"하여 버림(무작위 아님). */
MC.EFFECTS.discardResourceEachPlayerPerBoost = function(G, p, ctx){
  const cnt = G._lastBoostDiscarded || 0;
  if (cnt <= 0) return;
  const order = (MC.playersInOrder ? MC.playersInOrder(G) : G.players).filter(pl => !pl.eliminated);
  MC.setupResourceDiscardPick(G, {
    queue: order.map(pl => pl.uid), perPlayerCount: cnt, types: null,
    prompt: '파워 드레인 — 버린 부스트당 자원 카드 ' + cnt + '장 선택 버림', reason: 'Power Drain',
  });
};
/* EM Pulse: 방금 버린 카드 중 Electro가 있으면 교전 배치, 없으면 이 카드 surge */
MC.EFFECTS.summonElectroIfDiscarded = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const idx = (G.encounterDiscard || []).findIndex(c => c.defCode === 'electro' && (G._lastDrainDiscarded||[]).includes(c));
  if (idx >= 0){
    const [el] = G.encounterDiscard.splice(idx, 1);
    const cd = MC.cardDef('electro') || {};
    el.engagedWith = pl.uid; pl.engagedMinions.push(el);
    el.status = el.status || { stunned:0, confused:0, tough: cd.toughness?1:0 };
    if (MC.minionEnteredPlay) MC.minionEnteredPlay(G, el, pl);
    MC.log(G, 'Electro 전장 배치 (EM Pulse)');
  } else if (ctx.self){
    ctx.self.surge = true;
    MC.log(G, 'Electro 없음 → EM Pulse 급증(surge)');
  }
};

/* 02042 Electro — 강제반응: 공격 후 조우 1장 버림, 버린 부스트당 간접 피해 / 부스트★: 조우 3장 버림. */
MC.defineCardFx('electro', {
  vfx:{ attack:'electroStrike' },
  forcedResponseEffects:[{ fx:'boostDrain', count:1 }, { fx:'damagePerBoostDiscarded' }],
  boostStarEffects:[{ fx:'boostDrain', count:3 }],
});
/* 02043 Electromagnetic Pulse — WR: 조우 7장 버림, Electro 있으면 배치/없으면 surge / 부스트★: 조우 3장. */
MC.defineCardFx('electromagnetic-pulse', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'boostDrain', count:7 }, { fx:'summonElectroIfDiscarded' }],
  boostStarEffects:[{ fx:'boostDrain', count:3 }],
});
/* 02044 Lightning Bolt — WR: 조우 2장 버림, 버린 부스트당 간접 피해 / 부스트★: 조우 3장. */
MC.defineCardFx('lightning-bolt', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'boostDrain', count:2 }, { fx:'damagePerBoostDiscarded' }],
  boostStarEffects:[{ fx:'boostDrain', count:3 }],
});
/* 02045 Shock Therapy — WR: 조우 1/히어로 버림, 버린 부스트당 빌런 1 회복 / 부스트★: 조우 3장. */
MC.defineCardFx('shock-therapy', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'boostDrain', countPerHero:1 }, { fx:'healVillain', amountFrom:'boostDiscarded' }],
  boostStarEffects:[{ fx:'boostDrain', count:3 }],
});
/* 02041 Power Drain — 격퇴 시: 조우 2장 버림, 각 플레이어 버린 부스트당 손패 자원 1장 버림. */
MC.defineCardFx('power-drain', {
  whenCompleted:'runCardEffects',
  whenCompletedEffects:[{ fx:'boostDrain', count:2 }, { fx:'discardResourceEachPlayerPerBoost' }],
});

/* ═══ Running Interference (Tombstone) ═══ */
/* 손패에서 지정 타입(기본 mental/physical) 자원 아이콘 카드 1장 버림 (Tombstone 강제반응).
   공식: "🧠 또는 💪 자원 1장 버림 (가능하면)" — 무작위 아님, 소유 플레이어가 선택. 후보 2장+ 시 선택 pending. */
MC.EFFECTS.discardResourceFromHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const types = p.types || ['mental','physical'];
  MC.setupResourceDiscardPick(G, {
    queue: [pl.uid], perPlayerCount: 1, types,
    prompt: '톰스톤 — ' + types.map(t => ({mental:'🧠',physical:'💪',energy:'⚡'}[t] || t)).join(' 또는 ') + ' 자원 1장 버림',
    reason: 'Tombstone',
  });
};

/* 02047 Tombstone — Criminal 하수인. 강제반응: 공격+피해 후 mental/physical 자원 1장 버림. 공격 애니 있음. */
MC.defineCardFx('tombstone', {
  vfx:{ attack:'tombstoneStrike' },
  attackDamagedEffects:[{ fx:'discardResourceFromHand', types:['mental','physical'] }],
});

/* 02046 Running Interference — WR: 각 플레이어 [🧠💪 지불 / 이 스킴에 위협 2] 선택. */
MC.defineCardFx('running-interference', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'eachPlayerChoice',
    prompt:'방해 공작 — 🧠💪 자원을 지불하거나, 이 스킴에 위협 2를 배치한다',
    options:[
      { key:'pay', label:'🧠💪 지불', payIcons:{ mental:1, physical:1 }, effects:[] },
      { key:'threat', label:'위협 2 배치', effects:[{ fx:'threatHere', amount:2 }] },
    ] }],
});

/* 02048 All Tied Up — 자신의 신분에 부착. 부착된 캐릭터는 준비/형태 변경 불가.
   행동: 🧠💪 지불 → 이 카드 버림. */
MC.defineCardFx('all-tied-up', {
  attachTarget:'identity',
  identityCannotReady:true,
  identityCannotFlip:true,
  activatedAbility:{ payIcons:{ mental:1, physical:1 }, effect:{ fx:'discardSelfAttachment' } },
});

/* 02049 Media Coverage — 자신의 신분에 부착. 이 플레이어가 공개하는 각 "공개 시"를 1회 추가 발동.
   알터에고 행동: 🧠 지불 → 이 카드 버림. */
MC.defineCardFx('media-coverage', {
  attachTarget:'identity',
  wrDoubling:true,
  activatedAbility:{ form:'alter-ego', payCost:{ type:'mental', count:1 },
    effect:{ fx:'discardSelfAttachment' } },
});

})(typeof window !== 'undefined' ? window : globalThis);
