/* ═══════════════════════════════════════════════════════════════
   미즈마블(mc05) 시그니처 카드 효과 배선 — mcode 오름차순
   ※ 신분 능력(05001a/b)은 mc_cards_zidentity_fx.js. 여기는 시그니처 카드(05002~).
   ※ 이 파일은 db(mc_cards_db.js) 이후 로드되어 defineCardFx로 효과/훅을 병합한다.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 05003 Big Hands — 공격 이벤트. 히어로 행동(공격): 적에게 4 피해. 거대화한 주먹으로 강타. */
MC.defineCardFx('big-hands', {
  effects: [{ fx:'dealDamage', target:'chosen', amount:4 }],
  vfx: { event:'embiggen' },
  textKo: '이벤트 · 공격(Attack) · 초능력(Superpower). Cost 2. 💪 피지컬.\n\n히어로 행동 (공격): 적 하나에게 4 피해.\n\n*"손이 이-만큼 커지면? 이런 것도 되지!"* — 거대화한 주먹으로 내리찍는다.\n\n※ 미즈마블 시그니처 05003 (mc05)',
});

/* 05004 Sneak By — 저지 이벤트. 히어로 행동(저지): 스킴에서 위협 3 제거. 몸을 늘려 몰래 지나감. */
MC.defineCardFx('sneak-by', {
  effects: [{ fx:'removeThreat', amount:3 }],
  vfx: { event:'threatDrain' },
  textKo: '이벤트 · 기술(Skill) · 저지(Thwart). Cost 2. 🧠 멘탈.\n\n히어로 행동 (저지): 스킴 하나에서 위협 3 제거.\n\n*"살금살금… 아무도 못 봤겠지?"* — 몸을 가늘게 늘여 경비를 슬쩍 빠져나간다.\n\n※ 미즈마블 시그니처 05004 (mc05)',
});

/* 05005 Wiggle Room — 방어 인터럽트 이벤트. 피해 3 방지 + 카드 1장 드로우. 신축으로 충격 흡수. */
MC.defineCardFx('wiggle-room', {
  effects: [{ fx:'preventAmount', amount:3 }, { fx:'draw', amount:1 }],
  vfx: { event:'morphReturn' },
  textKo: '이벤트 · 방어(Defense) · 초능력(Superpower). Cost 0. ⚡ 에너지.\n\n히어로 방해 (방어): 당신이 피해를 입을 때 → 그 피해 중 3 방지. 카드 1장 드로우.\n\n*"몸이 고무 같으면 얻어맞아도 튕겨낼 수 있거든!"* — 충격을 신축으로 흘려보낸다.\n\n※ 미즈마블 시그니처 05005 (mc05)',
});

/* 05006 Aamir Khan — 서포트(Persona). 알터에고 행동: 소진 → 버림 1장을 덱 맨 아래로, 카드 1장 드로우.
   카말라의 오빠 — 신실하고 가족을 챙긴다. */
MC.defineCardFx('aamir-khan', {
  activatedAbility: { form:'alter-ego', exhaust:true, effect:[{ fx:'recycleDiscardBottomDraw' }] },
  vfx: { play:'teenSpirit' },
  textKo: '서포트 · 페르소나(Persona). Cost 1. 🧠 멘탈. 고유(Unique).\n\n알터에고 행동: 아미르 칸을 소진 → 버림 더미의 카드 1장을 덱 맨 아래에 놓고, 카드 1장 드로우.\n\n*"카말라, 늦지 말고… 그리고 몸조심해라."* — 잔소리 속에 담긴 오빠의 걱정.\n\n※ 미즈마블 시그니처 05006 (mc05)',
});

/* 05008 Nakia Bahadir — 서포트(Persona). 알터에고 행동: 소진 → 이번 페이즈 다음 카드 비용 -1.
   카말라의 절친 — 든든한 조언자. */
MC.defineCardFx('nakia-bahadir', {
  activatedAbility: { form:'alter-ego', exhaust:true, effect:[{ fx:'reduceNextPlayCost', amount:1 }] },
  vfx: { play:'teenSpirit' },
  textKo: '서포트 · 페르소나(Persona). Cost 1. ⚡ 에너지. 고유(Unique).\n\n알터에고 행동: 나키아 바하디르를 소진 → 이번 페이즈에 플레이하는 다음 카드의 비용 -1.\n\n*"네가 뭘 하든 난 네 편이야, 카말라."* — 절친의 한마디가 힘이 된다.\n\n※ 미즈마블 시그니처 05008 (mc05)',
});

/* 05009 Biokinetic Polymer Suit — 업그레이드(Armor). 히어로 자원: 소진 → 이벤트용 와일드 자원 1.
   브루노가 만든 신축 슈트. */
MC.defineCardFx('biokinetic-polymer-suit', {
  resourceGenerator: { form:'hero', exhaust:true, icons:{ wild:1 } },
  vfx: { play:'morphReturn' },
  textKo: '업그레이드 · 방어구(Armor). Cost 1. 🧠 멘탈. 고유(Unique).\n\n히어로 자원: 바이오키네틱 폴리머 슈트를 소진 → 이벤트를 위한 🌟 와일드 자원 1 생성.\n\n*"브루노가 만들어준 슈트 — 나처럼 쭉쭉 늘어나!"*\n\n※ 미즈마블 시그니처 05009 (mc05)\n※ 공식은 "이벤트에만" 사용 가능 — 현재 구현은 와일드 자원 생성(카드 유형 제한은 향후 강화)',
});

/* 05010 Embiggen! — 업그레이드(Condition). 히어로 방해: 공격 이벤트 플레이 시 소진 → 그 이벤트 피해 +2. */
MC.defineCardFx('embiggen', {
  eventBoost: { trait:'attack', stat:'damage', amount:2, vfx:'embiggen' },
  vfx: { play:'embiggen' },
  textKo: '업그레이드 · 상태(Condition) · 초능력(Superpower). Cost 2. ⚡ 에너지.\n\n히어로 방해: 공격(Attack) 이벤트를 플레이할 때 → Embiggen!을 소진 → 그 이벤트가 주는 피해 +2.\n\n*"더 크게! EMBIGGEN!"* — 주먹을 산더미만 하게 부풀린다.\n\n※ 미즈마블 시그니처 05010 (mc05)',
});

/* 05011 Shrink — 업그레이드(Condition). 히어로 방해: 저지 이벤트 플레이 시 소진 → 그 이벤트 위협 제거 +2. */
MC.defineCardFx('shrink', {
  eventBoost: { trait:'thwart', stat:'threat', amount:2, vfx:'morphReturn' },
  vfx: { play:'morphReturn' },
  textKo: '업그레이드 · 상태(Condition) · 초능력(Superpower). Cost 2. 🧠 멘탈.\n\n히어로 방해: 저지(Thwart) 이벤트를 플레이할 때 → Shrink를 소진 → 그 이벤트가 제거하는 위협 +2.\n\n*"작아지면 아무 데나 비집고 들어갈 수 있지!"* — 몸을 개미만큼 줄여 문제의 핵심을 파고든다.\n\n※ 미즈마블 시그니처 05011 (mc05)',
});

/* 05002 Red Dagger — 동료. 처치 인터럽트: 서로 다른 자원 2개 지불 → 적에 2피해 + 손 반환. */
MC.defineCardFx('red-dagger', {
  defeatInterrupt: { damage:2, differentTypes:2, vfx:'redDaggerStrike',
    prompt:'레드 대거 처치 — 서로 다른 자원 2개를 지불하면 적 1명에게 2 피해 + 레드 대거를 손으로 되돌립니다' },
  vfx: { play:'redDaggerEnter' },
});

/* 05007 Bruno Carrelli — 서포트. 능력 2개: AE 저장 / 어느 폼이든 회수(최대 3장). */
MC.defineCardFx('bruno-carrelli', {
  activatedAbilities: [
    { form:'alter-ego', exhaust:true, special:'brunoStore',
      label:'알터에고: 손패 1장을 엎어서 보관' },
    { exhaust:true, special:'brunoRetrieve',
      label:'보관 카드 최대 3장을 손으로 회수' },
  ],
  vfx: { play:'brunoPlace' },
});

/* 브루노 저장: 손패 1장 선택 → 엎어서 보관 pending. */
MC.HANDLERS.brunoStore = function(G, ctx){
  const pl = ctx.player, card = ctx.card;
  if (!pl.hand.length){ MC.log(G, '보관할 손패 없음'); return; }
  G.pending = { kind:'brunoStorePick', player: pl.uid, brunoUid: card.uid,
    handUids: pl.hand.map(c => c.uid),
    prompt: '브루노에게 엎어서 보관할 카드 1장을 선택하세요' };
  MC.log(G, MC.nameOf(card) + ' — 보관할 카드 선택 대기');
};

/* 브루노 회수: 보관 카드 최대 3장 선택 → 손으로 pending. */
MC.HANDLERS.brunoRetrieve = function(G, ctx){
  const pl = ctx.player, card = ctx.card;
  const stored = card.stored || [];
  if (!stored.length){ MC.log(G, '보관된 카드 없음'); return; }
  G.pending = { kind:'brunoRetrievePick', player: pl.uid, brunoUid: card.uid,
    storedUids: stored.map(c => c.uid), chosen: [], max: 3,
    prompt: '회수할 보관 카드를 최대 3장 선택하세요' };
  MC.log(G, MC.nameOf(card) + ' — 회수할 카드 선택 대기 (보관 ' + stored.length + '장)');
};

/* 05012 Nova — 동료. 난입: 적이 당신에게 공격 개시 시 ⚡1 소비 → 그 적에게 2피해 (반복 가능). */
MC.defineCardFx('nova-ally', {
  attackInitiateInterrupt: { cost:{ energy:1 }, damage:2, vfx:'novaBlast' },
  vfx: { play:'novaEnter' },
});

/* 05018 Lockjaw — 동료(basic). 당신의 턴 동안 버린더미에서 록조를 플레이 가능(정상 비용 지불). 반복 재플레이 블록 동료. */
MC.defineCardFx('lockjaw', {
  playableFromDiscard: true,
  vfx: { play:'lockjawTeleport' },
});

})(typeof window !== 'undefined' ? window : globalThis);
