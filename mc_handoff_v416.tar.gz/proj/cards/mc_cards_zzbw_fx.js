/* ═══════════════════════════════════════════════════════════════════
   블랙위도우(Black Widow) 시그니처 fx — mcode 08002~08010 (히어로 팩 mc07/코드08)
   신분(08001a/b)은 zidentity_fx.js. Preparation 메커니즘은 MC.triggerPreparation 헬퍼 재사용.
   ═══════════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
if (!MC || !MC.defineCardFx) return;

/* 08031 Rapid Response (신속 대응) — db 미등록분 신규 등록 (rapid-response는 미즈마블 05013와 충돌 → slug rapid-response-bw). */
if (MC.registerCards && !MC.cardDef('rapid-response-bw')){
  MC.registerCards({
    'rapid-response-bw': {
      code:'rapid-response-bw', type:'upgrade', name:'신속 대응', nameEn:'Rapid Response',
      side:'player', cost:2, aspect:'leadership', traits:['preparation','tactic'],
      resources:{ mental:1 }, hero:'black-widow-hero', mcode:'08031', maxPerPlayer:1,
    },
  });
}
/* 08031 Rapid Response — 리더십. 준비(Preparation)·Tactic. 비용 2, 멘탈 1. 플레이어당 최대 1.
   히어로 반응: 통제하던 동료가 격파된 후 → 버림 → 버림 더미에서 그 동료를 전장에 복귀 + 1 피해.
   구현: activatedAbility(preparation, reviveAllyFromDiscard damage:1). */
MC.defineCardFx('rapid-response-bw', {
  activatedAbility: { name:'신속 대응', form:'hero', preparation:true, effect:[{ fx:'reviveAllyFromDiscard', damage:1 }] },
  maxPerPlayer: 1,
  textKo: '업그레이드 — Upgrade. 리더십(Leadership). 준비(Preparation)·Tactic. 비용 2 · 멘탈 1. 플레이어당 최대 1장.\n\n히어로 반응(Hero Response): 통제하던 동료가 격파된 후 → 신속 대응을 버림 → 그 동료를 버림 더미에서 전장에 복귀시키고 1 피해를 준다.\n\n*"쓰러져도 다시 일어선다. 그게 우리 방식이야."*\n\n※ 공식 08031 Rapid Response (Black Widow 히어로 팩) — 자원 멘탈\n※ 구현: 버림 더미 동료 전장 복귀(1 피해) + 준비 발동(와이도우메이커)',
});

/* 08002 Winter Soldier (윈터 솔져) — 동료. Avenger·Spy. 비용 4, ATK 2 / THW 2 / HP 4. 자원 와일드.
   통제하는 Preparation 카드 1장당 플레이 비용 -1. 범용 재사용: costReduction(per:preparationCard). */
MC.defineCardFx('winter-soldier-bw', {
  costReduction: { per:'preparationCard', amount:1 },
  textKo: '동료 — Ally. 어벤져(Avenger)·스파이(Spy). 비용 4 · 와일드 1. ATK 2 / THW 2 / HP 4.\n\n통제하는 준비(Preparation) 카드 1장당 이 카드의 플레이 비용이 1 감소한다.\n\n*"임무를 위해서라면. 오랜만이군, 나타샤."*\n\n※ 공식 08002 Winter Soldier (Black Widow 히어로 팩) — 자원 와일드\n※ 준비 카드를 많이 깔수록 저렴 — 블랙위도우 엔진의 강력한 동료',
});

/* 08003 Covert Ops (은밀 작전) — 이벤트. 저지(Thwart). 비용 3, 멘탈 1.
   행동(저지): 스킴 1개에서 위협 4 제거 + 빌런 혼란(Confused). 범용: removeThreat + applyStatus(villain,confused). */
MC.defineCardFx('covert-ops', {
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'removeThreat', scheme:'chosen', amount:4 },
    { fx:'applyStatus', target:'villain', status:'confused' },
  ],
  textKo: '이벤트 — Event. 저지(Thwart). 비용 3 · 멘탈 1.\n\n행동(Action) (저지): 스킴 1개에서 위협 4를 제거한다. 빌런을 혼란(Confused)시킨다.\n\n*"그림자 속에서 처리한다. 아무도 모르게."*\n\n※ 공식 08003 Covert Ops (Black Widow 히어로 팩) — 자원 멘탈\n※ 위협 제거 + 빌런 혼란(다음 활성화 시 공격/암약 택1 무력화)',
});

/* 08004 Dance of Death (죽음의 춤) — 이벤트. 공격(Attack). 비용 3, 에너지 1.
   히어로 행동: 순서대로 3연격 — 적에 1 피해 / 적에 2 피해 / 적에 3 피해 (각각 대상 선택 가능).
   범용: dealDamage(target:chosen) 3회 순차. */
MC.defineCardFx('dance-of-death', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'dealDamage', target:'chosen', amount:1 },
    { fx:'dealDamage', target:'chosen', amount:2 },
    { fx:'dealDamage', target:'chosen', amount:3 },
  ],
  textKo: '이벤트 — Event. 공격(Attack). 비용 3 · 에너지 1.\n\n히어로 행동(Hero Action): 다음 3번의 공격을 순서대로 한다 — 적에게 1 피해 / 적에게 2 피해 / 적에게 3 피해. (각 공격의 대상을 따로 정할 수 있다.)\n\n*"죽음의 춤을 함께 추실까?"*\n\n※ 공식 08004 Dance of Death (Black Widow 히어로 팩) — 자원 에너지\n※ 총 6 피해를 여러 적에게 분산 가능 — 하수인 정리 + 빌런 마무리',
});

/* 08005 Safe House #29 (은신처 #29) — 지원(Support). Location·S.H.I.E.L.D. 비용 1, 물리 1.
   알터에고 행동: 소진 + 버림 더미의 Preparation 카드 1장 선택 → 손에 추가. 범용: recallFromDiscard(trait:preparation). */
MC.defineCardFx('safe-house-29', {
  activatedAbility: {
    name: '은신처 #29', form: 'alter-ego', exhaust: true,
    effect: [{ fx:'recallFromDiscard', trait:'preparation' }],
  },
  textKo: '지원 — Support. 장소(Location)·쉴드(S.H.I.E.L.D.). 비용 1 · 물리 1.\n\n알터에고 행동(Alter-Ego Action): 은신처 #29를 소진하고 버림 더미의 준비(Preparation) 카드 1장을 선택 → 그 카드를 손에 추가한다.\n\n*"안전 가옥. 여기선 잠시 숨 돌릴 수 있어."*\n\n※ 공식 08005 Safe House #29 (Black Widow 히어로 팩) — 자원 물리\n※ 발동해서 버린 준비 카드를 회수 — 준비 카드 재활용 엔진',
});

/* 08006 Attacrobatics (아크로바틱스) — 업그레이드. 공격(Attack)·준비(Preparation)·Skill. 비용 1, 물리 1.
   원본: 히어로 인터럽트 — 부스트 카드가 뒤집힐 때 버림 → 그 부스트 아이콘 취소 + 취소된 아이콘 1개당 빌런에 1 피해.
   구현: 부스트 공개는 빌런 활성화 중 자동 계산되어 소급 취소가 흐름을 깨므로, activatedAbility(hero, preparation)로
   실용화 — 빌런에 2 피해(취소 아이콘 근사) + 준비 발동(Widowmaker 추가 1 피해). */
MC.defineCardFx('attacrobatics', {
  activatedAbility: {
    name: '아크로바틱스', form: 'hero', preparation: true,
    effect: [{ fx:'dealDamage', target:'villain', amount:2 }],
  },
  textKo: '업그레이드 — Upgrade. 공격(Attack)·준비(Preparation)·Skill. 비용 1 · 물리 1.\n\n히어로 인터럽트(Hero Interrupt): 부스트 카드가 뒤집힐 때 → 아크로바틱스를 버림 → 그 부스트 아이콘을 취소하고, 취소된 아이콘 1개당 빌런에게 1 피해를 준다.\n\n*"우아하게, 그리고 치명적으로."*\n\n※ 공식 08006 Attacrobatics (Black Widow 히어로 팩) — 자원 물리\n※ 구현: 부스트 공개는 빌런 활성화 중 자동 계산되어 소급 취소가 어려워, 히어로 행동으로 빌런에 2 피해 + 준비 발동(와이도우메이커 추가 1 피해)으로 실용화\n※ 발동 시 버려짐 — 은신처 #29로 회수 가능',
});

/* 08007 Black Widows Gauntlet (블랙위도우의 건틀릿) — 업그레이드. Tech. 비용 1, 물리 1.
   자원(Resource): 소진 → 준비(Preparation) 카드용 와일드 자원 1개 생성. 범용: resourceGenerator(wild). */
MC.defineCardFx('bw-gauntlet', {
  resourceGenerator: { form:'hero', exhaust:true, icons:{ wild:1 } },
  textKo: '업그레이드 — Upgrade. Tech. 비용 1 · 물리 1.\n\n자원(Resource): 블랙위도우의 건틀릿을 소진 → 준비(Preparation) 카드를 위한 와일드 자원 1개를 생성한다.\n\n*"이 건틀릿 하나면 어떤 상황도 대비할 수 있지."*\n\n※ 공식 08007 Black Widows Gauntlet (Black Widow 히어로 팩) — 자원 물리\n※ 준비 카드 전용 자원 — 위도우 바이트·그래플링 훅 등 저렴하게 전개',
});

/* 08008 Grappling Hook (그래플링 훅) — 업그레이드. 준비(Preparation)·Tech. 비용 2, 멘탈 1.
   히어로 인터럽트(Hero Interrupt): 배신(Treachery)이 공개될 때 → 그래플링 훅을 버림 → 그 배신의 효과를 취소하고 버린다.
   구현: interruptOn(encounterType:treachery, form:hero) + preparation trait → 발동 시 취소 + 카드 버림 + Widowmaker. */
MC.defineCardFx('grappling-hook', {
  interruptOn: { encounterType:'treachery', form:'hero' },
  textKo: '업그레이드 — Upgrade. 준비(Preparation)·Tech. 비용 2 · 멘탈 1.\n\n히어로 인터럽트(Hero Interrupt): 배신(Treachery) 카드가 공개될 때 → 그래플링 훅을 버림 → 그 배신의 효과를 취소하고 버린다.\n\n*"위험을 미리 읽고 빠져나간다."*\n\n※ 공식 08008 Grappling Hook (Black Widow 히어로 팩) — 자원 멘탈\n※ 배신 완전 무력화 + 준비 발동 → 와이도우메이커(적 1 피해) 연동\n※ 발동 시 버려짐 — 은신처 #29로 회수 가능',
});

/* 08009 Synth-Suit (신스 수트) — 업그레이드. Armor·Tech. 비용 3, 에너지 1.
   블랙위도우 +1 DEF. / 히어로 반응: 준비 카드 능력 발동 후 → 신스 수트 소진 → 블랙위도우 준비(ready).
   범용: statMod(defense+1). ※ 재준비 반응은 Preparation 발동 감지와 함께 후속 배선. */
MC.defineCardFx('synth-suit', {
  statMod: { stat:'defense', amount:1 },
  textKo: '업그레이드 — Upgrade. Armor·Tech. 비용 3 · 에너지 1.\n\n블랙위도우는 방어력 +1을 얻는다.\n\n히어로 반응(Hero Response): 통제하는 준비(Preparation) 카드의 능력을 발동한 후 → 신스 수트를 소진 → 블랙위도우를 준비(ready) 상태로 만든다.\n\n*"이 슈트가 날 지켜줄 거야."*\n\n※ 공식 08009 Synth-Suit (Black Widow 히어로 팩) — 자원 에너지\n※ +1 DEF 상시 + 준비 발동마다 재준비(추가 행동) — 강력한 엔진 부품',
});

/* 08010 Widows Bite (위도우 바이트) — 업그레이드. 준비(Preparation)·Tech. 비용 1, 에너지 1.
   히어로 반응(attack): 하수인이 등장한 후 → 위도우 바이트를 버림 → 그 하수인에게 2 피해 + 기절.
   구현: activatedAbility(hero, preparation:true, targetType:minion) — 발동 시 카드 버림 + Widowmaker(적 1 피해).
   ※ "하수인 등장 후" 타이밍은 실용적으로 히어로 폼 수동 발동(대상 하수인 선택)으로 처리. */
MC.defineCardFx('widows-bite', {
  activatedAbility: {
    name: '위도우 바이트', form: 'hero', preparation: true, targetType: 'minion',
    effect: [
      { fx:'dealDamage', target:'chosen', amount:2 },
      { fx:'applyStatus', target:'chosen', status:'stunned' },
    ],
  },
  textKo: '업그레이드 — Upgrade. 준비(Preparation)·Tech. 비용 1 · 에너지 1.\n\n히어로 반응(Hero Response) (공격): 하수인이 등장한 후 → 위도우 바이트를 버린다 → 그 하수인에게 2 피해를 주고 기절(Stunned)시킨다.\n\n*"한 방이면 충분해."*\n\n※ 공식 08010 Widows Bite (Black Widow 히어로 팩) — 자원 에너지\n※ 준비 카드 발동 → 와이도우메이커(적 1명에 추가 1 피해) 연동\n※ 발동 시 버려짐 — 은신처 #29로 회수 가능',
});

/* ═══ 블랙위도우 정의(Justice) 성향 카드 ═══ */

/* 08011 Agent Coulson (에이전트 콜슨) — 동료. 정의. S.H.I.E.L.D.·Spy. 비용 3, 멘탈 1. ATK 1 / THW 2 / HP 3.
   반응: 등장 후 → 덱과 버림 더미에서 준비(Preparation) 카드 1장을 찾아 손에 추가 + 덱 셔플.
   범용: whenPlayed:searchDeckToHand(trait:preparation, includeDiscard, shuffle). */
MC.defineCardFx('agent-coulson', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'searchDeckToHand', trait:'preparation', includeDiscard:true, shuffle:true }],
  textKo: '동료 — Ally. 정의(Justice). S.H.I.E.L.D.·Spy. 비용 3 · 멘탈 1. ATK 1 / THW 2 / HP 3.\n\n반응(Response): 에이전트 콜슨이 등장한 후 → 덱과 버림 더미에서 준비(Preparation) 카드 1장을 찾아 손에 추가한다. 그 후 덱을 섞는다.\n\n*"필요한 장비는 제가 준비해 두었습니다, 요원님."*\n\n※ 공식 08011 Agent Coulson (Black Widow 히어로 팩) — 자원 멘탈\n※ 준비 카드 즉시 서치 — 블랙위도우 엔진 가속',
});

/* 08012 Quake (퀘이크) — 동료. 정의. Avenger·S.H.I.E.L.D. 비용 2, 에너지 1. ATK 2 / THW 1 / HP 2.
   반응: 하수인이 암약한 후 → 퀘이크 소진 → 그 하수인에게 2 피해.
   구현: activatedAbility(exhaust, targetType:minion, 2피해) — 수동 발동으로 실용화. */
MC.defineCardFx('quake', {
  activatedAbility: {
    name: '퀘이크', exhaust: true, targetType: 'minion',
    effect: [{ fx:'dealDamage', target:'chosen', amount:2 }],
  },
  textKo: '동료 — Ally. 정의(Justice). Avenger·S.H.I.E.L.D. 비용 2 · 에너지 1. ATK 2 / THW 1 / HP 2.\n\n반응(Response): 하수인이 암약한 후 → 퀘이크를 소진 → 그 하수인에게 2 피해.\n\n*"진동 하나로 네 균형을 무너뜨리겠어."*\n\n※ 공식 08012 Quake (Black Widow 히어로 팩) — 자원 에너지\n※ 하수인 암약 대응 (구현: 수동 발동, 대상 하수인 2 피해)',
});

/* 08013 Stealth Strike (은밀한 일격) — 이벤트. 정의. 공격(Attack). 비용 3, 멘탈 1.
   히어로 행동(공격): 적에게 4 피해. 격파 시 → 스킴 위협 2 제거.
   범용: dealDamage(onDefeat) — 격파 시 후속 효과 인덱스 재사용(special 제거). */
MC.defineCardFx('stealth-strike', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'dealDamage', target:'chosen', amount:4, isAttack:true, onDefeat:[{ fx:'removeThreat', scheme:'main', amount:2 }] }],
  needsEnemyTarget: true,
  textKo: '이벤트 — Event. 정의(Justice). 공격(Attack). 비용 3 · 멘탈 1.\n\n히어로 행동(Hero Action) (공격): 적에게 4 피해. 이 공격으로 그 적이 격파되면 → 스킴에서 위협 2를 제거한다.\n\n*"그림자에서 나와, 단숨에."*\n\n※ 공식 08013 Stealth Strike (Black Widow 히어로 팩) — 자원 멘탈\n※ 4 피해 + 격파 시 위협 2 제거 — 공격/저지 겸용',
});

/* 08017 Counterintelligence (방첩) — 업그레이드. 정의. 준비(Preparation)·Skill. 비용 2, 에너지 1. 플레이어당 최대 1.
   인터럽트: 메인 스킴에 위협이 놓일 때 → 방첩을 버림 → 그 위협 3을 방지.
   범용: threatPrevent{amount:3, discardSelf:true, form:hero} — placeThreat 중앙 집계가 upgrade Preparation 스캔(발동 시 버림+Widowmaker). */
MC.defineCardFx('counterintelligence', {
  threatPrevent: { amount:3, discardSelf:true, form:'hero' },
  maxPerPlayer: 1,
  textKo: '업그레이드 — Upgrade. 정의(Justice). 준비(Preparation)·Skill. 비용 2 · 에너지 1. 플레이어당 최대 1장.\n\n인터럽트(Interrupt): 메인 스킴에 위협이 놓일 때 → 방첩을 버림 → 그 위협 중 3을 방지한다.\n\n*"적의 정보를 먼저 읽으면, 그들의 수는 통하지 않아."*\n\n※ 공식 08017 Counterintelligence (Black Widow 히어로 팩) — 자원 에너지\n※ 메인 위협 3 방지 + 준비 발동(와이도우메이커 빌런 피해) — 암약 방어의 핵심',
});

/* 08018 Spycraft (첩보술) — 업그레이드. 정의. 준비(Preparation)·Skill. 비용 1, 물리 1.
   Spy 캐릭터 통제 시에만 플레이. / 인터럽트: 조우 카드가 공개될 때 → 첩보술을 버림 → 그 카드 효과 취소+버림 → 조우덱에서 1장 더 공개.
   범용: interruptOn{encounterType:'any', form:hero, thenReveal:1} — 그래플링 훅에서 확장한 upgrade Preparation 인터럽트 재사용(데이터만). */
MC.defineCardFx('spycraft', {
  interruptOn: { encounterType:'any', form:'hero', thenReveal:1 },
  playCondition: { hasTrait:'spy', scope:'anyControlled' },
  textKo: '업그레이드 — Upgrade. 정의(Justice). 준비(Preparation)·Skill. 비용 1 · 물리 1.\n\nSpy(스파이) 특성 캐릭터를 통제할 때만 플레이할 수 있다.\n\n인터럽트(Interrupt): 조우 카드가 공개될 때 → 첩보술을 버림 → 그 카드의 효과를 취소하고 버린다. 그 후 조우덱에서 카드 1장을 새로 공개한다.\n\n*"그들이 무엇을 계획하든, 난 이미 알고 있지."*\n\n※ 공식 08018 Spycraft (Black Widow 히어로 팩) — 자원 물리\n※ 모든 조우 카드 취소(배신·공격·부작용 불문) + 추가 공개 — 만능 방어',
});

/* ═══ 블랙위도우 기타 성향 카드 ═══ */

/* 08023 Quincarrier (퀸캐리어) — 지원. 기본. Avenger·Vehicle. 비용 3, 멘탈 1.
   Avenger 신분일 때만 플레이. 자원: 소진 → 와일드 자원 1개 생성. 범용: resourceGenerator(wild). */
MC.defineCardFx('quincarrier', {
  resourceGenerator: { form:'hero', exhaust:true, icons:{ wild:1 } },
  textKo: '지원 — Support. 기본(Basic). Avenger·Vehicle. 비용 3 · 멘탈 1.\n\nAvenger 특성 신분일 때만 플레이할 수 있다.\n\n자원(Resource): 퀸캐리어를 소진 → 와일드 자원 1개를 생성한다.\n\n*"어벤져스의 발이 되어주는 비행 요새."*\n\n※ 공식 08023 Quincarrier (Black Widow 히어로 팩) — 자원 멘탈\n※ 만능 와일드 자원 — 어떤 성향 카드든 지불 보조',
});

/* 08024 Target Acquired (목표 포착) — 업그레이드. 기본. 준비(Preparation)·Skill. 비용 1, 물리 1. 플레이어당 최대 1.
   원본: 히어로 반응 — 부스트 뒤집힌 후 버림 → 그 부스트 능력 취소. 구현: activatedAbility(preparation, 빌런 2피해 근사). */
MC.defineCardFx('target-acquired', {
  activatedAbility: { name:'목표 포착', form:'hero', preparation:true, effect:[{ fx:'dealDamage', target:'villain', amount:2 }] },
  maxPerPlayer: 1,
  textKo: '업그레이드 — Upgrade. 기본(Basic). 준비(Preparation)·Skill. 비용 1 · 물리 1. 플레이어당 최대 1장.\n\n히어로 반응(Hero Response): 부스트 카드가 뒤집힌 후 → 목표 포착을 버림 → 그 카드의 부스트 능력을 취소한다.\n\n*"조준 완료. 놓치지 않아."*\n\n※ 공식 08024 Target Acquired (Black Widow 히어로 팩) — 자원 물리\n※ 구현: 부스트 취소를 히어로 행동으로 실용화 — 빌런 2 피해 + 준비 발동(와이도우메이커)',
});

/* 08030 Counterattack (반격) — 업그레이드. 공격. 준비(Preparation)·Tactic. 비용 1, 물리 1. 플레이어당 최대 1.
   원본: 히어로 반응(공격) — 적 공격으로 피해받은 후 버림 → 그 적에 동일 피해. 구현: activatedAbility(preparation, 대상 적 2피해). */
MC.defineCardFx('counterattack', {
  activatedAbility: { name:'반격', form:'hero', preparation:true, targetType:'enemy', effect:[{ fx:'dealDamage', target:'chosen', amount:2 }] },
  maxPerPlayer: 1,
  textKo: '업그레이드 — Upgrade. 공격(Aggression). 준비(Preparation)·Tactic. 비용 1 · 물리 1. 플레이어당 최대 1장.\n\n히어로 반응(Hero Response) (공격): 적의 공격으로 피해를 받은 후 → 반격을 버림 → 그 적에게 받은 만큼 피해.\n\n*"때린 만큼 돌려준다."*\n\n※ 공식 08030 Counterattack (Black Widow 히어로 팩) — 자원 물리\n※ 구현: 대상 적에게 반격 피해 + 준비 발동(와이도우메이커)',
});

/* 08032 Defensive Stance (방어 자세) — 업그레이드. 보호. 준비(Preparation)·Tactic. 비용 2, 에너지 1. 플레이어당 최대 1.
   히어로 인터럽트: 피해를 받으려 할 때 → 버림 → 그 피해 3을 방지. 범용: defenseInterrupt{prevent:3, discardSelf, preparation}. */
MC.defineCardFx('defensive-stance', {
  defenseInterrupt: { prevent:3, discardSelf:true, preparation:true },
  maxPerPlayer: 1,
  textKo: '업그레이드 — Upgrade. 보호(Protection). 준비(Preparation)·Tactic. 비용 2 · 에너지 1. 플레이어당 최대 1장.\n\n히어로 인터럽트(Hero Interrupt): 피해를 받으려 할 때 → 방어 자세를 버림 → 그 피해 중 3을 방지한다.\n\n*"공격을 미리 읽으면, 피하는 건 쉬워."*\n\n※ 공식 08032 Defensive Stance (Black Widow 히어로 팩) — 자원 에너지\n※ 피해 3 방지 + 준비 발동(와이도우메이커 빌런 피해) — 방어형 준비 카드',
});

/* 08033 Espionage (첩보) — 업그레이드. 기본. 준비(Preparation)·Skill. 비용 1, 물리 1.
   Spy 통제 시만 플레이. 원본: 인터럽트 — surge 해소될 때 버림 → 2 드로우. 구현: activatedAbility(preparation, 2 드로우). */
MC.defineCardFx('espionage', {
  activatedAbility: { name:'첩보', form:'hero', preparation:true, effect:[{ fx:'draw', amount:2 }] },
  playCondition: { hasTrait:'spy', scope:'anyControlled' },
  textKo: '업그레이드 — Upgrade. 기본(Basic). 준비(Preparation)·Skill. 비용 1 · 물리 1.\n\nSpy 특성 캐릭터를 통제할 때만 플레이할 수 있다.\n\n인터럽트(Interrupt): 조우 카드의 쇄도(Surge)가 해소되려 할 때 → 첩보를 버림 → 카드 2장을 뽑는다.\n\n*"정보가 곧 힘이야."*\n\n※ 공식 08033 Espionage (Black Widow 히어로 팩) — 자원 물리\n※ 구현: 히어로 행동으로 2장 드로우 + 준비 발동(와이도우메이커)',
});

})(typeof window !== 'undefined' ? window : globalThis);
