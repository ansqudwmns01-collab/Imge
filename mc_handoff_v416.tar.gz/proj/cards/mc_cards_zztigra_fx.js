/* ═══════════════════════════════════════════════════════════════
   타이그라(tigra-ally 01051) 반응 배선 — 이전 todoFx:true라 미발동이었음.
   공식: "반응: 타이그라가 공격하여 하수인을 처치한 후 → 그녀에게서 1 피해 회복."
   ※ FAQ: 회복은 consequential(atkCost) 피해 적용 *전*에 발생 → allyAttack에서
     fireCardHook('afterAttack')가 atkCost보다 먼저 발화되므로 타이밍 일치.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

// afterAttack 훅 핸들러: 공격 대상이 하수인이고 이 공격으로 처치(hp<=0)됐으면 공격자(타이그라) 1 회복.
MC.HANDLERS.tigraAfterAttack = function(G, ctx){
  const tigra = ctx.attacker || ctx.self;
  const target = ctx.target;
  if (!tigra || !target) return;
  // "하수인을 처치한 후" — 대상이 하수인 + 이 공격으로 hp 0 이하(처치)
  const isMinion = target.kind === 'minion' || target.type === 'minion';
  const defeated = target.hp === undefined || target.hp <= 0;
  if (isMinion && defeated){
    MC.healTarget(G, tigra, 1);
    MC.log(G, MC.nameOf(tigra) + ' 반응 — 하수인 처치 후 1 피해 회복');
    // 연출 힌트 (있으면)
    if (!G.fxTigraHeal) G.fxTigraHeal = { uid: tigra.uid };
  }
};

// 카드 def에 afterAttack 훅 이름 심기 (fireCardHook이 cardDef.afterAttack로 조회) + todoFx 해제.
MC.defineCardFx('tigra-ally', { afterAttack: 'tigraAfterAttack' });

})(typeof window !== 'undefined' ? window : globalThis);
