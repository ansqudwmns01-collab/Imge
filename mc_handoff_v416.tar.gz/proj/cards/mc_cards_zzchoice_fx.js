/* ═══════════════════════════════════════════════════════════════
   선택(choice)이 필요한 카드 fx — 이전 todoFx:true로 미배선이라 선택 모달 없이
   기본 동작만 돌던(=사용자 "하드코딩" 지적) 카드들을 기존 선택 인프라에 배선한다.
   재사용: offerChoice(revealChoice pending) + chooseEnemy(대상 선택) + resolveTarget('chosen').
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 닉 퓨리(nick-fury 01084) — 강제 반응: 등장 후 다음 중 하나 선택.
   • 스킴에서 위협 2 제거  • 카드 3장 드로우  • 적 1명에게 4 피해
   피해 옵션은 chooseEnemy로 대상을 플레이어가 직접 선택(하드코딩 아님). */
MC.defineCardFx('nick-fury', {
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'offerChoice', prompt:'닉 퓨리 — 하나를 선택',
      options: [
        { key:'thwart', label:'스킴에서 위협 2 제거',
          effects:[{ fx:'removeThreat', amount:2 }] },
        { key:'draw',   label:'카드 3장 드로우',
          effects:[{ fx:'draw', amount:3, who:'self' }] },
        { key:'damage', label:'적 1명에게 4 피해',
          effects:[{ fx:'chooseEnemy', prompt:'닉 퓨리 — 피해 대상 선택',
                     then:[{ fx:'dealDamage', amount:4, target:'chosen' }] }] },
      ] },
  ],
});

/* 미래학자(Futurist, 토니 스타크 01029b 신분 액션) — 이전 effect:[{fx:'tonyFuturist'}]가
   미등록 fx라 사용 시 에러/무동작이었음. 범용 lookAtTopChoose로 교체:
   덱 위 3장을 보고 1장을 손에 넣고 나머지 2장은 버린다. (라운드당 1회, 알터에고 전용) */
MC.defineCardFx('01029b', {
  identityAction: {
    name: 'Futurist', form: 'alter-ego', oncePerRound: true,
    effect: [{ fx:'lookAtTopChoose', count:3, keep:1,
               prompt:'미래학자 — 손에 넣을 카드 1장 선택 (나머지 2장은 버림)' }],
    vfx: 'arcInstall',
  },
});

/* 범용 효과: 자기 자신(ctx.self=플레이된 동료/카드)의 스탯을 이번 페이즈 동안 +amount.
   allyStatOf가 ally.tempStatBonus[stat]를 합산 → 페이즈 종료 시 자동 리셋(mc_7_core 710행). */
MC.EFFECTS.buffSelfStat = function(G, p, ctx){
  // target: 'hero'/'player' → 플레이어(히어로 신분), 그 외/미지정 → ctx.self(이벤트/동료 자신)
  const target = (p.target === 'hero' || p.target === 'player') ? ctx.player : (ctx.self || ctx.card);
  if (!target) return;
  const stat = p.stat, amt = p.amount || 0;
  if (!target.tempStatBonus) target.tempStatBonus = {};
  target.tempStatBonus[stat] = (target.tempStatBonus[stat] || 0) + amt;
  MC.log(G, MC.nameOf(target) + ' — 이번 페이즈 ' + (stat==='attack'?'ATK':stat==='thwart'?'THW':stat==='defense'?'DEF':stat) + ' +' + amt);
};

/* 스파이더맨(마일즈 spider-man-miles 13019) — 반응: 손에서 플레이 후 → THW 또는 ATK 선택.
   이번 페이즈 동안 선택한 스탯 +2. 이전 todoFx:true라 선택 없이 미동작이었음. */
MC.defineCardFx('spider-man-miles', {
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'offerChoice', prompt:'마일즈 — 이번 페이즈 강화할 능력치 선택',
      options: [
        { key:'atk', label:'ATK +2', effects:[{ fx:'buffSelfStat', stat:'attack', amount:2 }] },
        { key:'thw', label:'THW +2', effects:[{ fx:'buffSelfStat', stat:'thwart', amount:2 }] },
      ] },
  ],
});

})(typeof window !== 'undefined' ? window : globalThis);
