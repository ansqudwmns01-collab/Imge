/* ═══════════════════════════════════════════════════════════════
   캡틴아메리카 시그니처 카드 FX — 히어로 팩 (mc04)
   03002 Agent 13 부터 mcode 순으로 등록. 신분(03001a/b)은 zidentity_fx.js.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 03002 Agent 13 (에이전트 13) — 동료. S.H.I.E.L.D. 셰런 카터. 비용 3, ATK 1, THW 2, HP 3. 🧠멘탈 1. 유니크.
   반응: 등장 후 스킴 하나에서 위협 2 제거.
   범용 whenPlayed:runCardEffects + removeThreat(scheme 미지정 → ctx.targetScheme 우선, 없으면 main). */
MC.defineCardFx('agent-13', {
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'removeThreat', amount:2 },
  ],
  quoteKey: 'agent-13',
  vfx: { entrance:'tacticsInstall', install:'tacticsInstall', basicThwart:'patrol', basicAttack:'gunshot' },
  textKo: '동료 — Ally. S.H.I.E.L.D. 비용 3 · ATK 1 · THW 2 · HP 3 · 🧠멘탈 1 · 유니크.\n\n반응(Response): 에이전트 13이 전장에 들어온 후, 스킴 하나에서 위협 2를 제거한다.\n\n*"작전 개시. 스킴은 내가 정리하죠, 캡틴."*\n\n※ 공식 03002 Agent 13 (Captain America 히어로 팩) — 공식 cap.json 교차검증\n※ 사이드 스킴이 있으면 대상 스킴 선택 · 없으면 메인 스킴에서 제거',
});

/* 03003 Fearless Determination (두려움 없는 결의) — 이벤트. 초능력. 비용 0, 🧠멘탈 1. ×3.
   히어로 행동: 캡틴아메리카 이번 페이즈 THW +1 + 카드 1장 드로우.
   범용: playForm hero + buffSelfStat(target:hero, 페이즈 종료 리셋) + draw. */
MC.defineCardFx('fearless-determination', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [
    { fx:'buffSelfStat', target:'hero', stat:'thwart', amount:1 },
    { fx:'draw', who:'self', amount:1 },
  ],
  vfx: { event:'capReady' },
  textKo: '이벤트 — Event. 초능력(Superpower). 비용 0 · 🧠멘탈 1.\n\n히어로 행동(Hero Action): 캡틴아메리카는 이번 페이즈 동안 THW +1을 얻고, 카드 1장을 뽑는다.\n\n*"한 걸음도 물러서지 않아. 끝까지 막아낸다."*\n\n※ 공식 03003 Fearless Determination (Captain America 히어로 팩) — cap.json 교차검증\n※ THW 보너스는 페이즈 종료 시까지 지속 · 비용 0의 고효율 드로우 + 저지 강화',
});

/* 03004 Heroic Strike (영웅적 일격) — 이벤트. 공격(Attack). 비용 3, 💪물리 1. ×3.
   히어로 행동(공격): 적 하나에게 6 피해. 물리 자원으로 지불했다면 그 적을 기절.
   범용: playForm hero + dealDamage(chosen, isAttack) + applyStatus(chosen, stunned, cond:paidWith physical). */
MC.defineCardFx('heroic-strike', {
  playForm: 'hero',
  effects: [
    { fx:'dealDamage', target:'chosen', amount:6, isAttack:true },
    { fx:'applyStatus', target:'chosen', status:'stunned', cond:{ type:'paidWith', resource:'physical' } },
  ],
  vfx: { event:'shieldToss' },
  textKo: '이벤트 — Event. 공격(Attack). 비용 3 · 💪물리 1.\n\n히어로 행동(공격): 적 하나에게 6의 피해를 입힌다. 이 카드를 💪물리 자원으로 지불했다면, 그 적을 기절(Stun)시킨다.\n\n*"방패는 방어만을 위한 게 아니다."*\n\n※ 공식 03004 Heroic Strike (Captain America 히어로 팩) — cap.json 교차검증\n※ 물리 킥커: 물리 자원으로 지불 시 대상 기절 (paidWith 조건)',
});

/* 03005 Shield Block (방패 막기) — 이벤트. 방어(Defense). 비용 0, 🧠멘탈 1. ×2.
   인터럽트(방어): 피해를 받으려 할 때, 캡틴아메리카의 방패를 소진 → 그 피해 전부 방지.
   방어 이벤트(defense trait + preventAll) → 방어 pending 중 플레이 가능. 방패 준비 필수(playCondition) + 방패 소진(비용). */
MC.defineCardFx('shield-block', {
  playCondition: { type:'hasReadyCard', card:'cap-shield' },   // 준비된 캡틴아메리카의 방패 필요
  effects: [
    { fx:'exhaustNamedCard', card:'cap-shield' },              // 비용: 방패 소진
    { fx:'preventAll' },                                        // 그 피해 전부 방지
  ],
  textKo: '이벤트 — Event. 방어(Defense). 비용 0 · 🧠멘탈 1.\n\n인터럽트(방어): 당신이 피해를 받게 될 때, 캡틴아메리카의 방패를 소진한다 → 그 피해를 전부 방지한다.\n\n*"이 방패는 그 어떤 공격도 막아낸다."*\n\n※ 공식 03005 Shield Block (Captain America 히어로 팩) — cap.json 교차검증\n※ 준비된 캡틴아메리카의 방패(03009)가 있어야 플레이 가능 · 방패를 소진하여 피해 전부 방지',
});

/* 03006 Shield Toss (방패 던지기) — 이벤트. 공격/초능력. 비용 0, ⚡에너지 1. ×2.
   히어로 행동(공격): 손에서 X장을 버리고, 캡틴아메리카의 방패를 플레이 영역에서 손으로 반환 → X명의 서로 다른 적에게 4 피해씩.
   가변 X(=버린 카드 수) + 방패 반환 + 다중 타겟 → special 핸들러(정당한 커스텀). */
MC.HANDLERS.shieldTossPlay = function(G, ctx){
  const pl = ctx.player;
  if (!pl) return;
  // ① 손에서 X장 버림 (ctx.discardUids)
  let x = 0;
  for (const uid of (ctx.discardUids || [])){
    const c = MC.fromHand(pl, uid);
    if (c){ MC.moveToDiscard(G, pl, c, {}); x++; }
  }
  MC.log(G, '방패 던지기 — 손패 ' + x + '장 버림 (X=' + x + ')');
  // ② 캡틴아메리카의 방패를 플레이 영역 → 손으로 반환
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    const i = arr.findIndex(c => c.defCode === 'cap-shield');
    if (i >= 0){
      const shield = arr[i];
      if (shield.attachments && shield.attachments.length) MC.releaseAttachments(G, shield);
      arr.splice(i, 1);
      const fresh = MC.makeInstance(G, 'cap-shield', {}); fresh.ownerUid = pl.uid;
      pl.hand.push(fresh);
      MC.log(G, '캡틴아메리카의 방패 — 손으로 반환');
      break;
    }
  }
  // ③ X명의 서로 다른 적에게 4 피해씩 (dealDamageMulti, lines=X, ctx.targets)
  MC.EFFECTS.dealDamageMulti(G, { amount:4, lines:x }, ctx);
};

MC.defineCardFx('shield-toss', {
  playForm: 'hero',
  playCondition: { type:'hasCardInPlay', card:'cap-shield' },   // 반환할 방패가 플레이 영역에 있어야 함
  special: 'shieldTossPlay',
  uiFlow: 'discardThenMultiTarget',   // UI: X장 버림 선택 → X명 적 선택
  vfx: { event:'shieldToss' },
  textKo: '이벤트 — Event. 공격(Attack) · 초능력(Superpower). 비용 0 · ⚡에너지 1.\n\n히어로 행동(공격): 손에서 X장의 카드를 버리고, 캡틴아메리카의 방패를 플레이 영역에서 손으로 되돌린다 → 서로 다른 적 X명에게 각각 4의 피해를 입힌다.\n\n*"돌아온다 — 언제나."*\n\n※ 공식 03006 Shield Toss (Captain America 히어로 팩) — cap.json 교차검증\n※ X = 버린 카드 수 · 방패가 플레이 영역에 있어야 플레이 가능 · 방패는 손으로 반환',
});

/* 03007 Steve's Apartment (스티브의 아파트) — 서포트. 장소(Location). 비용 1, ⚡에너지 1.
   알터에고 행동: 소진 → 카드 1장 뽑고, 스티브 로저스의 피해 1 회복.
   범용: activatedAbility(form:alter-ego, exhaust) + draw + heal(self). */
MC.defineCardFx('steves-apartment', {
  activatedAbility: {
    form: 'alter-ego',
    exhaust: true,
    effect: [
      { fx:'draw', who:'self', amount:1 },
      { fx:'heal', target:'self', amount:1 },
    ],
  },
  vfx: { recover:'recover' },
  textKo: '서포트 — Support. 장소(Location). 비용 1 · ⚡에너지 1.\n\n알터에고 행동: 스티브의 아파트를 소진한다 → 카드 1장을 뽑고, 스티브 로저스의 피해 1을 회복한다.\n\n*"가끔은 브루클린의 작은 아파트에서 숨을 고를 시간도 필요하지."*\n\n※ 공식 03007 Steve의 아파트 (Captain America 히어로 팩) — cap.json 교차검증\n※ 알터에고 형태에서만 · 소진하여 드로우 + 자가 회복',
});

/* 03008 Captain America's Helmet (캡틴아메리카의 헬멧) — 업그레이드. 방어구(Armor). 비용 1, 💪물리 1.
   인터럽트: 캡틴아메리카가 패배당할 때, HP를 1로 만들고 이 카드를 버린다.
   범용: preventDefeatToHp:1 (applyDamage 패배 방지 훅이 처리). */
MC.defineCardFx('cap-helmet', {
  preventDefeatToHp: 1,
  vfx: { install:'vibraniumArmorInstall' },
  textKo: '업그레이드 — Upgrade. 방어구(Armor). 비용 1 · 💪물리 1.\n\n인터럽트: 캡틴아메리카가 패배당하게 될 때, 그의 체력을 1로 만든다. 그 후 이 카드를 버린다.\n\n*"머리는 지켜야지. 아직 할 일이 남았으니까."*\n\n※ 공식 03008 Captain America의 헬멧 (Captain America 히어로 팩) — cap.json 교차검증\n※ 패배 순간 HP를 1로 되돌리고 헬멧은 버림 더미로 (1회성 구명)',
});

/* 03009 Captain America's Shield (캡틴아메리카의 방패) — 업그레이드. 아이템(Item). 비용 1, 🃏와일드 1.
   제한(Restricted, 플레이어당 최대 2장). 캡틴아메리카는 DEF +1을 얻고 보복 1을 얻는다 (지속).
   범용: statMod(defense,+1) + grantsRetaliate:1 (triggerRetaliate가 히어로 업그레이드 보복 합산). */
MC.defineCardFx('cap-shield', {
  restricted: true,
  statMod: { stat:'defense', amount:1 },
  grantsRetaliate: 1,
  vfx: { install:'vibraniumArmorInstall', retaliate:'sonicRetaliate' },
  textKo: '업그레이드 — Upgrade. 아이템(Item). 비용 1 · 🃏와일드 1.\n\n제한(Restricted) — 플레이어당 제한 카드 최대 2장.\n\n캡틴아메리카는 DEF +1을 얻고, 보복 1(Retaliate 1)을 얻는다.\n\n*"이 방패엔 아버지의 신념이 담겨 있어."*\n\n※ 공식 03009 Captain America의 방패 (Captain America 히어로 팩) — cap.json 교차검증\n※ 지속 효과: 방어력 +1 + 공격받을 때 공격자에게 1 피해(보복) · 방패 막기/던지기가 참조하는 그 방패',
});

/* 03010 Super-Soldier Serum (슈퍼 솔저 혈청) — 업그레이드. 아이템(Item). 비용 2, 💪물리 1.
   자원: 소진 → 💪물리 자원 1 생성.
   [체크1 통과] 기존 resourceGenerator 인덱스의 수치·대상만 다른 변형 — 신규 코드 0줄, 데이터만. */
MC.defineCardFx('super-soldier-serum', {
  resourceGenerator: { exhaust: true, icons: { physical: 1 } },
  vfx: { install:'combatInstall' },
  textKo: '업그레이드 — Upgrade. 아이템(Item). 비용 2 · 💪물리 1.\n\n자원: 슈퍼 솔저 혈청을 소진한다 → 💪물리 자원 1개를 생성한다.\n\n*"혈청은 몸을 강하게 만들었지만, 그를 위대하게 만든 건 그 안의 사람이었다."*\n\n※ 공식 03010 Super-Soldier Serum (Captain America 히어로 팩) — cap.json 교차검증\n※ 소진하여 물리 자원 생성 (카드 비용 지불에 사용) · 양쪽 형태에서 사용 가능',
});

/* 03011 Falcon (팔콘) — 동료. 리더십. 비용 4, 💪물리 1. Aerial·Avenger. ATK 2 / THW 2 / HP 3.
   반응: 팔콘 등장 후, 조우 덱 상위 3장을 확인 → 그중 배신(treachery) 1장당 스킴에서 위협 1 제거.
   [체크2] 신규 범용 EFFECT(peekEncounterRemoveThreat) 만들고 카드는 데이터만. */
MC.defineCardFx('falcon-ally', {
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'peekEncounterRemoveThreat', count:3, matchType:'treachery', perMatch:1 }],
  textKo: '동료 — Ally. 리더십(Leadership). 비용 4 · 💪물리 1. 특성: Aerial · Avenger.\nATK 2 / THW 2 / HP 3.\n\n반응: 팔콘이 등장한 후, 조우 덱 상위 3장을 확인한다 → 이렇게 확인한 배신(Treachery) 카드 1장당, 스킴에서 위협 1을 제거한다.\n\n*"위에서 보면 전장이 다르게 보이지. 샘 윌슨, 준비됐어."*\n\n※ 공식 03011 Falcon (Captain America 히어로 팩 / 리더십) — cap.json 교차검증\n※ 조우 덱 미리보기 — 다가올 배신 수만큼 위협 선제 제거 (덱은 확인만, 순서 유지)',
});

/* 03012 Hawkeye (호크아이/클린트 바튼) — 동료. 리더십. 비용 3, 🧠멘탈. Avenger. ATK 1 / THW 1 / HP 3.
   화살 카운터 4개와 함께 등장. 반응: 하수인 등장 후 → 화살 1개 소진 → 그 하수인에 2 피해.
   ★중복 통합: Core Set 01066(hawkeye) = 캡아 03012(hawkeye-cap) 동일 효과 → 한 정의로 두 slug 배선.
   [체크2] 신규 인덱스: entersWithCounters(등장 카운터) + onMinionEnterDamage(minionEnteredPlay 헬퍼가 처리). */
MC.defineCardFx(['hawkeye', 'hawkeye-cap'], {
  entersWithCounters: 4,
  onMinionEnterDamage: { counter: 'arrow', amount: 2 },
  vfx: { reaction: 'gunshot' },
  textKo: '동료 — Ally. 리더십(Leadership). Avenger. 유니크.\n비용 3 · 🧠멘탈. ATK 1 / THW 1 / HP 3.\n\n호크아이는 화살(Arrow) 카운터 4개와 함께 전장에 등장한다.\n\n반응: 하수인이 전장에 등장한 후 → 호크아이에서 화살 카운터 1개를 제거 → 그 하수인에게 2 피해.\n\n*"난 빗나가는 법이 없어. 그게 좀 짜증날 때도 있지만."*\n\n※ 공식 01066 Hawkeye(Core Set) = 03012 Hawkeye(Captain America 팩) 동일 카드 — 통합 정의\n※ 화살 4발 소진 · 대상은 방금 등장한 하수인 (카운터 있으면 자동 발동)',
});

/* 03013 Squirrel Girl (스쿼럴 걸) — 동료. 리더십. 비용 2, 🧠멘탈. Avenger. ATK 1 / THW 1 / HP 2.
   반응: 등장 후 각 적(빌런 + 모든 하수인)에게 1 피해.
   [체크1] 기존 dealDamage/allEnemies 인덱스(ground-stomp 동일)의 수치·대상 동일 변형 → 데이터만, 신규 코드 0줄. */
MC.defineCardFx('squirrel-girl', {
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'dealDamage', target:'allEnemies', amount:1 }],
  textKo: '동료 — Ally. 리더십(Leadership). Avenger. 유니크.\n비용 2 · 🧠멘탈. ATK 1 / THW 1 / HP 2.\n\n반응: 스쿼럴 걸이 전장에 등장한 후 → 각 적(빌런 + 모든 하수인)에게 1 피해.\n\n*"가자 다람쥐들, 해치우자!"*\n\n※ 공식 03013 Squirrel Girl (Captain America 팩 / 리더십)\n※ Tough 상태 제거에 특히 강력 · 다수 하수인 시나리오 최고의 저비용 AoE 동료',
});

/* 03014 Wonder Man (원더맨) — 동료. 리더십. 비용 2, 💪물리 1. Avenger. ATK 3 / THW 1 / HP 3.
   ★ 원더맨이 공격하기 위한 추가 비용으로, 손패에서 카드 1장을 버려야 한다. (저지/방어에는 추가 비용 없음)
   [체크2] 신규 인덱스 attackExtraCost — allyAttack이 손패 버림 선택(handDiscardCost pending)으로 처리. */
MC.defineCardFx('wonder-man', {
  attackExtraCost: { discardFromHand: 1 },
  textKo: '동료 — Ally. 리더십(Leadership). Avenger. 유니크.\n비용 2 · 💪물리 1. ATK 3 / THW 1 / HP 3.\n\n★ 원더맨이 공격하기 위한 추가 비용으로, 손패에서 카드 1장을 버려야 한다.\n(저지·방어에는 추가 비용이 없다.)\n\n*"심판의 시간이다!"*\n\n※ 공식 03014 Wonder Man (Captain America 팩 / 리더십)\n※ ATK 3 고타 동료 — 매 공격마다 손패 1장 소모 (자원 효율 트레이드오프)',
});

/* 03015 Avengers Assemble! (어벤져스 어셈블!) — 이벤트. 리더십. 비용 4, ⚡에너지. 라운드당 최대 1회.
   히어로 행동: 내가 조종하는 각 Avenger 캐릭터 준비 + 이 페이즈 끝까지 전장의 각 Avenger 캐릭터(전 플레이어) THW/ATK +1.
   [체크2] 신규 범용 인덱스 readyCharactersByTrait + buffCharactersByTrait + maxPerRound. 카드는 데이터만. */
MC.defineCardFx('avengers-assemble', {
  maxPerRound: 1,
  effects: [
    { fx:'readyCharactersByTrait', trait:'avenger' },
    { fx:'buffCharactersByTrait', trait:'avenger', stats:{ thwart:1, attack:1 } },
  ],
  textKo: '이벤트 — Event. 리더십(Leadership). 비용 4 · ⚡에너지.\n라운드당 최대 1회.\n\n히어로 행동: 당신이 조종하는 각 Avenger 캐릭터를 준비(ready)한다. 이 페이즈가 끝날 때까지, 전장의 각 Avenger 캐릭터(모든 플레이어)는 THW +1과 ATK +1을 얻는다.\n\n*"어벤져스... 어셈블!"*\n\n※ 공식 03015 Avengers Assemble! (Captain America 팩 / 리더십)\n※ 멀티플레이 극대화 — 전체 팀 Avenger 강화 + 재활성화',
});

/* 03017 Strength In Numbers (수적 우위) — 이벤트. 리더십. 비용 0, 💪물리 1.
   행동: 당신이 조종하는 원하는 수만큼의 동료를 소진 → 이렇게 소진한 동료 1명당 카드 1장 드로우.
   [체크2] 신규 인덱스 exhaustAlliesForDraw — 준비된 동료 임의 다중 선택(allyExhaustDraw pending, 토글+확정). */
MC.defineCardFx('strength-in-numbers', {
  effects: [{ fx:'exhaustAlliesForDraw' }],
  textKo: '이벤트 — Event. 리더십(Leadership). 비용 0 · 💪물리 1.\n\n행동: 당신이 조종하는 원하는 수만큼의 동료를 소진(exhaust)한다. 이렇게 소진한 동료 1명당 카드 1장을 뽑는다.\n\n*"우린 혼자가 아니야. 그게 우리의 힘이지."*\n\n※ 공식 03017 Strength In Numbers (Captain America 팩 / 리더십)\n※ 소진할 동료를 자유롭게 선택 — 0명 선택도 가능(드로우 0)',
});

/* 03019 Quinjet (퀸젯) — 서포트. 리더십. 비용 1, ⚡에너지. Avenger·Vehicle.
   반응: 당신의 턴이 시작된 후 → 시간(Time) 카운터 1개 적립 (playerPhaseStart 훅 + gainCounterOnPhase).
   행동: 손에서 Avenger 동료 1명(인쇄비용 ≤ 시간 카운터 수)을 전장에 무료 배치 → 그 후 퀸젯 버림.
   [체크2] 신규 인덱스: playerPhaseStart 카운터 적립(gainCounterOnPhase) + deployAllyFromHand(선택식). */
MC.defineCardFx('quinjet', {
  playerPhaseStart: 'gainCounterOnPhase',
  counterGainPerPhase: 1,
  activatedAbility: {
    effect: [{ fx:'deployAllyFromHand', trait:'avenger', costFromCounters:true, discardSelfAfter:true,
               prompt:'퀸젯 — 전장에 배치할 Avenger 동료 선택' }],
  },
  vfx: { install:'tacticalHolo', entrance:'tacticalHolo' },
  textKo: '지원 — Support. 어벤져(Avenger). 탈것(Vehicle). 리더십(Leadership). 비용 1 · ⚡에너지.\n\n반응: 당신의 턴이 시작된 후 → 퀸젯에 시간(Time) 카운터 1개를 놓는다.\n\n행동: 손에서 Avenger 동료 1명(인쇄된 비용이 퀸젯의 시간 카운터 수 이하)을 전장에 배치한다. 그 후 퀸젯을 버린다.\n\n*"어벤져스, 탑승하라. 목적지는 전장이다."*\n\n※ 공식 03019 Quinjet (Captain America 팩 / 리더십)\n※ "전장 배치" — 비용 무료(헬리캐리어 할인 무관). Avenger 동료만 (Nick Fury=S.H.I.E.L.D. 제외)\n※ 시간 카운터를 매 턴 1개씩 쌓아 고비용 Avenger를 무료 소환',
});

/* 03024 Avengers Tower (어벤져스 타워) — 서포트. 기본(Basic). 비용 2, 🧠멘탈. Avenger·Location.
   지속: 당신의 모든 동료가 Avenger 특성이면 → 동료 한도 +1 (조건부, allyLimitCondAllTrait).
   행동: 소진 → 이번 페이즈 다음에 플레이하는 Avenger 동료 비용 -1 (reduceNextPlayCost, 필터 할인).
   [체크2] allyLimitOf 조건부화 + reduceNextPlayCost(헬리캐리어 일반화, 특성 필터). */
MC.defineCardFx('avengers-tower', {
  allyLimitBonus: 1,
  allyLimitCondAllTrait: 'avenger',
  activatedAbility: {
    exhaust: true,
    effect: [{ fx:'reduceNextPlayCost', amount:1, allyTrait:'avenger' }],
  },
  vfx: { install:'tacticalHolo' },
  textKo: '지원 — Support. 어벤져(Avenger). 장소(Location). 비용 2 · 🧠멘탈.\n\n지속 효과: 당신이 조종하는 모든 동료가 Avenger 특성을 가지면 → 당신의 동료 한도 +1.\n\n행동: 어벤져스 타워를 소진 → 이번 페이즈에 다음에 플레이하는 Avenger 동료의 비용을 1 감소.\n\n*"지구 최강의 영웅들이 모이는 곳."*\n\n※ 공식 03024 Avengers Tower (Captain America 팩)\n※ 조건부 한도 — 비-Avenger 동료 1명이라도 있으면 +1 사라짐\n※ Stinger(한도 밖) + 타워 = 총 5명, The Triskelion까지 = 6명',
});

/* 03025 Honorary Avenger (명예 어벤져) — 업그레이드. 기본(Basic). 비용 0, 💪물리. Title.
   플레이 조건: 당신의 신분이 Avenger 특성일 때만. 캐릭터당 최대 1장. 우호 캐릭터(히어로/동료)에 부착.
   부착된 캐릭터는 HP +1 획득 + Avenger 특성 획득.
   [체크2] grantsTrait(→playerHasTrait/allyHasTrait 집계) + hpBonus(히어로 recompute / 동료 attachTo 부여) + attachCharacter 선택 picker. */
MC.defineCardFx('honorary-avenger', {
  playCondition: { type:'hasTrait', trait:'avenger' },
  maxPerTarget: 1,
  grantsTrait: 'avenger',
  hpBonus: 1,
  vfx: { install:'tacticalHolo' },
  textKo: '업그레이드 — Upgrade. 칭호(Title). 비용 0 · 💪물리.\n\n플레이 조건: 당신의 신분이 Avenger 특성을 가질 때만 플레이 가능.\n\n캐릭터당 최대 1장. 우호적인 캐릭터(히어로 또는 동료)에 부착.\n\n부착된 캐릭터는 체력(HP) +1을 얻고 Avenger 특성을 획득한다.\n\n*"넌 이제 어벤져다. 자격을 증명했으니까."*\n\n※ 공식 03025 Honorary Avenger (Captain America 팩)\n※ 히어로/동료 어느 쪽에도 부착 가능 — 부착 시 대상 선택\n※ 비-Avenger 동료를 Avenger로 만들어 어벤져스 타워/시너지에 편입',
});

/* 03026 Man Out of Time (시대에 뒤처진 사나이) — 의무(Obligation). 부스트 ▲2. 스티브 로저스에게 부여.
   공개 시: 알터에고 폼으로 전환 가능(선택). 택 1:
   ⓐ 스티브 로저스 소진 → 이 카드 게임에서 제거 (신분 준비 시에만).
   ⓑ 손패 절반(내림) 버림 → 이 의무 버림(조우 버린더미로).
   [체크2] 2단계 offerChoice 체이닝(폼전환 선택 → 택1) + flipToAlterEgo + discardChooseFromHand(선택식) + availableIf. */
const _motMain = {
  prompt: '시대에 뒤처진 사나이 — 어떻게 감당할 것인가 (택 1)',
  options: [
    { key:'exhaust', label:'스티브 로저스를 소진 → 이 의무를 게임에서 영구 제거',
      availableIf: { type:'identityReady' },
      effects: [ { fx:'exhaustTarget', target:'self' },
                 { fx:'playVfx', vfx:'manOutOfTimeResolve', quoteKey:'man-out-of-time', quoteKind:'duty' },
                 { fx:'resolveObligation', mode:'game' } ] },
    { key:'discardHalf', label:'손패의 절반(내림)을 버림 → 이 의무를 버림',
      effects: [ { fx:'playVfx', vfx:'manOutOfTimeDefer', quoteKey:'man-out-of-time', quoteKind:'defer' },
                 { fx:'discardChooseFromHand', countHalf:true, prompt:'버릴 카드를 선택하세요 (손패 절반, 내림)',
                   afterEffects:[ { fx:'resolveObligation', mode:'discard' } ] } ] },
  ],
};
MC.defineCardFx('man-out-of-time', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{
    fx: 'offerChoice',
    prompt: '시대에 뒤처진 사나이 — 알터에고 폼으로 전환하시겠습니까?',
    options: [
      { key:'flip', label:'알터에고 폼으로 전환한다', effects:[ { fx:'flipToAlterEgo' }, { fx:'offerChoice', ..._motMain } ] },
      { key:'noflip', label:'전환하지 않는다', effects:[ { fx:'offerChoice', ..._motMain } ] },
    ],
  }],
  vfx: { entrance:'revealCard' },
  textKo: '의무 — Obligation. 부스트 ▲2.\n\n스티브 로저스 플레이어에게 부여.\n\n공개 시: 당신은 알터에고 폼으로 전환할 수 있다. 그 후 택 1:\n• 스티브 로저스를 소진 → 시대에 뒤처진 사나이를 게임에서 제거한다.\n• 손패에 있는 카드의 절반(내림)을 버린다. 이 의무를 버린다.\n\n*"70년이 지났어. 내가 알던 세상은... 이제 없어."*\n\n※ 공식 03026 Man Out of Time (Captain America / 넴시스 세트)\n※ 소진→제거는 영구 해결(신분 준비 시). 절반 버림→버림은 다시 조우덱으로 순환\n※ 손패 절반은 무작위가 아니라 플레이어가 직접 선택',
});

/* 03027 Hit Squad (히트 스쿼드) — 사이드 스킴(Side Scheme). 넴시스. 시작 위협 3/인, 가속 ▲1.
   공개 시: 플레이어 순서로 각 플레이어가 조우덱 top 1장 버림 → 버린 카드의 부스트 아이콘 수만큼 그 플레이어에게 피해.
   [체크2] 신규 인덱스 eachPlayerDiscardEncounterBoostDamage (drawEncounterCard 재사용). */
MC.defineCardFx('hit-squad', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'eachPlayerDiscardEncounterBoostDamage' }],
  vfx: { entrance:'revealCard' },
  textKo: '사이드 스킴 — Side Scheme. 넴시스(Nemesis). 시작 위협 3(플레이어당) · 가속 ▲1.\n\n공개 시: 플레이어 순서대로, 각 플레이어는 조우덱의 맨 위 카드 1장을 버리고, 이렇게 버려진 카드의 부스트 아이콘 1개당 1의 피해를 받는다.\n\n*"하이드라가 보낸 암살조. 캡틴 아메리카, 넌 표적이 됐어."*\n\n※ 공식 03027 Hit Squad (Captain America / 넴시스 세트)\n※ 부스트 아이콘 수는 무작위 — 조우덱 상단에 따라 0~여러 피해\n※ 사이드 스킴 — 위협 누적 시 저지 필요',
});

/* 03028 Baron Zemo (바론 제모) — 하수인(Minion). 넴시스. Hydra·Elite. ATK 3 / SCH 1 / HP 5.
   Quickstrike(등장 즉시 공격). 교전 중인 동안 그 플레이어는 저지(thwart) 불가.
   [체크2] quickstrike(기존 키워드) + whileEngagedCannotThwart(신규 패시브, hasCannotThwartEngaged). */
MC.defineCardFx('baron-zemo', {
  quickstrike: true,
  whileEngagedCannotThwart: true,
  vfx: { entrance:'revealCard', attack:'gunshot' },
  textKo: '하수인 — Minion. 하이드라(Hydra). 정예(Elite). 넴시스(Nemesis). ATK 3 / SCH 1 / HP 5. 부스트 ▲2.\n\n속공(Quickstrike): 이 하수인이 교전 상태로 등장하면 즉시 공격한다.\n\n바론 제모가 당신과 교전 중인 동안, 당신은 저지(thwart)할 수 없다.\n\n*"헬무트 제모 — 하이드라의 귀족이자, 캡틴 아메리카의 숙적."*\n\n※ 공식 03028 Baron Zemo (Captain America 넴시스 세트)\n※ 저지 봉쇄 — 교전 중엔 스킴 위협을 제거할 수 없어 압박이 큼 (빨리 처치 필요)\n※ Elite — 일부 효과의 대상/영향에서 특별 취급',
});

/* 03030 Hail Hydra! (헤일 하이드라!) — 배신(Treachery). 넴시스.
   공개 시: 히어로와 교전 중인 각 Hydra 하수인이 그 히어로를 공격한다.
   이렇게 공격받지 않은 각 플레이어는 조우덱과 버린더미에서 Hydra 하수인을 찾아 자신과 교전 상태로 전장에 배치한다(탐색 시 조우덱 셔플).
   [체크2] minionsAttack에 reinforceUnattacked 옵션 확장(공격 안 받은 각 플레이어 증원). */
MC.defineCardFx('hail-hydra', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'minionsAttack', trait:'hydra', reinforceUnattacked:true }],
  vfx: { entrance:'revealCard' },
  textKo: '배신 — Treachery. 넴시스(Nemesis).\n\n공개 시: 히어로와 교전 중인 각 하이드라(Hydra) 하수인이 그 히어로를 공격한다. 이렇게 공격받지 않은 각 플레이어는 조우덱과 버린더미에서 하이드라 하수인 1명을 찾아 자신과 교전 상태로 전장에 배치한다(탐색했다면 조우덱을 섞는다).\n\n*"하이드라 만세! 한 머리를 자르면 둘이 그 자리를 대신하리라."*\n\n※ 공식 03030 Hail Hydra! (Captain America 넴시스 세트)\n※ Hydra 하수인 교전 중이면 공격, 없으면 증원 소환 — 어느 쪽이든 압박\n※ 조우덱/버림에 Hydra 하수인 없으면 증원 불발',
});

/* 03033 Expert Defense (전문가의 방어) — 이벤트. 방어(Defense). Protection. 비용 0 · 🧠멘탈 1.
   히어로 인터럽트(방어): 당신의 히어로가 방어할 때 그 공격에 대해 DEF +3.
   ★ 인덱스 재사용: DEF +3 = preventAmount 3 (Cosmic Flight 3방지와 동일 등가 — 라이더 없어 정확 일치).
     방어 이벤트(defense trait)라 방어 pending 중 플레이 가능(엔진 isDefenseInterrupt 게이트). */
MC.defineCardFx('expert-defense', {
  effects: [{ fx:'preventAmount', amount: 3 }],
  vfx: { defense:'expertDefense' },
  textKo: '이벤트 — Event. 방어(Defense). 프로텍션(Protection). 비용 0 · 🧠멘탈 1.\n\n히어로 인터럽트(방어): 당신의 히어로가 공격에 대해 방어할 때, 그 공격에 대해 DEF +3을 얻는다.\n\n*"이 녀석들은 총알이 다 떨어지지도 않나!" —캡틴아메리카*\n\n※ 공식 03033 Expert Defense (Captain America 히어로 팩) — cap.json 교차검증\n※ DEF +3 = 그 공격의 피해 3 방지와 등가(라이더 없음). 방패 준비 불필요 — 모든 히어로 사용 가능(Protection)',
});

/* 03034 Enhanced Awareness (강화된 감각) — 업그레이드. 상태(Condition). Basic. 비용 2 · 🧠멘탈 1.
   사용(멘탈 카운터 3). 히어로 자원: 소진 + 카운터 1 제거 → 🧠멘탈 자원 1 생성.
   ★ 인덱스 재사용: web-shooter(uses+resourceGenerator{counter}) 패턴 그대로, 아이콘만 mental. */
MC.defineCardFx('enhanced-awareness', {
  uses: 3,
  resourceGenerator: { form: 'hero', exhaust: true, counter: 1, icons: { mental: 1 } },
  vfx: { install: 'detectiveInstall' },
  textKo: '업그레이드 — Upgrade. 상태(Condition). 비용 2 · 🧠멘탈 1.\n\n사용(멘탈 카운터 3개).\n\n히어로 자원: 강화된 감각을 소진하고 멘탈 카운터 1개를 제거한다 → 🧠멘탈 자원 1개를 생성한다.\n\n※ 공식 03034 Enhanced Awareness (Captain America 히어로 팩) — cap.json 교차검증\n※ 히어로 폼 전용 · 카운터 3개 소진 시 카드 버림 · 자원 중립(3투자→3회수) · 인쇄 🧠멘탈 요구 카드 지불에 유용',
});

})(typeof window !== 'undefined' ? window : globalThis);
