/* ◇ 헐크 네메시스 (아보미네이션 세트) fx ◇
   10025 inner-demons(의무) / 10026 abomination / 10027 total-destruction / 10028 clash-of-titans */
(function(global){
  'use strict';
  const MC = global.MC;
  if (!MC || !MC.defineCardFx) return;

  /* 10025 Inner Demons (내면의 악마) — 책무(Obligation). 브루스 배너 플레이어에게.
     공개 시: 형태 변경 → 브루스 배너면 손패 2장 버림 / 헐크면 히어로 소진. 그 후 이 책무 버림.
     범용: changeForm + discardChooseFromHand(cond isAlterEgoForm) + exhaustPlayer(cond isHeroForm) + resolveObligation. */
  MC.defineCardFx('inner-demons', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [
      { fx:'changeForm' },
      { fx:'discardFromHand', amount:2, cond:{ type:'isAlterEgoForm' } },
      { fx:'exhaustPlayer', cond:{ type:'isHeroForm' } },
      { fx:'resolveObligation' },
    ],
  });

  /* 10026 Abomination (아보미네이션) — 하수인. 엘리트·감마. ATK 3 / SCH 2 / HP 6.
     ★ 강제 반응: 아보미네이션이 당신을 공격한 후 → 덱 위 카드 1장 버림. 물리(또는 와일드) 자원이면 2 피해.
     범용: forcedInterrupt{effect} + discardTopResourceBranch(branches physical만 — 와일드는 물리 포함 처리). */
  MC.defineCardFx('abomination', {
    forcedInterrupt: { effect: [
      { fx:'discardTopResourceBranch', branches: {
        physical: [{ fx:'dealDamage', target:'self', amount:2 }],
      } },
    ] },
    vfx: { attack:'gammaSmash', entrance:'gammaSmash' },
  });

  /* 10027 Total Destruction (완전한 파괴) — 사이드 스킴. 시작 위협 2.
     아보미네이션이 전장에 있는 동안 이 스킴에서 위협을 제거할 수 없다.
     범용: threatCannotRemove{whileMinionInPlay:'abomination'} (조건부 확장). */
  MC.defineCardFx('total-destruction', {
    threatCannotRemove: { whileMinionInPlay:'abomination' },
  });

  /* 10028 Clash of the Titans (거인들의 충돌) — 배신(Treachery). ×3.
     공개 시: 최고 ATK 적이 최고 ATK 히어로/동료를 공격 (동점은 첫 플레이어 결정). 공격 없으면 surge.
     범용: clashOfTitans EFFECT(최고 ATK 선정 + enemyActivation/직접피해 + surge). */
  MC.defineCardFx('clash-of-titans', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'clashOfTitans' }],
  });

})(typeof window !== 'undefined' ? window : globalThis);
