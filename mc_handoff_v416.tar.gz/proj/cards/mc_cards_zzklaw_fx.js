/* ═══════════════════════════════════════════════════════════════
   클로 세트 — 빌런 클로 3단계 (Klaw I/II/III)  Core Set #113~115
   Ulysses Klaw — 음파 물리학자에서 "살아있는 소리"의 존재가 된 무기 밀매업자.
   블랙 팬서/와칸다의 숙적, 마스터즈 오브 이블 멤버.

   I  (01113): HP 12/영웅 · ATK 0 · SCH 2. 강제 난입: 공격 시 부스트 카드 1장 추가.
   II (01114): HP 18/영웅 · ATK 1 · SCH 2. 강제 난입 부스트+1.
     When Revealed: 조우덱·버림에서 "불멸의 클로" 사이드 스킴을 찾아 공개, 조우덱 셔플.
   III(01115): HP 22/영웅 · ATK 2 · SCH 3. Toughness(등장 시 tough) + 강제 난입 부스트+1.

   ★ 교차검증(core_encounter.json): HP 12/18/22 hpPerHero, ATK 0/1/2, SCH 2/2/3 확정.
     강제 난입(공격 시 부스트+1)은 공통 — villainAttackExtraBoost:1 (seed).
   ★ 엔진: 빌런 공격 부스트 +1은 enemyActivation의 villainAttackExtraBoost 처리로 배선.
     Stage II 공개 시 불멸의 클로 사이드 스킴 공개(revealSpecificSideScheme 재사용).
     불멸의 클로 지속 효과: 클로 HP +10 (해결 시 -10).
   연출: 등장=sonicEmerge(음파 응축), 공격=sonicBlast(음파 대포),
     페이즈변화=sonicSurge(음파 폭발 진화), 패배=sonicShatter(음파 붕괴·침묵).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* Stage II 공개 — 불멸의 클로 사이드 스킴을 조우덱/버림에서 찾아 공개 + 셔플. */
MC.HANDLERS.klawStage2Reveal = function(G, ctx){
  MC.revealSpecificSideScheme(G, 'immortal-klaw');
  MC.log(G, '클로 2단계 — "불멸의 클로" 사이드 스킴 공개');
};

/* Stage III 공개 — Toughness(등장 시 tough 상태 부여). */
MC.HANDLERS.klawStage3Reveal = function(G, ctx){
  const v = ctx.villain || G.villain;
  MC.setStatus(G, v, 'tough', true);
  MC.log(G, '클로 3단계 — 강인함(Tough) 획득');
};

/* 불멸의 클로 사이드 스킴 공개 시 — 클로 HP +10 (지속). */
/* 불멸의 클로(01127) — 인덱스 타입으로 데이터화 (아래 defineCardFx 참조). */

/* ── 클로 메인 스킴 (01116 지하 유통망 / 01117 비밀 회합) ── */

/* 01116a 셋업 — "방어망(01125)" 사이드 스킴을 조우덱에서 찾아 공개 + 조우덱 셔플.
   (공용 revealSpecificSideScheme 재사용 — 클로 II 불멸의 클로와 동일 경로) */
MC.HANDLERS.undergroundDistributionSetup = function(G, ctx){
  MC.revealSpecificSideScheme(G, 'defense-network');
  MC.log(G, '지하 유통망 셋업 — "방어망" 공개');
};

/* 01116b/01117 공개 시 — 조우덱에서 하수인이 나올 때까지 버림 →
   첫 플레이어와 교전 상태로 전장 배치 (공용 discardUntilMinionIntoPlay 재사용). */
MC.HANDLERS.klawMainMinion = function(G, ctx){
  const pl = (ctx && ctx.player) || G.players[G.firstPlayer];
  MC.discardUntilMinionIntoPlay(G, pl);
};

/* whenRevealed / whenDefeated 훅을 카드 정의에 연결 (seed에 이미 명시했지만 안전하게 재확인). */
/* 방어망(01125) — db 마이그레이션 정의에 능력 연결 (01116a 셋업 의존성으로 순서 예외 완성).
   ★ 공식 정정: 구 텍스트 "Hinder 1(+1)"은 오류 — 공식 JSON은 "공개 시 플레이어당 위협 1 추가". */
MC.defineCardFx('defense-network', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'placeThreat', scheme:'self', perHero:1 }],
  textKo: '사이드 스킴. 시작 위협 2.\n\n공개 시: 여기에 플레이어당 위협 1을 추가로 놓는다.\n\n*클로의 범죄 조직을 고용된 깡패들이 보호하고 있다.*\n\n※ 공식 01125 Defense Network (Core Set #125) — 공개 시 [per_hero] 위협 (공식 JSON 교차검증)\n※ 클로 시나리오 셋업 시 조우덱에서 탐색·공개됨 (지하 유통망 1A Setup)',
});

MC.defineCardFx('01113', {});
MC.defineCardFx('01114', { whenRevealed: 'klawStage2Reveal' });
MC.defineCardFx('01115', { whenRevealed: 'klawStage3Reveal' });
/* 소닉 컨버터(01118) — 클로 부착 무기. 인덱스 타입으로 데이터화 (아래 defineCardFx 참조). */
/* 솔리드 사운드 바디(01119) — 클로 부착. 인덱스 타입으로 데이터화 (아래 defineCardFx 참조). */

/* 불멸의 클로(01127) — 사이드 스킴. slug 'immortal-klaw'(공식) 정본. 완전 인덱스 타입.
   공개 시: 클로 HP +10 / 스킴 해결(위협 제거) 시: -10 (whenCompleted — 사이드 스킴 처치 훅).
   ※ 기존 the-immortal-klaw(fx stub) + whenDefeated는 사이드 스킴에서 미발화(HP -10 버그)였음 → 정리. */
MC.defineCardFx('immortal-klaw', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'buffVillainHp', amount: 10 },
            { fx: 'playVfx', vfx: 'immortalKlawForm', quoteKey: 'klaw-immortal', quoteKind: 'reveal', target: 'villain' }],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'buffVillainHp', amount: -10 },
                         { fx: 'playVfx', vfx: 'immortalKlawShatter', quoteKey: 'klaw-immortal', quoteKind: 'shatter', target: 'villain' }],
  vfx: { attack: 'immortalKlawForm' }, quoteKey: 'klaw-immortal',
});
/* 소닉 컨버터(01118) — 클로 부착 무기. 완전 인덱스 타입(커스텀 핸들러 없음).
   ① 부착 시: 장착 연출/대사(공식엔 스탯 보너스 없음 — db의 ATK+1은 오류라 textKo 정정)
   ② 강제 반응: 클로가 공격해 피해를 준 대상 기절 (runAttachDamagedEffects + applyStatus target:'target')
   ③ 히어로 행동: 에너지·멘탈·피지컬 각 1 지불 → 이 카드 버림 (removeAbility, UI 제거 능력) */
MC.defineCardFx('sonic-converter', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'playVfx', vfx: 'sonicWeaponForge', quoteKey: 'klaw-sonic-converter', quoteKind: 'attach', target: 'villain' }],
  attackDamagedResponse: 'runAttachDamagedEffects',
  attackDamagedEffects: [
    { fx: 'applyStatus', target: 'target', status: 'stunned' },
    { fx: 'playVfx', vfx: 'sonicStunPulse', quoteKey: 'sonic-converter', quoteKind: 'stun', target: 'target' },
  ],
  removeAbility: { payIcons: { energy: 1, mental: 1, physical: 1 } },
  vfx: { install: 'sonicWeaponForge', attack: 'sonicStunPulse' }, quoteKey: 'sonic-converter',
  textKo: '무기. 클로 부착.\n강제 반응: 클로가 공격해 캐릭터에 피해를 주면 → 그 캐릭터 기절(Stun).\n히어로 행동: ⚡🧠💪 자원 각 1개 지불 → 이 카드 버림.',
});
if (MC.CARDS['sonic-converter']) delete MC.CARDS['sonic-converter'].attack;   // 공식 ATK 보너스 없음 (db 오류 정정)

/* 솔리드 사운드 바디(01119) — 클로 부착. 완전 인덱스 타입(커스텀 핸들러 없음). slug 'solid-sound-body' 정본.
   ① 부착: whenRevealed 결정화 연출  ② 클로 반격(retaliate) 1 (attachStats — statOf가 자동 적용)
   ③ 히어로 행동: ⚡🧠💪 각 1 지불 → 제거 (removeAbility). db textKo의 '정신3개'는 공식과 달라 정정. */
MC.defineCardFx('solid-sound-body', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'playVfx', vfx: 'sonicBodyHarden', quoteKey: 'klaw-solid-sound', quoteKind: 'attach', target: 'villain' }],
  attachStats: { retaliate: 1 },
  removeAbility: { payIcons: { energy: 1, mental: 1, physical: 1 } },
  vfx: { install: 'sonicBodyHarden' }, quoteKey: 'klaw-solid-sound',
  textKo: '상태. 클로 부착.\n클로가 반격(Retaliate) 1을 획득한다. (공격받으면 공격자에게 1 피해.)\n히어로 행동: ⚡🧠💪 자원 각 1개 지불 → 이 카드 버림.',
});
/* 클로의 복수(01122) — 폼 분기 배신. 커스텀 핸들러 없이 범용 EFFECTS 인덱스로 데이터화.
   히어로: 빌런 공격(피해 시 메인 위협 +1) / 알터에고: 손패 무작위 1장 버림 + 전용 연출. */
MC.defineCardFx('klaw-vengeance', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'formBranch',
    hero:  [{ fx: 'villainAttacks', threatOnDamage: 1 }],
    alter: [{ fx: 'discardFromHand', who: 'self', amount: 1 },
            { fx: 'playVfx', vfx: 'sonicVengeanceScatter', quoteKey: 'klaw-vengeance', quoteKind: 'vengeance', target: 'self' }] }],
  vfx: { alter: 'sonicVengeanceScatter' }, quoteKey: 'klaw-vengeance',
});
/* 소닉 붐(01123) — 선택 배신. 커스텀 핸들러 없이 범용 인덱스로 데이터화.
   공개 시: ⚡🧠💪 자원 각 1개 지불(회피) OR 통제하는 모든 캐릭터(히어로+동료) 소진. */
MC.defineCardFx('sonic-boom', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'offerChoice',
    prompt: '소닉 붐 — 음파 폭발! ⚡🧠💪 자원을 지불하거나, 모든 캐릭터가 소진된다',
    options: [
      { key: 'pay', label: '⚡🧠💪 자원 각 1개 지불', payIcons: { energy: 1, mental: 1, physical: 1 },
        effects: [{ fx: 'playVfx', vfx: 'sonicBoomBlast', quoteKey: 'klaw-sonic-boom', quoteKind: 'boom', target: 'villain' }] },
      { key: 'exhaust', label: '통제하는 모든 캐릭터 소진',
        effects: [{ fx: 'exhaustControlled' },
                  { fx: 'playVfx', vfx: 'sonicBoomBlast', quoteKey: 'klaw-sonic-boom', quoteKind: 'boom', target: 'villain' }] },
    ] }],
  // ★부스트: 이 활성화(빌런 공격)가 피해를 주면 → 히어로 소진 (부스트로 뒤집혔을 때만, 피해 조건부)
  boostStarOnDamage: [{ fx: 'exhaustTarget', target: 'self' }],
  vfx: { attack: 'sonicBoomBlast' }, quoteKey: 'klaw-sonic-boom',
});
/* 음파 조작(01124) — 폼 분기 배신. 커스텀 핸들러 없이 범용 인덱스로 데이터화.
   알터에고: 클로 4 회복 (회복량 0이면 이 카드 급증). 히어로: 히어로 2 피해 + 클로 2 회복. */
MC.defineCardFx('sound-manipulation', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'formBranch',
    alter: [{ fx: 'healVillain', amount: 4 },
            { fx: 'surge', cond: { type: 'healedNone' } },     // 회복이 하나도 없었으면 급증
            { fx: 'playVfx', vfx: 'sonicHeal', quoteKey: 'klaw-sound-manip', quoteKind: 'manip', target: 'villain' }],
    hero:  [{ fx: 'dealDamage', target: 'self', amount: 2 },
            { fx: 'healVillain', amount: 2 },
            { fx: 'playVfx', vfx: 'sonicHeal', quoteKey: 'klaw-sound-manip', quoteKind: 'manip', target: 'villain' }] }],
  vfx: { attack: 'sonicHeal' }, quoteKey: 'klaw-sound-manip',
});
/* 불법 무기 공장(01126) — 사이드 스킴. 공식: 시작 위협 3 + 공개 시 인원수당 위협 +1.
   완료 효과는 없으나(위협 제거로 처치) 테마 몰입을 위해 공개(가동)/완성(폐쇄) 연출·대사를 완결.
   모두 범용 인덱스: placeThreat(scheme:'self', perHero) + playVfx + whenCompleted 훅. */
MC.defineCardFx('illegal-arms-factory', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'placeThreat', scheme: 'self', perHero: 1 },   // 인원수당 위협 +1 (시작 위협 3에 추가)
            { fx: 'playVfx', vfx: 'armsFactoryActivate', quoteKey: 'klaw-arms-factory', quoteKind: 'reveal' }],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'armsFactoryShutdown', quoteKey: 'klaw-arms-factory', quoteKind: 'complete' }],
  vfx: { attack: 'armsFactoryActivate' }, quoteKey: 'klaw-arms-factory',
});
/* 악의 지배자들(01128) — Masters of Evil 모듈러 세트 사이드 스킴 (클로 권장 모듈러).
   공식: 시작 위협 인원수당 3(base_threat 3 per player), 가속 아이콘 1(scheme_acceleration — 진짜 가속,
   v162 엔진이 사이드 스킴 가속을 실제 반영), 부스트 2(★ 없음).
   공개 시: 조우덱에서 Masters of Evil 하수인이 나올 때까지 버림 → 첫 플레이어와 교전 배치.
   완전 인덱스 타입: discardUntilMinion(trait) + placeThreat는 공개 파이프라인 자동(baseThreatPerPlayer). */
MC.defineCardFx('masters-of-evil-scheme', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'discardUntilMinion', trait: 'masters of evil' },
            { fx: 'playVfx', vfx: 'mastersAssemble', quoteKey: 'masters-of-evil', quoteKind: 'reveal' }],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'mastersScatter', quoteKey: 'masters-of-evil', quoteKind: 'complete' }],
  vfx: { attack: 'mastersAssemble' }, quoteKey: 'masters-of-evil',
  textKo: '사이드 스킴. 시작 위협: 인원수당 3. ⚡가속(Acceleration) 1.\n\n공개 시: Masters of Evil 하수인이 버려질 때까지 조우덱에서 카드를 버린다. 그 하수인을 첫 플레이어와 교전 상태로 전장에 놓는다.\n\n*악의 지배자들이 히어로들을 공격하러 도착했다!*\n\n※ 공식 01128 The Masters of Evil (Core Set #128, Masters of Evil 모듈러 #1) — base_threat 3/인, scheme_acceleration 1 (공식 JSON 교차검증)\n※ 하수인 후보: 라디오액티브 맨(01129)·훨윈드(01130)·타이거 샤크(01131)·멜터(01132)',
});
/* 혼돈의 지배(01133) — Masters of Evil 모듈러 배신 ×2, 부스트 2(★ 없음).
   공식: 공개 시 각 Masters of Evil 하수인이 교전 중인 히어로를 공격. 이 방식의 공격이
   없었다면 → 조우덱+버림에서 MoE 하수인 탐색, 당신과 교전 배치 후 조우덱 셔플.
   완전 인덱스 타입: 신규 범용 minionsAttack(trait, fallback:'searchEngage').
   조건부 효과 = 조건부 연출 분리: ①일제 공격(mastersOnslaught/mayhem) ②증원(mastersAssemble/reinforce). */
MC.defineCardFx('masters-of-mayhem', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'minionsAttack', trait: 'masters of evil', fallback: 'searchEngage' },
    { fx: 'playVfx', vfx: 'mastersOnslaught', quoteKey: 'masters-of-evil', quoteKind: 'mayhem',
      cond: { type: 'minionsAttacked' } },
    { fx: 'playVfx', vfx: 'mastersAssemble', quoteKey: 'masters-of-evil', quoteKind: 'reinforce',
      cond: { type: 'minionsAttacked', negate: true } },
  ],
  vfx: { attack: 'mastersOnslaught' }, quoteKey: 'masters-of-evil',
  textKo: '배신. 부스트 ▲2.\n\n공개 시: 각 Masters of Evil 하수인이 자신과 교전 중인 히어로를 공격한다. 이 방식으로 이루어진 공격이 없다면, 조우덱과 버림 더미에서 Masters of Evil 하수인 1명을 탐색해 당신과 교전 상태로 전장에 놓은 뒤 조우덱을 셔플한다.\n\n※ 공식 01133 Masters of Mayhem (Core Set #133, Masters of Evil 모듈러 #6-7, ×2) — 공식 JSON 교차검증\n※ 기절 하수인은 기절 소모 후 공격 생략 — 공격이 하나도 없으면 증원 분기 발동',
});
})(typeof window !== 'undefined' ? window : globalThis);
