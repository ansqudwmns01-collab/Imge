/* ◇ 닥터 스트레인지 네메시스 (바론 모르도 세트) fx ◇
   09028 baron-mordo / 09029 open-dark-dimension / 09030 counterspell / 09031 thoughtcasting */
(function(global){
  'use strict';
  const MC = global.MC;
  if (!MC || !MC.defineCardFx) return;

  /* 09028 Baron Mordo (바론 모르도) — 하수인. 마법사(Mystic). 엘리트. ATK 2 / SCH 2 / HP 5. 부스트 ▲2.
     강제 인터럽트: 바론 모르도가 당신을 공격할 때 → 당신 덱 위 카드 1장 버림 → 인쇄 자원별:
       💪 물리→기절 / ⚡ 에너지→2 피해 / 🧠 멘탈→혼란 / 🌟 와일드→위 3가지 모두.
     범용: forcedInterrupt{effect} 데이터 방식 + discardTopResourceBranch(Magic Blast 09004와 동일 매핑) 재사용. */
  MC.defineCardFx('baron-mordo', {
    forcedInterrupt: { effect: [
      { fx:'discardTopResourceBranch', branches: {
        physical: [{ fx:'applyStatus', target:'self', status:'stunned' }],
        energy:   [{ fx:'dealDamage', target:'self', amount:2 }],
        mental:   [{ fx:'applyStatus', target:'self', status:'confused' }],
      } },
    ] },
    vfx: { attack:'darkMagicBolt', entrance:'darkMagicBolt' },
  });

  /* 09029 Open the Dark Dimension (다크 디멘션이 열리다) — 사이드 스킴. 시작 위협 3(인원당). ⚡가속 1.
     공개 시: 발동 덱 맨 위 카드 1장을 뒷면으로 이 스킴 아래 격리(발동덱에서 제외).
     격파 시: 격리한 발동 카드를 발동 덱에 셔플 복귀.
     범용: stashInvocation/restoreInvocation EFFECT — DS 발동덱(invocationDeck) 조작. */
  MC.defineCardFx('open-dark-dimension', {
    whenRevealed: 'runCardEffects',
    whenRevealedEffects: [{ fx:'stashInvocation' }],
    whenCompleted: 'runCardEffects',
    whenCompletedEffects: [{ fx:'restoreInvocation' }],
  });

  /* 09030 Counterspell (카운터 스펠) — 부착물(Attachment). 상태(Condition)·주문(Spell). 부스트 ▲1. ×2.
     공개 시: 이 카드를 히어로(신분)에 부착.
     강제 인터럽트: 히어로가 이벤트를 플레이할 때 → 그 효과 취소+버림. 그 후 이 카드도 버림(1회용).
     범용: attachTarget:'identity'(자동 부착) + resolveEventPlay의 counterspell 취소 인터럽트. */
  MC.defineCardFx('counterspell', {
    attachTarget: 'identity',
  });

  /* 09031 Thoughtcasting (생각 조종) — 배신(Treachery). 부스트 ▲2.
     공개 시(알터에고): 손패 최고 인쇄비용 카드 버림 → 그 비용만큼 메인 스킴 위협.
     공개 시(히어로): 손패 최고 인쇄비용 카드 버림 → 그 비용만큼 피해.
     범용: goblinPlayerFormReveal(폼 분기) + discardHighestCostHand(then:threat/damage) 재사용. */
  MC.defineCardFx('thoughtcasting', {
    whenRevealed: 'goblinPlayerFormReveal',
    whenRevealedByPlayerForm: {
      'alter-ego': [{ fx:'discardHighestCostHand', then:'threat' }],
      'hero':      [{ fx:'discardHighestCostHand', then:'damage' }],
    },
  });

})(typeof window !== 'undefined' ? window : globalThis);
