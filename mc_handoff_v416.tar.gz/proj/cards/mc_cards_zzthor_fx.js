/* ═══════════════════════════════════════════════════════════════
   토르 시그니처 카드 FX — 히어로 팩 (mc06)
   06002 Lady Sif 부터 mcode 순으로 등록. 신분(06001a/b)은 zidentity_fx.js.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 06002 Lady Sif (레이디 시프) — 동료. 아스가르드(Asgard). 비용 4, ATK 2, THW 2, HP 3. 🌟와일드 1. 유니크.
   반응: 등장 후 토르 또는 오딘슨(신분)을 준비(ready).
   범용 whenPlayed:runCardEffects + readySelf(컨트롤러 신분 exhausted=false). 폼 무관. */
MC.defineCardFx('lady-sif', {
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'readySelf' },
  ],
  quoteKey: 'lady-sif',
  vfx: { entrance:'allyEnter', install:'allyEnter', basicThwart:'patrol', basicAttack:'swordSlash' },
  textKo: '동료 — Ally. 아스가르드(Asgard). 비용 4 · ATK 2 · THW 2 · HP 3 · 🌟와일드 1 · 유니크.\n\n반응(Response): 레이디 시프가 전장에 들어온 후, 토르 또는 오딘슨을 준비(ready) 상태로 만든다.\n\n*"토르를 노리는 자, 먼저 이 시프를 쓰러뜨려야 하리!"*\n\n※ 공식 06002 Lady Sif (Thor 히어로 팩) — 공식 thor.json 교차검증 (자원 🌟와일드)\n※ 준비 대상은 폼 무관 — 히어로(토르)든 알터에고(오딘슨)든 정체성을 재사용',
});

/* 06003 Defender of the Nine Realms (아홉 왕국의 수호자) — 이벤트. 저지(Thwart). 비용 0, 💪물리 1. ×3.
   히어로 행동(저지): 조우덱 맨 위부터 하수인이 나올 때까지 버림 → 그 하수인을 나와 교전 배치 →
   스킴에서 위협 3 제거. (→ 하수인 배치 성공 시에만 위협 제거)
   범용 재사용(신규 코드 0줄): playForm hero + discardUntilMinion(who:you — 나와 교전, Have at thee! 콤보 유발)
   + removeThreat(amount:3, cond:minionPlaced, targetScheme UI 선택). */
MC.defineCardFx('defender-nine-realms', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'discardUntilMinion', who:'you' },
    { fx:'removeThreat', amount:3, cond:{ type:'minionPlaced' } },
  ],
  vfx: { event:'threatDrain' },
  textKo: '이벤트 — Event. 저지(Thwart). 비용 0 · 💪물리 1.\\n\\n히어로 행동(저지): 조우 덱 맨 위에서 하수인이 나올 때까지 카드를 버린다. 그 하수인을 당신과 교전한 상태로 전장에 놓는다 → 스킴 하나에서 위협을 3 제거한다.\\n\\n*\"아홉 왕국의 어느 적이든, 이 자리에서 막아서리라!\"*\\n\\n※ 공식 06003 Defender of the Nine Realms (Thor 히어로 팩) — thor.json 교차검증 (자원 💪물리)\\n※ 하수인을 끌어내 교전 → 토르의 \"Have at thee!\"로 카드 2장 드로우 콤보 · 위협 제거는 하수인 배치 성공 시',
});

/* 06004 For Asgard! (아스가르드를 위해!) — 이벤트. 비용 1, 💪물리 1. ×1.
   알터에고 행동: 덱·버림에서 [[Asgard]] 특성 카드 1장을 찾아 손에 추가, 덱 셔플.
   범용 재사용(신규 코드 0줄): playForm alter-ego + searchDeckToHand(trait:asgard, includeDiscard). */
MC.defineCardFx('for-asgard', {
  playForm: 'alter-ego',
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'searchDeckToHand', filters:[{ trait:'asgard' }], includeDiscard:true, logName:'아스가르드를 위해!' },
  ],
  vfx: { event:'worthy' },
  textKo: '이벤트 — Event. 비용 1 · 💪물리 1.\\n\\n알터에고 행동(Alter-Ego Action): 당신의 덱과 버린 카드 더미에서 [[아스가르드]](Asgard) 특성을 가진 카드 1장을 찾아 손에 추가한다. 그 후 덱을 섞는다.\\n\\n*\"아스가르드의 이름으로! 필요한 힘을 불러온다.\"*\\n\\n※ 공식 06004 For Asgard! (Thor 히어로 팩) — thor.json 교차검증 (자원 💪물리)\\n※ 묠니르·아스가르드·천둥의 신·레이디 시프 등 Asgard 카드 서치 — 콤보 셋업용',
});

/* 06005 Hammer Throw (해머 스로우) — 이벤트. 공격(Attack)·초능력(Superpower). 비용 3, ⚡에너지 1. ×?.
   히어로 행동(공격): 준비된 묠니르(06009)가 있어야 함 → 적 하나에게 8 피해(오버킬) + 묠니르를 손으로 반환.
   범용 재사용(신규 코드 0줄): playForm hero + playCondition(hasReadyCard mjolnir) +
   dealDamage(8, isAttack, overkill) + returnToHand(card:mjolnir — p.card 지정 반환).
   ※ "Exhaust Mjolnir → return to hand"는 손 반환으로 귀결 → 준비 조건 + 반환으로 표현. */
MC.defineCardFx('hammer-throw', {
  playForm: 'hero',
  playCondition: { type:'hasReadyCard', card:'mjolnir' },
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'dealDamage', target:'chosen', amount:8, isAttack:true, overkill:true },
    { fx:'returnToHand', card:'mjolnir' },
  ],
  vfx: { event:'thorStrike' },
  textKo: '이벤트 — Event. 공격(Attack) · 초능력(Superpower). 비용 3 · ⚡에너지 1.\\n\\n히어로 행동(공격): 묠니르를 소진한다 → 적 하나에게 8의 피해를 입히고 묠니르를 손으로 되돌린다. 이 공격은 과잉살상(Overkill)을 얻는다.\\n\\n*\"묠니르여, 돌아오라!\"*\\n\\n※ 공식 06005 Hammer Throw (Thor 히어로 팩) — thor.json 교차검증 (자원 ⚡에너지)\\n※ 준비된 묠니르 필요 · 8 피해 오버킬(초과분 빌런에게) · 묠니르는 손으로 회수되어 재투척 가능',
});

/* 06006 Lightning Strike (라이트닝 스트라이크) — 이벤트. 초능력(Superpower). 비용 1, 🧠멘탈 1.
   히어로 행동: X개의 ⚡에너지 자원을 지불 → 빌런과 나와 교전한 각 하수인에게 X 피해.
   [[Aerial]] 특성을 가졌다면 이 피해는 강인(Tough) 상태 카드를 무시한다.
   X 가변 지불(uiFlow:spendXEnergy) + AoE(villainAndMyMinions) + 조건부 관통(piercingIf:hasTrait aerial).
   ※ 범용 확장: dealDamage amountFrom:'xValue' + piercingIf, resolveTarget villainAndMyMinions 신규 추가. */
MC.HANDLERS.lightningStrikePlay = function(G, ctx){
  const pl = ctx.player;
  if (!pl) return;
  // ① 손에서 ⚡에너지 자원 카드 X장 지불(버림) — UI가 discardUids로 에너지 카드만 넘김
  let x = 0;
  for (const uid of (ctx.discardUids || [])){
    const c = MC.fromHand(pl, uid);
    if (c){ MC.moveToDiscard(G, pl, c, {}); x++; }
  }
  ctx.xValue = x;
  MC.log(G, '라이트닝 스트라이크 — ⚡에너지 ' + x + ' 지불 (X=' + x + ')');
  if (x <= 0){ MC.log(G, '(X=0 — 피해 없음)'); return; }
  // ② 빌런 + 나와 교전한 하수인 각각에 X 피해 (Aerial이면 강인 무시)
  MC.EFFECTS.dealDamage(G, {
    target:'villainAndMyMinions', amountFrom:'xValue',
    piercingIf:{ type:'hasTrait', trait:'aerial' },
  }, ctx);
};
MC.defineCardFx('lightning-strike', {
  playForm: 'hero',
  special: 'lightningStrikePlay',
  uiFlow: 'spendXEnergy',
  vfx: { event:'thorStrike' },
  textKo: '이벤트 — Event. 초능력(Superpower). 비용 1 · 🧠멘탈 1.\\n\\n히어로 행동: X개의 ⚡에너지 자원을 소비한다 → 빌런과 당신과 교전한 각 하수인에게 X의 피해를 입힌다. 당신이 [[에어리얼]](Aerial) 특성을 가졌다면, 이 피해는 강인(Tough) 상태 카드를 무시한다.\\n\\n*\"천둥이여, 내 뜻을 따르라!\"*\\n\\n※ 공식 06006 Lightning Strike (Thor 히어로 팩) — thor.json 교차검증 (자원 🧠멘탈)\\n※ X = 지불한 에너지 수 · 빌런+교전 하수인 전체 광역 · 묠니르로 Aerial 획득 시 강인 관통',
});

/* 06007 Asgard (아스가르드) — 서포트. 장소(Location)·아스가르드. 비용 3, 🧠멘탈 1.
   손패 크기 +1. 범용(신규 코드 0줄): statMod(stat:handSize) — statOf(handSize)가 passiveStatMod로 합산. */
MC.defineCardFx('asgard-support', {
  statMod: { stat:'handSize', amount:1 },
  textKo: '서포트 — Support. 장소(Location) · 아스가르드(Asgard). 비용 3 · 🧠멘탈 1.\\n\\n당신의 손 크기(hand size)가 +1이 된다.\\n\\n*\"신들의 왕국. 이곳에서 영웅은 다시 일어선다.\"*\\n\\n※ 공식 06007 Asgard (Thor 히어로 팩) — thor.json 교차검증 (자원 🧠멘탈)\\n※ 지속: 손 크기 +1 (statMod 집계)',
});

/* 06008 God of Thunder (천둥의 신) — 업그레이드. 칭호(Title)·아스가르드. 비용 2, ⚡에너지 1.
   히어로 자원(Hero Resource): 소진 → ⚡에너지 자원 1개 생성. 범용: resourceGenerator(exhaust, energy). */
MC.defineCardFx('god-of-thunder', {
  resourceGenerator: { form:'hero', exhaust:true, icons:{ energy:1 } },
  textKo: '업그레이드 — Upgrade. 칭호(Title) · 아스가르드(Asgard). 비용 2 · ⚡에너지 1.\\n\\n히어로 자원(Hero Resource): 천둥의 신을 소진한다 → ⚡에너지 자원 1개를 생성한다.\\n\\n*\"나는 천둥의 신. 폭풍을 부르는 자다.\"*\\n\\n※ 공식 06008 God of Thunder (Thor 히어로 팩) — thor.json 교차검증 (자원 ⚡에너지)\\n※ 소진하여 에너지 자원 생성 — 매 라운드 준비되면 재사용 · 에너지 카드 결제 보조',
});

/* 06009 Mjolnir (묠니르) — 업그레이드. 무기(Weapon)·아스가르드. 비용 1, ⚡에너지 1. Restricted(제한).
   토르 ATK +1 + [[Aerial]] 특성 획득. 범용: statMod(attack) + grantsTrait(aerial) + restricted.
   ※ Aerial 부여로 Lightning Strike 강인 관통 + Hammer Throw 조건 완성. */
MC.defineCardFx('mjolnir', {
  restricted: true,
  statMod: { stat:'attack', amount:1 },
  grantsTrait: 'aerial',
  vfx: { install:'asgardInstall' },
  textKo: '업그레이드 — Upgrade. 무기(Weapon) · 아스가르드(Asgard). 비용 1 · ⚡에너지 1.\\n\\n제한(Restricted). *(플레이어당 제한 카드 최대 2장.)*\\n\\n토르는 ATK +1을 얻고 [[에어리얼]](Aerial) 특성을 획득한다.\\n\\n*\"자격 있는 자만이 이 망치를 들 수 있다.\"*\\n\\n※ 공식 06009 Mjolnir (Thor 히어로 팩) — thor.json 교차검증 (자원 ⚡에너지)\\n※ ATK +1 지속 + Aerial 부여 · Hammer Throw(반환)·Lightning Strike(관통)·Worthy(서치) 연동 핵심',
});

/* 06010 Thor's Helmet (토르의 투구) — 업그레이드. 방어구(Armor)·아스가르드. 비용 2, 🧠멘탈 1.
   최대 HP +5. 범용: hpBonus(recomputeMaxHp 스캔). */
MC.defineCardFx('thors-helmet', {
  hpBonus: 5,
  textKo: '업그레이드 — Upgrade. 방어구(Armor) · 아스가르드(Asgard). 비용 2 · 🧠멘탈 1.\\n\\n당신은 최대 체력(hit points) +5를 얻는다.\\n\\n*\"아스가르드의 강철은 어떤 타격도 견뎌낸다.\"*\\n\\n※ 공식 06010 Thor의 투구 (Thor 히어로 팩) — thor.json 교차검증 (자원 🧠멘탈)\\n※ 지속: 최대 HP +5 (hpBonus 집계)',
});

/* 06012 Valkyrie (발키리) — 동료. 공격(Aggression). 비용 3, ⚡에너지 1. ATK2/THW1/HP3. Asgard·Avenger.
   반응: 등장 후 하수인에게 2 피해 (이 카드를 ⚡에너지 자원으로 지불했다면 3 피해).
   범용: whenPlayed:runCardEffects + dealDamage(chosen, amount:2, amountIf paidWith energy→3).
   테마(웹): 브룬힐데. 아스가르드 발키리단 수장, 전사자를 발할라로 인도. 헬라 전투 생존자. */
MC.defineCardFx('valkyrie-ally', {
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'dealDamage', target:'chosen', amount:2, amountIf:{ cond:{ type:'paidWith', resource:'energy' }, amount:3 } },
  ],
  quoteKey: 'valkyrie',
  vfx: { entrance:'allyEnter', install:'allyEnter', basicAttack:'swordSlash' },
  textKo: '동료 — Ally. 공격(Aggression). 비용 3 · ⚡에너지 1. ATK 2 / THW 1 / HP 3. 아스가르드(Asgard) · 어벤저(Avenger).\\n\\n반응(Response): 발키리가 전장에 등장한 후, 하수인 하나에게 2의 피해를 입힌다 (이 카드를 ⚡에너지 자원으로 지불했다면 대신 3의 피해).\\n\\n*"발할라가 그대들을 기다린다. 허나 오늘은 아니지."*\\n\\n※ 공식 06012 Valkyrie (Thor 히어로 팩 · 공격 성향) — thor.json 교차검증 (자원 ⚡에너지)\\n※ 에너지 지불 시 피해 강화(3) · 등장 즉시 하수인 견제',
});

/* 06014 Get Over Here! (이리 와라!) — 이벤트. 공격(Attack). 비용 0, ⚡에너지 1.
   히어로 행동(공격): 하수인에게 1 피해. [[Aerial]] 특성이 있으면 그 적과 교전한다.
   범용: playForm hero + dealDamage(chosen, 1, isAttack) + engageTarget(cond:hasTrait aerial). */
MC.defineCardFx('get-over-here', {
  playForm: 'hero',
  effects: [
    { fx:'dealDamage', target:'chosen', amount:1, isAttack:true },
    { fx:'engageTarget', cond:{ type:'hasTrait', trait:'aerial' } },
  ],
  vfx: { event:'thorStrike' },
  textKo: '이벤트 — Event. 공격(Attack). 비용 0 · ⚡에너지 1.\\n\\n히어로 행동(공격): 하수인 하나에게 1의 피해를 입힌다. 당신이 [[에어리얼]](Aerial) 특성을 가졌다면, 그 적과 교전한다.\\n\\n*"이리 오너라! 도망칠 생각은 마라!"*\\n\\n※ 공식 06014 Get Over Here! (Thor 히어로 팩 · 공격 성향) — thor.json 교차검증 (자원 ⚡에너지)\\n※ Aerial(묠니르) 보유 시 원거리 하수인을 끌어와 교전 — Have at thee! 드로우 콤보 유발',
});

/* 06015 Mean Swing (강타) — 이벤트. 특기(Skill). 비용 0, 💪물리 1.
   히어로 인터럽트: 히어로가 기본 공격을 할 때, 무기(Weapon) 업그레이드를 소진 → 이번 공격 ATK +3.
   구현: playForm hero + playCondition(hasReadyWeapon) + exhaustWeapon(attackBonus:3) →
   pl.nextBasicAttackBonus 세팅 → 직후 기본 공격에 +3 (basicAttack 액션에서 반영·리셋).
   ※ 인터럽트 근사: 기본 공격 직전에 플레이 → 무기 소진 → 곧바로 기본 공격 시 +3 적용. */
MC.defineCardFx('mean-swing', {
  playForm: 'hero',
  playCondition: { type:'hasReadyWeapon' },
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'exhaustWeapon', attackBonus:3 }],
  vfx: { event:'thorStrike' },
  textKo: '이벤트 — Event. 특기(Skill). 비용 0 · 💪물리 1.\\n\\n히어로 인터럽트(Hero Interrupt): 당신의 히어로가 기본 공격을 할 때, 히어로의 무기(Weapon) 업그레이드 하나를 소진한다 → 이번 공격에서 히어로는 ATK +3을 얻는다.\\n\\n*"제대로 한 방 먹여주지!"*\\n\\n※ 공식 06015 Mean Swing (Thor 히어로 팩 · 공격 성향) — thor.json 교차검증 (자원 💪물리)\\n※ 준비된 무기(묠니르 등) 필요 · 기본 공격 직전 플레이 → 무기 소진하고 그 공격 +3 강화',
});

/* 06017 Hall of Heroes (영웅의 전당) — 서포트. 장소(Location)·아스가르드. 비용 2, 🧠멘탈 1.
   반응: 하수인 처치 후 영광(glory) 카운터 1개 배치. / 알터에고 행동: 소진 + 영광 3개 제거 → 카드 3장 드로우.
   구현: gloryOnMinionDefeat(onDefeated 훅으로 처치 시 카운터 축적) + activatedAbility(alter-ego, exhaust,
   useCounter:3, keepOnEmpty — 영구 유지, draw 3). */
MC.defineCardFx('hall-of-heroes', {
  gloryOnMinionDefeat: true,
  activatedAbility: {
    form: 'alter-ego', exhaust: true, useCounter: 3, keepOnEmpty: true,
    effect: [{ fx:'draw', who:'self', amount:3 }],
  },
  vfx: { install:'asgardInstall' },
  textKo: '서포트 — Support. 장소(Location) · 아스가르드(Asgard). 비용 2 · 🧠멘탈 1.\\n\\n반응(Response): 하수인을 처치한 후, 이곳에 영광(glory) 카운터 1개를 놓는다.\\n\\n알터에고 행동(Alter-Ego Action): 영웅의 전당을 소진하고 영광 카운터 3개를 제거한다 → 카드 3장을 뽑는다.\\n\\n*"용맹한 자들의 이름이 이곳에 새겨지리라."*\\n\\n※ 공식 06017 Hall of Heroes (Thor 히어로 팩 · 공격 성향) — thor.json 교차검증 (자원 🧠멘탈)\\n※ 하수인 처치마다 영광 축적 → 3개 모아 3장 드로우 (반복 재사용)',
});

/* 06018 Battle Fury (전투의 광란) — 업그레이드. 조건(Condition). 비용 1, ⚡에너지 1. 아무 플레이어 통제 하 플레이. 플레이어당 최대 1.
   반응: 히어로가 공격으로 하수인을 처치한 후, 히어로에게 1 피해 + Battle Fury 버림 → 히어로 준비(추가 행동).
   범용 인덱스: afterAttackReaction(condition:defeatedMinion, effects:[selfDamage+readySelf], discardSelf). */
MC.defineCardFx('battle-fury', {
  afterAttackReaction: {
    condition: 'defeatedMinion',
    effects: [{ fx:'selfDamage', amount:1 }, { fx:'readySelf' }],
    discardSelf: true,
    prompt: '전투의 광란: 히어로에게 1 피해 → 히어로를 준비(추가 행동)하시겠습니까?',
  },
  maxPerPlayer: 1,
  vfx: { install:'asgardInstall' },
  textKo: '업그레이드 — Upgrade. 조건(Condition). 비용 1 · ⚡에너지 1.\\n\\n아무 플레이어의 통제 하에 플레이한다. 플레이어당 최대 1장.\\n\\n반응(Response): 당신의 히어로가 공격으로 하수인을 처치한 후, 히어로에게 1의 피해를 입히고 전투의 광란을 버린다 → 당신의 히어로를 준비(ready) 상태로 만든다.\\n\\n*"피가 끓어오른다 — 멈출 수 없다!"*\\n\\n※ 공식 06018 Battle Fury (Thor 히어로 팩 · 공격 성향) — thor.json 교차검증 (자원 ⚡에너지)\\n※ 공격 처치 시 1 피해 감수하고 추가 행동 획득 — 연쇄 공격 콤보',
});

/* 06019 Jarnbjorn (야른뵨) — 업그레이드. 무기(Weapon)·아스가르드. 비용 1, 💪물리 1. Restricted(제한).
   반응: 히어로가 적을 공격한 후, 💪물리 자원 1개를 지불 → 적 하나에게 2 피해.
   범용 인덱스: afterAttackReaction(cost:physical1, needsTarget, effects:[dealDamage 2]). */
MC.defineCardFx('jarnbjorn', {
  restricted: true,
  afterAttackReaction: {
    cost: { physical: 1 },
    needsTarget: true,
    effects: [{ fx:'dealDamage', target:'chosen', amount:2 }],
    prompt: '야른뵨: 💪물리 자원을 지불하고 적에게 2 피해를 입히시겠습니까?',
  },
  vfx: { install:'asgardInstall' },
  textKo: '업그레이드 — Upgrade. 무기(Weapon) · 아스가르드(Asgard). 비용 1 · 💪물리 1.\\n\\n제한(Restricted).\\n\\n반응(Response): 당신의 히어로가 적을 공격한 후, 💪물리 자원 1개를 지불한다 → 적 하나에게 2의 피해를 입힌다.\\n\\n*"이 도끼는 신도 벨 수 있다."*\\n\\n※ 공식 06019 Jarnbjorn (Thor 히어로 팩 · 공격 성향) — thor.json 교차검증 (자원 💪물리)\\n※ 공격마다 물리 자원 1로 추가 2 피해 — 지속 딜링 무기 (아펠라시온의 도끼)',
});

/* 06031 Under Surveillance (감시 중) — 업그레이드. 정의(Justice). 비용 2, ⚡에너지 1. 조건(Condition).
   메인 스킴에 부착 (스킴당 최대 1). 부착된 스킴의 목표 위협치 +4 (완료 지연).
   범용: attachTarget:mainScheme(playCard가 부착) + whenPlayed:buffSchemeTarget(amount:4, _targetBuff 기록). */
MC.defineCardFx('under-surveillance', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'buffSchemeTarget', amount:4 }],
  textKo: '업그레이드 — Upgrade. 조건(Condition). 정의(Justice). 비용 2 · ⚡에너지 1.\\n\\n메인 스킴에 부착한다. 스킴당 최대 1장.\\n\\n부착된 스킴의 목표 위협치(완료 한도)를 +4 한다.\\n\\n*"놈들의 일거수일투족을 감시하고 있다."*\\n\\n※ 공식 06031 Under Surveillance (Thor 히어로 팩 · 정의) — thor.json 교차검증 (자원 ⚡에너지)\\n※ 위협 제거가 아닌 완료 한도 증가 — 솔로 시나리오(라이노·울트론) 생명줄\\n※ 메인 스킴 단계 진행 시 부착물·보너스 소멸',
});


/* 06021 Invulnerability (무적) — 이벤트. 초능력(Superpower)·기본. 비용 3, 💪물리 1.
   히어로 행동: 당신의 히어로에게 강인(Tough) 상태 카드를 부여한다.
   범용: playForm hero + applyStatus(target:self, status:tough). */
MC.defineCardFx('invulnerability', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'applyStatus', target:'self', status:'tough' }],
  textKo: '이벤트 — Event. 초능력(Superpower) · 기본(Basic). 비용 3 · 💪물리 1.\\n\\n히어로 행동: 당신의 히어로에게 강인(Tough) 상태 카드를 부여한다.\\n\\n*"어떤 공격도 나를 막을 수 없다."*\\n\\n※ 공식 06021 Invulnerability (Thor 히어로 팩 · 기본) — thor.json 교차검증 (자원 💪물리)\\n※ 강인(Tough) 부여 — 다음 피해 1회 완전 무효 (관통 제외)',
});

/* 06034 Enhanced Physique (강화된 신체) — 업그레이드. 조건(Condition)·기본. 비용 2, 💪물리 1.
   사용 횟수(Uses): 💪물리 카운터 3개. 히어로 자원: 소진 + 물리 카운터 1 제거 → 💪물리 자원 1개 생성.
   범용: uses:3 + resourceGenerator(exhaust, counter:1, icons:physical). (web-shooter 패턴) */
MC.defineCardFx('enhanced-physique', {
  uses: 3,
  resourceGenerator: { form:'hero', exhaust:true, counter:1, icons:{ physical:1 } },
  textKo: '업그레이드 — Upgrade. 조건(Condition) · 기본(Basic). 비용 2 · 💪물리 1.\\n\\n사용 횟수(Uses): 💪물리 카운터 3개.\\n\\n히어로 자원(Hero Resource): 강화된 신체를 소진하고 물리 카운터 1개를 제거한다 → 💪물리 자원 1개를 생성한다.\\n\\n*"단련된 육체는 그 자체로 무기다."*\\n\\n※ 공식 06034 Enhanced Physique (Thor 히어로 팩 · 기본) — thor.json 교차검증 (자원 💪물리)\\n※ 물리 자원 3회 생성 (소진→준비 반복) · 물리 자원 결제 보조',
});

/* 06033 Second Wind (재기) — 이벤트. 보호(Protection). 비용 3, 🧠멘탈 1.
   행동: 정체성 1명에서 4 피해 회복 (🧠멘탈 자원으로 지불했다면 5 회복).
   범용: whenPlayed:heal(target:self, amount:4, amountIf paidWith mental → 5). playForm 없음 = 알터에고도 사용 가능. */
MC.defineCardFx('second-wind', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'heal', target:'self', amount:4, amountIf:{ cond:{ type:'paidWith', resource:'mental' }, amount:5 } }],
  textKo: '이벤트 — Event. 보호(Protection). 비용 3 · 🧠멘탈 1.\\n\\n행동(Action): 정체성 1명에서 피해 4를 회복한다. 이 카드를 🧠멘탈 자원으로 지불했다면 → 5를 회복한다.\\n\\n*"아직 쓰러질 때가 아니다."*\\n\\n※ 공식 06033 Second Wind (Thor 히어로 팩 · 보호) — thor.json 교차검증 (자원 🧠멘탈)\\n※ "행동"이라 알터에고 폼에서도 사용 가능 (회복 턴 소모 없이 즉시)\\n※ 멘탈 지불 킥커 — 쉬헐크·와스프·스파이더맨(알터에고 🧠 생성)에 최적',
});

/* 06032 Teamwork (팀워크) — 이벤트. 리더십(Leadership). 비용 0, ⚡에너지 1. 전술(Tactic).
   히어로 난입: 기본 저지(THW)/기본 공격(ATK) 사용 시 → 통제 동료 1명 소진 → 그 동료의 일치 능력치를 이 사용에 추가.
   구현(프리로드): special:teamworkPlay → 동료 선택 소진 → nextBasicAttackBonus(+동료ATK)/nextBasicThwartBonus(+동료THW).
   다음 기본 공격이면 ATK 보너스, 기본 저지면 THW 보너스 적용 후 둘 다 소멸 (1회용). */
MC.HANDLERS.teamworkPlay = function(G, ctx){
  const pl = ctx.player;
  const ready = (pl.playArea.allies || []).filter(a => !a.exhausted);
  if (!ready.length){ MC.log(G, '팀워크 — 준비된 동료 없음 (효과 없음)'); return; }
  G.pending = { kind:'teamworkAlly', player: pl.uid, allyUids: ready.map(a => a.uid),
                prompt:'팀워크 — 소진할 동료 선택 (그 동료의 ATK를 다음 기본 공격에, THW를 다음 기본 저지에 추가)' };
};
MC.defineCardFx('teamwork', {
  playForm: 'hero',
  special: 'teamworkPlay',
  textKo: '이벤트 — Event. 전술(Tactic). 리더십(Leadership). 비용 0 · ⚡에너지 1.\\n\\n히어로 난입(Hero Interrupt): 기본 저지(THW) 또는 기본 공격(ATK) 능력을 사용할 때 → 통제하는 동료 1명을 소진한다 → 그 동료의 일치하는 능력치를 이 사용에 히어로 능력치로 추가한다.\\n\\n*"혼자선 못 해. 하지만 우리라면?"*\\n\\n※ 공식 06032 Teamwork (Thor 히어로 팩 · 리더십) — thor.json 교차검증 (자원 ⚡에너지)\\n※ 구현: 동료 소진 → 다음 기본 공격에 동료 ATK, 다음 기본 저지에 동료 THW 추가 (먼저 하는 행동에 적용, 1회용)\\n※ 동료는 소진만 (부수 피해 없음) · Wonder Man 💪 비용 회피에 유용',
});

/* ═══ 토르 성향(기타 어스팩트) 카드 ═══ */

/* 06020 Heimdall (하임달) — 동료. 기본(Basic). 비용 5, 🧠멘탈 1. ATK3/THW2/HP4. Asgard.
   반응: 등장 후 조우덱 상위 3장을 보고, 1장을 버리고 나머지를 원하는 순서로 되돌린다.
   범용: whenPlayed:runCardEffects + scryEncounter(count:3, discard:1) — pending:encounterScry UI.
   테마(웹): 비프로스트 파수꾼, 만물을 보는 자. 아홉 세계를 꿰뚫는 예지. */
MC.defineCardFx('heimdall', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'scryEncounter', count:3, discard:1, prompt:'하임달의 예지 — 조우덱 상위 3장 중 1장 버림' }],
  quoteKey: 'heimdall',
  vfx: { entrance:'allyEnter', install:'allyEnter', basicAttack:'swordSlash' },
  textKo: '동료 — Ally. 기본(Basic). 비용 5 · 🧠멘탈 1. ATK 3 / THW 2 / HP 4. 아스가르드(Asgard).\\n\\n반응(Response): 하임달이 전장에 등장한 후, 조우 덱 맨 위 3장을 본다. 그중 1장을 버리고 나머지를 원하는 순서로 맨 위에 되돌린다.\\n\\n*"만물을 보는 자, 하임달이 왔노라."*\\n\\n※ 공식 06020 Heimdall (Thor 히어로 팩 · 기본) — thor.json 교차검증 (자원 🧠멘탈)\\n※ 조우덱 예지 — 위험 카드 미리 제거 (되돌림 순서는 상단 유지)',
});



/* 06011 Hercules (헤라클레스) — 동료. 공격(Aggression). 비용 6, 💪물리 1. ATK3/THW1/HP4. Avenger·Olympus.
   나와 교전 중인 하수인 1명당 플레이 비용 -1. 범용: costReduction(per:engagedMinion).
   테마(웹): 권능의 왕자·올림푸스의 사자·제우스의 아들. 전투를 "선물"로 즐기는 호탕한 반신. */
MC.defineCardFx('hercules', {
  costReduction: { per:'engagedMinion', amount:1 },
  quoteKey: 'hercules',
  vfx: { entrance:'allyEnter', install:'allyEnter' },
  textKo: '동료 — Ally. 공격(Aggression). 비용 6 · 💪물리 1. ATK 3 / THW 1 / HP 4. 어벤저(Avenger) · 올림푸스(Olympus).\\n\\n헤라클레스를 플레이하는 비용은 당신과 교전 중인 하수인 1명당 1씩 감소한다.\\n\\n*"전투의 선물을 가져왔노라!"*\\n\\n※ 공식 06011 Hercules (Thor 히어로 팩 · 공격 성향) — thor.json 교차검증 (자원 💪물리)\\n※ 교전 하수인이 많을수록 저렴 — 하수인 몰릴 때 강력한 어벤저 동료',
});

})(typeof window !== 'undefined' ? window : globalThis);


