/* ═══════════════════════════════════════════════════════════════
   mc_scenarios.js — 시나리오/프리셋 덱 정의 (인덱스 JSON에서 이식)
   조우덱 구성: ENCOUNTER_DECK_DEF 라이노 구간 (라이노 세트 + 폭탄 위협 모듈 + 표준 세트)
   프리셋 덱: 이전 빌드 PRESET_DECK_IDS 승계
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* ═══ 모듈러 인카운터 세트 카탈로그 ═══
   빌런 전용 카드와 분리된 모듈러 세트들. 빌런 + (고정/랜덤/선택) 모듈러 조합에 사용.
   각 세트는 카드 slug 배열(수량만큼 반복 포함). */
MC.MODULAR_SETS = {
  'hydra-patrol': {
    name: '하이드라 순찰대',
    cards: ['04152','04152','04153','04153','04153','04154'],
  },
  'goblin-gimmicks': {
    name: '고블린 장치', nameEn: 'Goblin Gimmicks',
    // Goblin Glider(02019)·Pumpkin Bombs(02021)는 시나리오 카드와 동일 — 재사용. 각 2장.
    cards: ['02019','02019','02021','02021','02035','02035','regenerative-healing','regenerative-healing'],
  },
  'a-mess-of-things': {
    name: '뒤죽박죽', nameEn: 'A Mess of Things',
    cards: ['a-mess-of-things','scorpion','gang-up','tail-sweep','tail-sweep'],
  },
  'power-drain': {
    name: '전력 흡수', nameEn: 'Power Drain',
    cards: ['power-drain','electro','electromagnetic-pulse','lightning-bolt','shock-therapy'],
  },
  'running-interference': {
    name: '방해 공작', nameEn: 'Running Interference',
    cards: ['running-interference','tombstone','all-tied-up','media-coverage','media-coverage'],
  },
  'bomb-scare': {
    name: '폭탄 위협', nameEn: 'Bomb Scare',
    cards: ['bomb-threat','hydra-bomber','hydra-bomber','explosion','false-alarm','false-alarm'],
  },
  'legions-of-hydra': {
    name: '히드라 군단', nameEn: 'Legions of Hydra',
    cards: ['legions-of-hydra-scheme','legions-of-hydra-scheme','madame-hydra',
            'hydra-soldier','hydra-soldier','hydra-soldier'],
  },
  'modok': {
    name: 'M.O.D.O.K.', nameEn: 'M.O.D.O.K.',
    cards: ['doomsday-chair-scheme','doomsday-chair-scheme','modok',
            'biomechanical-upgrades','biomechanical-upgrades','biomechanical-upgrades'],
  },
  'under-attack': {
    name: '기습 공격', nameEn: 'Under Attack',
    // 공식 Core Set #151-154: Under Attack(사이드스킴), Concussion Blasters(부착), Concussive Blast(배반 ×2), Vibranium Chassis(부착)
    cards: ['under-attack','concussion-blasters','concussive-blast','concussive-blast','vibranium-armor-u'],
  },
  'masters-of-evil': {
    name: '악의 지배자들', nameEn: 'The Masters of Evil',
    cards: ['masters-of-evil-scheme','radioactive-man','whirlwind','tiger-shark','melter',
            'masters-of-mayhem','masters-of-mayhem'],
  },
  'hydra-assault': {
    name: '하이드라 강습', nameEn: 'Hydra Assault',
    cards: ['04145','04145','04145','04146','04146','04147'],
  },
  'weapon-master': {
    name: '무기 마스터', nameEn: 'Weapon Master',
    cards: ['04148','04149','04150','04150','04151'],
  },
};

/* ═══ 넴시스 세트 매핑 ═══
   각 영웅의 넴시스 조우 세트. Shadow of the Past(01190)가 셋어사이드에서 투입.
   구성: minion(하수인 1종), sideScheme(사이드 스킴 1종), rest(나머지 배신/부착; [slug, 수량]).
   ※ obligation은 셋업 시 이미 조우덱에 셔플되므로 여기서 제외.
   ※ 앞면(hero)·뒷면(alter-ego) 코드 둘 다 키로 등록 (어느 폼으로 조회해도 매칭). */
MC.NEMESIS_SETS = {
  blackPanther: { minion:'killmonger', sideScheme:'usurp-the-throne',
    rest:[['heart-shaped-herb',1],['ritual-combat',2]] },
  sheHulk: { minion:'titania', sideScheme:'personal-challenge',
    rest:[['genetic-enhancement',1],['titanias-fury',2]] },
  spiderMan: { minion:'vulture', sideScheme:'highway-robbery',
    rest:[['sweeping-swoop',2],['vultures-plans',1]] },
  ironMan: { minion:'whiplash', sideScheme:'imminent-overload',
    rest:[['electric-whip-attack',2],['electromagnetic-backlash',1]] },
  captainMarvel: { minion:'yon-rogg', sideScheme:'psyche-magnitron',
    rest:[['kree-manipulator',2],['yon-roggs-treason',1]] },
  captainAmerica: { minion:'baron-zemo', sideScheme:'hit-squad',
    rest:[['hydra-soldier',2],['hail-hydra',1]] },
  msMarvel: { minion:'thomas-edison', sideScheme:'generation-why',
    rest:[['edisons-giant-robot',1],['harvest',2]] },
  hawkeye: { minion:'crossfire', sideScheme:'marked-for-death',
    rest:[['sniper-shot',2]] },
  thor: { minion:'loki-nemesis', sideScheme:'family-feud',
    rest:[['frost-giant',2],['trickster',1]] },
  blackWidow: { minion:'taskmaster-nemesis', sideScheme:'killer-for-hire',
    rest:[['hydra-mercenary-bw',2],['deadly-shot',1]] },
  doctorStrange: { minion:'baron-mordo', sideScheme:'open-dark-dimension',
    rest:[['counterspell',2],['thoughtcasting',1]] },
  hulk: { minion:'abomination', sideScheme:'total-destruction',
    rest:[['clash-of-titans',3]] },
};
/* 의무(obligation) 카드 hero 필드 보정 — db 누락분. 셋업 시 slug 매칭으로 조우덱 셔플됨. */
if (MC.CARDS){
  if (MC.CARDS['criminal-past']) MC.CARDS['criminal-past'].hero = 'hawkeye-cb';
  if (MC.CARDS['odins-anger'])   MC.CARDS['odins-anger'].hero   = 'thor';
  if (MC.CARDS['burn-notice'])   MC.CARDS['burn-notice'].hero   = 'black-widow-hero';
}
/* 영웅 신분 코드(앞/뒷면) → 넴시스 세트 키 */
MC.NEMESIS_BY_HERO = {
  '01040a':'blackPanther', '01040b':'blackPanther',   // 블랙 팬서 / 티찰라
  '01019a':'sheHulk',      '01019b':'sheHulk',        // 쉬헐크 / 제니퍼 월터스
  '01001a':'spiderMan',    '01001b':'spiderMan',      // 스파이더맨 / 피터 파커 (벌처)
  '01029a':'ironMan',      '01029b':'ironMan',        // 아이언맨 / 토니 스타크 (위플래시)
  '01010a':'captainMarvel','01010b':'captainMarvel',  // 캡틴 마블 / 캐롤 댄버스 (욘-로그)
  '03001a':'captainAmerica','03001b':'captainAmerica', // 캡틴 아메리카 / 스티브 로저스 (바론 제모)
  '05001a':'msMarvel',      '05001b':'msMarvel',       // 미즈마블 / 카말라 칸 (토마스 에디슨/발명가)
  '04001a':'hawkeye',       '04001b':'hawkeye',        // 호크아이 / 클린트 바턴 (크로스파이어)
  '06001a':'thor',          '06001b':'thor',           // 토르 / 오딘슨 (로키)
  '08001a':'blackWidow',    '08001b':'blackWidow',     // 블랙위도우 / 나타샤 (타스크마스터)
  '09001a':'doctorStrange', '09001b':'doctorStrange',  // 닥터 스트레인지 / 스티븐 스트레인지 (바론 모르도)
  '10001a':'hulk',          '10001b':'hulk',           // 헐크 / 브루스 배너 (아보미네이션)
};

MC.SCENARIOS = {
  rhino: {
    name: '라이노', nameEn: 'Rhino',
    villainStart: '01094',
    mainScheme: '01097b',
    // 빌런 전용 조우 카드 (모듈러 제외)
    villainEncounter: [
      'rhino-suit','charge','charge','horn-attack','hydra-mercenary','hydra-mercenary',
      'sandman','shocker','hard-to-keep-down','hard-to-keep-down','im-tough','im-tough',
      'stampede','stampede','stampede','crowd-control','breakin-and-takin',
    ],
    // 표준 세트 (모든 코어 시나리오 공통)
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    // 이 빌런의 권장(기본) 모듈러 세트 키
    defaultModular: ['bomb-scare'],
  },
  klaw: {
    name: '클로', nameEn: 'Klaw',
    villainStart: '01113',          // 클로 (I)
    mainScheme: '01116b',           // 지하 유통망 1B (진행면)
    // 클로 전용 조우 세트 (공식 quantity, 부착물은 whenRevealed로 조우덱에서 등장)
    villainEncounter: [
      'sonic-converter','solid-sound-body',
      'armored-guard','armored-guard','armored-guard',
      'weapons-runner','weapons-runner',
      'klaw-vengeance','klaw-vengeance',
      'sonic-boom','sonic-boom',
      'sound-manipulation','sound-manipulation',
      'defense-network','illegal-arms-factory','immortal-klaw',
    ],
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: ['masters-of-evil'],   // 클로 공식 권장 모듈러
  },
  ultron: {
    name: '울트론', nameEn: 'Ultron',
    villainStart: '01134',          // 울트론 (I) — 표준 모드
    mainScheme: '01137b',           // 크림슨 카울 1B (진행면) · 1A 셋업(울트론 드론 환경)은 onSetup
    villainEncounter: [
      // 울트론 세트 (ultron-drones 환경은 셋업으로 배치되므로 조우덱에서 제외)
      'android-efficiency','android-efficiency','android-efficiency',
      'rage-of-ultron','rage-of-ultron',
      'repair-sequence','repair-sequence',
      'swarm-attack','swarm-attack',
      'program-transmitter',
      'upgraded-drones','upgraded-drones',
      'drone-factory','invasive-ai','ultrons-imperative',
    ],
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: [],   // 울트론은 자체 세트가 강해 기본 모듈러 없음 (선택 시 추가 가능)
  },
  /* ── MVC02 그린 고블린 — Risky Business (양면 폼전환 빌런) ──
     빌런은 노먼 오스본(I, 02001a)로 시작 + Criminal Enterprise 환경을 셋업 배치.
     ★ 폼전환 엔진 메커니즘(카운터 플립) 구현 후 완전 플레이 가능. 현재는 데이터 등록 단계. */
  riskyBusiness: {
    name: '위험한 거래', nameEn: 'Risky Business',
    villainStart: '02001a',          // 노먼 오스본 (I)
    mainScheme: '02004b',            // 적대적 인수 1B (진행면) · 1A 셋업(Criminal Enterprise 배치)
    startEnvironment: 'criminal-enterprise',   // 셋업 시 전장 배치 (폼전환 엔진에서 소비)
    // Risky Business 전용 조우 세트 (공식 quantity · 환경은 셋업 배치라 조우덱 제외)
    villainEncounter: [
      'hired-gun','hired-gun','hired-gun',
      'private-security-specialist','private-security-specialist','private-security-specialist','private-security-specialist',
      'collapsing-bridge',
      'oscorp-manufacturing','oscorp-manufacturing',
      'payoff','payoff',
      'all-in-a-days-work','all-in-a-days-work','all-in-a-days-work','all-in-a-days-work',
      'mad-genius','mad-genius',
    ],
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: ['goblin-gimmicks'],   // 공식 권장 모듈러 (미등록 시 빈 배열 처리)
  },
  mutagenFormula: {
    name: '뮤타젠 포뮬러', nameEn: 'Mutagen Formula',
    villainStart: '02014',           // 그린 고블린 (I) — 단면(폼전환 없음)
    mainScheme: '02017b',            // 뮤타젠 방출 1B (진행면) · 1A 셋업(각 플레이어 Goblin Thrall 배치)
    // Mutagen Formula 전용 조우 세트 (공식 quantity)
    villainEncounter: [
      '02019',                       // goblin-glider (부착)
      'hysteria',                    // 02020 (부착)
      '02021',                       // pumpkin-bombs (부착)
      'goblin-knight',
      'goblin-soldier','goblin-soldier','goblin-soldier','goblin-soldier',
      'goblin-thrall','goblin-thrall','goblin-thrall','goblin-thrall','goblin-thrall','goblin-thrall',
      'monster',
      'goblin-reinforcements','goblin-reinforcements',
      'goblin-nation',
      'overrun','overrun',
      'death-from-above','death-from-above',
      'i-see-you',
      'overconfidence',
      'wicked-ambitions','wicked-ambitions',
    ],
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: ['goblin-gimmicks'],   // 공식 권장 모듈러 (미등록 시 buildEncounter가 스킵)
  },
  crossbones: {
    name: '크로스본즈', nameEn: 'Crossbones',
    villainStart: '04058',          // 크로스본즈 (I) — 표준 모드 (전문가: 04060 III 추가)
    mainScheme: '04061b',           // 마운트 아테나 공격 1B (진행면) → 인피니티 스톤 → 도주 (nextStage 다단계)
    // 크로스본즈 전용 조우 세트 (Crossbones set, 공식 quantity)
    villainEncounter: [
      '04064','04065',                       // 기관총·아머 (부착물)
      '04066','04066',                       // 하이드라 폭격병 ×2
      '04067','04067',                       // 풀 오토 ×2
      '04068','04068',                       // 강철 같은 의지 ×2
      '04069','04069',                       // 무기고 습격 ×2
      '04070','04070',                       // 크로스본즈의 강습 ×2
      '04071',                               // 궁지에 몰린 참모 ×1
    ],
    // 실험 무기 덱은 빌런 def(04058).experimentalWeaponsDeck으로 별도 셋업 (전용 UI 표시)
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: ['hydra-assault','weapon-master'],   // 크로스본즈 공식 권장 모듈러 (+ Legions of Hydra는 선택)
    // 캠페인 룰북 참조 (PDF.js 렌더용, 링크 방식 — 용량 최소). 5개 시나리오 공용 rulebookPdf.
    rulebookPdf: 'https://raw.githubusercontent.com/ansqudwmns01-collab/mav/Skull/mc10_%EB%A0%88%EB%93%9C%EC%8A%A4%EC%BB%AC%EC%9D%98%20%EB%B6%80%EC%83%81%20%EB%A3%B0_web.pdf',
    comicIntro: [4],    // 시나리오 인트로 코믹스 (크로스본즈: PEGASUS 강습, p4)
    comicIntroCaptions: ['<b>🎬 마운트 아테나 · P.E.G.A.S.U.S. 시설</b><br><i>[장면]</i> 하이드라 병력이 시설을 급습한다. 최전선에서 크로스본즈가 강습을 지휘한다.<br><br>“겁먹을 시간도 아깝다 — 하일 하이드라!”<br>경보를 감지한 어벤져스가 방어에 나서지만, 하이드라의 진짜 목표는 따로 있다. 실험 무기, 그리고 그 너머의 스톤.'],
    comicDefeat: [6],   // 빌런 격파(승리) 후 코믹스 (p6)
    comicDefeatCaptions: ['<b>🎬 크로스본즈, 쓰러지다 — 그러나</b><br><i>[장면]</i> 어벤져스가 크로스본즈를 제압한다. 하지만 그는 이미 스톤을 손에 넣은 뒤였다.<br><br>“이걸로 끝이라고? 웃기지 마 — 난 그냥 배달부일 뿐이야.”<br>오토바이 굉음과 함께 전장을 빠져나가는 크로스본즈. 그 뒤를 거구의 그림자가 가로막는다. 어보밍맨이다. 추격은 이제 시작이다.'],
    // ─ 캠페인 코믹스 페이지 매핑 기록 (확장 시 사용): 어보밍맨 격파=p8·9, 태스크마스터 격파=p11, 졸라=p13→p14 ─
  },
  'absorbing-man': {
    name: '어보밍맨', nameEn: 'Absorbing Man',
    villainStart: '04076',          // 어보밍맨 (I) — 표준 (전문가: 04077 II 시작)
    mainScheme: '04079b',           // 누구도 지나갈 수 없다 1B (delay 카운터 + 환경 1개 교체)
    villainEncounter: [
      '04080','04081','04082','04083',       // 환경 4종 (숲/언덕/바위/시설 — Wood/Ice/Stone/Metal)
      '04084',                               // 볼 앤 체인 (부착)
      '04085','04085','04086','04086',       // 지연 전술 ×2, 휘두르는 돌 ×2
      '04087','04087','04088','04088',       // 강철 발차기 ×2, 꿰뚫는 가시 ×2
      '04089','04089','04089','04090','04090', // 옴니모프 복제 ×3, 얼음 손아귀 ×2
      '04091','04091',                       // 눈사태! ×2
    ],
    setAside: ['04092'],            // 초강력 흡수 — 어보밍맨 II의 공개 시 능력이 소환 (set aside)
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: ['hydra-patrol'],
    setupRevealEnvironment: true,   // 셋업: 조우덱에서 환경이 나올 때까지 버리고 환경 1장 배치 후 재셔플             // 공식 권장 Hydra Patrol — 모듈러 미등록, 추후 추가
    rulebookPdf: 'https://raw.githubusercontent.com/ansqudwmns01-collab/mav/Skull/mc10_%EB%A0%88%EB%93%9C%EC%8A%A4%EC%BB%AC%EC%9D%98%20%EB%B6%80%EC%83%81%20%EB%A3%B0_web.pdf',
    comicDefeat: [8, 9],            // 어보밍맨 격파 코믹스 (인트로는 크로스본즈 격파 p6가 겸함)
    comicDefeatCaptions: [
      '<b>🎬 추격의 끝 — 어보밍맨, 무너지다</b><br><i>[장면]</i> 어보밍맨이 흡수한 강철도, 바위도 영웅들의 맹공을 버티지 못한다.<br><br>"흥… 겨우 이 정도로? 크러셔 크릴을 막았다고 우쭐대지 마라…"<br>거구가 무릎을 꿇는다. 하지만 크로스본즈는 이미 멀어졌고, 스톤은 더 깊은 곳으로 향한다. 다음 추격자는 냉정한 모방의 달인 — 태스크마스터다.',
    ],
  },

  'taskmaster': {
    name: '태스크마스터',
    nameEn: 'Taskmaster',
    villainStart: '04093',           // 태스크마스터 I (→ 04094 II → 04095 III)
    mainScheme: '04096b',            // 영웅 사냥 1B (빌런 페이즈 후 각 히어로 위협/피해 선택, 완료 시 패배)
    villainEncounter: [
      '04101','04101',                       // 하이드라 헌터 ×2 (관통+원거리)
      '04102','04103','04104','04104',       // 검, 방패, 사진 반사 ×2 (태스크마스터 부착)
      '04105','04105','04106','04106',       // 모방 ×2, 하이드라의 표적 ×2 (배반)
      '04107','04107','04107','04107','04108', // 하이드라에 포획 ×4, 훈련소 ×1 (사이드 스킴)
      '04152','04152','04153','04153','04153','04154', // Hydra Patrol 세트 (고정 포함)
    ],
    captiveAllies: ['04097','04098','04099','04100'],  // 포로 동료 — 게임 밖 set aside, Captured by Hydra 저지 시 구출
    setupRevealSideScheme: '04154',  // 셋업: Hydra Patrol 사이드 스킴을 찾아 공개
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: ['weapon-master'],   // 공식 권장 Weapon Master
    rulebookPdf: 'https://raw.githubusercontent.com/ansqudwmns01-collab/mav/Skull/mc10_%EB%A0%88%EB%93%9C%EC%8A%A4%EC%BB%AC%EC%9D%98%20%EB%B6%80%EC%83%81%20%EB%A3%B0_web.pdf',
    comicDefeat: [11],               // 태스크마스터 격파 코믹스 (인트로는 어보밍맨 격파 p8-9가 겸함)
    comicDefeatCaptions: [
      "<b>🎬 사냥꾼의 몰락 — 태스크마스터, 쓰러지다</b><br><i>[장면]</i> 완벽한 모방도, 훔친 무기도 영웅들의 진짜 의지 앞에선 소용없었다.<br><br>\"흥… 돈값은 했다고 생각했는데… 너희, 제법이군.\"<br>갈라진 스컬 마스크 아래로 토니 마스터스가 물러선다. 그는 계약을 포기했고, 사로잡혔던 히어로들은 무사히 풀려났다. 하지만 하이드라의 진짜 두뇌는 아직 그림자 속에 있다 — 생체공학의 광인, 아르님 졸라의 실험실이 기다린다.",
    ],
  },
  'zola': {
    name: '아르님 졸라',
    nameEn: 'Arnim Zola',
    villainStart: '04109',
    mainScheme: '04112b',
    villainEncounter: [
      '04114','04114','04114','04114',
      '04115','04115','04115',
      '04116','04116','04116',
      '04117','04117','04117','04118','04118','04119','04119',
      '04120','04120','04120','04121','04121',
      '04122','04123','04123','04124',
    ],
    setupRevealSideScheme: '04122',
    setupEngageMinion: '04114',
    standard: ['advance','advance','assault','assault','caught-off-guard','gang-up','shadow-of-the-past'],
    defaultModular: ['under-attack'],
    rulebookPdf: 'https://raw.githubusercontent.com/ansqudwmns01-collab/mav/Skull/mc10_%EB%A0%88%EB%93%9C%EC%8A%A4%EC%BB%AC%EC%9D%98%20%EB%B6%80%EC%83%81%20%EB%A3%B0_web.pdf',
    comicDefeat: [13, 14],
    comicDefeatCaptions: [
      "<b>🎬 미친 박사의 최후 — 아르님 졸라, 무너지다</b><br><i>[장면]</i> 시험관이 깨지고 뮤테이트들이 스러진다. 생체공학의 광인은 자신의 실험실 한복판에서 쓰러졌다.<br><br>\"불가능해… 내 계산은 완벽했는데…\"<br>초록빛 독성 연무가 잦아들고, 졸라의 몸이 기능을 멈춘다. 사로잡혔던 이들은 풀려났고, 섬의 악몽은 끝났다. 그러나 이 모든 실험을 지시한 자 — 하이드라의 총수, 붉은 해골이 마침내 그림자에서 걸어 나온다.",
      "<b>🎬 붉은 해골, 강림하다</b><br><i>[장면]</i> 졸라의 데이터가 그의 주인에게로 흘러간다. 하이드라의 깃발 아래, 요한 슈미트가 세상을 향해 선언한다.<br><br>\"머리 하나를 자르면, 둘이 자라난다. 이제 진짜 전쟁이 시작된다.\"<br>레드 스컬의 시대가 열린다. 최후의 대결이 다가온다.",
    ],
  },
};

/* 시나리오 + 선택 모듈러 키 배열 → 최종 조우덱 카드 목록 조립.
   modularKeys 미지정 시 시나리오의 defaultModular 사용. */
MC.buildEncounter = function(scenarioKey, modularKeys, difficulty){
  const scen = MC.SCENARIOS[scenarioKey];
  if (!scen) return [];
  const keys = modularKeys || scen.defaultModular || [];
  let cards = (scen.villainEncounter || []).slice();
  for (const mk of keys){
    const mod = MC.MODULAR_SETS[mk];
    if (mod) cards = cards.concat(mod.cards);
  }
  cards = cards.concat(scen.standard || []);
  // 난이도 Expert: 코어 Expert 인카운터 세트 3장 추가 (룰북 공식 — 모든 시나리오 공통)
  if (difficulty === 'expert') cards = cards.concat(['exhaustion', 'masterplan', 'under-fire']);
  return cards;
};

/* 랜덤 모듈러 세트 키 n개 선택 (중복 없이). rngFn(선택적)으로 결정론적 선택 가능. */
MC.randomModularKeys = function(n, rngFn){
  const all = Object.keys(MC.MODULAR_SETS);
  const rng = rngFn || Math.random;
  const pool = all.slice();
  const picked = [];
  n = Math.min(n || 1, pool.length);
  for (let i = 0; i < n; i++){
    const idx = Math.floor(rng() * pool.length);
    picked.push(pool.splice(idx, 1)[0]);
  }
  return picked;
};

/* 코어 세트 공식 프리빌트(스타터) 덱 5종 — 룰북 STARTER DECKS 그대로.
   구성: 시그니처 15장 + 아스펙트 카드 + 기본(Basic) 카드. slug는 db 기준.
   아스펙트: 스파이더맨=정의 · 캡틴마블=리더십 · 쉬헐크=용맹 · 아이언맨=용맹 · 블랙팬서=보호.
   ※ 쉬헐크·아이언맨은 용맹 아스펙트 카드를 공유(코어 1박스 동시 사용 불가). */
const _basicCore = ['avengers-mansion','emergency','energy','first-aid','haymaker','genius','mockingbird','nick-fury','helicarrier','strength','tenacity'];
MC.PRESET_DECKS = {
  spiderman: {
    hero: '01001a', name: '스파이더맨 / 정의',
    cards: [
      // 시그니처
      'aunt-may','backflip','backflip','black-cat','enhanced-spider-sense','enhanced-spider-sense',
      'spider-tracer','spider-tracer','swinging-web-kick','swinging-web-kick','swinging-web-kick',
      'web-shooter','web-shooter','webbed-up','webbed-up',
      // 정의(Justice)
      'daredevil','for-justice','for-justice','great-responsibility','great-responsibility',
      'heroic-intuition','heroic-intuition','interrogation-room','interrogation-room','jessica-jones',
      'surveillance-team','surveillance-team','power-of-justice','power-of-justice',
      ..._basicCore,
    ],
  },
  'captain-marvel': {
    hero: '01010a', name: '캡틴 마블 / 리더십',
    cards: [
      // 시그니처
      'alpha-station','captain-marvel-helmet','cosmic-flight','cosmic-flight',
      'crisis-interdiction','crisis-interdiction','crisis-interdiction',
      'energy-absorption','energy-absorption','energy-channel','energy-channel',
      'photon-blast','photon-blast','photon-blast','spider-woman-ally',
      // 리더십(Leadership)
      'get-ready','get-ready','hawkeye','inspired','inspired','lead-from-the-front','lead-from-the-front',
      'make-the-call','make-the-call','maria-hill','power-of-leadership','power-of-leadership',
      'the-triskelion','vision',
      ..._basicCore,
    ],
  },
  'she-hulk': {
    hero: '01019a', name: '쉬헐크 / 용맹',
    cards: [
      // 시그니처
      'focused-rage','focused-rage','gamma-slam','ground-stomp','ground-stomp',
      'legal-practice','legal-practice','one-two-punch','one-two-punch','one-two-punch',
      'split-personality','superhuman-law','superhuman-strength','superhuman-strength','hellcat',
      // 용맹(Aggression)
      'chase-them-down','chase-them-down','combat-training','combat-training','hulk-ally',
      'relentless-assault','relentless-assault','tac-team','tac-team',
      'power-of-aggression','power-of-aggression','tigra-ally','uppercut','uppercut',
      ..._basicCore,
    ],
  },
  'iron-man': {
    hero: '01029a', name: '아이언맨 / 용맹',
    cards: [
      // 시그니처
      'arc-reactor','mk5-armor','mk5-helmet','pepper-potts','powered-gauntlets','powered-gauntlets',
      'repulsor-blast','repulsor-blast','repulsor-blast','rocket-boots','rocket-boots',
      'stark-tower','supersonic-punch','supersonic-punch','war-machine',
      // 용맹(Aggression) — 쉬헐크와 공유
      'chase-them-down','chase-them-down','combat-training','combat-training','hulk-ally',
      'relentless-assault','relentless-assault','tac-team','tac-team',
      'power-of-aggression','power-of-aggression','tigra-ally','uppercut','uppercut',
      ..._basicCore,
    ],
  },
  'black-panther': {
    hero: '01040a', name: '블랙 팬서 / 보호',
    cards: [
      // 시그니처
      'ancestral-knowledge','energy-daggers','panther-claws','shuri','tactical-genius-bp',
      'golden-city','vibranium-resource','vibranium-resource','vibranium-resource','vibranium-suit',
      'wakanda-forever','wakanda-forever','wakanda-forever','wakanda-forever','wakanda-forever',
      // 보호(Protection)
      'armored-vest','armored-vest','black-widow-ally','counter-punch','counter-punch',
      'get-behind-me','get-behind-me','indomitable','indomitable','luke-cage',
      'med-team','med-team','power-of-protection','power-of-protection',
      ..._basicCore,
    ],
  },
  'captain-america': {
    hero: '03001a', name: '캡틴 아메리카 / 리더십',
    cards: [
      // 시그니처 (15) — Living Legend: 방패는 셋업 시 자동 손패
      'agent-13','fearless-determination','fearless-determination',
      'heroic-strike','heroic-strike','heroic-strike',
      'shield-block','shield-block','shield-toss','shield-toss',
      'steves-apartment','cap-helmet','cap-shield',
      'super-soldier-serum','super-soldier-serum',
      // 리더십(Leadership) 13 + 어벤져스 타워(Basic) 1
      'falcon-ally','wonder-man','hawkeye','squirrel-girl',
      'make-the-call','make-the-call','get-ready','get-ready',
      'avengers-assemble','strength-in-numbers','lead-from-the-front',
      'power-of-leadership','power-of-leadership',
      'avengers-tower',
      ..._basicCore,
    ],
  },
  'ms-marvel': {
    hero: '05001a', name: '미즈마블 / 수호',
    cards: [
      // 시그니처 (15) — 카말라 칸: Morphogenetics(공격/저지/방어 이벤트 재사용)
      'red-dagger',
      'big-hands','big-hands','big-hands',
      'sneak-by','sneak-by','sneak-by',
      'wiggle-room','wiggle-room',
      'aamir-khan','bruno-carrelli','nakia-bahadir',
      'biokinetic-polymer-suit','embiggen','shrink',
      // 수호(Protection) 14
      'nova-ally','preemptive-strike','preemptive-strike',
      'energy-barrier','energy-barrier','tackle',
      'med-team','armored-vest','indomitable',
      'counter-punch','get-behind-me','electrostatic-armor',
      'power-of-protection','power-of-protection',
      ..._basicCore,
    ],
  },
  thor: {
    hero: '06001a', name: '토르 / 용맹(Aggression)',
    cards: [
      // 시그니처 (15) — 오딘슨: Worthy(묠니르 소환/자원 전환), 천둥/번개 이벤트 화력
      'lady-sif',
      'defender-nine-realms','defender-nine-realms','defender-nine-realms',
      'for-asgard',
      'hammer-throw','hammer-throw','hammer-throw',
      'lightning-strike','lightning-strike',
      'asgard-support',
      'god-of-thunder','god-of-thunder',
      'mjolnir','thors-helmet',
      // 용맹(Aggression) 15 — 토르 팩 13 + 코어 2 (하수인 처치 + 과잉살상)
      'hercules','valkyrie-ally',
      'get-over-here','get-over-here','get-over-here',
      'mean-swing','mean-swing','mean-swing',
      'hall-of-heroes',
      'battle-fury','battle-fury','battle-fury',
      'jarnbjorn',
      'power-of-aggression','power-of-aggression',
      // 기본 10 — 토르 팩 basic 7 (헤임달·무적 x3·강화된 신체 x3) + 코어 3
      'heimdall',
      'invulnerability','invulnerability','invulnerability',
      'enhanced-physique','enhanced-physique','enhanced-physique',
      'energy','strength','tenacity',
    ],
  },
  blackWidow: {
    hero: '08001a', name: '블랙위도우 / 정의(Justice)',
    cards: [
      // 시그니처 15 — 나타샤: Widowmaker(준비 발동 시 적 피해) + Preparation 엔진
      'winter-soldier-bw',
      'covert-ops','covert-ops',
      'dance-of-death','dance-of-death',
      'safe-house-29',
      'attacrobatics','attacrobatics',
      'bw-gauntlet','bw-gauntlet',
      'grappling-hook','grappling-hook',
      'synth-suit',
      'widows-bite','widows-bite',
      // 정의(Justice) 15 — 블랙위도우 팩 11 + 코어 4
      'agent-coulson','quake',
      'stealth-strike','stealth-strike','stealth-strike',
      'counterintelligence','counterintelligence','counterintelligence',
      'spycraft','spycraft','spycraft',
      'power-of-justice','power-of-justice','for-justice','for-justice',
      // 기본 10 — 블랙위도우 팩 basic 7 (퀸캐리어·목표포착 x3·첩보 x3) + 코어 3
      'quincarrier',
      'target-acquired','target-acquired','target-acquired',
      'espionage','espionage','espionage',
      'energy','genius','strength',
    ],
  },
  'doctor-strange': {
    hero: '09001a', name: '닥터 스트레인지 / 보호',
    cards: [
      // 시그니처 15 (Invocation 덱은 셋업 시 별도 구성)
      'wong','astral-projection','astral-projection','magic-blast','magic-blast',
      'master-of-mystic-arts','master-of-mystic-arts','mystical-studies','protective-ward','protective-ward',
      'sanctum-sanctorum-ds','cloak-of-levitation','magical-enhancements','magical-enhancements','eye-of-agamotto',
      // 보호(Protection) 17
      'brother-voodoo','clea','iron-fist','desperate-defense','desperate-defense','desperate-defense',
      'momentum-shift','momentum-shift','momentum-shift','night-nurse','unflappable','unflappable','unflappable',
      'power-of-protection','power-of-protection','med-team','med-team',
      // 기본 8 — DS 팩 basic(경고 x3·소서러슈프림) + 코어 4
      'warning','warning','warning','sorcerer-supreme',
      'energy','genius','strength','avengers-mansion',
    ],
  },
  'hulk': {
    hero: '10001a', name: '헐크 / 어그레션',
    cards: [
      // 시그니처 15
      'crushing-blow','crushing-blow','hulk-smash','hulk-smash','sub-orbital-leap','sub-orbital-leap',
      'thunderclap','thunderclap','unstoppable-force','unstoppable-force','limitless-strength','limitless-strength',
      'banners-laboratory','boundless-rage','immovable-object',
      // 어그레션(Aggression) 15
      'brawn','sentry','she-hulk-ally','drop-kick','drop-kick','drop-kick',
      'toe-to-toe','toe-to-toe','toe-to-toe','youll-pay-for-that','youll-pay-for-that','youll-pay-for-that',
      'martial-prowess','martial-prowess','martial-prowess',
      // 기본 10 — 헐크 팩 basic(구조하러간다 x3·임기응변 x3) + 코어 4
      'to-the-rescue','to-the-rescue','to-the-rescue','resourceful','resourceful','resourceful',
      'energy','genius','strength','avengers-mansion',
    ],
  },
};

})(typeof window !== 'undefined' ? window : globalThis);
