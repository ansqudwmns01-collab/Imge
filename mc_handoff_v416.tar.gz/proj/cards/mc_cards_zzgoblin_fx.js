/* ═══════════════════════════════════════════════════════════════
   MVC02 그린 고블린 — Risky Business 폼전환 엔진 (카운터 + 플립 인프라)
   빌런: 노먼 오스본(a면) ↔ 그린 고블린(b면). 환경: Criminal Enterprise(악명)
     ↔ State of Madness(광기). 양면 카드처럼 빌런·환경이 함께 뒤집힌다.

   ★ 이 파일 = 폼전환 코어 인프라 (02006a Criminal Enterprise / 02006b State of Madness).
     - goblinActiveEnv : 현재 활성 플립 환경(악명/광기)을 찾음
     - goblinAddCounter/goblinRemoveCounter : 카운터 조작 (0 도달 시 자동 플립)
     - goblinFlip : 빌런 defCode 교체 + 환경 교체 + 새 면 카운터 리셋 + 새 빌런 WR 발화
       (빌런 인스턴스는 유지되므로 HP·피해·부착·부스트·상태 전부 보존 — 룰북 준수)
     - goblinRiskyBusinessSetup : 셋업 시 Criminal Enterprise 배치(악명 2×히어로)

   ★ 개별 카드 배선(다음 단계)은 이 프리미티브를 호출:
     노먼 공격→goblinAddCounter / 노먼 피해→goblinRemoveCounter /
     고블린 스킴→goblinRemoveCounter / 하수인·사이드스킴·배신 부스트→add/remove.
   자원/스탯 출처: zzorba gob_encounter.json (authoritative).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 플립 환경 메타데이터 (인덱스식 로컬 상수 — baseFields 오염 없음).
   per = 활성화 시 배치되는 카운터 수(×히어로). alt = 뒤집힌 반대면 환경. */
const GOBLIN_ENV = {
  'criminal-enterprise': { counterType:'infamy',  label:'악명', per:2, alt:'state-of-madness'  },
  'state-of-madness':    { counterType:'madness', label:'광기', per:2, alt:'criminal-enterprise' },
};
MC.GOBLIN_ENV = GOBLIN_ENV;

/* 현재 전장의 활성 플립 환경(악명/광기 중 하나)을 반환. 없으면 null. */
MC.goblinActiveEnv = function(G){
  return (G.environments || []).find(e => GOBLIN_ENV[e.defCode]) || null;
};

/* 활성 플립 환경에 카운터 N개 배치 (노먼 공격 / 하수인 부스트 등).
   카운터가 늘어나는 방향이라 플립은 발생하지 않는다. */
MC.goblinAddCounter = function(G, n){
  const env = MC.goblinActiveEnv(G);
  if (!env || !n) return 0;
  const meta = GOBLIN_ENV[env.defCode];
  env.counters = (env.counters || 0) + n;
  MC.log(G, MC.nameOf(env) + ' — ' + meta.label + ' 카운터 +' + n + ' (현재 ' + env.counters + ')');
  return env.counters;
};

/* 활성 플립 환경에서 카운터 N개 제거 (노먼 피해 / 고블린 스킴 등).
   0 이하가 되면 → 빌런·환경 플립. 실제 제거량을 반환.
   ※ "제거할 수 없으면 반대편 카운터 제거"(공유 메커니즘)는 개별 카드 쪽에서
     addToOther 옵션으로 처리 — 여기선 활성 환경 카운터만 다룬다. */
MC.goblinRemoveCounter = function(G, n){
  const env = MC.goblinActiveEnv(G);
  if (!env || !n) return 0;
  const meta = GOBLIN_ENV[env.defCode];
  const had = env.counters || 0;
  const removed = Math.min(had, n);
  env.counters = had - removed;
  MC.log(G, MC.nameOf(env) + ' — ' + meta.label + ' 카운터 -' + removed + ' (현재 ' + env.counters + ')');
  if (env.counters <= 0) MC.goblinFlip(G, 'counterEmpty');
  return removed;
};

/* 활성 플립 환경에 카운터가 하나도 없는지 (개별 카드가 "배치 불가" 판정에 사용). */
MC.goblinCanAddCounter = function(G){
  const env = MC.goblinActiveEnv(G);
  return !!env;   // 활성 환경이 있으면 항상 배치 가능 (상한 없음)
};

/* ── 폼전환 코어 ──
   빌런 인스턴스(G.villain)는 유지하고 defCode만 반대면으로 교체 → HP·피해·부착·
   부스트·상태 전부 보존. 활성 환경도 반대면으로 교체하고 새 면 카운터를 배치한다.
   룰북: "폼전환은 그린 고블린의 When Revealed를 발동한다" → 새 빌런 면의 whenRevealed 발화. */
MC.goblinFlip = function(G, reason){
  const v = G.villain;
  if (!v) return;
  const vdef = MC.cardDef(v.defCode);
  const newCode = vdef && vdef.altForm;
  if (!newCode){ MC.log(G, '[goblinFlip] altForm 없음: ' + (v.defCode||'?')); return; }

  const fromName = MC.nameOf(v);
  const oldCode = v.defCode;
  // 1) 빌런 면 교체 (인스턴스 유지 = HP/피해/부착/부스트/상태 보존)
  v.defCode = newCode;
  const newVdef = MC.cardDef(newCode);
  // maxHp는 양 면 동일(hpPerPlayer 같음) — 재계산 불필요, 현재 HP 그대로 유지

  // 2) 활성 환경 교체 + 새 면 카운터 배치
  const env = MC.goblinActiveEnv(G);
  if (env){
    const meta = GOBLIN_ENV[env.defCode];
    const altMeta = GOBLIN_ENV[meta.alt];
    env.defCode = meta.alt;
    env.counters = altMeta.per * G.players.length;
    MC.log(G, '환경 전환 → ' + MC.nameOf(env) + ' (' + altMeta.label + ' 카운터 ' + env.counters + ')');
  }

  MC.log(G, '★ 빌런 폼 전환: ' + fromName + ' → ' + MC.nameOf(v));

  // 3) 폼 전환 변신 연출 힌트 (UI가 goblinTransform 재생 — 노먼↔고블린 변신).
  //    새 면 등장 대사도 함께 실어 UI가 변신 후 말풍선으로 표시.
  const toGoblin = (newVdef && newVdef.form === 'goblin');
  const quote = (MC.randomQuote && newVdef.quoteKey) ? MC.randomQuote(newVdef.quoteKey, 'entrance') : null;
  G.fxGoblinFlip = { fromCode: oldCode, toCode: newCode,
    dir: toGoblin ? 'toGoblin' : 'toNorman', quote,
    seq: (G.fxSeq = (G.fxSeq || 0) + 1) };

  // 4) 새 빌런 면의 When Revealed 발화 (룰북: 폼전환이 GG의 WR 트리거)
  if (newVdef && newVdef.whenRevealed && MC.HANDLERS[newVdef.whenRevealed]){
    MC.HANDLERS[newVdef.whenRevealed](G, { villain:v, self:v, card:v,
      hook:'whenRevealed', cause:'flip', player: G.players[0] });
  }
};

/* ── 셋업: Criminal Enterprise 환경 배치 (악명 2×히어로) ──
   메인 스킴 1B(02004b) def.onSetup 로 발화. 빌런은 villainStart=02001a(노먼)로 시작. */
MC.HANDLERS.goblinRiskyBusinessSetup = function(G, ctx){
  G.environments = G.environments || [];
  if (!G.environments.some(e => GOBLIN_ENV[e.defCode])){
    const env = MC.makeInstance(G, 'criminal-enterprise', {});
    env.counters = GOBLIN_ENV['criminal-enterprise'].per * G.players.length;   // 악명 2×히어로
    G.environments.push(env);
    MC.log(G, 'Risky Business 셋업 — Criminal Enterprise 배치 (악명 카운터 ' + env.counters + ')');
  }
};

/* 메인 스킴 1B(02004b)에 셋업 훅 부착 + todoFx 해제 (진행면 효과는 다음 단계) */
MC.defineCardFx('02004b', { onSetup: 'goblinRiskyBusinessSetup' });

/* ── 노먼 오스본 (a면) 3스테이지 — attackToCounter + damageToCounter (인덱스식) ──
   공격→악명+N (실공격 안함), 피해→악명 제거 (본체 무피해). amount만 스테이지별로 다름.
   엔진 중앙 처리: enemyActivation(attackToCounter) + applyDamage(damageToCounter). */
MC.defineCardFx('02001a', { attackToCounter:{ amount:1 }, damageToCounter:true });
MC.defineCardFx('02002a', { attackToCounter:{ amount:2 }, damageToCounter:true });
MC.defineCardFx('02003a', { attackToCounter:{ amount:3 }, damageToCounter:true });

/* ── 그린 고블린 (b면) 3스테이지 — schemeToCounter + When Revealed(플립 시 발화) ──
   스킴→광기-N (실스킴 안함). WR은 goblinFlip이 발화(룰북: 폼전환이 GG WR 트리거).
   WR 피해는 damageEachHero 인덱스 재사용(heroForm/indirect 파라미터).
   I  : 히어로 폼 각 플레이어 간접 3 · 스킴→광기-1
   II : 각 플레이어 간접 3 · 스킴→광기-1
   III: 각 플레이어 피해 4 · 스킴→광기-2 */
MC.defineCardFx('02001b', {
  schemeToCounter:{ amount:1 },
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'damageEachHero', amount:3, heroForm:true, indirect:true }],
});
MC.defineCardFx('02002b', {
  schemeToCounter:{ amount:1 },
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'damageEachHero', amount:3, indirect:true }],
});
MC.defineCardFx('02003b', {
  schemeToCounter:{ amount:2 },
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'damageEachHero', amount:4 }],
});

/* ── 공유 메커니즘: "악명 카운터 배치 / 불가 시 광기 제거" ──
   룰북: "Place N infamy on Criminal Enterprise. If you cannot, remove N madness from State of Madness."
   "배치 불가" = Criminal Enterprise가 전장에 없을 때(= State of Madness 활성 = 고블린 면).
   → 노먼 면: 악명 +N (goblinAddCounter) / 고블린 면: 광기 -N (goblinRemoveCounter, 0시 역플립).
   하수인·사이드스킴·배신 다수가 공유. 인덱스식 EFFECT 하나로 수렴. */
MC.goblinInfamyOrMadness = function(G, n){
  n = n || 1;
  const env = MC.goblinActiveEnv(G);
  if (!env) return;
  if (env.defCode === 'criminal-enterprise') MC.goblinAddCounter(G, n);   // 악명 배치(노먼 면)
  else MC.goblinRemoveCounter(G, n);                                      // 광기 제거(고블린 면)
};
MC.EFFECTS.goblinCounter = function(G, p, ctx){
  MC.goblinInfamyOrMadness(G, (p && p.amount) || 1);
};

/* 부스트★: 악명+1 / 불가 시 광기-1 (하수인·사이드스킴·배신 공유) — 인덱스식 데이터 */
const BOOST_STAR_INFAMY = { boostStarEffects: [{ fx:'goblinCounter', amount:1 }] };
MC.defineCardFx('hired-gun', BOOST_STAR_INFAMY);                    // 02007 (WR 선택은 후속)
MC.defineCardFx('private-security-specialist', BOOST_STAR_INFAMY);  // 02008 (Guard 기존)
MC.defineCardFx('collapsing-bridge', BOOST_STAR_INFAMY);           // 02009
MC.defineCardFx('payoff', BOOST_STAR_INFAMY);                      // 02011
/* 02012 All in a Day's Work — WR: 악명+2(불가 시 광기-2) + 부스트★: 악명+1 */
MC.defineCardFx('all-in-a-days-work', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'goblinCounter', amount:2 }],
  boostStarEffects:[{ fx:'goblinCounter', amount:1 }],
});

/* ── 폼 조건부 유틸 + 추가 인덱스 (02004b/02005a/02010/02013용) ── */
/* 현재 빌런 면('norman'|'goblin') */
MC.goblinVillainForm = function(G){
  const d = G.villain && MC.cardDef(G.villain.defCode);
  return (d && d.form) || null;
};
/* Criminal Enterprise 활성 시 악명 카운터 수, 아니면 0 */
MC.goblinInfamyCount = function(G){
  const env = MC.goblinActiveEnv(G);
  return (env && env.defCode === 'criminal-enterprise') ? (env.counters || 0) : 0;
};

/* goblinCounter perHero 확장: perHero=true면 amount×히어로수 */
const _goblinCounterBase = MC.EFFECTS.goblinCounter;
MC.EFFECTS.goblinCounter = function(G, p, ctx){
  const n = ((p && p.amount) || 1) * (p && p.perHero ? G.players.length : 1);
  MC.goblinInfamyOrMadness(G, n);
};

/* 메인 스킴 즉시 전진 (02005a 2A: "공개 시 2B로 진행") */
MC.EFFECTS.advanceMainSchemeNow = function(G, p, ctx){ MC.advanceMainScheme(G); };

/* 이 사이드 스킴에 위협 배치 (02010 오스코프: 노먼 면 +1/히어로 · 02026 고블린 증원: 고블린 하수인 수만큼) */
MC.EFFECTS.threatHere = function(G, p, ctx){
  let amt;
  if (p && p.amountFrom === 'goblinMinions') amt = MC.goblinMinionCount ? MC.goblinMinionCount(G) : 0;
  else amt = ((p && p.amount) || 1) * (p && p.perHero ? G.players.length : 1);
  if (ctx.self && amt > 0){
    ctx.self.threat = (ctx.self.threat || 0) + amt;
    MC.log(G, MC.nameOf(ctx.self) + ' — 위협 +' + amt + ' (현재 ' + ctx.self.threat + ')');
  } else if (ctx.self){
    MC.log(G, MC.nameOf(ctx.self) + ' — 추가 위협 0');
  }
};

/* 각 플레이어(또는 활성)가 악명 카운터 수만큼 덱 맨 위 버림 (02004b 완료 / 02013 노먼 WR) */
MC.EFFECTS.goblinDiscardPerInfamy = function(G, p, ctx){
  const n = MC.goblinInfamyCount(G);
  if (n <= 0){ MC.log(G, '(악명 카운터 0 — 덱 버림 없음)'); return; }
  const players = (p && p.scope === 'eachPlayer')
    ? MC.playersInOrder(G).filter(pl => !pl.eliminated)
    : [ctx.player || G.players[G.firstPlayer]];
  for (const pl of players) MC.discardTopOfDeck(G, pl, n);
};

/* 빌런이 남은 HP 최소 히어로를 공격 (02013 고블린 WR). 대상 없으면 이 카드 surge. */
MC.EFFECTS.villainAttacksFewestHp = function(G, p, ctx){
  const heroes = MC.playersInOrder(G).filter(pl => !pl.eliminated && pl.form === 'hero');
  if (!heroes.length){
    if (ctx.self) ctx.self.surge = true;
    MC.log(G, '그린 고블린 — 공격 대상(히어로) 없음 → 이 카드 surge');
    return;
  }
  let target = heroes[0];
  for (const pl of heroes) if ((pl.hp || 0) < (target.hp || 0)) target = pl;
  MC.EFFECTS.villainAttacks(G, {}, { player: target });
};

/* 폼 조건부 When Revealed — def.whenRevealedByForm[현재 면] 실행 (02010/02013).
   룰북 "When Revealed (Norman Osborn)" / "(Green Goblin)" 패턴을 인덱스로. */
MC.HANDLERS.goblinFormReveal = function(G, ctx){
  const self = ctx.self;
  const def = (self && self.defCode && MC.cardDef(self.defCode)) || self;
  const form = MC.goblinVillainForm(G);
  const list = def && def.whenRevealedByForm && def.whenRevealedByForm[form];
  if (!list){ MC.log(G, MC.nameOf(self) + ' — 현재 면(' + form + ') 공개 효과 없음'); return; }
  MC.runEffectList(G, list, { player: ctx.player, card: self, self });
};

/* ── 메인 스킴 진행 효과 ── */
/* 02004b 적대적 인수 1B — 완료 시: 악명 1/히어로 배치 → 악명 수만큼 각 플레이어 덱 버림 */
MC.defineCardFx('02004b', {
  onSetup: 'goblinRiskyBusinessSetup',
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [
    { fx:'goblinCounter', amount:1, perHero:true },
    { fx:'goblinDiscardPerInfamy', scope:'eachPlayer' },
  ],
});
/* 02005a 기업 인수합병 2A — 공개 시 즉시 2B로 진행 */
MC.defineCardFx('02005a', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'advanceMainSchemeNow' }],
});
/* 02005b 기업 인수합병 2B — nextStage 없음 → 완료 시 onMainSchemeThreshold가 자동 패배 처리 (별도 배선 불필요) */

/* ── 남은 조우 카드 ── */
/* 02007 Hired Gun — WR: (선택) 악명+2 배치 [부스트 부여 대안은 카운터 분기로 통일] */
MC.defineCardFx('hired-gun', {
  boostStarEffects: [{ fx:'goblinCounter', amount:1 }],
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'goblinCounter', amount:2 }],
});
/* 02010 Oscorp Manufacturing — WR(노먼): 이 스킴에 +1/히어로 위협 */
MC.defineCardFx('oscorp-manufacturing', {
  whenRevealed:'goblinFormReveal',
  whenRevealedByForm:{ norman:[{ fx:'threatHere', amount:1, perHero:true }] },
});
/* 02013 Mad Genius — WR(고블린): 최소HP 히어로 공격, 없으면 surge / WR(노먼): 악명당 덱 버림 */
MC.defineCardFx('mad-genius', {
  whenRevealed:'goblinFormReveal',
  whenRevealedByForm:{
    goblin:[{ fx:'villainAttacksFewestHp' }],
    norman:[{ fx:'goblinDiscardPerInfamy' }],
  },
});

})(typeof window !== 'undefined' ? window : globalThis);
