/* ═══════════════════════════════════════════════════════════════
   표준 인카운터 세트 (Standard Encounter Set) — Core Set #186~187 등
   모든 코어 시나리오에 공통으로 섞이는 표준 조우 카드.
   구성(발췌): Advance(배신 ×2), Assault(배신 ×2) 등

   01186 Advance — 배신 ×2
     · 공개 시: 빌런이 암약한다(메인 스킴에 빌런 SCH만큼 위협).
   01187 Assault — 배신 ×2
     · 공개 시(알터에고): 이 카드는 급증(Surge)을 얻는다.
     · 공개 시(히어로): 빌런이 당신을 공격한다.
   ★ 엔진: villainSchemes / villainAttacks (기존) + isHeroForm/isAlterEgoForm 조건.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* Advance(01186) — 배신. 빌런이 암약. */
MC.defineCardFx('advance', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'villainSchemes', scheme: 'main' },
    { fx: 'playVfx', vfx: 'advanceReveal', quoteKey: 'advance', quoteKind: 'reveal' },
  ],
  quoteKey: 'advance', vfx: { attack: 'advanceReveal' }, copies: 2,
  textKo: '배신 — Treachery. ×2.\n\n공개 시: 빌런이 암약한다. (메인 스킴에 빌런의 SCH 값만큼 위협을 놓는다.)\n\n*"빌런의 계획이 한 걸음 더 나아간다 — 위협이 커지고 있어!"*\n\n※ 공식 01186 Advance (Core Set #186, 표준 인카운터 세트, ×2) — 공식 JSON 교차검증\n※ 메인 스킴 위협 가속 · 알터에고 방치 시 위협 관리 부담',
});

/* Assault(01187) — 배신. 알터에고=급증 / 히어로=빌런 공격. */
MC.defineCardFx('assault', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'surge', cond: { type: 'isAlterEgoForm' } },
    { fx: 'villainAttacks', cond: { type: 'isHeroForm' } },
    { fx: 'playVfx', vfx: 'assaultReveal', quoteKey: 'assault', quoteKind: 'reveal' },
  ],
  quoteKey: 'assault', vfx: { attack: 'assaultReveal' }, copies: 2,
  textKo: '배신 — Treachery. ×2.\n\n공개 시(알터에고): 이 카드는 급증(Surge)을 얻는다.\n공개 시(히어로): 빌런이 당신을 공격한다.\n\n*"빌런이 기회를 노린다 — 히어로 폼일 때 정면으로 덮친다!"*\n\n※ 공식 01187 Assault (Core Set #187, 표준 인카운터 세트, ×2) — 공식 JSON 교차검증\n※ 히어로 폼이면 즉시 공격 · 알터에고면 추가 조우로 전환',
});

/* Caught Off Guard(01188) — 배신. 업그레이드/지원 1장 버림, 없으면 급증. */
MC.defineCardFx('caught-off-guard', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'discardUpgradeOrSupport' },
    { fx: 'playVfx', vfx: 'caughtOffGuardReveal', quoteKey: 'caught-off-guard', quoteKind: 'reveal' },
    { fx: 'surge', cond: { type: 'discardedUpgradeOrSupportNone' } },
  ],
  quoteKey: 'caught-off-guard', vfx: { attack: 'caughtOffGuardReveal' },
  textKo: '배신 — Treachery. 부스트 ▲1.\n\n공개 시: 당신이 조종하는 업그레이드(Upgrade) 또는 지원(Support) 1장을 버린다. 이렇게 버려진 카드가 없으면 → 이 카드는 급증(Surge)을 얻는다.\n\n영구(Permanent)나 부착물(Attached)은 선택할 수 없다.\n\n*"방심한 순간을 노렸다 — 네 장비 하나가 부서진다!"*\n\n※ 공식 01188 Caught Off Guard (Core Set #188, 표준 인카운터 세트, ×1) — 공식 JSON 교차검증\n※ 장비 손실 · 장비 없으면 급증으로 추가 조우',
});

/* Gang-Up(01189) — 배신. 알터에고=급증 / 히어로=빌런+교전 하수인 전원 공격. */
MC.defineCardFx('gang-up', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'surge', cond: { type: 'isAlterEgoForm' } },
    { fx: 'playVfx', vfx: 'gangUpReveal', quoteKey: 'gang-up', quoteKind: 'reveal', cond: { type: 'isHeroForm' } },
    { fx: 'villainAndMinionsAttack', cond: { type: 'isHeroForm' } },
  ],
  quoteKey: 'gang-up', vfx: { attack: 'gangUpReveal' },
  textKo: '배신 — Treachery. 부스트 ▲1.\n\n공개 시(알터에고): 이 카드는 급증(Surge)을 얻는다.\n공개 시(히어로): 빌런과 당신과 교전 중인 각 하수인이 당신을 공격한다.\n\n*"놈들이 한꺼번에 덮친다 — 사방에서 공격이 쏟아진다!"*\n\n※ 공식 01189 Gang-Up (Core Set #189, 표준 인카운터 세트, ×1) — 공식 JSON 교차검증\n※ 히어로 폼 + 다수 하수인 = 치명적 · 알터에고면 급증만(더 안전) · 재발행 02039',
});

/* Shadow of the Past(01190) — 배신. 자신의 넴시스 세트를 전장/조우덱에 투입. 하수인 미등장 시 급증. */
MC.defineCardFx('shadow-of-the-past', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'revealNemesisSet' },
    { fx: 'playVfx', vfx: 'shadowOfThePastReveal', quoteKey: 'shadow-of-the-past', quoteKind: 'reveal' },
    { fx: 'surge', cond: { type: 'nemesisMinionNotEntered' } },
  ],
  quoteKey: 'shadow-of-the-past', vfx: { attack: 'shadowOfThePastReveal' },
  textKo: '배신 — Treachery. 부스트 ▲2.\n\n공개 시: 셋어사이드된 자신의 넴시스 하수인을 공개하여 자신과 교전한 상태로 전장에 놓는다. 셋어사이드된 자신의 넴시스 사이드 스킴을 공개하여 전장에 놓는다. 나머지 셋어사이드된 넴시스 조우 세트를 조우덱에 섞는다. 이렇게 넴시스 하수인이 등장하지 않았다면, 이 카드는 급증(Surge)을 얻는다.\n\n*"과거의 그림자가 되살아난다 — 네 숙적이 다시 나타났어!"*\n\n※ 공식 01190 Shadow of the Past (Core Set #190, 표준 인카운터 세트, ×1) — 공식 JSON 교차검증\n※ 영웅별 넴시스 세트를 게임에 투입 (블랙팬서=킬몽거, 아이언맨=위플래시 등) · 이미 하수인 전장 시 급증',
});

/* Exhaustion(01191) — 배신. 급증 + 공개 시 신분 카드 소진. */
MC.defineCardFx('exhaustion', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'exhaustIdentity' },
    { fx: 'playVfx', vfx: 'exhaustionReveal', quoteKey: 'exhaustion', quoteKind: 'reveal' },
    { fx: 'surge' },
  ],
  quoteKey: 'exhaustion', vfx: { attack: 'exhaustionReveal' },
  textKo: '배신 — Treachery. 부스트 ▲2.\n\n급증(Surge).\n공개 시: 자신의 정체성 카드(히어로 또는 알터에고)를 소진(exhaust)한다.\n\n*"몸이 천근만근이다… 지금은 움직일 수 없어."*\n\n※ 공식 01191 Exhaustion (Core Set #191, 표준 인카운터 세트) — 공식 JSON 교차검증\n※ 소진된 신분은 이번 라운드에 능력·기본 행동 사용 불가 · Surge로 조우 카드 1장 추가 공개',
});

/* Masterplan(01192) — 배신. 각 사이드 스킴에 위협 4, 없으면 조우덱에서 사이드 스킴 탐색·공개. */
MC.defineCardFx('masterplan', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'placeThreat', amount: 4, scheme: 'eachSide', cond: { type: 'anySideSchemeInPlay' } },
    { fx: 'discardUntilSideScheme', cond: { type: 'noSideSchemesInPlay' } },
    { fx: 'playVfx', vfx: 'masterplanReveal', quoteKey: 'masterplan', quoteKind: 'reveal' },
  ],
  quoteKey: 'masterplan', vfx: { attack: 'masterplanReveal' },
  textKo: '배신 — Treachery. 부스트 ▲2.\n\n공개 시: 각 사이드 스킴에 위협 4를 놓는다. 전장에 사이드 스킴이 없다면, 사이드 스킴이 버려질 때까지 조우덱 맨 위 카드를 버린 뒤 그 사이드 스킴을 공개한다.\n\n*"모든 것이 계획대로다 — 판이 무르익어 간다."*\n\n※ 공식 01192 Masterplan (Core Set #192, 표준 인카운터 세트) — 공식 JSON 교차검증\n※ 사이드 스킴 있음 → 각각 위협 4 · 없음 → 조우덱에서 사이드 스킴 찾아 전장 공개',
});

/* 05013 Rapid Response — leadership 업그레이드. 동료 처치 후 되살림 반응. */
MC.defineCardFx('rapid-response', {
  rapidResponse: true,
  vfx: { play:'rapidResponsePlace' },
});

/* 05014 Preemptive Strike — protection 방어 이벤트. 부스트 카드 취소 + 취소 아이콘당 빌런 1피해. */
MC.defineCardFx('preemptive-strike', {
  special: 'preemptiveStrike',
  defenseInterruptEvent: true,
  vfx: { event:'preemptiveStrike' },
});

/* 05017 Energy Barrier — protection 업그레이드. 반영 카운터 3. 난입: 피해 받을 때 카운터1 → 피해1 방지 + 적1피해. */
MC.defineCardFx('energy-barrier', {
  uses: 3,
  defenseInterrupt: { prevent:1, counter:1, damageEnemy:1, vfx:'energyBarrier' },
  vfx: { play:'energyBarrierPlace' },
});

/* 05023 Endurance — basic 업그레이드(condition, attachTarget:hero). HP +3(현재+최대).
   hpBonus 인덱스 재사용(recomputeMaxHp가 현재+최대 델타 조정, 제거 시 초과분만 감소).
   설치 직후 recompute는 mk5-armor와 동일하게 whenPlayed refreshMaxHp로. 신규 코드 0줄. */
MC.defineCardFx('endurance', {
  hpBonus: 3,
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'refreshMaxHp' }],
  vfx: { install:'enduranceInstall' },
});

/* 05024 Enhanced Reflexes — basic 업그레이드(condition, uses 3). 히어로 자원: 소진+에너지 카운터1 제거 → ⚡1 생성(히어로폼 전용).
   web-shooter(uses+resourceGenerator{form:'hero',exhaust,counter}) 인덱스 100% 재사용, 아이콘만 wild→energy. 신규 코드 0줄. */
MC.defineCardFx('enhanced-reflexes', {
  uses: 3,
  resourceGenerator: { form:'hero', exhaust:true, counter:1, icons:{ energy:1 } },
  vfx: { install:'reflexInstall' },
});

/* 05031 Concussive Blow — justice 공격 이벤트. 적 1명 혼란 + 💪피지컬 지불 시 3 피해.
   tackle(applyStatus + dealDamageIfPaid) 인덱스 100% 재사용, status만 stunned→confused. 신규 코드 0줄. */
MC.defineCardFx('concussive-blow', {
  effects: [
    { fx:'applyStatus', target:'chosen', status:'confused' },
    { fx:'dealDamageIfPaid', target:'chosen', resource:'physical', amount:3 },
  ],
  vfx: { basicAttack:'concussiveBlow' },
});

/* 05033 Down Time — basic 업그레이드(condition, attachTarget:hero). 알터에고 REC +2(영구).
   statMod{stat:'recover'} → passiveStatMod 인덱스 100% 재사용(combat-training ATK+1 동일 패턴).
   회복 액션이 statOf(recover)를 쓰므로 자동 +2. 신규 코드 0줄. */
MC.defineCardFx('down-time', {
  statMod: { stat:'recover', amount:2 },
  vfx: { install:'downtimeInstall' },
});

})(typeof window !== 'undefined' ? window : globalThis);
