/* ═══════════════════════════════════════════════════════════════
   mc_cards_seed.js — 신분/빌런/메인스킴 (인덱스 JSON에 없는 카드들)
   데이터 출처: zzorba core.json / core_encounter.json (authoritative)
   플레이어/조우 카드는 마이그레이션 DB(슬러그 키)를 사용 — 여기 두지 않는다.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 신분 카드는 mc_cards_identities.js(생성기)가 전량 담당 — 여기엔 빌런/스킴만 */
MC.registerCards({
  '01094': { code:'01094', side:'encounter', type:'villain', name:'라이노', nameEn:'Rhino',
    stage:1, hpPerPlayer:14, attack:2, scheme:1, nextStage:'01095',
    vfx:{ entrance:'wallBreak', enemyAttack:'headbutt', defeat:'rhinoCollapse' }, quoteKey:'rhino' , textKo:'"난 라이노다. 난 부순다. 그게 내가 하는 일이고, 그게 나야."' }, // 파괴 등장·박치기·갑옷 붕괴
  '01095': { code:'01095', side:'encounter', type:'villain', name:'라이노', nameEn:'Rhino',
    stage:2, hpPerPlayer:15, attack:3, scheme:1, nextStage:'01096',
    vfx:{ enemyAttack:'headbutt', stageChange:'rhinoRampage', defeat:'rhinoCollapse' }, quoteKey:'rhino' , textKo:'공개 시: 조우 덱과 버린 더미에서 "부수고 빼앗기" 사이드 스킴을 찾아 공개한다. 그 후 조우 덱을 섞는다.\n\n"비켜!"' },
  '01096': { code:'01096', side:'encounter', type:'villain', name:'라이노', nameEn:'Rhino',
    stage:3, hpPerPlayer:16, attack:4, scheme:1,
    vfx:{ enemyAttack:'headbutt', stageChange:'rhinoRampage', defeat:'rhinoCollapse' }, quoteKey:'rhino' , textKo:'강인함(Toughness): 이 캐릭터는 강인 상태 카드를 가지고 등장한다.\n\n공개 시: 각 히어로를 기절시킨다.\n\n"네가 자초한 일이야!"' },
  /* 클로(Klaw) 3단계 — Core Set #113~115. Ulysses Klaw, 음파 무기 밀매업자.
     공통: 강제 난입 — 공격 시 부스트 카드 1장 추가 (villainAttackExtraBoost:1).
     I  (01113): ATK0/SCH2/HP12×히어로.
     II (01114): ATK1/SCH2/HP18×히어로. 공개 시 "불멸의 클로" 사이드 스킴 공개 + 조우덱 셔플.
     III(01115): ATK2/SCH3/HP22×히어로. Toughness(등장 시 tough). */
  '01113': { code:'01113', side:'encounter', type:'villain', name:'클로', nameEn:'Klaw',
    stage:1, hpPerPlayer:12, attack:0, scheme:2, nextStage:'01114', unique:true,
    traits:['masters of evil'], villainAttackExtraBoost:1,
    vfx:{ entrance:'sonicEmerge', enemyAttack:'sonicBlast', stageChange:'sonicSurge', defeat:'sonicShatter' }, quoteKey:'klaw' , textKo:'★ 강제 개입: 클로가 공격할 때, 이 활성화에 부스트 카드 1장을 추가로 준다.\n\n"네 파멸을 맞이하러 와라!"' },
  '01114': { code:'01114', side:'encounter', type:'villain', name:'클로', nameEn:'Klaw',
    stage:2, hpPerPlayer:18, attack:1, scheme:2, nextStage:'01115', unique:true,
    traits:['masters of evil'], villainAttackExtraBoost:1, whenRevealed:'klawStage2Reveal',
    vfx:{ enemyAttack:'sonicBlast', stageChange:'sonicSurge', defeat:'sonicShatter' }, quoteKey:'klaw' , textKo:'공개 시: 조우 덱과 버린 더미에서 "불멸의" 클로를 찾아 공개한다. 그 후 조우 덱을 섞는다.\n\n★ 강제 개입: 클로가 공격할 때, 이 활성화에 부스트 카드 1장을 추가로 준다.' },
  '01115': { code:'01115', side:'encounter', type:'villain', name:'클로', nameEn:'Klaw',
    stage:3, hpPerPlayer:22, attack:2, scheme:3, unique:true,
    traits:['masters of evil'], villainAttackExtraBoost:1, whenRevealed:'klawStage3Reveal',
    vfx:{ enemyAttack:'sonicBlast', stageChange:'sonicSurge', defeat:'sonicShatter' }, quoteKey:'klaw' , textKo:'강인함(Toughness): 강인 상태 카드를 가지고 등장한다.\n\n★ 강제 개입: 클로가 공격할 때, 이 활성화에 부스트 카드 1장을 추가로 준다.' },
  /* 메인 스킴 양면: 1A = 셋업 지시면 / 1B = 진행면 (한글 텍스트 포함) */
  '01097a': { code:'01097a', side:'encounter', type:'main_scheme', name:'침입!', nameEn:'The Break-In!',
    stage:'1A',
    textKo:'셋업: 조우덱을 셔플한다. 라이노는 1단계로 등장한다.\n메인 스킴은 위협 0으로 시작한다.\n\n준비가 끝나면 1B면으로 뒤집는다.' },
  '01097b': { code:'01097b', side:'encounter', type:'main_scheme', name:'침입!', nameEn:'The Break-In!',
    stage:'1B', baseThreat:0, maxThreatPerPlayer:7, accelIcons:1,
    textKo:'라이노가 도시를 헤집으며 은행 금고를 노린다!\n\n가속 ⚡1: 빌런 페이즈마다 위협이 (플레이어 수 + 1)만큼 쌓인다.\n\n위협이 한도(플레이어당 7)에 도달하면 — 플레이어 전원 패배.' },
  /* ── 클로 메인 스킴 (Core Set #116~117) — 공식 core_encounter.json 교차검증 ──
     01116 지하 유통망: 1A 셋업 = "방어망(01125)" 사이드 스킴 탐색·공개 + 조우덱 셔플.
       1B 공개 시 = 조우덱에서 하수인이 나올 때까지 버림 → 첫 플레이어와 교전 배치.
       한도 6/인 · 가속 ⚡1.
     01117 비밀 회합: 2A 공개 시 = 동일 하수인 배치 → 2B 진행. 2B 한도 8/인 · ⚡1.
       2B 완성 시 플레이어 전원 패배. */
  '01116a': { code:'01116a', side:'encounter', type:'main_scheme', name:'지하 유통망', nameEn:'Underground Distribution',
    stage:'1A',
    textKo:'셋업: 조우덱에서 "방어망" 사이드 스킴을 찾아 공개한다. 조우덱을 셔플한다.\n\n준비가 끝나면 1B면으로 뒤집는다.' },
  '01116b': { code:'01116b', side:'encounter', type:'main_scheme', name:'지하 유통망', nameEn:'Underground Distribution',
    stage:'1B', baseThreat:0, maxThreatPerPlayer:6, accelIcons:1, nextStage:'01117b',
    onSetup:'undergroundDistributionSetup', whenRevealed:'klawMainMinion',
    textKo:'클로가 지하 무기 유통망을 통해 도시 곳곳에 음파 무기를 퍼뜨리고 있다!\n\n공개 시: 조우덱에서 하수인이 버려질 때까지 카드를 버린다. 그 하수인을 첫 플레이어와 교전 상태로 전장에 놓는다.\n\n가속 ⚡1 · 위협 한도: 플레이어당 6.' },
  '01117a': { code:'01117a', side:'encounter', type:'main_scheme', name:'비밀 회합', nameEn:'Secret Rendezvous',
    stage:'2A',
    textKo:'공개 시: 조우덱에서 하수인이 버려질 때까지 카드를 버린다. 그 하수인을 첫 플레이어와 교전 상태로 전장에 놓는다.\n\n2B면으로 진행한다.' },
  '01117b': { code:'01117b', side:'encounter', type:'main_scheme', name:'비밀 회합', nameEn:'Secret Rendezvous',
    stage:'2B', baseThreat:0, maxThreatPerPlayer:8, accelIcons:1,
    whenRevealed:'klawMainMinion',
    textKo:'클로가 무기 구매자들과의 최종 회합을 준비한다. 거래가 성사되면 도시는 끝장이다!\n\n이 단계가 완성되면 — 플레이어 전원 패배.\n\n가속 ⚡1 · 위협 한도: 플레이어당 8.' },
  /* 울트론(Ultron) 3단계 — Core Set #134~136. 스스로를 진화의 다음 단계로 여기는 광기의 AI.
     Android/unique. 드론 군단과 하이브 회로. 스탯 공식 core_encounter.json 교차검증.
     I  (01134): ATK2/SCH1/HP17×히어로. ★강제반응: 공격 후 선택(메인 위협1 or 드론 스폰).
     II (01135): ATK2/SCH2/HP22×히어로. ★강제개입: 공격 시 드론 스폰 + 교전 드론당 ATK+1(그 공격 한정).
     III(01136): ATK4/SCH2/HP27×히어로. 지속: 드론 ATK/HP+1 · 드론 있으면 울트론 무적.
        공개 시: "울트론의 명령" 사이드 스킴 탐색 공개 + 조우덱 셔플. */
  '01134': { code:'01134', side:'encounter', type:'villain', name:'울트론', nameEn:'Ultron',
    stage:1, hpPerPlayer:17, attack:2, scheme:1, nextStage:'01135', unique:true, traits:['android'],
    forcedAttackChoice:{
      prompt:'울트론 강제 반응 — 메인 스킴에 위협 1을 놓거나, 덱 맨 위 카드를 뒷면 드론으로 등장',
      options:[
        { key:'threat', label:'메인 스킴에 위협 1', effects:[{ fx:'placeThreat', scheme:'main', amount:1 }] },
        { key:'drone',  label:'뒷면 드론 등장', effects:[{ fx:'spawnDrone', scope:'activePlayer', fallback:{ attack:1, scheme:1, hp:1 } }] },
      ] },
    vfx:{ entrance:'ultronEntrance', enemyAttack:'ultronAttack', stageChange:'ultronStageChange', defeat:'ultronDefeat' }, quoteKey:'ultron' , textKo:'★ 강제 반응: 울트론이 당신을 공격한 후, 메인 스킴에 위협 1을 놓거나 당신의 덱 맨 위 카드를 드론(Drone) 하수인으로 뒤집어 당신과 교전 상태로 배치하는 것 중 선택한다.' },
  '01135': { code:'01135', side:'encounter', type:'villain', name:'울트론', nameEn:'Ultron',
    stage:2, hpPerPlayer:22, attack:2, scheme:2, nextStage:'01136', unique:true, traits:['android'],
    villainAttackSpawnDrone:true, attackBonusPerDrone:true,
    vfx:{ entrance:'ultronEntrance', enemyAttack:'ultronAttack', stageChange:'ultronStageChange', defeat:'ultronDefeat' }, quoteKey:'ultron' , textKo:'★ 강제 개입: 울트론이 당신을 공격할 때, 당신의 덱 맨 위 카드를 드론(Drone) 하수인으로 뒤집어 당신과 교전 상태로 배치한다.' },
  '01136': { code:'01136', side:'encounter', type:'villain', name:'울트론', nameEn:'Ultron',
    stage:3, hpPerPlayer:27, attack:4, scheme:2, unique:true, traits:['android'],
    droneBuffVillain:{ attack:1, hp:1 }, invulnWhileDrone:true, whenRevealed:'ultronStage3Reveal',
    vfx:{ entrance:'ultronEntrance', enemyAttack:'ultronAttack', stageChange:'ultronStageChange', defeat:'ultronDefeat' }, quoteKey:'ultron' , textKo:'각 드론(Drone) 하수인은 ATK +1, HP +1을 얻는다. 드론 하수인이 전장에 있는 동안 울트론은 피해를 받지 않는다.\n\n공개 시: 조우 덱과 버린 더미에서 사이드 스킴을 찾아 공개한다.' },
  /* ── 울트론 메인 스킴 3단계 (Core Set #137~139) — 공식 core_encounter.json 교차검증 ──
     escalation_threat 1 = 인원당 기본 상승(표준, baseGain에 반영) · threat = 진행 임계(maxThreatPerPlayer).
     01137 The Crimson Cowl: 1A 셋업 = 울트론 드론 환경 배치 + 조우덱 셔플. 1B 임계 3/인.
       공개 시(1B/2B/3B 공통): 각 플레이어 뒷면 드론 스폰.
     01138 Assault on NORAD: 2B 임계 10/인. 강제반응 = 빌런 페이즈 위협 후 각 플레이어 선택(위협2 or 드론).
     01139 Countdown to Oblivion: 3B 임계 5/인. 위협 제거 불가. 완성 시 플레이어 전원 패배. */
  '01137a': { code:'01137a', side:'encounter', type:'main_scheme', name:'크림슨 카울', nameEn:'The Crimson Cowl',
    stage:'1A',
    textKo:'구성: 울트론 (I)·(II). (전문가 모드는 (II)·(III).)\\n셋업: 울트론 드론 환경을 전장에 놓는다. 조우덱을 셔플한다.\\n\\n준비가 끝나면 1B면으로 뒤집는다.\\n\\n*클로의 붉은 두건을 쓴 의문의 고용주는 사실 인류 절멸을 꾀하는 안드로이드 울트론이다.*' },
  '01137b': { code:'01137b', side:'encounter', type:'main_scheme', name:'크림슨 카울', nameEn:'The Crimson Cowl',
    stage:'1B', baseThreat:0, maxThreatPerPlayer:3, accelIcons:1, nextStage:'01138b',
    onSetup:'ultronSetup', whenRevealed:'runCardEffects',
    effects:[ { fx:'spawnDrone', scope:'eachPlayer', fallback:{ attack:1, scheme:1, hp:1 } },
              { fx:'playVfx', vfx:'ultronSchemeAdvance', quoteKey:'ultron-scheme', quoteKind:'crimson' } ],
    quoteKey:'ultron-scheme',
    textKo:'울트론이 클로가 조달한 부품으로 드론 군단을 만들고 있다!\\n\\n공개 시: 각 플레이어는 자기 덱 맨 위 카드를 뒷면으로, 자신과 교전한 Drone 하수인으로 전장에 놓는다.\\n\\n가속 ⚡1 · 진행 임계: 플레이어당 3.' },
  '01138a': { code:'01138a', side:'encounter', type:'main_scheme', name:'노라드 습격', nameEn:'Assault on NORAD',
    stage:'2A',
    textKo:'공개 시: 각 플레이어는 자기 덱 맨 위 카드를 뒷면 드론으로 전장에 놓는다.\\n\\n2B면으로 진행한다.' },
  '01138b': { code:'01138b', side:'encounter', type:'main_scheme', name:'노라드 습격', nameEn:'Assault on NORAD',
    stage:'2B', baseThreat:0, maxThreatPerPlayer:10, accelIcons:1, nextStage:'01139b',
    whenRevealed:'runCardEffects',
    effects:[ { fx:'spawnDrone', scope:'eachPlayer', fallback:{ attack:1, scheme:1, hp:1 } },
              { fx:'playVfx', vfx:'ultronSchemeAdvance', quoteKey:'ultron-scheme', quoteKind:'norad' } ],
    forcedThreatChoice:{
      prompt:'노라드 습격 강제 반응 — 여기에 위협 2를 놓거나, 덱 맨 위 카드를 뒷면 드론으로 등장',
      options:[
        { key:'threat', label:'여기에 위협 2', effects:[{ fx:'placeThreat', scheme:'main', amount:2 }] },
        { key:'drone',  label:'뒷면 드론 등장', effects:[{ fx:'spawnDrone', scope:'activePlayer', fallback:{ attack:1, scheme:1, hp:1 } }] },
      ] },
    quoteKey:'ultron-scheme',
    textKo:'울트론이 노라드를 장악하면 미국의 탄도 미사일 지휘권을 손에 넣는다!\\n\\n강제 반응: 빌런 페이즈 1단계에서 이곳에 위협을 놓은 후 — 각 플레이어는 이곳에 위협 2를 놓거나, 자기 덱 맨 위 카드를 뒷면 드론으로 전장에 놓는다.\\n\\n가속 ⚡1 · 진행 임계: 플레이어당 10.' },
  '01139a': { code:'01139a', side:'encounter', type:'main_scheme', name:'파멸의 카운트다운', nameEn:'Countdown to Oblivion',
    stage:'3A',
    textKo:'공개 시: 각 플레이어는 자기 덱 맨 위 카드를 뒷면 드론으로 전장에 놓는다.\\n\\n3B면으로 진행한다.' },
  '01139b': { code:'01139b', side:'encounter', type:'main_scheme', name:'파멸의 카운트다운', nameEn:'Countdown to Oblivion',
    stage:'3B', baseThreat:0, maxThreatPerPlayer:5, accelIcons:1, threatCannotRemove:true,
    whenRevealed:'runCardEffects',
    effects:[ { fx:'spawnDrone', scope:'eachPlayer', fallback:{ attack:1, scheme:1, hp:1 } },
              { fx:'playVfx', vfx:'ultronSchemeAdvance', quoteKey:'ultron-scheme', quoteKind:'countdown' } ],
    quoteKey:'ultron-scheme',
    textKo:'울트론이 노라드를 장악했다. 지휘 안전장치를 뚫고 핵무기를 발사하는 건 시간 문제다!\\n\\n이 스킴에서는 위협을 제거할 수 없다.\\n\\n이 단계가 완성되면 — 플레이어 전원 패배.\\n\\n가속 ⚡1 · 진행 임계: 플레이어당 5.' },
  '01120': { code:'01120', side:'encounter', type:'minion',
    name:'아머드 가드', nameEn:'Armored Guard', mcode:'01120', boost:1,
    attack:1, scheme:0, hp:3, guard:true, toughness:true, traits:['mercenary'], copies:3,
    vfx:{ attack:'armoredGuardStrike' },
    textKo:'하수인. 용병(Mercenary). ATK 1 / SCH 0 / HP 3.\n\n호위(Guard): 이 하수인이 당신과 교전 중인 동안 빌런을 공격할 수 없다.\n강인함(Toughness): 등장 시 강인함(Tough) 상태로 전장에 나온다.\n\n※ 공식 01120 Armored Guard (Core Set #120) ×3' },

  /* ═══════════════════════════════════════════════════════════════
     MVC02 그린 고블린 — Risky Business 시나리오 (양면 폼전환 빌런)
     노먼 오스본(a면) ↔ 그린 고블린(b면). 스테이지 처치 시 다음 스테이지가
     방금 처치된 같은 면으로 등장. 폼전환은 Criminal Enterprise/State of Madness
     환경의 카운터(악명/광기)가 0이 되면 발생.
     ★ 폼전환 엔진 메커니즘(카운터 플립 + 공격→카운터 리다이렉트 + 피해→카운터
       리다이렉트 + 면별 When Revealed)은 다음 증분에서 엔진 확장으로 구현.
       이 패스는 정확한 공식 스탯/텍스트 + 대사 데이터 레이어 등록.
     자원/스탯 출처: zzorba gob_encounter.json (authoritative).
     ═══════════════════════════════════════════════════════════════ */
  '02001a': { code:'02001a', side:'encounter', type:'villain', name:'노먼 오스본', nameEn:'Norman Osborn',
    stage:1, hpPerPlayer:14, scheme:2, noAttack:true, unique:true,
    form:'norman', altForm:'02001b', pairedEnv:'criminal-enterprise', nextStage:'02002a',
    traits:['businessman','genius'], vfx:{ entrance:'normanEntrance', stageChange:'normanStageUp', defeat:'normanDefeat' }, quoteKey:'norman-osborn',
    textKo:'빌런 (I). 사업가(Businessman). 천재(Genius). SCH 2 / HP 14×히어로. (공격력 없음)\n\n★ 강제 인터럽트: 노먼 오스본이 공격하려 할 때 → 공격 대신 Criminal Enterprise에 악명 카운터 1개를 배치한다.\n강제 인터럽트: 노먼 오스본이 피해를 받게 될 때 → 피해 대신 그만큼 Criminal Enterprise에서 악명 카운터를 제거한다.\n\n※ 공식 02001a Norman Osborn (I) · 공격 미발동(카운터 배치)이라 공격 트리거 미해소, 공격력 수정 불가' },
  '02001b': { code:'02001b', side:'encounter', type:'villain', name:'그린 고블린', nameEn:'Green Goblin',
    stage:1, hpPerPlayer:14, attack:3, noScheme:true, unique:true,
    form:'goblin', altForm:'02001a', pairedEnv:'state-of-madness', nextStage:'02002b',
    traits:['goblin'], vfx:{ entrance:'goblinEntrance', enemyAttack:'goblinAttack', stageChange:'goblinStageUp', defeat:'goblinDefeat' }, quoteKey:'green-goblin',
    textKo:'빌런 (I). 고블린(Goblin). ATK 3 / HP 14×히어로. (스킴력 없음)\n\n공개 시: 히어로 형태인 각 플레이어에게 간접 피해 3.\n★ 강제 인터럽트: 그린 고블린이 스킴하려 할 때 → 스킴 대신 State of Madness에서 광기 카운터 1개를 제거한다.\n\n※ 공식 02001b Green Goblin (I) · 스킴 미발동(카운터 제거)이라 스킴 트리거 미해소, 스킴력 수정 불가' },
  '02002a': { code:'02002a', side:'encounter', type:'villain', name:'노먼 오스본', nameEn:'Norman Osborn',
    stage:2, hpPerPlayer:18, scheme:2, noAttack:true, unique:true,
    form:'norman', altForm:'02002b', pairedEnv:'criminal-enterprise', nextStage:'02003a',
    traits:['businessman','genius'], vfx:{ entrance:'normanEntrance', stageChange:'normanStageUp', defeat:'normanDefeat' }, quoteKey:'norman-osborn',
    textKo:'빌런 (II). 사업가. 천재. SCH 2 / HP 18×히어로. (공격력 없음)\n\n★ 강제 인터럽트: 노먼 오스본이 공격하려 할 때 → 공격 대신 Criminal Enterprise에 악명 카운터 2개를 배치한다.\n강제 인터럽트: 노먼 오스본이 피해를 받게 될 때 → 피해 대신 그만큼 악명 카운터를 제거한다.\n\n※ 공식 02002a Norman Osborn (II)' },
  '02002b': { code:'02002b', side:'encounter', type:'villain', name:'그린 고블린', nameEn:'Green Goblin',
    stage:2, hpPerPlayer:18, attack:4, noScheme:true, unique:true,
    form:'goblin', altForm:'02002a', pairedEnv:'state-of-madness', nextStage:'02003b',
    traits:['goblin'], vfx:{ entrance:'goblinEntrance', enemyAttack:'goblinAttack', stageChange:'goblinStageUp', defeat:'goblinDefeat' }, quoteKey:'green-goblin',
    textKo:'빌런 (II). 고블린. ATK 4 / HP 18×히어로. (스킴력 없음)\n\n공개 시: 각 플레이어에게 간접 피해 3.\n★ 강제 인터럽트: 그린 고블린이 스킴하려 할 때 → 스킴 대신 광기 카운터 1개를 제거한다.\n\n※ 공식 02002b Green Goblin (II)' },
  '02003a': { code:'02003a', side:'encounter', type:'villain', name:'노먼 오스본', nameEn:'Norman Osborn',
    stage:3, hpPerPlayer:22, scheme:3, noAttack:true, unique:true,
    form:'norman', altForm:'02003b', pairedEnv:'criminal-enterprise',
    traits:['businessman','genius'], vfx:{ entrance:'normanEntrance', stageChange:'normanStageUp', defeat:'normanDefeat' }, quoteKey:'norman-osborn',
    textKo:'빌런 (III). 사업가. 천재. SCH 3 / HP 22×히어로. (공격력 없음)\n\n★ 강제 인터럽트: 노먼 오스본이 공격하려 할 때 → 공격 대신 Criminal Enterprise에 악명 카운터 3개를 배치한다.\n강제 인터럽트: 노먼 오스본이 피해를 받게 될 때 → 피해 대신 그만큼 악명 카운터를 제거한다.\n\n※ 공식 02003a Norman Osborn (III)' },
  '02003b': { code:'02003b', side:'encounter', type:'villain', name:'그린 고블린', nameEn:'Green Goblin',
    stage:3, hpPerPlayer:22, attack:4, noScheme:true, unique:true,
    form:'goblin', altForm:'02003a', pairedEnv:'state-of-madness',
    traits:['goblin'], vfx:{ entrance:'goblinEntrance', enemyAttack:'goblinAttack', stageChange:'goblinStageUp', defeat:'goblinDefeat' }, quoteKey:'green-goblin',
    textKo:'빌런 (III). 고블린. ATK 4 / HP 22×히어로. (스킴력 없음)\n\n공개 시: 각 플레이어에게 피해 4.\n★ 강제 인터럽트: 그린 고블린이 스킴하려 할 때 → 스킴 대신 광기 카운터 2개를 제거한다.\n\n※ 공식 02003b Green Goblin (III)' },

  /* Risky Business 메인 스킴 — Hostile Takeover(1) → Corporate Acquisition(2) */
  '02004a': { code:'02004a', side:'encounter', type:'main_scheme', name:'적대적 인수', nameEn:'Hostile Takeover',
    stage:'1A', nextStage:'02004b',
    textKo:'구성: 노먼 오스본 (I), (II) 사용. Risky Business + 표준 조우 세트. 모듈러 1세트(권장: Goblin Gimmicks).\n\n셋업: Criminal Enterprise 환경을 전장에 놓는다. 조우덱을 셔플한다. 1B면으로 진행한다.' },
  '02004b': { code:'02004b', side:'encounter', type:'main_scheme', name:'적대적 인수', nameEn:'Hostile Takeover',
    stage:'1B', baseThreat:2, maxThreatPerPlayer:7, accelIcons:1, nextStage:'02005a',
    textKo:'노먼 오스본이 스타크 인더스트리의 부실 지사를 인수해 범죄 제국을 키우려 한다!\n\n시작 위협: 플레이어당 2 · 가속 ⚡1 · 위협 한도: 플레이어당 7.\n\n완료 시: Criminal Enterprise에 악명 카운터 1개×히어로를 배치한다. 그 후 Criminal Enterprise의 악명 카운터 수만큼 각 플레이어가 덱에서 카드를 버린다.' },
  '02005a': { code:'02005a', side:'encounter', type:'main_scheme', name:'기업 인수합병', nameEn:'Corporate Acquisition',
    stage:'2A', nextStage:'02005b',
    textKo:'공개 시: 2B면으로 진행한다.' },
  '02005b': { code:'02005b', side:'encounter', type:'main_scheme', name:'기업 인수합병', nameEn:'Corporate Acquisition',
    stage:'2B', baseThreat:1, maxThreatPerPlayer:10, accelIcons:2,
    textKo:'오스본의 인수가 완료되면 도시는 그의 손아귀에 떨어진다!\n\n시작 위협: 플레이어당 1 · 가속 ⚡2 · 위협 한도: 플레이어당 10.\n\n이 스킴이 완료되면 — 플레이어 전원 패배.' },

  /* ═══ MVC02 Mutagen Formula — 단면 그린 고블린 3스테이지 (폼전환 없음) ═══
     뮤타젠 가스로 시민을 고블린으로 변이시킨다. 공격 후 피해 시 메인 위협 배치(강제반응).
     ★ 인덱스 재사용: attackThreatOnDamage(공격 pending threatOnDamage 경유) + WR 조우 배분. */
  '02014': { code:'02014', side:'encounter', type:'villain', name:'그린 고블린', nameEn:'Green Goblin',
    stage:1, hpPerPlayer:16, attack:2, scheme:1, nextStage:'02015', unique:true,
    traits:['goblin'], vfx:{ entrance:'goblinEntrance', enemyAttack:'goblinAttack', stageChange:'goblinStageUp', defeat:'goblinDefeat' }, quoteKey:'green-goblin', attackThreatOnDamage:1,
    textKo:'빌런 (I). 고블린(Goblin). ATK 2 / SCH 1 / HP 16×히어로.\n\n★ 강제 반응: 그린 고블린이 당신을 공격하여 피해를 입힌 후 → 메인 스킴에 위협 1을 배치한다.\n\n※ 공식 02014 Green Goblin (I) · Mutagen Formula' },
  '02015': { code:'02015', side:'encounter', type:'villain', name:'그린 고블린', nameEn:'Green Goblin',
    stage:2, hpPerPlayer:18, attack:2, scheme:2, nextStage:'02016', unique:true,
    traits:['goblin'], vfx:{ entrance:'goblinEntrance', enemyAttack:'goblinAttack', stageChange:'goblinStageUp', defeat:'goblinDefeat' }, quoteKey:'green-goblin', attackThreatOnDamage:1,
    whenRevealed:'runCardEffects', whenRevealedEffects:[{ fx:'dealEncounterEachPlayer', amount:2 }],
    textKo:'빌런 (II). 고블린. ATK 2 / SCH 2 / HP 18×히어로.\n\n공개 시: 각 플레이어에게 조우 카드 2장을 배분한다.\n★ 강제 반응: 그린 고블린이 당신을 공격하여 피해를 입힌 후 → 메인 스킴에 위협 1을 배치한다.\n\n※ 공식 02015 Green Goblin (II)' },
  '02016': { code:'02016', side:'encounter', type:'villain', name:'그린 고블린', nameEn:'Green Goblin',
    stage:3, hpPerPlayer:20, attack:3, scheme:2, unique:true,
    traits:['goblin'], vfx:{ entrance:'goblinEntrance', enemyAttack:'goblinAttack', stageChange:'goblinStageUp', defeat:'goblinDefeat' }, quoteKey:'green-goblin', attackThreatOnDamage:2,
    whenRevealed:'runCardEffects', whenRevealedEffects:[{ fx:'dealEncounterEachPlayer', amount:3 }],
    textKo:'빌런 (III). 고블린. ATK 3 / SCH 2 / HP 20×히어로.\n\n공개 시: 각 플레이어에게 조우 카드 3장을 배분한다.\n★ 강제 반응: 그린 고블린이 당신을 공격하여 피해를 입힌 후 → 메인 스킴에 위협 2를 배치한다.\n\n※ 공식 02016 Green Goblin (III)' },

  /* Mutagen Formula 메인 스킴 — Unleashing the Mutagen(1) → Mutagen Cloud(2) */
  '02017a': { code:'02017a', side:'encounter', type:'main_scheme', name:'뮤타젠 방출', nameEn:'Unleashing the Mutagen',
    stage:'1A', nextStage:'02017b',
    textKo:'구성: 그린 고블린 (I), (II) 사용. Mutagen Formula + 표준 조우 세트. 모듈러 1세트(권장: Goblin Gimmicks).\n\n셋업: 각 플레이어와 교전 상태로 Goblin Thrall 하수인 1마리를 전장에 놓는다. 조우덱을 셔플한다. 1B로 진행한다.' },
  '02017b': { code:'02017b', side:'encounter', type:'main_scheme', name:'뮤타젠 방출', nameEn:'Unleashing the Mutagen',
    stage:'1B', baseThreat:2, maxThreatPerPlayer:7, accelIcons:1, nextStage:'02018a',
    textKo:'그린 고블린이 뮤타젠 가스를 도시에 퍼뜨린다!\n\n시작 위협: 플레이어당 2 · 가속 ⚡1 · 위협 한도: 플레이어당 7.\n\n완료 시: 플레이어 순서로, 고블린 하수인과 교전 중이 아닌 각 플레이어는 조우덱에서 3장을 버리고, 그렇게 버린 첫 고블린 하수인을 자신과 교전 상태로 전장에 놓는다.' },
  '02018a': { code:'02018a', side:'encounter', type:'main_scheme', name:'뮤타젠 구름', nameEn:'Mutagen Cloud',
    stage:'2A', nextStage:'02018b',
    textKo:'공개 시: 2B로 진행한다.' },
  '02018b': { code:'02018b', side:'encounter', type:'main_scheme', name:'뮤타젠 구름', nameEn:'Mutagen Cloud',
    stage:'2B', baseThreat:4, maxThreatPerPlayer:11, accelFrom:'goblinEnemies',
    textKo:'도시 전체가 뮤타젠 구름에 뒤덮인다!\n\n시작 위협: 플레이어당 4 · 가속: X(전장의 고블린 적 수, 그린 고블린 포함) · 위협 한도: 플레이어당 11.\n\n이 스킴이 완료되면 — 플레이어 전원 패배.' },

  /* Mutagen Formula 부착물 — Goblin Glider (최고 HP 적 강화) */
  '02019': { code:'02019', side:'encounter', type:'attachment', name:'고블린 글라이더', nameEn:'Goblin Glider',
    boost:3, attachTarget:'highestHpEnemy', attachStats:{ attack:1 },
    activatedAbility:{ payCost:{ type:'energy', count:2 }, effect:{ fx:'discardSelfAttachment' } },
    textKo:'인쇄된 HP가 가장 높은 적(다른 고블린 글라이더가 없는)에 부착한다. 부착할 수 없으면 이 카드는 급증(surge)한다.\n\n부착된 적: ATK +1.\n\n히어로 행동: ⚡⚡ 자원 지불 → 이 카드를 버린다.' },
  '02021': { code:'02021', side:'encounter', type:'attachment', name:'펌킨 폭탄', nameEn:'Pumpkin Bombs',
    boost:2, attachTarget:'villain',
    attackResponseEffects:[{ fx:'dealDamage', target:'self', amount:2, indirect:true }, { fx:'discardSelfAttachment' }],
    activatedAbility:{ payCost:{ type:'physical', count:2 }, effect:{ fx:'discardSelfAttachment' } },
    textKo:'빌런에 부착한다.\n\n★ 강제 반응: 빌런이 당신을 공격한 후 → 펌킨 폭탄을 버리고 간접 피해 2를 받는다.\n\n히어로 행동: 💪💪 자원 지불 → 이 카드를 버린다.' },
  '02035': { code:'02035', side:'encounter', type:'treachery', name:'위협', nameEn:'Intimidation', boost:1,
    textKo:'공개 시: [아무 자원 2 지불] 또는 [빌런에게 뒷면 부스트 카드 1개 부여] 중 선택한다.\n\n★ 부스트: 빌런에게 이번 활성화 추가 부스트 카드 1개를 준다.\n\n※ Goblin Gimmicks 모듈러 (02035)' }
});

})(typeof window !== 'undefined' ? window : globalThis);
