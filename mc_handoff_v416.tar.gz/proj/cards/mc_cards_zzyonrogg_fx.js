/* ═══════════════════════════════════════════════════════════════
   욘-로그 넴시스 세트 (캡틴 마블/캐롤 댄버스) — Core Set #175~
   캐롤 댄버스의 개인 조우 카드. 지구의 가족과 크리 제국(욘-로그) 사이의 갈등.
   캡틴 마블 시그니처는 이미 완료.

   01175 가족 비상사태 (Family Emergency) — 의무(Obligation) ×1, 부스트 ▲1
     · 공개 시: 캐롤 댄버스 플레이어에게. 알터에고 전환 가능. 택 1:
       ① 캐롤 댄버스 소진 → 이 카드 게임에서 제거
       ② 자신 기절 + 이 카드 급증(Surge) → 이 의무 버림
   ★ 엔진: offerChoice + exhaustTarget/resolveObligation/applyStatus/surge(기존).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 가족 비상사태(01175) — 의무. 지구의 가족을 챙겨야 하는 캐롤의 개인사. */
MC.defineCardFx('family-emergency', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'offerChoice', prompt: '가족 비상사태 — 가족과 임무 사이에서 (택 1)',
      options: [
        { key: 'exhaust', label: '캐롤 댄버스를 소진 → 이 의무를 게임에서 제거',
          effects: [
            { fx: 'exhaustTarget', target: 'self' },
            { fx: 'playVfx', vfx: 'familyEmergencyResolve', quoteKey: 'family-emergency', quoteKind: 'duty' },
            { fx: 'resolveObligation', mode: 'game' },
          ] },
        { key: 'stun', label: '자신 기절 + 급증 → 이 의무를 버림',
          effects: [
            { fx: 'applyStatus', target: 'self', status: 'stunned' },
            { fx: 'surge' },
            { fx: 'playVfx', vfx: 'familyEmergencyDefer', quoteKey: 'family-emergency', quoteKind: 'defer' },
            { fx: 'resolveObligation', mode: 'discard' },
          ] },
      ] },
  ],
  quoteKey: 'family-emergency', vfx: { attack: 'familyEmergencyResolve' },
  textKo: '의무 — Obligation. 부스트 ▲1.\n\n캐롤 댄버스 플레이어에게 준다. 알터에고 폼으로 전환할 수 있다. 다음 중 택 1:\n\n• 캐롤 댄버스를 소진한다 → 가족 비상사태를 게임에서 제거한다.\n• 자신은 기절(Stunned)한다. 이 카드는 급증(Surge)을 얻는다. → 이 의무를 버림.\n\n*"우주를 지키는 것도 중요하지만… 가족을 저버릴 순 없어."*\n\n※ 공식 01175 Family Emergency (Core Set #175, Captain Marvel 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 소진 = 영구 해결 · 기절+급증 = 행동력 손실 + 추가 조우 대가로 회피',
});

/* 사이키-마그니트론(01176) — 사이드 스킴. 위험(Hazard). 생각을 현실로 바꾸는 크리 장치. */
MC.defineCardFx('psyche-magnitron', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'placeThreat', scheme: 'self', perHero: 1 },
    { fx: 'playVfx', vfx: 'psycheMagnitronReveal', quoteKey: 'psyche-magnitron', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'psycheMagnitronCleared', quoteKey: 'psyche-magnitron', quoteKind: 'complete' }],
  quoteKey: 'psyche-magnitron', vfx: { attack: 'psycheMagnitronReveal' },
  textKo: '사이드 스킴 — 시작 위협 3(고정). ☣ 위험(Hazard).\n\n공개 시: 여기에 위협을 추가로 1/인 놓는다 (솔로: 총 4).\n\n위험(Hazard): 이 스킴이 전장에 있는 동안, 빌런 페이즈에 조우 카드를 1장 추가로 처리한다.\n\n*"사이키-마그니트론은 생각을 현실로 바꾸는 크리 장치다. 욘-로그의 손에 들어가면 파괴적인 무기가 된다."*\n\n※ 공식 01176 The Psyche-Magnitron (Core Set #176, Captain Marvel 넴시스 세트, ×1) — base_threat 3 고정 · Hazard 아이콘\n※ 위험으로 조우 압박 가중 · 우선 처치 권장',
});

/* 욘-로그(01177) — 하수인. 강제 반응: 공격 후 사이키-마그니트론에 위협 +1. 크리 지휘관. */
MC.defineCardFx('yon-rogg', {
  forcedResponseEffects: [
    { fx: 'placeThreat', scheme: 'namedSide', slug: 'psyche-magnitron', amount: 1 },
    { fx: 'playVfx', vfx: 'yonRoggForcedResponse', quoteKey: 'yon-rogg', quoteKind: 'forced' },
  ],
  vfx: { entrance: 'yonRoggEntrance', minionAttack: 'yonRoggAttack', defeat: 'yonRoggDefeat' },
  textKo: '하수인 — 정예(Elite). 크리(Kree).\nATK 3 / SCH 2 / HP 5.\n\n★ 강제 반응(Forced Response): 욘-로그가 공격한 후, 사이키-마그니트론에 위협을 1 놓는다.\n\n*"마-벨을 쓰러뜨리지 못했지만, 캡틴 마블도 같은 운명일 거다." —욘-로그*\n\n※ 공식 01177 Yon-Rogg (Core Set #177, Captain Marvel 넴시스 세트, ×1) — Forced Response\n※ 공격할 때마다 사이키-마그니트론 위협 가속 → 사이드 스킴 방치 시 위험',
});

/* 크리 조종자(01178) — 배신 ×2. 급증. 메인 위협 +1. 부스트★도 메인 위협 +1. */
MC.defineCardFx('kree-manipulator', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'placeThreat', scheme: 'main', amount: 1 },
    { fx: 'playVfx', vfx: 'kreeManipulatorReveal', quoteKey: 'kree-manipulator', quoteKind: 'reveal' },
    { fx: 'surge' },
  ],
  boostStarEffects: [
    { fx: 'placeThreat', scheme: 'main', amount: 1 },
    { fx: 'playVfx', vfx: 'kreeManipulatorReveal', quoteKey: 'kree-manipulator', quoteKind: 'reveal' },
  ],
  quoteKey: 'kree-manipulator', vfx: { attack: 'kreeManipulatorReveal' }, copies: 2,
  textKo: '배신 — Treachery. 급증(Surge). 부스트 ★.\n\n공개 시: 메인 스킴에 위협을 1 놓는다.\n\n★ 부스트: 빌런이 무방어 공격을 하는 중이면, 메인 스킴에 위협을 1 놓는다.\n\n*"크리의 의지가 이 세계를 잠식한다 — 저항은 무의미해."*\n\n※ 공식 01178 Kree Manipulator (Core Set #178, Captain Marvel 넴시스 세트, ×2) — 공식 JSON 교차검증\n※ 급증으로 추가 조우 + 메인 위협 가속 · 크리 심리전 테마',
});

/* 욘-로그의 반역(01179) — 배신. 손패 자원 카드 전체 버림. 버린 게 없으면 급증. */
MC.defineCardFx('yon-roggs-treason', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'discardAllResourcesFromHand' },
    { fx: 'playVfx', vfx: 'yonRoggsTreasonReveal', quoteKey: 'yon-roggs-treason', quoteKind: 'reveal' },
    { fx: 'surge', cond: { type: 'treasonDiscardedNone' } },
  ],
  quoteKey: 'yon-roggs-treason', vfx: { attack: 'yonRoggsTreasonReveal' },
  textKo: '배신 — Treachery. 부스트 ▲1.\n\n공개 시: 자신의 손에서 자원(resource)을 가진 카드를 모두 버린다. 이렇게 버린 카드가 없으면 → 이 카드는 급증(Surge)을 얻는다.\n\n*"크리를 배신한 대가다, 버스 — 네 모든 걸 앗아가주지."*\n\n※ 공식 01179 Yon-Rogg\'s Treason (Core Set #179, Captain Marvel 넴시스 세트, ×1) — marvelcdb 확정: "each resource"(모든 자원, energy 한정 아님)\n※ 손패 대부분 소실(자원 아이콘 카드 전부) · 자원 없는 손패면 급증으로 전환',
});

})(typeof window !== 'undefined' ? window : globalThis);
