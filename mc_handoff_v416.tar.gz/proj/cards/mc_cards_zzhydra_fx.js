/* ═══════════════════════════════════════════════════════════════
   Legions of Hydra 모듈러 인카운터 세트 — Core Set #180~182
   히드라 군단이 등장하는 모듈러 세트. 어떤 빌런 시나리오에도 추가 가능.
   구성: Legions of Hydra(사이드 스킴 ×2), Madame Hydra(하수인), Hydra Soldier(하수인 ×3)

   01180 Legions of Hydra — 사이드 스킴 ×2, 시작 위협 3(고정), 위험(Hazard)
     · 공개 시: 마담 히드라가 전장에 없으면 조우덱/버림 탐색→전장 배치(교전), 조우덱 셔플.
       전장의 각 히드라(Hydra) 적 1명당 여기에 위협 2 추가.
   ★ 엔진: summonNamedMinionIfAbsent + placeThreatPerEnemyTrait(이번 신설).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* Legions of Hydra(01180) — 사이드 스킴. 마담 히드라 소환 + 히드라 적 수 ×2 위협. */
MC.defineCardFx('legions-of-hydra-scheme', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'summonNamedMinionIfAbsent', code: 'madame-hydra' },
    { fx: 'placeThreatPerEnemyTrait', trait: 'hydra', mult: 2 },
    { fx: 'playVfx', vfx: 'legionsOfHydraReveal', quoteKey: 'legions-of-hydra', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'legionsOfHydraCleared', quoteKey: 'legions-of-hydra', quoteKind: 'complete' }],
  quoteKey: 'legions-of-hydra', vfx: { attack: 'legionsOfHydraReveal' },
  textKo: '사이드 스킴 (모듈러) — 시작 위협 3(고정). ☣ 위험(Hazard). ×2.\n\n공개 시: 마담 히드라가 전장에 없으면, 조우덱과 버린 더미에서 마담 히드라를 찾아 당신과 교전한 상태로 전장에 놓고 조우덱을 섞는다. 그 다음, 전장의 히드라(Hydra) 적 1명당 여기에 위협을 2 놓는다.\n\n*"히드라 만세! 머리 하나를 자르면, 둘이 그 자리를 대신하리라!"*\n\n※ 공식 01180 Legions of Hydra (Core Set #180, Legions of Hydra 모듈러, ×2) — base_threat 3 고정 · Hazard\n※ 히드라 적이 많을수록 위협 폭증 · 마담 히드라 우선 처치로 확산 억제',
});

/* 마담 히드라(01181) — 하수인. Legions of Hydra 존재 시 피해 면역 + 강제 반응(스킴/공격 후 위협 +2). */
MC.defineCardFx('madame-hydra', {
  invulnWhileScheme: 'legions-of-hydra-scheme',
  forcedResponseEffects: [
    { fx: 'placeThreat', scheme: 'namedSide', slug: 'legions-of-hydra-scheme', amount: 2 },
    { fx: 'playVfx', vfx: 'madameHydraForcedResponse', quoteKey: 'madame-hydra', quoteKind: 'forced' },
  ],
  vfx: { entrance: 'madameHydraEntrance', minionAttack: 'madameHydraAttack', defeat: 'madameHydraDefeat' },
  textKo: '하수인 — 정예(Elite). 히드라(Hydra).\nATK 2 / SCH 2 / HP 6.\n\n지속 효과: Legions of Hydra 사이드 스킴이 전장에 있는 동안, 마담 히드라는 피해를 받지 않는다.\n\n★ 강제 반응(Forced Response): 마담 히드라가 스킴하거나 공격한 후, Legions of Hydra 사이드 스킴에 위협을 2 놓는다.\n\n*"히드라의 진정한 지도자가 누구인지 보여주지."*\n\n※ 공식 01181 Madame Hydra (Core Set #181, Legions of Hydra 모듈러, ×1) — 조건부 피해 면역 + Forced Response\n※ Legions of Hydra를 먼저 처치해야 마담 히드라에 피해를 줄 수 있음',
});

/* 하이드라 솔저(01182) — 하수인 ×3. 호위(Guard). 처치 시 교전 플레이어에게 조우 카드 1장.
   ※ 중복 등록 주의: 게임에서 'hydra-soldier'와 'hydra-soldier-loh' 둘 다 mcode 01182(같은 코어셋 카드)로
     쓰인다. 별칭 시스템이 없어 두 slug에 동일 FX를 등록한다. (hydra-soldier-patrol은 mcode 04153로 별개.) */
const HYDRA_SOLDIER_FX = {
  guard: true,
  whenDefeated: 'runCardEffects',
  whenDefeatedEffects: [
    { fx: 'dealEncounterToEngaged', count: 1 },
    { fx: 'playVfx', vfx: 'hydraSoldierDefeat', quoteKey: 'hydra-soldier', quoteKind: 'defeat' },
  ],
  vfx: { entrance: 'hydraSoldierEntrance', minionAttack: 'hydraSoldierAttack', defeat: 'hydraSoldierDefeat' },
  textKo: '하수인 — 히드라(Hydra). ×3.\nATK 2 / SCH 1 / HP 4.\n\n호위(Guard): 이 하수인이 당신과 교전 중인 동안, 당신은 빌런을 공격할 수 없다.\n\n처치될 때: 교전 중이던 플레이어에게 조우 카드를 1장 처리한다.\n\n*"히드라 만세! 우리는 잘려도 다시 자라난다!"*\n\n※ 공식 01182 Hydra Soldier (Core Set #182, Legions of Hydra 모듈러, ×3) — Guard + When Defeated\n※ 처치 시 조우 카드 반격 · 빌런 접근 차단(호위) · 무리로 등장',
};
MC.defineCardFx('hydra-soldier', HYDRA_SOLDIER_FX);
MC.defineCardFx('hydra-soldier-loh', HYDRA_SOLDIER_FX);

})(typeof window !== 'undefined' ? window : globalThis);
