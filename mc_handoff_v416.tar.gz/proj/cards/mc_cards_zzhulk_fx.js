/* ◇ 헐크 시그니처 fx ◇ (10002~10010) — 감마 방사선·격노·괴력 테마 */
(function(global){
  'use strict';
  const MC = global.MC;
  if (!MC || !MC.defineCardFx) return;

  /* 10002 Crushing Blow (분쇄의 일격) — 이벤트. 비용 1, 물리 1. ×2.
     이 카드는 물리 자원으로만 지불 가능. 히어로 행동(공격): 적 1명에게 ATK만큼 피해.
     범용: dealDamage amountFrom:'heroAtk'(신규) + isAttack. */
  MC.defineCardFx('crushing-blow', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [{ fx:'dealDamage', target:'chosen', amountFrom:'heroAtk', isAttack:true }],
    needsEnemyTarget: true,
  });

  /* 10003 Hulk Smash (헐크 스매시) — 이벤트. 비용 3, 물리 1. ×2.
     히어로 인터럽트: 기본 공격 시 → +10 ATK. 물리만 지불 시 과잉살상(Overkill).
     범용: buffNextBasicAttack(10) + setNextAttackOverkill(cond paidWith physical). */
  MC.defineCardFx('hulk-smash', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [
      { fx:'buffNextBasicAttack', amount:10 },
      { fx:'setNextAttackOverkill', cond:{ type:'paidWith', resource:'physical' } },
    ],
  });

  /* 10004 Sub-Orbital Leap (준궤도 도약) — 이벤트. 비용 3, 물리 1. ×2.
     히어로 행동(방해): 스킴에서 위협 3 제거 (물리만 지불 시 5).
     범용: removeThreat(3, amountIf paidWith physical→5, targetScheme UI 선택). */
  MC.defineCardFx('sub-orbital-leap', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [{ fx:'removeThreat', amount:3, amountIf:{ cond:{ type:'paidWith', resource:'physical' }, amount:5 } }],
  });

  /* 10005 Thunderclap (천둥 박수) — 이벤트. 비용 3, 물리 1. ×2.
     히어로 행동: 서로 다른 적 최대 3명 선택 → 각 3 피해.
     범용: dealDamageMulti(lines:3, amount:3, isAttack:false). */
  MC.defineCardFx('thunderclap', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [{ fx:'dealDamageMulti', lines:3, amount:3, isAttack:false }],
    needsEnemyTarget: true,
  });

  /* 10006 Unstoppable Force (막을 수 없는 힘) — 이벤트. 비용 2, 물리 1. ×2.
     히어로 행동: 헐크 준비(ready). 물리만 지불 시 카드 1 드로우.
     범용: readySelf + draw(cond paidWith physical). */
  MC.defineCardFx('unstoppable-force', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [
      { fx:'readySelf' },
      { fx:'draw', amount:1, cond:{ type:'paidWith', resource:'physical' } },
    ],
  });

  /* 10007 Limitless Strength (무한한 힘) — 자원 카드. 물리 3. ×2. 히어로 폼에서만 지불 가능.
     자원 카드는 결제로만 사용 — playForm 제약만 표시. */
  MC.defineCardFx('limitless-strength', {
    playForm: 'hero',
  });

  /* 10008 Banner's Laboratory (배너의 실험실) — 지원. 비용 2, 멘탈 1.
     브루스 배너 +2 REC. 알터에고 자원: 소진 → 멘탈 자원 생성.
     범용: statMod(recover +2) + resourceGenerator(alter-ego, exhaust, mental). */
  MC.defineCardFx('banners-laboratory', {
    statMod: { stat:'recover', amount:2 },
    resourceGenerator: { form:'alter-ego', exhaust:true, counter:1, icons:{ mental:1 } },
  });

  /* 10009 Boundless Rage (끝없는 분노) — 업그레이드. 비용 1, 물리 1. 히어로 폼 전용.
     헐크 +1 ATK. 강제 반응: 폼 변경 후 이 카드 버림.
     범용: statMod(attack +1, cond isHeroForm) + onFormChangeDiscard(폼변경 시 버림). */
  MC.defineCardFx('boundless-rage', {
    statMod: { stat:'attack', amount:1, cond:{ type:'isHeroForm' } },
    onFormChangeDiscard: true,
  });

  /* 10010 Immovable Object (요지부동) — 업그레이드. 비용 3, 물리 1.
     +4 HP. 헐크 보복(Retaliate) 1 획득.
     범용: hpBonus(4) + grantsRetaliate(1) — recomputeMaxHp/passiveRetaliate 재사용. */
  MC.defineCardFx('immovable-object', {
    hpBonus: 4,
    grantsRetaliate: 1,
  });

  /* ═══ 어그레션(Aggression) 성향 ═══ */

  /* 10011 Brawn (브런) — 동료. 어벤져·감마. 비용 3, 멘탈 1. ATK 1 / THW 1 / HP 5.
     반응: 브런이 공격한 후 → 스킴에서 위협 1 제거. afterAttack 데이터 방식 + removeThreat. */
  MC.defineCardFx('brawn', {
    afterAttack: { effect:[{ fx:'removeThreat', amount:1 }] },
  });

  /* 10012 Sentry (센트리) — 동료. 어벤져. 비용 4, 에너지 1. ATK 3 / THW 2 / HP 5.
     강제 반응: 인플레이 시 → 조우 카드 1장 받음. whenPlayed + dealEncounterToEngaged. */
  MC.defineCardFx('sentry', {
    whenPlayed: 'runCardEffects',
    whenPlayedEffects: [{ fx:'dealEncounterToEngaged', count:1 }],
  });

  /* 10013 She-Hulk (쉬헐크 동료) — 동료. 어벤져·감마. 비용 4, 물리 1. ATK 1 / THW 2 / HP 4.
     ★ 여기 놓인 피해 토큰 1개당 +1 ATK. dynamicStat(attack, per:damageOnSelf) — allyStatOf 재사용. */
  MC.defineCardFx('she-hulk-ally', {
    dynamicStat: { stat:'attack', per:'damageOnSelf' },
  });

  /* 10014 Drop Kick (드롭킥) — 이벤트. 비용 3, 물리 1. ×3.
     히어로 행동(공격): 적 1명 4 피해. 물리만 지불 시 → 그 적 기절 + 카드 1 드로우.
     범용: dealDamage(4, isAttack) + applyStatus(stunned, cond physical) + draw(cond physical). */
  MC.defineCardFx('drop-kick', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [
      { fx:'dealDamage', target:'chosen', amount:4, isAttack:true },
      { fx:'applyStatus', target:'chosen', status:'stunned', cond:{ type:'paidWith', resource:'physical' } },
      { fx:'draw', amount:1, cond:{ type:'paidWith', resource:'physical' } },
    ],
    needsEnemyTarget: true,
  });

  /* 10015 Toe to Toe (맞대결) — 이벤트. 비용 1, 멘탈 1. ×3.
     히어로 행동(공격): 적 1명 선택 → 그 적이 당신을 공격 → 그 후 그 적에게 5 피해.
     범용: provokeEnemyAttack(적 공격 유발) + afterEffects(방어 해소 후 dealDamage 5). */
  MC.defineCardFx('toe-to-toe', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [{ fx:'provokeEnemyAttack', afterEffects:[{ fx:'dealDamage', target:'chosen', amount:5, isAttack:true }] }],
    needsEnemyTarget: true,
  });

  /* 10016 "You'll Pay for That!" (대가를 치르게 해주지!) — 이벤트. 비용 1, 에너지 1. ×3.
     히어로 반응(방해): 빌런이 당신을 공격한 후 → 그 공격으로 받은 피해 1당 스킴에서 위협 1 제거 (최대 5).
     범용: whenPlayed + removeThreat(amountFrom:'lastDamageTaken', max:5). */
  MC.defineCardFx('youll-pay-for-that', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [{ fx:'removeThreat', amountFrom:'lastDamageTaken', max:5 }],
  });

  /* 10018 Martial Prowess (무예 숙련) — 업그레이드. 비용 2, 물리 1. 어느 플레이어나 제어. 플레이어당 최대 1.
     자원: 소진 → [Attack] 이벤트용 물리 자원 생성. resourceGenerator(exhaust, physical, forAttackEvent). */
  MC.defineCardFx('martial-prowess', {
    resourceGenerator: { exhaust:true, icons:{ physical:1 }, forAttackEvent:true },
  });

  /* 10019 To the Rescue! (구조하러 간다!) — 이벤트. 비용 2, 물리 1. ×3.
     히어로 행동(방해): 스킴에서 위협 2 제거. removeThreat 2. */
  MC.defineCardFx('to-the-rescue', {
    playForm: 'hero',
    whenPlayed: 'runCardEffects',
    effects: [{ fx:'removeThreat', amount:2 }],
  });

  /* 10032 Resourceful (임기응변) — 업그레이드. 비용 1, 와일드 1.
     자원: 이 카드를 버림 → 와일드 자원 생성. resourceGenerator(discard, wild). */
  MC.defineCardFx('resourceful', {
    resourceGenerator: { discard:true, icons:{ wild:1 } },
  });

})(typeof window !== 'undefined' ? window : globalThis);
