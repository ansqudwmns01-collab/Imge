/* ═══════════════════════════════════════════════════════════════
   쉬헐크(제니퍼 월터스) 넴시스 세트 — Core Set #160~
   변호사이자 히어로인 제니퍼의 개인 조우 카드. 법정과 전장 사이의 갈등.
   쉬헐크 시그니처(신분·감마 슬램 등)는 이미 완료.

   01160 법률 업무 (Legal Work) — 의무(Obligation) ×1, 부스트 ▲2
     · 공개 시: 제니퍼 월터스 플레이어에게. 알터에고 전환 가능. 택 1:
       ① 제니퍼 월터스 소진 → 이 카드 게임에서 제거
       ② 메인 스킴에 가속 토큰 +1 → 이 의무 버림
   ★ 엔진: offerChoice + exhaustTarget/resolveObligation(기존) + addAcceleration(이번 신설).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 법률 업무(01160) — 의무. 변호사 업무와 히어로 활동 사이의 갈등. */
MC.defineCardFx('legal-work', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'offerChoice', prompt: '법률 업무 — 밀린 사건을 어떻게 처리할 것인가 (택 1)',
      options: [
        { key: 'exhaust', label: '제니퍼 월터스를 소진 → 이 의무를 게임에서 제거',
          effects: [
            { fx: 'exhaustTarget', target: 'self' },
            { fx: 'playVfx', vfx: 'legalWorkResolve', quoteKey: 'legal-work', quoteKind: 'duty' },
            { fx: 'resolveObligation', mode: 'game' },
          ] },
        { key: 'accel', label: '메인 스킴에 가속 토큰 +1 → 이 의무를 버림',
          effects: [
            { fx: 'addAcceleration', amount: 1 },
            { fx: 'playVfx', vfx: 'legalWorkDefer', quoteKey: 'legal-work', quoteKind: 'defer' },
            { fx: 'resolveObligation', mode: 'discard' },
          ] },
      ] },
  ],
  quoteKey: 'legal-work', vfx: { attack: 'legalWorkResolve' },
  textKo: '의무 — Obligation. 부스트 ▲2.\n\n제니퍼 월터스 플레이어에게 준다. 알터에고 폼으로 전환할 수 있다. 다음 중 택 1:\n\n• 제니퍼 월터스를 소진한다 → 법률 업무를 게임에서 제거한다.\n• 메인 스킴에 가속(acceleration) 토큰 1개를 놓는다. → 이 의무를 버림.\n\n*"청구서는 미룰 수 있어도, 정의는 미룰 수 없지."*\n\n※ 공식 01160 Legal Work (Core Set #160, She-Hulk 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 소진 옵션 = 영구 해결 · 가속 토큰 = 위협 상승률 영구 증가(빌런 페이즈마다 메인 위협 가속)',
});

/* 개인적 도전(01161) — 사이드 스킴. 타이타니아의 원한. Crisis: 메인 위협 제거 봉쇄. */
MC.defineCardFx('personal-challenge', {
  crisis: true,
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'placeThreat', scheme: 'self', perHero: 1 },
    { fx: 'playVfx', vfx: 'personalChallengeReveal', quoteKey: 'personal-challenge', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'personalChallengeCleared', quoteKey: 'personal-challenge', quoteKind: 'complete' }],
  quoteKey: 'personal-challenge', vfx: { attack: 'personalChallengeReveal' },
  textKo: '사이드 스킴 — She-Hulk 숙적. 시작 위협 3(고정). ⚠ 위기(Crisis).\n\n공개 시: 여기에 위협을 추가로 1/인 놓는다 (솔로: 총 4).\n\n위기(Crisis): 이 스킴이 전장에 있는 동안 메인 스킴에서 위협을 제거할 수 없다.\n\n*"타이타니아가 쉬헐크에게 원한을 품고 있다. 그녀는 이 승부를 끝낼 때까지 쉬지 않는다."*\n\n※ 공식 01161 Personal Challenge (Core Set #161, She-Hulk 넴시스 세트, ×1) — base_threat 3 고정(fixed) · Crisis(공식 정정, hazard 아님)\n※ 처치(위협 제거)해야 메인 스킴 저지 재개 가능 · 우선 처리 필요',
});

/* 타이타니아(01162) — 하수인. 쉬헐크의 숙적. ATK = 현재 HP(동적). 공개 시 교전. */
MC.defineCardFx('titania', {
  atkEqualsHp: true,
  vfx: { entrance: 'titaniaEntrance', minionAttack: 'titaniaAttack', defeat: 'titaniaDefeat' },
  textKo: '하수인 — 브루트(Brute). 정예(Elite). 제니퍼 월터스의 숙적.\nATK X / SCH 1 / HP 6.\n\n지속 효과: X = 타이타니아의 현재 HP. (피해로 HP가 줄면 ATK도 비례해서 감소)\n\n공개 시: 교전.\n\n*"내 점수를 갚을 시간이 됐어, 시-헐크!" —타이타니아*\n\n※ 공식 01162 Titania (Core Set #162, She-Hulk 넴시스 세트, ×1) — ATK 동적(=현재 HP)\n※ HP 6 = ATK 6로 시작. 쪼개서 딜하면 매 턴 강펀치 · 한 번에 처치가 이상적',
});

/* 유전자 강화(01163) — 부착. 최고 인쇄 HP 하수인에 부착 → HP +3(동적 ATK 하수인이면 ATK도 상승). */
MC.defineCardFx('genetic-enhancement', {
  attachStats: { hp: 3, maxHp: 3 },
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'attachToHighestHpMinion', surgeIfNone: true },
    { fx: 'playVfx', vfx: 'geneticEnhanceReveal', quoteKey: 'genetic-enhancement', quoteKind: 'attach' },
  ],
  quoteKey: 'genetic-enhancement', vfx: { attack: 'geneticEnhanceReveal' },
  textKo: '부착물 — Attachment. 상태(Condition). 부스트 ▲1.\n\n공개 시: 인쇄된 HP가 가장 높은 하수인에 부착한다. 그 하수인은 HP +3을 얻는다. 전장에 하수인이 없으면 → 이 카드는 급증(Surge).\n\n*두린 그라임스의 실험이 그녀를 더욱 강하게 만든다.*\n\n※ 공식 01163 Genetically Enhanced (Core Set #163, She-Hulk 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 타이타니아(HP 6)+3 = HP 9 → ATK도 9(동적) · 우선 처치 대상 강화',
});

/* 타이타니아의 분노(01164) — 배신 ×2. 전장의 타이타니아가 히어로 공격, 없으면 회복+surge. */
MC.defineCardFx('titanias-fury', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'titaniaFury' },
    { fx: 'playVfx', vfx: 'titaniasFuryAttack', quoteKey: 'titanias-fury', quoteKind: 'fury' },
  ],
  boostStarEffects: [
    { fx: 'addVillainBoostCard', amount: 1 },
    { fx: 'playVfx', vfx: 'titaniasFuryAttack', quoteKey: 'titanias-fury', quoteKind: 'fury' },
  ],
  quoteKey: 'titanias-fury', vfx: { attack: 'titaniasFuryAttack' }, copies: 2,
  textKo: '배신 — Treachery. 부스트 ★.\n\n공개 시: 타이타니아가 전장에 있으면 그녀가 당신의 히어로를 공격한다. 타이타니아가 공격하지 못했다면 → 타이타니아의 모든 피해를 회복하고 이 카드는 급증(Surge)한다.\n\n★ 부스트: 이 활성화에 빌런의 부스트 카드를 1장 추가한다.\n\n*"내 분노를 느껴봐, 시-헐크!" —타이타니아*\n\n※ 공식 01164 Titania\'s Fury (Core Set #164, She-Hulk 넴시스 세트, ×2) — 공식 JSON 교차검증\n※ 타이타니아(동적 ATK=HP)의 추가 공격 · 부재 시 회복+급증으로 재등장 압박',
});

})(typeof window !== 'undefined' ? window : globalThis);
