/* ═══════════════════════════════════════════════════════════════
   신분(Identity) 능력 등록 — She-Hulk / 아이언맨
   신분 카드는 defineCardFx로 능력/훅을 부착. onFormChange는 flipForm에서 발화.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* She-Hulk 히어로 파워 "Do You Even Lift?": 이 형태(히어로)로 변신 후 → 적에게 2 피해.
   테마(웹): 자신감 넘치는 감마 히어로 — 변신하자마자 힘을 과시. 단일 대상 게임 기준
   빌런에게 자동 적용(교전 하수인 있으면 UI에서 대상 선택 확장 가능). */
MC.HANDLERS.sheHulkPower = function(G, ctx){
  if (ctx.newForm !== 'hero') return;              // 히어로로 변신할 때만
  const target = G.villain;
  if (!target) return;
  MC.applyDamage(G, target, 2, { source: ctx.player, isAttack: true });
  MC.log(G, 'She-Hulk 히어로 파워 — ' + MC.nameOf(target) + '에게 2 피해!');
  G.fxHeroPower = { hero:'she-hulk', vfx:'gammaSlam', targetUid: target.uid };
};
MC.defineCardFx('01019a', { onFormChange: 'sheHulkPower',
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'gammaSmash' },
});

/* 아이언맨 "Tech 업그레이드 1개당 손패 +1 (최대 7)": 조건부 handSize statMod.
   Tech 특성 업그레이드 수를 세어 손패 크기 증가. 최대 7 상한은 statOf에서 처리. */
MC.defineCardFx('01029a', {
  dynamicHandSize: { perTrait: 'tech', cardType: 'upgrade', max: 7 },
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'repulsorBeam' },
});

})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   신분 액션 (라운드 1회) — 캡틴 마블 / 캐롤 / 토니 스타크 / 제니퍼
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 캡틴 마블 Rechannel (01010a, 히어로): 에너지 지불 + 자신 1 회복 → 카드 1장 드로우. */
MC.defineCardFx('01010a', {
  identityAction: {
    name:'Rechannel', form:'hero', oncePerRound:true,
    payEnergy:1, selfHeal:1,
    effect:[{ fx:'draw', amount:1 }],
    vfx:'photonBlast',
  },
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'photonBlast' },
});

/* 캐롤 댄버스 Commander (01010b, 알터에고): 플레이어 1명 카드 1장 드로우 (단일=자신). */
MC.defineCardFx('01010b', {
  identityAction: {
    name:'Commander', form:'alter-ego', oncePerRound:true,
    effect:[{ fx:'draw', amount:1 }],
    vfx:'starInstall',
  },
});

/* 토니 스타크 Futurist (01029b, 알터에고): 덱 위 3장 보고 1장 손에, 나머지 버림.
   결정적 단순화: 맨 위 1장 손에 + 다음 2장 버림 (UI 선택은 차후 확장). */
MC.EFFECTS.tonyFuturist = function(G, p, ctx){
  const pl = ctx.player;
  const looked = [];
  for (let i = 0; i < 3; i++){
    if (pl.deck.length === 0){ MC.onEmptyPlayerDeck(G, pl); if (pl.deck.length===0) break; }
    looked.push(pl.deck.shift());
  }
  if (looked.length){
    pl.hand.push(looked[0]);   // 맨 위 1장 손에
    MC.log(G, 'Futurist — ' + MC.nameOf(looked[0]) + ' 손에 추가');
    for (let i = 1; i < looked.length; i++){ pl.discard.push(looked[i]); }
    if (looked.length > 1) MC.log(G, 'Futurist — 나머지 ' + (looked.length-1) + '장 버림');
    G.fxReveal = { kind:'futurist', cards: looked.map(c=>({defCode:c.defCode,name:MC.nameOf(c)})), kept:0 };
  }
};
MC.defineCardFx('01029b', {
  identityAction: {
    name:'Futurist', form:'alter-ego', oncePerRound:true,
    effect:[{ fx:'tonyFuturist' }],
    vfx:'arcInstall',
  },
});

})(typeof window !== 'undefined' ? window : globalThis);

/* 제니퍼 왈터스 "I Object!" (01019b, 알터에고): 위협 배치 시 1 방지 (라운드 1회).
   변호사 테마 — 이의 제기로 위협을 막음. placeThreat 인터럽트로 자동 처리. */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('01019b', {
  threatPrevent: { name:'I Object!', form:'alter-ego', oncePerRound:true, amount:1 },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   블랙팬서 / 티찰라 (01040a/b) — 코어 세트 신분
   테마(웹 리서치): 와칸다의 왕 — 위엄·절제·전략. 비브라늄 수트는 받은 운동
   에너지를 흡수해 보라색 파동으로 되돌려준다(Retaliate의 시각 테마).
   "나를 공격하는 것은 와칸다를 공격하는 것이다."
   ─ 01040a 블랙팬서(히어로): Retaliate 1 — 공격받은 후 공격자에게 1 피해.
     연출 kineticRebuke: 보라 키네틱 파동 + 표범 발톱 3줄 반격 + SHRAKK!
   ─ 01040b 티찰라(알터에고): Foresight — 셋업: 덱에서 Black Panther 업그레이드
     1장을 손에 넣고 덱 셔플. (결정적 단순화: 덱 순서상 첫 장 — UI 선택은 차후)
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('01040a', {
  retaliate: 1,
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'claws', retaliate:'kineticRebuke' },
});

MC.defineCardFx('01040b', { onSetup: 'runCardEffects',
  onSetupEffects: [{ fx:'searchDeckToHand', filters:[{ type:'upgrade', trait:'black panther' }], logName:'Foresight' }],
});

/* ═══════════════════════════════════════════════════════════════
   캡틴아메리카 03001a/b — 히어로 팩 (mc04)
   히어로: "I Can Do This All Day!" — 행동: 손패 1장 버림 → 캡틴 준비. 라운드당 1회.
   알터에고: 리빙 레전드(첫 동료 비용 -1) + 셋업(캡틴의 방패 손에 추가).
   ═══════════════════════════════════════════════════════════════ */
/* 스티브 로저스 셋업: 덱·버림 더미에서 '캡틴아메리카의 방패'(cap-shield) 업그레이드를 찾아 손에 추가, 덱 셔플. */
MC.defineCardFx('03001a', {
  identityAction: {
    name:'하루 종일도 가능해!', form:'hero', oncePerRound:true,
    discardCost:1,
    effect:[{ fx:'readySelf' }],
    vfx:'capReady',
  },
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'shieldToss' },
});
MC.defineCardFx('03001b', {
  livingLegend: true,
  onSetup: 'runCardEffects',
  onSetupEffects: [{ fx:'searchDeckToHand', filters:[{ mcode:'03009' }], includeDiscard:true, logName:'살아있는 전설 셋업' }],
  vfx: { formChange:'formFlip', basicThwart:'patrol' },
});

/* ═══════════════════════════════════════════════════════════════
   미즈마블 05001a/b — 히어로 팩 (mc05, 카말라 칸)
   히어로 "Morphogenetics": 공격/저지/방어 이벤트 플레이 후 → 소진 → 그 이벤트를 손으로 반환(재사용).
   알터에고 "Teen Spirit": 행동(라운드 1회) — 덱 위에서 미즈마블 카드 나올 때까지 버림 → 손에 추가.
   테마(웹): 저지시티의 열정적인 10대 인휴먼. 신축 폴리모프. "Embiggen!" 외치며 거대화.
   ═══════════════════════════════════════════════════════════════ */
MC.defineCardFx('05001a', {
  afterEventResponse: {
    traits: ['attack', 'thwart', 'defense'],
    vfx: 'morphReturn',
    prompt: '모포제네틱스 — 미즈마블을 소진하고 이 이벤트를 손으로 되돌릴까? (재사용)',
  },
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'embiggen' },
});
MC.defineCardFx('05001b', {
  identityAction: {
    name:'Teen Spirit', form:'alter-ego', oncePerRound:true,
    effect:[{ fx:'discardUntilHeroCard', hero:'ms-marvel' }],
    vfx:'teenSpirit',
  },
  vfx: { formChange:'formFlip', basicThwart:'patrol' },
});

/* ═══════════════════════════════════════════════════════════════
   블랙위도우 08001a/b — 히어로 팩 (mc07/코드 08, 나타샤 로마노프)
   히어로 "Widowmaker": 통제하는 Preparation 카드의 능력을 발동한 후 → 적 1명에게 1 피해 (Response).
   알터에고 "Mission Prep": Preparation 카드를 플레이한 후 → 카드 1장 드로우 (페이즈당 1회, Response).
   테마(웹): KGB 훈련을 받은 전 스파이, 지금은 S.H.I.E.L.D. 요원. 준비(Preparation)로 적의 계획을 미리 무력화.
   ═══════════════════════════════════════════════════════════════ */
MC.defineCardFx('08001a', {
  preparationTrigger: { damage: 1 },
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'widowStrike' },
});
MC.defineCardFx('08001b', {
  afterPlayTrait: { trait:'preparation', form:'alter-ego', effect:[{ fx:'draw', amount:1 }], oncePerPhase:true },
  vfx: { formChange:'formFlip', basicThwart:'patrol' },
});

/* ═══════════════════════════════════════════════════════════════
   닥터 스트레인지 09001a/b — 소서러 슈프림. Invocation(발동 덱) 시스템.
   히어로 "Spell Mastery": 행동 — 닥터 소진 + 발동 덱 맨 위 카드의 Special 능력 해결(→발동덱 버림).
   알터에고 "Natural Talent": 행동(페이즈 1회) — 발동 덱 맨 위 카드 1장 버림.
   테마(웹): 전 신경외과의, 사고 후 카마르타지에서 신비 마법 수련 → 소서러 슈프림. 아가모토의 눈·부양의 망토.
   ═══════════════════════════════════════════════════════════════ */
MC.defineCardFx('09001a', {
  identityAction: { name:'주문 숙련(Spell Mastery)', form:'hero', exhaustSelf:true, effect:[{ fx:'castInvocation' }], vfx:'invocationCast' },
  vfx: { formChange:'formFlip', basicAttack:'mysticBolt' },
});
MC.defineCardFx('09001b', {
  identityAction: { name:'천부적 재능(Natural Talent)', form:'alter-ego', oncePerPhase:true, effect:[{ fx:'naturalTalent' }], vfx:'invocationDiscard' },
  vfx: { formChange:'formFlip' },
});

/* ═══════════════════════════════════════════════════════════════
   호크아이 (Clint Barton) — 04001, The Rise of Red Skull
   히어로 04001a "Quick Draw": Action — 호크아이 소진 → 호크아이의 활(04002) 준비.
     활을 재장전해 화살 이벤트를 연사. exhaustSelf(자기 소진) + readyNamedCard 인덱스.
   알터에고 04001b "Weapon of Choice": Action — 아무 자원 1 소비 → 덱/버림에서 활 서치 → 손 (페이즈당 1회).
     payAny + oncePerPhase + searchDeckToHand 인덱스 재사용.
   테마(웹): 최고의 명궁, 초능력 없이 활 하나로 어벤져스에 선 클린트 바튼. 냉소적 유머, 자신감.
   ═══════════════════════════════════════════════════════════════ */
MC.defineCardFx('04001a', {
  identityAction: {
    name:'Quick Draw', form:'hero',
    exhaustSelf:true,
    effect:[{ fx:'readyNamedCard', mcode:'04002' }],   // 호크아이의 활
    vfx:'quickDraw',
  },
  vfx: { formChange:'formFlip', basicAttack:'strike' },
});
MC.defineCardFx('04001b', {
  identityAction: {
    name:'Weapon of Choice', form:'alter-ego', oncePerPhase:true,
    payAny:1,
    effect:[{ fx:'searchDeckToHand', filters:[{ mcode:'04002' }], includeDiscard:true, logName:'Weapon of Choice' }],
    vfx:'weaponChoice',
  },
  vfx: { formChange:'formFlip' },
});

/* ═══════════════════════════════════════════════════════════════
   토르 06001a/b — 히어로 팩 (mc06)
   히어로 06001a "Have at thee!": Response — 하수인과 교전한 후 카드 2장 드로우 (페이즈당 1회).
     하수인 교전 훅(minionEnteredPlay)에 신분 반응 인덱스(onMinionEngage)로 배선.
   알터에고 06001b "Worthy": Action — 덱·버림에서 묠니르(06009) 업그레이드 서치 → 손 (라운드당 1회).
     searchDeckToHand + oncePerRound 재사용 (캡아 03001b·호크아이 04001b 패턴).
   테마(웹): 오만하지만 고결한 천둥의 신. 고어체 말투("Have at thee!", "I say thee nay!"). 전투를 즐김.
   ═══════════════════════════════════════════════════════════════ */
MC.defineCardFx('06001a', {
  onMinionEngage: {
    name:'Have at thee!', form:'hero', oncePerPhase:true,
    drawCards:2,
    vfx:'haveAtThee',
  },
  vfx: { formChange:'formFlip', basicThwart:'patrol', basicAttack:'thorStrike' },
});
MC.defineCardFx('06001b', {
  identityAction: {
    name:'Worthy', form:'alter-ego', oncePerRound:true,
    effect:[{ fx:'searchDeckToHand', filters:[{ mcode:'06009' }], includeDiscard:true, logName:'Worthy — 묠니르' }],
    vfx:'worthy',
  },
  vfx: { formChange:'formFlip', basicThwart:'patrol' },
});

/* ═══ 헐크 / 브루스 배너 (10001) — 감마 방사선. 격노는 통제 불가. ═══
   Hulk(hero): "격노(Enraged)" — 턴 종료 시 손패 전체 강제 버림 (공용 discardHand + forcedDiscard VFX).
   Bruce Banner(alter-ego): "실험적 연구(Experimental Research)" — 드로우 1 + 손패 1장 선택 버림 (라운드당 1회). */
MC.defineCardFx('10001a', {
  onTurnEnd: [{ fx:'discardHand', reason:'격노!' }],
});
MC.defineCardFx('10001b', {
  identityAction: {
    name:'실험적 연구', form:'alter-ego', oncePerRound:true,
    effect:[{ fx:'draw', amount:1 }, { fx:'discardChooseFromHand', amount:1 }],
  },
});

})(typeof window !== 'undefined' ? window : globalThis);
