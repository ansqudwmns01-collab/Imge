/* ═══════════════════════════════════════════════════════════════
   호크아이(mc04, The Rise of Red Skull) 시그니처 카드 효과 배선 — mcode 오름차순
   ※ 신분 능력(04001a/b)은 mc_cards_zidentity_fx.js. 여기는 시그니처 카드(04002~).
   ※ 이 파일은 db(mc_cards_db.js) 이후 로드되어 defineCardFx로 효과/훅을 병합한다.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 04002 Hawkeye's Bow — 무기 업그레이드(한정). 지속: 히어로 ATK +1 + 화살(Arrow) 공격에 원거리(ranged) 부여.
   statMod{attack} → passiveStatMod 인덱스 재사용(combat-training 동일 패턴). grantsArrowRanged 플래그는
   화살 이벤트가 "활 소진" 시 참조하여 그 공격에 ranged(수호 하수인 무시)를 부여한다. */
MC.defineCardFx('hawkeyes-bow', {
  statMod: { stat:'attack', amount:1 },
  restricted: true,
  grantsArrowRanged: true,
  vfx: { install:'bowInstall' },
});

/* 04003 Hawkeye's Quiver — 아이템 업그레이드. 지속: 부착된 화살(Arrow) 이벤트를 손에 있는 것처럼 플레이 가능.
   히어로 행동: 화살통 소진 → 덱 위 5장에서 화살 이벤트 1장 → 이 카드에 앞면 부착 (나머지 원순서 복귀).
   activatedAbility{exhaust,special} + playCard의 fromQuiver 소스(부착 화살을 손처럼 플레이) 활용. */
MC.defineCardFx('hawkeyes-quiver', {
  activatedAbility: { form:'hero', exhaust:true, special:'quiverSearch' },
  vfx: { install:'quiverInstall', ability:'quiverSearch' },
});

/* 화살통 서치: 덱 위 5장에서 화살(arrow) 이벤트 첫 1장을 화살통에 부착, 나머지는 원순서로 덱 상단 복귀. */
MC.HANDLERS.quiverSearch = function(G, ctx){
  const pl = ctx.player, quiver = ctx.card;
  const look = pl.deck.splice(0, 5);
  const idx = look.findIndex(c => ((MC.cardDef(c.defCode) || {}).traits || []).includes('arrow')
    && (MC.cardDef(c.defCode) || {}).type === 'event');
  if (idx >= 0){
    const arrow = look.splice(idx, 1)[0];
    quiver.attachedArrows = quiver.attachedArrows || [];
    quiver.attachedArrows.push(arrow);
    MC.log(G, '화살통 — ' + MC.nameOf(arrow) + ' 부착 (손처럼 플레이 가능)');
  } else {
    MC.log(G, '화살통 — 상위 5장에 화살 이벤트 없음');
  }
  for (let i = look.length - 1; i >= 0; i--) pl.deck.unshift(look[i]);
};

/* 04004 Mockingbird — 방어 동료(cost3 ATK2/THW2/HP3, 🌟wild). 인터럽트: 빌런이 당신을 공격할 때 →
   아무 자원 1 소비 + 모킹버드 손 반환 → 그 공격 피해 전부 방지. 무한 재활용 방어 동료.
   defenseInterrupt 인덱스 확장 재사용: payAny(자원1) + preventAll(전부 방지) + returnToHand(손 반환). */
MC.defineCardFx('mockingbird-hw', {
  defenseInterrupt: { payAny:1, preventAll:true, returnToHand:true, vfx:'mockingbirdBlock' },
  vfx: { play:'mockingbirdEnter' },
});

})(typeof window !== 'undefined' ? window : globalThis);
