/* ═══════════════════════════════════════════════════════════════
   라이노 세트 — 빌런 라이노 3단계 (Rhino I/II/III)  Core Set #94~96
   1단계(01094): HP 14/영웅 · ATK 2 · SCH 1. 특수 능력 없음 (순수 스탯).
   2단계(01095): HP 15/영웅 · ATK 3 · SCH 1.
     When Revealed: 조우덱·버림에서 "침입 & 약탈" 사이드스킴을 찾아 공개, 조우덱 셔플.
   3단계(01096): HP 16/영웅 · ATK 4 · SCH 1.
     Toughness(등장 시 tough) + When Revealed: 각 히어로 기절.
   ★ 교차검증(core_encounter.json): HP 14/15/16 hpPerHero, ATK 2/3/4, SCH 1 확정.
     seed 데이터 완전 일치. flavor도 기등록.
   ★ 엔진: advanceVillainStage에서 새 단계 whenRevealed 발화 신설. 사이드스킴 특정
     공개 헬퍼(revealSpecificSideScheme) + 전체 히어로 기절.
   연출: 등장=wallBreak(1단계 벽 파괴), 공격=headbutt(박치기).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 사이드스킴 특정 공개는 엔진 공용 헬퍼 MC.revealSpecificSideScheme
   (shards/mc_5_encounter.js) 재사용 — resolveEncounterCard 경유로
   whenRevealed·위협 계산·연출 로그가 모두 정상 발화된다. */
MC.HANDLERS.rhinoStage2Reveal = function(G, ctx){
  MC.revealSpecificSideScheme(G, 'breakin-and-takin');
};

MC.HANDLERS.rhinoStage3Reveal = function(G, ctx){
  const v = ctx.villain || G.villain;
  // Toughness — tough 상태 부여
  MC.setStatus(G, v, 'tough', true);
  MC.log(G, '라이노 3단계 — 강인함(Tough) 획득');
  // 각 히어로 기절
  for (const pl of G.players){
    MC.setStatus(G, pl, 'stunned', true);
  }
  MC.log(G, '라이노 3단계 — 모든 히어로 기절(Stun)');
};

MC.defineCardFx('01095', { whenRevealed: 'rhinoStage2Reveal' });
MC.defineCardFx('01096', { whenRevealed: 'rhinoStage3Reveal' });

/* 쇄도(01106) — 폼 분기 배신. 범용 인덱스로 데이터화.
   알터에고: 이 카드 급증. 히어로: 라이노가 공격, 피해 입은 캐릭터 기절(stunOnHit). */
MC.defineCardFx('stampede', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'formBranch',
    alter: [{ fx: 'surge' }],
    hero:  [{ fx: 'playVfx', vfx: 'rhinoRampage', quoteKey: 'rhino-stampede', quoteKind: 'stampede', target: 'villain' },
            { fx: 'villainAttacks', stunOnHit: true }] }],
  vfx: { attack: 'rhinoRampage' }, quoteKey: 'rhino-stampede',
});

/* 침입 & 약탈(01107) — 사이드 스킴. 공식: 시작 위협 2 + 공개 시 인원수당 +1, 위험(Hazard).
   Hazard는 엔진 공용 처리(dealEnc에서 hazard 사이드 스킴 1장당 조우 카드 +1). 여기선 hazard:true 선언.
   공개(약탈 시작)/완성(저지) 연출·대사 완결 — 모두 범용 인덱스. */
MC.defineCardFx('breakin-and-takin', {
  hazard: true,
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'placeThreat', scheme: 'self', perHero: 1 },
            { fx: 'playVfx', vfx: 'rhinoRansack', quoteKey: 'rhino-ransack', quoteKind: 'reveal' }],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'rhinoRansack', quoteKey: 'rhino-ransack', quoteKind: 'complete' }],
  vfx: { attack: 'rhinoRansack' }, quoteKey: 'rhino-ransack',
});

/* 군중 통제(01108) — 사이드 스킴(Crisis). 공식: 시작 위협 인원수당 2, 위기 아이콘.
   Crisis는 엔진 공용 처리(hasCrisisScheme → 메인 스킴 저지 차단). 여기선 crisis:true 선언.
   공개 시 추가 효과 없음(시작 위협만) — 시민 패닉(공개)/대피(완성) 연출·대사 완결. */
MC.defineCardFx('crowd-control', {
  crisis: true,
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'playVfx', vfx: 'crowdPanic', quoteKey: 'rhino-crowd', quoteKind: 'reveal' }],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'crowdPanic', quoteKey: 'rhino-crowd', quoteKind: 'complete' }],
  vfx: { attack: 'crowdPanic' }, quoteKey: 'rhino-crowd',
});

/* 폭탄 위협(01109) — Bomb Scare 모듈러 세트 사이드 스킴 (라이노 권장 모듈러).
   공식: 시작 위협 2 + 공개 시 인원수당 +1, 가속 아이콘(빌런 페이즈마다 메인 스킴 +1).
   가속은 db accelIcons:1 유지 → 엔진 threat 스텝이 전장 사이드 스킴 가속으로 자동 반영(v162).
   공개(폭탄 발견)/완성(해체) 연출·대사 완결 — 범용 인덱스. */
MC.defineCardFx('bomb-threat', {
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'placeThreat', scheme: 'self', perHero: 1 },
            { fx: 'playVfx', vfx: 'bombScareAlert', quoteKey: 'bomb-scare', quoteKind: 'reveal' }],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'bombDefused', quoteKey: 'bomb-scare', quoteKind: 'complete' }],
  vfx: { attack: 'bombScareAlert' }, quoteKey: 'bomb-scare',
});

/* 폭발!(01111) — Bomb Scare 모듈러 배신. 완전 인덱스 타입(조건 분기 데이터, 커스텀 핸들러 없음).
   공식: 폭탄 위협(bomb-threat)이 전장에 있으면 그 위협 수(X)만큼 피해 분배, 없으면 급증.
   범용 요소: condCheck 'schemeInPlay'(+negate), dealDamage 'amountFromSchemeThreat', target 'firstPlayer'.
   ※ 공식은 "히어로/동료 간 X 피해 자유 분배" — 시뮬은 첫 플레이어에 집중(분배 UI는 추후). */
MC.defineCardFx('explosion', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'dealDamage', target: 'firstPlayer', amountFromSchemeThreat: 'bomb-threat',
      cond: { type: 'schemeInPlay', slug: 'bomb-threat' } },
    { fx: 'playVfx', vfx: 'explosionBlast', quoteKey: 'explosion', quoteKind: 'blast', target: 'firstPlayer',
      cond: { type: 'schemeInPlay', slug: 'bomb-threat' } },
    { fx: 'surge', cond: { type: 'schemeInPlay', slug: 'bomb-threat', negate: true } },   // 폭탄 위협 없으면 급증
    { fx: 'playVfx', vfx: 'fuseSpark', quoteKey: 'explosion', quoteKind: 'fuse',          // 급증 분기 전용 연출/대사
      cond: { type: 'schemeInPlay', slug: 'bomb-threat', negate: true } },
  ],
  vfx: { attack: 'explosionBlast' }, quoteKey: 'explosion',
});
})(typeof window !== 'undefined' ? window : globalThis);