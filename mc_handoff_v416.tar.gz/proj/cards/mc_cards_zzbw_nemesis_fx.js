/* ═══════════════════════════════════════════════════════════════════
   블랙위도우(Black Widow) 네메시스 세트 fx — mcode 08025~08029
   타스크마스터(Taskmaster) 세트: 소각통보(의무)·타스크마스터(하수인)·
   킬러고용(사이드스킴)·히드라용병(하수인×2)·치명적사격(배신)
   ─ db 스탯/텍스트는 mc_cards_db.js, 효과·연출은 이 파일에서 배선.
   ═══════════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
if (!MC || !MC.defineCardFx) return;

/* ─────────────────────────────────────────────────────────────────
   08025 Burn Notice (소각 통보) — 의무. 나타샤 로마노프 플레이어에게 부여.
   공개 시: 알터에고 폼 전환 가능. 택 1:
     ① 나타샤 소진 → 이 카드 게임에서 제거.
     ② 가장 비용 높은 준비(Preparation) 카드 1장 버림. 버릴 준비 카드 없으면 급증. 이 의무 버림.
   범용 재사용: odins-anger 패턴(offerChoice 폼전환 + 택1) + 신규 discardMostExpensivePreparation. */
const _burnMain = {
  prompt: '소각 통보 — 어떻게 대응할 것인가 (택 1)',
  options: [
    { key:'exhaust', label:'나타샤를 소진 → 이 의무를 게임에서 영구 제거',
      availableIf: { type:'identityReady' },
      effects: [ { fx:'exhaustTarget', target:'self' },
                 { fx:'resolveObligation', mode:'game' } ] },
    { key:'discardPrep', label:'가장 비싼 준비 카드 버림(없으면 급증) → 이 의무를 버림',
      effects: [ { fx:'discardMostExpensivePreparation' },
                 { fx:'resolveObligation', mode:'discard', surgeIfNoDiscard:true } ] },
  ],
};
MC.defineCardFx('burn-notice', {
  todoFx: false,
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{
    fx: 'offerChoice',
    prompt: '소각 통보 — 알터에고 폼으로 전환하시겠습니까?',
    options: [
      { key:'flip',   label:'알터에고 폼으로 전환한다',  effects:[ { fx:'flipToAlterEgo' }, { fx:'offerChoice', ..._burnMain } ] },
      { key:'noflip', label:'전환하지 않는다',          effects:[ { fx:'offerChoice', ..._burnMain } ] },
    ],
  }],
  vfx: { entrance:'revealCard' },
});

/* ─────────────────────────────────────────────────────────────────
   08026 Taskmaster (타스크마스터) — 하수인. 히드라·엘리트. ATK 0 / SCH 0 / HP 4. 부스트 ▲2, ★.
   지속: 교전 플레이어의 통제 업그레이드 1장당 ATK +1, SCH +1.
   ★부스트: 통제 업그레이드 수만큼 빌런 ATK/SCH +1 (근사).
   범용: 신규 minionStatScale{atk:1,sch:1} — enemyAtkPassive/enemySchemePassive 중앙 집계. */
MC.defineCardFx('taskmaster-nemesis', {
  todoFx: false,
  minionStatScale: { atk:1, sch:1 },
  vfx: { entrance:'revealCard' },
});

/* ─────────────────────────────────────────────────────────────────
   08027 Killer for Hire (킬러 고용) — 사이드 스킴. 시작 위협 3. ⚡가속(Acceleration).
   공개 시: 여기에 위협 +1 (합계 4). 범용: 신규 addSelfThreat. 가속은 db accelIcons로 자동. */
MC.defineCardFx('killer-for-hire', {
  todoFx: false,
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'addSelfThreat', amount:1 }],
  vfx: { entrance:'revealCard' },
});

/* 08029 Deadly Shot (치명적 사격) — 배신. 부스트 ▲2.
   공개 시 (히어로): 업그레이드/지원 1장 버림 + 1 피해.
   공개 시 (알터에고): 업그레이드/지원 1장 버림 + 메인 스킴 위협 +1.
   범용 재사용: discardUpgradeOrSupport + dealDamage(cond isHeroForm) + placeThreat(cond isAlterEgoForm). */
MC.defineCardFx('deadly-shot', {
  todoFx: false,
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [
    { fx:'discardUpgradeOrSupport' },
    { fx:'dealDamage', target:'self', amount:1, cond:{ type:'isHeroForm' } },
    { fx:'placeThreat', scheme:'main', amount:1, cond:{ type:'isAlterEgoForm' } },
  ],
  vfx: { entrance:'revealCard' },
});

})(typeof window !== 'undefined' ? window : globalThis);
