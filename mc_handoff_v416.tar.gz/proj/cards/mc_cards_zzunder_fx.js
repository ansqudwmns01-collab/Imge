/* ═══════════════════════════════════════════════════════════════
   Under Attack 모듈러 인카운터 세트 — Core Set #151~154
   특정 빌런이 아닌 범용 모듈러 세트 (여러 시나리오에 추가 — 울트론 권장 모듈러 등).
   민간인이 공격받는 긴급 상황 + 빌런 강화 부착물 + 광역 피해 배신.

   01151 공격 받는 중 (Under Attack) — 사이드 스킴 ×1, 시작 위협 3(고정), 부스트 3
     · 공개 시: 각 플레이어가 여기에 위협 2를 놓거나, 자기 히어로에 피해 3을 준다
   ★ 엔진: EFFECTS.eachPlayerChoice(각 플레이어 순차 선택 체인) + flushEachChoice — 이번 신설.
   연출: underAttackReveal(민간인 위기)/underAttackCleared(위기 해소), 대사 reveal/complete 각 5.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 공격 받는 중(01151) — 사이드 스킴. 각 플레이어 선택(위협2 or 히어로 피해3). 완전 인덱스 타입. */
MC.defineCardFx('under-attack', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'eachPlayerChoice',
      prompt: '공격 받는 중 — 여기에 위협 2를 놓거나, 자기 히어로에 피해 3을 받으세요',
      options: [
        { key: 'threat', label: '여기에 위협 2', effects: [{ fx: 'placeThreat', scheme: 'self', amount: 2 }] },
        { key: 'damage', label: '내 히어로에 피해 3', effects: [{ fx: 'dealDamage', target: 'self', amount: 3 }] },
      ] },
    { fx: 'playVfx', vfx: 'underAttackReveal', quoteKey: 'under-attack', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'underAttackCleared', quoteKey: 'under-attack', quoteKind: 'complete' }],
  vfx: { attack: 'underAttackReveal' }, quoteKey: 'under-attack',
  textKo: '사이드 스킴. 시작 위협: 3.\n\n공개 시: 각 플레이어는 이곳에 위협 2를 놓거나, 자기 히어로에게 피해 3을 준다.\n\n*민간인들이 공격받고 있다. 당장 도움이 필요하다!*\n\n※ 공식 01151 Under Attack (Core Set #151, Under Attack 모듈러 세트, ×1) — base_threat 3(고정) (공식 JSON 교차검증)\n※ 각 플레이어 순차 선택 · 위협 제거로 처치(완성 효과 없음)',
});

/* 비브라늄 갑옷(01152) — 빌런 부착물(Armor). 완전 인덱스 타입.
   강제반응: 빌런이 피해를 받은 후(생존 시) tough 부여(grantsToughOnDamage — applyDamage 배선).
   히어로 행동: 소진 + 💪💪 → 제거. */
MC.defineCardFx('vibranium-armor-u', {
  grantsToughOnDamage: true,
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'playVfx', vfx: 'vibraniumArmorInstall', quoteKey: 'under-attack-armor', quoteKind: 'armor' }],
  removeAbility: { exhaustHero: true, payIcons: { physical: 2 } },
  vfx: { retaliate: 'vibraniumArmorRetough' },
  textKo: '부착물 — Armor. 부스트 ▲1.\n\n빌런에게 부착한다.\n\n강제 반응: 빌런이 피해를 받은 후 → 빌런에게 강인함(Tough) 상태 카드를 준다.\n\n히어로 행동: 자신의 히어로를 소진하고 💪💪 자원을 지불한다 → 이 카드를 버린다.\n\n※ 공식 01152 Vibranium Armor (Core Set #152, Under Attack 모듈러, ×1) — 공식 JSON 교차검증\n※ 매 피해 후 tough 재생성(빌런 생존 시) — 뚫기 어려워짐 · 제거로 강제반응 해제',
});

/* 충격파 블라스터(01153) — 빌런 부착물(Weapon). 완전 인덱스 타입.
   빌런에게 보복(Retaliate) 1 부여(attachStats.retaliate — 기존 보복 시스템 재사용).
   히어로 행동: 소진 + ⚡⚡ → 제거. */
MC.defineCardFx('concussion-blasters', {
  attachStats: { retaliate: 1 },
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'playVfx', vfx: 'concussionBlastersInstall', quoteKey: 'under-attack-armor', quoteKind: 'blaster' }],
  removeAbility: { exhaustHero: true, payIcons: { energy: 2 } },
  vfx: { retaliate: 'concussionBlastersRetaliate' },
  textKo: '부착물 — Weapon. 부스트 ▲1.\n\n빌런에게 부착한다. 빌런은 보복(Retaliate) 1을 얻는다.\n\n히어로 행동: 자신의 히어로를 소진하고 ⚡⚡ 자원을 지불한다 → 이 카드를 버린다.\n\n※ 공식 01153 Concussion Blasters (Core Set #153, Under Attack 모듈러, ×1) — 공식 JSON 교차검증\n※ 보복 1: 빌런이 공격받아 피해를 입으면 공격한 캐릭터에 1 피해 · 제거로 해제',
});

/* 충격파 폭발(01154) — 배신 ×2. 광역 피해. 완전 인덱스 타입.
   공개 시: 각 우호 캐릭터에 1 피해(allFriendly). ★부스트: 통제 캐릭터에 각 1 피해(controlled). */
MC.defineCardFx('concussive-blast', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'dealDamage', target: 'allFriendly', amount: 1, isAttack: false },
    { fx: 'playVfx', vfx: 'concussiveBlast', quoteKey: 'concussive-blast', quoteKind: 'reveal' },
  ],
  boostStarEffects: [
    { fx: 'dealDamage', target: 'controlled', amount: 1, isAttack: false },
    { fx: 'playVfx', vfx: 'concussiveBlast', quoteKey: 'concussive-blast', quoteKind: 'reveal' },
  ],
  vfx: { attack: 'concussiveBlast' }, quoteKey: 'concussive-blast', copies: 2,
  textKo: '배신 — Treachery. 부스트 ▲★.\n\n공개 시: 각 우호 캐릭터에게 피해 1을 준다.\n\n★ 부스트: 당신이 통제하는 각 캐릭터에게 피해 1을 준다.\n\n※ 공식 01154 Concussive Blast (Core Set #154, Under Attack 모듈러, ×2) — 공식 JSON 교차검증\n※ 우호 캐릭터 = 모든 플레이어 히어로 + 동료 · 부스트★ = 부스트 뽑은 플레이어의 히어로 + 동료',
});

})(typeof window !== 'undefined' ? window : globalThis);
