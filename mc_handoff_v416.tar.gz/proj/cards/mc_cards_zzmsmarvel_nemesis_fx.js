/* ═══════════════════════════════════════════════════════════════
   미즈마블(mc05) 네메시스 세트 효과 배선 — 05025~05029
   ※ db(mc_cards_db.js) 이후 로드. defineCardFx로 효과/훅 병합.
   ※ 공통 인덱스(신규): discardPersonaSupport / millPerAllyAndPersona /
      exhaustPersonaHealVillain (mc_2_effects), invulnWhileOtherMinion /
      invulnUnlessNullified (mc_6_keywords), nullifiedThisPhase 리셋(mc_5).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 05025 Home by Dawn (새벽까지 귀가) — 의무(Obligation). 부스트 ▲1. 카말라 칸에게 부여.
   공개 시: 알터에고 폼으로 전환 가능. 택 1:
   • 카말라 칸 소진 → 이 의무를 게임에서 제거.
   • 페르소나(Persona) 지원 1장 버림. 없으면 급증. 이 의무 버림.
   [의무 인덱스 재사용] offerChoice(flip) → _hbdMain(택1). man-out-of-time 패턴. */
const _hbdMain = {
  prompt: '새벽까지 귀가 — 어떻게 감당할 것인가 (택 1)',
  options: [
    { key:'exhaust', label:'카말라 칸을 소진 → 이 의무를 게임에서 영구 제거',
      availableIf: { type:'identityReady' },
      effects: [ { fx:'exhaustTarget', target:'self' },
                 { fx:'playVfx', vfx:'revealCard', quoteKey:'home-by-dawn', quoteKind:'duty' },
                 { fx:'resolveObligation', mode:'game' } ] },
    { key:'discardPersona', label:'페르소나 지원 1장 버림 (없으면 급증) → 이 의무를 버림',
      effects: [ { fx:'playVfx', vfx:'revealCard', quoteKey:'home-by-dawn', quoteKind:'defer' },
                 { fx:'discardPersonaSupport' },
                 { fx:'resolveObligation', mode:'discard', surgeIfNoDiscard:true } ] },
  ],
};
MC.defineCardFx('home-by-dawn', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{
    fx: 'offerChoice',
    prompt: '새벽까지 귀가 — 알터에고 폼으로 전환하시겠습니까?',
    options: [
      { key:'flip',   label:'알터에고 폼으로 전환한다',   effects:[ { fx:'flipToAlterEgo' }, { fx:'offerChoice', ..._hbdMain } ] },
      { key:'noflip', label:'전환하지 않는다',           effects:[ { fx:'offerChoice', ..._hbdMain } ] },
    ],
  }],
  vfx: { entrance:'revealCard' },
});

/* 05026 Generation Why? (제너레이션 와이?) — 사이드 스킴. 시작 위협 2/인.
   공개 시: 전장의 각 동료(ally) + 페르소나(Persona) 지원마다 각 플레이어 덱 맨 위 1장 버림.
   [신규 인덱스] millPerAllyAndPersona. */
MC.defineCardFx('generation-why', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'millPerAllyAndPersona' }],
  vfx: { entrance:'revealCard' },
});

/* 05027 Thomas Edison (토마스 에디슨) — 하수인. 새(Bird)·천재(Genius). ATK 1 / SCH 3 / HP 3.
   지속: 다른 하수인과 교전 중이면 피해를 받지 않음.
   [신규 패시브] invulnWhileOtherMinion. 부리로 쪼고 전선을 휘두르는 새-인간 하이브리드. */
MC.defineCardFx('thomas-edison', {
  invulnWhileOtherMinion: true,
  vfx: { entrance:'revealCard', attack:'gunshot' },
  quoteKey: 'thomas-edison',
});

/* 05028 Edison's Giant Robot (에디슨의 거대 로봇) — 하수인. 로봇(Robot). ATK 2 / SCH 1 / HP 8.
   지속: 피해를 받지 않음.
   히어로 행동: 🧠 멘탈 1 → 페이즈 끝까지 텍스트 무효화(nullifiedThisPhase → 피해 가능).
   [신규 패시브] invulnUnlessNullified + 무효화 히어로 액션(special). */
MC.defineCardFx('edisons-giant-robot', {
  invulnUnlessNullified: true,
  activatedAbility: { form:'hero', payCost:{ type:'mental', count:1 }, special:'nullifyRobot',
    label:'🧠 무효화' },
  vfx: { entrance:'revealCard', attack:'wallBreak' },
  quoteKey: 'edisons-giant-robot',
});

/* 05029 Harvest (수확) — 배신(Treachery). ×2.
   공개 시: 전장의 각 페르소나 지원 소진. 소진 수만큼 빌런 회복. 아무 지원도 소진 안 됐으면 급증.
   [신규 인덱스] exhaustPersonaHealVillain. */
MC.defineCardFx('harvest', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'exhaustPersonaHealVillain' }],
  vfx: { entrance:'revealCard' },
});

})(typeof window !== 'undefined' ? window : globalThis);
