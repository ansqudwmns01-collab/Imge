/* ═══════════════════════════════════════════════════════════════
   위플래시 넴시스 세트 (아이언맨/토니 스타크) — Core Set #170~
   토니 스타크의 개인 조우 카드. 스타크 인더스트리 경영난과 위플래시의 공격.
   아이언맨 시그니처는 이미 완료.

   01170 사업 문제 (Business Problems) — 의무(Obligation) ×1, 부스트 ▲1
     · 공개 시: 토니 스타크 플레이어에게. 알터에고 전환 가능. 택 1:
       ① 토니 스타크 소진 → 이 카드 게임에서 제거
       ② 통제하는 모든 업그레이드 소진 → 이 의무 버림
   ★ 엔진: offerChoice + exhaustTarget/resolveObligation(기존) + exhaustAllUpgrades(이번 신설).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 사업 문제(01170) — 의무. 스타크 인더스트리 경영 현안. */
MC.defineCardFx('business-problems', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'offerChoice', prompt: '사업 문제 — 스타크 인더스트리 현안을 어떻게 처리할 것인가 (택 1)',
      options: [
        { key: 'exhaust', label: '토니 스타크를 소진 → 이 의무를 게임에서 제거',
          effects: [
            { fx: 'exhaustTarget', target: 'self' },
            { fx: 'playVfx', vfx: 'businessProblemsResolve', quoteKey: 'business-problems', quoteKind: 'duty' },
            { fx: 'resolveObligation', mode: 'game' },
          ] },
        { key: 'exhaustUpgrades', label: '통제하는 모든 업그레이드 소진 → 이 의무를 버림',
          effects: [
            { fx: 'exhaustAllUpgrades' },
            { fx: 'playVfx', vfx: 'businessProblemsDefer', quoteKey: 'business-problems', quoteKind: 'defer' },
            { fx: 'resolveObligation', mode: 'discard' },
          ] },
      ] },
  ],
  quoteKey: 'business-problems', vfx: { attack: 'businessProblemsResolve' },
  textKo: '의무 — Obligation. 부스트 ▲1.\n\n토니 스타크 플레이어에게 준다. 알터에고 폼으로 전환할 수 있다. 다음 중 택 1:\n\n• 토니 스타크를 소진한다 → 사업 문제를 게임에서 제거한다.\n• 통제하는 모든 업그레이드를 소진한다. → 이 의무를 버림.\n\n*"이사회, 투자자, 기자회견… 아이언맨보다 이게 더 골치 아파."*\n\n※ 공식 01170 Business Problems (Core Set #170, Iron Man 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 소진 = 영구 해결 · 업그레이드 전체 소진 = 아머 일시 정지(방어·능력 사용 불가) 대가로 회피',
});

/* 임박한 과부하(01171) — 사이드 스킴. 가속. 위플래시의 에너지 폭주. 시작 3 + 공개 시 +1/인. */
MC.defineCardFx('imminent-overload', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'placeThreat', scheme: 'self', perHero: 1 },
    { fx: 'playVfx', vfx: 'imminentOverloadReveal', quoteKey: 'imminent-overload', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'imminentOverloadCleared', quoteKey: 'imminent-overload', quoteKind: 'complete' }],
  quoteKey: 'imminent-overload', vfx: { attack: 'imminentOverloadReveal' },
  textKo: '사이드 스킴 — 시작 위협 3(고정). ⚡ 가속(Acceleration).\n\n공개 시: 여기에 위협을 추가로 1/인 놓는다 (솔로: 총 4).\n\n*"에너지 수치가 임계점을 넘어선다 — 곧 과부하가 터질 거야!"*\n\n※ 공식 01171 Imminent Overload (Core Set #171, Iron Man 넴시스 세트, ×1) — base_threat 3 고정 · 가속 아이콘 1\n※ 가속으로 빌런 페이즈마다 메인 위협 상승 압박 · 우선 처치 권장',
});

/* 위플래시(01172) — 하수인. 반격 1(Retaliate). 전기 채찍의 복수자, 아이언맨의 숙적. */
MC.defineCardFx('whiplash', {
  vfx: { entrance: 'whiplashEntrance', minionAttack: 'whiplashAttack', defeat: 'whiplashDefeat' },
  textKo: '하수인.\nATK 3 / SCH 2 / HP 4.\n\n반격 1(Retaliate): 이 캐릭터가 공격받은 후, 공격한 캐릭터에게 1 피해를 준다.\n\n*"스타크… 네 아버지가 우리 가족에게 진 빚을 갚아주지."*\n\n※ 공식 01172 Whiplash (Core Set #172, Iron Man 넴시스 세트, ×1) — Retaliate 1 (db 필드로 applyDamage 자동 처리)\n※ 근접 공격 시 1 반격 피해 주의 · 원거리/이벤트로 처치 권장',
});

/* 전기 채찍 공격(01173) — 배신 ×2. 택1: 업그레이드 수만큼 피해 / 업그레이드 1장 버림. */
MC.defineCardFx('electric-whip-attack', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'offerChoice', prompt: '전기 채찍 공격 — 채찍이 아머를 노린다 (택 1)',
      options: [
        { key: 'damage', label: '통제 업그레이드 수만큼 내 히어로에 피해',
          effects: [
            { fx: 'dealDamage', target: 'self', amountFrom: 'upgradeCount' },
            { fx: 'playVfx', vfx: 'electricWhipStrike', quoteKey: 'electric-whip-attack', quoteKind: 'strike' },
          ] },
        { key: 'discard', label: '통제 업그레이드 1장 버림',
          effects: [
            { fx: 'discardControlledUpgrade' },
            { fx: 'playVfx', vfx: 'electricWhipStrike', quoteKey: 'electric-whip-attack', quoteKind: 'strike' },
          ] },
      ] },
  ],
  boostStarEffects: [
    { fx: 'discardControlledUpgrade' },
    { fx: 'playVfx', vfx: 'electricWhipStrike', quoteKey: 'electric-whip-attack', quoteKind: 'strike' },
  ],
  quoteKey: 'electric-whip-attack', vfx: { attack: 'electricWhipStrike' }, copies: 2,
  textKo: '배신 — Treachery. 부스트 ★.\n\n공개 시: 택 1 — 통제하는 업그레이드 1장당 히어로에게 1 피해를 주거나, 통제하는 업그레이드 1장을 선택해 버린다.\n\n★ 부스트: 빌런이 방어 없는 공격을 하는 중이면, 통제하는 업그레이드 1장을 선택해 버린다.\n\n*"네 값비싼 장난감들, 하나씩 부숴주지."*\n\n※ 공식 01173 Electric Whip Attack (Core Set #173, Iron Man 넴시스 세트, ×2) — 공식 JSON 교차검증\n※ 아머(업그레이드) 의존 영웅에 치명타 · 피해 vs 장비 손실 선택',
});

/* 전자기 반발(01174) — 배신. 각 플레이어 덱 top 5장 버림 → 에너지 자원 수만큼 피해. */
MC.defineCardFx('electromagnetic-backlash', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'discardTopEnergyDamage', count: 5 },
    { fx: 'playVfx', vfx: 'electromagneticBacklashReveal', quoteKey: 'electromagnetic-backlash', quoteKind: 'reveal' },
  ],
  quoteKey: 'electromagnetic-backlash', vfx: { attack: 'electromagneticBacklashReveal' },
  textKo: '배신 — Treachery. 부스트 ▲2.\n\n공개 시: 각 플레이어는 자신의 덱 맨 위 5장을 버린다. 이렇게 버린 카드 중 인쇄된 에너지(⚡) 자원 1개당, 그 플레이어는 1 피해를 받는다.\n\n*"전자기장이 폭주한다 — 네 에너지가 곧 네 무덤이 될 거야!"*\n\n※ 공식 01174 Electromagnetic Backlash (Core Set #174, Iron Man 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 에너지 자원 위주 덱(아이언맨 등)에 큰 피해 · 덱 소모 + 직접 피해',
});

})(typeof window !== 'undefined' ? window : globalThis);
