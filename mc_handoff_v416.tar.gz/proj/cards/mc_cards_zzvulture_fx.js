/* ═══════════════════════════════════════════════════════════════
   벌처 넴시스 세트 (스파이더맨/피터 파커) — Core Set #165~
   피터 파커의 개인 조우 카드. 재정난·집세 압박과 벌처의 습격.
   스파이더맨 시그니처는 이미 완료.

   01165 퇴거 통지 (Eviction Notice) — 의무(Obligation) ×1, 부스트 ▲1
     · 공개 시: 피터 파커 플레이어에게. 알터에고 전환 가능. 택 1:
       ① 피터 파커 소진 → 이 카드 게임에서 제거
       ② 손패 무작위 1장 버림 + 이 카드 급증(Surge) → 이 의무 버림
   ★ 엔진: offerChoice + exhaustTarget/resolveObligation/discardFromHand/surge(기존).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 퇴거 통지(01165) — 의무. 피터 파커의 재정난(집세 체납). */
MC.defineCardFx('eviction-notice', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'offerChoice', prompt: '퇴거 통지 — 밀린 집세를 어떻게 할 것인가 (택 1)',
      options: [
        { key: 'exhaust', label: '피터 파커를 소진 → 이 의무를 게임에서 제거',
          effects: [
            { fx: 'exhaustTarget', target: 'self' },
            { fx: 'playVfx', vfx: 'evictionNoticeResolve', quoteKey: 'eviction-notice', quoteKind: 'duty' },
            { fx: 'resolveObligation', mode: 'game' },
          ] },
        { key: 'discard', label: '손패 무작위 1장 버림 + 급증 → 이 의무를 버림',
          effects: [
            { fx: 'discardFromHand', amount: 1 },
            { fx: 'surge' },
            { fx: 'playVfx', vfx: 'evictionNoticeDefer', quoteKey: 'eviction-notice', quoteKind: 'defer' },
            { fx: 'resolveObligation', mode: 'discard' },
          ] },
      ] },
  ],
  quoteKey: 'eviction-notice', vfx: { attack: 'evictionNoticeResolve' },
  textKo: '의무 — Obligation. 부스트 ▲1.\n\n피터 파커 플레이어에게 준다. 알터에고 폼으로 전환할 수 있다. 다음 중 택 1:\n\n• 피터 파커를 소진한다 → 퇴거 통지를 게임에서 제거한다.\n• 손패에서 무작위로 1장을 버린다. 이 카드는 급증(Surge)을 얻는다. → 이 의무를 버림.\n\n*"집세는 밀렸고, 도시는 날 필요로 하고… 하루가 너무 짧아."*\n\n※ 공식 01165 Eviction Notice (Core Set #165, Spider-Man 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 소진 = 영구 해결 · 손패 버림 = 급증(추가 조우) 대가로 회피',
});

/* 노상 강도(01166) — 사이드 스킴. 가속. 각 손패 1장 강탈 보관 → 처치 시 반환. */
MC.defineCardFx('highway-robbery', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'storeRandomFromEachHand' },
    { fx: 'playVfx', vfx: 'highwayRobberyReveal', quoteKey: 'highway-robbery', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [
    { fx: 'returnStoredCards' },
    { fx: 'playVfx', vfx: 'highwayRobberyCleared', quoteKey: 'highway-robbery', quoteKind: 'complete' },
  ],
  quoteKey: 'highway-robbery', vfx: { attack: 'highwayRobberyReveal' },
  textKo: '사이드 스킴 — 시작 위협 3/인. ⚡ 가속(Acceleration).\n\n공개 시: 각 플레이어는 자신의 손패에서 무작위 카드 1장을 여기에 뒷면으로 놓는다.\n\n해결 시: 여기 놓인 각 뒷면 카드를 원래 소유자의 손으로 되돌린다.\n\n*"벌처가 도시를 털고 다닌다. 그의 손아귀에서 뭐든 사라지지."*\n\n※ 공식 01166 Highway Robbery (Core Set #166, Spider-Man 넴시스 세트, ×1) — 가속 아이콘 1\n※ 손패 강탈(임시 카드 봉인) → 처치로 회수 · 가속으로 위협 상승 압박',
});

/* 벌처(01167) — 하수인. 빠른 공격(Quickstrike). 노회한 비행 악당, 스파이더맨의 숙적. */
MC.defineCardFx('vulture', {
  quickstrike: true,
  vfx: { entrance: 'vultureEntrance', minionAttack: 'vultureAttack', defeat: 'vultureDefeat' },
  textKo: '하수인 — 크리미널(Criminal).\nATK 3 / SCH 1 / HP 4.\n\n빠른 공격(Quickstrike): 이 하수인이 당신의 히어로와 교전한 직후, 즉시 공격한다.\n\n*"스파이더맨은 끝이야 — 이 하늘은 내 것이다."*\n\n※ 공식 01167 Vulture (Core Set #167, Spider-Man 넴시스 세트, ×1) — Quickstrike 키워드\n※ 교전 즉시 3딜 → 빠른 처치 필요 · 방어/저지 타이밍 주의',
});

/* 급강하 습격(01168) — 배신 ×2. 벌처의 기습. 히어로 기절 + 벌처 전장 시 급증. */
MC.defineCardFx('sweeping-swoop', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'applyStatus', target: 'self', status: 'stunned' },
    { fx: 'playVfx', vfx: 'sweepingSwoopStrike', quoteKey: 'sweeping-swoop', quoteKind: 'strike' },
    { fx: 'surge', cond: { type: 'enemyInPlay', slug: 'vulture' } },
  ],
  boostStarEffects: [
    { fx: 'setBoostStunOnDamage' },
    { fx: 'playVfx', vfx: 'sweepingSwoopStrike', quoteKey: 'sweeping-swoop', quoteKind: 'strike' },
  ],
  quoteKey: 'sweeping-swoop', vfx: { attack: 'sweepingSwoopStrike' }, copies: 2,
  textKo: '배신 — Treachery. 부스트 ★.\n\n공개 시: 당신의 히어로를 기절(Stun)시킨다. 벌처가 전장에 있으면 이 카드는 급증(Surge)을 얻는다.\n\n★ 부스트: 이 활성화가 우호 캐릭터에게 피해를 주면, 그 캐릭터를 기절시킨다.\n\n*"위에서 덮친다 — 넌 날 볼 수도 없어!"*\n\n※ 공식 01168 Sweeping Swoop (Core Set #168, Spider-Man 넴시스 세트, ×2) — 공식 JSON 교차검증\n※ 벌처 존재 시 급증(추가 조우) · 부스트★로 공격 시 기절 연계',
});

/* 벌처의 계략(01169) — 배신. 각 손패 무작위 1장 버림 → 자원 종류 수만큼 메인 위협. */
MC.defineCardFx('vultures-plans', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'discardRandomCountResources' },
    { fx: 'playVfx', vfx: 'vulturesPlansReveal', quoteKey: 'vultures-plans', quoteKind: 'reveal' },
  ],
  quoteKey: 'vultures-plans', vfx: { attack: 'vulturesPlansReveal' },
  textKo: '배신 — Treachery. 부스트 ▲2.\n\n공개 시: 각 플레이어의 손패에서 무작위 카드 1장을 버린다. 이렇게 버려진 카드들의 서로 다른 자원 종류(물리/정신/에너지/와일드) 수만큼 메인 스킴에 위협을 놓는다.\n\n*"모든 계획은 이미 준비됐다. 넌 그저 추락할 일만 남았어."*\n\n※ 공식 01169 The Vulture\'s Plans (Core Set #169, Spider-Man 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 버린 카드의 자원 다양성이 클수록 위협 증가(최대 4) · 손패 손실 + 메인 가속',
});

})(typeof window !== 'undefined' ? window : globalThis);
