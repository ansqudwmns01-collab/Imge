/* ═══════════════════════════════════════════════════════════════
   MVC02 그린 고블린 — Mutagen Formula 시나리오 fx
   단면 그린 고블린(폼전환 없음) + 고블린 하수인 군단. 뮤타젠으로 시민을
   고블린으로 변이시킨다. 다수 카드가 "고블린 하수인 수"에 비례해 강화.

   ★ 이 파일은 정확도 확실한 것부터 순차 배선 (공식 gob_encounter.json 기준).
     현재: 고블린 소환 하수인(Goblin Soldier/Thrall) — 부스트★ 전장 배치 + 처치 효과.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 02023 Goblin Soldier — 부스트★: 교전 상태로 전장 배치 / 처치 시: 교전 플레이어에 피해 1.
   ★ 인덱스 재사용: boostStarPutIntoPlay(minion) + whenDefeatedEffects(dealDamage engagedPlayer). */
MC.defineCardFx('goblin-soldier', {
  boostStarPutIntoPlay: true,
  vfx:{ attack:'goblinSoldierStrike' },
  whenDefeated: 'runCardEffects',
  whenDefeatedEffects: [{ fx:'dealDamage', target:'engagedPlayer', amount:1 }],
});

/* 02024 Goblin Thrall — Guard(기존 데이터) + 부스트★: 교전 상태로 전장 배치.
   ★ 인덱스 재사용: boostStarPutIntoPlay(minion). */
MC.defineCardFx('goblin-thrall', {
  boostStarPutIntoPlay: true,
  vfx:{ attack:'goblinThrallStrike' },
});

/* 각 플레이어에게 조우 카드 N장 배분 (빌런 02015/02016 WR). dealEncounterTo 재사용. */
MC.EFFECTS.dealEncounterEachPlayer = function(G, p, ctx){
  const n = (p && p.amount) || 1;
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    MC.dealEncounterTo(G, pl, n);
  }
  MC.log(G, '그린 고블린 — 각 플레이어에게 조우 카드 ' + n + '장 배분');
};

/* 02025 Monster — WR: 당신은 기절. 이미 기절 상태면 대신 피해 2. */
MC.defineCardFx('monster', {
  vfx:{ attack:'monsterStrike' },
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[
    { fx:'dealDamage', target:'self', amount:2, cond:{ type:'targetStatus', target:'self', status:'stunned' } },
    { fx:'applyStatus', target:'self', status:'stunned' },
  ],
});

/* 플레이어 폼 조건부 When Revealed — def.whenRevealedByPlayerForm[플레이어 폼] 실행.
   룰북 "When Revealed (Hero)" / "(Alter-Ego)" 패턴을 인덱스로 (Risky Business 빌런폼 게이트의 플레이어 버전). */
MC.HANDLERS.goblinPlayerFormReveal = function(G, ctx){
  const self = ctx.self;
  const def = (self && self.defCode && MC.cardDef(self.defCode)) || self;
  const pl = ctx.player || G.players[G.firstPlayer];
  const form = pl && pl.form;   // 'hero' | 'alter-ego'
  const list = def && def.whenRevealedByPlayerForm && def.whenRevealedByPlayerForm[form];
  if (!list){ MC.log(G, MC.nameOf(self) + ' — 현재 플레이어 폼(' + form + ') 공개 효과 없음'); return; }
  MC.runEffectList(G, list, { player: pl, card: self, self });
};

/* 02029 Death from Above — WR(알터에고): GG 암약 +스테이지 SCH / WR(히어로): GG 공격 +스테이지 ATK */
MC.defineCardFx('death-from-above', {
  whenRevealed:'goblinPlayerFormReveal',
  whenRevealedByPlayerForm:{
    'alter-ego':[{ fx:'villainSchemes', scheme:'main', bonusFrom:'villainStage' }],
    'hero':[{ fx:'villainAttacks', bonusFrom:'villainStage' }],
  },
});

/* 전장의 고블린(trait) 하수인 수 (교전 중인 모든 하수인 스캔). 다수 카드가 이 수에 비례. */
MC.goblinMinionCount = function(G){
  let n = 0;
  for (const pl of G.players)
    for (const m of (pl.engagedMinions || []))
      if (((MC.cardDef(m.defCode) || {}).traits || []).includes('goblin')) n++;
  return n;
};

/* 02026 Goblin Reinforcements — WR: 전장의 고블린 하수인 1마리당 이 스킴에 위협 +1. */
MC.defineCardFx('goblin-reinforcements', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'threatHere', amountFrom:'goblinMinions' }],
});

/* ── 하수인 전장 배치 헬퍼 (boostStarPutIntoPlay 배치 로직과 동일) ── */
MC.goblinPutMinion = function(G, slug, pl){
  const m = MC.makeInstance(G, slug, {});
  const def = MC.cardDef(slug) || {};
  m.engagedWith = pl.uid;
  pl.engagedMinions.push(m);
  m.status = m.status || { stunned:0, confused:0, tough: def.toughness ? 1 : 0 };
  if (MC.minionEnteredPlay) MC.minionEnteredPlay(G, m, pl);
  MC.log(G, MC.nameOf(m) + ' — ' + pl.uid + '와(과) 교전 상태로 전장 등장');
  return m;
};

/* 전장의 고블린 "적" 수 = 고블린 하수인 + 고블린 빌런(그린 고블린 포함). 02018b 가속 X. */
MC.goblinEnemyCount = function(G){
  let n = MC.goblinMinionCount ? MC.goblinMinionCount(G) : 0;
  const vd = G.villain && MC.cardDef(G.villain.defCode);
  if (vd && (vd.traits || []).includes('goblin')) n += 1;
  return n;
};

/* ── 메인 스킴: Unleashing the Mutagen (02017) ── */
/* 셋업(02017b onSetup): 각 플레이어와 교전 상태로 Goblin Thrall 배치. 게임은 1B에서 시작. */
MC.HANDLERS.mutagenSetup = function(G, ctx){
  for (const pl of MC.playersInOrder(G)) MC.goblinPutMinion(G, 'goblin-thrall', pl);
  MC.log(G, 'Mutagen Formula 셋업 — 각 플레이어에 Goblin Thrall 배치');
};
/* 완료(02017b): 고블린 하수인과 교전 중이 아닌 각 플레이어 → 조우덱 3장 버리고 첫 고블린 하수인 전장 배치. */
MC.EFFECTS.mutagenDiscardSummon = function(G, p, ctx){
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    const hasGoblin = (pl.engagedMinions || []).some(m => ((MC.cardDef(m.defCode)||{}).traits||[]).includes('goblin'));
    if (hasGoblin) continue;
    let summoned = false;
    for (let i = 0; i < 3; i++){
      const c = MC.drawEncounterCard(G);
      if (!c) break;
      const cd = MC.cardDef(c.defCode) || {};
      if (!summoned && cd.type === 'minion' && (cd.traits||[]).includes('goblin')){
        c.engagedWith = pl.uid; pl.engagedMinions.push(c);
        c.status = c.status || { stunned:0, confused:0, tough: cd.toughness?1:0 };
        if (MC.minionEnteredPlay) MC.minionEnteredPlay(G, c, pl);
        MC.log(G, pl.uid + ' — 버린 ' + MC.nameOf(c) + '을(를) 교전 전장 배치');
        summoned = true;
      } else {
        G.encounterDiscard.push(c);
      }
    }
  }
};
MC.defineCardFx('02017b', {
  onSetup:'mutagenSetup',
  whenCompleted:'runCardEffects',
  whenCompletedEffects:[{ fx:'mutagenDiscardSummon' }],
});
/* 02018a Mutagen Cloud 2A — 공개 시 2B 진행 (advanceMainSchemeNow 재사용) */
MC.defineCardFx('02018a', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'advanceMainSchemeNow' }],
});
/* 02018b Mutagen Cloud 2B — nextStage 없음 → 완료 시 자동 패배. 가속 X는 accelFrom 훅(엔진)에서 처리 */

/* 부착물 자기 버림 (히어로 액션: Goblin Glider/Pumpkin Bombs/All Tied Up 등 "자원 지불 → 이 카드 버림"). */
MC.EFFECTS.discardSelfAttachment = function(G, p, ctx){
  const inst = ctx.self || ctx.card;
  if (!inst) return;
  // 신분 부착(All Tied Up/Media Coverage): 플레이어의 identityAttachments에서 제거.
  if (inst.attachedToPlayer){
    for (const pl of G.players){
      const i = (pl.identityAttachments || []).indexOf(inst);
      if (i >= 0){ pl.identityAttachments.splice(i, 1); break; }
    }
    G.encounterDiscard.push(inst);
    MC.log(G, MC.nameOf(inst) + ' — 신분 부착 제거');
    return;
  }
  MC.detachFrom(G, inst);   // attachStats 원복 포함
  G.encounterDiscard.push(inst);
  MC.log(G, MC.nameOf(inst) + ' — 히어로 액션으로 버림');
};

/* 빌런 추가 부스트 카드 수 집계 (중앙 수렴). kind: 'attack'|'scheme'.
   - villainAttackExtraBoost(빌런 def, 공격 전용 — 클로 강제 난입)
   - 부착물 grantsExtraBoost(Hysteria — 공격+스킴 모두) */
MC.villainExtraBoost = function(G, kind){
  if (!G.villain) return 0;
  const vdef = MC.cardDef(G.villain.defCode) || {};
  let n = 0;
  if (kind === 'attack') n += vdef.villainAttackExtraBoost || 0;
  for (const att of (G.villain.attachments || [])){
    const ad = MC.cardDef(att.defCode);
    if (ad && ad.grantsExtraBoost) n += ad.grantsExtraBoost;
  }
  // 저장된 부스트(Intimidation 등 "빌런에게 뒷면 부스트 부여") — 다음 활성화 1회 소비
  if (G.villainStoredBoost){ n += G.villainStoredBoost; G.villainStoredBoost = 0; }
  return n;
};

/* 02020 Hysteria — GG 부착. 스킴/공격 시 부스트 카드 +1(grantsExtraBoost). 히어로 액션(🧠🧠 → 버림). */
MC.defineCardFx('hysteria', {
  attachTarget:'villain',
  grantsExtraBoost:1,
  activatedAbility:{ payCost:{ type:'mental', count:2 }, effect:{ fx:'discardSelfAttachment' } },
});

/* 조우덱 1장 버림 → 그 카드가 고블린 하수인이면 교전 전장 배치 (Goblin Knight 강제반응). */
MC.EFFECTS.discardEncounterSummonGoblin = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const c = MC.drawEncounterCard(G);
  if (!c){ MC.log(G, '(조우덱 비어 있음)'); return; }
  const cd = MC.cardDef(c.defCode) || {};
  if (cd.type === 'minion' && (cd.traits || []).includes('goblin')){
    c.engagedWith = pl.uid; pl.engagedMinions.push(c);
    c.status = c.status || { stunned:0, confused:0, tough: cd.toughness ? 1 : 0 };
    if (MC.minionEnteredPlay) MC.minionEnteredPlay(G, c, pl);
    MC.log(G, pl.uid + ' — 버린 ' + MC.nameOf(c) + '을(를) 교전 전장 배치');
  } else {
    G.encounterDiscard.push(c);
    MC.log(G, '조우 카드 버림: ' + MC.nameOf(c));
  }
};

/* 02022 Goblin Knight — HP7(공식). 강제반응: 공격 후 조우 1장 → 고블린이면 배치.
   부스트★: 활성화 후 조우덱 셔플백. */
MC.defineCardFx('goblin-knight', {
  hp:7,
  vfx:{ attack:'goblinKnightStrike' },
  forcedResponseEffects:[{ fx:'discardEncounterSummonGoblin' }],
  boostStarShuffleBack:true,
});

/* 적 ATK 패시브 집계 (중앙) — enemyAtk가 호출. 현재: Goblin Nation.
   Goblin Nation(사이드 스킴)이 전장에 있으면 각 고블린 적 +1 ATK (사본 수만큼). */
MC.enemyAtkPassive = function(G, enemy){
  let bonus = 0;
  const d = MC.cardDef(enemy.defCode);
  const isGoblin = d && (d.traits || []).includes('goblin');
  if (isGoblin){
    const nations = (G.sideSchemes || []).filter(s => s.defCode === 'goblin-nation').length;
    bonus += nations;
  }
  // Taskmaster 등: 교전 플레이어의 통제 업그레이드 1장당 ATK 스케일 (minionStatScale.atk)
  if (d && d.minionStatScale && d.minionStatScale.atk){
    const pl = G.players.find(p => p.uid === enemy.engagedWith);
    if (pl) bonus += (pl.playArea.upgrades || []).length * d.minionStatScale.atk;
  }
  return bonus;
};

/* 02027 Goblin Nation — 패시브: 각 고블린 적 +1 ATK(enemyAtkPassive가 처리) / 부스트★: 전장 배치. */
MC.defineCardFx('goblin-nation', {
  boostStarPutIntoPlay:true,
});

/* 각 플레이어가 조우덱 N장 버리고, 그렇게 버린 "각" 고블린 하수인을 교전 배치 (Overrun 격퇴 시). */
MC.EFFECTS.overrunDiscardSummon = function(G, p, ctx){
  const cnt = (p && p.count) || 2;
  for (const pl of MC.playersInOrder(G)){
    if (pl.eliminated) continue;
    for (let i = 0; i < cnt; i++){
      const c = MC.drawEncounterCard(G);
      if (!c) break;
      const cd = MC.cardDef(c.defCode) || {};
      if (cd.type === 'minion' && (cd.traits || []).includes('goblin')){
        c.engagedWith = pl.uid; pl.engagedMinions.push(c);
        c.status = c.status || { stunned:0, confused:0, tough: cd.toughness ? 1 : 0 };
        if (MC.minionEnteredPlay) MC.minionEnteredPlay(G, c, pl);
        MC.log(G, pl.uid + ' — 버린 ' + MC.nameOf(c) + ' 교전 배치');
      } else {
        G.encounterDiscard.push(c);
      }
    }
  }
};

/* 02028 Overrun — 격퇴 시(사이드스킴 whenCompleted): 각 플레이어 조우 2장 버리고 각 고블린 배치. */
MC.defineCardFx('overrun', {
  whenCompleted:'runCardEffects',
  whenCompletedEffects:[{ fx:'overrunDiscardSummon', count:2 }],
});

/* 02030 I See You — WR: GG가 당신을 공격(부스트 부여, 단 알터에고면 부스트 생략).
   부스트★: 고블린 하수인이 당신과 교전 중이면 이 카드 부스트 +1(boostOf가 처리). */
MC.defineCardFx('i-see-you', {
  whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'villainAttacks', withBoost:true, noBoostIfAlterEgo:true }],
  boostBonusIfGoblinEngaged:1,
});

/* 방금 배치된 위협(_lastThreatPlaced)이 임계 이상이면 이 카드 surge (Overconfidence 알터에고 분기). */
MC.EFFECTS.surgeIfThreat = function(G, p, ctx){
  const th = G._lastThreatPlaced || 0;
  if (th >= (p.threshold || 3) && ctx.self){
    ctx.self.surge = true;
    MC.log(G, MC.nameOf(ctx.self) + ' — 위협 ' + th + ' ≥ ' + (p.threshold||3) + ' → 급증(surge)');
  }
};

/* 02031 Overconfidence — WR(알터에고): GG 암약, 위협 3+ 배치 시 surge / WR(히어로): GG 공격, 피해 3+ 시 surge. */
MC.defineCardFx('overconfidence', {
  whenRevealed:'goblinPlayerFormReveal',
  whenRevealedByPlayerForm:{
    'alter-ego':[{ fx:'villainSchemes', scheme:'main' }, { fx:'surgeIfThreat', threshold:3 }],
    'hero':[{ fx:'villainAttacks', surgeIfDamageGTE:3 }],
  },
});

/* 02032 Wicked Ambitions — WR: 조우덱 X장 버림(X=2×빌런 스테이지). 버린 각 고블린 하수인마다
   공개한 플레이어가 [피해 3 받기 / 그 고블린을 자신과 교전 배치] 중 선택. 선택은 순차 연쇄. */
MC.HANDLERS.wickedAmbitions = function(G, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const stage = (MC.cardDef(G.villain.defCode) || {}).stage || 1;
  const X = 2 * stage;
  const goblinUids = [];
  for (let i = 0; i < X; i++){
    const c = MC.drawEncounterCard(G);
    if (!c) break;
    G.encounterDiscard.push(c);
    const cd = MC.cardDef(c.defCode) || {};
    if (cd.type === 'minion' && (cd.traits || []).includes('goblin')) goblinUids.push(c.uid);
  }
  MC.log(G, 'Wicked Ambitions — 조우 ' + X + '장 버림 (고블린 ' + goblinUids.length + '마리)');
  if (!goblinUids.length) return;
  G._pendingWickedGoblins = goblinUids;
  G._wickedPlayer = pl.uid;
  MC.flushWickedGoblin(G);
};
/* 다음 고블린 선택 pending 세우기 (없으면 상태 정리) */
MC.flushWickedGoblin = function(G){
  const q = G._pendingWickedGoblins;
  if (!q || !q.length){ G._pendingWickedGoblins = null; G._wickedPlayer = null; G._wickedCurrentGob = null; return; }
  const uid = q.shift();
  const gob = (G.encounterDiscard || []).find(c => c.uid === uid);
  const name = gob ? MC.nameOf(gob) : '고블린 하수인';
  G._wickedCurrentGob = uid;
  G.pending = {
    kind:'revealChoice', player: G._wickedPlayer, selfUid:null,
    prompt: name + ' — 피해 3을 받거나, 이 고블린을 전장에 배치하시오',
    options:[
      { key:'damage', label:'피해 3 받기', effects:[{ fx:'dealDamage', target:'self', amount:3 }] },
      { key:'summon', label:name + ' 전장 배치', effects:[{ fx:'wickedSummonCurrent' }] },
    ],
  };
  MC.log(G, name + ' — 선택 대기 (피해 3 / 배치)');
};
/* 현재 대상 고블린(_wickedCurrentGob)을 조우 버림더미에서 꺼내 교전 배치 */
MC.EFFECTS.wickedSummonCurrent = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  const uid = G._wickedCurrentGob;
  const idx = (G.encounterDiscard || []).findIndex(c => c.uid === uid);
  if (idx < 0) return;
  const [gob] = G.encounterDiscard.splice(idx, 1);
  const cd = MC.cardDef(gob.defCode) || {};
  gob.engagedWith = pl.uid; pl.engagedMinions.push(gob);
  gob.status = gob.status || { stunned:0, confused:0, tough: cd.toughness ? 1 : 0 };
  if (MC.minionEnteredPlay) MC.minionEnteredPlay(G, gob, pl);
  MC.log(G, pl.uid + ' — ' + MC.nameOf(gob) + ' 전장 배치 (Wicked Ambitions)');
};
MC.defineCardFx('wicked-ambitions', {
  whenRevealed:'wickedAmbitions',
});

})(typeof window !== 'undefined' ? window : globalThis);
