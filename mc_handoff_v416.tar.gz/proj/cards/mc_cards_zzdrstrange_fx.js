/* ═══════════════════════════════════════════════════════════════════
   닥터 스트레인지(Doctor Strange) — Invocation(발동 덱) 카드 Special 효과
   발동 덱 5종: 각 카드의 invocationSpecial이 Spell Mastery / Master of the Mystic Arts로 발동.
   대상이 필요한 Special(진홍 밴드·이콘의 환영)은 castInvocation의 targets(기본 빌런) 사용.
   ═══════════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
if (!MC || !MC.defineCardFx) return;

/* 시토락의 진홍 밴드 (Crimson Bands of Cyttorak) — Cost 2.
   Special: 적 1명에게 7 피해 + 기절(Stun). */
MC.defineCardFx('crimson-bands-of-cyttorak', {
  invocationSpecial: [
    { fx:'dealDamage', target:'chosen', amount:7 },
    { fx:'applyStatus', target:'chosen', status:'stunned' },
  ],
});

/* 이콘의 환영 (Images of Ikonn) — Cost 1.
   Special: 적 1명 혼란(Confuse) + 스킴에서 위협 4 제거. */
MC.defineCardFx('images-of-ikonn', {
  invocationSpecial: [
    { fx:'applyStatus', target:'chosen', status:'confused' },
    { fx:'removeThreat', scheme:'main', amount:4 },
  ],
});

/* 라가도르의 일곱 고리 (Seven Rings of Raggadorr) — Cost 1.
   Special: 시전자 히어로가 강인함(Tough) 획득. */
MC.defineCardFx('seven-rings-of-raggadorr', {
  invocationSpecial: [
    { fx:'applyStatus', target:'self', status:'tough' },
  ],
});

/* 발토르의 증기 (Vapors of Valtorr) — Cost 0.
   원본: 전장의 상태 카드 1장을 다른 상태로 교체. 구현: 적 1명에게 혼란 부여(실용화). */
MC.defineCardFx('vapors-of-valtorr', {
  invocationSpecial: [
    { fx:'applyStatus', target:'chosen', status:'confused' },
  ],
});

/* 와툼의 바람 (Winds of Watoomb) — Cost 0.
   Special: 카드 3장 드로우. */
MC.defineCardFx('winds-of-watoomb', {
  invocationSpecial: [
    { fx:'draw', amount:3 },
  ],
});

/* ═══ 닥터 스트레인지 시그니처 카드 ═══ */

/* 09002 Wong (웡) — 동료. Mystic. 유니크. 비용 3, 와일드 1. ATK 2 / THW 1 / HP 3.
   행동: 웡 소진 → 택1: ① 정체성 1 피해 회복 ② 발동 덱 맨 위 카드 1장 버림. */
MC.defineCardFx('wong', {
  activatedAbility: {
    name: '웡', exhaust: true,
    effect: [{ fx:'offerChoice', prompt:'웡 — 택 1', options:[
      { key:'heal',    label:'정체성 1 피해 회복',    effects:[{ fx:'heal', amount:1 }] },
      { key:'discard', label:'발동 덱 맨 위 카드 버림', effects:[{ fx:'naturalTalent' }] },
    ]}],
  },
  textKo: '동료 — Ally. Mystic. 유니크. 비용 3 · 와일드 1. ATK 2 / THW 1 / HP 3.\n\n행동(Action): 웡을 소진 → 택 1: ① 정체성에서 1 피해 회복 / ② 발동 덱 맨 위 카드 1장 버림.\n\n*"나의 주인을 보호하겠다는 맹세가 다른 모든 지시를 능가한다."*\n\n※ 공식 09002 Wong (Doctor Strange 히어로 팩) — 자원 와일드\n※ 닥터 스트레인지 핵심 동료 — 알터에고 회피 + 발동 덱 회전',
});

/* 09003 Astral Projection (유체이탈) — 이벤트. 주문(Spell)·저지(Thwart). 비용 2, 멘탈 1.
   히어로 행동(저지): 스킴 1개에서 위협 3 제거 + 조우덱 위 카드 부스트 아이콘 수만큼 추가 제거. */
MC.defineCardFx('astral-projection', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'removeThreat', scheme:'chosen', amount:3 },
    { fx:'removeThreatByEncounterBoost', scheme:'chosen' },
  ],
  textKo: '이벤트 — Event. 주문(Spell)·저지(Thwart). 비용 2 · 멘탈 1.\n\n히어로 행동(저지): 스킴 1개를 선택 → 그 스킴에서 위협 3 제거. 그 후 조우덱 맨 위 카드를 확인 → 그 카드의 부스트 아이콘 수만큼 선택한 스킴에서 위협 추가 제거.\n\n*"물질계를 떠나 정신체로 적을 살핀다."*\n\n※ 공식 09003 Astral Projection (Doctor Strange 히어로 팩) — 자원 멘탈\n※ 위협 3 + 조우덱 부스트만큼 추가 제거 — 강력한 저지',
});

/* 09004 Magic Blast (마법 폭발) — 이벤트. 공격(Attack)·주문(Spell). 비용 3, 에너지 1.
   히어로 행동(공격): 적 1명에게 5 피해 + 덱 위 카드 1장 버림 → 인쇄 자원별:
   💪물리=기절 / ⚡에너지=추가 2피해 / 🧠멘탈=혼란 / 🌟와일드=전부.
   범용: dealDamage + discardTopResourceBranch(자원-효과 매핑 인덱스, Baron Mordo 재사용). */
MC.defineCardFx('magic-blast', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'dealDamage', target:'chosen', amount:5, isAttack:true },
    { fx:'discardTopResourceBranch', branches:{
      physical: [{ fx:'applyStatus', target:'chosen', status:'stunned' }],
      energy:   [{ fx:'dealDamage', target:'chosen', amount:2, isAttack:true }],
      mental:   [{ fx:'applyStatus', target:'chosen', status:'confused' }],
    } },
  ],
  needsEnemyTarget: true,
  textKo: '이벤트 — Event. 공격(Attack)·주문(Spell). 비용 3 · 에너지 1.\n\n히어로 행동(공격): 적 1명에게 5 피해. 그 후 자신의 덱 맨 위 카드 1장을 버림 → 그 카드의 인쇄 자원에 따라:\n• 💪 물리: 대상 기절(Stun)\n• ⚡ 에너지: 추가 2 피해\n• 🧠 멘탈: 대상 혼란(Confuse)\n• 🌟 와일드: 위 3가지 모두 적용\n\n*"소서러 슈프림의 힘을 보여주지."*\n\n※ 공식 09004 Magic Blast (Doctor Strange 히어로 팩) — 자원 에너지\n※ 5 피해 + 자원별 추가 효과 — 닥터 스트레인지 주력 공격',
});

/* 09005 Master of the Mystic Arts (마법 예술의 대가) — 이벤트. 비용 1, 멘탈 1.
   히어로 행동: 발동 덱 맨 위 카드 Special 해결 → 그 카드를 발동 덱 맨 위에 앞면 유지(재사용). castInvocation keepOnTop. */
MC.defineCardFx('master-of-mystic-arts', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'castInvocation', keepOnTop:true }],
  textKo: '이벤트 — Event. 비용 1 · 멘탈 1.\n\n히어로 행동: 발동 덱 맨 위 카드의 인쇄 비용을 지불 → 그 카드의 "Special" 능력을 해결. 그 후 그 카드를 발동 덱 맨 위에 앞면으로 유지(재사용 가능).\n\n*"소서러 슈프림에게 불가능이란 없다!"*\n\n※ 공식 09005 Master of the Mystic Arts (Doctor Strange 히어로 팩) — 자원 멘탈\n※ Spell Mastery와 차이: 닥터 소진 X + 카드 앞면 유지(반복 발동)',
});

/* 09006 Mystical Studies (신비 수련) — 이벤트. 비용 1, 물리 1.
   알터에고 행동: 덱/버림에서 닥터 스트레인지 카드 1장 서치 + 덱 셔플. searchDeckToHand(hero). */
MC.defineCardFx('mystical-studies', {
  playForm: 'alter-ego',
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'searchDeckToHand', hero:'doctor-strange', includeDiscard:true, shuffle:true }],
  textKo: '이벤트 — Event. 비용 1 · 물리 1.\n\n알터에고 행동: 자신의 덱과 버림 더미에서 닥터 스트레인지 카드 1장을 선택해 손에 추가. 덱을 셔플.\n\n*"나는 관찰과 지식이 행동에 앞서야 한다고 믿는다."*\n\n※ 공식 09006 Mystical Studies (Doctor Strange 히어로 팩) — 자원 물리\n※ 시그니처 서치 — 원하는 주문/유물 확보',
});

/* 09007 Protective Ward (보호 결계) — 이벤트. 주문(Spell). 비용 1, 물리 1.
   히어로 인터럽트: 배신 공개 시 → 그 카드 효과 취소 + 버림. interruptOn(treachery) 손패 이벤트. */
MC.defineCardFx('protective-ward', {
  interruptOn: { encounterType:'treachery', form:'hero' },
  interruptEffect: 'cancelReveal',
  textKo: '이벤트 — Event. 주문(Spell). 비용 1 · 물리 1.\n\n히어로 인터럽트: 조우덱에서 배신(Treachery)이 공개될 때 → 그 카드의 모든 효과를 취소하고 버린다.\n\n*"내가 가장 먼저 배운 주문 중 하나지."*\n\n※ 공식 09007 Protective Ward (Doctor Strange 히어로 팩) — 자원 물리\n※ 배신 완전 무력화 — 손패에서 즉시 발동',
});

/* 09008 Sanctum Sanctorum (생텀 생토럼) — 지원. 위치(Location). 비용 1, 멘탈 1.
   알터에고 행동: 소진 → 버림 더미의 주문(Spell) 1장을 덱에 셔플 + 카드 1장 드로우. */
MC.defineCardFx('sanctum-sanctorum-ds', {
  activatedAbility: {
    name: '생텀 생토럼', form: 'alter-ego', exhaust: true,
    effect: [{ fx:'recallSpellToDeck' }, { fx:'draw', amount:1 }],
  },
  textKo: '지원 — Support. 위치(Location). 비용 1 · 멘탈 1.\n\n알터에고 행동: 생텀 생토럼을 소진 → 버림 더미의 주문(Spell) 카드 1장을 덱에 셔플 + 카드 1장 드로우.\n\n*"블리커 거리치고는 좀 화려하군."*\n\n※ 공식 09008 Sanctum Sanctorum (Doctor Strange 히어로 팩) — 자원 멘탈\n※ 주문 재활용 + 드로우 — 알터에고 엔진',
});

/* 09009 Cloak of Levitation (부양의 망토) — 업그레이드. 유물(Artifact)·도구(Item). 비용 2, 물리 1.
   지속: Aerial 트레잇 획득. / 히어로 행동: 소진 → 닥터 스트레인지 준비(ready). */
MC.defineCardFx('cloak-of-levitation', {
  grantsTrait: 'aerial',
  activatedAbility: { name:'부양의 망토', form:'hero', exhaust:true, effect:[{ fx:'readySelf' }] },
  vfx: { install:'runeInstall' },
  textKo: '업그레이드 — Upgrade. 유물(Artifact)·도구(Item). 유니크. 비용 2 · 물리 1.\n\n지속 효과: 당신은 에어리얼(Aerial) 트레잇을 획득한다.\n\n히어로 행동: 부양의 망토를 소진 → 닥터 스트레인지를 준비(ready) 상태로.\n\n*"소서러 슈프림이라 자칭하려면, 비행하는 망토 정도는 있어야지."*\n\n※ 공식 09009 Cloak of Levitation (Doctor Strange 히어로 팩) — 자원 물리\n※ Aerial 상시 부여(Guard/Escort 무시) + 추가 행동',
});

/* 09011 The Eye of Agamotto (아가모토의 눈) — 업그레이드. 유물(Artifact)·도구(Item). 비용 2, 에너지 1.
   히어로 자원: 소진 → 와일드 자원 1개 생성. resourceGenerator(wild). */
MC.defineCardFx('eye-of-agamotto', {
  resourceGenerator: { form:'hero', exhaust:true, icons:{ wild:1 } },
  vfx: { install:'runeInstall' },
  textKo: '업그레이드 — Upgrade. 유물(Artifact)·도구(Item). 유니크. 비용 2 · 에너지 1.\n\n히어로 자원(Resource): 아가모토의 눈을 소진 → 와일드 자원 1개를 생성한다.\n\n*"아가모토의 눈으로 진실을 꿰뚫어 본다."*\n\n※ 공식 09011 The Eye of Agamotto (Doctor Strange 히어로 팩) — 자원 에너지\n※ 만능 와일드 자원 — 주문/유물 전개 보조',
});

/* ═══ 닥터 스트레인지 보호(Protection) 성향 카드 ═══ */

/* 09012 Brother Voodoo (브라더 부두) — 동료. 보호. 비용 3, 멘탈 1.
   반응: 등장 후 → 덱 맨 위 5장에서 이벤트 카드 1장을 찾아 손에 추가 + 덱 셔플. searchTopN. */
MC.defineCardFx('brother-voodoo', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'searchTopN', count:5, cardType:'event', shuffle:true }],
  textKo: '동료 — Ally. 보호(Protection). 비용 3 · 멘탈 1. ATK 1 / THW 1 / HP 3.\n\n반응(Response): 브라더 부두가 등장한 후 → 덱 맨 위 5장에서 이벤트 카드 1장을 찾아 손에 추가. 덱을 셔플.\n\n*"죽은 자와 산 자의 경계에서 힘을 빌린다."*\n\n※ 공식 09012 Brother Voodoo (Doctor Strange 히어로 팩) — 자원 멘탈\n※ 이벤트 서치 — 방어/공격 이벤트 확보',
});

/* 09013 Clea (클레아) — 동료. 보호. 비용 2, 물리 1.
   인터럽트: 클레아가 격파될 때 → 소유자 덱에 셔플(버림 대신). defeatInterrupt shuffleIntoDeck. */
MC.defineCardFx('clea', {
  defeatInterrupt: { shuffleIntoDeck: true },
  textKo: '동료 — Ally. 보호(Protection). 비용 2 · 물리 1. ATK 1 / THW 1 / HP 2.\n\n인터럽트(Interrupt): 클레아가 격파될 때 → 버림 대신 소유자의 덱에 셔플한다.\n\n*"다크 디멘션의 후예, 스트레인지의 곁을 지킨다."*\n\n※ 공식 09013 Clea (Doctor Strange 히어로 팩) — 자원 물리\n※ 격파돼도 덱으로 복귀 — 재사용 가능한 동료',
});

/* 09014 Iron Fist (아이언 피스트) — 동료. 보호. 비용 4, 물리 1. ATK 2 / THW 1 / HP 3.
   등장 시 미스틱 카운터 2. 인터럽트: 아이언 피스트가 적을 공격할 때 → 카운터 1 소비 → 그 적 기절 + 1 피해.
   범용: entersWithCounters + afterAttack 데이터(useCounter+effect) — fireCardHook 데이터 방식 재사용. */
MC.defineCardFx('iron-fist', {
  entersWithCounters: 2,
  afterAttack: { useCounter:true, effect:[
    { fx:'applyStatus', target:'target', status:'stunned' },
    { fx:'dealDamage', target:'target', amount:1 },
  ] },
  textKo: '동료 — Ally. 보호(Protection). 비용 4 · 물리 1. ATK 2 / THW 1 / HP 3.\n\n아이언 피스트는 미스틱 카운터 2개를 지니고 등장한다.\n\n인터럽트(Interrupt): 아이언 피스트가 적을 공격할 때 → 미스틱 카운터 1개 제거 → 그 적을 기절(Stun)시키고 1 피해.\n\n*"쿤룬의 힘, 아이언 피스트!"*\n\n※ 공식 09014 Iron Fist (Doctor Strange 히어로 팩) — 자원 물리\n※ 카운터 2회 한정 강력한 공격 보조 — 기절+피해',
});

/* 09015 Desperate Defense (필사의 방어) — 이벤트. 보호. 방어(Defense). 비용 1, 에너지 1.
   히어로 인터럽트(방어): 방어 시 +2 DEF(피해 2 방지). 그 공격으로 피해 0이면 → 히어로 재준비(ready).
   범용: preventAmount(2) + setReadyIfNoDamage — 방어 해소 시 dmg===0이면 ready. */
MC.defineCardFx('desperate-defense', {
  effects: [{ fx:'preventAmount', amount:2 }, { fx:'setReadyIfNoDamage' }],
  textKo: '이벤트 — Event. 보호(Protection). 방어(Defense). 비용 1 · 에너지 1.\n\n히어로 인터럽트(방어): 히어로가 공격을 방어할 때 → 그 공격에 대해 +2 DEF(피해 2 방지). 그 공격으로 피해를 받지 않으면 → 히어로를 재준비(ready).\n\n*"최선의 방어가 최선의 반격이 된다."*\n\n※ 공식 09015 Desperate Defense (Doctor Strange 히어로 팩) — 자원 에너지\n※ +2 DEF + 무피해 시 재준비 — 방어 후 추가 행동 가능',
});

/* 09016 Momentum Shift (기세 전환) — 이벤트. 보호. 공격(Attack). 비용 2, 물리 1.
   히어로 행동(공격): 히어로에서 2 피해 회복 → 적 1명에게 2 피해. heal + dealDamage. */
MC.defineCardFx('momentum-shift', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [
    { fx:'heal', amount:2 },
    { fx:'dealDamage', target:'chosen', amount:2 },
  ],
  textKo: '이벤트 — Event. 보호(Protection). 공격(Attack). 비용 2 · 물리 1.\n\n히어로 행동(공격): 히어로에서 2 피해를 회복 → 적 1명에게 2 피해.\n\n*"수세에서 공세로. 흐름을 뒤집는다."*\n\n※ 공식 09016 Momentum Shift (Doctor Strange 히어로 팩) — 자원 물리\n※ 회복 + 공격 동시 — 보호 성향의 공수 전환',
});

/* 09038 Foiled! (저지됐다!) — 이벤트. 정의. 비용 0, 에너지 1.
   인터럽트: 빌런/하수인이 음모(scheme)를 활성화할 때 → 그 부스트 아이콘(▲)을 취소.
   범용: cancelLastSchemeBoost — 음모 부스트분(G._lastSchemeBoost) 소급 제거. */
MC.defineCardFx('foiled', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'cancelLastSchemeBoost' }],
  textKo: '이벤트 — Event. 정의(Justice). 비용 0 · 에너지 1.\n\n인터럽트(Interrupt): 빌런 또는 하수인이 음모(scheme)를 활성화할 때 → 그 활성화의 부스트 아이콘(▲)을 취소한다 (그만큼 놓인 위협 제거).\n\n*"이번엔 안 통해, 킹핀!" —스파이더맨*\n\n※ 공식 09038 Foiled! (Doctor Strange 히어로 팩) — 자원 에너지\n※ 음모 부스트 취소 — 위협 급증 방지 (시뮬: 직전 음모 부스트분 소급 취소)',
});

/* 09026 Sorcerer Supreme (소서러 슈프림) — 업그레이드. 베이직. 칭호(Title). 유니크. 비용 2, 에너지 1.
   플레이 조건: 자신이 Mystic 트레잇을 가질 때만.
   지속 효과: 자신이 Mystic 트레잇을 가지면 → 핸드 크기 +1.
   범용: statMod{handSize +1, cond:Mystic} — passiveStatMod/statOf 중앙 집계 재사용. */
MC.defineCardFx('sorcerer-supreme', {
  statMod: { stat:'handSize', amount:1, cond:{ type:'hasTrait', trait:'mystic' } },
  textKo: '업그레이드 — Upgrade. 베이직(Basic). 칭호(Title). 유니크. 비용 2 · 에너지 1.\n\n플레이 조건: 자신의 정체성이 마법사(Mystic) 트레잇을 가질 때만 플레이 가능.\n\n지속 효과: 자신이 Mystic 트레잇을 가지는 동안 → 핸드 크기 +1.\n\n*"소서러 슈프림의 자리는 에인션트 원께서 내게 물려주신 것이다."*\n\n※ 공식 09026 Sorcerer Supreme (Doctor Strange 히어로 팩) — 자원 에너지\n※ 핸드 +1 지속 — Mystic 히어로(닥터스트레인지/스칼렛위치/아담워록) 카드 순환 강화',
});

/* 09021 Warning (경고) — 이벤트. 베이직. 비용 0, 물리 1.
   방해(인터럽트): 히어로가 피해를 받을 때 → 그 피해량 1 감소.
   범용: defenseInterruptEvent + preventAmount(1) — 방어 인터럽트 이벤트로 처리(피해 1 방지). */
MC.defineCardFx('warning', {
  defenseInterruptEvent: true,
  effects: [{ fx:'preventAmount', amount:1 }],
  textKo: '이벤트 — Event. 베이직(Basic). 비용 0 · 물리 1.\n\n방해(Interrupt): 히어로가 피해를 받을 때 → 그 피해량을 1 감소시킨다.\n\n*"조심해!" —아이언맨*\n\n※ 공식 09021 Warning (Doctor Strange 히어로 팩) — 자원 물리\n※ 비용 0 피해 1 감소 — 방어 선언 시 추가 완화 (시뮬: 방어 인터럽트로 처리)',
});

/* 09020 Unflappable (침착함) — 업그레이드. 보호. 상태(Condition). 비용 1, 물리 1. 플레이어당 최대 1장.
   반응: 히어로가 방어 후 피해 0이면 → 소진(버림) → 카드 1장 드로우.
   범용: afterDefendNoDamage 중앙 스캔(discardSelf + draw) — 방어 무피해 훅 재사용. */
MC.defineCardFx('unflappable', {
  afterDefendNoDamage: { discardSelf: true, effect: [{ fx:'draw', amount:1 }] },
  textKo: '업그레이드 — Upgrade. 보호(Protection). 상태(Condition). 비용 1 · 물리 1. 플레이어당 최대 1장.\n\n반응(Response): 히어로가 공격을 방어한 후 그 공격으로 피해를 받지 않았다면 → 침착함을 소진(버림) → 카드 1장 드로우.\n\n*"동요하지 않는 자가 승리한다."*\n\n※ 공식 09020 Unflappable (Doctor Strange 히어로 팩) — 자원 물리\n※ 무피해 방어 시 카드 순환 — 방어 특화 덱 보조',
});

/* 09019 The Night Nurse (나이트 너스) — 지원. 보호. 비용 1, 멘탈 1. Uses(메디컬 카운터 3).
   행동: 소진 + 카운터 1 제거 → 히어로 1 피해 회복 + 그 히어로의 상태 카드 1개 제거. */
MC.defineCardFx('night-nurse', {
  uses: 3,
  activatedAbility: {
    name: '나이트 너스', exhaust: true, useCounter: 1,
    effect: [{ fx:'heal', amount:1 }, { fx:'removeStatus', target:'self' }],
  },
  textKo: '지원 — Support. 보호(Protection). 비용 1 · 멘탈 1. Uses(메디컬 카운터 3개).\n\n행동(Action): 나이트 너스를 소진 + 메디컬 카운터 1개 제거 → 히어로 1 피해 회복 + 그 히어로의 상태 카드 1개 제거.\n\n*"내 진료실에선 슈퍼히어로도 환자일 뿐이야."*\n\n※ 공식 09019 The Night Nurse (Doctor Strange 히어로 팩) — 자원 멘탈\n※ 회복 + 상태 해제 3회 — 보호 성향 힐러',
});

/* 09037 Skilled Strike (숙련된 일격) — 이벤트. 어그레션. 비용 0, 물리 1.
   히어로 인터럽트: 기본 공격을 할 때 → 그 공격 ATK +2. buffNextBasicAttack. */
MC.defineCardFx('skilled-strike', {
  playForm: 'hero',
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'buffNextBasicAttack', amount:2 }],
  textKo: '이벤트 — Event. 어그레션(Aggression). 비용 0 · 물리 1.\n\n히어로 인터럽트: 기본 공격(basic attack)을 할 때 → 그 공격의 ATK를 +2 한다.\n\n*"수련한 자의 일격은 낭비가 없다."*\n\n※ 공식 09037 Skilled Strike (Doctor Strange 히어로 팩) — 자원 물리\n※ 비용 0 기본 공격 강화 — 저비용 딜 증폭',
});

})(typeof window !== 'undefined' ? window : globalThis);
