/* ═══════════════════════════════════════════════════════════════
   mc_cards_fx.js — 카드 능력 등록 레이어 (Phase 3 파이프라인의 결과 축적처)
   규율: 카드 1장 = 응답 1개 파이프라인을 거친 카드만 여기 등록.
   defineCardFx는 todoFx 마커를 해제한다 (UI '수동' 배지 제거).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* ── swinging-web-kick (01005) ──
   "히어로 행동 (공격): 적 1명에게 8 피해."
   등록일: v2026.07.08.4 · 검증: tests/test_phase1.js
   ※ '공격 이벤트' 판정(보복 트리거) 정밀화는 R-2 보류 항목 */
MC.defineCardFx('swinging-web-kick', {
  effects: [{ fx:'dealDamage', target:'chosen', amount:8 }],
});

/* ── 자원 카드 결제 속성 (공식 텍스트 재등록) ──
   "이 성향 카드 결제 시 이 카드가 생성하는 자원 2배" — doubleForAspect 모델
   등록일: v2026.07.08.5 · 검증: tests/test_payment.js */
MC.defineCardFx('power-of-protection', { doubleForAspect: 'protection' });
MC.defineCardFx('power-of-justice',    { doubleForAspect: 'justice' });
MC.defineCardFx('power-of-leadership', { doubleForAspect: 'leadership' });
MC.defineCardFx('power-of-aggression', { doubleForAspect: 'aggression' });


})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   Phase 3 — 코어 카드 능력 등록 (스파이더맨 + 라이노)
   1차 배치: 즉발형 조우 카드 (whenRevealed 즉시 해소, pending 없음)
   각 등록은 EFFECTS 재사용을 우선한다. 핸들러는 effectList를 실행.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
const H = MC.HANDLERS;

/* 공통: whenRevealed용 효과 리스트 실행 핸들러 팩토리는 쓰지 않고
   각 카드 정의에 whenRevealed 핸들러 이름을 직접 매핑 (인덱스 규율) */

/* shocker — 공개 시: 각 히어로에게 1 피해 */
MC.defineCardFx('shocker', { whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'damageEachHero', amount:1 }],
  unique: true, vfx: { attack: 'vibroShock' } });

/* hard-to-keep-down — 공개 시: 라이노 4 회복 (회복 없으면 급증) */
MC.defineCardFx('hard-to-keep-down', { whenRevealed:'runCardEffects',
  whenRevealedEffects:[
    { fx:'healVillain', amount:4 },
    { fx:'surge', cond:{ type:'healedNone' } },          // 이미 풀피 → 회복 0 → 급증
  ] });

/* im-tough — 공개 시: 라이노 강인함 (이미 있으면 급증). 부스트★도 강인함 */
MC.defineCardFx('im-tough', { whenRevealed:'runCardEffects',
  whenRevealedEffects:[
    { fx:'surge',      cond:{ type:'targetStatus', target:'villain', status:'tough' } },              // 이미 tough → 급증
    { fx:'toughEnemy', target:'villain', cond:{ type:'targetStatus', target:'villain', status:'tough', negate:true } },
  ],
  boostStarEffect:'toughEnemy' }); // 부스트★ 참조(문서화)

/* false-alarm — 공개 시: 히어로 혼란 (이미 혼란이면 급증) */
MC.defineCardFx('false-alarm', { whenRevealed:'runCardEffects',
  whenRevealedEffects:[
    { fx:'surge',       cond:{ type:'targetStatus', target:'self', status:'confused' } },             // 이미 혼란 → 급증
    { fx:'applyStatus', target:'self', status:'confused', cond:{ type:'targetStatus', target:'self', status:'confused', negate:true } },
  ] });

/* shocker/hydra 등은 minion이라 whenRevealed가 하수인 등장 후 발화됨(엔진 배선 확인 완료) */

/* hydra-bomber — 공개 시: 교전 플레이어 선택 — 피해 2 받기 OR 메인 스킴 위협 +1.
   플레이어 선택 pending(revealChoice)을 세워 공개 루프를 멈춘다. 선택 액션으로 해소. */
MC.defineCardFx('hydra-bomber', { whenRevealed:'runCardEffects',
  whenRevealedEffects:[{ fx:'offerChoice',
    prompt:'하이드라 폭파범 — 폭탄이 터진다! 선택하세요',
    options:[
      { key:'damage', label:'피해 2 받기',      effects:[{ fx:'dealDamage', target:'self', amount:2 }] },
      { key:'threat', label:'메인 스킴 위협 +1', effects:[{ fx:'placeThreat', scheme:'main', amount:1 }] },
    ] }],
  vfx: { attack: 'hydraBomb' } });

/* 01121 무기 밀매상(weapons-runner) — 클로 조우 하수인 (Core Set #121, ×2, Mercenary)
   Surge — 공개 시 추가 조우 카드 1장 공개 (surge 플래그 → revealPendingEncounters가 처리).
   부스트★ — 부스트 카드로 뽑히면 그 플레이어와 교전 상태로 전장 배치(boostStarPutIntoPlay).
   테마: 클로에게 무기를 조달·밀매하는 용병 러너. 무기 투척/밀수 공격(weaponSmuggle). */
MC.defineCardFx('weapons-runner', { surge: true, boostStarPutIntoPlay: true, vfx: { attack: 'weaponSmuggle' } });

/* 01129 라디오액티브 맨(radioactive-man) — 클로/Masters of Evil 하수인 (Core Set #129, ×1 unique)
   ★강제 반응: 공격 후 대상 플레이어 손패 무작위 1장 버림 (resolveDefensePending 끝에서 발화).
   ★부스트: 부스트로 뽑히면 그 플레이어 손패 무작위 1장 버림 (boostStarEffect).
   Elite + Masters of Evil, HP 7 (까다로운 엘리트). 방사능 테마 공격(radiationBlast). */
/* ── 범용 덱 검색 → 손 (shuri/bpForesight/capShieldSetup 통합) ──
   filters: [{type?,trait?,mcode?}, ...] 우선순위대로 탐색. 첫 매치 1장을 손으로.
   includeDiscard: 덱에 없으면 버림 더미도 탐색(캡틴 방패). shuffle: 기본 true. reveal: 공개 힌트 kind. */
MC.EFFECTS.searchDeckToHand = function(G, p, ctx){
  const pl = ctx.player || G.players[G.firstPlayer];
  if (!pl) return;
  const filters = p.filters || [{}];
  const matches = (c, f) => {
    const d = MC.cardDef(c.defCode); if (!d) return false;
    if (f.type  && d.type  !== f.type)  return false;
    if (f.mcode && d.mcode !== f.mcode) return false;
    if (f.trait && !((d.traits || []).includes(f.trait))) return false;
    return true;
  };
  let card = null;
  for (const f of filters){ const i = pl.deck.findIndex(c => matches(c, f)); if (i >= 0){ card = pl.deck.splice(i,1)[0]; break; } }
  if (!card && p.includeDiscard){
    for (const f of filters){ const i = pl.discard.findIndex(c => matches(c, f)); if (i >= 0){ card = pl.discard.splice(i,1)[0]; break; } }
  }
  const label = p.logName || '덱 검색';
  if (!card){ MC.log(G, label + ' — 조건에 맞는 카드 없음'); return; }
  pl.hand.push(card);
  if (p.shuffle !== false) MC.shuffle(G, pl.deck);
  MC.log(G, label + ' — ' + MC.nameOf(card) + ' 손에 추가' + (p.shuffle !== false ? ', 덱 셔플' : ''));
  if (p.reveal) G.fxReveal = { kind: p.reveal, card: { defCode: card.defCode, name: MC.nameOf(card) } };
};

/* ── 부착물 → 동료 스탯 버프 (enraged/inspired 통합) ── */
MC.EFFECTS.buffAttachedAlly = function(G, p, ctx){
  const ally = ctx.targets && ctx.targets[0];
  const label = p.logName || '부착 강화';
  if (!ally){ MC.log(G, label + ' — 부착 대상 없음'); return; }
  if (p.attack)  ally.attack  = (ally.attack  || 0) + p.attack;
  if (p.thwart)  ally.thwart  = (ally.thwart  || 0) + p.thwart;
  if (p.atkCost) ally.atkCost = (ally.atkCost || 0) + p.atkCost;
  MC.log(G, label + ' — ' + MC.nameOf(ally) + ' 강화'
    + (p.attack ? ' ATK+' + p.attack : '') + (p.thwart ? ' THW+' + p.thwart : '') + (p.atkCost ? ' 부수+' + p.atkCost : ''));
};

/* ── 설치 직후 소유자 최대 HP 재계산 (mk5-armor/rocket-boots 등 hpBonus 업그레이드 통합) ── */
MC.EFFECTS.refreshMaxHp = function(G, p, ctx){
  const card = ctx.self;
  const pl = ctx.player || G.players.find(q =>
    q.playArea.upgrades.some(c => c.uid === card.uid) || q.playArea.supports.some(c => c.uid === card.uid));
  if (pl) MC.recomputeMaxHp(G, pl);
};


MC.EFFECTS.discardBooster = function(G, p, ctx){
  const pl = ctx.player;
  if (pl && pl.hand && pl.hand.length){
    MC.discardRandomFromHand(G, pl, 1);
    MC.log(G, MC.nameOf(ctx.self || {name:'라디오액티브 맨'}) + ' 부스트★ — ' + pl.uid + ' 손패 무작위 1장 버림');
  }
};
MC.defineCardFx('radioactive-man', {
  unique: true,
  forcedResponse: 'runCardEffects',
  forcedResponseEffects: [{ fx:'discardFromHand', who:'self', amount:1 }],
  boostStarEffect: 'discardBooster',
  vfx: { attack: 'radiationBlast' },
});

/* 01130 회오리바람(whirlwind) — 클로/Masters of Evil 하수인 (Core Set #130, ×1 unique)
   ★강제 난입: 공격 시 다른 모든 히어로에게도 동일 공격 (forcedInterrupt=fi_attackEachHero,
     엔진 enemyActivation에서 pending.alsoAttack 체인으로 처리 — 마커만 지정).
   ★부스트: 각 히어로에게 1피해 (boostStarEffect=damageEachHeroBoost).
   Masters of Evil, HP 6. 고속 회전 공격 테마(tornadoSpin). */
/* fi_attackEachHero: 회오리바람 강제 난입 마커. 실제 처리는 엔진 enemyActivation이
   pending.alsoAttack 체인으로 수행하므로 이 핸들러 본체는 no-op (test_index 등록 검사 충족용). */
H.fi_attackEachHero = function(G, ctx){ /* 엔진이 pending.alsoAttack으로 처리 */ };
MC.EFFECTS.damageEachHeroBoost = function(G, p, ctx){
  MC.runEffectList(G, [{ fx:'damageEachHero', amount:1 }], ctx);
};
MC.defineCardFx('whirlwind', {
  unique: true,
  forcedInterrupt: 'fi_attackEachHero',   // 마커 (엔진이 pending.alsoAttack 체인으로 처리)
  boostStarEffect: 'damageEachHeroBoost',
  vfx: { attack: 'tornadoSpin' },
});

/* 01131 타이거 샤크(tiger-shark) — 클로/Masters of Evil 하수인 (Core Set #131, ×1 unique)
   ★강제 반응: 공격 후 자신에게 강인 부여 (fr_tigerShark — 점점 단단해지는 상어).
   ★부스트: 빌런에게 강인 부여 (boostStarEffect=toughEnemy, target 빌런).
   Masters of Evil, HP 6 / ATK 3 (높은 공격력). 상어 물어뜯기 공격(sharkBite). */
MC.defineCardFx('tiger-shark', {
  unique: true,
  forcedResponse: 'runCardEffects',
  forcedResponseEffects: [{ fx:'applyStatus', target:'card', status:'tough' }],   // 자신에게 강인
  boostStarEffect: 'toughEnemy',   // 빌런에게 강인 (toughEnemy 기본 대상=villain)
  vfx: { attack: 'sharkBite' },
});

/* 01132 멜터(melter) — 클로/Masters of Evil 하수인 (Core Set #132, ×1 unique)
   ★지속 효과: 교전 영웅은 가능하면 동료로 멜터의 공격을 반드시 방어 (forceAllyDefend — 엔진
     enemyActivation이 pending.mustDefendWithAlly 마커로 처리, UI/봇이 신분·무방어 차단).
   ★부스트: 통제하는 모든 동료 소진 (boostStarEffect=exhaustAllAllies).
   Elite + Masters of Evil, ATK 3 / HP 5. 용해 광선 공격(meltRay). */
MC.defineCardFx('melter', {
  unique: true,
  forceAllyDefend: true,             // 지속 효과 마커 (엔진이 mustDefendWithAlly로 처리)
  boostStarEffect: 'exhaustAllAllies',
  vfx: { attack: 'meltRay' },
});

/* ── 스파이더맨 성향/기본 이벤트 (2차) ── */

/* tackle — 공격: 적 1명 기절 + 💪피지컬 지불 시 3 피해 */
MC.defineCardFx('tackle', {
  effects: [
    { fx:'applyStatus', target:'chosen', status:'stunned' },
    { fx:'dealDamageIfPaid', target:'chosen', resource:'physical', amount:3 },
  ],
  vfx:{ basicAttack:'strike' }, // 공격 이벤트 — 타격 연출 재사용 (카드 스코프는 UI가 처리)
});


})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #1 — 스파이더맨 Spider-Sense (신분 능력)
   인터럽트: 빌런이 당신을 공격 개시할 때 → 카드 1장 뽑기.
   연출은 표현 계층에서 spiderSense 재생 (핸들러는 상태만 변경).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
const H = MC.HANDLERS;

/* spiderSense — 공격 개시 인터럽트: 대상 플레이어 카드 1장 드로우 */
H.spiderSense = function(G, ctx){
  MC.log(G, '스파이더 센스 발동 — ' + ctx.player.uid + ' 카드 1장 뽑기');
  MC.runEffectList(G, [{ fx:'draw', who:'self', amount:1 }], ctx);
};

})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #2 — 블랙캣 (스파이더맨 전용 동료)
   강제 반응: 플레이 후 덱 위 2장 버림 → 인쇄 🧠멘탈 자원 카드는 손으로.
   연출: 설치=webInstall(거미줄) / 기본공격=claw(발톱) / 저지=patrol
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('black-cat', {
  atkCost: 0,                       // 공식: 블랙캣은 공격 후 부수 피해 없음 (atkCost 0)
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'millAndGrab', amount:2, keepResource:'mental' }],
  vfx: { install:'webInstall', basicAttack:'claw', basicThwart:'patrol' },
});

})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #3 — 공중제비 (Backflip) 스파이더맨 전용 방어 이벤트
   인터럽트(방어): 공격으로 피해를 입으려 할 때 → 그 공격의 모든 피해 방지.
   연출: 스파이더맨 카드가 뒤로 공중제비 회전하며 공격을 흘려보냄 + MISS!
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('backflip', {
  effects: [{ fx:'preventAll' }],
  vfx: { defense:'backflip' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #4 — 강화된 스파이더 센스 (Enhanced Spider-Sense)
   히어로 인터럽트: 배반(treachery) 카드 공개 시 → "공개 시" 효과 취소.
   범용 인터럽트 정지점 시스템 사용 (interruptOn/interruptEffect).
   연출: 스파이더센스 물결 번짐 + 배반 카드 회색으로 흩어짐.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('enhanced-spider-sense', {
  interruptOn: { encounterType: 'treachery' },
  interruptEffect: 'cancelReveal',
  vfx: { interrupt: 'senseCancel' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #5 — 회전 거미줄 발차기 (Swinging Web Kick)
   능력(8피해)은 마이그레이션 등록됨. 스파이더맨 유일 메인 딜링기 → 화려한 연출.
   연출: 거미줄 스윙 → 회전 발차기 임팩트(다중 링+스파크+강한 흔들림) + THWIP!→SMASH!
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('swinging-web-kick', {
  vfx: { basicAttack: 'webKick' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #6 — 메이 숙모 (Aunt May)  스파이더맨 시그니처 서포트
   알터에고 행동: 소진 → 피터 파커(자신) 4 회복.
   활성 능력 시스템(activatedAbility) 첫 사례 — 소진 능력 support/upgrade 재사용 기반.
   연출: 공용 회복(recover, 초록 십자 상승). 설치는 스파이더맨 전용 webInstall 재사용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('aunt-may', {
  activatedAbility: { form:'alter-ego', exhaust:true,
                      effect: { fx:'heal', target:'self', amount:4 } },
  vfx: { install:'webInstall', recover:'recover' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #7 — 스파이더 트레이서 (Spider-Tracer)  스파이더맨 시그니처 업그레이드
   하수인에 부착. 강제 난입: 부착된 하수인이 쓰러질 때 → 스킴에서 위협 3 제거.
   범용 부착 시스템 사용 (attachTarget:'minion' + whenAttachedDefeated 훅).
   연출: 카드가 크게 확대됐다 작아지며 부착 대상에 겹쳐짐(attachPlace) + 부착 배지 UI.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.HANDLERS.tracerDefeated = function(G, ctx){
  // 부착 하수인 처치 → 메인 스킴에서 위협 3 제거 (사이드 우선 선택은 후속 확장)
  MC.removeThreat(G, 'main', 3);
  MC.log(G, '스파이더 트레이서 — 위협 3 제거');
};
MC.defineCardFx('spider-tracer', {
  attachTarget: 'minion',
  whenAttachedDefeated: 'tracerDefeated',
  vfx: { install: 'attachPlace' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #8 — 웹-슈터 (Web-Shooter)  스파이더맨 시그니처 업그레이드
   사용(3 웹 카운터). 히어로 자원: 소진 + 웹 카운터 1개 제거 → 🌟 와일드 자원 1개 생성.
   ── 자원 생성 카드 시스템 정립 ──
   · uses:3 → makeInstance가 counters=3으로 초기화, 0이 되면 자동 버림
   · resourceGenerator: 결제 요소 {kind:'card'}로 편입 (범용 — 차후 음모/적/빌런
     부착물 제거용 자원의 원천으로 재사용)
   설치는 스파이더맨 전용 webInstall 재사용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('web-shooter', {
  uses: 3,
  resourceGenerator: { form:'hero', exhaust:true, counter:1, icons:{ wild:1 } },
  vfx: { install:'webInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #9 — 거미줄에 감기다 (Webbed-Up)  스파이더맨 시그니처 업그레이드
   히어로 폼 전용. 적에 부착(적당 최대 1장).
   강제 인터럽트: 부착된 적이 공격 시도 → webbed-up 버림(공격 대체) → 그 적 기절.
   부착 시스템 + 부착물 공격 인터럽트 활용.
   연출: 부착 중 적이 거미줄에 둘러싸임(webCocoon) + 부착 해제 시 거미줄 찢김(webTear).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.HANDLERS.webbedUpInterrupt = function(G, ctx){
  const enemy = ctx.enemy, att = ctx.self;
  const owner = G.players.find(p => p.uid === att.ownerUid);
  MC.log(G, MC.nameOf(enemy) + '의 공격 — 거미줄에 감기다로 대체');
  // 부착 해제 + 카드 버림 (연출: webTear는 UI가 처리)
  MC.detachFrom(G, att);
  if (owner) MC.moveToDiscard(G, owner, att, {});
  // 그 적 기절
  MC.setStatus(G, enemy, 'stunned', true);
  MC.log(G, MC.nameOf(enemy) + ' 기절 (거미줄에 감기다)');
  return true;  // 공격 대체됨 — 활성화 중단
};
MC.defineCardFx('webbed-up', {
  attachTarget: 'enemy',
  maxPerTarget: 1,
  attachAttackInterrupt: 'webbedUpInterrupt',
  vfx: { install:'webCocoon', detach:'webTear' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 카드 — 블랙 위도우 (Black Widow, ally)  S.H.I.E.L.D. 첩보원
   인터럽트: 조우덱에서 카드 공개 시 → 소진 + 🧠멘탈 1 지불 → 그 카드 취소·버림
   → 조우덱에서 1장 추가 공개. (모든 조우 카드 대응, 폼 무관)
   범용 인터럽트 시스템(동료 인터럽트) 사용.
   연출: 베이직 카드 — 공격은 공용 [사격](gunshot), 저지는 기본 patrol 재사용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('black-widow-ally', {
  interruptOn: { encounterType:'any', pay:{ type:'mental', count:1 }, thenReveal:1 },
  vfx: { basicAttack:'gunshot', basicThwart:'patrol' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 카드 — 내 뒤로! (Get Behind Me!)
   히어로 인터럽트: 배반 공개 시 → "공개 시" 효과 취소. 대신 빌런이 당신을 공격.
   범용 인터럽트 시스템 + 커스텀 interruptEffect 핸들러(취소 + 빌런 공격).
   연출: 공용 cancelReveal(취소된 배반 카드 회색+X) 재사용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.HANDLERS.getBehindMe = function(G, ctx){
  // 취소는 상위(resolveRevealInterrupt)에서 revealCancelled=true 처리됨.
  // 추가 효과: 빌런이 그 플레이어를 공격 (방어 pending 생성).
  MC.EFFECTS.villainAttacks(G, {}, { player: ctx.player });
};
MC.defineCardFx('get-behind-me', {
  interruptOn: { encounterType:'treachery' },
  interruptEffect: 'getBehindMe',
  vfx: { interrupt:'cancelReveal' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #11 — 스파이더 우먼 (Spider-Woman, ally)  캡틴 마블 시그니처
   반응: 등장 후 → 빌런을 혼란(Confuse). whenPlayed 훅으로 발동.
   연출: 동료 소환=공용 allyEnter, 능력=공용 confuse(혼란), 공격/저지=공용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.HANDLERS.spiderWomanEnter = function(G, ctx){
  MC.EFFECTS.applyStatus(G, { target:'villain', status:'confused' }, ctx);
  MC.log(G, '스파이더 우먼 — 빌런 혼란');
};
MC.defineCardFx('spider-woman-ally', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'applyStatus', target:'villain', status:'confused' }],   // 빌런 혼란 (데이터 인덱스)
  vfx: { basicAttack:'gunshot', basicThwart:'patrol', confuse:'confuse' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #12 — 위기 저지 (Crisis Interdiction)  캡틴 마블 시그니처 이벤트
   저지: 한 스킴에서 위협 2 제거. 그 후 Aerial 트레잇 보유 시 → 다른 스킴에서 2 추가 제거.
   조건부 효과(cond:hasTrait aerial) + 플레이어 트레잇 판정 시스템 사용.
   연출: 저지 이벤트 — 공용 patrol 재사용(캡틴 마블 전용 아님).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('crisis-interdiction', {
  effects: [
    { fx:'removeThreat', scheme:'main', amount:2 },
    { fx:'removeThreat', scheme:'main', amount:2, cond:{ type:'hasTrait', trait:'aerial' } },
  ],
  vfx: { basicThwart:'patrol' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #13 — 광자 폭발 (Photon Blast)  캡틴 마블 메인 딜링기
   공격: 적 1명에게 5 피해. 에너지 자원으로 결제했으면 카드 1장 드로우.
   조건부 효과(cond:paidWith energy) — 키커 시스템.
   연출: 캡틴 마블 메인 딜링기 → 과장된 광자 빔 폭발(photonBlast).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('photon-blast', {
  effects: [
    { fx:'dealDamage', target:'chosen', amount:5 },
    { fx:'draw', who:'self', amount:1, cond:{ type:'paidWith', resource:'energy' } },
  ],
  vfx: { basicAttack:'photonBlast' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #15 — 알파 플라이트 기지 (Alpha Flight Station)  캡틴 마블 시그니처 서포트
   행동: 소진 + 손에서 카드 1장 버림 → 카드 1장 드로우
   (캐롤 댄버스[01010b] 알터에고면 2장 드로우 대신).
   활성 능력 시스템(activatedAbility) + discardCost + 조건부 효과(isIdentity).
   연출: 서포트 설치=공용, 능력=드로우(별도 연출 없음, 폼 무관).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('alpha-station', {
  activatedAbility: {
    exhaust: true,
    discardCost: 1,
    effect: [
      // 캐롤 댄버스면 2장, 아니면 1장 (상호배타 조건)
      { fx:'draw', who:'self', amount:2, cond:{ type:'isIdentity', code:'01010b' } },
      { fx:'draw', who:'self', amount:1, cond:{ type:'notIdentity', code:'01010b' } },
    ],
  },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #16 — 캡틴 마블 헬멧 (Captain Marvel's Helmet)  캡틴 마블 시그니처 업그레이드
   지속 효과: 캡틴 마블 DEF +1 (Aerial 트레잇 보유 시 +2 대신).
   패시브 스탯 수정(statMod) + 조건부 대체값(amountIf: Aerial).
   연출: 캡틴 마블 전용 설치 = starInstall(별 장착).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('captain-marvel-helmet', {
  statMod: { stat:'defense', amount:1, amountIf:{ cond:{ type:'hasTrait', trait:'aerial' }, amount:2 } },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #17 — 우주 비행 (Cosmic Flight)  캡틴 마블 시그니처 업그레이드
   지속 효과: 캡틴 마블이 Aerial(비행) 트레잇 획득 (grantsTrait).
   히어로 인터럽트(방어): 피해받을 때 → 우주 비행 버림 → 피해 3 방지.
   grantsTrait(트레잇 부여) + 방어 인터럽트(부분 방지 + 자체 버림).
   연출: 설치=캡틴 마블 전용(starInstall) + Aerial 부양 지속 상태 표현.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('cosmic-flight', {
  grantsTrait: 'aerial',
  // 방어 인터럽트: 활성 능력으로 발동 (방어 pending 시), 3 방지 후 자체 버림
  defenseInterrupt: { prevent: 3, discardSelf: true },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #18 — 에너지 채널 (Energy Channel)  캡틴 마블 시그니처 업그레이드
   플레이어당 최대 1장. Cost 0.
   행동(충전): 에너지 자원 X개 소비 → 카운터 X개 추가 (게임 끝까지 누적).
   히어로 행동(발사): 카드 버림 → 적에게 카운터당 2 피해 (최대 10, 최소 카운터 1).
   카운터 능력(counterAbility) — 충전/발사 2단 시스템.
   연출: 설치=캡틴 마블 전용(starInstall) / 발사=광자 폭발(photonBlast) 재사용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('energy-channel', {
  maxPerTarget: 1,   // 플레이어당 최대 1장 (정체성 부착이 아니므로 UI에서 별도 처리)
  counterAbility: {
    charge: { resource: 'energy' },
    fire:   { perCounter: 2, max: 10, minCounters: 1, discardSelf: true },
  },
  vfx: { fire: 'photonBlast' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #20 — 헬캣 (Hellcat, ally)  She-Hulk 시그니처 동료
   행동: 헬캣을 소유자 손으로 반환 (HP 리셋 — 재배치 시 새 카드).
   returnToHand 효과 + 활성 능력. 연출: 소환=공용 allyEnter, 공격/저지=공용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('hellcat', {
  activatedAbility: { effect: [{ fx:'returnToHand' }] },
  vfx: { basicAttack:'gunshot', basicThwart:'patrol' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #21 — 감마 슬램 (Gamma Slam)  She-Hulk 시그니처 피니셔
   히어로 행동(공격): 적 1명에게 X 피해 (최대 15). X = 자신의 누적 피해량(maxHp-hp).
   dealDamageSustained 효과(자기 상태 기반 가변 피해).
   연출: She-Hulk 피니셔 → 과장된 감마 슬램(gammaSlam).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('gamma-slam', {
  effects: [{ fx:'dealDamageSustained', target:'chosen', max:15 }],
  vfx: { basicAttack:'gammaSlam' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #22 — 짓밟기 (Ground Stomp)  She-Hulk 시그니처 광역기
   히어로 행동: 모든 적(빌런 + 모든 하수인)에게 각 1 피해.
   allEnemies 대상(광역 피해). 연출: She-Hulk 지면 강타 광역(groundStomp).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('ground-stomp', {
  effects: [{ fx:'dealDamage', target:'allEnemies', amount:1 }],
  vfx: { basicAttack:'groundStomp' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #23 — 법률 업무 (Legal Practice)  She-Hulk 시그니처 (제니퍼 왈터스)
   알터에고 행동(저지): 손에서 최대 5장 버림 → 버린 1장당 메인 스킴 위협 1 제거.
   playForm(alter-ego 전용) + discardForThreat 효과.
   연출: 변호사 테마 → 서류 정리(legalWork).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('legal-practice', {
  playForm: 'alter-ego',
  effects: [{ fx:'discardForThreat', max:5, perCard:1, scheme:'main' }],
  vfx: { basicThwart:'legalWork' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #24 — 원투 펀치 (One-Two Punch)  She-Hulk 시그니처
   반응(Response): 자신이 기본 공격을 한 후 → 자신을 준비(ready) 상태로.
   playCondition(justBasicAttacked) + readySelf 효과.
   연출: She-Hulk 연타 — 두 번째 펀치(oneTwoPunch).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('one-two-punch', {
  playCondition: { type:'justBasicAttacked' },
  effects: [{ fx:'readySelf' }],
  vfx: { play:'oneTwoPunch' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #25 — 이중인격 (Split Personality)  She-Hulk 시그니처
   행동: 정체성 변신(라운드 제한 무시) → 인쇄된 핸드 크기까지 드로우.
   splitPersonality 효과(flipForm force + drawUpToHandSize).
   연출: 감마 분열 폼 전환(splitForm) — 폼 전환이므로 formFlip 지연 디스패치 필요.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('split-personality', {
  effects: [{ fx:'splitPersonality' }],
  vfx: { formChange:'splitForm' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #26 — 초인법 사무소 (Superhuman Law Division)  She-Hulk 시그니처
   서포트(위치). 알터에고 행동(저지): 소진 + 멘탈 자원 1 지불 → 한 스킴 위협 2 제거.
   activatedAbility (form:alter-ego + exhaust + payCost) + removeThreat 효과.
   연출: 변호사 테마 → 법률 업무(legalWork) 재사용.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('superhuman-law', {
  activatedAbility: {
    form: 'alter-ego',
    exhaust: true,
    payCost: { type:'mental', count:1 },
    effect: [{ fx:'removeThreat', scheme:'main', amount:2 }],
  },
  vfx: { ability:'legalWork' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   ★ 플레이 폼 자동 유도 패스 (파일 끝 — 모든 등록 후 실행)
   이벤트 카드의 textKo에서 폼 제한 문구를 파싱해 playForm 자동 부여:
   "히어로 행동/인터럽트/반응" → hero / "알터에고 행동/반응" → alter-ego.
   명시적으로 등록된 playForm은 유지. playCard가 폼 불일치 시 거부.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
let derived = 0;
for (const code in MC.CARDS){
  const d = MC.CARDS[code];
  if (d.side !== 'player' || d.type !== 'event' || d.playForm) continue;
  const t = d.textKo || '';
  if (/히어로\s*(행동|인터럽트|반응)/.test(t)){ d.playForm = 'hero'; derived++; }
  else if (/알터\s*에고\s*(행동|반응)/.test(t)){ d.playForm = 'alter-ego'; derived++; }
}
MC._playFormDerived = derived; // 테스트 확인용
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #27 — 집중된 분노 (Focused Rage)  She-Hulk 시그니처 업그레이드
   히어로 행동: 소진 + 자신에게 1 피해 → 카드 1장 드로우.
   activatedAbility (form:hero + exhaust + selfDamage:1) + draw 효과.
   연출: 분노를 끌어올리는 감마 집중(focusedRage).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('focused-rage', {
  activatedAbility: {
    form: 'hero',
    exhaust: true,
    selfDamage: 1,
    effect: [{ fx:'draw', amount:1 }],
  },
  vfx: { ability:'focusedRage' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #28 — 초인적인 힘 (Superhuman Strength)  She-Hulk 시그니처 업그레이드
   지속: She-Hulk ATK +2. 강제 반응: 기본 공격 후 → 자체 버림 + 공격받은 적 기절.
   statMod(패시브) + afterBasicAttack 핸들러(자체 버림 + 대상 stun).
   테마(웹 확인): 초인적 힘은 She-Hulk의 트레이드마크 — 차량도 들어올리는 파워.
   연출: 강력한 완력 강타(superStrength).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.HANDLERS.superhumanStrengthForced = function(G, ctx){
  const card = ctx.self, pl = ctx.player, target = ctx.target;
  const zone = pl.playArea.upgrades;
  const i = zone.findIndex(c => c.uid === card.uid);
  if (i >= 0){ const c = zone.splice(i,1)[0]; pl.discard.push(c); }
  MC.log(G, MC.nameOf(card) + ' — 초인적인 힘 발휘 (버림)');
  if (target && target.status){
    target.status.stunned = (target.status.stunned || 0) + 1;
    MC.log(G, MC.nameOf(target) + ' 기절!');
  }
};
MC.defineCardFx('superhuman-strength', {
  statMod: { stat:'attack', amount:2 },   // 지속: She-Hulk ATK +2
  afterBasicAttack: 'superhumanStrengthForced',
  vfx: { install:'gammaInstall', basicAttack:'superStrength' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #30 — 워 머신 (War Machine)  아이언맨 동료 (제임스 로즈)
   행동: 워 머신 소진 + 자신에게 2 피해 → 모든 적에게 1 피해 (광역 화력 지원).
   activatedAbility (exhaust + selfDamage:2 to card + allEnemies 1 피해).
   테마(웹): 아이언맨 세계관의 중무장 아머 — 로디는 미사일·개틀링 등 중화기 특화.
   연출: 미사일 일제 사격 광역(warMachineBarrage).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('war-machine', {
  activatedAbility: {
    exhaust: true,
    selfDamage: 2,
    selfDamageTarget: 'card',        // 자신(동료)에게 피해
    effect: [{ fx:'dealDamage', target:'allEnemies', amount:1 }],
  },
  vfx: { ability:'warMachineBarrage', entrance:'allyEnter' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #31 — 리펄서 블래스트 (Repulsor Blast)  아이언맨 시그니처
   히어로 공격: 적 1 피해 + 덱 위 5장 버림 → 인쇄 에너지 아이콘당 추가 2 피해.
   repulsorBlast 효과(대상 chosen). 테마(웹): 아이언맨 상징 리펄서 — 손바닥 에너지포.
   연출: 청백색 리펄서 광선(repulsorBeam).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('repulsor-blast', {
  effects: [{ fx:'repulsorBlast', target:'chosen', base:1, mill:5, perEnergy:2 }],
  vfx: { basicAttack:'repulsorBeam' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #32 — 초음속 펀치 (Supersonic Punch)  아이언맨 시그니처
   히어로 공격: 적 4 피해 (Aerial 특성 보유 시 8 피해).
   dealDamage + amountIf(Aerial 시 8). 테마(웹): 아이언맨 비행 돌진 초음속 강타.
   연출: 초음속 돌진 강타(supersonicPunch).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('supersonic-punch', {
  effects: [{ fx:'dealDamage', target:'chosen', amount:4,
              amountIf:{ cond:{ type:'hasTrait', trait:'aerial' }, amount:8 } }],
  vfx: { basicAttack:'supersonicPunch', basicAttackAerial:'supersonicFlight' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #33 — 페퍼 포츠 (Pepper Potts)  아이언맨 시그니처 서포트
   자원: 소진 → 버린 더미 맨 위 카드의 자원 생성 (동적 자원 재활용).
   resourceGenerator(exhaust + fromDiscardTop). 테마(웹): 토니의 유능한 조력자·조율가.
   설치 연출: 아크 원자로 테마(iron-man 매핑 자동). 자원 생성: pepperAssist.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('pepper-potts', {
  resourceGenerator: { exhaust: true, fromDiscardTop: true },
  vfx: { resource:'pepperAssist' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #34 — 스타크 타워 (Stark Tower)  아이언맨 시그니처 서포트(장소)
   알터에고 행동: 소진 → 플레이어 선택 → 그 플레이어 버림 더미 맨 위 Tech 업그레이드
   손 반환. activatedAbility(form:alter-ego + exhaust) + returnTopTraitUpgrade(기술).
   테마(웹): 토니의 본거지·기술 회수. 설치는 arcInstall(iron-man 매핑 자동).
   연출: 타워에서 장비 회수(techRecall).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('stark-tower', {
  activatedAbility: {
    form: 'alter-ego',
    exhaust: true,
    effect: [{ fx:'returnTopTraitUpgrade', trait:'기술', cardType:'upgrade' }],
  },
  vfx: { ability:'techRecall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #34 — 스타크 타워 (Stark Tower)  아이언맨 시그니처 서포트(장소)
   알터에고 행동: 소진 → 플레이어 선택 → 버림 더미 맨 위 Tech 업그레이드 손으로 반환.
   activatedAbility (form:alter-ego + exhaust) + recallFromDiscard(trait:tech, upgrade).
   테마(웹): 토니의 본거지 스타크 타워 — 장비 재보급 거점.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('stark-tower', {
  activatedAbility: {
    form: 'alter-ego',
    exhaust: true,
    effect: [{ fx:'recallFromDiscard', trait:'tech', cardType:'upgrade' }],
  },
  vfx: { ability:'techRecall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #35 — 아크 원자로 (Arc Reactor)  아이언맨 시그니처 업그레이드
   히어로 행동: 소진 → Iron Man 준비(ready). 한 턴 추가 행동.
   activatedAbility (form:hero + exhaust + readySelf). 테마: 토니의 심장, 아크 원자로.
   설치 연출: arcInstall(iron-man 매핑 자동). 능력 연출: arcReactorReady.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('arc-reactor', {
  activatedAbility: {
    form: 'hero',
    exhaust: true,
    effect: [{ fx:'readySelf' }],
  },
  vfx: { ability:'arcReactorReady' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #36 — MK.5 아머 (Mark V Armor)  아이언맨 시그니처 업그레이드
   지속: HP +6 (최대 HP 증가, 버려지면 보너스 소멸). hpBonus + whenPlayed 재계산.
   테마: 아이언맨 방어 아머. 설치 연출 arcInstall(자동). Tech라 손패 +1도.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('mk5-armor', {
  hpBonus: 6,
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'refreshMaxHp' }],
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #37 — MK.5 헬멧 (Mark V Helmet)  아이언맨 시그니처 업그레이드
   히어로 행동(저지): 소진 → 스킴 1개 위협 1 제거 (Aerial이면 모든 스킴 1씩).
   activatedAbility (form:hero + exhaust) + removeThreat(allSchemesIf: aerial).
   테마: 헬멧 표적 시스템. 설치 arcInstall(자동). 능력 연출 helmetTarget.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('mk5-helmet', {
  activatedAbility: {
    form: 'hero',
    exhaust: true,
    effect: [{ fx:'removeThreat', amount:1,
               allSchemesIf:{ type:'hasTrait', trait:'aerial' } }],
  },
  vfx: { ability:'helmetTarget', abilityAerial:'helmetTargetAll' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #38 — 동력 건틀릿 (Powered Gauntlets)  아이언맨 시그니처 업그레이드
   히어로 행동(공격): 소진 → 적 1 피해 (Aerial이면 2). 매 턴 반복 화력.
   activatedAbility (form:hero + exhaust) + dealDamage(chosen, amountIf: aerial→2).
   조건부 연출: gauntletBlast(지상) / gauntletBlastAerial(비행 강화).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('powered-gauntlets', {
  activatedAbility: {
    form: 'hero',
    exhaust: true,
    needsTarget: true,
    effect: [{ fx:'dealDamage', target:'chosen', amount:1,
               amountIf:{ cond:{ type:'hasTrait', trait:'aerial' }, amount:2 } }],
  },
  vfx: { ability:'gauntletBlast', abilityAerial:'gauntletBlastAerial' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #39 — 로켓 부츠 (Rocket Boots)  아이언맨 시그니처 업그레이드
   지속: HP +1. 히어로 행동: 소진 + 자원 1 지불 → 이번 페이즈 Aerial 획득.
   hpBonus + activatedAbility(exhaust + payCost mental1 + grantTrait aerial).
   아이언맨 Aerial 부여 핵심(초음속/건틀릿/헬멧 강화 조건 켜기).
   설치 arcInstall(자동). 능력 연출 rocketBoost.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('rocket-boots', {
  hpBonus: 1,
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'refreshMaxHp' }],
  activatedAbility: {
    form: 'hero',
    exhaust: true,
    payCost: { type:'mental', count:1 },
    effect: [{ fx:'grantTrait', trait:'aerial' }],
  },
  vfx: { ability:'rocketBoost' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #40 — 슈리 (Shuri)  블랙팬서 시그니처 동료
   테마(웹): 와칸다의 나노테크 천재 공주 — "수트 전체가 목걸이 이빨 안에",
   나노입자 조립·홀로그램 제어. 장난기 있는 재치("그렇게 세게 치라곤 안 했어,
   천재야!"), 오빠 티찰라와의 티키타카("나 없으면 넌 길을 잃을걸, 오빠!").
   반응: 슈리 등장 후 → 덱에서 업그레이드 1장 탐색해 손에 추가. 덱 셔플.
   결정적 단순화: Black Panther 업그레이드 우선, 없으면 첫 업그레이드
   (BP 덱에서 전략적으로 자명한 선택 — UI 선택 모달은 차후 확장).
   설치 연출 wakandaTech(나노입자 수렴 + 스캔라인 조립 + 홀로 링).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('shuri', {
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'searchDeckToHand',
    filters:[{ type:'upgrade', trait:'black panther' }, { type:'upgrade' }],
    reveal:'shuri', logName:'슈리' }],
  vfx: { install:'wakandaTech', basicThwart:'patrol' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #42 — 조상의 지식 (Ancestral Knowledge)  블랙팬서 시그니처 이벤트
   테마: 조상 평원(Ancestral Plane) — 하트 모양 약초의 환상 속 보라빛 밤하늘
   아래 조상들의 영혼에게서 지혜를 얻는다. "와칸다에서는 조상들의 지식에서
   힘을 얻습니다." —티찰라
   알터에고 행동: 버린 더미에서 서로 다른(이름 기준) 카드 최대 3장 → 덱에 셔플.
   결정적 단순화: ① BP 업그레이드 ② 와칸다 포에버 ③ 버림 최신순 — 서로 다른
   defCode 3장 (UI 선택 모달 차후). 자기 자신(해결 중 카드)은 제외.
   연출 ancestralPlane: 보라 영혼 불꽃 상승 + 별 반짝임.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.EFFECTS.ancestralKnowledge = function(G, p, ctx){
  const pl = ctx.player;
  const selfUid = ctx.card && ctx.card.uid;
  const pool = pl.discard.filter(c => c.uid !== selfUid);
  const picked = [], seen = new Set();
  const take = pred => {
    for (let i = pool.length - 1; i >= 0 && picked.length < 3; i--){  // 최신(뒤)부터
      const c = pool[i];
      if (seen.has(c.defCode) || picked.includes(c)) continue;
      if (pred && !pred(c)) continue;
      picked.push(c); seen.add(c.defCode);
    }
  };
  take(c => { const d = MC.cardDef(c.defCode); return d.type==='upgrade' && (d.traits||[]).includes('black panther'); });
  take(c => c.defCode === 'wakanda-forever');
  take(null);
  if (!picked.length){ MC.log(G, '조상의 지식 — 버린 더미가 비어 있음'); return; }
  for (const c of picked){
    pl.discard.splice(pl.discard.indexOf(c), 1);
    pl.deck.push(c);
  }
  MC.shuffle(G, pl.deck);
  MC.log(G, '조상의 지식 — ' + picked.map(c=>MC.nameOf(c)).join(', ') + ' 덱에 셔플');
};
MC.defineCardFx('ancestral-knowledge', {
  playForm: 'alter-ego',
  effects: [{ fx:'ancestralKnowledge' }],
  vfx: { play:'ancestralPlane' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #43~49 — 와칸다 포에버! + BP 업그레이드 4종 (세트의 심장)
   테마: "Wakanda Forever!" — 가슴 앞 X자 팔 교차 경례. 비브라늄 장비들이
   연쇄적으로 힘을 발휘하는 필살 시퀀스.
   ─ 와칸다 포에버(01043, 이벤트 1): 히어로 행동 — 조종하는 각 BP 업그레이드의
     "특수" 능력을 임의 순서로 해결. 마지막 단계는 강화 수치.
     결정적 단순화(전략 최적): 슈트 → 재능 → 단검 → 발톱(최종 강화 = 최대 이득).
   ─ 에너지 단검(01046, 2): 특수 — 플레이어 선택(솔로=자신). 빌런과 그 플레이어
     교전 적 각각 1 피해 (최종 2). 비공격(반격 미유발).
   ─ 팬서 발톱(01047, 2): 특수(공격) — 적 2 피해 (최종 4). 빌런 우선.
   ─ 전술적 재능(01048, 2): 특수(저지) — 스킴 위협 1 제거 (최종 2). 메인 우선.
   ─ 비브라늄 슈트(01049, 2): 특수(공격) — 히어로 피해 1을 적에게 이동 (최종 2).
     흡수한 운동 에너지의 재분배 — 피해 없으면 이동 불가(무효).
   설치 연출: 4종 모두 wakandaTech(나노테크 조립). 특수 발동 연출은 조건부
   분리 — specialGlow(일반, 보라) / specialGlowFinal(최종 강화, 금색 대형).
   시퀀스는 G.fxWakandaSeq { steps:[{uid,defCode,final}] } 힌트 → UI 순차 재생.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

const aliveEnemies = (G, pl) => {
  const out = [];
  if (G.villain && G.villain.hp > 0) out.push(G.villain);
  for (const m of (pl.engagedMinions || [])) if (m.hp > 0) out.push(m);
  return out;
};

/* 특수 능력 핸들러 — ctx: { player, final } */
MC.HANDLERS.bpSpecialDaggers = function(G, ctx){
  const pl = ctx.player, dmg = ctx.final ? 2 : 1;
  const hit = aliveEnemies(G, pl);
  for (const e of hit) MC.applyDamage(G, e, dmg, {});   // 비공격 — 반격 미유발
  if (ctx.step) ctx.step.targets = hit.map(e => e.uid);
  MC.log(G, '에너지 단검 특수 — 적 ' + hit.length + '명에게 각 ' + dmg + ' 피해' + (ctx.final ? ' (최종 강화)' : ''));
};
MC.HANDLERS.bpSpecialClaws = function(G, ctx){
  const pl = ctx.player, dmg = ctx.final ? 4 : 2;
  const tgt = aliveEnemies(G, pl)[0];
  if (!tgt){ MC.log(G, '팬서 발톱 특수 — 대상 없음'); return; }
  MC.applyDamage(G, tgt, dmg, { source: pl, isAttack: true });
  if (ctx.step) ctx.step.target = tgt.uid;
  MC.log(G, '팬서 발톱 특수 — ' + (tgt.uid === (G.villain||{}).uid ? '빌런' : MC.nameOf(tgt)) + '에게 ' + dmg + ' 피해' + (ctx.final ? ' (최종 강화)' : ''));
};
MC.HANDLERS.bpSpecialGenius = function(G, ctx){
  const amt = ctx.final ? 2 : 1;
  MC.removeThreat(G, 'main', amt);
  if (ctx.step) ctx.step.schemeUid = (G.mainScheme || {}).uid;
  MC.log(G, '전술적 재능 특수 — 메인 스킴 위협 ' + amt + ' 제거' + (ctx.final ? ' (최종 강화)' : ''));
};
MC.HANDLERS.bpSpecialSuit = function(G, ctx){
  const pl = ctx.player;
  const taken = pl.maxHp - pl.hp;
  const move = Math.min(ctx.final ? 2 : 1, taken);
  if (move <= 0){ MC.log(G, '비브라늄 슈트 특수 — 이동할 피해 없음'); return; }
  const tgt = aliveEnemies(G, pl)[0];
  if (!tgt){ MC.log(G, '비브라늄 슈트 특수 — 대상 없음'); return; }
  pl.hp += move;
  MC.applyDamage(G, tgt, move, { source: pl, isAttack: true });
  if (ctx.step){ ctx.step.target = tgt.uid; ctx.step.heroUid = pl.uid; }
  MC.log(G, '비브라늄 슈트 특수 — 키네틱 에너지 재분배: 피해 ' + move + ' 이동' + (ctx.final ? ' (최종 강화)' : ''));
};

MC.defineCardFx('energy-daggers',    { special:'bpSpecialDaggers', vfx:{ install:'daggersInstall', special:'energyDaggers' } });
MC.defineCardFx('panther-claws',     { special:'bpSpecialClaws',   vfx:{ install:'clawsInstall', special:'claws' } });
MC.defineCardFx('tactical-genius-bp',{ special:'bpSpecialGenius',  vfx:{ install:'tacticsInstall', special:'tacticalHolo' } });
MC.defineCardFx('vibranium-suit',    { special:'bpSpecialSuit',    vfx:{ install:'suitInstall', special:'kineticTransfer' } });

/* 와칸다 포에버! — 조종 중인 BP 업그레이드를 플레이어가 정한 순서로 순차 해결.
   ★ 순서 하드코딩 금지: 대상은 카드 고유 속성(black panther 특성 + special)으로 식별하고,
     해결 순서는 플레이어가 선택(pending: wakandaOrder). 업그레이드 1개면 자동 해결. */
MC.EFFECTS.wakandaForever = function(G, p, ctx){
  const pl = ctx.player;
  const ups = (pl.playArea.upgrades || []).filter(c => {
    const d = MC.cardDef(c.defCode);
    return d && d.special && (d.traits || []).includes('black panther');
  });
  if (!ups.length){ MC.log(G, '와칸다 포에버! — 조종하는 BP 업그레이드 없음'); return; }
  if (ups.length === 1){
    MC.resolveWakandaUpgrade(G, pl, ups[0], true);
    return;
  }
  // 2개 이상 → 플레이어가 해결 순서 선택 (탭한 순서대로 발동)
  G.pending = { kind:'wakandaOrder', player: pl.uid,
                remaining: ups.map(u => u.uid), total: ups.length, resolved: [] };
  MC.log(G, '와칸다 포에버! — 해결할 BP 업그레이드를 순서대로 선택하세요 (' + ups.length + '개)');
};
/* 단일 BP 업그레이드 해결 (special 핸들러 실행 + vfx step 힌트). */
MC.resolveWakandaUpgrade = function(G, pl, inst, final){
  const step = { uid: inst.uid, defCode: inst.defCode, final: !!final };
  const h = MC.cardDef(inst.defCode).special;
  if (h && MC.HANDLERS[h]) MC.HANDLERS[h](G, { player: pl, final: !!final, card: inst, step });
  G.fxWakandaSeq = { steps: [step] };
  return step;
};
MC.defineCardFx('wakanda-forever', {
  playForm: 'hero',
  effects: [{ fx:'wakandaForever' }],
  vfx: { play:'wakandaForever' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   코어 #44·#45 — 비브라늄 + 황금 도시 (BP 시그니처 마지막 2장)
   ─ 비브라늄(01044, 자원 0): ★★ 와일드 2 생성 — 데이터 완비(resources wild:2),
     결제 파이프라인(resourceIconsOf)이 자동 합산. 등록 효과 없음(패시브 데이터).
   ─ 황금 도시(01045, 지원 3, 장소·와칸다): 알터에고 행동 — 소진 → 2장 드로우.
     테마: 와칸다의 수도 비르닌 자나(Birnin Zana), 황금빛 미래 도시. 왕 티찰라가
     도시로 돌아와 지혜와 조언(카드)을 얻는다.
     설치=wakandaTech(와칸다 테마 통일), 활성화=goldenCity(황금 마천루 상승 +
     금 입자 + 금 링 — vfx.ability 슬롯, UI 자동 재생).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
MC.defineCardFx('golden-city', {
  activatedAbility: { form:'alter-ego', exhaust:true,
                      effect: { fx:'draw', amount:2 } },
  vfx: { install:'wakandaTech', ability:'goldenCity' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 #50 — 헐크 (Hulk, 동료)  Core Set #50
   테마(웹): "HULK SMASH!" — 통제 불가능한 순수 파괴력. 최대 데미지 지향이지만
   자기 파괴 위험(멘탈=자멸). "Hulk, strongest one there is." 감마 방사능 괴력.
   강제 반응(Forced Response): 헐크 공격 후 → 덱 위 1장 버림. 인쇄 자원별:
     · 💪 피지컬: 적 1명에게 2 피해
     · ⚡ 에너지: 각 캐릭터(아군 포함)에게 1 피해
     · 🧠 멘탈: 헐크 버림(자멸)
     · 🌟 와일드: 위 전부
   공식 룰: 이중 아이콘이면 두 번 적용(BGG). 와일드+다중 아이콘은 모든 인쇄
   자원을 동시 체크 후 컨트롤러가 순서 선택(FAQ Salvage) — 결정적 순서:
   피지컬 → 에너지 → 멘탈(자멸 마지막, 헐크가 먼저 사라지지 않도록).
   연출 gammaSmash: 감마 녹색 충격파 + 균열 + HULK SMASH!
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.hulkForcedResponse = function(G, ctx){
  const pl = ctx.player;
  if (!pl || !pl.deck.length){ MC.log(G, '헐크 — 덱이 비어 버릴 카드 없음'); return; }
  const hulk = ctx.attacker;
  const card = pl.deck.shift();
  pl.discard.push(card);
  const ic = MC.resourceIconsOf(card);
  MC.log(G, '헐크 강제 반응 — ' + MC.nameOf(card) + ' 버림 (💪' + ic.physical + ' ⚡' + ic.energy + ' 🧠' + ic.mental + ' 🌟' + ic.wild + ')');

  // 와일드는 모든 유형 발동 + 각 인쇄 아이콘 수만큼 반복(이중 아이콘 = 2회)
  const phys = ic.physical + ic.wild;
  const enrg = ic.energy   + ic.wild;
  const ment = ic.mental   + ic.wild;
  const steps = [];

  // 결정적 순서: 피지컬 → 에너지 → 멘탈(자멸 마지막)
  // 💪 피지컬: 적 1명에게 2 피해 (빌런 우선)
  for (let i = 0; i < phys; i++){
    const enemies = [];
    if (G.villain && G.villain.hp > 0) enemies.push(G.villain);
    for (const m of (pl.engagedMinions || [])) if (m.hp > 0) enemies.push(m);
    const tgt = enemies[0];
    if (tgt){ MC.applyDamage(G, tgt, 2, { source: hulk, isAttack: true });
      steps.push({ kind:'physical', target: tgt.uid });
      MC.log(G, '  💪 ' + (tgt.uid===(G.villain||{}).uid?'빌런':MC.nameOf(tgt)) + '에게 2 피해'); }
  }
  // ⚡ 에너지: 각 캐릭터(아군 포함)에게 1 피해
  for (let i = 0; i < enrg; i++){
    const chars = [];
    if (G.villain && G.villain.hp > 0) chars.push(G.villain);
    for (const p of G.players){
      chars.push(p);                                   // 영웅 신분
      for (const a of p.playArea.allies) chars.push(a); // 아군 동료
      for (const m of p.engagedMinions) chars.push(m);  // 교전 하수인
    }
    const hitUids = [];
    for (const ch of chars){ if (ch.hp > 0){ MC.applyDamage(G, ch, 1, { source: hulk }); hitUids.push(ch.uid); } }
    steps.push({ kind:'energy', targets: hitUids });
    MC.log(G, '  ⚡ 모든 캐릭터 ' + hitUids.length + '명에게 1 피해');
  }
  // 🧠 멘탈: 헐크 버림(자멸) — 마지막
  if (ment > 0){
    const ai = pl.playArea.allies.indexOf(hulk);
    if (ai >= 0){
      pl.playArea.allies.splice(ai, 1);
      MC.moveToDiscard(G, pl, hulk);
      steps.push({ kind:'mental', target: hulk.uid });
      MC.log(G, '  🧠 헐크 버림(자멸)');
    }
  }
  G.fxHulk = { hulkUid: hulk.uid, steps };
};

MC.defineCardFx('hulk-ally', {
  afterAttack: 'hulkForcedResponse',
  vfx: { entrance:'gammaSmash', basicAttack:'gammaSmash' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 #51 — 타이그라 (Tigra, 동료)  Core Set #51
   테마(웹): 야수 본능의 고양이류 여전사 (Greer Grant Nelson). 날카로운 발톱과
   송곳니, 사냥 본능, 초인적 민첩·재생력, 먹잇감 추적. 사냥감을 처치하면 야수의
   활력으로 스스로 회복. "미안해—사인은 없어" — 자신의 야수 외모에 대한 시크한 자조.
   반응: 타이그라가 공격하여 하수인을 처치한 후 → 그녀에게서 1 피해 회복.
   ★ 자원 아이콘 없음 (marvelcdb Resource 공백). cost 3 / ATK 2 / THW 1 / HP 3.
   ★ FAQ: 회복은 consequential damage 적용 전 발생 → 하수인만 계속 잡으면 무한 생존.
      (동료 기본 공격엔 자기 피해가 없어 순서 무관 — afterAttack 시점에 처치 판정)
   연출 tigraPounce: 야수 도약 + 발톱 스크래치 3줄 + 호랑이 줄무늬 잔상 + 회복 반짝임.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.tigraHeal = function(G, ctx){
  const tigra = ctx.attacker;
  const target = ctx.target;
  if (!tigra || !target) return;
  // 하수인을 처치한 경우에만 회복 (빌런/빌런단계 공격은 회복 없음).
  // onDefeated 후에도 target 객체는 유지되며 hp<=0 / type==='minion' 판정 가능.
  const isMinion = target.type === 'minion' ||
                   (MC.cardDef(target.defCode) && MC.cardDef(target.defCode).type === 'minion');
  const defeated = target.hp <= 0;
  if (isMinion && defeated){
    if (tigra.hp < tigra.maxHp){
      MC.healTarget(G, tigra, 1);
      MC.log(G, '타이그라 — 사냥감 처치, 1 회복');
    } else {
      MC.log(G, '타이그라 — 사냥감 처치 (이미 최대 HP)');
    }
    G.fxTigra = { tigraUid: tigra.uid, targetUid: target.uid };
  }
};

MC.defineCardFx('tigra-ally', {
  afterAttack: 'tigraHeal',
  vfx: { entrance:'tigraPounce', basicAttack:'tigraPounce' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 #52 — 추적하라! (Chase Them Down)  Core Set #52
   이벤트. 저지(Thwart). Cost 0. 🧠 멘탈. (공식 자원 — 이전 스텁 💪 오류 정정)
   반응 (저지): 당신의 히어로가 공격으로 적(하수인 또는 빌런 단계)을 처치한 후 →
   스킴에서 2 위협 제거.
   ★ playCondition: justDefeatedEnemyByAttack (히어로가 공격으로 적 처치 직후에만 플레이 가능)
   ★ FAQ(Hall of Heroes): 빌런 단계 처치도 "적 처치"로 간주. 히어로의 기본/이벤트
     공격 모두 트리거 (RRG 재정). onDefeated에서 opt.isAttack + 히어로 source 판정.
   연출: 위협 제거는 기존 removeThreat 시각화 사용 (전용 설치 연출 불필요 — 이벤트).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('chase-them-down', {
  playCondition: { type:'justDefeatedEnemyByAttack' },
  effects: [{ fx:'removeThreat', amount:2 }],
  vfx: { event:'threatDrain' }, eventScheme:true,   // 스킴에서 청록 위협 제거 입자
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 #53 — 거침없는 돌진 (Relentless Assault)  Core Set #53
   이벤트. 공격(Attack). Cost 2. ⚡ 에너지.
   히어로 행동(공격): 하수인 1명에게 5 피해. 💪 피지컬 자원으로 지불했다면 →
   이 공격은 오버킬(Overkill) 획득 (초과 피해 → 빌런).
   ★ 교차검증: 오버킬 조건 = "피지컬(💪) 자원 지불" (cardgamedb + 리뷰 다수 확정).
     marvelcdb 리마인더 텍스트엔 [Physical] 아이콘 생략됐으나 실제 조건은 physical.
   ★ 엔진: applyDamage에 overkill 초과피해→빌런 신설 + dealDamage overkillIf 조건부.
   연출: 공격 이벤트 → 기존 basicAttack 계열 시각화. 전용 설치 연출 불필요(이벤트).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('relentless-assault', {
  effects: [
    { fx:'dealDamage', target:'chosen', amount:5, overkillIf:{ type:'paidWith', resource:'physical' } },
  ],
  vfx: { event:'overkillPierce' },   // 하수인 슬래시 + (오버킬 시) 빌런 관통 궤적
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 #54(인덱스) — 근접 전투 (Melee)  Core Set #05030
   이벤트. 공격(Attack). Cost 3. 🧠 멘탈.
   히어로 행동(공격): 적 1명에게 3 피해. 다른 적 1명에게 3 피해.
   ★ 교차검증: DB 정확 (정정 불필요). marvelcdb "Deal 3 damage to an enemy.
     Deal 3 damage to another enemy." + 공식 FAQ 4건 확보:
     ① 두 번째 피해는 서로 다른 적에게 (same enemy 중복 불가)
     ② 단일 공격/두 피해 라인 — 기절이면 첫 라인이 기절만 제거(피해 없음)
     ③ Guard 하수인을 첫 라인으로 처치 후 두 번째 라인으로 빌런 타격 가능
     ④ 첫 라인이 빌런 단계 처치 시 두 번째도 빌런 (스테이지 변경=같은 빌런)
   ★ 엔진: dealDamageMulti 신설 (순차 다중 대상, 서로 다른 적, 처치 반영).
   연출: 공격 이벤트 → 기존 시각화. 전용 설치 연출 불필요(이벤트).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('melee', {
  effects: [{ fx:'dealDamageMulti', lines:2, amount:3 }],
  vfx: { event:'aggressionSlash' },   // 두 대상에 순차 슬래시 (UI가 targetUids 순회)
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 01054 — 어퍼컷 (Uppercut)  Core Set #54
   이벤트. 공격(Attack). Cost 3. 💪 피지컬.
   히어로 행동(공격): 적 1명에게 5 피해.
   ★ 교차검증: marvelcdb "Deal 5 damage to an enemy." — 단순 5피해 공격.
     "적(enemy)"이라 하수인/빌런 모두 대상 (relentless-assault의 하수인 전용과 대비).
     DB 이미 정확 (정정 불필요). 오버킬/조건 없음.
   연출: 공격 이벤트 → 기존 시각화. 전용 설치 연출 불필요(이벤트).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('uppercut', {
  effects: [{ fx:'dealDamage', target:'chosen', amount:5 }],
  vfx: { event:'aggressionSlash' },   // 대상에 붉은 X자 슬래시
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 01056 — 전술공격팀 (Tac Team)  Core Set #56
   서포트. S.H.I.E.L.D. Cost 3. (자원 아이콘 없음)
   사용(3): 공격 카운터 3개로 등장. 모두 소진 시 버림.
   행동: Tac Team 소진 + 공격 카운터 1개 제거 → 적 1명에게 2 피해.
   ★ 교차검증(메모리 #3): marvelcdb 원문 대조 — 자원 아이콘 없음(Resource 공백) 확정.
     DB의 energy:1 + textKo "💪피지컬" 둘 다 오류였음 → 정정 완료. cost 3, uses 3.
   ★ FAQ: "공격(attack)"이 아니므로 Guard에 막히지 않고 기절도 안 됨 (동료와 차별점).
   ★ 엔진: activatedAbility에 useCounter(카운터 소비 + 소진 시 버림) 신설.
   연출: 설치 = tacticsInstall(S.H.I.E.L.D. 전술 홀로그램 테마 재사용),
         활성화 공격 = aggressionSlash (붉은 슬래시).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('tac-team', {
  uses: 3,   // 공격 카운터 3개로 등장 → inst.counters = 3
  activatedAbility: {
    exhaust: true,
    useCounter: 1,
    needsTarget: true,
    effect: [{ fx:'dealDamage', target:'chosen', amount:2 }],
  },
  vfx: { install:'tacticsInstall', ability:'aggressionSlash' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 01057 — 전투 훈련 (Combat Training)  Core Set #57
   업그레이드. 기술(Skill). Cost 2. 💪 피지컬.
   어느 플레이어의 통제로든 플레이 가능. 플레이어당 최대 1장.
   당신의 히어로는 ATK +1 획득 (지속 효과).
   ★ 교차검증: marvelcdb + cardgamedb 대조 — "Your hero gets +1 ATK." 확정.
     DB 완전 일치 (정정 불필요). cost 2 / 💪피지컬 / upgrade / skill.
   ★ statMod 지속 효과 (초인적인 힘 She-Hulk ATK+2와 동일 패턴). passiveStatMod가
     statOf(attack)에 합산 → 기본 공격 피해 +1.
   연출: 설치 = combatInstall (붉은 주먹 각인 + ATK+1 강화 표시).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('combat-training', {
  statMod: { stat:'attack', amount:1 },   // 지속: 히어로 ATK +1
  maxPerTarget: 1,   // 플레이어당 최대 1장 (Max 1 per player)
  vfx: { install:'combatInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   공격 어스팩트 03031 — 격분 (Enraged)  Captain America #31
   업그레이드. 상태(Condition). Cost 1. 💪 피지컬.
   동료에 부착. 동료당 최대 1장.
   부착된 동료: ATK +2, 공격 후 부수 피해(consequential damage) +1.
   ★ 교차검증: marvelcdb + cardgamedb 대조 — "Attached ally gets +2 ATK and takes
     +1 consequential damage after it attacks." 확정. DB 일치 (정정 불필요).
     cost 1 / 💪피지컬 / upgrade / condition.
   ★ FAQ(Hall of Heroes): +2 ATK는 Assault 저지 시에도 적용되나, +1 consequential
     damage는 "공격할 때만" 적용(저지 시 아님). → allyAttack의 atkCost에만 반영.
   ★ 엔진: attachTarget:'ally' 지원 신설. whenPlayed로 부착 동료 attack+2/atkCost+1.
     동료 격파 시 부착물 함께 정리(releaseAttachments)되므로 원복 불필요.
   연출: 설치 = combatInstall (붉은 분노 각인, 무술/격분 테마 재사용).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('enraged', {
  attachTarget: 'ally',
  maxPerTarget: 1,   // 동료당 최대 1장
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'buffAttachedAlly', attack:2, atkCost:1, logName:'격분' }],
  vfx: { install:'combatInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   정의 어스팩트 01058 — 데어데블 (Daredevil, 동료)  Core Set #58
   동료. 수호자(Defender). Cost 4. (자원 아이콘 없음) 유니크.
   ATK 2 / THW 2 / HP 3.
   반응: 데어데블이 저지한 후 → 적 1명에게 1 피해.
   ★ 교차검증(메모리 #3): marvelcdb 원문 web_fetch — 자원 아이콘 없음(Resource 공백)
     확정. DB의 physical:1 + textKo "🧠멘탈" 둘 다 오류 → 정정 완료.
     cost 4 / ATK 2 / THW 2 / HP 3 / Defender / unique.
   ★ 테마(웹): 맹인 변호사 매트 머독 — 초인 감각(레이더 센스), 낮엔 법정(저지)
     밤엔 주먹(피해). 대사 "법률사무소보다 주먹으로 더 많은 일을".
   ★ FAQ(Blackhaven, Tigra 재정 준용): "데어데블 저지한 후" 조건은 consequential
     damage 적용 *전*에 판정 → 마지막 저지에서도 피해 가능. → afterThwart 훅을
     thwCost 전에 발화 (엔진 신설).
   연출: 설치/반응 = radarSense (붉은 레이더 파동 3겹, 초인 감각 테마).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.daredevilThwartPing = function(G, ctx){
  const dd = ctx.thwarter;
  const target = ctx.targets && ctx.targets[0];
  // UI가 대상을 지정하지 않았으면 빌런을 기본 대상으로 (반응 자동 해소)
  const enemy = target || G.villain;
  if (!enemy || enemy.hp === undefined){ MC.log(G, '데어데블 반응 — 대상 없음'); return; }
  MC.applyDamage(G, enemy, 1, { source: dd });
  MC.log(G, '데어데블 — 저지 후 ' + MC.nameOf(enemy) + '에게 1 피해');
  G.fxDaredevil = { ddUid: dd.uid, targetUid: enemy.uid };
};

MC.defineCardFx('daredevil', {
  afterThwart: 'daredevilThwartPing',
  vfx: { entrance:'radarSense', install:'radarSense' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   정의 어스팩트 01059 — 제시카 존스 (Jessica Jones, 동료)  Core Set #59
   동료. 수호자(Defender). Cost 3. ⚡ 에너지. 유니크.
   ATK 2 / THW 1 / HP 3.
   지속 효과: 제시카 존스는 전장의 각 사이드 스킴마다 THW +1 획득.
   ★ 교차검증(메모리 #3): 공식 JSON(zzorba core.json) resource_energy 확정.
     DB resources {energy:1} 정답, textKo만 "🧠멘탈" 오류 → ⚡에너지로 정정.
     cost 3 / ATK 2 / THW 1 / HP 3 / Defender / unique.
   ★ 테마(웹): 사립탐정(Alias Investigations), 초인적 힘, 사람 찾기 전문.
     "사람 찾는 데 뛰어나다" — 사이드 스킴(찾아야 할 문제)이 많을수록 강해짐.
   ★ 엔진: allyStatOf 동적 스탯 헬퍼 신설 (dynamicStat per:sideScheme).
     allyThwart/allyAttack이 이 헬퍼로 유효 스탯 계산.
   연출: 설치 = detectiveInstall (돋보기 스캔 + 보라색 추적 링, 탐정 테마).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('jessica-jones', {
  dynamicStat: { stat:'thwart', per:'sideScheme' },   // 사이드 스킴 개수만큼 THW +1
  vfx: { entrance:'detectiveInstall', install:'detectiveInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   정의 어스팩트 01060 — 정의를 위해! (For Justice!)  Core Set #60
   이벤트. 저지(Thwart). Cost 2. ⚡ 에너지.
   히어로 행동(저지): 스킴에서 3 위협 제거 (🧠멘탈 자원으로 지불 시 4 위협 제거).
   ★ 교차검증(메모리 #3): 공식 JSON(zzorba core.json) resource_energy 확정.
     DB resources {energy:1} 정답, textKo 첫 줄만 "🧠멘탈" 오류 → ⚡에너지 정정.
     cost 2 / event / Thwart / deckLimit 3.
   ★ 킥커: 멘탈(🧠) 자원으로 지불 시 3→4 (paidWith mental). photon-blast/거침없는
     돌진과 동일 킥커 시스템. removeThreat에 amountIf 신설.
   ★ 플레이버: 캡틴 아메리카 — 정의롭고 단호한 어조로 의역.
   연출: threatDrain (스킴에서 청록 위협 제거 입자) 재사용 + eventScheme.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('for-justice', {
  effects: [{ fx:'removeThreat', amount:3, amountIf:{ cond:{ type:'paidWith', resource:'mental' }, amount:4 } }],
  vfx: { event:'threatDrain' }, eventScheme:true,
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   정의 어스팩트 01061 — 큰 힘에는 큰 책임이 따른다 (Great Responsibility)  Core Set #61
   이벤트. Cost 0. 🧠 멘탈.
   히어로 인터럽트: 스킴에 위협이 놓이려 할 때 → 당신이 그 위협만큼 피해를 대신 받음.
   ★ 교차검증(공식 JSON): resource_mental 확정. DB 정답 (정정 불필요).
     cost 0 / event / 특성 없음 / deckLimit 3 (Core Set #61). 플레이버 공식엔 없음.
   ★ FAQ: 전체 양을 받아야 함(부분 방지 불가). 사이드 스킴 시작 위협은 "놓이는" 것이
     아니므로 적용 불가.
   ★ 엔진: 이벤트 플레이 시 ctx.threatAmount만큼 히어로 피해 + G.preventNextThreat에
     기록 → 다음 placeThreat가 그만큼 위협 배치 취소 (위협→피해 대체).
   연출: 이벤트 기본 시각화 (위협을 몸으로 받는 방어적 카드).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.greatResponsibility = function(G, ctx){
  const pl = ctx.player;
  // 예정 위협량: UI가 ctx.threatAmount로 전달 (인터럽트 대상 위협 배치량).
  const amt = ctx.threatAmount || (ctx.card && ctx.card._threatAmount) || 0;
  if (amt <= 0){ MC.log(G, '큰 힘에는 큰 책임 — 대상 위협 없음'); return; }
  // 전량을 히어로가 피해로 받음 (부분 방지 불가)
  MC.applyDamage(G, pl, amt, { source: ctx.card });
  MC.log(G, '큰 힘에는 큰 책임 — 위협 ' + amt + '을 피해로 받음');
  // 다음 위협 배치를 그만큼 취소하도록 예약
  G.preventNextThreat = (G.preventNextThreat || 0) + amt;
};

MC.defineCardFx('great-responsibility', {
  special: 'greatResponsibility',
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   정의 어스팩트 01063 — 심문실 (Interrogation Room)  Core Set #63
   지원. 장소(Location). Cost 1. ⚡ 에너지. 플레이어당 최대 1장.
   반응: 당신이 하수인을 처치한 후 → 심문실 소진 → 스킴에서 1 위협 제거.
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "🧠멘탈" 오류 → ⚡에너지 정정. cost 1 / support / Location / deckLimit 3.
   ★ FAQ: "당신"=히어로 본인(정체성/업그레이드/자원카드/이벤트). 동료·지원 미포함.
   ★ 엔진: onDefeated에 justDefeatedMinionByHero 플래그 신설 (하수인만, 히어로 소스,
     수단 무관). useCardAbility에 playCondition 검사 추가. activatedAbility playCondition.
   ★ 플레이버: 미스티 나이트 — 강력계 형사 출신의 시니컬·터프한 말투로 의역.
   연출: 설치 = detectiveInstall (심문/수사 테마 재사용), 활성화 = threatDrain.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('interrogation-room', {
  maxPerTarget: 1,   // 플레이어당 최대 1장
  activatedAbility: {
    exhaust: true,
    playCondition: { type:'justDefeatedMinionByHero' },
    effect: [{ fx:'removeThreat', amount:1 }],
  },
  vfx: { install:'detectiveInstall', ability:'threatDrain' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   정의 어스팩트 01064 — 감시팀 (Surveillance Team)  Core Set #64
   지원. S.H.I.E.L.D. Cost 2. 🧠 멘탈.
   사용(3 스눕 카운터): 카운터 3개로 진입. 모두 소진 시 버림.
   행동: 감시팀 소진 + 스눕 카운터 1개 제거 → 스킴에서 1 위협 제거.
   ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
     cost 2 / support / S.H.I.E.L.D. / deckLimit 3 / Uses 3. 공식 flavor 없음.
   ★ 구조: tac-team(전술공격팀)과 동일 — Uses 3 + 소진하며 소비. 차이는 tac-team이
     피해(dealDamage)인 반면 감시팀은 위협 제거(removeThreat). useCounter 재사용.
   ★ FAQ: "행동"이라 매턴 자유 행동(히어로/알터에고 무관). 3번 사용 후 자동 버림.
   연출: 설치 = tacticsInstall(S.H.I.E.L.D. 전술 홀로그램 재사용), 활성화 = threatDrain.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('surveillance-team', {
  uses: 3,   // 스눕 카운터 3개
  activatedAbility: {
    exhaust: true,
    useCounter: 1,
    effect: [{ fx:'removeThreat', amount:1 }],
  },
  vfx: { install:'tacticsInstall', ability:'threatDrain' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   정의 어스팩트 01065 — 히어로의 직감 (Heroic Intuition)  Core Set #65
   업그레이드. 기술(Skill). Cost 2. ⚡ 에너지.
   어느 플레이어의 통제로든 플레이. 플레이어당 최대 1장.
   당신의 히어로는 THW +1 획득 (지속 효과).
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "🧠멘탈" 오류 → ⚡에너지 정정. cost 2 / upgrade / Skill / deckLimit 3. 공식 flavor 없음.
   ★ 구조: 전투 훈련(combat-training, ATK+1)의 THW 버전. statMod 재사용.
   연출: 설치 = detectiveInstall (직감/통찰 테마 재사용).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('heroic-intuition', {
  statMod: { stat:'thwart', amount:1 },   // 지속: 히어로 THW +1
  maxPerTarget: 1,   // 플레이어당 최대 1장
  vfx: { install:'detectiveInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01066 — 호크아이 (Hawkeye, 동료)  Core Set #66
   동료. 어벤져(Avenger). Cost 3. ⚡ 에너지. 유니크.
   ATK 1 / THW 1 / HP 3.
   등장 시 화살(Arrow) 카운터 4개와 함께 진입.
   반응: 하수인이 전장에 등장한 후 → 화살 카운터 1개 제거 → 그 하수인에게 2 피해.
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "🧠멘탈" 오류 → ⚡에너지 정정. cost 3 / ATK 1 / THW 1 / HP 3 / Avenger / unique.
   ★ 테마(웹): 클린트 바튼, 백발백중 명사수, 트릭 애로우. 화살 카운터가 테마와 일치.
   ★ FAQ: 카운터로 하수인 처치해도 Surge/When Revealed 효과는 정상 발동.
   ★ 엔진: 하수인 등장 시 G.minionJustEntered 힌트 신설. condCheck minionJustEntered.
     호크아이는 활성화 능력(useCounter:1) + playCondition으로 등장 직후에만 발동 가능.
   연출: 설치 = combatInstall(궁수 테마), 활성화 = aggressionSlash(화살 명중).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.hawkeyeArrow = function(G, ctx){
  // 방금 등장한 하수인을 대상으로 2 피해
  const mUid = G.minionJustEntered;
  let target = null;
  for (const pl of G.players){
    const m = (pl.engagedMinions||[]).find(x => x.uid === mUid);
    if (m){ target = m; break; }
  }
  if (!target){ MC.log(G, '호크아이 — 대상 하수인 없음'); return; }
  MC.applyDamage(G, target, 2, { source: ctx.card });
  MC.log(G, '호크아이 — 화살! ' + MC.nameOf(target) + '에게 2 피해');
  G.fxHawkeye = { hawkeyeUid: ctx.card.uid, targetUid: target.uid };
};

MC.defineCardFx('hawkeye', {
  uses: 4,   // 화살 카운터 4개
  activatedAbility: {
    exhaust: false,   // 소진 아님 (카운터만 소비, 매 하수인 등장마다 가능)
    useCounter: 1,
    playCondition: { type:'minionJustEntered' },
    special: 'hawkeyeArrow',
  },
  vfx: { entrance:'combatInstall', install:'combatInstall', ability:'aggressionSlash' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01067 — 마리아 힐 (Maria Hill, 동료)  Core Set #67
   동료. S.H.I.E.L.D. Cost 2. 🧠 멘탈. 유니크.
   ATK 1 / THW 2 / HP 2.
   반응: 마리아 힐이 전장에 등장한 후 → 각 플레이어가 카드 1장 드로우.
   ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
     cost 2 / ATK 1 / THW 2 / HP 2 / S.H.I.E.L.D. / unique (Core Set #67).
   ★ 테마(웹): S.H.I.E.L.D. 부국장, 냉철하고 유능한 지휘관. 카드 드로우=정보/지원 조율.
   ★ 엔진: whenPlayed 훅으로 각 플레이어(who:all) 1장 드로우. 기존 draw 이펙트 재사용.
   연출: 설치 = tacticsInstall (S.H.I.E.L.D. 지휘 홀로그램 재사용).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.mariaHillDraw = function(G, ctx){
  MC.runEffectList(G, [{ fx:'draw', who:'all', amount:1 }], ctx);
  MC.log(G, '마리아 힐 — 각 플레이어 카드 1장 드로우');
};

MC.defineCardFx('maria-hill', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'draw', who:'all', amount:1 }],   // 각 플레이어 카드 1장 (데이터 인덱스)
  vfx: { entrance:'tacticsInstall', install:'tacticsInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01068 — 비전 (Vision, 동료)  Core Set #68
   동료. 안드로이드(Android). 어벤져(Avenger). Cost 4. 💪 피지컬. 유니크.
   ATK 2 / THW 1 / HP 3.
   행동: ⚡에너지 자원 1개 소비 → THW 또는 ATK 선택. 페이즈 종료까지 +2. (라운드당 1회)
   ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
     줄만 "⚡에너지" 오류 → 💪피지컬 정정. cost 4 / ATK 2 / THW 1 / HP 3 / unique.
   ★ 주의: 카드 비용 자원은 💪피지컬, 능력 발동 비용은 ⚡에너지 (별개!).
   ★ 테마(웹): 밀도 제어 능력의 안드로이드 어벤져. 냉정하고 논리적.
   ★ 엔진: allyStatOf에 tempStatBonus 합산 신설. useCardAbility에 oncePerRound +
     choice 전달. 페이즈 종료 시 tempStatBonus 초기화. 라운드 리셋 시 usedAbilityThisRound.
   연출: 설치 = combatInstall(안드로이드 테마), 활성화 = combatInstall(밀도 강화).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.visionBoost = function(G, ctx){
  const vision = ctx.card;
  const stat = ctx.choice === 'attack' ? 'attack' : 'thwart';   // 기본 thwart
  vision.tempStatBonus = vision.tempStatBonus || {};
  vision.tempStatBonus[stat] = (vision.tempStatBonus[stat] || 0) + 2;
  MC.log(G, '비전 — ' + (stat==='attack'?'ATK':'THW') + ' +2 (페이즈 종료까지)');
  G.fxVision = { visionUid: vision.uid, stat };
};

MC.defineCardFx('vision', {
  activatedAbility: {
    exhaust: false,   // 소진 아님 (라운드당 1회 제한으로 통제)
    oncePerRound: true,
    payCost: { type:'energy', count:1 },
    special: 'visionBoost',
  },
  vfx: { entrance:'combatInstall', install:'combatInstall', ability:'combatInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01069 — 준비 완료! (Get Ready)  Core Set #69
   이벤트. Cost 0. 💪 피지컬.
   행동: 동료 1명을 준비(Ready) 상태로.
   ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
     줄만 "🧠멘탈" 오류 → 💪피지컬 정정. cost 0 / event / deckLimit 3 (Core Set #69).
   ★ "행동"이라 알터에고 상태에서도 사용 가능. 소진된 동료를 재사용 (추가 공격/저지).
   ★ readyTarget 이펙트 재사용 (대상 exhausted → false).
   ★ 플레이버: 스티브 로저스 — 절제되고 결연한 리더의 어조.
   연출: 이벤트 기본 시각화 (준비=재정비).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('get-ready', {
  effects: [{ fx:'readyTarget', target:'chosen' }],
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01070 — 선두에서 이끌기 (Lead from the Front)  Core Set #70
   이벤트. 전술(Tactic). Cost 2. ⚡ 에너지.
   히어로 행동: 플레이어 1명 선택 → 그 플레이어가 통제하는 각 캐릭터(히어로+동료)가
   페이즈 종료까지 THW +1, ATK +1.
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "🧠멘탈" 오류 → ⚡에너지 정정. cost 2 / event / Tactic / deckLimit 3 (Core Set #70).
   ★ 테마: 캐롤 댄버스(캡틴 마블)의 리더십 — 앞장서서 팀 전체를 강화.
   ★ 엔진: statOf에 히어로 tempStatBonus 합산 신설. 히어로+동료 모두 임시 버프.
     페이즈 종료 시 초기화. (기본 대상=시전 플레이어 본인, ctx.targetPlayer로 지정 가능)
   ★ 플레이버: 캐롤 댄버스 — 앞장서는 리더의 힘찬 구령.
   연출: 이벤트 시각화 (팀 전체 강화 오라).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.leadFromFront = function(G, ctx){
  // 대상 플레이어: ctx.targetPlayer(멀티) 또는 시전자 본인
  const target = (ctx.targetPlayer && G.players.find(p => p.uid === ctx.targetPlayer)) || ctx.player;
  // 히어로 임시 버프 +1/+1
  target.tempStatBonus = target.tempStatBonus || {};
  target.tempStatBonus.thwart = (target.tempStatBonus.thwart || 0) + 1;
  target.tempStatBonus.attack = (target.tempStatBonus.attack || 0) + 1;
  // 모든 동료 임시 버프 +1/+1
  for (const a of target.playArea.allies){
    a.tempStatBonus = a.tempStatBonus || {};
    a.tempStatBonus.thwart = (a.tempStatBonus.thwart || 0) + 1;
    a.tempStatBonus.attack = (a.tempStatBonus.attack || 0) + 1;
  }
  MC.log(G, '선두에서 이끌기 — ' + MC.nameOf(target) + '의 모든 캐릭터 THW+1/ATK+1 (페이즈 종료까지)');
};

MC.defineCardFx('lead-from-the-front', {
  special: 'leadFromFront',
});

/* 05032 Morale Boost — leadership 이벤트. 히어로 1명 이번 라운드 THW+1/ATK+1/DEF+1.
   roundStatBuff 범용 EFFECT + roundStatBonus 인덱스(statOf 합산, 라운드 종료 리셋) 재사용 — 카드는 데이터만. */
MC.defineCardFx('morale-boost', {
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'roundStatBuff', stats:{ thwart:1, attack:1, defense:1 } }],
  vfx: { event:'moraleBoost' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01071 — 호출하기 (Make the Call)  Core Set #71
   이벤트. Cost 0. 🧠 멘탈.
   행동: 어느 플레이어의 버림 더미에서 동료 1명 선택 → 그 동료의 인쇄된 비용 지불 →
   당신의 통제로 전장에 배치.
   ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
     cost 0 / event / deckLimit 3 (Core Set #71).
   ★ FAQ: "플레이"가 아닌 "전장 배치" — Helicarrier/Avengers Tower 할인 적용 X.
     Play 제약(Groot, Ghost-Spider 등) 무시 가능. Power of Leadership은 적용됨.
   ★ 엔진: special 핸들러 — a.recallUid로 지정된 동료를 버림 더미에서 찾아 전장 배치 +
     whenPlayed 훅 발화. 인쇄 비용 지불은 결제 시스템(UI)에서 처리.
   ★ 플레이버: 마리아 힐 — 비상 소집 지휘관의 다급한 명령.
   연출: 설치 = tacticsInstall (소집/지휘 테마 재사용).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.makeTheCall = function(G, ctx){
  const pl = ctx.player;
  const recallUid = ctx.recallUid;
  if (!recallUid){ MC.log(G, '호출하기 — 대상 동료 미지정'); return; }
  // 모든 플레이어의 버림 더미에서 대상 동료 탐색
  let ally = null, ownerPl = null;
  for (const p of G.players){
    const i = p.discard.findIndex(c => c.uid === recallUid);
    if (i >= 0){ ally = p.discard[i]; ownerPl = p; p.discard.splice(i, 1); break; }
  }
  if (!ally){ MC.log(G, '호출하기 — 버림 더미에서 동료를 찾지 못함'); return; }
  // 전장 배치 (시전자 통제) + 상태 초기화
  ally.ownerUid = pl.uid;
  ally.exhausted = false;
  ally.hp = ally.maxHp = (MC.cardDef(ally.defCode).hp || ally.hp);
  ally.tempStatBonus = {};
  pl.playArea.allies.push(ally);
  MC.log(G, '호출하기 — ' + MC.nameOf(ally) + '를 전장에 배치');
  // whenPlayed 훅 발화 (마리아 힐 드로우 등 등장 효과 — FAQ: 배치도 등장 반응 트리거)
  MC.fireCardHook(G, ally, 'whenPlayed', { player: pl, card: ally });
  G.fxMakeCall = { allyUid: ally.uid };
};

MC.defineCardFx('make-the-call', {
  special: 'makeTheCall',
  vfx: { install:'tacticsInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);


/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01073 — 트리스켈리온 (The Triskelion)  Core Set #73
   지원. 장소(Location). S.H.I.E.L.D. Cost 1. ⚡ 에너지. (deckLimit 1)
   지속 효과: 당신의 동료 한도 +1 (3 → 4명 제어 가능).
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "🧠멘탈" 오류 → ⚡에너지 정정. cost 1 / support / Location+S.H.I.E.L.D. (Core #73).
   ★ 엔진: allyLimitOf 헬퍼 신설 (기본 3 + allyLimitBonus 합산). playCard 동료 플레이
     시 한도 검사. 트리스켈리온 = allyLimitBonus:1.
   ★ 플레이버: 쉬헐크 — 뉴욕 S.H.I.E.L.D. 본부의 높이를 농담조로.
   연출: 설치 = tacticsInstall (S.H.I.E.L.D. 본부 홀로그램 재사용).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('the-triskelion', {
  allyLimitBonus: 1,   // 동료 한도 +1 (지속)
  vfx: { install:'tacticsInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   리더십 어스팩트 01074 — 감화 (Inspired)  Core Set #74
   업그레이드. 상태(Condition). Cost 1. 💪 피지컬.
   동료에 부착. 동료당 최대 1장. 부착된 동료 THW +1, ATK +1 (지속).
   ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
     줄만 "🧠멘탈" 오류 → 💪피지컬 정정. cost 1 / upgrade / Condition (Core Set #74).
   ★ 구조: 격분(enraged)과 유사한 동료 부착이나, 부수 피해 없이 순수 THW+1/ATK+1.
     attachTarget:'ally' 재사용. tempStatBonus가 아닌 영구 부착이므로 attack/thwart 직접 수정.
   ★ 플레이버: 스타로드 — 가디언즈 특유의 가벼운 감탄조.
   연출: 설치 = combatInstall (동료 고무/각성 테마).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('inspired', {
  attachTarget: 'ally',
  maxPerTarget: 1,   // 동료당 최대 1장
  whenPlayed: 'runCardEffects',
  whenPlayedEffects: [{ fx:'buffAttachedAlly', attack:1, thwart:1, logName:'감화' }],
  vfx: { install:'combatInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   보호 어스팩트 01076 — 루크 케이지 (Luke Cage, 동료)  Core Set #76
   동료. 수호자(Defender). Cost 4. ⚡ 에너지. 유니크.
   ATK 2 / THW 1 / HP 5.
   강인함(Toughness): 등장 시 강인(Tough) 상태 카드와 함께 진입.
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "💪피지컬" 오류 → ⚡에너지 정정. cost 4 / ATK 2 / THW 1 / HP 5 / Defender / unique.
   ★ 테마(웹): 파괴 불가 피부의 히어로 포 하이어, 할렘의 수호자. HP 5 최고 체력 탱커.
   ★ 엔진: whenPlayed로 자신에게 tough 상태 부여 (보호 어스팩트 최초 Toughness 동료).
     기존 setStatus(tough) 재사용. 첫 공격/저지 피해를 tough가 1회 무효화.
   ★ 플레이버: 루크 케이지 — 히어로 포 하이어 특유의 시크한 자기소개.
   연출: 설치 = combatInstall (강인한 방벽 테마).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.lukeCageTough = function(G, ctx){
  const self = ctx.card;
  MC.setStatus(G, self, 'tough', true);
  MC.log(G, '루크 케이지 — 강인함(Tough) 상태와 함께 등장');
};

MC.defineCardFx('luke-cage', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx:'applyStatus', target:'card', status:'tough' }],   // 자신 Tough (데이터 인덱스, target:'card')
  vfx: { entrance:'combatInstall', install:'combatInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   보호 어스팩트 01077 — 카운터 펀치 (Counter-Punch)  Core Set #77
   이벤트. 공격(Attack). Cost 0. 💪 피지컬.
   반응(공격): 히어로가 적 공격을 방어한 후 → 그 적에게 히어로 ATK만큼 피해.
   ★ 교차검증(공식 JSON): resource_physical 확정. DB 완전 일치 (정정 불필요).
     cost 0 / event / Attack / deckLimit 3 (Core Set #77).
   ★ FAQ: Guard 하수인 교전 중 빌런 공격 방어 시 사용 불가 (빌런을 공격 못함).
   ★ 엔진: resolveDefensePending에 justDefendedAgainst 힌트 신설 (히어로 방어 시만).
     condCheck justDefended. special 핸들러가 그 적에게 히어로 ATK 피해.
   ★ 플레이버: 아이언 피스트 — 쿵푸 마스터의 통쾌한 반격 대사.
   연출: 이벤트 = aggressionSlash (반격 타격).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.counterPunch = function(G, ctx){
  const pl = ctx.player;
  const enemyUid = pl.justDefendedAgainst;
  if (!enemyUid){ MC.log(G, '카운터 펀치 — 방금 방어한 적 없음'); return; }
  const enemy = MC.findByUid(G, enemyUid);
  if (!enemy || enemy.hp === undefined){ MC.log(G, '카운터 펀치 — 대상 적 없음'); return; }
  const atk = MC.statOf(G, pl, 'attack') || 0;
  MC.applyDamage(G, enemy, atk, { source: pl, isAttack: true });
  MC.log(G, '카운터 펀치 — ' + MC.nameOf(enemy) + '에게 히어로 ATK ' + atk + ' 반격');
  delete pl.justDefendedAgainst;   // 1회성 소비
  G.fxEvent = { vfx:'aggressionSlash', targetUids:[enemy.uid], villainUid:(G.villain&&G.villain.uid)||null, scheme:null };
};

MC.defineCardFx('counter-punch', {
  playCondition: { type:'justDefended' },
  special: 'counterPunch',
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   보호 어스팩트 01080 — 의료팀 (Med Team)  Core Set #80
   지원. S.H.I.E.L.D. Cost 3. ⚡ 에너지.
   사용(3 의료 카운터): 카운터 3개로 진입. 모두 소진 시 버림.
   행동: 의료팀 소진 + 의료 카운터 1개 제거 → 아군 캐릭터 1명의 피해 2 회복.
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "💪피지컬" 오류 → ⚡에너지 정정. cost 3 / support / S.H.I.E.L.D. / Uses 3 (Core #80).
   ★ 구조: 감시팀(surveillance-team)/전술공격팀(tac-team)과 동일 useCounter 구조.
     차이는 위협 제거/피해 대신 heal 2. 아군(히어로/동료) 대상.
   ★ FAQ: "행동"이라 매턴 자유 행동. 3번 사용 후 자동 버림.
   연출: 설치 = tacticsInstall(S.H.I.E.L.D. 의료 홀로그램 재사용), 활성화 = healPulse.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('med-team', {
  uses: 3,   // 의료 카운터 3개
  activatedAbility: {
    exhaust: true,
    useCounter: 1,
    needsTarget: true,
    effect: [{ fx:'heal', target:'chosen', amount:2 }],
  },
  vfx: { install:'tacticsInstall', ability:'healPulse' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   보호 어스팩트 01081 — 방탄 조끼 (Armored Vest)  Core Set #81
   업그레이드. 갑옷(Armor). Cost 1. 🧠 멘탈.
   어느 플레이어의 통제로든 플레이. 플레이어당 최대 1장.
   당신의 히어로는 DEF +1 획득 (지속).
   ★ 교차검증(공식 JSON): resource_mental 확정. DB {mental:1} 정답, textKo 첫 줄만
     "💪피지컬" 오류 → 🧠멘탈 정정. cost 1 / upgrade / Armor / deckLimit 3 (Core #81).
   ★ 구조: 전투 훈련(ATK+1)/히어로의 직감(THW+1)의 DEF 버전. statMod 재사용.
     방어 시 받는 피해를 1 더 줄임 (보호 어스팩트 핵심 방어 업그레이드).
   ★ 플레이버: 실용적이면서 스타일리시한 방어구 소개.
   연출: 설치 = combatInstall (갑옷 장착 테마).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('armored-vest', {
  statMod: { stat:'defense', amount:1 },   // 지속: 히어로 DEF +1
  maxPerTarget: 1,   // 플레이어당 최대 1장
  vfx: { install:'combatInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   보호 어스팩트 01082 — 불굴의 정신 (Indomitable)  Core Set #82
   업그레이드. 상태(Condition). Cost 1. ⚡ 에너지.
   반응: 히어로가 방어한 후 → 불굴의 정신을 버림 → 히어로 준비(Ready).
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "💪피지컬" 오류 → ⚡에너지 정정. cost 1 / upgrade / Condition / deckLimit 3 (Core #82).
   ★ 엔진: justDefended 조건(카운터 펀치에서 만든 것) 재사용. activatedAbility로
     발동 시 자신을 버림(special) + 히어로 준비(readySelf). 방어→준비→추가 행동 콤보.
   ★ 플레이버: 캡틴 아메리카 — 결연한 불굴의 의지.
   연출: 활성화 = combatInstall (재정비/재기 테마).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.indomitableReady = function(G, ctx){
  const pl = ctx.player;
  const card = ctx.card;
  // 히어로 준비
  pl.exhausted = false;
  MC.log(G, '불굴의 정신 — 히어로 준비(Ready)');
  // 자신을 버림
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    const i = arr.indexOf(card);
    if (i >= 0){ arr.splice(i, 1); break; }
  }
  MC.moveToDiscard(G, pl, card, {});
  delete pl.justDefendedAgainst;   // 방어 반응 소비
};

MC.defineCardFx('indomitable', {
  activatedAbility: {
    playCondition: { type:'justDefended' },
    special: 'indomitableReady',
  },
  vfx: { install:'combatInstall', ability:'combatInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01083 — 모킹버드 (Mockingbird, 동료)  Core Set #83
   동료. S.H.I.E.L.D. 첩보원(Spy). Cost 3. 💪 피지컬. 유니크.
   ATK 1 / THW 1 / HP 3.
   반응: 모킹버드가 등장한 후 → 적 1명에게 기절(Stun) 상태 부여.
   ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
     줄만 "🧠멘탈" 오류 → 💪피지컬 정정. cost 3 / ATK 1 / THW 1 / HP 3 / unique.
   ★ 테마(웹): 바비 모스, S.H.I.E.L.D. 첩보원, 배튼 무술가, 호크아이 파트너.
   ★ 엔진: whenPlayed로 대상 적(ctx.targets)에게 stunned 부여. applyStatus 재사용.
     기본 어스팩트라 모든 히어로 덱에 넣을 수 있음.
   ★ 플레이버: 모킹버드 — 첩보원 특유의 시크하고 주도적인 말투.
   연출: 설치 = combatInstall(첩보/무술 테마), 등장 시 대상 기절.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 모킹버드(01083) — 등장 후 적 1명 선택 기절. 범용 chooseEnemy 인덱스로 데이터화.
   후보(빌런+교전 하수인)가 1명이면 자동, 여럿이면 대상 선택 pending. */
MC.defineCardFx('mockingbird', {
  whenPlayed: 'runCardEffects',
  effects: [{ fx: 'chooseEnemy', prompt: '기절시킬 적 선택',
    then: [{ fx: 'applyStatus', target: 'chosen', status: 'stunned' },
           { fx: 'playVfx', vfx: 'stunStrike', quoteKey: 'mockingbird', quoteKind: 'stun', target: 'chosen' }] }],
  vfx: { entrance:'combatInstall', install:'combatInstall' },
  quoteKey: 'mockingbird',
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01084 — 닉 퓨리 (Nick Fury, 동료)  Core Set #84
   동료. S.H.I.E.L.D. 첩보원(Spy). Cost 4. 🧠 멘탈. 유니크.
   ATK 2 / THW 2 / HP 3.
   강제 반응: 등장 후 하나 선택 — 위협 2 제거 / 카드 3장 드로우 / 적에게 4 피해.
   라운드 종료 시 아직 전장에 있으면 버림.
   ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
     cost 4 / ATK 2 / THW 2 / HP 3 / S.H.I.E.L.D.+Spy / unique (Core Set #84).
   ★ 엔진: whenPlayed(choice로 3택 실행) + endOfRound(라운드 종료 시 버림). ctx.choice
     전달. endOfRound 훅은 fireHook(allInPlay)로 발화.
   ★ FAQ: "라운드 끝" ≠ "페이즈 끝" — 빌런 공격 블록 후 버림.
   ★ 플레이버: 닉 퓨리 — S.H.I.E.L.D. 국장의 능글맞고 자신만만한 첩보 대가 색깔.
   연출: 설치 = tacticsInstall(S.H.I.E.L.D. 국장 지휘 홀로그램).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.nickFuryChoice = function(G, ctx){
  const pl = ctx.player;
  const choice = ctx.choice || 'draw';   // 기본 draw
  if (choice === 'thwart'){
    MC.runEffectList(G, [{ fx:'removeThreat', amount:2 }], ctx);
    MC.log(G, '닉 퓨리 — 위협 2 제거');
  } else if (choice === 'damage'){
    const enemy = (ctx.targets && ctx.targets[0]) || G.villain;
    if (enemy && enemy.hp !== undefined){
      MC.applyDamage(G, enemy, 4, { source: ctx.card });
      MC.log(G, '닉 퓨리 — ' + MC.nameOf(enemy) + '에게 4 피해');
    }
  } else {
    MC.runEffectList(G, [{ fx:'draw', who:'self', amount:3 }], ctx);
    MC.log(G, '닉 퓨리 — 카드 3장 드로우');
  }
};

MC.HANDLERS.nickFuryDiscard = function(G, ctx){
  const self = ctx.self;
  // 소유 플레이어 찾아 버림
  for (const pl of G.players){
    const i = pl.playArea.allies.indexOf(self);
    if (i >= 0){
      pl.playArea.allies.splice(i, 1);
      MC.moveToDiscard(G, pl, self, {});
      MC.log(G, '닉 퓨리 — 라운드 종료, 임무 완료 후 떠남 (버림)');
      break;
    }
  }
};

MC.defineCardFx('nick-fury', {
  whenPlayed: 'nickFuryChoice',
  endOfRound: 'nickFuryDiscard',
  vfx: { entrance:'tacticsInstall', install:'tacticsInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01085 — 비상사태 (Emergency)  Core Set #85
   이벤트. 저지(Thwart). Cost 0. ⚡ 에너지.
   인터럽트(저지): 빌런이 스킴할 때 → 스킴에 놓이는 위협량 1 감소.
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "🧠멘탈" 오류 → ⚡에너지 정정. cost 0 / event / Thwart / deckLimit 3 (Core Set #85).
   ★ FAQ: "난입"이라 알터에고에서도 사용. 빌런 스킴 시에만. 배치 방지(이미 놓인 위협
     제거 불가). 큰 힘에는 큰 책임의 preventNextThreat 재사용하되 히어로 피해 없이 예방만.
   ★ 엔진: special 핸들러 — G.preventNextThreat에 1 예약 → 다음 placeThreat가 1 감소.
   ★ 플레이버: 긴급 무전 콜 ("전 대원 출동! 반복한다, 전 대원 출동!")
   연출: 이벤트 = threatDrain (위협 감소).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.emergencyPrevent = function(G, ctx){
  // 다음 위협 배치를 1 감소 예약 (히어로 피해 없이 순수 예방)
  G.preventNextThreat = (G.preventNextThreat || 0) + 1;
  MC.log(G, '비상사태 — 다음 빌런 스킴 위협 1 감소 예약');
};

MC.defineCardFx('emergency', {
  special: 'emergencyPrevent',
  vfx: { event:'threatDrain' }, eventScheme:true,
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01086 — 응급처치 (First Aid)  Core Set #86
   이벤트. Cost 1. 🧠 멘탈.
   행동: 아무 캐릭터의 피해 2 회복.
   ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
     cost 1 / event / deckLimit 3 (Core Set #86).
   ★ 히어로/동료 모두 치료 가능. 다른 플레이어 동료에게도. "행동"이라 알터에고에서도.
   ★ heal 이펙트 재사용 (target:chosen, amount:2). 의료팀과 유사하나 카운터 없는 단발.
   ★ 플레이버: 클린트 바튼 — 부상 잦은 호크아이 특유의 능청스러운 자조 유머.
   연출: 이벤트 = healPulse (회복).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('first-aid', {
  effects: [{ fx:'heal', target:'chosen', amount:2 }],
  vfx: { event:'healPulse' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01087 — 강타 (Haymaker)  Core Set #87
   이벤트. 공격(Attack). Cost 2. ⚡ 에너지.
   히어로 행동(공격): 적 1명에게 3 피해.
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답, textKo 첫 줄만
     "💪피지컬" 오류 → ⚡에너지 정정. cost 2 / event / Attack / deckLimit 3 (Core #87).
   ★ 공격(Attack) 이벤트 — playForm:'hero' (히어로 상태만). dealDamage isAttack.
     심플하지만 효율적인 고정 피해 (기본 어스팩트 대표 딜링).
   ★ 플레이버: 강력한 어퍼컷의 타격음.
   연출: 이벤트 = aggressionSlash (강타 임팩트).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('haymaker', {
  playForm: 'hero',
  effects: [{ fx:'dealDamage', target:'chosen', amount:3, isAttack:true }],
  vfx: { event:'aggressionSlash' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01088~01090 — 기본 자원 카드 3종  Core Set #88~90
   에너지(Energy) ⚡×2 / 천재(Genius) 🧠×2 / 힘(Strength) 💪×2.
   자원. Cost 0. 덱당 최대 1장. 특수 효과 없음 — 순수 자원 아이콘만 제공.
   ★ 교차검증(공식 JSON): 각각 resource_energy:2 / resource_mental:2 / resource_physical:2
     확정. DB 완전 일치. type:resource, deckLimit:1 (Core Set #88~90).
   ★ 효과 없는 자원 카드 — 빈 fx 등록으로 todoFx 해제 (자원은 DB resources 필드로 처리).
     결제 시 resourceIconsOf가 DB resources를 읽어 아이콘 2개 제공.
   ★ 참고: 게임에서 이미 자원으로 활용 중 (테스트 결제·프리셋 덱). fx 등록만 누락됐던 것.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.defineCardFx('energy',   {});   // ⚡ 에너지 ×2
MC.defineCardFx('genius',   {});   // 🧠 멘탈 ×2
MC.defineCardFx('strength', {});   // 💪 피지컬 ×2
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01091 — 어벤져스 맨션 (Avengers Mansion)  Core Set #91
   지원. 어벤져(Avenger). 장소(Location). Cost 4. 🧠 멘탈. 플레이어당 최대 1장.
   행동: 어벤져스 맨션 소진 → 플레이어 1명 선택 → 그 플레이어가 카드 1장 드로우.
   ★ 교차검증(공식 JSON): resource_mental 확정. DB 완전 일치 (정정 불필요).
     cost 4 / support / Avenger+Location / deckLimit 3 (Core Set #91).
   ★ 매 턴 반복 드로우 엔진 (소진 후 다음 라운드 준비). draw 이펙트 재사용.
   ★ 멀티플레이: ctx.targetPlayer로 다른 플레이어 드로우 가능. 미지정 시 본인.
   ★ 플레이버: 자넷 밴 다인(와스프) — 저택 살림 걱정하는 위트.
   연출: 설치 = tacticsInstall(어벤져스 본부 홀로그램), 활성화 = 드로우.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.avengersMansionDraw = function(G, ctx){
  const target = (ctx.targetPlayer && G.players.find(p => p.uid === ctx.targetPlayer)) || ctx.player;
  MC.drawCards(G, target, 1);
  MC.log(G, '어벤져스 맨션 — ' + MC.nameOf(target) + ' 카드 1장 드로우');
};

MC.defineCardFx('avengers-mansion', {
  maxPerTarget: 1,   // 플레이어당 최대 1장
  activatedAbility: {
    exhaust: true,
    special: 'avengersMansionDraw',
  },
  vfx: { install:'tacticsInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01092 — 헬리캐리어 (Helicarrier)  Core Set #92
   지원. 장소(Location). S.H.I.E.L.D. Cost 3. 💪 피지컬. 플레이어당 최대 1장.
   행동: 헬리캐리어 소진 → 플레이어 1명 선택 → 그 플레이어가 이번 페이즈에 다음
   플레이하는 카드의 자원 비용 1 감소.
   ★ 교차검증(공식 JSON): resource_physical 확정. DB {physical:1} 정답, textKo 첫
     줄만 "⚡에너지" 오류 → 💪피지컬 정정. cost 3 / support / Location+S.H.I.E.L.D. (Core #92).
   ★ 엔진: nextCardDiscount 비용 할인 시스템 신설. playCard에서 유효 비용 = max(0,
     cost - discount). 사용 후 소비, 페이즈 종료 시 초기화. useCardAbility targetPlayer.
   ★ FAQ: 자원 아님 — 빌런 페이즈 반응/난입 불가. 팀 협동(다른 플레이어 할인 가능).
   ★ 플레이버: 제니퍼 월터스(쉬헐크) — 하늘 나는 항공모함에 대한 어이없어하는 반응.
   연출: 설치 = tacticsInstall(헬리캐리어 홀로그램).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.helicarrierDiscount = function(G, ctx){
  const target = (ctx.targetPlayer && G.players.find(p => p.uid === ctx.targetPlayer)) || ctx.player;
  target.nextCardDiscount = (target.nextCardDiscount || 0) + 1;
  MC.log(G, '헬리캐리어 — ' + MC.nameOf(target) + ' 다음 카드 비용 -1 (이번 페이즈)');
};

MC.defineCardFx('helicarrier', {
  maxPerTarget: 1,   // 플레이어당 최대 1장
  activatedAbility: {
    exhaust: true,
    special: 'helicarrierDiscount',
  },
  vfx: { install:'tacticsInstall' },
});
})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   기본 어스팩트 01093 — 끈기 (Tenacity)  Core Set #93
   업그레이드. 상태(Condition). Cost 2. ⚡ 에너지.
   히어로 행동: 💪피지컬 자원 1개 소비 + 이 카드를 버림 → 히어로 준비(Ready).
   ★ 교차검증(공식 JSON): resource_energy 확정. DB {energy:1} 정답 (정정 불필요).
     cost 2 / upgrade / Condition / deckLimit 3 (Core Set #93). 공식 flavor 없음.
   ★ 구조: 불굴의 정신(indomitable)과 유사(자신 버림 + 히어로 준비)하나, 방어 조건
     대신 form:hero + payCost:physical. 준비로 추가 행동 1회 확보.
   ★ 엔진: activatedAbility payCost(physical) + special(버림 + readySelf). 재사용.
   ★ 플레이버: 굴하지 않는 의지 (공식 flavor 없음 — 자체 창작).
   연출: 활성화 = combatInstall (재기/재정비).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

MC.HANDLERS.tenacityReady = function(G, ctx){
  const pl = ctx.player;
  const card = ctx.card;
  pl.exhausted = false;
  MC.log(G, '끈기 — 히어로 준비(Ready)');
  for (const arr of [pl.playArea.upgrades, pl.playArea.supports]){
    const i = arr.indexOf(card);
    if (i >= 0){ arr.splice(i, 1); break; }
  }
  MC.moveToDiscard(G, pl, card, {});
};

MC.defineCardFx('tenacity', {
  activatedAbility: {
    form: 'hero',
    payCost: { type:'physical', count:1 },
    special: 'tenacityReady',
  },
  vfx: { install:'combatInstall', ability:'combatInstall' },
});

/* 장갑 라이노 슈트(rhino-suit) — 라이노 부착 방어 갑옷 (Core Set #98)
   피해 흡수 로직은 applyDamage(mc_6_keywords.js)에 완비 — 5 피해 흡수 후 파괴.
   여기서는 연출·대사만 배선: 부착 시 suitArmor(갑옷 체결) + attach 대사,
   파괴 시 suitBreak 연출 + suitBreak 대사(UI가 G.fxSuitBreak 힌트로 트리거). */
MC.defineCardFx('rhino-suit', { vfx:{ install:'suitArmor' }, quoteKey:'rhino-suit' });

/* 돌진(charge) — 라이노 부착 (Core Set #99, ×2, 부스트 2)
   부착: ATK+3 (attachStats — attachTo/detachFrom가 적용·원복).
   강제 개입: 라이노 공격 시 과잉살상 획득(grantOverkillOnAttack) — 동료 방어 시
   초과 피해가 그 동료의 컨트롤러에게 (resolveDefensePending). 공격 종료 후 이 카드
   버림(discardAfterAttack → G.fxAttachSpent 힌트).
   연출: 부착=chargeAttach(발구르기+속도선+CHARGE!), 소모=chargeSpent(먼지 소산) */
MC.defineCardFx('charge', {
  attachStats: { attack: 3 },
  grantOverkillOnAttack: true,
  discardAfterAttack: true,
  vfx: { install: 'chargeAttach', spent: 'chargeSpent' },
  quoteKey: 'charge',
});

/* 강화된 상아 뿔(horn-attack) — 라이노 부착 무기 (Core Set #100, ×1, 부스트 2)
   부착: ATK+1 (attachStats). 히어로 행동: 💪×3 지출 → 이 카드 버림
   (useCardAbility가 빌런 부착물 탐색 + payCost 결제 → hornRemove가 detach+조우버림).
   연출: 부착=hornGrow(뿔 강화), 제거=hornRip(뿔 뽑힘 — G.fxAttachSpent 힌트 재사용) */
MC.HANDLERS.hornRemove = function(G, ctx){
  const att = ctx.card;
  MC.detachFrom(G, att);
  G.encounterDiscard.push(att);
  MC.log(G, MC.nameOf(att) + ' — 뿔 제거! 조우 버림');
  G.fxAttachSpent = { defCode: att.defCode, targetUid: G.villain && G.villain.uid,
                      seq: (G.fxSeq = (G.fxSeq || 0) + 1) };
};
MC.defineCardFx('horn-attack', {
  attachStats: { attack: 1 },
  activatedAbility: { form: 'hero', payCost: { type: 'physical', count: 3 }, special: 'hornRemove' },
  vfx: { install: 'hornGrow', spent: 'hornRip' },
  quoteKey: 'horn-attack',
});

/* 하이드라 용병(hydra-mercenary) — 라이노 조우 하수인 (Core Set #101, ×2, 부스트 1)
   Guard 키워드 — 교전 중일 때 빌런 공격 불가 (hasGuardEngaged가 basicAttack에서 검사).
   특수 능력·연출 없음 (순수 스탯 하수인 ATK 1 / SCH 0 / HP 3).
   guard 플래그는 baseFields 경유로 makeInstance가 인스턴스에 복사 → engagedMinions 검사 작동. */
MC.defineCardFx('hydra-mercenary', { guard: true, vfx: { attack: 'hydraGunfire' } });

/* 01102 샌드맨(sandman) — 라이노 조우 하수인 (Core Set #102, ×1 unique, 부스트 2)
   Toughness — 강인함 상태 카드를 갖고 등장 (makeInstance가 status.tough 부여).
   Criminal + Elite 트레잇. 특수 능력 없음 (순수 스탯 ATK3/SCH2/HP4 + 강인).
   테마: 플린트 마르코 — 돈에 집착하는 거친 모래 브롤러. 모래주먹 공격(sandBlast). */
MC.defineCardFx('sandman', { toughness: true, unique: true, vfx: { attack: 'sandBlast' } });

/* ═══ 가드 하수인 키워드 플래그 일괄 등록 (v2026.07.12.132) ═══
   문제: hasGuardEngaged 등 키워드 로직은 완비돼 있으나, 등록된 가드 하수인 18장에
   guard/patrol/retaliate/toughness/quickstrike 플래그가 DB에 누락 → 실제로 가드가
   무력화 상태(플레이어가 하수인 무시하고 빌런 직접 공격 가능)였음.
   각 카드의 공식 textKo(공식 대조 번역)를 authoritative로 정확한 플래그만 부여.
   과거 S.H.I.E.L.D. 트레잇 25장 일괄 수정과 동일한 데이터 정합성 작업.
   - guard: 교전 중 빌런 공격 불가 (basicAttack에서 hasGuardEngaged 검사)
   - patrol: 교전 중 메인 스킴 저지 불가 (basicThwart에서 hasPatrolEngaged 검사)
   - retaliate N: 공격받아 피해 시 공격자에게 N 피해 (mc_6_keywords)
   - toughness: 등장 시 강인 상태 1 (makeInstance가 status.tough 부여)
   - quickstrike: 등장 즉시 공격 (mc_5_encounter)
   - stalwart: 기절/혼란 면역 — 현재 데이터 정합성용 (로직 미구현, 향후 확장) */
[
  // 순수 Guard
  ['hydra-soldier',            { guard: true }],
  ['hydra-soldier-loh',        { guard: true }],
  ['hydra-soldier-patrol',     { guard: true }],
  ['hydra-mercenary-bw',       { guard: true }],
  ['beetle-nemesis',           { guard: true }],
  ['private-security-specialist', { guard: true }],
  ['goblin-thrall',            { guard: true }],
  ['madame-masque',            { guard: true }],
  ['advanced-drone',           { guard: true }],
  ['advanced-ultron-drone',    { guard: true }],
  // Guard + Patrol
  ['servant-bot',              { guard: true, patrol: true }],
  ['enraged-symbiote',         { guard: true, patrol: true }],
  // Guard + Retaliate
  ['yotat-the-destroyer',      { guard: true, retaliate: 1 }],
  ['sir-raston',               { guard: true, retaliate: 1 }],
  // Guard + Retaliate + Toughness
  ['the-sleeper',              { guard: true, retaliate: 1, toughness: true }],
  // Guard + Toughness
  ['armored-guard',            { guard: true, toughness: true, vfx: { attack: 'armorSlam' } }],
  // Guard + Stalwart (kree)
  ['kree-lieutenant',          { guard: true, stalwart: true }],
  // Quickstrike (Guard 아님 — 자동감지 오탐, 공식 textKo에 Guard 없음)
  ['lady-deathstrike',         { quickstrike: true }],
].forEach(([code, flags]) => {
  if (MC.CARDS[code]) MC.defineCardFx(code, flags);
});

/* 2차 감사 — 전수 재조사로 발견한 추가 키워드 누락 (공식 textKo 기준):
   patrol(메인 저지 차단), retaliate(반격), piercing(관통 — 자기 지속 능력). */
[
  ['badoon-lieutenant',        { patrol: true }],
  ['kree-commando',            { patrol: true }],
  ['badoon-sentry',            { retaliate: 1 }],
  ['omega-red',                { retaliate: 1 }],
  ['mister-knife',             { retaliate: 1 }],
  ['nebula-nemesis',           { retaliate: 2 }],
  ['whiplash',                 { retaliate: 1 }],
  ['modok',                    { retaliate: 2 }],
  ['proxima-midnight-minion',  { piercing: true }],
].forEach(([code, flags]) => {
  if (MC.CARDS[code]) MC.defineCardFx(code, flags);
});
})(typeof window !== 'undefined' ? window : globalThis);
