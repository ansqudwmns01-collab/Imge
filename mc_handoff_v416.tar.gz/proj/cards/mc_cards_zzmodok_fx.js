/* ═══════════════════════════════════════════════════════════════
   M.O.D.O.K. 모듈러 인카운터 세트 — Core Set #183~187
   Mental Organism Designed Only for Killing. AIM이 만든 거대 두뇌 사이보그.
   구성: The Doomsday Chair(사이드 스킴 ×2), M.O.D.O.K.(하수인),
         Biomechanical Upgrades(부착), Advance(배신), Assault(배신)

   01183 The Doomsday Chair — 사이드 스킴 ×2, 시작 위협 8(고정), 가속(Acceleration)
     · 공개 시: M.O.D.O.K.이 전장에 없으면 조우덱/버림 탐색→전장 배치(교전), 조우덱 셔플.
   ★ 엔진: summonNamedMinionIfAbsent(Legions of Hydra에서 신설한 범용 이펙트 재사용).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* The Doomsday Chair(01183) — 사이드 스킴. 가속. M.O.D.O.K. 소환. 시작 위협 8(고정). */
MC.defineCardFx('doomsday-chair-scheme', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'summonNamedMinionIfAbsent', code: 'modok' },
    { fx: 'playVfx', vfx: 'doomsdayChairReveal', quoteKey: 'doomsday-chair', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'doomsdayChairCleared', quoteKey: 'doomsday-chair', quoteKind: 'complete' }],
  quoteKey: 'doomsday-chair', vfx: { attack: 'doomsdayChairReveal' },
  textKo: '사이드 스킴 (모듈러) — 시작 위협 8(고정). ⚡ 가속(Acceleration). ×2.\n\n공개 시: M.O.D.O.K.이 전장에 없으면, 조우덱과 버린 더미에서 M.O.D.O.K.을 찾아 당신과 교전한 상태로 전장에 놓고 조우덱을 섞는다.\n\n*"둠스데이 체어가 가동된다 — 저 기계 옥좌에서 M.O.D.O.K.의 광기가 뿜어져 나온다!"*\n\n※ 공식 01183 The Doomsday Chair (Core Set #183, M.O.D.O.K. 모듈러, ×2) — base_threat 8 고정 · 가속 아이콘\n※ 높은 시작 위협 + 가속으로 강한 압박 · M.O.D.O.K. 소환 트리거',
});

/* M.O.D.O.K.(01184) — 하수인. 반격 2(Retaliate). AIM이 만든 거대 두뇌 사이보그. 과대망상 지성. */
MC.defineCardFx('modok', {
  vfx: { entrance: 'modokEntrance', minionAttack: 'modokAttack', defeat: 'modokDefeat' },
  textKo: '하수인 — 사이보그(Cyborg). 정예(Elite).\nATK 2 / SCH 2 / HP 8.\n\n반격 2(Retaliate): 이 캐릭터가 공격받은 후, 공격한 캐릭터에게 2 피해를 준다.\n\n*"내 지성 앞에 무릎 꿇어라 — 나는 오직 파괴를 위해 설계된 정신체다!"*\n\n※ 공식 01184 M.O.D.O.K. (Core Set #184, M.O.D.O.K. 모듈러, ×1) — Retaliate 2 (db 필드로 applyDamage 자동 처리)\n※ HP 8 + 근접 반격 2 · 원거리/이벤트 피해로 처치 권장 · 둠스데이 체어 처치 후 등장 억제',
});

/* Biomechanical Upgrades(01185) — 부착 ×3. 급증. 최대 HP 하수인에 부착(중복 불가). 처치 시 부활 방패. */
MC.defineCardFx('biomechanical-upgrades', {
  reviveOnDefeat: true,
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'attachToHighestHpMinion', excludeSameAttachment: true, surgeIfNone: true },
    { fx: 'playVfx', vfx: 'biomechUpgradesReveal', quoteKey: 'biomechanical-upgrades', quoteKind: 'attach' },
    { fx: 'surge' },
  ],
  onRevive: 'runCardEffects',
  onReviveEffects: [{ fx: 'playVfx', vfx: 'biomechUpgradesRevive', quoteKey: 'biomechanical-upgrades', quoteKind: 'revive' }],
  quoteKey: 'biomechanical-upgrades', vfx: { attack: 'biomechUpgradesReveal' }, copies: 3,
  textKo: '부착(Attachment) — 기술(Tech). 급증(Surge). ×3.\n\n최대 인쇄 HP가 가장 높은, 다른 Biomechanical Upgrades가 부착되지 않은 하수인에게 부착한다.\n\n강제 난입(Forced Interrupt): 부착된 하수인이 처치되려 할 때, 대신 그 하수인의 모든 피해를 회복시키고 이 카드를 버린다.\n\n*"AIM의 생체역학 강화 — 이 병력은 쉽게 쓰러지지 않아."*\n\n※ 공식 01185 Biomechanical Upgrades (Core Set #185, M.O.D.O.K. 모듈러, ×3) — 부착 하수인 1회 부활\n※ 부착 하수인은 처치되기 전 1회 완전 회복 · 강화를 먼저 벗겨야 확실히 처치',
});

})(typeof window !== 'undefined' ? window : globalThis);
