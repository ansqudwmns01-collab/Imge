/* ═══════════════════════════════════════════════════════════════
   블랙 팬서(티찰라) 넴시스 세트 — Core Set #155~158
   티찰라의 개인 조우 카드. 왕좌를 노리는 킬몽거와 와칸다의 위기.
   티찰라 시그니처(신분 01040a/b, panther-claws 등)는 이미 완료.

   01155 국정의 의무 (Affairs of State) — 의무(Obligation) ×1, 부스트 ▲2
     · 공개 시: 티찰라 플레이어에게. 알터에고 전환 가능. 택 1:
       ① 티찰라 소진 → 이 카드 게임에서 제거(영구 해결)
       ② 통제 중인 블랙 팬서 업그레이드 1장 버림 → 이 의무 버림
   ★ 엔진: EFFECTS.offerChoice(기존) + discardControlledUpgrade/resolveObligation(이번 신설).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 국정의 의무(01155) — 의무. 왕의 책무와 영웅 활동 사이의 갈등. */
MC.defineCardFx('obligation-bp', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'offerChoice', prompt: '국정의 의무 — 왕의 책무를 어떻게 감당할 것인가 (택 1)',
      options: [
        { key: 'exhaust', label: '티찰라를 소진 → 이 의무를 게임에서 제거',
          effects: [
            { fx: 'exhaustTarget', target: 'self' },
            { fx: 'playVfx', vfx: 'affairsOfStateResolve', quoteKey: 'affairs-of-state', quoteKind: 'duty' },
            { fx: 'resolveObligation', mode: 'game' },
          ] },
        { key: 'discard', label: '블랙 팬서 업그레이드 1장 버림 → 이 의무를 버림',
          effects: [
            { fx: 'discardControlledUpgrade', hero: 'black-panther' },
            { fx: 'playVfx', vfx: 'affairsOfStateDefer', quoteKey: 'affairs-of-state', quoteKind: 'defer' },
            { fx: 'resolveObligation', mode: 'discard' },
          ] },
      ] },
  ],
  quoteKey: 'affairs-of-state', vfx: { attack: 'affairsOfStateResolve' },
  textKo: '의무 — Obligation. 부스트 ▲2.\n\n티찰라 플레이어에게 준다. 알터에고 폼으로 전환할 수 있다. 다음 중 택 1:\n\n• 티찰라를 소진한다 → 국정의 의무를 게임에서 제거한다.\n• 통제 중인 블랙 팬서(Black Panther) 업그레이드 1장을 선택해 버린다. → 이 의무를 버린다.\n\n*"왕좌의 무게는 그것을 짊어진 자만이 안다."*\n\n※ 공식 01155 Affairs of State (Core Set #155, Black Panther 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 소진 옵션 = 영구 해결(게임 제거) · 업그레이드 버림 = 임시 회피(의무만 버림, 다시 섞임)',
});

/* 왕좌 찬탈(01156) — 사이드 스킴. 킬몽거의 쿠데타. 지속 효과: 전장에 있는 동안 알터에고 전환 봉쇄. */
MC.defineCardFx('usurp-the-throne', {
  blocksAlterEgoFlip: true,
  whenRevealed: 'runCardEffects',
  effects: [{ fx: 'playVfx', vfx: 'usurpThroneReveal', quoteKey: 'usurp-the-throne', quoteKind: 'reveal' }],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'usurpThroneCleared', quoteKey: 'usurp-the-throne', quoteKind: 'complete' }],
  quoteKey: 'usurp-the-throne', vfx: { attack: 'usurpThroneReveal' },
  textKo: '사이드 스킴 — 블랙 팬서 숙적. 시작 위협: 3/인.\n\n지속 효과: 이 스킴이 전장에 있는 동안, 블랙 팬서는 알터에고 형태로 전환할 수 없다.\n\n*"반역자 킬몽거가 와칸다를 차지하기 위한 쿠데타를 일으키고 있다."*\n\n※ 공식 01156 Usurp the Throne (Core Set #156, Black Panther 넴시스 세트, ×1) — base_threat 3/인 (공식 JSON)\n※ 알터에고 봉쇄 = 회복/알터에고 능력 차단 · 위협 제거로 처치하면 해제',
});

/* 킬몽거(01157) — 하수인. 왕좌를 노리는 냉혹한 용병·암살자. 블랙 팬서 업그레이드 피해 면역. */
MC.defineCardFx('killmonger', {
  immuneToUpgradeDamage: 'black-panther',
  vfx: { entrance: 'killmongerEntrance', minionAttack: 'killmongerAttack', defeat: 'killmongerDefeat' },
  textKo: '하수인 — 암살자(Assassin). 정예(Elite). 용병(Mercenary).\nATK 2 / SCH 2 / HP 5.\n\n지속 효과: 킬몽거는 블랙 팬서(Black Panther) 업그레이드로 인한 피해를 받지 않는다.\n\n*"네 왕좌는 내 것이 될 것이다." —에릭 킬몽거*\n\n※ 공식 01157 Killmonger (Core Set #157, Black Panther 넴시스 세트, ×1) — HP 5 (공식 JSON, db 스텁 4 정정)\n※ 팬서 발톱/에너지 단검/비브라늄 슈트 등 블랙 팬서 업그레이드 피해 무효 → 일반 공격/이벤트/동료로 처치',
});

/* 심장 모양 허브(01158) — 배신. 급증. 킬몽거의 쿠데타가 빌런 진영을 강화. */
MC.defineCardFx('heart-shaped-herb', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'grantTough', scope: 'villainAndEngaged' },
    { fx: 'playVfx', vfx: 'heartHerbReveal', quoteKey: 'heart-shaped-herb', quoteKind: 'reveal' },
    { fx: 'surge' },
  ],
  boostStarEffects: [
    { fx: 'grantTough', scope: 'villain' },
    { fx: 'playVfx', vfx: 'heartHerbReveal', quoteKey: 'heart-shaped-herb', quoteKind: 'reveal' },
  ],
  quoteKey: 'heart-shaped-herb', vfx: { attack: 'heartHerbReveal' },
  textKo: '배신 — Treachery. 급증(Surge). 부스트 ▲1.\n\n공개 시: 빌런과, 당신(히어로)과 교전 중인 각 하수인에게 강인함(Tough) 상태 카드를 1장씩 준다.\n\n★ 부스트: 빌런에게 강인함(Tough) 상태 카드를 준다.\n\n*"킬몽거의 쿠데타가 백성들을 선동한다."*\n\n※ 공식 01158 Heart-Shaped Herb (Core Set #158, Black Panther 넴시스 세트, ×1) — 공식 JSON 교차검증\n※ 급증 = 해결 후 조우 카드 1장 추가 공개 · 빌런 진영 방어 강화',
});

/* 의식 결투(01159) — 배신 ×2. 왕좌를 건 도전. 조우덱 버림 → X=부스트+1 → 피해/위협 선택. */
MC.defineCardFx('ritual-combat', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'discardEncounterComputeX', plus: 1 },
    { fx: 'offerChoice', prompt: '의식 결투 — 도전을 받아들여라 (택 1)',
      options: [
        { key: 'damage', label: '내 히어로에 X 피해',
          effects: [
            { fx: 'dealDamage', target: 'self', amountFrom: 'ritualX' },
            { fx: 'playVfx', vfx: 'ritualCombatStrike', quoteKey: 'ritual-combat', quoteKind: 'strike' },
          ] },
        { key: 'threat', label: '메인 스킴에 위협 X',
          effects: [
            { fx: 'placeThreat', scheme: 'main', amountFrom: 'ritualX' },
            { fx: 'playVfx', vfx: 'ritualCombatScheme', quoteKey: 'ritual-combat', quoteKind: 'scheme' },
          ] },
      ] },
  ],
  quoteKey: 'ritual-combat', vfx: { attack: 'ritualCombatStrike' }, copies: 2,
  textKo: '배신 — Treachery. 부스트 ▲2.\n\n공개 시: 조우덱 맨 위 카드 1장을 버린다. 그 다음 택 1 — 자기 히어로에게 X 피해를 주거나, 메인 스킴에 위협을 X만큼 놓는다.\nX = 버린 조우 카드의 부스트 아이콘 수 + 1.\n\n*"이 도전을 받아들여라, T\'Challa."*\n\n※ 공식 01159 Ritual Combat (Core Set #159, Black Panther 넴시스 세트, ×2) — 공식 JSON 교차검증\n※ X는 버린 카드에 따라 가변(최소 1) · 피해(정체성) 또는 위협(메인) 선택',
});

})(typeof window !== 'undefined' ? window : globalThis);
