/* ═══════════════════════════════════════════════════════════════
   코어 세트 플레이어 카드 한국어 플레이버 — 돋보기(info) 표시용.
   ★ 공식 영어 flavor 번역이 아니라, 각 카드의 테마/캐릭터에 맞춘 오리지널 창작 문구.
     (프로젝트 원칙: 대사·플레이버는 캐릭터 공개 성향 기반 오리지널 한국어)
   info()가 한국어 flavor를 우선 표시 → 영어 원문 대신 이 문구가 뜬다.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

const FLAVOR_KO = {
  // ─ 스파이더맨 ─
  'black-cat': '훔치는 것도 실력이지 — 오늘만큼은 네 편이지만.',
  'backflip': '한 발 물러서는 게 아니라, 공중으로 피하는 거야.',
  'enhanced-spider-sense': '위험이 닿기도 전에, 등줄기가 먼저 안다.',
  'swinging-web-kick': '거미줄로 반동, 그리고 두 발로 작렬!',
  'aunt-may': '따뜻한 밥 한 끼가 세상을 구하기도 한단다.',
  'spider-woman-ally': '거미의 힘은 나에게도 흐르고 있어.',
  // ─ 캡틴 마블 ─
  'crisis-interdiction': '위기는 번지기 전에 잘라내야 해.',
  'energy-absorption': '쏟아지는 힘? 전부 내 것으로 만든다.',
  'alpha-station': '우주 방위의 최전선, 여기서 시작된다.',
  'captain-marvel-helmet': '빛나는 투구 아래, 흔들림 없는 의지.',
  // ─ 쉬헐크 ─
  'hellcat': '발톱과 채찍, 그리고 넘치는 자신감.',
  'gamma-slam': '감마의 분노가 지면을 가른다!',
  'ground-stomp': '한 번 내리찍으면, 발밑이 무너진다.',
  'legal-practice': '법정에서도 전장에서도 — 나는 이긴다.',
  'one-two-punch': '하나, 둘 — 그리고 넉다운.',
  'split-personality': '제니퍼와 쉬헐크, 둘 다 진짜 나야.',
  'superhuman-law': '초인의 권리도, 법으로 지킨다.',
  // ─ 아이언맨 ─
  'war-machine': '화력으로 말한다 — 그게 전장의 언어지.',
  'supersonic-punch': '소리보다 빠른 주먹, 피할 방법은 없어.',
  'pepper-potts': '천재를 관리하는 것도 재능이 필요하죠.',
  'stark-tower': '혁신은 이 탑에서 태어난다.',
  'arc-reactor': '가슴 속에서 빛나는 심장, 무한한 동력.',
  'mk5-armor': '접었다 펴는 강철 — 언제든 출동 준비 완료.',
  'mk5-helmet': '시야에 뜬 데이터가 곧 승리의 지도.',
  'powered-gauntlets': '리펄서 충전 완료 — 발사.',
  // ─ 블랙 팬서 ─
  'shuri': '오빠, 이건 내가 만든 최신 기술이야.',
  'ancestral-knowledge': '선대의 목소리가 답을 알려준다.',
  'vibranium-resource': '와칸다의 보물, 무엇이든 될 수 있는 금속.',
  'golden-city': '비르닌 자나 — 황금빛 미래의 도시.',
  // ─ 용맹(Aggression) ─
  'tigra-ally': '야수의 본능과 인간의 이성, 둘 다 내 무기.',
  'chase-them-down': '도망쳐봐야 소용없어 — 끝까지 쫓는다.',
  'uppercut': '턱을 노린 한 방, 정신이 번쩍 들걸.',
  'combat-training': '반복이 곧 완성 — 몸이 먼저 기억한다.',
  'haymaker': '혼신의 한 방, 제대로 꽂아준다.',
  // ─ 정의(Justice) ─
  'daredevil': '앞이 안 보여도, 모든 걸 느낄 수 있지.',
  'jessica-jones': '사건은 내가 판다 — 그리고 주먹도.',
  'for-justice': '정의는 구호가 아니라 행동이다.',
  'interrogation-room': '진실을 말할 때까지, 나갈 생각 마.',
  // ─ 리더십(Leadership) ─
  'maria-hill': '지휘는 냉정하게, 결정은 신속하게.',
  'vision': '밀도를 바꾸면, 무엇도 나를 막지 못한다.',
  'get-ready': '숨 고르고 — 다시 간다.',
  'lead-from-the-front': '따라오라는 말보다, 앞장서는 게 낫지.',
  'make-the-call': '지원 요청 — 지금 바로.',
  'the-triskelion': '실드의 심장부, 모든 작전이 여기서 시작된다.',
  'inspired': '한 사람의 용기가 모두를 움직인다.',
  // ─ 보호(Protection) ─
  'luke-cage': '이 몸에 흠집 하나 못 낸다.',
  'counter-punch': '때려봐 — 그 두 배로 돌려주지.',
  'get-behind-me': '다들 물러서, 여긴 내가 막는다.',
  'armored-vest': '한 겹의 방어가, 목숨을 가른다.',
  'indomitable': '쓰러져도 다시 일어선다 — 그게 나다.',
  // ─ 기본(Basic) ─
  'emergency': '위급할수록, 더 침착하게.',
  'first-aid': '상처는 빠르게 — 싸움은 계속된다.',
  'avengers-mansion': '지구 최강의 영웅들, 그 집결지.',
  'helicarrier': '하늘을 나는 요새, 실드의 자존심.',
};

for (const slug in FLAVOR_KO){
  if (MC.CARDS[slug]) MC.CARDS[slug].flavor = FLAVOR_KO[slug];
}

})(typeof window !== 'undefined' ? window : globalThis);
