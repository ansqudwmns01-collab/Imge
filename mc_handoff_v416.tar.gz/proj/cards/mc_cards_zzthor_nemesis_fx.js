/* ═══════════════════════════════════════════════════════════════════
   토르(Thor) 네메시스 세트 fx — mcode 06026~06030
   로키(Loki) 네메시스: 오딘의 분노(의무) · 가족의 불화(사이드스킴) ·
   로키(하수인) · 서리 거인(하수인×2) · 속임수(배반)
   ─ db 스탯은 mc_cards_db.js, 효과·대사·연출은 이 파일에서 배선.
   ═══════════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;
if (!MC || !MC.defineCardFx) return;

/* ─────────────────────────────────────────────────────────────────
   06026 Odin's Anger (오딘의 분노) — 의무(Obligation). 오딘슨 플레이어에게 부여.
   공개 시: 알터에고 폼으로 전환 가능. 택 1:
     ① 오딘슨 소진 → 이 의무를 게임에서 영구 제거.
     ② 묠니르를 손이나 전장에서 버림 + 히어로 기절(Stunned) → 이 의무를 버림.
   범용 재사용: man-out-of-time 패턴(offerChoice 체이닝 + flipToAlterEgo + resolveObligation)
   + 신규 discardNamedCard(묠니르 지정 버림).
   ───────────────────────────────────────────────────────────────── */
const _odinMain = {
  prompt: '오딘의 분노 — 어떻게 감당할 것인가 (택 1)',
  options: [
    { key:'exhaust', label:'오딘슨을 소진 → 이 의무를 게임에서 영구 제거',
      availableIf: { type:'identityReady' },
      effects: [ { fx:'exhaustTarget', target:'self' },
                 { fx:'resolveObligation', mode:'game' } ] },
    { key:'discardMjolnir', label:'묠니르를 손/전장에서 버림 + 히어로 기절 → 이 의무를 버림',
      effects: [ { fx:'discardNamedCard', card:'mjolnir' },
                 { fx:'applyStatus', target:'self', status:'stunned' },
                 { fx:'resolveObligation', mode:'discard' } ] },
  ],
};
MC.defineCardFx('odins-anger', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{
    fx: 'offerChoice',
    prompt: '오딘의 분노 — 알터에고 폼으로 전환하시겠습니까?',
    options: [
      { key:'flip',   label:'알터에고 폼으로 전환한다',  effects:[ { fx:'flipToAlterEgo' }, { fx:'offerChoice', ..._odinMain } ] },
      { key:'noflip', label:'전환하지 않는다',          effects:[ { fx:'offerChoice', ..._odinMain } ] },
    ],
  }],
  vfx: { entrance:'revealCard' },
  textKo: '의무 — Obligation. 부스트 ▲2.\n\n오딘슨(토르) 플레이어에게 부여.\n\n공개 시: 알터에고 폼으로 전환할 수 있다. 그 후 택 1:\n• 오딘슨을 소진 → 오딘의 분노를 게임에서 제거한다.\n• 묠니르를 손이나 전장에서 버린다. 당신의 히어로가 기절(Stunned)한다. 이 의무를 버린다.\n\n*"넌 아직도 아버지의 인정을 갈구하는군. 가엾은 형제여." —로키*\n\n※ 공식 06026 Odins Anger (Thor 히어로 팩 · 네메시스 세트)\n※ 소진→제거는 영구 해결(오딘슨 준비 시). 묠니르 버림→기절은 다시 조우덱 순환\n※ 묠니르 없으면 기절만 적용 후 의무 버림',
});

/* ─────────────────────────────────────────────────────────────────
   06027 Family Feud (가족의 불화) — 사이드 스킴. 시작 위협 2. ⚡가속(Acceleration 1).
   공개 시: 아스가르드(Asgard) 카드 1장당 이 스킴에 위협 +1.
   범용 재사용: 신규 countTraitAddThreat(trait:'asgard'). Acceleration은 db accelIcons:1로 자동.
   ───────────────────────────────────────────────────────────────── */
MC.defineCardFx('family-feud', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'countTraitAddThreat', trait:'asgard' }],
  vfx: { entrance:'revealCard' },
  textKo: '사이드 스킴 — Side Scheme. 넴시스(Nemesis). 시작 위협 2 · ⚡가속(Acceleration) 1.\n\n공개 시: 전장의 아스가르드(Asgard) 카드 1장당 이 스킴에 위협 +1을 놓는다.\n\n*"오딘의 두 아들이 영원히 다투는 한, 로키는 이를 자신의 즐거움 삼아 부추긴다."*\n\n※ 공식 06027 Family Feud (Thor 히어로 팩 · 네메시스 세트)\n※ 가속 아이콘 — 빌런 페이즈마다 메인 스킴 위협 +1\n※ 아스가르드 동료·업그레이드·서포트 모두 집계 (레이디 시프·묠니르·아스가르드 등)',
});

/* ─────────────────────────────────────────────────────────────────
   06028 Loki (로키) — 하수인. 아스가르드(Asgard). ATK 2 / SCH 2 / HP 4. 부스트 ▲3.
   강제 인터럽트: 로키가 격파될 때 → 조우덱 상단 1장 버림. 그 카드가 배신(Treachery)이면 로키 전체 회복(부활).
   범용 재사용: 신규 reviveOnTreachery 인덱스(onDefeated minion 블록). 대사 quoteKey:'loki'.
   ───────────────────────────────────────────────────────────────── */
MC.defineCardFx('loki-nemesis', {
  reviveOnTreachery: true,
  vfx: { entrance:'lokiEnter', enemyAttack:'lokiAttack', defeat:'lokiVanish' },
  textKo: '하수인 — Minion. 아스가르드(Asgard). ATK 2 / SCH 2 / HP 4. 부스트 ▲3.\n\n강제 인터럽트(Forced Interrupt): 로키가 격파될 때 → 조우덱 상단 카드 1장을 버린다. 그 카드가 배신(Treachery)이면 → 로키의 모든 피해를 회복한다(부활).\n\n*"형제여, 실망한 표정이군. 좋아." —로키*\n\n※ 공식 06028 Loki (Thor 히어로 팩 · 네메시스 세트)\n※ 배신 카드가 나오면 격파가 취소되고 전체 회복 — 확실히 처치하려면 연속 타격 필요\n※ 조우덱이 비었으면 부활 판정 없이 정상 격파',
});

/* ─────────────────────────────────────────────────────────────────
   06029 Frost Giant (서리 거인) — 하수인. 거인(Giant). ATK 3 / SCH 1 / HP 4. 강인함(Toughness). 부스트 ▲1.
   ★ 부스트: 빌런이 공격 중이고 이 공격이 캐릭터에게 피해를 입히면, 그 캐릭터를 기절(Stun)시킴.
   범용 재사용: toughness:true(등장 강인함, baseFields 병합) + boostStarOnDamage(공격+피해 조건부, ctx.self=피해대상).
   ───────────────────────────────────────────────────────────────── */
MC.defineCardFx('frost-giant', {
  toughness: true,
  boostStarOnDamage: [{ fx:'applyStatus', target:'self', status:'stunned' }],
  vfx: { entrance:'frostGiantEnter', enemyAttack:'frostGiantAttack', defeat:'frostGiantSmash' },
  textKo: '하수인 — Minion. 거인(Giant). ATK 3 / SCH 1 / HP 4. 강인함(Toughness). 부스트 ▲1.\n\n★ 부스트: 빌런이 공격 중이고 이 공격이 캐릭터에게 피해를 입히면 → 그 캐릭터를 기절(Stunned)시킨다.\n\n*"요툰헤임의 서리가 너희를 얼려버리리라!"*\n\n※ 공식 06029 Frost Giant (Thor 히어로 팩 · 네메시스 세트, ×2)\n※ 등장 시 강인함 토큰 1개 (첫 피해 흡수)\n※ ★부스트는 빌런 공격의 부스트 카드로 뒤집혔을 때만 발동 (피해받은 캐릭터 기절)',
});

/* ─────────────────────────────────────────────────────────────────
   06030 Trickster (속임수) — 배신(Treachery). 부스트 ▲1.
   공개 시: 각 플레이어 덱 상단 3장 버림 → 버려진 카드의 서로 다른 타입 종류 수만큼 메인 스킴 위협 추가.
   범용 재사용: 신규 discardTopCountTypes(count:3). 가능 타입 ally/event/upgrade/support/resource (최대 5).
   ───────────────────────────────────────────────────────────────── */
MC.defineCardFx('trickster', {
  whenRevealed: 'runCardEffects',
  whenRevealedEffects: [{ fx:'discardTopCountTypes', count:3 }],
  vfx: { entrance:'revealCard' },
  textKo: '배신 — Treachery. 부스트 ▲1.\n\n공개 시: 각 플레이어는 자기 덱 상단 3장을 버린다. 그렇게 버려진 카드의 서로 다른 타입(type) 종류 1개당 메인 스킴에 위협 +1을 놓는다.\n\n*"몇 번이나 이걸 당할 거야!" —로키*\n\n※ 공식 06030 Trickster (Thor 히어로 팩 · 네메시스 세트)\n※ 가능 타입: ally · event · upgrade · support · resource (최대 5)\n※ 덱이 얇으면 버릴 카드가 줄어 위협도 감소',
});

})(typeof window !== 'undefined' ? window : globalThis);
