/* ═══════════════════════════════════════════════════════════════
   울트론 세트 인카운터 카드 — Core Set #141~150
   Ultron — 스스로를 진화의 다음 단계로 여기는 광기의 AI.
   "내겐 이제 실이 없다(There are no strings on me)" — 인류 멸종 = 평화,
   하이브 회로로 드론 군단을 지휘하며 육체(유기체)를 경멸한다.

   01141 프로그램 전송기 (Program Transmitter) — 부착물 ×1, Item.Tech, 부스트 1★
     · 울트론(빌런)에 부착: SCH +1 (공식 scheme:1 → attachStats)
     · ★강제 반응: 울트론이 암약한 후 → 각 사이드 스킴에 위협 1 (boostStarOnScheme)
     · 히어로 행동: 히어로 소진 + 🧠🧠 지불 → 이 카드 버림 (removeAbility exhaustHero)
   ★ 교차검증(core_encounter.json): boost 1, scheme 1, traits Item.Tech, ×1 확정.
   ★ 엔진: boostStarOnScheme(암약 부스트 조건부 — boostStarOnDamage의 짝),
     placeThreat scheme:'eachSide', removeAbility.exhaustHero — 모두 이번에 신설한 범용.
   연출: 부착=transmitterInstall(크림슨 회로 침투), 암약★=transmitterPulse(전파 확산).
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* ── 울트론 빌런 3스테이지 (Core Set #134~136) — 강제효과는 seed 데이터 필드로 엔진 배선.
   forcedAttackChoice(01134 공격 후 선택)/villainAttackSpawnDrone·attackBonusPerDrone(01135
   공격 시 드론+ATK)/droneBuffVillain·invulnWhileDrone(01136 지속 버프·무적)는 seed에 정의.
   여기선 whenRevealed 핸들러 + seed 카드 fx 연결만. */
MC.HANDLERS.ultronStage3Reveal = function(G, ctx){
  MC.revealSpecificSideScheme(G, 'ultrons-imperative');
  MC.log(G, '울트론 3단계 — "울트론의 명령" 사이드 스킴 공개');
  if (MC.recalcDroneStats) MC.recalcDroneStats(G);   // 지속 드론 버프를 전장 드론에 즉시 반영
};
/* 크림슨 카울 1A 셋업(01137a→b) — 울트론 드론 환경을 전장에 놓는다. */
MC.HANDLERS.ultronSetup = function(G, ctx){
  G.environments = G.environments || [];
  if (!G.environments.some(e => e.defCode === 'ultron-drones')){
    G.environments.push(MC.makeInstance(G, 'ultron-drones', {}));
    MC.log(G, '크림슨 카울 셋업 — 울트론 드론 환경 전장 배치');
  }
};
MC.defineCardFx('01134', {});
MC.defineCardFx('01135', {});
MC.defineCardFx('01136', { whenRevealed: 'ultronStage3Reveal' });

/* 프로그램 전송기(01141) — 울트론 부착물. 완전 인덱스 타입 (커스텀 핸들러 0).
   부착은 resolveEncounterCard의 attachment 케이스가 자동 처리(빌런에 attachTo). */
MC.defineCardFx('program-transmitter', {
  attachStats: { scheme: 1 },                       // 부착 동안 빌런 SCH +1 (이탈 시 자동 원복)
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'playVfx', vfx: 'transmitterInstall', quoteKey: 'ultron-transmitter', quoteKind: 'attach' },
  ],
  // ★강제 반응 — 이 카드가 "암약 활성화의 부스트"로 뒤집혔을 때만 발동 (공격 부스트는 아이콘만)
  boostStarOnScheme: [
    { fx: 'placeThreat', scheme: 'eachSide', amount: 1 },
    { fx: 'playVfx', vfx: 'transmitterPulse', quoteKey: 'ultron-transmitter', quoteKind: 'signal' },
  ],
  // 히어로 행동: 히어로 소진 + 정신🧠 2 지불 → 버림
  removeAbility: { exhaustHero: true, payIcons: { mental: 2 } },
  textKo: '부착물 — Item. Tech. 부스트 ▲1★.\n\n울트론에게 부착한다. 부착된 동안 울트론은 SCH +1.\n\n★ 강제 반응: 울트론이 암약한 후 → 각 사이드 스킴에 위협 1을 놓는다.\n\n히어로 행동: 자신의 히어로를 소진하고 🧠🧠 자원을 지불한다 → 이 카드를 버린다.\n\n※ 공식 01141 Program Transmitter (Core Set #141, Ultron 세트, ×1) — 공식 JSON 교차검증 (boost 1★ · scheme +1)\n※ ★효과는 이 카드가 암약(스킴) 활성화의 부스트 카드로 뒤집혔을 때 발동 — 공격 부스트일 땐 아이콘(▲1)만 적용',
});

})(typeof window !== 'undefined' ? window : globalThis);

/* ═══════════════════════════════════════════════════════════════
   01142 업그레이드 드론 (Upgraded Drones) — 부착물 ×2, Condition
     · "울트론 드론" 환경에 부착: 각 뒷면 Drone 하수인 ATK +1, HP +1 (droneStatBonus)
     · 히어로 행동: ⚡🧠💪 각 1 지불 → 이 카드 버림 (removeAbility)
   01140 울트론 드론 환경 — 뒷면 드론 하수인 스탯 정의(droneStats ATK1 SCH1 HP1)
     + 드론 처치 시 뒷면 카드는 소유자 버림 더미로 (엔진 onDefeated isDrone 분기)
   ★ 드론 서브시스템: spawnFacedownDrone(덱 맨 위 뒷면 드론화)/recalcDroneStats
     (부착·이탈 시 상한 조정, 피해 보존, 상한 하락 즉사) — 이번에 신설한 범용 엔진.

   01144 안드로이드 효율 (Android Efficiency) — 배신 ×3 (a=⚡/b=🧠/c=💪 변형)
     · 공개 시: 각 플레이어가 덱 맨 위 카드를 뒷면 Drone 하수인으로 전장에 놓는다 (spawnDrone eachPlayer)
     · ★부스트: 부스트로 뽑힌 플레이어 선택 — 자원 1 지불(회피) OR 뒷면 드론 등장
       (boostStarChoice → deferred flush: 자원 불가 시 자동 드론)
   ★ 엔진: EFFECTS.spawnDrone(scope eachPlayer/activePlayer, fallback),
     boostStarChoice + flushDeferredBoostChoice(공격/암약 종료 후 선택 pending) — 이번 신설.
   연출: droneConversion(덱→드론 변환), 대사 reveal/boost 각 5.

   01145 울트론의 분노 (Rage of Ultron) — 배신 ×2, 부스트 2 (★ 없음)
     · 공개 시(알터에고): 울트론이 암약 → 놓인 위협 1당 덱 맨 위 카드 1장 버림
     · 공개 시(히어로): 울트론이 공격 → 준 피해 1당 덱 맨 위 카드 1장 버림
   ★ 엔진: formBranch(폼분기), villainSchemes(위협 캡처 G._lastThreatPlaced),
     villainAttacks discardDeckPerDamage(방어 해소 시 피해량 밀링), EFFECTS.discardTopDeck,
     MC.discardTopOfDeck(덱 밀링 헬퍼) — 밀링 후속값 캡처 이번 신설.
   연출: ultronRageScheme(암약 파동)/ultronRageAttack(강타+밀링), 대사 scheme/attack 각 5.

   01146 수리 시퀀스 (Repair Sequence) — 배신 ×2, 부스트 1★
     · 공개 시: 교전 중인 Drone 1명당 울트론 2 회복. 회복 0이면 이 카드 급증(surge)
     · ★부스트: 교전 중인 Drone 1명당 울트론 1 회복
   ★ 엔진: healVillain perEngagedDrone(교전 드론 비례 회복), boostStarEffects(무조건 발동
     파라미터형 부스트★) — 이번 신설. surge는 cond healedNone 재사용(회복 분기 연출 분리).
   연출: ultronRepair(자가 수복)/ultronRepairFail(수복 실패 스파크), 대사 heal/fail 각 5.

   01147 군집 공격 (Swarm Attack) — 배신 ×2, 부스트 1 (★ 없음)
     · 공개 시: 당신과 교전 중인 각 Drone이 공격. 공격이 없었다면 덱 맨 위 카드를 뒷면 드론으로 스폰
   ★ 엔진: minionsAttack scope:'activePlayer' + fallback:'spawnDrone' (혼돈의 지배와 공용 인덱스,
     scope/fallback만 확장). 분기 연출 = cond minionsAttacked(공격/증원 분리).
   연출: droneSwarmAttack(공격, 재사용)/droneConversion(증원, 재사용), 대사 attack/reinforce 각 5.

   01148 드론 공장 (Drone Factory) — 사이드 스킴 ×1, 시작 위협 4, 가속 1, 부스트 2
     · 공개 시: 각 플레이어가 뒷면 드론 스폰 + 전장의 각 Drone 1명당 이곳에 위협 1
   ★ 엔진: spawnDrone(eachPlayer) + placeThreat scheme:'self' perDroneInPlay:1 (신설).
     가속 아이콘 1은 정의 필드(빌런 페이즈 메인 스킴 가속에 기여 — 엔진 자동).
   연출: droneFactoryActivate(생산 라인 가동)/droneFactoryShutdown(공장 정지), 대사 reveal/complete 각 5.

   01149 침습 AI (Invasive AI) — 사이드 스킴 ×1, 시작 위협 3/인, 위험(Hazard), 부스트 3
     · 공개 시: 각 플레이어가 덱 맨 위 3장을 버린다
   ★ 엔진: discardTopDeck scope:'eachPlayer'(신설). hazard 위험 = 빌런 페이즈 조우 +1 (엔진 자동).
   연출: invasiveAiActivate(전역 네트워크 해킹)/invasiveAiShutdown(연결 차단), 대사 reveal/complete 각 5.

   01150 울트론의 명령 (Ultron's Imperative) — 사이드 스킴 ×1, 시작 위협 2/인, 위험(Hazard), 부스트 3
     · 공개 시: 첫 플레이어가 덱 맨 위 2장을 뒷면 Drone 하수인으로 전장에 놓는다
   ★ 엔진: spawnDrone scope:'firstPlayer' + count:2 (신설). hazard 위험 = 빌런 페이즈 조우 +1.
   연출: hiveImperative(하이브 명령 하달)/hiveDisconnect(명령망 차단), 대사 reveal/complete 각 5.
   ═══════════════════════════════════════════════════════════════ */
(function(global){
'use strict';
const MC = global.MC;

/* 뒷면 드론 토큰 (시스템 유사카드) — 울트론 드론 환경이 정의하는 익명 하수인.
   플레이어 덱 맨 위 카드가 뒷면으로 뒤집혀 이 토큰이 된다. 실스탯은 스폰/재계산 시
   droneBaseStats(환경 droneStats + 부착 droneStatBonus 합산)로 덮어씀. */
MC.registerCards({
  'facedown-drone': {
    code: 'facedown-drone', side: 'encounter', type: 'minion',
    name: '울트론 드론', nameEn: 'Ultron Drone',
    traits: ['drone'], attack: 1, scheme: 1, hp: 1,
    vfx: { attack: 'droneSwarmAttack' },
    image: 'https://marvelcdb.com/bundles/cards/01134.png',
    textKo: '하수인 — Drone. (뒷면 드론 토큰)\n\n울트론 드론 환경이 정의하는 뒷면 하수인. 기본 ATK 1 · SCH 1 · HP 1 (업그레이드 드론 부착 시 ATK +1 · HP +1).\n\n강제 반응: 이 드론이 처치되면, 뒷면 카드를 소유자의 버림 더미에 놓는다.\n\n※ 시스템 토큰 — 공식 카드 아님 (울트론 드론 환경 01140의 규칙 구현체)',
  },
});

/* 울트론 드론 환경(01140) — 드론 스탯 정의 + 공개 연출/대사 기계화 (기존 stub 승격) */
MC.defineCardFx('ultron-drones', {
  droneStats: { attack: 1, scheme: 1, hp: 1 },
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'playVfx', vfx: 'droneHiveDeploy', quoteKey: 'ultron-drones', quoteKind: 'reveal' },
  ],
  textKo: '환경.\n\n각 뒷면 Drone 하수인은 ATK 1 · SCH 1 · HP 1을 가진다.\n\n강제 반응: 뒷면 Drone 하수인이 처치되면, 그 카드를 소유자의 버림 더미에 놓는다.\n\n※ 공식 01140 Ultron Drones (Core Set #140, Ultron 세트, ×1) — 공식 JSON 교차검증\n※ 엔진: droneStats(스탯 정의) + spawnFacedownDrone(덱 맨 위 뒷면 드론화) + onDefeated isDrone 분기(뒷면 카드 소유자 버림)',
});

/* 업그레이드 드론(01142) — 울트론 드론 환경 부착물 ×2. 완전 인덱스 타입.
   부착 라우팅은 resolveEncounterCard의 attachTarget 처리(환경 없으면 불발 버림). */
MC.defineCardFx('upgraded-drones', {
  attachTarget: 'ultron-drones',                    // "울트론 드론" 환경에 부착
  droneStatBonus: { attack: 1, hp: 1 },             // 각 뒷면 드론 ATK +1 · HP +1 (attachTo/detachFrom이 재계산)
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'playVfx', vfx: 'droneUpgrade', quoteKey: 'ultron-drones', quoteKind: 'upgrade' },
  ],
  removeAbility: { payIcons: { energy: 1, mental: 1, physical: 1 } },
  copies: 2,
  textKo: '부착물 — Condition. ×2\n\n"울트론 드론" 환경에 부착한다. 각 뒷면 Drone 하수인은 ATK +1과 체력 +1을 얻는다.\n\n히어로 행동: ⚡🧠💪 자원을 지불한다 → 이 카드를 버린다.\n\n※ 공식 01142 Upgraded Drones (Core Set #142, Ultron 세트, ×2) — 공식 JSON 교차검증\n※ 환경이 전장에 없으면 부착 불발 → 버림 · 이탈 시 드론 HP 상한 하락(피해 보존, 0 이하면 즉시 격파)',
});

/* 안드로이드 효율(01144) — 배신 ×3 (a/b/c 자원 변형, 단일 슬러그 대표=a면 ⚡).
   완전 인덱스 타입: whenRevealed=spawnDrone(eachPlayer), boostStar=선택(자원/드론).
   드론 스탯은 울트론 드론 환경(있으면)을 따르고, 없으면 fallback {1,1,1}. */
MC.defineCardFx('android-efficiency', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'spawnDrone', scope: 'eachPlayer', fallback: { attack:1, scheme:1, hp:1 } },
    { fx: 'playVfx', vfx: 'droneConversion', quoteKey: 'android-efficiency', quoteKind: 'reveal' },
  ],
  // ★부스트: 부스트로 뒤집힌 플레이어가 선택 (deferred flush가 자원 판정 후 pending/자동드론)
  boostStarChoice: {
    prompt: '안드로이드 효율 — 자원 1을 지불하거나 뒷면 드론을 등장시키세요',
    resourcePayIcons: { energy: 1 },
    resourceLabel: '⚡ 자원 1 지불 (드론 회피)',
    droneLabel: '뒷면 드론 등장',
    droneFallback: { attack:1, scheme:1, hp:1 },
    vfx: 'droneConversion',
  },
  quoteKey: 'android-efficiency',
  copies: 3,
  textKo: '배신 — Treachery. 부스트 ▲1★.\n\n공개 시: 각 플레이어는 자기 덱 맨 위 카드를 뒷면으로, 자신과 교전한 Drone 하수인으로 전장에 놓는다.\n\n★ 부스트: 선택 — ⚡ 자원 1을 지불하거나, 덱 맨 위 카드를 뒷면으로 자신과 교전한 Drone 하수인으로 전장에 놓는다.\n\n※ 공식 01144 Android Efficiency (Core Set #144, Ultron 세트, ×3 — a=⚡/b=🧠/c=💪 자원 변형) — 공식 JSON 교차검증\n※ 시뮬 단순화: 단일 슬러그 대표 = a면(⚡). 부스트★ 선택은 부스트 활성화 종료 후 처리 · 지불 자원 없으면 자동 드론\n※ 드론 스탯: 울트론 드론 환경이 있으면 그 값(업그레이드 부착 보정 포함), 없으면 기본 ATK1·SCH1·HP1',
});

/* 울트론의 분노(01145) — 폼 분기 배신 ×2. 완전 인덱스 타입(커스텀 핸들러 0).
   알터에고=암약 후 위협만큼 밀링 / 히어로=공격 후 피해만큼 밀링. */
MC.defineCardFx('rage-of-ultron', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'formBranch',
      alter: [
        { fx: 'playVfx', vfx: 'ultronRageScheme', quoteKey: 'rage-of-ultron', quoteKind: 'scheme' },
        { fx: 'villainSchemes', scheme: 'main' },
        { fx: 'discardTopDeck', amountFrom: 'lastThreatPlaced' },
      ],
      hero: [
        { fx: 'playVfx', vfx: 'ultronRageAttack', quoteKey: 'rage-of-ultron', quoteKind: 'attack' },
        { fx: 'villainAttacks', discardDeckPerDamage: true },
      ],
    },
  ],
  quoteKey: 'rage-of-ultron',
  copies: 2,
  textKo: '배신 — Treachery. 부스트 ▲2.\n\n공개 시(알터에고): 울트론이 암약한다. 이 방식으로 놓인 위협 1개당 자기 덱 맨 위 카드 1장을 버린다.\n\n공개 시(히어로): 울트론이 당신을 공격한다. 이 공격으로 준 피해 1점당 자기 덱 맨 위 카드 1장을 버린다.\n\n※ 공식 01145 Rage of Ultron (Core Set #145, Ultron 세트, ×2) — 공식 JSON 교차검증\n※ 알터에고: 놓인 위협 = 울트론 SCH · 히어로: 준 피해 = 방어 후 실제 피해량 (무방어면 전량)\n※ 덱 소진 시 인카운터 1장+리셔플 후 계속 밀링',
});

/* 수리 시퀀스(01146) — 배신 ×2. 교전 드론 비례 빌런 회복. 완전 인덱스 타입.
   회복 0(드론 없음/이미 만피)이면 급증 — cond healedNone으로 분기별 연출 분리. */
MC.defineCardFx('repair-sequence', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'healVillain', perEngagedDrone: 2 },
    { fx: 'playVfx', vfx: 'ultronRepair', quoteKey: 'repair-sequence', quoteKind: 'heal',
      cond: { type: 'healedNone', negate: true } },
    // 회복 0 → 급증 + 실패 연출
    { fx: 'surge', cond: { type: 'healedNone' } },
    { fx: 'playVfx', vfx: 'ultronRepairFail', quoteKey: 'repair-sequence', quoteKind: 'fail',
      cond: { type: 'healedNone' } },
  ],
  // ★부스트: 교전 드론 1명당 1 회복 (무조건 발동 — boostStarEffects)
  boostStarEffects: [
    { fx: 'healVillain', perEngagedDrone: 1 },
    { fx: 'playVfx', vfx: 'ultronRepair', quoteKey: 'repair-sequence', quoteKind: 'heal' },
  ],
  quoteKey: 'repair-sequence',
  copies: 2,
  textKo: '배신 — Treachery. 부스트 ▲1★.\n\n공개 시: 당신과 교전 중인 Drone 하수인 1명당 울트론이 피해 2를 회복한다. 이 방식으로 회복이 없었다면, 이 카드는 급증(surge)을 얻는다.\n\n★ 부스트: 당신과 교전 중인 Drone 하수인 1명당 울트론이 피해 1을 회복한다.\n\n※ 공식 01146 Repair Sequence (Core Set #146, Ultron 세트, ×2) — 공식 JSON 교차검증\n※ 교전 드론 = 활성 플레이어와 교전한 Drone 특성 하수인(뒷면 드론 포함) · 회복 0(드론 없음/이미 만피)이면 급증\n※ 부스트★는 부스트로 뽑히면 무조건 발동 (공격·암약 무관)',
});

/* 군집 공격(01147) — 배신 ×2. 교전 드론 일제 공격, 공격 없으면 드론 증원. 완전 인덱스 타입.
   혼돈의 지배(01133)와 minionsAttack 공용 — scope:'activePlayer' + fallback:'spawnDrone'만 다름. */
MC.defineCardFx('swarm-attack', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'minionsAttack', trait: 'drone', scope: 'activePlayer',
      fallback: 'spawnDrone', droneFallback: { attack:1, scheme:1, hp:1 } },
    { fx: 'playVfx', vfx: 'droneSwarmAttack', quoteKey: 'swarm-attack', quoteKind: 'attack',
      cond: { type: 'minionsAttacked' } },
    { fx: 'playVfx', vfx: 'droneConversion', quoteKey: 'swarm-attack', quoteKind: 'reinforce',
      cond: { type: 'minionsAttacked', negate: true } },
  ],
  vfx: { attack: 'droneSwarmAttack' }, quoteKey: 'swarm-attack',
  copies: 2,
  textKo: '배신 — Treachery. 부스트 ▲1.\n\n공개 시: 당신 히어로와 교전 중인 각 Drone 하수인이 공격한다. 이 방식으로 공격이 없었다면, 자기 덱 맨 위 카드를 뒷면으로 자신과 교전한 Drone 하수인으로 전장에 놓는다.\n\n※ 공식 01147 Swarm Attack (Core Set #147, Ultron 세트, ×2) — 공식 JSON 교차검증\n※ 혼돈의 지배(01133)와 동일 엔진(minionsAttack) — 대상=활성 플레이어 교전 드론, 공격 없으면 드론 증원\n※ 기절 드론은 기절 소모 후 공격 생략 — 모두 생략되면 증원 분기',
});

/* 드론 공장(01148) — 사이드 스킴. 시작 위협 4 + 각 플레이어 드론 스폰 + 전장 드론 수만큼 위협.
   완전 인덱스 타입: spawnDrone(eachPlayer) + placeThreat(self, perDroneInPlay). 완성 효과는 없음(위협 제거로 처치). */
MC.defineCardFx('drone-factory', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'spawnDrone', scope: 'eachPlayer', fallback: { attack:1, scheme:1, hp:1 } },
    { fx: 'placeThreat', scheme: 'self', perDroneInPlay: 1 },   // 전장 드론 수만큼 (스폰 직후 카운트)
    { fx: 'playVfx', vfx: 'droneFactoryActivate', quoteKey: 'drone-factory', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'droneFactoryShutdown', quoteKey: 'drone-factory', quoteKind: 'complete' }],
  vfx: { attack: 'droneFactoryActivate' }, quoteKey: 'drone-factory',
  textKo: '사이드 스킴. 시작 위협: 4. ⚡가속(Acceleration) 1.\n\n공개 시: 각 플레이어는 자기 덱 맨 위 카드를 뒷면으로, 자신과 교전한 Drone 하수인으로 전장에 놓는다. 전장의 Drone 하수인 1명당 이곳에 위협 1을 놓는다.\n\n※ 공식 01148 Drone Factory (Core Set #148, Ultron 세트, ×1) — base_threat 4(고정), scheme_acceleration 1 (공식 JSON 교차검증)\n※ 드론 스폰 후 전장 전체 드론(스폰분 포함) 수만큼 시작 위협 4에 추가 · 위협 제거로 처치(완성 효과 없음)',
});

/* 침습 AI(01149) — 사이드 스킴. 위험(Hazard). 각 플레이어 덱 3장 밀링. 완전 인덱스 타입.
   시작 위협 3/인(baseThreatPerPlayer, 공식 base_threat_fixed=false=per player). */
MC.defineCardFx('invasive-ai', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'discardTopDeck', scope: 'eachPlayer', amount: 3 },
    { fx: 'playVfx', vfx: 'invasiveAiActivate', quoteKey: 'invasive-ai', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'invasiveAiShutdown', quoteKey: 'invasive-ai', quoteKind: 'complete' }],
  vfx: { attack: 'invasiveAiActivate' }, quoteKey: 'invasive-ai',
  textKo: '사이드 스킴 — 위험(Hazard). 시작 위협: 인원수당 3.\n\n공개 시: 각 플레이어는 자기 덱 맨 위 3장을 버린다.\n\n*울트론이 전 세계의 무선 네트워크를 해킹해 세계적 위기를 일으키고 있다.*\n\n※ 공식 01149 Invasive AI (Core Set #149, Ultron 세트, ×1) — base_threat 3/인(base_threat_fixed=false), Hazard (공식 JSON 교차검증)\n※ 위험(Hazard): 전장에 있는 동안 빌런 페이즈마다 조우 카드 +1 (엔진 자동) · 위협 제거로 처치(완성 효과 없음)',
});

/* 울트론의 명령(01150) — 사이드 스킴. 위험(Hazard). 첫 플레이어 드론 2체 스폰. 완전 인덱스 타입.
   시작 위협 2/인(baseThreatPerPlayer, 공식 base_threat_fixed=false=per player). */
MC.defineCardFx('ultrons-imperative', {
  whenRevealed: 'runCardEffects',
  effects: [
    { fx: 'spawnDrone', scope: 'firstPlayer', count: 2, fallback: { attack:1, scheme:1, hp:1 } },
    { fx: 'playVfx', vfx: 'hiveImperative', quoteKey: 'ultrons-imperative', quoteKind: 'reveal' },
  ],
  whenCompleted: 'runCardEffects',
  whenCompletedEffects: [{ fx: 'playVfx', vfx: 'hiveDisconnect', quoteKey: 'ultrons-imperative', quoteKind: 'complete' }],
  vfx: { attack: 'hiveImperative' }, quoteKey: 'ultrons-imperative',
  textKo: '사이드 스킴 — 위험(Hazard). 시작 위협: 인원수당 2.\n\n공개 시: 첫 플레이어는 자기 덱 맨 위 2장을 뒷면으로, 자신과 교전한 Drone 하수인으로 전장에 놓는다.\n\n*울트론이 하이브 회로를 통해 드론 군단을 지휘한다.*\n\n※ 공식 01150 Ultron\'s Imperative (Core Set #150, Ultron 세트, ×1) — base_threat 2/인(base_threat_fixed=false), Hazard (공식 JSON 교차검증)\n※ 첫 플레이어만 대상(각 플레이어 아님) · 드론 2체 스폰 · 위협 제거로 처치(완성 효과 없음)',
});

})(typeof window !== 'undefined' ? window : globalThis);
